//
//  MainWindowMagnification.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2017-12-05.
//
//

#import "MainWindowMagnification.h"

NSString *notificationToMainWindowMagnification = @"notificationExecuteMainWindowMagnification";

@implementation MainWindowMagnification

-(id)initWithFrame:(NSRect)frame{
    self = [super initWithFrame:frame];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToMainWindowMagnification object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    [self setNeedsDisplay:YES];
}

-(void)mouseDown:(NSEvent *)event{
    NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
    xPointDownDisplay = clickPoint.x;
    yPointDownDisplay = clickPoint.y;
    
    int clickFlag = 0;
    
    if (upLoadingProgress == 0){
        if (xPointDownDisplay > 1140 && xPointDownDisplay < 1161 && yPointDownDisplay > 390 && yPointDownDisplay < 404){  //----Blue Line----
            if (blueLineFlag == 0) blueLineFlag = 1;
            else blueLineFlag = 0;
            
            clickFlag = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else if (xPointDownDisplay > 1140 && xPointDownDisplay < 1161 && yPointDownDisplay > 370 && yPointDownDisplay < 384){  //----Line Width----
            if (lineWidthFlag == 0) lineWidthFlag = 1;
            else if (lineWidthFlag == 1) lineWidthFlag = 2;
            else if (lineWidthFlag == 2) lineWidthFlag = 3;
            else if (lineWidthFlag == 3) lineWidthFlag = 4;
            else if (lineWidthFlag == 4) lineWidthFlag = 5;
            else lineWidthFlag = 0;
            
            clickFlag = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else if (xPointDownDisplay > 1140 && xPointDownDisplay < 1161 && yPointDownDisplay > 350 && yPointDownDisplay < 364){  //----Cell number----
            if (cellNumberFlag == 0) cellNumberFlag = 1;
            else cellNumberFlag = 0;
            
            clickFlag = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else if (xPointDownDisplay > 1140 && xPointDownDisplay < 1161 && yPointDownDisplay > 330 && yPointDownDisplay < 344){  //----End number----
            if (endNumberFlag == 0) endNumberFlag = 1;
            else endNumberFlag = 0;
            
            clickFlag = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else if (xPointDownDisplay > 1140 && xPointDownDisplay < 1161 && yPointDownDisplay > 310 && yPointDownDisplay < 324){  //----Mark Size----
            if (markSizeFlag == 0) markSizeFlag = 1;
            else if (markSizeFlag == 1) markSizeFlag = 2;
            else markSizeFlag = 0;
            
            clickFlag = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else if (xPointDownDisplay > 1130 && xPointDownDisplay < 1172 && yPointDownDisplay > 630 && yPointDownDisplay < 644){
            clickFlag = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else if (xPointDownDisplay > 1084 && xPointDownDisplay < 1126 && yPointDownDisplay > 630 && yPointDownDisplay < 644){
            clickFlag = 1;
            exportFlag8 = 1;
            
            string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
            mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Lineage_Map";
            mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            string sourceNameExport = arrayTableMain [tableCurrentRowHold][1];
            string seriesNameExport = arrayTableMain [tableCurrentRowHold][2];
            string analysisNameExport = arrayTableMain [tableCurrentRowHold][3];
            string treatNameExportSave = arrayTableMain [tableCurrentRowHold][5];
            string nameString = sourceNameExport+"_"+seriesNameExport+"_"+analysisNameExport+"_"+treatNameExportSave+"-LME";
            
            DIR *dir;
            struct dirent *dent;
            
            string entry;
            string extractString;
            int maxEntryNo = 0;
            
            dir = opendir(resultSavePath2.c_str());
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find(nameString) != -1){
                        extractString = entry.substr(entry.find("LME")+3, entry.find(".tif")-entry.find("LME")-3);
                        
                        if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                    }
                }
                
                closedir(dir);
            }
            
            maxEntryNo++;
            
            exportResultPath = resultSavePath2+"/"+nameString+to_string(maxEntryNo)+".tif";
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        
        if (exportFlag8 == 2){
            clickFlag = 1;
            exportFlag8 = 0;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        
        if (clickFlag == 1) [self setNeedsDisplay:YES];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(BOOL)acceptsFirstResponder{
    return YES;
}

-(void)drawRect:(NSRect)rect{
    if (exportFlag8 == 0){
        [[NSColor whiteColor] set];
        
        if (drawingOptionHold == 1 && liveCurrentCHNo == 0) lineageDisplayOption = 0;
        if (drawingOptionHold == 2 && liveCurrentCHNo == 0) lineageDisplayOption = 0;
        else if (drawingOptionHold == 3 && ifCurrentTime == 0) lineageDisplayOption = 0;
        else if (drawingOptionHold == 4 && ifCurrentTime == 0) lineageDisplayOption = 0;
        
        //cout<<liveCurrentCHNo<<" "<<ifCurrentTime<<" "<<ifCurrentCHNo<<" "<<lineageDisplayOption<<" Channel"<<endl;
        
        NSBezierPath *path;
        path = [NSBezierPath bezierPathWithRect: NSMakeRect(0, 0, 1176, 653)];
        [path fill];
        
        [[NSColor blackColor] set];
        
        [NSBezierPath setDefaultLineWidth:2];
        
        path = [NSBezierPath bezierPathWithRect: NSMakeRect(25, 40, 1100, 575)];
        [path stroke];
        
        if (initialArraySet == 1){
            //----Horizontal Scale----
            int horizontalTime = arrayTableDetail [tableCurrentRowHold][3];
            string timeInterval = arrayLineageDataType [tableCurrentRowHold][5];
            string timeString = "Time point (x"+timeInterval+" min)";
            NSString *timeNSstring = @(timeString.c_str());
            
            NSFont *font = [NSFont fontWithName:@"Times New Roman" size:12];
            NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
            NSAttributedString *attrStrS = [[NSAttributedString alloc] initWithString:timeNSstring attributes:attributes];
            CGFloat size2 = [attrStrS size].width;
            
            NSPoint pointA;
            NSAttributedString *attrStrA;
            NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
            
            [attributesA setObject:[NSFont boldSystemFontOfSize:12] forKey:NSFontAttributeName];
            [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            
            attrStrA = [[NSAttributedString alloc] initWithString:timeNSstring attributes:attributesA];
            pointA.x = 550-size2/(double)2;
            pointA.y = 6;
            [attrStrA drawAtPoint:pointA];
            
            double lengthDivision = horizontalTime/(double)5;
            int lengthDivisionInt = 0;
            
            if (lengthDivision <= 25) lengthDivisionInt = 25;
            else if (lengthDivision > 25 && lengthDivision <= 50) lengthDivisionInt = 50;
            else if (lengthDivision > 50 && lengthDivision <= 100) lengthDivisionInt = 100;
            else if (lengthDivision > 100 && lengthDivision <= 150) lengthDivisionInt = 100;
            else if (lengthDivision > 150 && lengthDivision <= 200) lengthDivisionInt = 200;
            else if (lengthDivision > 200 && lengthDivision <= 250) lengthDivisionInt = 200;
            else if (lengthDivision > 250 && lengthDivision <= 300) lengthDivisionInt = 300;
            else if (lengthDivision > 300 && lengthDivision <= 350) lengthDivisionInt = 300;
            else if (lengthDivision > 350 && lengthDivision <= 400) lengthDivisionInt = 300;
            else if (lengthDivision > 400 && lengthDivision <= 450) lengthDivisionInt = 400;
            else if (lengthDivision > 450 && lengthDivision <= 550) lengthDivisionInt = 500;
            else if (lengthDivision > 550 && lengthDivision <= 650) lengthDivisionInt = 600;
            else if (lengthDivision > 650 && lengthDivision <= 750) lengthDivisionInt = 700;
            else if (lengthDivision > 750 && lengthDivision <= 850) lengthDivisionInt = 800;
            else if (lengthDivision > 850 && lengthDivision <= 950) lengthDivisionInt = 900;
            else if (lengthDivision > 950 && lengthDivision <= 1050) lengthDivisionInt = 1000;
            else if (lengthDivision > 1050 && lengthDivision <= 1150) lengthDivisionInt = 1100;
            else if (lengthDivision > 1150 && lengthDivision <= 1250) lengthDivisionInt = 1200;
            else if (lengthDivision > 1250 && lengthDivision <= 1350) lengthDivisionInt = 1300;
            else if (lengthDivision > 1350 && lengthDivision <= 1450) lengthDivisionInt = 1400;
            else if (lengthDivision > 1450 && lengthDivision <= 1550) lengthDivisionInt = 1500;
            
            double lengthPix = ((1000-40)/(double)horizontalTime)*lengthDivisionInt;
            int numberOfDivision = (int)((1000-40)/(double)lengthPix)+1;
            
            NSPoint positionAA;
            NSPoint positionBB;
            
            int sift = 0;
            
            for (int counter1 = 0; counter1 < numberOfDivision; counter1++){
                positionAA.x = 40+lengthPix*counter1;
                positionAA.y = 40;
                positionBB.x = 40+lengthPix*counter1;
                positionBB.y = 50;
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                
                NSString *timeNSstring2 = @(to_string(counter1*lengthDivisionInt).c_str());
                NSDictionary *attributes2 = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                NSAttributedString *attrStrS2 = [[NSAttributedString alloc] initWithString:timeNSstring2 attributes:attributes2];
                size2 = [attrStrS2 size].width;
                
                if (counter1*lengthDivision == 0) sift = 1;
                else if (counter1*lengthDivision < 1000) sift = 2;
                
                NSPoint pointA2;
                NSAttributedString *attrStrA2;
                NSMutableDictionary *attributesA2 = [NSMutableDictionary dictionary];
                
                [attributesA2 setObject:[NSFont boldSystemFontOfSize:12] forKey:NSFontAttributeName];
                [attributesA2 setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                
                attrStrA2 = [[NSAttributedString alloc] initWithString:timeNSstring2 attributes:attributesA];
                pointA2.x = (40+lengthPix*counter1)-size2/(double)2-sift;
                pointA2.y = 25;
                [attrStrA2 drawAtPoint:pointA2];
            }
            
            //----Lineage no----
            double *cellExtractedInfo = new double [lineageExtractCount+50];
            int cellExtractedInfoCount = 0;
            
            double *cellNoList = new double [lineageExtractCount/9*4+50];
            int cellNoListCount = 0;
            
            for (unsigned long counter1 = 0; counter1 < lineageExtractCount/9*3+50; counter1++) cellNoList [counter1] = 0;
            
            for (unsigned long counter1 = 0; counter1 < lineageExtractCount/9; counter1++){
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageExtract [counter1*9], cellExtractedInfoCount++;
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageExtract [counter1*9+1], cellExtractedInfoCount++;
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageExtract [counter1*9+2], cellExtractedInfoCount++;
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageExtract [counter1*9+3], cellExtractedInfoCount++;
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageExtract [counter1*9+4], cellExtractedInfoCount++;
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageExtract [counter1*9+5], cellExtractedInfoCount++;
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageExtract [counter1*9+6], cellExtractedInfoCount++;
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageExtract [counter1*9+7], cellExtractedInfoCount++;
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageExtract [counter1*9+8], cellExtractedInfoCount++;
                
                if (arrayLineageExtract [counter1*9+3] == 1 || arrayLineageExtract [counter1*9+3] == 31 || arrayLineageExtract [counter1*9+3] == 41 || arrayLineageExtract [counter1*9+3] == 51){
                    cellNoList [cellNoListCount] = arrayLineageExtract [counter1*9+5], cellNoListCount++;
                    cellNoList [cellNoListCount] = arrayLineageExtract [counter1*9+4], cellNoListCount++;
                    cellNoList [cellNoListCount] = 0, cellNoListCount++;
                    cellNoList [cellNoListCount] = arrayLineageExtract [counter1*9+6], cellNoListCount++;
                }
            }
            
            //for (int counterA = 0; counterA < cellExtractedInfoCount/8; counterA++){
            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<cellExtractedInfo [counterA*8+counterB];
            //    cout<<" cellExtractedInfo "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < cellNoListCount/4; counterA++){
            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<cellNoList [counterA*4+counterB];
            //    cout<<" cellNoList "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < ifValueExtractCount/13; counterA++){
            //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<ifValueExtract [counterA*13+counterB];
            //    cout<<" ifValueExtract "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < cellNoListCount/4; counterA++){
            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<to_string(cellNoList [counterA*4+counterB]);
            //    cout<<" cellNoList "<<counterA<<endl;
            //}
            
            string extensionNoExtract;
            string extensionNoExtract2;
            string extensionNoExtractB;
            int extensionValueSource = 0;
            
            double extensionValue = 0;
            double parentInfo = 0;
            
            for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                if (cellNoList [counter2*4] <= 299999999 && cellNoList [counter2*4] >= -299999999){
                    cellNoList [counter2*4+2] = cellNoList [counter2*4]*1000000;
                    cellNoList [counter2*4+1] = cellNoList [counter2*4+1]*1000000;
                }
                else if (cellNoList [counter2*4] <= 499999999 && cellNoList [counter2*4] >= 300000000 && cellNoList [counter2*4+1] <= 299999999 && cellNoList [counter2*4+1] >= -299999999){
                    extensionNoExtract = to_string(cellNoList [counter2*4]);
                    
                    if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                    
                    extensionNoExtract = extensionNoExtract.substr(6, 3);
                    extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                    extensionNoExtractB = to_string(extensionValueSource)+"000";
                    extensionNoExtract2 = to_string(cellNoList [counter2*4+1]);
                    
                    if ((int)extensionNoExtract2.find(".") != -1) extensionNoExtract2 = extensionNoExtract2.substr(0, extensionNoExtract2.find("."));
                    
                    extensionNoExtract2 = extensionNoExtract2+"000000";
                    extensionValue = atof(extensionNoExtract2.c_str())+atof(extensionNoExtractB.c_str());
                    
                    cellNoList [counter2*4+2] = extensionValue;
                    cellNoList [counter2*4+1] = cellNoList [counter2*4+1]*1000000;
                }
                else if (cellNoList [counter2*4] >= -499999999 && cellNoList [counter2*4] <= -300000000 && cellNoList [counter2*4+1] <= 299999999 && cellNoList [counter2*4+1] >= -299999999){
                    extensionNoExtract = to_string(cellNoList [counter2*4]);
                    
                    if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                    
                    extensionNoExtract = extensionNoExtract.substr(7, 3);
                    extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                    extensionNoExtractB = to_string(extensionValueSource)+"000";
                    
                    extensionNoExtract2 = to_string(cellNoList [counter2*4+1]);
                    
                    if ((int)extensionNoExtract2.find(".") != -1) extensionNoExtract2 = extensionNoExtract2.substr(0, extensionNoExtract2.find("."));
                    
                    extensionNoExtract2 = extensionNoExtract2+"000000";
                    extensionValue = atof(extensionNoExtract2.c_str())+atof(extensionNoExtractB.c_str());
                    
                    cellNoList [counter2*4+2] = extensionValue;
                    cellNoList [counter2*4+1] = cellNoList [counter2*4+1]*1000000;
                }
            }
            
            for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                if (cellNoList [counter2*4] <= 499999999 && cellNoList [counter2*4] >= 300000000 && cellNoList [counter2*4+1] <= 499999999 && cellNoList [counter2*4+1] >= 300000000){
                    extensionNoExtract = to_string(cellNoList [counter2*4]);
                    
                    if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                    
                    extensionNoExtract = extensionNoExtract.substr(6, 3);
                    parentInfo = 0;
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter3*4] == cellNoList [counter2*4+1]){
                            parentInfo = cellNoList [counter3*4+1];
                            break;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter2*4+1] == cellNoList [counter3*4] && cellNoList [counter3*4+1] > 999999999 && cellNoList [counter2*4+3] == cellNoList [counter3*4+3]){
                            extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                            extensionNoExtractB = to_string(extensionValueSource)+"000";
                            extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                            cellNoList [counter2*4+2] = extensionValue;
                            cellNoList [counter2*4+1] = cellNoList [counter3*4+2];
                            break;
                        }
                    }
                }
                else if (cellNoList [counter2*4] >= -499999999 && cellNoList [counter2*4] <= -300000000 && cellNoList [counter2*4+1] >= -499999999 && cellNoList [counter2*4+1] <= -300000000){
                    extensionNoExtract = to_string(cellNoList [counter2*4]);
                    
                    if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                    
                    extensionNoExtract = extensionNoExtract.substr(7, 3);
                    parentInfo = 0;
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter3*4] == cellNoList [counter2*4+1]){
                            parentInfo = cellNoList [counter3*4+1];
                            break;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter2*4+1] == cellNoList [counter3*4] && cellNoList [counter3*4+1] < -999999999 && cellNoList [counter2*4+3] == cellNoList [counter3*4+3]){
                            extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                            extensionNoExtractB = to_string(extensionValueSource)+"000";
                            extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                            cellNoList [counter2*4+2] = extensionValue;
                            cellNoList [counter2*4+1] = cellNoList [counter3*4+2];
                            break;
                        }
                    }
                }
            }
            
            for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                if (cellNoList [counter2*4] <= 699999999 && cellNoList [counter2*4] >= 500000000 && cellNoList [counter2*4+1] <= 499999999 && cellNoList [counter2*4+1] >= 300000000){
                    extensionNoExtract = to_string(cellNoList [counter2*4]);
                    
                    if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                    
                    extensionNoExtract = extensionNoExtract.substr(6, 3);
                    parentInfo = 0;
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter3*4] == cellNoList [counter2*4+1]){
                            parentInfo = cellNoList [counter3*4+1];
                            break;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter2*4+1] == cellNoList [counter3*4] && cellNoList [counter3*4+1] > 999999999 && cellNoList [counter2*4+3] == cellNoList [counter3*4+3]){
                            extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                            extensionNoExtractB = to_string(extensionValueSource);
                            extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                            cellNoList [counter2*4+2] = extensionValue;
                            cellNoList [counter2*4+1] = cellNoList [counter3*4+2];
                            break;
                        }
                    }
                }
                else if (cellNoList [counter2*4] >= -699999999 && cellNoList [counter2*4] <= -500000000 && cellNoList [counter2*4+1] >= -499999999 && cellNoList [counter2*4+1] <= -300000000){
                    extensionNoExtract = to_string(cellNoList [counter2*4]);
                    
                    if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                    
                    extensionNoExtract = extensionNoExtract.substr(7, 3);
                    parentInfo = 0;
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter3*4] == cellNoList [counter2*4+1]){
                            parentInfo = cellNoList [counter3*4+1];
                            break;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter2*4+1] == cellNoList [counter3*4] && cellNoList [counter3*4+1] < -999999999 && cellNoList [counter2*4+3] == cellNoList [counter3*4+3]){
                            extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                            extensionNoExtractB = to_string(extensionValueSource);
                            extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                            cellNoList [counter2*4+2] = extensionValue;
                            cellNoList [counter2*4+1] = cellNoList [counter3*4+2];
                            break;
                        }
                    }
                }
            }
            
            for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                if (cellNoList [counter2*4] <= 699999999 && cellNoList [counter2*4] >= 500000000 && cellNoList [counter2*4+1] <= 699999999 && cellNoList [counter2*4+1] >= 500000000){
                    extensionNoExtract = to_string(cellNoList [counter2*4]);
                    
                    if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                    
                    extensionNoExtract = extensionNoExtract.substr(6, 3);
                    parentInfo = 0;
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter3*4] == cellNoList [counter2*4+1]){
                            parentInfo = cellNoList [counter3*4+1];
                            break;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter2*4+1] == cellNoList [counter3*4] && cellNoList [counter3*4+1] > 999999999 && cellNoList [counter2*4+3] == cellNoList [counter3*4+3]){
                            extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                            extensionNoExtractB = to_string(extensionValueSource);
                            extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                            cellNoList [counter2*4+2] = extensionValue;
                            cellNoList [counter2*4+1] = cellNoList [counter3*4+2];
                            break;
                        }
                    }
                }
                else if (cellNoList [counter2*4] >= -699999999 && cellNoList [counter2*4] <= -500000000 && cellNoList [counter2*4+1] >= -699999999 && cellNoList [counter2*4+1] <= -500000000){
                    extensionNoExtract = to_string(cellNoList [counter2*4]);
                    
                    if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                    
                    extensionNoExtract = extensionNoExtract.substr(7, 3);
                    parentInfo = 0;
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter3*4] == cellNoList [counter2*4+1]){
                            parentInfo = cellNoList [counter3*4+1];
                            break;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter2*4+1] == cellNoList [counter3*4] && cellNoList [counter3*4+1] < -999999999 && cellNoList [counter2*4+3] == cellNoList [counter3*4+3]){
                            extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                            extensionNoExtractB = to_string(extensionValueSource);
                            extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                            cellNoList [counter2*4+2] = extensionValue;
                            cellNoList [counter2*4+1] = cellNoList [counter3*4+2];
                            break;
                        }
                    }
                }
            }
            
            //for (int counterA = 0; counterA < cellNoListCount/4; counterA++){
            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<to_string(cellNoList [counterA*4+counterB]);
            //    cout<<" cellNoList "<<counterA<<endl;
            //}
            
            int findBoth = 0;
            double cellNoSummary = 0;
            double lingNoSummary = 0;
            double cellNoEntry1 = 0;
            double cellNoEntry2 = 0;
            
            for (int counter1 = 0; counter1 < cellExtractedInfoCount/9; counter1++){
                if (cellNoSummary != cellExtractedInfo [counter1*9+5] || lingNoSummary != cellExtractedInfo [counter1*9+6]){
                    cellNoSummary = cellExtractedInfo [counter1*9+5];
                    lingNoSummary = cellExtractedInfo [counter1*9+6];
                    
                    findBoth = 0;
                    cellNoEntry1 = 0;
                    cellNoEntry2 = 0;
                    
                    for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                        if (cellExtractedInfo [counter1*9+5] == cellNoList [counter2*4] && cellExtractedInfo [counter1*9+6] == cellNoList [counter2*4+3]){
                            cellNoEntry1 = cellNoList [counter2*4+2];
                            findBoth++;
                        }
                        
                        if (cellExtractedInfo [counter1*9+4] == cellNoList [counter2*4] && cellExtractedInfo [counter1*9+6] == cellNoList [counter2*4+3]){
                            cellNoEntry2 = cellNoList [counter2*4+2];
                            findBoth++;
                        }
                        
                        if (findBoth == 2){
                            break;
                        }
                    }
                    
                    cellExtractedInfo [counter1*9+5] = cellNoEntry1;
                    cellExtractedInfo [counter1*9+4] = cellNoEntry2;
                }
                else cellExtractedInfo [counter1*9+5] = cellNoEntry1;
                
                if (cellExtractedInfo [counter1*9+3] == 91 || cellExtractedInfo [counter1*9+3] == 92){
                    for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                        if (cellExtractedInfo [counter1*9+4] == cellNoList [counter2*4]){
                            cellExtractedInfo [counter1*9+4] = cellNoList [counter2*4+2];
                            break;
                        }
                    }
                }
            }
            
            double *cellExtractedInfoSummary = new double [cellExtractedInfoCount+50];
            int cellExtractedInfoSummaryCount = 0;
            
            cellNoSummary = 0;
            lingNoSummary = 0;
            
            for (int counter1 = 0; counter1 < cellExtractedInfoCount/9; counter1++){
                if (cellExtractedInfo [counter1*9+3] != 2){
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+1], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+2], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+3], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+4], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+5], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+6], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+7], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+8], cellExtractedInfoSummaryCount++;
                }
                
                if (cellNoSummary != cellExtractedInfo [counter1*9+5] || lingNoSummary != cellExtractedInfo [counter1*9+6]){
                    cellNoSummary = cellExtractedInfo [counter1*9+5];
                    lingNoSummary = cellExtractedInfo [counter1*9+6];
                    
                    if (counter1 != 0 && cellExtractedInfo [(counter1-1)*9+3] == 2){
                        cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [(counter1-1)*9], cellExtractedInfoSummaryCount++;
                        cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [(counter1-1)*9+1], cellExtractedInfoSummaryCount++;
                        cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [(counter1-1)*9+2], cellExtractedInfoSummaryCount++;
                        cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [(counter1-1)*9+3], cellExtractedInfoSummaryCount++;
                        cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [(counter1-1)*9+4], cellExtractedInfoSummaryCount++;
                        cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [(counter1-1)*9+5], cellExtractedInfoSummaryCount++;
                        cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [(counter1-1)*9+6], cellExtractedInfoSummaryCount++;
                        cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [(counter1-1)*9+7], cellExtractedInfoSummaryCount++;
                        cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [(counter1-1)*9+8], cellExtractedInfoSummaryCount++;
                    }
                }
                
                if (counter1 == cellExtractedInfoCount/9-1 && cellExtractedInfoCount/9-1 != 0){
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+1], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+2], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+3], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+4], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+5], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+6], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+7], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+8], cellExtractedInfoSummaryCount++;
                }
            }
            
            int lineageFuseNo = 0;
            
            for (int counter1 = 0; counter1 < lineageLinkListLength; counter1++){
                if (arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1] != 0){
                    lineageFuseNo++;
                }
            }
            
            if (lineageFuseNo <= 3){
                string lineageNo = to_string(arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength]);
                
                for (int counter1 = 1; counter1 < lineageLinkListLength; counter1++){
                    if (arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1] != 0){
                        lineageNo = lineageNo+", "+to_string(arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1]);
                    }
                }
                
                lineageNo = "Lineage: "+lineageNo;
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(lineageNo.c_str()) attributes:attributesA];
                pointA.x = 30;
                pointA.y = 625;
                [attrStrA drawAtPoint:pointA];
            }
            else if (lineageFuseNo > 3 && lineageFuseNo <= 6){
                string lineageNo = "Lineage:";
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(lineageNo.c_str()) attributes:attributesA];
                pointA.x = 30;
                pointA.y = 625;
                [attrStrA drawAtPoint:pointA];
                
                lineageNo = to_string(arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength]);
                
                for (int counter1 = 1; counter1 < 3; counter1++){
                    if (arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1] != 0){
                        lineageNo = lineageNo+", "+to_string(arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1]);
                    }
                }
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(lineageNo.c_str()) attributes:attributesA];
                pointA.x = 85;
                pointA.y = 632;
                [attrStrA drawAtPoint:pointA];
                
                lineageNo = to_string(arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+3]);
                
                for (int counter1 = 4; counter1 < lineageLinkListLength; counter1++){
                    if (arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1] != 0){
                        lineageNo = lineageNo+", "+to_string(arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1]);
                    }
                }
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(lineageNo.c_str()) attributes:attributesA];
                pointA.x = 85;
                pointA.y = 618;
                [attrStrA drawAtPoint:pointA];
            }
            else if (lineageFuseNo > 6){
                string lineageNo = "";
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(lineageNo.c_str()) attributes:attributesA];
                pointA.x = 30;
                pointA.y = 625;
                [attrStrA drawAtPoint:pointA];
                
                lineageNo = to_string(arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength]);
                
                for (int counter1 = 1; counter1 < 3; counter1++){
                    if (arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1] != 0){
                        lineageNo = lineageNo+", "+to_string(arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1]);
                    }
                }
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(lineageNo.c_str()) attributes:attributesA];
                pointA.x = 85;
                pointA.y = 632;
                [attrStrA drawAtPoint:pointA];
                
                lineageNo = to_string(arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+3]);
                
                for (int counter1 = 4; counter1 < 6; counter1++){
                    if (arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1] != 0){
                        lineageNo = lineageNo+", "+to_string(arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1]);
                    }
                }
                
                lineageNo = lineageNo+"+";
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(lineageNo.c_str()) attributes:attributesA];
                pointA.x = 85;
                pointA.y = 618;
                [attrStrA drawAtPoint:pointA];
            }
            
            //for (int counterA = 0; counterA < cellExtractedInfoCount/9; counterA++){
            //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<to_string(cellExtractedInfo [counterA*9+counterB]);
            //    cout<<" cellExtractedInfo "<<counterA<<endl;
            //}
            
            //----Doubling time Calculation----
            int shortestDoublingTime = 1000000;
            int longestDoublingTime = 0;
            int meanDoublingTime = 0;
            int numberOfDoubling = 0;
            int timeTemp = 0;
            
            for (int counter1 = 0; counter1 < cellExtractedInfoSummaryCount/9; counter1++){
                if (cellExtractedInfoSummary [counter1*9+3] == 31 || cellExtractedInfoSummary [counter1*9+3] == 41 || cellExtractedInfoSummary [counter1*9+3] == 51){
                    timeTemp = (int)(cellExtractedInfoSummary [counter1*9+2]);
                    
                    for (int counter2 = 0; counter2 < cellExtractedInfoSummaryCount/9; counter2++){
                        if (cellExtractedInfoSummary [counter2*9+5] == cellExtractedInfoSummary [counter1*9+5] && cellExtractedInfoSummary [counter2*9+6] == cellExtractedInfoSummary [counter1*9+6] && (cellExtractedInfoSummary [counter2*9+3] == 32 || cellExtractedInfoSummary [counter2*9+3] == 42 || cellExtractedInfoSummary [counter2*9+3] == 52)){
                            if (cellExtractedInfoSummary [counter2*9+2]-timeTemp < shortestDoublingTime) shortestDoublingTime = (int)(cellExtractedInfoSummary [counter2*9+2]-timeTemp);
                            if (cellExtractedInfoSummary [counter2*9+2]-timeTemp > longestDoublingTime) longestDoublingTime = (int)(cellExtractedInfoSummary [counter2*9+2]-timeTemp);
                            meanDoublingTime = meanDoublingTime+(int)(cellExtractedInfoSummary [counter2*9+2]-timeTemp);
                            
                            numberOfDoubling++;
                            break;
                        }
                    }
                }
            }
            
            double shortestDoublingTimeDouble = 0;
            double longestDoublingTimeDouble = 0;
            double meanDoublingTimeDouble = 0;
            
            if (shortestDoublingTime == 1000000) shortestDoublingTime = 0;
            
            if (meanDoublingTime != 0) meanDoublingTimeDouble = meanDoublingTime/(double)numberOfDoubling;
            
            shortestDoublingTimeDouble = shortestDoublingTime*atoi(timeInterval.c_str())/(double)60;
            shortestDoublingTime = (int)(shortestDoublingTimeDouble*100);
            shortestDoublingTimeDouble = shortestDoublingTime/(double)100;
            
            longestDoublingTimeDouble = longestDoublingTime*atoi(timeInterval.c_str())/(double)60;
            longestDoublingTime = (int)(longestDoublingTimeDouble*100);
            longestDoublingTimeDouble = longestDoublingTime/(double)100;
            
            meanDoublingTimeDouble = meanDoublingTimeDouble*atoi(timeInterval.c_str())/(double)60;
            meanDoublingTime = (int)(meanDoublingTimeDouble*100);
            meanDoublingTimeDouble = meanDoublingTime/(double)100;
            
            stringstream extension1;
            extension1 << shortestDoublingTimeDouble;
            string shortestString = extension1.str();
            
            stringstream extension2;
            extension2 << longestDoublingTimeDouble;
            string longestString = extension2.str();
            
            stringstream extension3;
            extension3 << meanDoublingTimeDouble;
            string meanString = extension3.str();
            
            string doubling = "Doub. M: "+meanString;
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(doubling.c_str()) attributes:attributesA];
            pointA.x = 200;
            pointA.y = 618;
            [attrStrA drawAtPoint:pointA];
            
            if (longestString == "0") doubling = "Doub. T : 0";
            else doubling = "Doub. T : "+shortestString+"-"+longestString;
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(doubling.c_str()) attributes:attributesA];
            pointA.x = 200;
            pointA.y = 632;
            [attrStrA drawAtPoint:pointA];
            
            //for (int counterA = 0; counterA < ifDataExtractCount/4; counterA++){
            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<ifDataExtract [counterA*4+counterB];
            //    cout<<" ifDataExtract "<<counterA<<endl;
            //}
            
            string ifString;
            
            [[NSColor blueColor] set];
            [NSBezierPath setDefaultLineWidth:1];
            
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(1140, 390, 20, 14)];
            [path stroke];
            
            if (blueLineFlag == 0) ifString = "B";
            else if (blueLineFlag == 1) ifString = "N";
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(ifString.c_str()) attributes:attributesA];
            pointA.x = 1146;
            pointA.y = 390;
            [attrStrA drawAtPoint:pointA];
            
            [[NSColor blueColor] set];
            [NSBezierPath setDefaultLineWidth:1];
            
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(1140, 370, 20, 14)];
            [path stroke];
            
            if (lineWidthFlag == 0) ifString = "L1";
            else if (lineWidthFlag == 1) ifString = "L2";
            else if (lineWidthFlag == 2) ifString = "L3";
            else if (lineWidthFlag == 3) ifString = "L4";
            else if (lineWidthFlag == 4) ifString = "L5";
            else if (lineWidthFlag == 5) ifString = "L6";
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(ifString.c_str()) attributes:attributesA];
            pointA.x = 1143;
            pointA.y = 370;
            [attrStrA drawAtPoint:pointA];
            
            [[NSColor blueColor] set];
            [NSBezierPath setDefaultLineWidth:1];
            
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(1140, 350, 20, 14)];
            [path stroke];
            
            if (cellNumberFlag == 0) ifString = "C1";
            else if (cellNumberFlag == 1) ifString = "C0";
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(ifString.c_str()) attributes:attributesA];
            pointA.x = 1142;
            pointA.y = 350;
            [attrStrA drawAtPoint:pointA];
            
            [[NSColor blueColor] set];
            [NSBezierPath setDefaultLineWidth:1];
            
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(1140, 330, 20, 14)];
            [path stroke];
            
            if (endNumberFlag == 0) ifString = "E1";
            else if (endNumberFlag == 1) ifString = "E0";
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(ifString.c_str()) attributes:attributesA];
            pointA.x = 1143;
            pointA.y = 330;
            [attrStrA drawAtPoint:pointA];
            
            [[NSColor blueColor] set];
            [NSBezierPath setDefaultLineWidth:1];
            
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(1140, 310, 20, 14)];
            [path stroke];
            
            if (markSizeFlag == 0) ifString = "M1";
            else if (markSizeFlag == 1) ifString = "M2";
            else if (markSizeFlag == 2) ifString = "M0";
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(ifString.c_str()) attributes:attributesA];
            pointA.x = 1141;
            pointA.y = 310;
            [attrStrA drawAtPoint:pointA];
            
            [[NSColor blueColor] set];
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(1130, 630, 41, 14)];
            [path stroke];
            
            ifString = "Reload";
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(ifString.c_str()) attributes:attributesA];
            pointA.x = 1130;
            pointA.y = 630;
            [attrStrA drawAtPoint:pointA];
            
            [[NSColor blueColor] set];
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(1084, 630, 42, 14)];
            [path stroke];
            
            ifString = "Export";
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(ifString.c_str()) attributes:attributesA];
            pointA.x = 1086;
            pointA.y = 630;
            [attrStrA drawAtPoint:pointA];
            
            //for (int counterA = 0; counterA < ifTimeExtractCount/2; counterA++){
            //    for (int counterB = 0; counterB < 2; counterB++) cout<<" "<<ifTimeExtract [counterA*2+counterB];
            //    cout<<" iifTimeExtract "<<counterA<<endl;
            //}
            
            //----Lineage display Horizontal set----
            [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            
            int numberOfCellEntry = 0;
            int numberOfEventCount = 0;
            
            for (int counter1 = 0; counter1 < cellExtractedInfoSummaryCount/9; counter1++){
                if (cellExtractedInfoSummary [counter1*9+3] == 1 || cellExtractedInfoSummary [counter1*9+3] == 31 || cellExtractedInfoSummary [counter1*9+3] == 41 || cellExtractedInfoSummary [counter1*9+3] == 51){
                    numberOfCellEntry++;
                    numberOfEventCount++;
                }
                
                if (cellExtractedInfoSummary [counter1*9+3] == 32 || cellExtractedInfoSummary [counter1*9+3] == 42 || cellExtractedInfoSummary [counter1*9+3] == 52 || cellExtractedInfoSummary [counter1*9+3] == 91 || cellExtractedInfoSummary [counter1*9+3] == 6 || cellExtractedInfoSummary [counter1*9+3] == 92 || cellExtractedInfoSummary [counter1*9+3] == 8 || cellExtractedInfoSummary [counter1*9+3] == 10 || cellExtractedInfoSummary[counter1*9+3] == 11 || cellExtractedInfoSummary [counter1*9+3] == 7){
                    numberOfEventCount++;
                }
            }
            
            double *horizontalList = new double [numberOfCellEntry*7+50];
            int horizontalListCount = 0;
            double *eventList = new double [numberOfEventCount*5+50];
            int eventListCount = 0;
            
            int largestTimePoint = 0;
            int findFlag = 0;
            
            for (int counter1 = 0; counter1 < cellExtractedInfoSummaryCount/9; counter1++){
                if (cellExtractedInfoSummary [counter1*9+3] == 1 || cellExtractedInfoSummary [counter1*9+3] == 31 || cellExtractedInfoSummary [counter1*9+3] == 41 || cellExtractedInfoSummary [counter1*9+3] == 51){
                    horizontalList [horizontalListCount] = cellExtractedInfoSummary [counter1*9+5], horizontalListCount++;
                    horizontalList [horizontalListCount] = cellExtractedInfoSummary [counter1*9+6], horizontalListCount++;
                    horizontalList [horizontalListCount] = cellExtractedInfoSummary [counter1*9+8], horizontalListCount++;
                    horizontalList [horizontalListCount] = cellExtractedInfoSummary [counter1*9+2], horizontalListCount++;
                    
                    largestTimePoint = 0;
                    findFlag = 0;
                    
                    for (int counter2 = 0; counter2 < cellExtractedInfoSummaryCount/9; counter2++){
                        if ((cellExtractedInfoSummary [counter2*9+3] == 32 || cellExtractedInfoSummary [counter2*9+3] == 42 || cellExtractedInfoSummary [counter2*9+3] == 52 || cellExtractedInfoSummary [counter2*9+3] == 91 || cellExtractedInfoSummary [counter2*9+3] == 6 || cellExtractedInfoSummary [counter2*9+3] == 92 || cellExtractedInfoSummary [counter2*9+3] == 8 || cellExtractedInfoSummary [counter2*9+3] == 10 || cellExtractedInfoSummary [counter2*9+3] == 11 || cellExtractedInfoSummary [counter2*9+3] == 7) && cellExtractedInfoSummary [counter2*9+5] == cellExtractedInfoSummary [counter1*9+5] && cellExtractedInfoSummary [counter2*9+6] == cellExtractedInfoSummary [counter1*9+6]){
                            eventList [eventListCount] = cellExtractedInfoSummary [counter2*9+5], eventListCount++;
                            eventList [eventListCount] = cellExtractedInfoSummary [counter2*9+6], eventListCount++;
                            eventList [eventListCount] = cellExtractedInfoSummary [counter2*9+2], eventListCount++;
                            eventList [eventListCount] = cellExtractedInfoSummary [counter2*9+3], eventListCount++;
                            eventList [eventListCount] = 0, eventListCount++;
                        }
                    }
                    
                    for (int counter2 = 0; counter2 < cellExtractedInfoSummaryCount/9; counter2++){
                        if ((cellExtractedInfoSummary [counter2*9+3] == 32 || cellExtractedInfoSummary [counter2*9+3] == 42 || cellExtractedInfoSummary [counter2*9+3] == 52 || cellExtractedInfoSummary [counter2*9+3] == 91) && cellExtractedInfoSummary [counter2*9+5] == cellExtractedInfoSummary [counter1*9+5] && cellExtractedInfoSummary [counter2*9+6] == cellExtractedInfoSummary [counter1*9+6]){
                            horizontalList [horizontalListCount] = cellExtractedInfoSummary [counter2*9+2], horizontalListCount++;
                            horizontalList [horizontalListCount] = cellExtractedInfoSummary [counter2*9+3], horizontalListCount++;
                            findFlag = 1;
                            break;
                        }
                        else{
                            
                            if (cellExtractedInfoSummary [counter2*9+5] == cellExtractedInfoSummary [counter1*9+5] && cellExtractedInfoSummary [counter2*9+6] == cellExtractedInfoSummary [counter1*9+6]){
                                if (cellExtractedInfoSummary [counter2*9+2] > largestTimePoint) largestTimePoint = (int)(cellExtractedInfoSummary [counter2*9+2]);
                            }
                        }
                    }
                    
                    if (findFlag == 0){
                        horizontalList [horizontalListCount] = largestTimePoint, horizontalListCount++;
                        horizontalList [horizontalListCount] = 2, horizontalListCount++;
                    }
                    
                    if (cellExtractedInfoSummary [counter1*9+3] == 1) horizontalList [horizontalListCount] = 1, horizontalListCount++;
                    else horizontalList [horizontalListCount] = 0, horizontalListCount++;
                }
            }
            
            //for (int counterA = 0; counterA < horizontalListCount/7; counterA++){
            //    cout<<to_string(horizontalList [counterA*7])<<" "<<horizontalList [counterA*7+1]<<" "<<horizontalList [counterA*7+2]<<" "<<horizontalList [counterA*7+3]<<" "<<horizontalList [counterA*7+4]<<" horizontalList"<<endl;
            //}
            
            //for (int counterA = 0; counterA < eventListCount/5; counterA++){
            //    cout<<counterA<<" "<<to_string(eventList [counterA*5])<<" "<<eventList [counterA*5+1]<<" "<< eventList [counterA*5+2]<<" "<<eventList [counterA*5+3]<<" "<<eventList [counterA*5+4]<<"   eventList"<<endl;
            //}
            
            int terminationFlag = 0;
            int lineageSelect = 0;
            int cellSelectPosition = 0;
            int eventListCount2 = 0;
            double cellSelect = 0;
            
            double *horizontalList2 = new double [numberOfCellEntry*7+50];
            int horizontalListCount2 = 0;
            
            double *eventList2 = new double [numberOfEventCount*6+50];
            
            for (int counter1 = 0; counter1 < numberOfEventCount*6+50; counter1++) eventList2 [counter1] = 0;
            
            int entryOrder = 0;
            
            do{
                
                terminationFlag = 1;
                lineageSelect = 100000;
                
                for (int counter1 = 0; counter1 < horizontalListCount/7; counter1++){
                    if (horizontalList [counter1*7+1] != -1){
                        lineageSelect = (int)(horizontalList [counter1*7+1]);
                        break;
                    }
                }
                
                if (lineageSelect == 100000) terminationFlag = 0;
                else{
                    
                    cellSelect = 999999999999999;
                    cellSelectPosition = 0;
                    
                    for (int counter1 = 0; counter1 < horizontalListCount/7; counter1++){
                        if (horizontalList [counter1*7] != -1 && horizontalList [counter1*7+1] == lineageSelect && horizontalList [counter1*7] < cellSelect){
                            cellSelect = horizontalList [counter1*7];
                            cellSelectPosition = counter1;
                        }
                    }
                    
                    if (cellSelect != 999999999999999){
                        horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7], horizontalListCount2++; //----Cell no---
                        horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+1], horizontalListCount2++; //----Ling no----
                        horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+2], horizontalListCount2++; //----Rev cell no----
                        horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+3], horizontalListCount2++; //----Time start----
                        horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+4], horizontalListCount2++; //----Time end----
                        horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+5], horizontalListCount2++; //----Event last----
                        horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+6], horizontalListCount2++; //----Event I----
                        
                        for (int counter1 = 0; counter1 < eventListCount/5; counter1++){
                            if (eventList [counter1*5] == horizontalList [cellSelectPosition*7] && eventList [counter1*5+1] == horizontalList [cellSelectPosition*7+1]){
                                eventList2 [eventListCount2] = eventList [counter1 *5], eventListCount2++; //----Cell no----
                                eventList2 [eventListCount2] = eventList [counter1 *5+1], eventListCount2++; //----Ling no----
                                eventList2 [eventListCount2] = eventList [counter1 *5+2], eventListCount2++; //----Time----
                                eventList2 [eventListCount2] = eventList [counter1 *5+3], eventListCount2++; //----Event----
                                eventList2 [eventListCount2] = entryOrder, eventListCount2++; //----Entry order----
                            }
                        }
                        
                        horizontalList [cellSelectPosition*7] = -1;
                        horizontalList [cellSelectPosition*7+1] = -1;
                        
                        entryOrder++;
                    }
                }
                
            } while (terminationFlag == 1);
            
            //for (int counterA = 0; counterA < horizontalListCount2/7; counterA++){
            //    cout<<to_string(horizontalList2 [counterA*7])<<" "<<to_string(horizontalList2 [counterA*7+1])<<" "<<horizontalList2 [counterA*7+2]<<" "<<horizontalList2 [counterA*7+3]<<" "<<horizontalList2 [counterA*7+4]<<" horizontalList2"<<endl;
            //}
            
            //----Lineage display Vertical set----
            double *verticalList = new double [numberOfEventCount*9+50];
            int verticalListCount = 0;
            
            double parentCellNo = 0;
            double cellNoLow = 0;
            double cellNoHigh = 0;
            int cellNoLowPosition = 0;
            int cellNoHighPosition = 0;
            int matchFindFlag = 0;
            
            for (int counter1 = 0; counter1 < cellExtractedInfoSummaryCount/9; counter1++){
                if (cellExtractedInfoSummary [counter1*9+3] == 91){
                    matchFindFlag = 0;
                    
                    for (int counter2 = 0; counter2 < verticalListCount/9; counter2++){
                        if ((verticalList [counter2*9] == cellExtractedInfoSummary [counter1*9+5] && verticalList [counter2*9+1] == cellExtractedInfoSummary [counter1*9+6] && verticalList [counter2*9+2] == cellExtractedInfoSummary [counter1*9+2]) || (verticalList [counter2*9+3] == cellExtractedInfoSummary [counter1*9+5] && verticalList [counter2*9+4] == cellExtractedInfoSummary [counter1*9+6] && verticalList [counter2*9+5] == cellExtractedInfoSummary [counter1*9+2])){
                            matchFindFlag = 1;
                        }
                    }
                    
                    if (matchFindFlag == 0){
                        for (int counter2 = 0; counter2 < cellExtractedInfoSummaryCount/9; counter2++){
                            if (cellExtractedInfoSummary [counter2*9+3] == 92 && cellExtractedInfoSummary [counter1*9+4] == cellExtractedInfoSummary [counter2*9+5] && cellExtractedInfoSummary [counter1*9+7] == cellExtractedInfoSummary [counter2*9+6] && cellExtractedInfoSummary [counter2*9+2] == cellExtractedInfoSummary [counter1*9+2]){
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+5], verticalListCount++;
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+6], verticalListCount++;
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+2], verticalListCount++;
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+5], verticalListCount++;
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+6], verticalListCount++;
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+2], verticalListCount++;
                                verticalList [verticalListCount] = 0, verticalListCount++;
                                verticalList [verticalListCount] = 0, verticalListCount++;
                                verticalList [verticalListCount] = 91, verticalListCount++;
                                
                                break;
                            }
                        }
                    }
                }
                else if (cellExtractedInfoSummary [counter1*9+3] == 92){
                    matchFindFlag = 0;
                    
                    for (int counter2 = 0; counter2 < verticalListCount/9; counter2++){
                        if ((verticalList [counter2*9] == cellExtractedInfoSummary [counter1*9+5] && verticalList [counter2*9+1] == cellExtractedInfoSummary [counter1*9+6] && verticalList [counter2*9+2] == cellExtractedInfoSummary [counter1*9+2]) || (verticalList [counter2*9+3] == cellExtractedInfoSummary [counter1*9+5] && verticalList [counter2*9+4] == cellExtractedInfoSummary [counter1*9+6] && verticalList [counter2*9+5] == cellExtractedInfoSummary [counter1*9+2])){
                            matchFindFlag = 1;
                        }
                    }
                    
                    if (matchFindFlag == 0){
                        for (int counter2 = 0; counter2 < cellExtractedInfoSummaryCount/9; counter2++){
                            if (cellExtractedInfoSummary [counter2*9+3] == 91 && cellExtractedInfoSummary [counter1*9+4] == cellExtractedInfoSummary [counter2*9+5] && cellExtractedInfoSummary [counter1*9+7] == cellExtractedInfoSummary [counter2*9+6] && cellExtractedInfoSummary [counter2*9+2] == cellExtractedInfoSummary [counter1*9+2]){
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+5], verticalListCount++;
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+6], verticalListCount++;
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+2], verticalListCount++;
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+5], verticalListCount++;
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+6], verticalListCount++;
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+2], verticalListCount++;
                                verticalList [verticalListCount] = 0, verticalListCount++;
                                verticalList [verticalListCount] = 0, verticalListCount++;
                                verticalList [verticalListCount] = 91, verticalListCount++;
                                
                                break;
                            }
                        }
                    }
                }
                else if (cellExtractedInfoSummary [counter1*9+3] == 31){
                    parentCellNo = cellExtractedInfoSummary [counter1*9+4];
                    matchFindFlag = 0;
                    
                    for (int counter2 = 0; counter2 < verticalListCount/9; counter2++){
                        if ((verticalList [counter2*9] == cellExtractedInfoSummary [counter1*9+5] && verticalList [counter2*9+1] == cellExtractedInfoSummary [counter1*9+6] && verticalList [counter2*9+2] == cellExtractedInfoSummary [counter1*9+2]) || (verticalList [counter2*9+3] == cellExtractedInfoSummary [counter1*9+5] && verticalList [counter2*9+4] == cellExtractedInfoSummary [counter1*9+6] && verticalList [counter2*9+5] == cellExtractedInfoSummary [counter1*9+2])){
                            matchFindFlag = 1;
                        }
                    }
                    
                    if (matchFindFlag == 0){
                        for (int counter2 = 0; counter2 < cellExtractedInfoSummaryCount/9; counter2++){
                            if (cellExtractedInfoSummary [counter2*9+3] == 31 && cellExtractedInfoSummary [counter1*9+6] == cellExtractedInfoSummary [counter2*9+6] && cellExtractedInfoSummary [counter2*9+4] == parentCellNo && cellExtractedInfoSummary [counter2*9+5] != cellExtractedInfoSummary [counter1*9+5] && cellExtractedInfoSummary [counter2*9+2] == cellExtractedInfoSummary [counter1*9+2]){
                                
                                if (cellExtractedInfoSummary [counter2*9+5] > cellExtractedInfoSummary [counter1*9+5]){
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+5], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+6], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+2], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+5], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+6], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+2], verticalListCount++;
                                    verticalList [verticalListCount] = 0, verticalListCount++;
                                    verticalList [verticalListCount] = 0, verticalListCount++;
                                    verticalList [verticalListCount] = 31, verticalListCount++;
                                }
                                else{
                                    
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+5], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+6], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+2], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+5], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+6], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+2], verticalListCount++;
                                    verticalList [verticalListCount] = 0, verticalListCount++;
                                    verticalList [verticalListCount] = 0, verticalListCount++;
                                    verticalList [verticalListCount] = 31, verticalListCount++;
                                }
                                
                                break;
                            }
                        }
                    }
                }
                else if (cellExtractedInfoSummary [counter1*9+3] == 41){
                    parentCellNo = cellExtractedInfoSummary [counter1*9+4];
                    cellNoLow = cellExtractedInfoSummary [counter1*9+5];
                    cellNoHigh = cellExtractedInfoSummary [counter1*9+5];
                    cellNoLowPosition = counter1;
                    cellNoHighPosition = counter1;
                    
                    matchFindFlag = 0;
                    
                    for (int counter2 = 0; counter2 < verticalListCount/9; counter2++){
                        if ((verticalList [counter2*9] == cellExtractedInfoSummary [counter1*9+5] && verticalList [counter2*9+1] == cellExtractedInfoSummary [counter1*9+6] && verticalList [counter2*9+2] == cellExtractedInfoSummary [counter1*9+2]) || (verticalList [counter2*9+3] == cellExtractedInfoSummary [counter1*9+5] && verticalList [counter2*9+4] == cellExtractedInfoSummary [counter1*9+6] && verticalList [counter2*9+5] == cellExtractedInfoSummary [counter1*9+2])){
                            matchFindFlag = 1;
                        }
                    }
                    
                    if (matchFindFlag == 0){
                        for (int counter2 = 0; counter2 < cellExtractedInfoSummaryCount/9; counter2++){
                            if (cellExtractedInfoSummary [counter2*9+3] == 41 && cellExtractedInfoSummary [counter1*9+6] == cellExtractedInfoSummary [counter2*9+6] && cellExtractedInfoSummary [counter2*9+4] == parentCellNo && cellExtractedInfoSummary [counter2*9+5] != cellExtractedInfoSummary [counter1*9+5]){
                                if (cellExtractedInfoSummary [counter2*9+5] > cellNoHigh){
                                    cellNoHigh = cellExtractedInfoSummary [counter2*9+5];
                                    cellNoHighPosition = counter2;
                                }
                                
                                if (cellExtractedInfoSummary [counter2*9+5] < cellNoLow){
                                    cellNoHigh = cellExtractedInfoSummary [counter2*9+5];
                                    cellNoLowPosition = counter2;
                                }
                            }
                        }
                        
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoLowPosition*9+5], verticalListCount++;
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoLowPosition*9+6], verticalListCount++;
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoLowPosition*9+2], verticalListCount++;
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoHighPosition*9+5], verticalListCount++;
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoHighPosition*9+6], verticalListCount++;
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoHighPosition*9+2], verticalListCount++;
                        verticalList [verticalListCount] = 0, verticalListCount++;
                        verticalList [verticalListCount] = 0, verticalListCount++;
                        verticalList [verticalListCount] = 41, verticalListCount++;
                    }
                }
                else if (cellExtractedInfoSummary [counter1*9+3] == 51){
                    parentCellNo = cellExtractedInfoSummary [counter1*9+4];
                    cellNoLow = cellExtractedInfoSummary [counter1*9+5];
                    cellNoHigh = cellExtractedInfoSummary [counter1*9+5];
                    cellNoLowPosition = counter1;
                    cellNoHighPosition = counter1;
                    
                    matchFindFlag = 0;
                    
                    for (int counter2 = 0; counter2 < verticalListCount/9; counter2++){
                        if ((verticalList [counter2*9] == cellExtractedInfoSummary [counter1*9+5] && verticalList [counter2*9+1] == cellExtractedInfoSummary [counter1*9+6] && verticalList [counter2*9+2] == cellExtractedInfoSummary [counter1*9+2]) || (verticalList [counter2*9+3] == cellExtractedInfoSummary [counter1*9+5] && verticalList [counter2*9+4] == cellExtractedInfoSummary [counter1*9+6] && verticalList [counter2*9+5] == cellExtractedInfoSummary [counter1*9+2])){
                            matchFindFlag = 1;
                        }
                    }
                    
                    if (matchFindFlag == 0){
                        for (int counter2 = 0; counter2 < cellExtractedInfoSummaryCount/9; counter2++){
                            if (cellExtractedInfoSummary [counter2*9+3] == 51 && cellExtractedInfoSummary [counter1*9+6] == cellExtractedInfoSummary [counter2*9+6] && cellExtractedInfoSummary [counter2*9+4] == parentCellNo && cellExtractedInfoSummary [counter2*9+5] != cellExtractedInfoSummary [counter1*9+5]){
                                
                                if (cellExtractedInfoSummary [counter2*9+5] > cellNoHigh){
                                    cellNoHigh = cellExtractedInfoSummary [counter2*9+5];
                                    cellNoHighPosition = counter2;
                                }
                                
                                if (cellExtractedInfoSummary [counter2*9+5] < cellNoLow){
                                    cellNoLow = cellExtractedInfoSummary [counter2*9+5];
                                    cellNoLowPosition = counter2;
                                }
                            }
                        }
                        
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoLowPosition*9+5], verticalListCount++; //----Cell no 1----
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoLowPosition*9+6], verticalListCount++; //----Ling no 1----
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoLowPosition*9+2], verticalListCount++; //----Time 1----
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoHighPosition*9+5], verticalListCount++; //----Cell no 2----
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoHighPosition*9+6], verticalListCount++; //----Ling no 2----
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoHighPosition*9+2], verticalListCount++; //----Time 2----
                        verticalList [verticalListCount] = 0, verticalListCount++; //----Cell order 1----
                        verticalList [verticalListCount] = 0, verticalListCount++; //----Cell order 2----
                        verticalList [verticalListCount] = 51, verticalListCount++; //----Event----
                    }
                }
            }
            
            //for (int counterA = 0; counterA < verticalListCount/9; counterA++){
            //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<< to_string(verticalList [counterA*9+counterB]);
            //    cout<<" verticalList "<<counterA<<endl;
            //}
            
            for (int counter1 = 0; counter1 < verticalListCount/9; counter1++){
                for (int counter2 = 0; counter2 < horizontalListCount2/7; counter2++){
                    if (horizontalList2 [counter2*7] == verticalList [counter1*9] && horizontalList2 [counter2*7+1] == verticalList [counter1*9+1]){
                        verticalList [counter1*9+6] = counter2;
                        break;
                    }
                }
                
                for (int counter2 = 0; counter2 < horizontalListCount2/7; counter2++){
                    if (horizontalList2 [counter2*7] == verticalList [counter1*9+3] && horizontalList2 [counter2*7+1] == verticalList [counter1*9+4]){
                        verticalList [counter1*9+7] = counter2;
                        break;
                    }
                }
            }
            
            //for (int counterA = 0; counterA < verticalListCount/9; counterA++){
            //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<< to_string(verticalList [counterA*9+counterB]);
            //    cout<<" verticalList "<<counterA<<endl;
            //}
            
            double increment = (585-52)/(double)(numberOfCellEntry+1);
            double horizontalIncrement = (1000-40)/(double)horizontalTime;
            
            [[NSColor blackColor] set];
            [NSBezierPath setDefaultLineWidth:1];
            
            [attributesA setObject:[NSFont boldSystemFontOfSize:9] forKey:NSFontAttributeName];
            
            //for (int counterA = 0; counterA < eventListCount2/5; counterA++){
            //    cout<<eventList2 [counterA*5]<<" "<<eventList2 [counterA*5+1]<<" "<< eventList2 [counterA*5+2]<<" "<<eventList2 [counterA*5+3]<<" "<<eventList2 [counterA*5+4]<<"   eventList2"<<endl;
            //}
            
            //----Live vertical line----
            int roundNoGet = 0;
            int ifDataEntryGet = arrayIFTimeLineDataEntryHold [tableCurrentRowHold];
            int positionShiftA = 0;
            
            int *liveTimeList = new int [ifDataEntryGet/9+1];
            int liveTimeListCount = 0;
            
            //for (int counterA = 0; counterA < arrayIFTimeLineDataEntryHold [tableCurrentRowHold]/6; counterA++){
            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayIFTimeLineData [tableCurrentRowHold][counterA*6+counterB];
            //    cout<<" arrayIFTimeLineData "<<counterA<<endl;
            //}
            
            for (int counter1 = 0; counter1 < ifDataEntryGet/9; counter1++){
                if (arrayIFTimeLineData [tableCurrentRowHold][counter1*9+1] == -1){
                    liveTimeList [liveTimeListCount] = arrayIFTimeLineData [tableCurrentRowHold][counter1*9], liveTimeListCount++;
                    
                    if (blueLineFlag == 0){
                        [[NSColor blueColor] set];
                        
                        positionAA.x = 40+arrayIFTimeLineData [tableCurrentRowHold][counter1*9]*horizontalIncrement;
                        positionAA.y = 40;
                        positionBB.x = 40+arrayIFTimeLineData [tableCurrentRowHold][counter1*9]*horizontalIncrement;
                        positionBB.y = 585;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        if (to_string(arrayIFTimeLineData [tableCurrentRowHold][counter1*9]).length() == 1) positionShiftA = 2;
                        else if (to_string(arrayIFTimeLineData [tableCurrentRowHold][counter1*9]).length() == 2) positionShiftA = 4;
                        else if (to_string(arrayIFTimeLineData [tableCurrentRowHold][counter1*9]).length() == 3) positionShiftA = 6;
                        else if (to_string(arrayIFTimeLineData [tableCurrentRowHold][counter1*9]).length() == 4) positionShiftA = 8;
                        
                        attrStrA = [[NSAttributedString alloc] initWithString:@(to_string(arrayIFTimeLineData [tableCurrentRowHold][counter1*9]).c_str()) attributes:attributesA];
                        pointA.x = 40+arrayIFTimeLineData [tableCurrentRowHold][counter1*9]*horizontalIncrement-positionShiftA;
                        pointA.y = 586;
                        [attrStrA drawAtPoint:pointA];
                    }
                }
                
                if (arrayIFTimeLineData [tableCurrentRowHold][counter1*9] == ifCurrentTime) roundNoGet = arrayIFTimeLineData [tableCurrentRowHold][counter1*9+1];
            }
            
            
            if (ifDataExtractCount > 7){
                [[NSColor blackColor] set];
                
                positionAA.x = 40+(ifDataExtract [7]-1)*horizontalIncrement;
                positionAA.y = 40;
                positionBB.x = 40+(ifDataExtract [7]-1)*horizontalIncrement;
                positionBB.y = 585;
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                
                if (to_string(ifDataExtract [7]-1).length() == 1) positionShiftA = 2;
                else if (to_string(ifDataExtract [7]-1).length() == 2) positionShiftA = 5;
                else if (to_string(ifDataExtract [7]-1).length() == 3) positionShiftA = 8;
                else if (to_string(ifDataExtract [7]-1).length() == 4) positionShiftA = 11;
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(to_string(ifDataExtract [7]-1).c_str()) attributes:attributesA];
                pointA.x = 40+(ifDataExtract [7]-1)*horizontalIncrement-positionShiftA;
                pointA.y = 586;
                [attrStrA drawAtPoint:pointA];
            }
            
            //----Lineage Display Vertical----
            if (lineWidthFlag == 0) [NSBezierPath setDefaultLineWidth:2];
            else if (lineWidthFlag == 1) [NSBezierPath setDefaultLineWidth:1];
            else if (lineWidthFlag == 2) [NSBezierPath setDefaultLineWidth:0.5];
            else if (lineWidthFlag == 3) [NSBezierPath setDefaultLineWidth:5];
            else if (lineWidthFlag == 4) [NSBezierPath setDefaultLineWidth:4];
            else if (lineWidthFlag == 5) [NSBezierPath setDefaultLineWidth:3];
            
            for (int counter1 = 0; counter1 < verticalListCount/9; counter1++){
                if (verticalList [counter1*9+8] == 91) [[NSColor orangeColor] set];
                else if (verticalList [counter1*9+8] == 31) [[NSColor blackColor] set];
                else if (verticalList [counter1*9+8] == 41) [[NSColor redColor] set];
                else if (verticalList [counter1*9+8] == 51) [[NSColor redColor] set];
                
                positionAA.x = 40+verticalList [counter1*9+2]*horizontalIncrement;
                positionAA.y = 52+increment+verticalList [counter1*9+6]*increment;
                positionBB.x = 40+verticalList [counter1*9+5]*horizontalIncrement;
                positionBB.y = 52+increment+verticalList [counter1*9+7]*increment;
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
            }
            
            [attributesA setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            [[NSColor blackColor] set];
            
            int findMainLength = arrayTableMainHold [tableCurrentRowHold];
            
            double *horizontalLineList = new double [horizontalListCount2/7*3+50];
            int horizontalLineListCount = 0;
            
            double *horizontalLineListValue = new double [horizontalListCount2/7*2+50];
            int horizontalLineListValueCount = 0;
            
            int cellNoOriginal = 0;
            int rangeNo = 0;
            int rangeAverageLow = 0;
            int rangeAverageHigh = 0;
            int rangeTotalLow = 0;
            int rangeTotalHigh = 0;
            
            if (drawingOptionHold == 3 || drawingOptionHold == 4){
                string ifName = "";
                
                for (int counter1 = 13; counter1 < findMainLength; counter1 = counter1+8){
                    if (atoi(arrayTableMain [tableCurrentRowHold][counter1].c_str()) == roundNoGet){
                        ifName = arrayTableMain [tableCurrentRowHold][counter1+ifCurrentCHNo+1];
                        break;
                    }
                }
                
                string roundExtract;
                
                for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryCount; counter1++){
                    roundExtract = arrayLineageFluorescentDataType [counter1][1];
                    roundExtract = roundExtract.substr(1);
                    
                    if (atoi(arrayLineageFluorescentDataType [counter1][0].c_str()) == tableCurrentRowHold+1 && atoi(roundExtract.c_str()) == roundNoGet && arrayLineageFluorescentDataType [counter1][2] == ifName){
                        
                        rangeTotalLow = atoi(arrayLineageFluorescentDataType [counter1][6].c_str());
                        rangeTotalHigh = atoi(arrayLineageFluorescentDataType [counter1][7].c_str());
                        rangeAverageLow = atoi(arrayLineageFluorescentDataType [counter1][4].c_str());
                        rangeAverageHigh = atoi(arrayLineageFluorescentDataType [counter1][5].c_str());
                        break;
                    }
                }
                
                double *fluorescentEntry = new double [numberOfCellEntry*5+50];
                int fluorescentEntryCount = 0;
                
                for (int counter2 = 0; counter2 < horizontalListCount2/7; counter2++){
                    if (horizontalList2 [counter2*7+3] <= ifCurrentTime && horizontalList2 [counter2*7+4] >= ifCurrentTime){
                        fluorescentEntry [fluorescentEntryCount] = horizontalList2 [counter2*7], fluorescentEntryCount++; //----Cell no----
                        fluorescentEntry [fluorescentEntryCount] = horizontalList2 [counter2*7+1], fluorescentEntryCount++; //----Ling no----
                        fluorescentEntry [fluorescentEntryCount] = 0, fluorescentEntryCount++; //----AV----
                        fluorescentEntry [fluorescentEntryCount] = 0, fluorescentEntryCount++; //----Total----
                        fluorescentEntry [fluorescentEntryCount] = counter2, fluorescentEntryCount++; //----Cell order----
                    }
                }
                
                //for (int counterA = 0; counterA < horizontalListCount2/7; counterA++){
                //    cout<<horizontalList2 [counterA*7]<<" "<<horizontalList2 [counterA*7+1]<<" "<<horizontalList2 [counterA*7+2]<<" "<<horizontalList2 [counterA*7+3]<<" "<<horizontalList2 [counterA*7+4]<<" "<<horizontalList2 [counterA*7+5]<<" "<<horizontalList2 [counterA*7+6]<<"  horizontalList2"<<endl;
                //}
                
                //for (int counterA = 0; counterA < fluorescentEntryCount/5; counterA++){
                //    cout<<fluorescentEntry [counterA*5]<<" "<<fluorescentEntry [counterA*5+1]<<" "<< fluorescentEntry [counterA*5+2]<<" "<<fluorescentEntry [counterA*5+3]<<" "<<fluorescentEntry [counterA*5+4]<<"   fluorescentEntry"<<endl;
                //}
                
                //for (int counterA = 0; counterA < ifEntryCount/13; counterA++){
                //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<arrayIFData [tableCurrentRowHold][counterA*13+counterB];
                //    cout<<" arrayIFData "<<counterA<<endl;
                //}
                
                for (int counter1 = 0; counter1 < fluorescentEntryCount/5; counter1++){
                    cellNoOriginal = 0;
                    
                    for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                        if (fluorescentEntry [counter1*5] == cellNoList [counter2*4+2]){
                            cellNoOriginal = (int)(cellNoList [counter2*4]);
                            break;
                        }
                    }
                    
                    for (int counter2 = 0; counter2 < ifValueExtractCount/22; counter2++){
                        if (cellNoOriginal == ifValueExtract [counter2*22] && (int)(fluorescentEntry [counter1*5+1]) == ifValueExtract [counter2*22+1] && ifCurrentTime == ifValueExtract [counter2*22+2]){
                            if (ifCurrentCHNo == 1){
                                fluorescentEntry [counter1*5+2] = ifValueExtract [counter2*22+5];
                                fluorescentEntry [counter1*5+3] = ifValueExtract [counter2*22+5]*ifValueExtract [counter2*22+6];
                            }
                            else if (ifCurrentCHNo == 2){
                                fluorescentEntry [counter1*5+2] = ifValueExtract [counter2*22+8];
                                fluorescentEntry [counter1*5+3] = ifValueExtract [counter2*22+8]*ifValueExtract [counter2*22+9];
                            }
                            else if (ifCurrentCHNo == 3){
                                fluorescentEntry [counter1*5+2] = ifValueExtract [counter2*22+11];
                                fluorescentEntry [counter1*5+3] = ifValueExtract [counter2*22+11]*ifValueExtract [counter2*22+12];
                            }
                            else if (ifCurrentCHNo == 4){
                                fluorescentEntry [counter1*5+2] = ifValueExtract [counter2*22+14];
                                fluorescentEntry [counter1*5+3] = ifValueExtract [counter2*22+14]*ifValueExtract [counter2*22+15];
                            }
                            else if (ifCurrentCHNo == 5){
                                fluorescentEntry [counter1*5+2] = ifValueExtract [counter2*22+17];
                                fluorescentEntry [counter1*5+3] = ifValueExtract [counter2*22+17]*ifValueExtract [counter2*22+18];
                            }
                            else if (ifCurrentCHNo == 6){
                                fluorescentEntry [counter1*5+2] = ifValueExtract [counter2*22+20];
                                fluorescentEntry [counter1*5+3] = ifValueExtract [counter2*22+20]*ifValueExtract [counter2*22+21];
                            }
                            
                            break;
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < fluorescentEntryCount/5; counterA++){
                //    cout<<fluorescentEntry [counterA*5]<<" "<<fluorescentEntry [counterA*5+1]<<" "<< fluorescentEntry [counterA*5+2]<<" "<<fluorescentEntry [counterA*5+3]<<" "<<fluorescentEntry [counterA*5+4]<<"   fluorescentEntry"<<endl;
                //}
                
                if (averageTotalFlag == 0){
                    double rangeDivisionAverage = (rangeAverageHigh-rangeAverageLow)/(double)25;
                    
                    for (int counter1 = 0; counter1 < fluorescentEntryCount/5; counter1++){
                        if (fluorescentEntry [counter1*5+2] <= rangeAverageLow+rangeDivisionAverage) rangeNo = 1;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*2) rangeNo = 2;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*3) rangeNo = 3;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*4) rangeNo = 4;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*5) rangeNo = 5;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*6) rangeNo = 6;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*7) rangeNo = 7;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*8) rangeNo = 8;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*9) rangeNo = 9;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*10) rangeNo = 10;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*11) rangeNo = 11;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*12) rangeNo = 12;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*13) rangeNo = 13;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*14) rangeNo = 14;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*15) rangeNo = 15;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*16) rangeNo = 16;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*17) rangeNo = 17;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*18) rangeNo = 18;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*19) rangeNo = 19;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*20) rangeNo = 20;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*21) rangeNo = 21;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*22) rangeNo = 22;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*23) rangeNo = 23;
                        else rangeNo = 24;
                        
                        [[NSColor colorWithCalibratedRed:arrayColorRange [(rangeNo-1)*3] green:arrayColorRange [(rangeNo-1)*3+1] blue:arrayColorRange [(rangeNo-1)*3+2] alpha:1] set];
                        
                        positionAA.x = 1065;
                        positionAA.y = 52+increment+fluorescentEntry [counter1*5+4]*increment;
                        positionBB.x = 1075;
                        positionBB.y = 52+increment+fluorescentEntry [counter1*5+4]*increment;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    }
                }
                else{
                    
                    double rangeDivisionTotal = (rangeTotalHigh-rangeTotalLow)/(double)25;
                    
                    for (int counter1 = 0; counter1 < fluorescentEntryCount/5; counter1++){
                        if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal) rangeNo = 1;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*2) rangeNo = 2;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*3) rangeNo = 3;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*4) rangeNo = 4;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*5) rangeNo = 5;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*6) rangeNo = 6;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*7) rangeNo = 7;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*8) rangeNo = 8;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*9) rangeNo = 9;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*10) rangeNo = 10;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*11) rangeNo = 11;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*12) rangeNo = 12;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*13) rangeNo = 13;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*14) rangeNo = 14;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*15) rangeNo = 15;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*16) rangeNo = 16;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*17) rangeNo = 17;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*18) rangeNo = 18;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*19) rangeNo = 19;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*20) rangeNo = 20;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*21) rangeNo = 21;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*22) rangeNo = 22;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*23) rangeNo = 23;
                        else rangeNo = 24;
                        
                        [[NSColor colorWithCalibratedRed:arrayColorRange [(rangeNo-1)*3] green:arrayColorRange [(rangeNo-1)*3+1] blue:arrayColorRange [(rangeNo-1)*3+2] alpha:1] set];
                        
                        positionAA.x = 1065;
                        positionAA.y = 52+increment+fluorescentEntry [counter1*5+4]*increment;
                        positionBB.x = 1075;
                        positionBB.y = 52+increment+fluorescentEntry [counter1*5+4]*increment;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    }
                }
                
                //for (int counterA = 0; counterA < fluorescentEntryCount/5; counterA++){
                //    cout<<fluorescentEntry [counterA*5]<<" "<<fluorescentEntry [counterA*5+1]<<" "<< fluorescentEntry [counterA*5+2]<<" "<<fluorescentEntry [counterA*5+3]<<" "<<fluorescentEntry [counterA*5+4]<<"   fluorescentEntry"<<endl;
                //}
                
                if (drawingOptionHold == 4){
                    for (int counter2 = 0; counter2 < horizontalListCount2/7*3+50; counter2++){
                        horizontalLineList [counter2] = 0;
                    }
                    
                    for (int counter2 = 0; counter2 < horizontalListCount2/7*2+50; counter2++){
                        horizontalLineListValue [counter2] = 0;
                    }
                    
                    horizontalLineListCount = 0;
                    horizontalLineListValueCount = 0;
                    
                    for (int counter2 = 0; counter2 < horizontalListCount2/7; counter2++){
                        horizontalLineList [horizontalLineListCount] = horizontalList2 [counter2*7], horizontalLineListCount++;
                        horizontalLineList [horizontalLineListCount] = horizontalList2 [counter2*7+1], horizontalLineListCount++;
                        horizontalLineList [horizontalLineListCount] = 0, horizontalLineListCount++;
                        
                        horizontalLineListValue [horizontalLineListValueCount] = -1, horizontalLineListValueCount++;
                        horizontalLineListValue [horizontalLineListValueCount] = -1, horizontalLineListValueCount++;
                    }
                    
                    //for (int counterA = 0; counterA < horizontalListCount2/7; counterA++){
                    //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<< horizontalList2 [counterA*7+counterB];
                    //    cout<<" horizontalList2 "<<counterA<<" "<<counter1<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < horizontalLineListCount/3; counterA++){
                    //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<< to_string(horizontalLineList [counterA*3+counterB]);
                    //    cout<<" horizontalLineList "<<counterA<<" "<<endl;
                    //}
                    
                    //----Enter fluorescent value at the end point----
                    if (lineageDisplayOption == 0){
                        for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                            for (int counter3 = 0; counter3 < fluorescentEntryCount/5; counter3++){
                                if (horizontalLineList [counter2*3] == fluorescentEntry [counter3*5] && horizontalLineList [counter2*3+1] == fluorescentEntry [counter3*5+1]){
                                    horizontalLineList [counter2*3+2] = 1;
                                    horizontalLineListValue [counter2*2] = fluorescentEntry [counter3*5+2];
                                    horizontalLineListValue [counter2*2+1] = fluorescentEntry [counter3*5+3];
                                    
                                    break;
                                }
                            }
                        }
                    }
                    else{
                        
                        for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                            for (int counter3 = 0; counter3 < fluorescentEntryCount/5; counter3++){
                                if (horizontalLineList [counter2*3] == fluorescentEntry [counter3*5] && horizontalLineList [counter2*3+1] == fluorescentEntry [counter3*5+1]){
                                    horizontalLineList [counter2*3+2] = 1;
                                    
                                    if (fluorescentEntry [counter3*5+2] == 0) horizontalLineListValue [counter2*2] = lowXlow;
                                    else if (fluorescentEntry [counter3*5+2] == 100) horizontalLineListValue [counter2*2] = highXhigh;
                                    else horizontalLineListValue [counter2*2] = -100;
                                    
                                    horizontalLineListValue [counter2*2+1] = fluorescentEntry [counter3*5+3];
                                    
                                    break;
                                }
                            }
                        }
                    }
                    
                    //----Set dummy value at CD, OF FU lines----
                    if (unknownOptionHold == 1 && lineageDisplayOption == 0){
                        for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                            if (horizontalLineList [counter2*3+2] == 0){
                                cellNoOriginal = 0;
                                
                                for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                                    if (horizontalLineList [counter2*3] == cellNoList [counter3*4+2]){
                                        cellNoOriginal = (int)(cellNoList [counter3*4]);
                                        break;
                                    }
                                }
                                
                                for (unsigned long counter3 = 0; counter3 < lineageExtractCount/9; counter3++){
                                    if (arrayLineageExtract [counter3*9+5] == cellNoOriginal && (arrayLineageExtract [counter3*9+3] == 7 || arrayLineageExtract [counter3*9+3] == 8 || arrayLineageExtract [counter3*9+3] == 91)){
                                        horizontalLineList [counter2*3+2] = 1;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    else if (lineageDisplayOption == 1){
                        for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                            if (horizontalLineList [counter2*3+2] == 0){
                                cellNoOriginal = 0;
                                
                                for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                                    if (horizontalLineList [counter2*3] == cellNoList [counter3*4+2]){
                                        cellNoOriginal = (int)(cellNoList [counter3*4]);
                                        break;
                                    }
                                }
                                
                                for (unsigned long counter3 = 0; counter3 < lineageExtractCount/9; counter3++){
                                    if (arrayLineageExtract [counter3*9+5] == cellNoOriginal && (arrayLineageExtract [counter3*9+3] == 7 || arrayLineageExtract [counter3*9+3] == 8 || arrayLineageExtract [counter3*9+3] == 91)){
                                        horizontalLineList [counter2*3+2] = 1;
                                        
                                        horizontalLineListValue [counter2*2] = -100;
                                        horizontalLineListValue [counter2*2+1] = 100;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < horizontalLineListCount/3; counterA++){
                    //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<< horizontalLineList [counterA*3+counterB];
                    //    cout<<" horizontalLineList "<<counterA<<" "<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < horizontalLineListCount/3; counterA++){
                    //    for (int counterB = 0; counterB < 2; counterB++) cout<<" "<< horizontalLineListValue [counterA*2+counterB];
                    //    cout<<" horizontalLineListValue "<<counterA<<" "<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < lineageExtractCount/9; counterA++){
                    //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayLineageExtract [counterA*9+counterB];
                    //    cout<<" arrayLineageExtract "<<counterA<<endl;
                    //}
                    
                    int expandLineage = 0;
                    int skipCount = 0;
                    int skipEntryCount = 0;
                    int divisionStatus = 0;
                    int dataEntryCheck = 0;
                    int endStatusCheck = 0;
                    int endStatusCheck2 = 0;
                    int colorCountTemp = 0;
                    int checkStart = 0;
                    int checkNoCheck = 0;
                    
                    double expandCell = 0;
                    double parentDoubleCell = 0;
                    double cellNoOriginal2 = 0;
                    double sumTotal = 0;
                    double sumAverage = 0;
                    double colorDataCount = 0;
                    
                    double *cellNoListTemp = new double [10];
                    int cellNoListTempCount = 0;
                    
                    int *endStatusHold = new int [20];
                    int endStatusHoldCount = 0;
                    
                    do{
                        
                        terminationFlag = 1;
                        expandLineage = 0;
                        skipEntryCount = skipCount;
                        
                        for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                            if (horizontalLineList [counter2*3+2] == 1 && skipEntryCount == 0){
                                expandLineage = (int)(horizontalLineList [counter2*3+1]);
                                expandCell = horizontalLineList [counter2*3];
                                break;
                            }
                            else if (horizontalLineList [counter2*3+2] == 1 && skipEntryCount >= 0) skipEntryCount--;
                        }
                        
                        if (expandLineage != 0){
                            parentCellNo = -1;
                            cellNoOriginal = 0;
                            
                            for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                                if (expandCell == cellNoList [counter2*4+2]){
                                    cellNoOriginal = (int)(cellNoList [counter2*4]);
                                    break;
                                }
                            }
                            
                            for (unsigned long counter2 = 0; counter2 < lineageExtractCount/9; counter2++){
                                if (arrayLineageExtract [counter2*9+3] == 31 || arrayLineageExtract [counter2*9+3] == 41 || arrayLineageExtract [counter2*9+3] == 51){
                                    if (arrayLineageExtract [counter2*9+6] == expandLineage && arrayLineageExtract [counter2*9+5] == cellNoOriginal){
                                        parentCellNo = arrayLineageExtract [counter2*9+4];
                                        break;
                                    }
                                }
                            }
                            
                            parentDoubleCell = 0;
                            
                            for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                                if (parentCellNo == cellNoList [counter2*4]){
                                    parentDoubleCell = cellNoList [counter2*4+2];
                                    break;
                                }
                            }
                            
                            if (parentCellNo != -1){
                                cellNoListTempCount = 0;
                                endStatusHoldCount = 0;
                                divisionStatus = 0;
                                
                                for (unsigned long counter2 = 0; counter2 < lineageExtractCount/9; counter2++){
                                    if (arrayLineageExtract [counter2*9+3] == 31 || arrayLineageExtract [counter2*9+3] == 41 || arrayLineageExtract [counter2*9+3] == 51){
                                        if (arrayLineageExtract [counter2*9+6] == expandLineage && arrayLineageExtract [counter2*9+4] == parentCellNo){
                                            cellNoOriginal2 = 0;
                                            
                                            for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                                                if (arrayLineageExtract [counter2*9+5] == cellNoList [counter3*4]){
                                                    cellNoOriginal2 = cellNoList [counter3*4+2];
                                                    break;
                                                }
                                            }
                                            
                                            if (arrayLineageExtract [counter2*9+3] == 31) divisionStatus = 2;
                                            else if (arrayLineageExtract [counter2*9+3] == 41) divisionStatus = 3;
                                            else if (arrayLineageExtract [counter2*9+3] == 51) divisionStatus = 4;
                                            
                                            cellNoListTemp [cellNoListTempCount] = cellNoOriginal2, cellNoListTempCount++;
                                            
                                            endStatusHold [endStatusHoldCount] = 0, endStatusHoldCount++;
                                            endStatusHold [endStatusHoldCount] = -1, endStatusHoldCount++;
                                            
                                            //----Check end status, enter 1 when end is CD, OF, FU----
                                            for (unsigned long counter3 = 0; counter3 < lineageExtractCount/9; counter3++){
                                                if (arrayLineageExtract [counter3*9+6] == expandLineage && arrayLineageExtract [counter3*9+5] == arrayLineageExtract [counter2*9+5] && (arrayLineageExtract [counter3*9+3] == 7 || arrayLineageExtract [counter3*9+3] == 8 || arrayLineageExtract [counter3*9+3] == 91)){
                                                    endStatusHold [endStatusHoldCount-2] = 1;
                                                    break;
                                                }
                                            }
                                            
                                            checkStart = 0;
                                            checkNoCheck = 0;
                                            
                                            //----Check progeny's end status, enter 1 when end is CD, OF, FU----
                                            for (unsigned long counter3 = 0; counter3 < lineageExtractCount/9; counter3++){
                                                if (arrayLineageExtract [counter3*9+6] == expandLineage && arrayLineageExtract [counter3*9+4] == arrayLineageExtract [counter2*9+5] && arrayLineageExtract [counter3*9+3] != 91 && arrayLineageExtract [counter3*9+4] != 92){
                                                    checkStart = 1;
                                                    checkNoCheck = arrayLineageExtract [counter3*9+5];
                                                }
                                                
                                                if (arrayLineageExtract [counter3*9+6] == expandLineage && arrayLineageExtract [counter3*9+5] == checkNoCheck && checkStart == 1 && (arrayLineageExtract [counter3*9+3] == 7 || arrayLineageExtract [counter3*9+3] == 8 || arrayLineageExtract [counter3*9+3] == 91)){
                                                    if (endStatusHold [endStatusHoldCount-1] == -1) endStatusHold [endStatusHoldCount-1] = 1;
                                                    checkStart = 0;
                                                }
                                                else if (arrayLineageExtract [counter3*9+6] == expandLineage && arrayLineageExtract [counter3*9+5] == checkNoCheck && checkStart == 1 && (arrayLineageExtract [counter3*9+3] == 32 || arrayLineageExtract [counter3*9+3] == 42 || arrayLineageExtract [counter3*9+3] == 52 || arrayLineageExtract [counter3*9+2] == arrayTableDetail [tableCurrentRowHold][3])){
                                                    
                                                    endStatusHold [endStatusHoldCount-1] = 0;
                                                    break;
                                                }
                                            }
                                            
                                            if (endStatusHold [endStatusHoldCount-1] == -1) endStatusHold [endStatusHoldCount-1] = 0;
                                        }
                                    }
                                }
                                
                                endStatusCheck = 0;
                                endStatusCheck2 = 0;
                                
                                for (int counter2 = 0; counter2 < endStatusHoldCount/2; counter2++){
                                    if (endStatusHold [counter2*2] == 1) endStatusCheck = 1;
                                    if (endStatusHold [counter2*2+1] == 1) endStatusCheck2 = 1;
                                }
                                
                                sumTotal = 0;
                                sumAverage = 0;
                                colorDataCount = 0;
                                colorCountTemp = 0;
                                
                                if (lineageDisplayOption == 1) sumAverage = -1;
                                
                                if (lineageDisplayOption == 0){
                                    if (unknownOptionHold == 0){
                                        if (endStatusCheck == 0){
                                            for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                    if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && horizontalLineListValue [counter3*2] != -1 && horizontalLineListValue [counter3*2+1] != -1){
                                                        sumTotal = sumTotal+horizontalLineListValue [counter3*2+1];
                                                        sumAverage = sumAverage+(int)horizontalLineListValue [counter3*2];
                                                        
                                                        horizontalLineList [counter3*3+2] = -1;
                                                        colorDataCount++;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else if (unknownOptionHold == 1){
                                        if (endStatusCheck == 0 && endStatusCheck2 == 0){
                                            for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                    if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && horizontalLineListValue [counter3*2] != -1 && horizontalLineListValue [counter3*2+1] != -1){
                                                        sumTotal = sumTotal+horizontalLineListValue [counter3*2+1];
                                                        sumAverage = sumAverage+(int)horizontalLineListValue [counter3*2];
                                                        
                                                        horizontalLineList [counter3*3+2] = -1;
                                                        colorDataCount++;
                                                    }
                                                }
                                            }
                                        }
                                        else{
                                            
                                            endStatusCheck = 0;
                                            dataEntryCheck = 0;
                                            
                                            for (int counter2 = 0; counter2 < endStatusHoldCount/2; counter2++){
                                                if (endStatusHold [counter2*2] == 0) endStatusCheck = 1;
                                                
                                                for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                    if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && endStatusHold [counter2*2] == 0 && endStatusHold [counter2*2+1] == 0 && horizontalLineListValue [counter3*2] == -1 && horizontalLineListValue [counter3*2+1] == -1){
                                                        dataEntryCheck = 1;
                                                    }
                                                }
                                            }
                                            
                                            if (endStatusCheck == 0){
                                                for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                    for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                        if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2]){
                                                            sumTotal = -2;
                                                            sumAverage = -2;
                                                            
                                                            horizontalLineListValue [counter3*2] = -1;
                                                            horizontalLineListValue [counter3*2+1] = -1;
                                                            horizontalLineList [counter3*3+2] = -1;
                                                            
                                                            colorDataCount++;
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                            else if (dataEntryCheck == 0){
                                                for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                    for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                        if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && horizontalLineListValue [counter3*2] != -1 && horizontalLineListValue [counter3*2+1] != -1){
                                                            sumTotal = sumTotal+horizontalLineListValue [counter3*2+1];
                                                            sumAverage = sumAverage+(int)horizontalLineListValue [counter3*2];
                                                            
                                                            horizontalLineList [counter3*3+2] = -1;
                                                            colorCountTemp++;
                                                            colorDataCount++;
                                                        }
                                                    }
                                                }
                                                
                                                for (int counter2 = 0; counter2 < endStatusHoldCount/2; counter2++){
                                                    if (endStatusHold [counter2*2] == 1 || endStatusHold [counter2*2+1] == 1){
                                                        for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                            if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2]){
                                                                horizontalLineListValue [counter3*2] = (int)(sumAverage/(double)colorCountTemp);
                                                                horizontalLineListValue [counter3*2+1] = sumTotal/(double)colorCountTemp;
                                                                horizontalLineList [counter3*3+2] = -1;
                                                                
                                                                colorDataCount++;
                                                                break;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                else if (lineageDisplayOption == 1){
                                    if (endStatusCheck == 0){
                                        for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                            for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && horizontalLineListValue [counter3*2] != -1 && horizontalLineListValue [counter3*2+1] != -1){
                                                    sumTotal = sumTotal+horizontalLineListValue [counter3*2+1];
                                                    
                                                    //cout<<highXhigh<<" "<<lowXlow<<" "<<lowXhigh<<" "<<valueUK<<" "<<sumAverage<<" "<<horizontalLineListValue [counter3*2]<<" "<<to_string(cellNoListTemp [counter2])<<" cellNoListTemp"<<endl;
                                                    
                                                    if (sumAverage == -1 && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXlow;
                                                    else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = highXhigh;
                                                    else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                    else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                    else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == -100) sumAverage = -100;
                                                    else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXlow;
                                                    else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = lowXhigh;
                                                    else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                    else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = valueUK;
                                                    else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = lowXlow;
                                                    else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                    else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXhigh;
                                                    else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = highXhigh;
                                                    else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                    else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = valueUK;
                                                    else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = highXhigh;
                                                    else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                    else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXhigh;
                                                    else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = lowXhigh;
                                                    else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                    else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = lowXhigh;
                                                    else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = lowXhigh;
                                                    else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                    else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXlow && unknownPriorityHold == 0) sumAverage = valueUK;
                                                    else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXlow && unknownPriorityHold == 1) sumAverage = lowXlow;
                                                    else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == highXhigh && unknownPriorityHold == 0) sumAverage = valueUK;
                                                    else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == highXhigh && unknownPriorityHold == 1) sumAverage = highXhigh;
                                                    else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXhigh && unknownPriorityHold == 0) sumAverage = lowXhigh;
                                                    else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXhigh && unknownPriorityHold == 1) sumAverage = lowXhigh;
                                                    else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                    else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                    else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = valueUK;
                                                    else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = valueUK;
                                                    else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = valueUK;
                                                    else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                    else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == -100) sumAverage = -100;
                                                    else sumAverage = -100;
                                                    
                                                    horizontalLineList [counter3*3+2] = -1;
                                                    colorDataCount++;
                                                }
                                            }
                                        }
                                    }
                                    else{
                                        
                                        endStatusCheck = 0;
                                        dataEntryCheck = 0;
                                        
                                        for (int counter2 = 0; counter2 < endStatusHoldCount/2; counter2++){
                                            if (endStatusHold [counter2*2] == 0) endStatusCheck = 1;
                                            
                                            for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && endStatusHold [counter2*2] == 0 && horizontalLineListValue [counter3*2] == -1 && horizontalLineListValue [counter3*2+1] == -1){
                                                    dataEntryCheck = 1;
                                                }
                                            }
                                        }
                                        
                                        if (endStatusCheck == 0){
                                            for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                    if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2]){
                                                        sumTotal = 0;
                                                        sumAverage = -100;
                                                        
                                                        horizontalLineListValue [counter3*2] = -100;
                                                        horizontalLineListValue [counter3*2+1] = 0;
                                                        horizontalLineList [counter3*3+2] = -1;
                                                        
                                                        colorDataCount++;
                                                        break;
                                                    }
                                                }
                                            }
                                        }
                                        else if (dataEntryCheck == 0){
                                            for (int counter2 = 0; counter2 < endStatusHoldCount/2; counter2++){
                                                if (endStatusHold [counter2*2] == 1){
                                                    for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                        if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2]){
                                                            sumAverage = -100;
                                                            
                                                            horizontalLineListValue [counter3*2] = -100;
                                                            horizontalLineListValue [counter3*2+1] = sumTotal/(double)colorCountTemp;
                                                            horizontalLineList [counter3*3+2] = -1;
                                                            
                                                            colorDataCount++;
                                                            
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                            
                                            for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                if (endStatusHold [counter2*2] == 0){
                                                    for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                        if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && horizontalLineListValue [counter3*2] != -1 && horizontalLineListValue [counter3*2+1] != -1){
                                                            
                                                            sumTotal = sumTotal+horizontalLineListValue [counter3*2+1];
                                                            
                                                            if (sumAverage == -1 && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXlow;
                                                            else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = highXhigh;
                                                            else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                            else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                            else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == -100) sumAverage = -100;
                                                            else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXlow;
                                                            else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = lowXhigh;
                                                            else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                            else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = valueUK;
                                                            else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = lowXlow;
                                                            else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                            else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXhigh;
                                                            else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = highXhigh;
                                                            else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                            else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = valueUK;
                                                            else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = highXhigh;
                                                            else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                            else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXhigh;
                                                            else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = lowXhigh;
                                                            else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                            else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = lowXhigh;
                                                            else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = lowXhigh;
                                                            else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                            else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXlow && unknownPriorityHold == 0) sumAverage = valueUK;
                                                            else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXlow && unknownPriorityHold == 1) sumAverage = lowXlow;
                                                            else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == highXhigh && unknownPriorityHold == 0) sumAverage = valueUK;
                                                            else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == highXhigh && unknownPriorityHold == 1) sumAverage = highXhigh;
                                                            else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXhigh && unknownPriorityHold == 0) sumAverage = lowXhigh;
                                                            else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXhigh && unknownPriorityHold == 1) sumAverage = lowXhigh;
                                                            else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                            else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                            else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = valueUK;
                                                            else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = valueUK;
                                                            else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = valueUK;
                                                            else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                            else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == -100) sumAverage = -100;
                                                            else sumAverage = -100;
                                                            
                                                            horizontalLineList [counter3*3+2] = -1;
                                                            colorCountTemp++;
                                                            colorDataCount++;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < horizontalLineListCount/3; counterA++){
                                //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<< horizontalLineList [counterA*3+counterB];
                                //    cout<<" horizontalLineList "<<counterA<<" "<<counter1<<endl;
                                //}
                                
                                if (colorDataCount == divisionStatus){
                                    skipCount = 0;
                                    
                                    if (lineageDisplayOption == 0){
                                        if (colorCountTemp == 0){
                                            sumTotal = sumTotal/(double)colorDataCount;
                                            sumAverage = (int)(sumAverage/(double)colorDataCount);
                                        }
                                        else{
                                            
                                            sumTotal = sumTotal/(double)colorCountTemp;
                                            sumAverage = (int)(sumAverage/(double)colorCountTemp);
                                        }
                                    }
                                    
                                    for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                                        if ((int)(horizontalLineList [counter2*3+1]) == expandLineage && horizontalLineList [counter2*3] == parentDoubleCell){
                                            horizontalLineListValue [counter2*2] = sumAverage;
                                            horizontalLineListValue [counter2*2+1] = sumTotal;
                                            horizontalLineList [counter2*3+2] = 1;
                                            break;
                                        }
                                    }
                                }
                                else skipCount++;
                            }
                            else{
                                
                                for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                    if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == expandCell){
                                        horizontalLineList [counter3*3+2] = -1;
                                    }
                                }
                            }
                        }
                        else terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                    
                    delete [] cellNoListTemp;
                    delete [] endStatusHold;
                }
                
                delete [] fluorescentEntry;
            }
            
            if (drawingOptionHold == 2){
                int liveIfLastTimePoint = 0;
                
                for (int counter2 = 0; counter2 < ifValueExtractCount/22; counter2++){
                    if (ifValueExtract [counter2*22+2] > liveIfLastTimePoint) liveIfLastTimePoint = ifValueExtract [counter2*22+2];
                }
                
                //cout<<liveCurrentCHNo<<" "<<ifCurrentTime<<" "<<ifCurrentCHNo<<" "<<lineageDisplayOption<<" "<<liveIfLastTimePoint<<" Channel"<<endl;
                
                double *fluorescentEntry = new double [numberOfCellEntry*5+50];
                int fluorescentEntryCount = 0;
                
                for (int counter2 = 0; counter2 < horizontalListCount2/7; counter2++){
                    if (horizontalList2 [counter2*7+3] <= arrayTableDetail [tableCurrentRowHold][3] && horizontalList2 [counter2*7+4] >= arrayTableDetail [tableCurrentRowHold][3]){
                        fluorescentEntry [fluorescentEntryCount] = horizontalList2 [counter2*7], fluorescentEntryCount++; //----Cell no----
                        fluorescentEntry [fluorescentEntryCount] = horizontalList2 [counter2*7+1], fluorescentEntryCount++; //----Ling no----
                        fluorescentEntry [fluorescentEntryCount] = 0, fluorescentEntryCount++; //----AV----
                        fluorescentEntry [fluorescentEntryCount] = 0, fluorescentEntryCount++; //----Total----
                        fluorescentEntry [fluorescentEntryCount] = counter2, fluorescentEntryCount++; //----Cell order----
                    }
                }
                
                //for (int counterA = 0; counterA < horizontalListCount2/7; counterA++){
                //    cout<<to_string(horizontalList2 [counterA*7])<<" "<<horizontalList2 [counterA*7+1]<<" "<<horizontalList2 [counterA*7+2]<<" "<<horizontalList2 [counterA*7+3]<<" "<<horizontalList2 [counterA*7+4]<<" "<<horizontalList2 [counterA*7+5]<<" "<<horizontalList2 [counterA*7+6]<<"  horizontalList2"<<endl;
                //}
                
                //for (int counterA = 0; counterA < fluorescentEntryCount/5; counterA++){
                //    cout<<to_string(fluorescentEntry [counterA*5])<<" "<<fluorescentEntry [counterA*5+1]<<" "<< fluorescentEntry [counterA*5+2]<<" "<<fluorescentEntry [counterA*5+3]<<" "<<fluorescentEntry [counterA*5+4]<<"   fluorescentEntry"<<endl;
                //}
                
                //for (int counterA = 0; counterA < ifEntryCount/13; counterA++){
                //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<arrayIFData [tableCurrentRowHold][counterA*13+counterB];
                //    cout<<" arrayIFData "<<counterA<<endl;
                //}
                
                for (int counter1 = 0; counter1 < fluorescentEntryCount/5; counter1++){
                    cellNoOriginal = 0;
                    
                    for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                        if (fluorescentEntry [counter1*5] == cellNoList [counter2*4+2]){
                            cellNoOriginal = (int)(cellNoList [counter2*4]);
                            break;
                        }
                    }
                    
                    for (int counter2 = 0; counter2 < ifValueExtractCount/22; counter2++){
                        if (cellNoOriginal == ifValueExtract [counter2*22] && (int)(fluorescentEntry [counter1*5+1]) == ifValueExtract [counter2*22+1] && liveIfLastTimePoint == ifValueExtract [counter2*22+2]){
                            if (liveCurrentCHNo == 1){
                                fluorescentEntry [counter1*5+2] = ifValueExtract [counter2*22+5];
                                fluorescentEntry [counter1*5+3] = ifValueExtract [counter2*22+5]*ifValueExtract [counter2*22+6];
                            }
                            else if (liveCurrentCHNo == 2){
                                fluorescentEntry [counter1*5+2] = ifValueExtract [counter2*22+8];
                                fluorescentEntry [counter1*5+3] = ifValueExtract [counter2*22+8]*ifValueExtract [counter2*22+9];
                            }
                            else if (liveCurrentCHNo == 3){
                                fluorescentEntry [counter1*5+2] = ifValueExtract [counter2*22+11];
                                fluorescentEntry [counter1*5+3] = ifValueExtract [counter2*22+11]*ifValueExtract [counter2*22+12];
                            }
                            else if (liveCurrentCHNo == 4){
                                fluorescentEntry [counter1*5+2] = ifValueExtract [counter2*22+14];
                                fluorescentEntry [counter1*5+3] = ifValueExtract [counter2*22+14]*ifValueExtract [counter2*22+15];
                            }
                            else if (liveCurrentCHNo == 5){
                                fluorescentEntry [counter1*5+2] = ifValueExtract [counter2*22+17];
                                fluorescentEntry [counter1*5+3] = ifValueExtract [counter2*22+17]*ifValueExtract [counter2*22+18];
                            }
                            else if (liveCurrentCHNo == 6){
                                fluorescentEntry [counter1*5+2] = ifValueExtract [counter2*22+20];
                                fluorescentEntry [counter1*5+3] = ifValueExtract [counter2*22+20]*ifValueExtract [counter2*22+21];
                            }
                            
                            break;
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < fluorescentEntryCount/5; counterA++){
                //    cout<<to_string(fluorescentEntry [counterA*5])<<" "<<fluorescentEntry [counterA*5+1]<<" "<< fluorescentEntry [counterA*5+2]<<" "<<fluorescentEntry [counterA*5+3]<<" "<<fluorescentEntry [counterA*5+4]<<"   fluorescentEntry"<<endl;
                //}
                
                for (int counter2 = 0; counter2 < horizontalListCount2/7*3+50; counter2++){
                    horizontalLineList [counter2] = 0;
                }
                
                for (int counter2 = 0; counter2 < horizontalListCount2/7*2+50; counter2++){
                    horizontalLineListValue [counter2] = 0;
                }
                
                horizontalLineListCount = 0;
                horizontalLineListValueCount = 0;
                
                for (int counter2 = 0; counter2 < horizontalListCount2/7; counter2++){
                    horizontalLineList [horizontalLineListCount] = horizontalList2 [counter2*7], horizontalLineListCount++;
                    horizontalLineList [horizontalLineListCount] = horizontalList2 [counter2*7+1], horizontalLineListCount++;
                    horizontalLineList [horizontalLineListCount] = 0, horizontalLineListCount++;
                    
                    horizontalLineListValue [horizontalLineListValueCount] = -1, horizontalLineListValueCount++;
                    horizontalLineListValue [horizontalLineListValueCount] = -1, horizontalLineListValueCount++;
                }
                
                //for (int counterA = 0; counterA < horizontalListCount2/7; counterA++){
                //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<< horizontalList2 [counterA*7+counterB];
                //    cout<<" horizontalList2 "<<counterA<<" "<<counter1<<endl;
                //}
                
                //for (int counterA = 0; counterA < horizontalLineListCount/3; counterA++){
                //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<< to_string(horizontalLineList [counterA*3+counterB]);
                //    cout<<" horizontalLineList "<<counterA<<" "<<endl;
                //}
                
                if (liveIfLastTimePoint == arrayTableDetail [tableCurrentRowHold][3]){
                    if (lineageDisplayOption == 0){
                        for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                            for (int counter3 = 0; counter3 < fluorescentEntryCount/5; counter3++){
                                if (horizontalLineList [counter2*3] == fluorescentEntry [counter3*5] && horizontalLineList [counter2*3+1] == fluorescentEntry [counter3*5+1]){
                                    horizontalLineList [counter2*3+2] = 1;
                                    horizontalLineListValue [counter2*2] = fluorescentEntry [counter3*5+2];
                                    horizontalLineListValue [counter2*2+1] = fluorescentEntry [counter3*5+3];
                                    
                                    break;
                                }
                            }
                        }
                    }
                    else{
                        
                        for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                            for (int counter3 = 0; counter3 < fluorescentEntryCount/5; counter3++){
                                if (horizontalLineList [counter2*3] == fluorescentEntry [counter3*5] && horizontalLineList [counter2*3+1] == fluorescentEntry [counter3*5+1]){
                                    horizontalLineList [counter2*3+2] = 1;
                                    
                                    if (fluorescentEntry [counter3*5+2] == 0) horizontalLineListValue [counter2*2] = lowXlow;
                                    else if (fluorescentEntry [counter3*5+2] == 100) horizontalLineListValue [counter2*2] = highXhigh;
                                    else horizontalLineListValue [counter2*2] = -100;
                                    
                                    horizontalLineListValue [counter2*2+1] = fluorescentEntry [counter3*5+3];
                                    
                                    break;
                                }
                            }
                        }
                    }
                    
                    //----Set dummy value at CD, OF FU lines----
                    if (unknownOptionHold == 1 && lineageDisplayOption == 0){
                        for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                            if (horizontalLineList [counter2*3+2] == 0){
                                cellNoOriginal = 0;
                                
                                for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                                    if (horizontalLineList [counter2*3] == cellNoList [counter3*4+2]){
                                        cellNoOriginal = (int)(cellNoList [counter3*4]);
                                        break;
                                    }
                                }
                                
                                for (unsigned long counter3 = 0; counter3 < lineageExtractCount/9; counter3++){
                                    if (arrayLineageExtract [counter3*9+5] == cellNoOriginal && (arrayLineageExtract [counter3*9+3] == 7 || arrayLineageExtract [counter3*9+3] == 8 || arrayLineageExtract [counter3*9+3] == 91)){
                                        horizontalLineList [counter2*3+2] = 1;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    else if (lineageDisplayOption == 1){
                        for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                            if (horizontalLineList [counter2*3+2] == 0){
                                cellNoOriginal = 0;
                                
                                for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                                    if (horizontalLineList [counter2*3] == cellNoList [counter3*4+2]){
                                        cellNoOriginal = (int)(cellNoList [counter3*4]);
                                        break;
                                    }
                                }
                                
                                for (unsigned long counter3 = 0; counter3 < lineageExtractCount/9; counter3++){
                                    if (arrayLineageExtract [counter3*9+5] == cellNoOriginal && (arrayLineageExtract [counter3*9+3] == 7 || arrayLineageExtract [counter3*9+3] == 8 || arrayLineageExtract [counter3*9+3] == 91)){
                                        horizontalLineList [counter2*3+2] = 1;
                                        
                                        horizontalLineListValue [counter2*2] = -100;
                                        horizontalLineListValue [counter2*2+1] = 100;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < horizontalLineListCount/3; counterA++){
                    //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<< horizontalLineList [counterA*3+counterB];
                    //    cout<<" horizontalLineList "<<counterA<<" "<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < horizontalLineListCount/3; counterA++){
                    //    for (int counterB = 0; counterB < 2; counterB++) cout<<" "<< horizontalLineListValue [counterA*2+counterB];
                    //    cout<<" horizontalLineListValue "<<counterA<<" "<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < lineageExtractCount/9; counterA++){
                    //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayLineageExtract [counterA*9+counterB];
                    //    cout<<" arrayLineageExtract "<<counterA<<endl;
                    //}
                    
                    int expandLineage = 0;
                    int skipCount = 0;
                    int skipEntryCount = 0;
                    int divisionStatus = 0;
                    int dataEntryCheck = 0;
                    int endStatusCheck = 0;
                    int endStatusCheck2 = 0;
                    int colorCountTemp = 0;
                    int checkStart = 0;
                    int checkNoCheck = 0;
                    
                    double expandCell = 0;
                    double parentDoubleCell = 0;
                    double cellNoOriginal2 = 0;
                    double sumTotal = 0;
                    double sumAverage = 0;
                    double colorDataCount = 0;
                    
                    double *cellNoListTemp = new double [10];
                    int cellNoListTempCount = 0;
                    
                    int *endStatusHold = new int [20];
                    int endStatusHoldCount = 0;
                    
                    do{
                        
                        terminationFlag = 1;
                        expandLineage = 0;
                        skipEntryCount = skipCount;
                        
                        for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                            if (horizontalLineList [counter2*3+2] == 1 && skipEntryCount == 0){
                                expandLineage = (int)(horizontalLineList [counter2*3+1]);
                                expandCell = horizontalLineList [counter2*3];
                                break;
                            }
                            else if (horizontalLineList [counter2*3+2] == 1 && skipEntryCount >= 0) skipEntryCount--;
                        }
                        
                        if (expandLineage != 0){
                            parentCellNo = -1;
                            cellNoOriginal = 0;
                            
                            for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                                if (expandCell == cellNoList [counter2*4+2]){
                                    cellNoOriginal = (int)(cellNoList [counter2*4]);
                                    break;
                                }
                            }
                            
                            for (unsigned long counter2 = 0; counter2 < lineageExtractCount/9; counter2++){
                                if (arrayLineageExtract [counter2*9+3] == 31 || arrayLineageExtract [counter2*9+3] == 41 || arrayLineageExtract [counter2*9+3] == 51){
                                    if (arrayLineageExtract [counter2*9+6] == expandLineage && arrayLineageExtract [counter2*9+5] == cellNoOriginal){
                                        parentCellNo = arrayLineageExtract [counter2*9+4];
                                        break;
                                    }
                                }
                            }
                            
                            parentDoubleCell = 0;
                            
                            for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                                if (parentCellNo == cellNoList [counter2*4]){
                                    parentDoubleCell = cellNoList [counter2*4+2];
                                    break;
                                }
                            }
                            
                            if (parentCellNo != -1){
                                cellNoListTempCount = 0;
                                endStatusHoldCount = 0;
                                divisionStatus = 0;
                                
                                for (unsigned long counter2 = 0; counter2 < lineageExtractCount/9; counter2++){
                                    if (arrayLineageExtract [counter2*9+3] == 31 || arrayLineageExtract [counter2*9+3] == 41 || arrayLineageExtract [counter2*9+3] == 51){
                                        if (arrayLineageExtract [counter2*9+6] == expandLineage && arrayLineageExtract [counter2*9+4] == parentCellNo){
                                            cellNoOriginal2 = 0;
                                            
                                            for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                                                if (arrayLineageExtract [counter2*9+5] == cellNoList [counter3*4]){
                                                    cellNoOriginal2 = cellNoList [counter3*4+2];
                                                    break;
                                                }
                                            }
                                            
                                            if (arrayLineageExtract [counter2*9+3] == 31) divisionStatus = 2;
                                            else if (arrayLineageExtract [counter2*9+3] == 41) divisionStatus = 3;
                                            else if (arrayLineageExtract [counter2*9+3] == 51) divisionStatus = 4;
                                            
                                            cellNoListTemp [cellNoListTempCount] = cellNoOriginal2, cellNoListTempCount++;
                                            
                                            endStatusHold [endStatusHoldCount] = 0, endStatusHoldCount++;
                                            endStatusHold [endStatusHoldCount] = -1, endStatusHoldCount++;
                                            
                                            for (unsigned long counter3 = 0; counter3 < lineageExtractCount/9; counter3++){
                                                if (arrayLineageExtract [counter3*9+6] == expandLineage && arrayLineageExtract [counter3*9+5] == arrayLineageExtract [counter2*9+5] && (arrayLineageExtract [counter3*9+3] == 7 || arrayLineageExtract [counter3*9+3] == 8 || arrayLineageExtract [counter3*9+3] == 91)){
                                                    endStatusHold [endStatusHoldCount-2] = 1;
                                                    break;
                                                }
                                            }
                                            
                                            checkStart = 0;
                                            checkNoCheck = 0;
                                            
                                            //----Check progeny's end status, enter 1 when end is CD, OF, FU----
                                            for (unsigned long counter3 = 0; counter3 < lineageExtractCount/9; counter3++){
                                                if (arrayLineageExtract [counter3*9+6] == expandLineage && arrayLineageExtract [counter3*9+4] == arrayLineageExtract [counter2*9+5] && arrayLineageExtract [counter3*9+3] != 91 && arrayLineageExtract [counter3*9+4] != 92){
                                                    checkStart = 1;
                                                    checkNoCheck = arrayLineageExtract [counter3*9+5];
                                                }
                                                
                                                if (arrayLineageExtract [counter3*9+6] == expandLineage && arrayLineageExtract [counter3*9+5] == checkNoCheck && checkStart == 1 && (arrayLineageExtract [counter3*9+3] == 7 || arrayLineageExtract [counter3*9+3] == 8 || arrayLineageExtract [counter3*9+3] == 91)){
                                                    if (endStatusHold [endStatusHoldCount-1] == -1) endStatusHold [endStatusHoldCount-1] = 1;
                                                    
                                                    checkStart = 0;
                                                }
                                                else if (arrayLineageExtract [counter3*9+6] == expandLineage && arrayLineageExtract [counter3*9+5] == checkNoCheck && checkStart == 1 && (arrayLineageExtract [counter3*9+3] == 32 || arrayLineageExtract [counter3*9+3] == 42 || arrayLineageExtract [counter3*9+3] == 52 || arrayLineageExtract [counter3*9+2] == arrayTableDetail [tableCurrentRowHold][3])){
                                                    endStatusHold [endStatusHoldCount-1] = 0;
                                                    break;
                                                }
                                            }
                                            
                                            if (endStatusHold [endStatusHoldCount-1] == -1) endStatusHold [endStatusHoldCount-1] = 0;
                                        }
                                    }
                                }
                                
                                endStatusCheck = 0;
                                endStatusCheck2 = 0;
                                
                                for (int counter2 = 0; counter2 < endStatusHoldCount; counter2++){
                                    if (endStatusHold [counter2] == 1) endStatusCheck = 1;
                                    if (endStatusHold [counter2*2+1] == 1) endStatusCheck2 = 1;
                                }
                                
                                sumTotal = 0;
                                sumAverage = -1;
                                colorDataCount = 0;
                                colorCountTemp = 0;
                                
                                if (lineageDisplayOption == 1) sumAverage = -1;
                                
                                if (lineageDisplayOption == 0){
                                    if (unknownOptionHold == 0){
                                        if (endStatusCheck == 0){
                                            for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                    if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && horizontalLineListValue [counter3*2] != -1 && horizontalLineListValue [counter3*2+1] != -1){
                                                        sumTotal = sumTotal+horizontalLineListValue [counter3*2+1];
                                                        sumAverage = sumAverage+(int)horizontalLineListValue [counter3*2];
                                                        
                                                        horizontalLineList [counter3*3+2] = -1;
                                                        colorDataCount++;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else if (unknownOptionHold == 1){
                                        if (endStatusCheck == 0 && endStatusCheck2 == 0){
                                            for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                    if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && horizontalLineListValue [counter3*2] != -1 && horizontalLineListValue [counter3*2+1] != -1){
                                                        sumTotal = sumTotal+horizontalLineListValue [counter3*2+1];
                                                        sumAverage = sumAverage+(int)horizontalLineListValue [counter3*2];
                                                        
                                                        horizontalLineList [counter3*3+2] = -1;
                                                        colorDataCount++;
                                                    }
                                                }
                                            }
                                        }
                                        else{
                                            
                                            endStatusCheck = 0;
                                            dataEntryCheck = 0;
                                            
                                            for (int counter2 = 0; counter2 < endStatusHoldCount/2; counter2++){
                                                if (endStatusHold [counter2*2] == 0) endStatusCheck = 1;
                                                
                                                for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                    if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && endStatusHold [counter2*2] == 0 && endStatusHold [counter2*2+1] == 0 && horizontalLineListValue [counter3*2] == -1 && horizontalLineListValue [counter3*2+1] == -1){
                                                        dataEntryCheck = 1;
                                                    }
                                                }
                                            }
                                            
                                            if (endStatusCheck == 0){
                                                for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                    for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                        if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2]){
                                                            sumTotal = -2;
                                                            sumAverage = -2;
                                                            
                                                            horizontalLineListValue [counter3*2] = -1;
                                                            horizontalLineListValue [counter3*2+1] = -1;
                                                            horizontalLineList [counter3*3+2] = -1;
                                                            
                                                            colorDataCount++;
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                            else if (dataEntryCheck == 0){
                                                for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                    for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                        if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && horizontalLineListValue [counter3*2] != -1 && horizontalLineListValue [counter3*2+1] != -1){
                                                            sumTotal = sumTotal+horizontalLineListValue [counter3*2+1];
                                                            sumAverage = sumAverage+(int)horizontalLineListValue [counter3*2];
                                                            
                                                            horizontalLineList [counter3*3+2] = -1;
                                                            colorCountTemp++;
                                                            colorDataCount++;
                                                        }
                                                    }
                                                }
                                                
                                                for (int counter2 = 0; counter2 < endStatusHoldCount/2; counter2++){
                                                    if (endStatusHold [counter2*2] == 1 || endStatusHold [counter2*2+1] == 1){
                                                        for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                            if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2]){
                                                                horizontalLineListValue [counter3*2] = (int)(sumAverage/(double)colorCountTemp);
                                                                horizontalLineListValue [counter3*2+1] = sumTotal/(double)colorCountTemp;
                                                                horizontalLineList [counter3*3+2] = -1;
                                                                
                                                                colorDataCount++;
                                                                
                                                                break;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                else if (lineageDisplayOption == 1){
                                    if (endStatusCheck == 0){
                                        for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                            for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && horizontalLineListValue [counter3*2] != -1 && horizontalLineListValue [counter3*2+1] != -1){
                                                    sumTotal = sumTotal+horizontalLineListValue [counter3*2+1];
                                                    
                                                    //cout<<highXhigh<<" "<<lowXlow<<" "<<lowXhigh<<" "<<sumAverage<<" "<<horizontalLineListValue [counter3*2]<<" "<<to_string(cellNoListTemp [counter2])<<" cellNoListTemp"<<endl;
                                                    
                                                    if (sumAverage == -1 && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXlow;
                                                    else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = highXhigh;
                                                    else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                    else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                    else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == -100) sumAverage = -100;
                                                    else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXlow;
                                                    else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = lowXhigh;
                                                    else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                    else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = valueUK;
                                                    else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = lowXlow;
                                                    else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                    else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXhigh;
                                                    else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = highXhigh;
                                                    else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                    else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = valueUK;
                                                    else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = highXhigh;
                                                    else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                    else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXhigh;
                                                    else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = lowXhigh;
                                                    else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                    else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = lowXhigh;
                                                    else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = lowXhigh;
                                                    else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                    else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXlow && unknownPriorityHold == 0) sumAverage = valueUK;
                                                    else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXlow && unknownPriorityHold == 1) sumAverage = lowXlow;
                                                    else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == highXhigh && unknownPriorityHold == 0) sumAverage = valueUK;
                                                    else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == highXhigh && unknownPriorityHold == 1) sumAverage = highXhigh;
                                                    else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXhigh && unknownPriorityHold == 0) sumAverage = lowXhigh;
                                                    else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXhigh && unknownPriorityHold == 1) sumAverage = lowXhigh;
                                                    else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                    else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                    else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = valueUK;
                                                    else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = valueUK;
                                                    else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = valueUK;
                                                    else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                    else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == -100) sumAverage = -100;
                                                    else sumAverage = -100;
                                                    
                                                    horizontalLineList [counter3*3+2] = -1;
                                                    colorDataCount++;
                                                }
                                            }
                                        }
                                    }
                                    else{
                                        
                                        endStatusCheck = 0;
                                        dataEntryCheck = 0;
                                        
                                        for (int counter2 = 0; counter2 < endStatusHoldCount/2; counter2++){
                                            if (endStatusHold [counter2*2] == 0) endStatusCheck = 1;
                                            
                                            for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && endStatusHold [counter2*2] == 0 && horizontalLineListValue [counter3*2] == -1 && horizontalLineListValue [counter3*2+1] == -1){
                                                    dataEntryCheck = 1;
                                                }
                                            }
                                        }
                                        
                                        if (endStatusCheck == 0){
                                            for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                    if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2]){
                                                        sumTotal = 0;
                                                        sumAverage = -100;
                                                        
                                                        horizontalLineListValue [counter3*2] = -100;
                                                        horizontalLineListValue [counter3*2+1] = 0;
                                                        horizontalLineList [counter3*3+2] = -1;
                                                        
                                                        colorDataCount++;
                                                        break;
                                                    }
                                                }
                                            }
                                        }
                                        else if (dataEntryCheck == 0){
                                            for (int counter2 = 0; counter2 < endStatusHoldCount/2; counter2++){
                                                if (endStatusHold [counter2*2] == 1){
                                                    for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                        if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2]){
                                                            sumAverage = -100;
                                                            
                                                            horizontalLineListValue [counter3*2] = -100;
                                                            horizontalLineListValue [counter3*2+1] = sumTotal/(double)colorCountTemp;
                                                            horizontalLineList [counter3*3+2] = -1;
                                                            
                                                            colorDataCount++;
                                                            
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                            
                                            for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                if (endStatusHold [counter2*2] == 0){
                                                    for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                        if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && horizontalLineListValue [counter3*2] != -1 && horizontalLineListValue [counter3*2+1] != -1){
                                                            sumTotal = sumTotal+horizontalLineListValue [counter3*2+1];
                                                            
                                                            if (sumAverage == -1 && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXlow;
                                                            else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = highXhigh;
                                                            else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                            else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                            else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == -100) sumAverage = -100;
                                                            else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXlow;
                                                            else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = lowXhigh;
                                                            else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                            else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = valueUK;
                                                            else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = lowXlow;
                                                            else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                            else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXhigh;
                                                            else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = highXhigh;
                                                            else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                            else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = valueUK;
                                                            else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = highXhigh;
                                                            else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                            else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXhigh;
                                                            else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = lowXhigh;
                                                            else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                            else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = lowXhigh;
                                                            else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = lowXhigh;
                                                            else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                            else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXlow && unknownPriorityHold == 0) sumAverage = valueUK;
                                                            else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXlow && unknownPriorityHold == 1) sumAverage = lowXlow;
                                                            else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == highXhigh && unknownPriorityHold == 0) sumAverage = valueUK;
                                                            else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == highXhigh && unknownPriorityHold == 1) sumAverage = highXhigh;
                                                            else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXhigh && unknownPriorityHold == 0) sumAverage = lowXhigh;
                                                            else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXhigh && unknownPriorityHold == 1) sumAverage = lowXhigh;
                                                            else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                            else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                            else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = valueUK;
                                                            else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = valueUK;
                                                            else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = valueUK;
                                                            else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                            else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == -100) sumAverage = -100;
                                                            else sumAverage = -100;
                                                            
                                                            horizontalLineList [counter3*3+2] = -1;
                                                            colorCountTemp++;
                                                            colorDataCount++;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < horizontalLineListCount/3; counterA++){
                                //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<< horizontalLineList [counterA*3+counterB];
                                //    cout<<" horizontalLineList "<<counterA<<" "<<counter1<<endl;
                                //}
                                
                                if (colorDataCount == divisionStatus){
                                    skipCount = 0;
                                    
                                    if (lineageDisplayOption == 0){
                                        if (colorCountTemp == 0){
                                            sumTotal = sumTotal/(double)colorDataCount;
                                            sumAverage = (int)(sumAverage/(double)colorDataCount);
                                        }
                                        else{
                                            
                                            sumTotal = sumTotal/(double)colorCountTemp;
                                            sumAverage = (int)(sumAverage/(double)colorCountTemp);
                                        }
                                    }
                                    
                                    for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                                        if ((int)(horizontalLineList [counter2*3+1]) == expandLineage && horizontalLineList [counter2*3] == parentDoubleCell){
                                            horizontalLineListValue [counter2*2] = sumAverage;
                                            horizontalLineListValue [counter2*2+1] = sumTotal;
                                            horizontalLineList [counter2*3+2] = 1;
                                            break;
                                        }
                                    }
                                }
                                else skipCount++;
                            }
                            else{
                                
                                for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                    if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == expandCell){
                                        horizontalLineList [counter3*3+2] = -1;
                                    }
                                }
                            }
                        }
                        else terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                    
                    delete [] cellNoListTemp;
                    delete [] endStatusHold;
                }
                
                delete [] fluorescentEntry;
            }
            
            //for (int counterA = 0; counterA < horizontalLineListCount/3; counterA++){
            //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<< horizontalLineList [counterA*3+counterB];
            //    cout<<" horizontalLineList "<<counterA<<" "<<endl;
            //}
            
            //for (int counterA = 0; counterA < horizontalLineListCount/3; counterA++){
            //    for (int counterB = 0; counterB < 2; counterB++) cout<<" "<< horizontalLineListValue [counterA*2+counterB];
            //    cout<<" horizontalLineListValue "<<counterA<<" "<<endl;
            //}
            
            ifString = to_string(roundNoGet);
            
            [attributesA setObject:[NSFont boldSystemFontOfSize:9] forKey:NSFontAttributeName];
            
            //----Color data range get----
            int rangeLiveAverageLow = 0;
            int rangeLiveAverageHigh = 0;
            int rangeLiveTotalLow = 0;
            int rangeLiveTotalHigh = 0;
            
            if (liveCurrentCHNo != 0){
                string liveName = "";
                
                if (liveCurrentCHNo == 1) liveName = arrayTableMain [tableCurrentRowHold][6];
                else if (liveCurrentCHNo == 2) liveName = arrayTableMain [tableCurrentRowHold][7];
                else if (liveCurrentCHNo == 3) liveName = arrayTableMain [tableCurrentRowHold][8];
                else if (liveCurrentCHNo == 4) liveName = arrayTableMain [tableCurrentRowHold][9];
                else if (liveCurrentCHNo == 5) liveName = arrayTableMain [tableCurrentRowHold][10];
                else if (liveCurrentCHNo == 6) liveName = arrayTableMain [tableCurrentRowHold][11];
                
                for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryCount; counter1++){
                    if (atoi(arrayLineageFluorescentDataType [counter1][0].c_str()) == tableCurrentRowHold+1 && arrayLineageFluorescentDataType [counter1][1] == "Live" && arrayLineageFluorescentDataType [counter1][2] == liveName){
                        rangeLiveTotalLow = atoi(arrayLineageFluorescentDataType [counter1][6].c_str());
                        rangeLiveTotalHigh = atoi(arrayLineageFluorescentDataType [counter1][7].c_str());
                        rangeLiveAverageLow = atoi(arrayLineageFluorescentDataType [counter1][4].c_str());
                        rangeLiveAverageHigh = atoi(arrayLineageFluorescentDataType [counter1][5].c_str());
                        break;
                    }
                }
            }
            
            //for (int counterA = 0; counterA < liveTimeListCount; counterA++){
            //    cout<<counterA<<" "<<liveTimeList [counterA] <<" liveTimeList"<<endl;
            //}
            
            string liveName = "";
            string cellNumberString;
            string horizontalString;
            
            NSBezierPath *pathCircle;
            
            int endType = 0;
            int startType = 0;
            int liveColorStart = 0;
            int liveColorEnd = 0;
            int liveValueGet = 0;
            int rangeNoHold = 0;
            int timeHold = 0;
            int timeHold2 = 0;
            int differenceInt = 0;
            double rangeDivision = 0;
            double difference = 0;
            double difference2 = 0;
            
            double *rangeList = new double [horizontalTime*3+30];
            int rangeListCount = 0;
            
            double markerSizeSet = 0;
            
            if (markSizeFlag == 0) markerSizeSet = 12;
            else if (markSizeFlag == 1) markerSizeSet = 6;
            else if (markSizeFlag == 2) markerSizeSet = 0;
            
            for (int counter1 = 0; counter1 < horizontalListCount2/7; counter1++){
                [[NSColor blackColor] set];
                
                cellNoOriginal = 0;
                
                for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                    if (horizontalList2 [counter1*7] == cellNoList [counter2*4+2]){
                        cellNoOriginal = (int)(cellNoList [counter2*4]);
                        break;
                    }
                }
                
                if (horizontalList2 [counter1*7+5] == 32 || horizontalList2 [counter1*7+3] == 42 || horizontalList2 [counter1*7+3] == 52) endType = 1;
                else endType = 0;
                
                if (horizontalList2 [counter1*7+6] == 1) startType = 1;
                else startType = 0;
                
                //cout<<counter1<<" "<<horizontalList2 [counter1*7]<<" "<<horizontalList2 [counter1*7+1]<<" TimeStartEnd"<<endl;
                
                //----Color data drawing----
                if (drawingOptionHold == 0 || drawingOptionHold == 3){
                    positionAA.x = 40+horizontalList2 [counter1*7+3]*horizontalIncrement;
                    positionAA.y = 52+increment+counter1*increment;
                    
                    if (endType == 1) positionBB.x = 40+(horizontalList2 [counter1*7+4]+1)*horizontalIncrement;
                    else positionBB.x = 40+horizontalList2 [counter1*7+4]*horizontalIncrement;
                    
                    positionBB.y = 52+increment+counter1*increment;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                }
                else if (drawingOptionHold == 1){
                    liveColorStart = -1;
                    liveColorEnd = -1;
                    
                    for (int counter2 = 0; counter2 < liveTimeListCount; counter2++){
                        if (liveColorStart == -1 && liveTimeList [counter2] >= horizontalList2 [counter1*7+3]) liveColorStart = counter2;
                        if (liveTimeList [counter2] <= horizontalList2 [counter1*7+4]) liveColorEnd = counter2;
                    }
                    
                    if (liveColorStart != -1 && liveColorStart == liveColorEnd){
                        liveValueGet = 0;
                        
                        for (int counter2 = 0; counter2 < ifValueExtractCount/22; counter2++){
                            if (cellNoOriginal == ifValueExtract [counter2*22] && (int)(horizontalList2 [counter1*7+1]) == ifValueExtract [counter2*22+1] && liveTimeList [liveColorStart] == ifValueExtract [counter2*22+2]){
                                
                                if (liveCurrentCHNo == 1){
                                    if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter2*22+5];
                                    else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter2*22+5]*ifValueExtract [counter2*22+6];
                                }
                                else if (liveCurrentCHNo == 2){
                                    if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter2*22+8];
                                    else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter2*22+8]*ifValueExtract [counter2*22+9];
                                }
                                else if (liveCurrentCHNo == 3){
                                    if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter2*22+11];
                                    else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter2*22+11]*ifValueExtract [counter2*22+12];
                                }
                                else if (liveCurrentCHNo == 4){
                                    if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter2*22+14];
                                    else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter2*22+14]*ifValueExtract [counter2*22+15];
                                }
                                else if (liveCurrentCHNo == 5){
                                    if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter2*22+17];
                                    else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter2*22+17]*ifValueExtract [counter2*22+18];
                                }
                                else if (liveCurrentCHNo == 6){
                                    if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter2*22+20];
                                    else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter2*22+20]*ifValueExtract [counter2*22+21];
                                }
                                
                                break;
                            }
                        }
                        
                        if (averageTotalFlag == 0){
                            rangeDivision = (rangeLiveAverageHigh-rangeLiveAverageLow)/(double)25;
                            
                            if (liveValueGet <= rangeLiveAverageLow+rangeDivision) rangeNo = 1;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*2) rangeNo = 2;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*3) rangeNo = 3;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*4) rangeNo = 4;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*5) rangeNo = 5;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*6) rangeNo = 6;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*7) rangeNo = 7;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*8) rangeNo = 8;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*9) rangeNo = 9;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*10) rangeNo = 10;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*11) rangeNo = 11;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*12) rangeNo = 12;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*13) rangeNo = 13;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*14) rangeNo = 14;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*15) rangeNo = 15;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*16) rangeNo = 16;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*17) rangeNo = 17;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*18) rangeNo = 18;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*19) rangeNo = 19;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*20) rangeNo = 20;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*21) rangeNo = 21;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*22) rangeNo = 22;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*23) rangeNo = 23;
                            else rangeNo = 24;
                            
                            if (liveValueGet == -1) rangeNo = 105/3+1;
                            
                            [[NSColor colorWithCalibratedRed:arrayColorRange [(rangeNo-1)*3] green:arrayColorRange [(rangeNo-1)*3+1] blue:arrayColorRange [(rangeNo-1)*3+2] alpha:1] set];
                            
                            positionAA.x = 40+horizontalList2 [counter1*7+3]*horizontalIncrement;
                            positionAA.y = 52+increment+counter1*increment;
                            
                            if (endType == 1) positionBB.x = 40+(horizontalList2 [counter1*7+4]+1)*horizontalIncrement;
                            else positionBB.x = 40+horizontalList2 [counter1*7+4]*horizontalIncrement;
                            
                            positionBB.y = 52+increment+counter1*increment;
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                        else{
                            
                            rangeDivision = (rangeLiveTotalHigh-rangeLiveTotalLow)/(double)25;
                            
                            if (liveValueGet <= rangeLiveTotalLow+rangeDivision) rangeNo = 1;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*2) rangeNo = 2;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*3) rangeNo = 3;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*4) rangeNo = 4;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*5) rangeNo = 5;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*6) rangeNo = 6;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*7) rangeNo = 7;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*8) rangeNo = 8;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*9) rangeNo = 9;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*10) rangeNo = 10;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*11) rangeNo = 11;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*12) rangeNo = 12;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*13) rangeNo = 13;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*14) rangeNo = 14;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*15) rangeNo = 15;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*16) rangeNo = 16;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*17) rangeNo = 17;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*18) rangeNo = 18;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*19) rangeNo = 19;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*20) rangeNo = 20;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*21) rangeNo = 21;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*22) rangeNo = 22;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*23) rangeNo = 23;
                            else rangeNo = 24;
                            
                            if (liveValueGet == -1) rangeNo = 105/3+1;
                            
                            [[NSColor colorWithCalibratedRed:arrayColorRange [(rangeNo-1)*3] green:arrayColorRange [(rangeNo-1)*3+1] blue:arrayColorRange [(rangeNo-1)*3+2] alpha:1] set];
                            
                            positionAA.x = 40+horizontalList2 [counter1*7+3]*horizontalIncrement;
                            positionAA.y = 52+increment+counter1*increment;
                            
                            if (endType == 1) positionBB.x = 40+(horizontalList2 [counter1*7+4]+1)*horizontalIncrement;
                            else positionBB.x = 40+horizontalList2 [counter1*7+4]*horizontalIncrement;
                            
                            positionBB.y = 52+increment+counter1*increment;
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                    } //----One live data/cell----
                    else if (liveColorStart != -1 && liveColorStart < liveColorEnd){ //----More than one live data/cell----
                        rangeListCount = 0;
                        
                        for (int counter2 = liveColorStart; counter2 <= liveColorEnd; counter2++){
                            liveValueGet = 0;
                            
                            for (int counter3 = 0; counter3 < ifValueExtractCount/22; counter3++){
                                if (cellNoOriginal == ifValueExtract [counter3*22] && (int)(horizontalList2 [counter1*7+1]) == ifValueExtract [counter3*22+1] && liveTimeList [counter2] == ifValueExtract [counter3*22+2]){
                                    
                                    if (liveCurrentCHNo == 1){
                                        if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter3*22+5];
                                        else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter3*22+5]*ifValueExtract [counter3*22+6];
                                    }
                                    else if (liveCurrentCHNo == 2){
                                        if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter3*22+8];
                                        else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter3*22+8]*ifValueExtract [counter3*22+9];
                                    }
                                    else if (liveCurrentCHNo == 3){
                                        if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter3*22+11];
                                        else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter3*22+11]*ifValueExtract [counter3*22+12];
                                    }
                                    else if (liveCurrentCHNo == 4){
                                        if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter3*22+14];
                                        else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter3*22+14]*ifValueExtract [counter3*22+15];
                                    }
                                    else if (liveCurrentCHNo == 5){
                                        if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter3*22+17];
                                        else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter3*22+17]*ifValueExtract [counter3*22+18];
                                    }
                                    else if (liveCurrentCHNo == 6){
                                        if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter3*22+20];
                                        else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter3*22+20]*ifValueExtract [counter3*22+21];
                                    }
                                    
                                    break;
                                }
                            }
                            
                            if (averageTotalFlag == 0){
                                rangeDivision = (rangeLiveAverageHigh-rangeLiveAverageLow)/(double)25;
                                
                                if (liveValueGet <= rangeLiveAverageLow+rangeDivision) rangeNo = 1;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*2) rangeNo = 2;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*3) rangeNo = 3;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*4) rangeNo = 4;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*5) rangeNo = 5;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*6) rangeNo = 6;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*7) rangeNo = 7;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*8) rangeNo = 8;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*9) rangeNo = 9;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*10) rangeNo = 10;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*11) rangeNo = 11;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*12) rangeNo = 12;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*13) rangeNo = 13;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*14) rangeNo = 14;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*15) rangeNo = 15;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*16) rangeNo = 16;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*17) rangeNo = 17;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*18) rangeNo = 18;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*19) rangeNo = 19;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*20) rangeNo = 20;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*21) rangeNo = 21;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*22) rangeNo = 22;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*23) rangeNo = 23;
                                else rangeNo = 23;
                                
                                if (liveValueGet == -1) rangeNo = 105/3+1;
                            }
                            else{
                                
                                rangeDivision = (rangeLiveTotalHigh-rangeLiveTotalLow)/(double)25;
                                
                                if (liveValueGet <= rangeLiveTotalLow+rangeDivision) rangeNo = 1;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*2) rangeNo = 2;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*3) rangeNo = 3;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*4) rangeNo = 4;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*5) rangeNo = 5;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*6) rangeNo = 6;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*7) rangeNo = 7;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*8) rangeNo = 8;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*9) rangeNo = 9;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*10) rangeNo = 10;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*11) rangeNo = 11;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*12) rangeNo = 12;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*13) rangeNo = 13;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*14) rangeNo = 14;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*15) rangeNo = 15;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*16) rangeNo = 16;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*17) rangeNo = 17;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*18) rangeNo = 18;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*19) rangeNo = 19;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*20) rangeNo = 20;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*21) rangeNo = 21;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*22) rangeNo = 22;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*23) rangeNo = 23;
                                else rangeNo = 23;
                                
                                if (liveValueGet == -1) rangeNo = 105/3+1;
                            }
                            
                            if (counter2 == liveColorStart){
                                rangeList [rangeListCount] = horizontalList2 [counter1*7+3], rangeListCount++;
                                rangeList [rangeListCount] = liveTimeList [counter2], rangeListCount++;
                                rangeList [rangeListCount] = rangeNo, rangeListCount++;
                                
                                rangeNoHold = rangeNo;
                                timeHold = liveTimeList [counter2];
                            }
                            else if (counter2 == liveColorEnd){
                                difference = (rangeNo-rangeNoHold)/(double)(liveTimeList [counter2]-timeHold);
                                
                                if (liveTimeList [counter2]-timeHold < 5){
                                    rangeList [rangeListCount] = horizontalList2 [counter1*7+3], rangeListCount++;
                                    rangeList [rangeListCount] = liveTimeList [counter2], rangeListCount++;
                                    rangeList [rangeListCount] = rangeNo, rangeListCount++;
                                }
                                else{
                                    
                                    difference2 = difference;
                                    timeHold2 = timeHold;
                                    
                                    for (int counter3 = timeHold+1; counter3 <= liveTimeList [counter2]; counter3++){
                                        if (counter3 == liveTimeList [counter2]){
                                            
                                            rangeList [rangeListCount] = timeHold2, rangeListCount++;
                                            rangeList [rangeListCount] = counter3, rangeListCount++;
                                            rangeList [rangeListCount] = rangeNo, rangeListCount++;
                                        }
                                        else if (difference2 >= 1){
                                            differenceInt = (int)difference2;
                                            
                                            rangeList [rangeListCount] = timeHold2, rangeListCount++;
                                            rangeList [rangeListCount] = counter3, rangeListCount++;
                                            rangeList [rangeListCount] = rangeNoHold+differenceInt, rangeListCount++;
                                            
                                            difference2 = difference;
                                            rangeNoHold = rangeNoHold+differenceInt;
                                            timeHold2 = counter3;
                                        }
                                        else difference2 = difference2+difference;
                                    }
                                }
                                
                                rangeList [rangeListCount] = liveTimeList [counter2], rangeListCount++;
                                
                                if (endType == 1) rangeList [rangeListCount] = horizontalList2 [counter1*7+4]+1, rangeListCount++;
                                else rangeList [rangeListCount] = horizontalList2 [counter1*7+4], rangeListCount++;
                                
                                rangeList [rangeListCount] = rangeNo, rangeListCount++;
                            }
                            else{
                                
                                difference = (rangeNo-rangeNoHold)/(double)(liveTimeList [counter2]-timeHold);
                                
                                if (liveTimeList [counter2]-timeHold < 5){
                                    rangeList [rangeListCount] = horizontalList2 [counter1*7+3], rangeListCount++;
                                    rangeList [rangeListCount] = liveTimeList [counter2], rangeListCount++;
                                    rangeList [rangeListCount] = rangeNo, rangeListCount++;
                                }
                                else{
                                    
                                    difference2 = difference;
                                    timeHold2 = timeHold;
                                    
                                    for (int counter3 = timeHold+1; counter3 <= liveTimeList [counter2]; counter3++){
                                        if (counter3 == liveTimeList [counter2]){
                                            rangeList [rangeListCount] = timeHold2, rangeListCount++;
                                            rangeList [rangeListCount] = counter3, rangeListCount++;
                                            rangeList [rangeListCount] = rangeNo, rangeListCount++;
                                        }
                                        else if (difference2 >= 1){
                                            differenceInt = (int)difference2;
                                            
                                            rangeList [rangeListCount] = timeHold2, rangeListCount++;
                                            rangeList [rangeListCount] = counter3, rangeListCount++;
                                            rangeList [rangeListCount] = rangeNoHold+differenceInt, rangeListCount++;
                                            
                                            difference2 = difference;
                                            rangeNoHold = rangeNoHold+differenceInt;
                                            timeHold2 = counter3;
                                        }
                                        else difference2 = difference2+difference;
                                    }
                                }
                                
                                rangeNoHold = rangeNo;
                                timeHold = liveTimeList [counter2];
                            }
                        }
                        
                        for (int counter2 = 0; counter2 < rangeListCount/3; counter2++){
                            [[NSColor colorWithCalibratedRed:arrayColorRange [(int)(rangeList [counter2*3+2])*3] green:arrayColorRange [(int)(rangeList [counter2*3+2])*3+1] blue:arrayColorRange [(int)(rangeList [counter2*3+2])*3+2] alpha:1] set];
                            
                            positionAA.x = 40+rangeList [counter2*3]*horizontalIncrement;
                            positionAA.y = 52+increment+counter1*increment;
                            positionBB.x = 40+rangeList [counter2*3+1]*horizontalIncrement;
                            positionBB.y = 52+increment+counter1*increment;
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                    }
                    else{
                        
                        positionAA.x = 40+horizontalList2 [counter1*7+3]*horizontalIncrement;
                        positionAA.y = 52+increment+counter1*increment;
                        
                        if (endType == 1) positionBB.x = 40+(horizontalList2 [counter1*7+4]+1)*horizontalIncrement;
                        else positionBB.x = 40+horizontalList2 [counter1*7+4]*horizontalIncrement;
                        
                        positionBB.y = 52+increment+counter1*increment;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    }
                }
                else if (drawingOptionHold == 2){
                    if (lineageDisplayOption == 0){
                        if (averageTotalFlag == 0) liveValueGet = (int)horizontalLineListValue [counter1*2];
                        else liveValueGet = (int)horizontalLineListValue [counter1*2+1];
                        
                        if (averageTotalFlag == 0){
                            rangeDivision = (rangeLiveAverageHigh-rangeLiveAverageLow)/(double)25;
                            
                            if (liveValueGet <= rangeLiveAverageLow+rangeDivision) rangeNo = 1;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*2) rangeNo = 2;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*3) rangeNo = 3;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*4) rangeNo = 4;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*5) rangeNo = 5;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*6) rangeNo = 6;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*7) rangeNo = 7;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*8) rangeNo = 8;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*9) rangeNo = 9;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*10) rangeNo = 10;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*11) rangeNo = 11;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*12) rangeNo = 12;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*13) rangeNo = 13;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*14) rangeNo = 14;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*15) rangeNo = 15;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*16) rangeNo = 16;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*17) rangeNo = 17;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*18) rangeNo = 18;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*19) rangeNo = 19;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*20) rangeNo = 20;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*21) rangeNo = 21;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*22) rangeNo = 22;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*23) rangeNo = 23;
                            else rangeNo = 24;
                            
                            if (liveValueGet == -1) rangeNo = 105/3+1;
                            
                            [[NSColor colorWithCalibratedRed:arrayColorRange [(rangeNo-1)*3] green:arrayColorRange [(rangeNo-1)*3+1] blue:arrayColorRange [(rangeNo-1)*3+2] alpha:1] set];
                            
                            positionAA.x = 40+horizontalList2 [counter1*7+3]*horizontalIncrement;
                            positionAA.y = 52+increment+counter1*increment;
                            
                            if (endType == 1) positionBB.x = 40+(horizontalList2 [counter1*7+4]+1)*horizontalIncrement;
                            else positionBB.x = 40+horizontalList2 [counter1*7+4]*horizontalIncrement;
                            
                            positionBB.y = 52+increment+counter1*increment;
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                        else{
                            
                            rangeDivision = (rangeLiveTotalHigh-rangeLiveTotalLow)/(double)25;
                            
                            if (liveValueGet <= rangeLiveTotalLow+rangeDivision) rangeNo = 1;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*2) rangeNo = 2;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*3) rangeNo = 3;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*4) rangeNo = 4;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*5) rangeNo = 5;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*6) rangeNo = 6;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*7) rangeNo = 7;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*8) rangeNo = 8;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*9) rangeNo = 9;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*10) rangeNo = 10;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*11) rangeNo = 11;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*12) rangeNo = 12;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*13) rangeNo = 13;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*14) rangeNo = 14;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*15) rangeNo = 15;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*16) rangeNo = 16;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*17) rangeNo = 17;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*18) rangeNo = 18;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*19) rangeNo = 19;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*20) rangeNo = 20;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*21) rangeNo = 21;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*22) rangeNo = 22;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*23) rangeNo = 23;
                            else rangeNo = 24;
                            
                            if (liveValueGet == -1) rangeNo = 105/3+1;
                            
                            [[NSColor colorWithCalibratedRed:arrayColorRange [(rangeNo-1)*3] green:arrayColorRange [(rangeNo-1)*3+1] blue:arrayColorRange [(rangeNo-1)*3+2] alpha:1] set];
                            
                            positionAA.x = 40+horizontalList2 [counter1*7+3]*horizontalIncrement;
                            positionAA.y = 52+increment+counter1*increment;
                            
                            if (endType == 1) positionBB.x = 40+(horizontalList2 [counter1*7+4]+1)*horizontalIncrement;
                            else positionBB.x = 40+horizontalList2 [counter1*7+4]*horizontalIncrement;
                            
                            positionBB.y = 52+increment+counter1*increment;
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                    }
                    else{
                        
                        if (horizontalLineListValue [counter1*2] == -1 || horizontalLineListValue [counter1*2] == -100) rangeNo = 105;
                        else rangeNo = (int)(horizontalLineListValue [counter1*2]);
                        
                        [[NSColor colorWithCalibratedRed:arrayColorRange [rangeNo] green:arrayColorRange [rangeNo+1] blue:arrayColorRange [rangeNo+2] alpha:1] set];
                        
                        positionAA.x = 40+horizontalList2 [counter1*7+3]*horizontalIncrement;
                        positionAA.y = 52+increment+counter1*increment;
                        
                        if (endType == 1) positionBB.x = 40+(horizontalList2 [counter1*7+4]+1)*horizontalIncrement;
                        else positionBB.x = 40+horizontalList2 [counter1*7+4]*horizontalIncrement;
                        
                        positionBB.y = 52+increment+counter1*increment;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    }
                }
                else if (drawingOptionHold == 4){
                    if (lineageDisplayOption == 0){
                        if (averageTotalFlag == 0) liveValueGet = (int)horizontalLineListValue [counter1*2];
                        else liveValueGet = (int)horizontalLineListValue [counter1*2+1];
                        
                        if (averageTotalFlag == 0){
                            rangeDivision = (rangeAverageHigh-rangeAverageLow)/(double)25;
                            
                            if (liveValueGet <= rangeAverageLow+rangeDivision) rangeNo = 1;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*2) rangeNo = 2;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*3) rangeNo = 3;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*4) rangeNo = 4;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*5) rangeNo = 5;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*6) rangeNo = 6;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*7) rangeNo = 7;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*8) rangeNo = 8;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*9) rangeNo = 9;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*10) rangeNo = 10;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*11) rangeNo = 11;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*12) rangeNo = 12;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*13) rangeNo = 13;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*14) rangeNo = 14;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*15) rangeNo = 15;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*16) rangeNo = 16;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*17) rangeNo = 17;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*18) rangeNo = 18;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*19) rangeNo = 19;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*20) rangeNo = 20;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*21) rangeNo = 21;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*22) rangeNo = 22;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*23) rangeNo = 23;
                            else rangeNo = 24;
                            
                            if (liveValueGet == -1) rangeNo = 105/3+1;
                            
                            [[NSColor colorWithCalibratedRed:arrayColorRange [(rangeNo-1)*3] green:arrayColorRange [(rangeNo-1)*3+1] blue:arrayColorRange [(rangeNo-1)*3+2] alpha:1] set];
                            
                            positionAA.x = 40+horizontalList2 [counter1*7+3]*horizontalIncrement;
                            positionAA.y = 52+increment+counter1*increment;
                            
                            if (endType == 1) positionBB.x = 40+(horizontalList2 [counter1*7+4]+1)*horizontalIncrement;
                            else positionBB.x = 40+horizontalList2 [counter1*7+4]*horizontalIncrement;
                            
                            positionBB.y = 52+increment+counter1*increment;
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                        else{
                            
                            rangeDivision = (rangeTotalHigh-rangeTotalLow)/(double)25;
                            
                            if (liveValueGet < rangeLiveTotalLow+rangeDivision) rangeNo = 1;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*2) rangeNo = 2;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*3) rangeNo = 3;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*4) rangeNo = 4;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*5) rangeNo = 5;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*6) rangeNo = 6;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*7) rangeNo = 7;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*8) rangeNo = 8;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*9) rangeNo = 9;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*10) rangeNo = 10;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*11) rangeNo = 11;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*12) rangeNo = 12;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*13) rangeNo = 13;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*14) rangeNo = 14;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*15) rangeNo = 15;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*16) rangeNo = 16;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*17) rangeNo = 17;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*18) rangeNo = 18;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*19) rangeNo = 19;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*20) rangeNo = 20;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*21) rangeNo = 21;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*22) rangeNo = 22;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*23) rangeNo = 23;
                            else rangeNo = 24;
                            
                            if (liveValueGet == -1) rangeNo = 105/3+1;
                            
                            [[NSColor colorWithCalibratedRed:arrayColorRange [(rangeNo-1)*3] green:arrayColorRange [(rangeNo-1)*3+1] blue:arrayColorRange [(rangeNo-1)*3+2] alpha:1] set];
                            
                            positionAA.x = 40+horizontalList2 [counter1*7+3]*horizontalIncrement;
                            positionAA.y = 52+increment+counter1*increment;
                            
                            if (endType == 1) positionBB.x = 40+(horizontalList2 [counter1*7+4]+1)*horizontalIncrement;
                            else positionBB.x = 40+horizontalList2 [counter1*7+4]*horizontalIncrement;
                            
                            positionBB.y = 52+increment+counter1*increment;
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                    }
                    else{
                        
                        if (horizontalLineListValue [counter1*2] == -1 || horizontalLineListValue [counter1*2] == -100) rangeNo = 105;
                        else rangeNo = (int)(horizontalLineListValue [counter1*2]);
                        
                        [[NSColor colorWithCalibratedRed:arrayColorRange [rangeNo] green:arrayColorRange [rangeNo+1] blue:arrayColorRange [rangeNo+2] alpha:1] set];
                        
                        positionAA.x = 40+horizontalList2 [counter1*7+3]*horizontalIncrement;
                        positionAA.y = 52+increment+counter1*increment;
                        
                        if (endType == 1) positionBB.x = 40+(horizontalList2 [counter1*7+4]+1)*horizontalIncrement;
                        else positionBB.x = 40+horizontalList2 [counter1*7+4]*horizontalIncrement;
                        
                        positionBB.y = 52+increment+counter1*increment;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    }
                }
                
                for (int counter2 = 0; counter2 < eventListCount2/5; counter2++){
                    if (eventList2 [counter2*5+4] == counter1){
                        if (eventList2 [counter2*5+3] == 91 || eventList2 [counter2*5+3] == 92){
                            [[NSColor orangeColor] set];
                            pathCircle = [NSBezierPath bezierPathWithOvalInRect:NSMakeRect(40+eventList2 [counter2*5+2]*horizontalIncrement-6, 48+increment+counter1*increment, markerSizeSet, markerSizeSet)];
                            
                            [pathCircle fill];
                        }
                        else if (eventList2 [counter2*5+3] == 6){
                            [[NSColor cyanColor] set];
                            pathCircle = [NSBezierPath bezierPathWithOvalInRect:NSMakeRect(40+eventList2 [counter2*5+2]*horizontalIncrement-6, 48+increment+counter1*increment, markerSizeSet, markerSizeSet)];
                            [pathCircle fill];
                        }
                        else if (eventList2 [counter2*5+3] == 7){
                            [[NSColor magentaColor] set];
                            path = [NSBezierPath bezierPathWithRect: NSMakeRect(40+eventList2 [counter2*5+2]*horizontalIncrement-6, 48+increment+counter1*increment, markerSizeSet, markerSizeSet)];
                            [path fill];
                        }
                        else if (eventList2 [counter2*5+3] == 8){
                            [[NSColor grayColor] set];
                            path = [NSBezierPath bezierPathWithRect: NSMakeRect(40+eventList2 [counter2*5+2]*horizontalIncrement-6, 48+increment+counter1*increment, markerSizeSet, markerSizeSet)];
                            [path fill];
                        }
                        else if (eventList2 [counter2*5+3] == 10){
                            [[NSColor redColor] set];
                            path = [NSBezierPath bezierPathWithRect: NSMakeRect(40+eventList2 [counter2*5+2]*horizontalIncrement-6, 48+increment+counter1*increment, markerSizeSet, markerSizeSet)];
                            [path stroke];
                        }
                        else if (eventList2 [counter2*5+3] == 11){
                            [[NSColor blueColor] set];
                            path = [NSBezierPath bezierPathWithRect: NSMakeRect(40+eventList2 [counter2*5+2]*horizontalIncrement-6, 48+increment+counter1*increment, markerSizeSet, markerSizeSet)];
                            [path fill];
                        }
                    }
                }
                
                if (startType == 0){
                    if (to_string(horizontalList2 [counter1*7+3]).length() == 1) positionShiftA = 7;
                    else if (to_string(horizontalList2 [counter1*7+3]).length() == 2) positionShiftA = 14;
                    else if (to_string(horizontalList2 [counter1*7+3]).length() == 3) positionShiftA = 21;
                    else if (to_string(horizontalList2 [counter1*7+3]).length() == 4) positionShiftA = 28;
                    
                    if ((int)to_string(horizontalList2 [counter1*7+3]).find (".") != -1) horizontalString = to_string(horizontalList2 [counter1*7+3]).substr(0, to_string(horizontalList2 [counter1*7+3]).find ("."));
                    else horizontalString = to_string(horizontalList2 [counter1*7+3]);
                    
                    attrStrA = [[NSAttributedString alloc] initWithString:@(horizontalString.c_str()) attributes:attributesA];
                    pointA.x = 40+horizontalList2 [counter1*7+3]*horizontalIncrement-positionShiftA;
                    pointA.y = 47+increment+counter1*increment;
                    [attrStrA drawAtPoint:pointA];
                }
                else{
                    
                    [attributesA setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
                    
                    if (to_string(horizontalList2 [counter1*7+1]).length() == 1) positionShiftA = 7;
                    else if (to_string(horizontalList2 [counter1*7+1]).length() == 2) positionShiftA = 11;
                    else if (to_string(horizontalList2 [counter1*7+1]).length() == 3) positionShiftA = 17;
                    else if (to_string(horizontalList2 [counter1*7+1]).length() == 4) positionShiftA = 24;
                    
                    if ((int)to_string(horizontalList2 [counter1*7+1]).find (".") != -1) horizontalString = to_string(horizontalList2 [counter1*7+1]).substr(0, to_string(horizontalList2 [counter1*7+1]).find ("."));
                    else horizontalString = to_string(horizontalList2 [counter1*7+1]);
                    
                    attrStrA = [[NSAttributedString alloc] initWithString:@(horizontalString.c_str()) attributes:attributesA];
                    pointA.x = 40+horizontalList2 [counter1*7+3]*horizontalIncrement-positionShiftA;
                    pointA.y = 47+increment+counter1*increment;
                    [attrStrA drawAtPoint:pointA];
                }
                
                [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                
                if (endType == 1){
                    if (to_string(horizontalList2 [counter1*7+4]+1).length() == 1) positionShiftA = 1;
                    else if (to_string(horizontalList2 [counter1*7+4]+1).length() == 2) positionShiftA = 2;
                    else if (to_string(horizontalList2 [counter1*7+4]+1).length() == 3) positionShiftA = 3;
                    else if (to_string(horizontalList2 [counter1*7+4]+1).length() == 4) positionShiftA = 4;
                    
                    if ((int)to_string(horizontalList2 [counter1*7+4]).find (".") != -1) horizontalString = to_string(horizontalList2 [counter1*7+4]).substr(0, to_string(horizontalList2 [counter1*7+4]).find ("."));
                    else horizontalString = to_string(horizontalList2 [counter1*7+4]);
                    
                    if (endNumberFlag == 0){
                        attrStrA = [[NSAttributedString alloc] initWithString:@(horizontalString.c_str()) attributes:attributesA];
                        pointA.x = 40+(horizontalList2 [counter1*7+4]+1)*horizontalIncrement+positionShiftA;
                        pointA.y = 47+increment+counter1*increment;
                        [attrStrA drawAtPoint:pointA];
                    }
                }
                else{
                    
                    if (to_string(horizontalList2 [counter1*7+4]).length() == 1) positionShiftA = 1;
                    else if (to_string(horizontalList2 [counter1*7+4]).length() == 2) positionShiftA = 2;
                    else if (to_string(horizontalList2 [counter1*7+4]).length() == 3) positionShiftA = 3;
                    else if (to_string(horizontalList2 [counter1*7+4]).length() == 4) positionShiftA = 4;
                    
                    if ((int)to_string(horizontalList2 [counter1*7+4]).find (".") != -1) horizontalString = to_string(horizontalList2 [counter1*7+4]).substr(0, to_string(horizontalList2 [counter1*7+4]).find ("."));
                    else horizontalString = to_string(horizontalList2 [counter1*7+4]);
                    
                    if (endNumberFlag == 0){
                        attrStrA = [[NSAttributedString alloc] initWithString:@(horizontalString.c_str()) attributes:attributesA];
                        pointA.x = 40+horizontalList2 [counter1*7+4]*horizontalIncrement+positionShiftA;
                        pointA.y = 47+increment+counter1*increment;
                        [attrStrA drawAtPoint:pointA];
                    }
                }
                
                if ((int)to_string(horizontalList2 [counter1*7+2]).find (".") != -1) horizontalString = to_string(horizontalList2 [counter1*7+2]).substr(0, to_string(horizontalList2 [counter1*7+2]).find ("."));
                else horizontalString = to_string(horizontalList2 [counter1*7+2]);
                
                cellNumberString = "C"+horizontalString;
                
                if (cellNumberFlag == 0){
                    attrStrA = [[NSAttributedString alloc] initWithString:@(cellNumberString.c_str()) attributes:attributesA];
                    pointA.x = 40+((horizontalList2 [counter1*7+4]+horizontalList2 [counter1*7+3])/(double)2)*horizontalIncrement-5;
                    pointA.y = 53+increment+counter1*increment;
                    [attrStrA drawAtPoint:pointA];
                }
            }
            
            //for (int counterA = 0; counterA < lineageFluorescentDataTypeEntryCount; counterA++){
            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageFluorescentDataType [counterA][counterB];
            //    cout<<" arrayLineageFluorescentDataType "<<counterA+1<<endl;
            //}
            
            //for (int counterA = 0; counterA < 1; counterA++){
            //    for (int counterB = 0; counterB < findMainLength; counterB++) cout<<" "<< arrayTableMain [tableCurrentRowHold][counterA+counterB];
            //    cout<<"  arrayTableMain "<<counterA<<endl;
            //}
            
            delete [] horizontalList;
            delete [] horizontalList2;
            delete [] eventList;
            delete [] eventList2;
            delete [] verticalList;
            delete [] liveTimeList;
            delete [] rangeList;
            delete [] cellExtractedInfo;
            delete [] cellNoList;
            delete [] horizontalLineList;
            delete [] horizontalLineListValue;
            delete [] cellExtractedInfoSummary;
        }
    }
    else{
        
        int magFactor = 4;
        
        NSBitmapImageRep *bitmapReps;
        bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:1176*magFactor pixelsHigh:653*magFactor bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:1176*magFactor*4 bitsPerPixel:32];
        
        [NSGraphicsContext saveGraphicsState];
        [NSGraphicsContext setCurrentContext:[NSGraphicsContext graphicsContextWithBitmapImageRep:bitmapReps]];
        
        [[NSColor whiteColor] set];
        
        if (drawingOptionHold == 1 && liveCurrentCHNo == 0) lineageDisplayOption = 0;
        if (drawingOptionHold == 2 && liveCurrentCHNo == 0) lineageDisplayOption = 0;
        else if (drawingOptionHold == 3 && ifCurrentTime == 0) lineageDisplayOption = 0;
        else if (drawingOptionHold == 4 && ifCurrentTime == 0) lineageDisplayOption = 0;
        
        //cout<<liveCurrentCHNo<<" "<<ifCurrentTime<<" "<<ifCurrentCHNo<<" "<<lineageDisplayOption<<" Channel"<<endl;
        
        NSBezierPath *path;
        path = [NSBezierPath bezierPathWithRect: NSMakeRect(0, 0, 1176*magFactor, 653*magFactor)];
        [path fill];
        
        [[NSColor blackColor] set];
        
        [NSBezierPath setDefaultLineWidth:2*magFactor];
        
        path = [NSBezierPath bezierPathWithRect: NSMakeRect(25*magFactor, 40*magFactor, 1100*magFactor, 575*magFactor)];
        [path stroke];
        
        if (initialArraySet == 1){
            //----Horizontal Scale----
            int horizontalTime = arrayTableDetail [tableCurrentRowHold][3];
            string timeInterval = arrayLineageDataType [tableCurrentRowHold][5];
            string timeString = "Time point (x"+timeInterval+" min)";
            NSString *timeNSstring = @(timeString.c_str());
            
            NSFont *font = [NSFont fontWithName:@"Times New Roman" size:12*magFactor];
            NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
            NSAttributedString *attrStrS = [[NSAttributedString alloc] initWithString:timeNSstring attributes:attributes];
            CGFloat size2 = [attrStrS size].width;
            
            NSPoint pointA;
            NSAttributedString *attrStrA;
            NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
            
            [attributesA setObject:[NSFont boldSystemFontOfSize:12*magFactor] forKey:NSFontAttributeName];
            [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            
            attrStrA = [[NSAttributedString alloc] initWithString:timeNSstring attributes:attributesA];
            pointA.x = 550*magFactor-size2/(double)2;
            pointA.y = 6*magFactor;
            [attrStrA drawAtPoint:pointA];
            
            double lengthDivision = horizontalTime/(double)5;
            int lengthDivisionInt = 0;
            
            if (lengthDivision <= 25) lengthDivisionInt = 25;
            else if (lengthDivision > 25 && lengthDivision <= 50) lengthDivisionInt = 50;
            else if (lengthDivision > 50 && lengthDivision <= 100) lengthDivisionInt = 100;
            else if (lengthDivision > 100 && lengthDivision <= 150) lengthDivisionInt = 100;
            else if (lengthDivision > 150 && lengthDivision <= 200) lengthDivisionInt = 200;
            else if (lengthDivision > 200 && lengthDivision <= 250) lengthDivisionInt = 200;
            else if (lengthDivision > 250 && lengthDivision <= 300) lengthDivisionInt = 300;
            else if (lengthDivision > 300 && lengthDivision <= 350) lengthDivisionInt = 300;
            else if (lengthDivision > 350 && lengthDivision <= 400) lengthDivisionInt = 300;
            else if (lengthDivision > 400 && lengthDivision <= 450) lengthDivisionInt = 400;
            else if (lengthDivision > 450 && lengthDivision <= 550) lengthDivisionInt = 500;
            else if (lengthDivision > 550 && lengthDivision <= 650) lengthDivisionInt = 600;
            else if (lengthDivision > 650 && lengthDivision <= 750) lengthDivisionInt = 700;
            else if (lengthDivision > 750 && lengthDivision <= 850) lengthDivisionInt = 800;
            else if (lengthDivision > 850 && lengthDivision <= 950) lengthDivisionInt = 900;
            else if (lengthDivision > 950 && lengthDivision <= 1050) lengthDivisionInt = 1000;
            else if (lengthDivision > 1050 && lengthDivision <= 1150) lengthDivisionInt = 1100;
            else if (lengthDivision > 1150 && lengthDivision <= 1250) lengthDivisionInt = 1200;
            else if (lengthDivision > 1250 && lengthDivision <= 1350) lengthDivisionInt = 1300;
            else if (lengthDivision > 1350 && lengthDivision <= 1450) lengthDivisionInt = 1400;
            else if (lengthDivision > 1450 && lengthDivision <= 1550) lengthDivisionInt = 1500;
            
            double lengthPix = ((1000-40)/(double)horizontalTime)*lengthDivisionInt;
            int numberOfDivision = (int)((1000-40)/(double)lengthPix)+1;
            
            NSPoint positionAA;
            NSPoint positionBB;
            
            int sift = 0;
            
            for (int counter1 = 0; counter1 < numberOfDivision; counter1++){
                positionAA.x = 40*magFactor+lengthPix*counter1*magFactor;
                positionAA.y = 40*magFactor;
                positionBB.x = 40*magFactor+lengthPix*counter1*magFactor;
                positionBB.y = 50*magFactor;
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                
                NSString *timeNSstring2 = @(to_string(counter1*lengthDivisionInt).c_str());
                NSDictionary *attributes2 = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                NSAttributedString *attrStrS2 = [[NSAttributedString alloc] initWithString:timeNSstring2 attributes:attributes2];
                size2 = [attrStrS2 size].width;
                
                if (counter1*lengthDivision == 0) sift = 1;
                else if (counter1*lengthDivision < 1000) sift = 2;
                
                NSPoint pointA2;
                NSAttributedString *attrStrA2;
                NSMutableDictionary *attributesA2 = [NSMutableDictionary dictionary];
                
                [attributesA2 setObject:[NSFont boldSystemFontOfSize:12*magFactor] forKey:NSFontAttributeName];
                [attributesA2 setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                
                attrStrA2 = [[NSAttributedString alloc] initWithString:timeNSstring2 attributes:attributesA];
                pointA2.x = (40+lengthPix*counter1)*magFactor-size2/(double)2-sift*magFactor;
                pointA2.y = 25*magFactor;
                [attrStrA2 drawAtPoint:pointA2];
            }
            
            //----Lineage no----
            double *cellExtractedInfo = new double [lineageExtractCount+50];
            int cellExtractedInfoCount = 0;
            
            double *cellNoList = new double [lineageExtractCount/9*4+50];
            int cellNoListCount = 0;
            
            for (unsigned long counter1 = 0; counter1 < lineageExtractCount/9*3+50; counter1++) cellNoList [counter1] = 0;
            
            for (unsigned long counter1 = 0; counter1 < lineageExtractCount/9; counter1++){
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageExtract [counter1*9], cellExtractedInfoCount++;
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageExtract [counter1*9+1], cellExtractedInfoCount++;
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageExtract [counter1*9+2], cellExtractedInfoCount++;
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageExtract [counter1*9+3], cellExtractedInfoCount++;
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageExtract [counter1*9+4], cellExtractedInfoCount++;
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageExtract [counter1*9+5], cellExtractedInfoCount++;
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageExtract [counter1*9+6], cellExtractedInfoCount++;
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageExtract [counter1*9+7], cellExtractedInfoCount++;
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageExtract [counter1*9+8], cellExtractedInfoCount++;
                
                if (arrayLineageExtract [counter1*9+3] == 1 || arrayLineageExtract [counter1*9+3] == 31 || arrayLineageExtract [counter1*9+3] == 41 || arrayLineageExtract [counter1*9+3] == 51){
                    cellNoList [cellNoListCount] = arrayLineageExtract [counter1*9+5], cellNoListCount++;
                    cellNoList [cellNoListCount] = arrayLineageExtract [counter1*9+4], cellNoListCount++;
                    cellNoList [cellNoListCount] = 0, cellNoListCount++;
                    cellNoList [cellNoListCount] = arrayLineageExtract [counter1*9+6], cellNoListCount++;
                }
            }
            
            //for (int counterA = 0; counterA < cellExtractedInfoCount/8; counterA++){
            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<cellExtractedInfo [counterA*8+counterB];
            //    cout<<" cellExtractedInfo "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < cellNoListCount/4; counterA++){
            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<cellNoList [counterA*4+counterB];
            //    cout<<" cellNoList "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < ifValueExtractCount/13; counterA++){
            //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<ifValueExtract [counterA*13+counterB];
            //    cout<<" ifValueExtract "<<counterA<<endl;
            //}
            
            string extensionNoExtract;
            string extensionNoExtract2;
            string extensionNoExtractB;
            int extensionValueSource = 0;
            
            double extensionValue = 0;
            double parentInfo = 0;
            
            for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                if (cellNoList [counter2*4] <= 299999999 && cellNoList [counter2*4] >= -299999999){
                    cellNoList [counter2*4+2] = cellNoList [counter2*4]*1000000;
                    cellNoList [counter2*4+1] = cellNoList [counter2*4+1]*1000000;
                }
                else if (cellNoList [counter2*4] <= 499999999 && cellNoList [counter2*4] >= 300000000 && cellNoList [counter2*4+1] <= 299999999 && cellNoList [counter2*4+1] >= -299999999){
                    extensionNoExtract = to_string(cellNoList [counter2*4]);
                    
                    if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                    
                    extensionNoExtract = extensionNoExtract.substr(6, 3);
                    extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                    extensionNoExtractB = to_string(extensionValueSource)+"000";
                    extensionNoExtract2 = to_string(cellNoList [counter2*4+1]);
                    
                    if ((int)extensionNoExtract2.find(".") != -1) extensionNoExtract2 = extensionNoExtract2.substr(0, extensionNoExtract2.find("."));
                    
                    extensionNoExtract2 = extensionNoExtract2+"000000";
                    extensionValue = atof(extensionNoExtract2.c_str())+atof(extensionNoExtractB.c_str());
                    
                    cellNoList [counter2*4+2] = extensionValue;
                    cellNoList [counter2*4+1] = cellNoList [counter2*4+1]*1000000;
                }
                else if (cellNoList [counter2*4] >= -499999999 && cellNoList [counter2*4] <= -300000000 && cellNoList [counter2*4+1] <= 299999999 && cellNoList [counter2*4+1] >= -299999999){
                    extensionNoExtract = to_string(cellNoList [counter2*4]);
                    
                    if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                    
                    extensionNoExtract = extensionNoExtract.substr(7, 3);
                    extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                    extensionNoExtractB = to_string(extensionValueSource)+"000";
                    
                    extensionNoExtract2 = to_string(cellNoList [counter2*4+1]);
                    
                    if ((int)extensionNoExtract2.find(".") != -1) extensionNoExtract2 = extensionNoExtract2.substr(0, extensionNoExtract2.find("."));
                    
                    extensionNoExtract2 = extensionNoExtract2+"000000";
                    extensionValue = atof(extensionNoExtract2.c_str())+atof(extensionNoExtractB.c_str());
                    
                    cellNoList [counter2*4+2] = extensionValue;
                    cellNoList [counter2*4+1] = cellNoList [counter2*4+1]*1000000;
                }
            }
            
            for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                if (cellNoList [counter2*4] <= 499999999 && cellNoList [counter2*4] >= 300000000 && cellNoList [counter2*4+1] <= 499999999 && cellNoList [counter2*4+1] >= 300000000){
                    extensionNoExtract = to_string(cellNoList [counter2*4]);
                    
                    if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                    
                    extensionNoExtract = extensionNoExtract.substr(6, 3);
                    parentInfo = 0;
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter3*4] == cellNoList [counter2*4+1]){
                            parentInfo = cellNoList [counter3*4+1];
                            break;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter2*4+1] == cellNoList [counter3*4] && cellNoList [counter3*4+1] > 999999999 && cellNoList [counter2*4+3] == cellNoList [counter3*4+3]){
                            extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                            extensionNoExtractB = to_string(extensionValueSource)+"000";
                            extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                            cellNoList [counter2*4+2] = extensionValue;
                            cellNoList [counter2*4+1] = cellNoList [counter3*4+2];
                            break;
                        }
                    }
                }
                else if (cellNoList [counter2*4] >= -499999999 && cellNoList [counter2*4] <= -300000000 && cellNoList [counter2*4+1] >= -499999999 && cellNoList [counter2*4+1] <= -300000000){
                    extensionNoExtract = to_string(cellNoList [counter2*4]);
                    
                    if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                    
                    extensionNoExtract = extensionNoExtract.substr(7, 3);
                    parentInfo = 0;
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter3*4] == cellNoList [counter2*4+1]){
                            parentInfo = cellNoList [counter3*4+1];
                            break;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter2*4+1] == cellNoList [counter3*4] && cellNoList [counter3*4+1] < -999999999 && cellNoList [counter2*4+3] == cellNoList [counter3*4+3]){
                            extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                            extensionNoExtractB = to_string(extensionValueSource)+"000";
                            extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                            cellNoList [counter2*4+2] = extensionValue;
                            cellNoList [counter2*4+1] = cellNoList [counter3*4+2];
                            break;
                        }
                    }
                }
            }
            
            for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                if (cellNoList [counter2*4] <= 699999999 && cellNoList [counter2*4] >= 500000000 && cellNoList [counter2*4+1] <= 499999999 && cellNoList [counter2*4+1] >= 300000000){
                    extensionNoExtract = to_string(cellNoList [counter2*4]);
                    
                    if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                    
                    extensionNoExtract = extensionNoExtract.substr(6, 3);
                    parentInfo = 0;
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter3*4] == cellNoList [counter2*4+1]){
                            parentInfo = cellNoList [counter3*4+1];
                            break;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter2*4+1] == cellNoList [counter3*4] && cellNoList [counter3*4+1] > 999999999 && cellNoList [counter2*4+3] == cellNoList [counter3*4+3]){
                            extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                            extensionNoExtractB = to_string(extensionValueSource);
                            extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                            cellNoList [counter2*4+2] = extensionValue;
                            cellNoList [counter2*4+1] = cellNoList [counter3*4+2];
                            break;
                        }
                    }
                }
                else if (cellNoList [counter2*4] >= -699999999 && cellNoList [counter2*4] <= -500000000 && cellNoList [counter2*4+1] >= -499999999 && cellNoList [counter2*4+1] <= -300000000){
                    extensionNoExtract = to_string(cellNoList [counter2*4]);
                    
                    if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                    
                    extensionNoExtract = extensionNoExtract.substr(7, 3);
                    parentInfo = 0;
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter3*4] == cellNoList [counter2*4+1]){
                            parentInfo = cellNoList [counter3*4+1];
                            break;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter2*4+1] == cellNoList [counter3*4] && cellNoList [counter3*4+1] < -999999999 && cellNoList [counter2*4+3] == cellNoList [counter3*4+3]){
                            extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                            extensionNoExtractB = to_string(extensionValueSource);
                            extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                            cellNoList [counter2*4+2] = extensionValue;
                            cellNoList [counter2*4+1] = cellNoList [counter3*4+2];
                            break;
                        }
                    }
                }
            }
            
            for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                if (cellNoList [counter2*4] <= 699999999 && cellNoList [counter2*4] >= 500000000 && cellNoList [counter2*4+1] <= 699999999 && cellNoList [counter2*4+1] >= 500000000){
                    extensionNoExtract = to_string(cellNoList [counter2*4]);
                    
                    if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                    
                    extensionNoExtract = extensionNoExtract.substr(6, 3);
                    parentInfo = 0;
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter3*4] == cellNoList [counter2*4+1]){
                            parentInfo = cellNoList [counter3*4+1];
                            break;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter2*4+1] == cellNoList [counter3*4] && cellNoList [counter3*4+1] > 999999999 && cellNoList [counter2*4+3] == cellNoList [counter3*4+3]){
                            extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                            extensionNoExtractB = to_string(extensionValueSource);
                            extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                            cellNoList [counter2*4+2] = extensionValue;
                            cellNoList [counter2*4+1] = cellNoList [counter3*4+2];
                            break;
                        }
                    }
                }
                else if (cellNoList [counter2*4] >= -699999999 && cellNoList [counter2*4] <= -500000000 && cellNoList [counter2*4+1] >= -699999999 && cellNoList [counter2*4+1] <= -500000000){
                    extensionNoExtract = to_string(cellNoList [counter2*4]);
                    
                    if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                    
                    extensionNoExtract = extensionNoExtract.substr(7, 3);
                    parentInfo = 0;
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter3*4] == cellNoList [counter2*4+1]){
                            parentInfo = cellNoList [counter3*4+1];
                            break;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter2*4+1] == cellNoList [counter3*4] && cellNoList [counter3*4+1] < -999999999 && cellNoList [counter2*4+3] == cellNoList [counter3*4+3]){
                            extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                            extensionNoExtractB = to_string(extensionValueSource);
                            extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                            cellNoList [counter2*4+2] = extensionValue;
                            cellNoList [counter2*4+1] = cellNoList [counter3*4+2];
                            break;
                        }
                    }
                }
            }
            
            //for (int counterA = 0; counterA < cellNoListCount/4; counterA++){
            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<to_string(cellNoList [counterA*4+counterB]);
            //    cout<<" cellNoList "<<counterA<<endl;
            //}
            
            int findBoth = 0;
            double cellNoSummary = 0;
            double lingNoSummary = 0;
            double cellNoEntry1 = 0;
            double cellNoEntry2 = 0;
            
            for (int counter1 = 0; counter1 < cellExtractedInfoCount/9; counter1++){
                if (cellNoSummary != cellExtractedInfo [counter1*9+5] || lingNoSummary != cellExtractedInfo [counter1*9+6]){
                    cellNoSummary = cellExtractedInfo [counter1*9+5];
                    lingNoSummary = cellExtractedInfo [counter1*9+6];
                    
                    findBoth = 0;
                    cellNoEntry1 = 0;
                    cellNoEntry2 = 0;
                    
                    for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                        if (cellExtractedInfo [counter1*9+5] == cellNoList [counter2*4] && cellExtractedInfo [counter1*9+6] == cellNoList [counter2*4+3]){
                            cellNoEntry1 = cellNoList [counter2*4+2];
                            findBoth++;
                        }
                        
                        if (cellExtractedInfo [counter1*9+4] == cellNoList [counter2*4] && cellExtractedInfo [counter1*9+6] == cellNoList [counter2*4+3]){
                            cellNoEntry2 = cellNoList [counter2*4+2];
                            findBoth++;
                        }
                        
                        if (findBoth == 2){
                            break;
                        }
                    }
                    
                    cellExtractedInfo [counter1*9+5] = cellNoEntry1;
                    cellExtractedInfo [counter1*9+4] = cellNoEntry2;
                }
                else cellExtractedInfo [counter1*9+5] = cellNoEntry1;
                
                if (cellExtractedInfo [counter1*9+3] == 91 || cellExtractedInfo [counter1*9+3] == 92){
                    for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                        if (cellExtractedInfo [counter1*9+4] == cellNoList [counter2*4]){
                            cellExtractedInfo [counter1*9+4] = cellNoList [counter2*4+2];
                            break;
                        }
                    }
                }
            }
            
            double *cellExtractedInfoSummary = new double [cellExtractedInfoCount+50];
            int cellExtractedInfoSummaryCount = 0;
            
            cellNoSummary = 0;
            lingNoSummary = 0;
            
            for (int counter1 = 0; counter1 < cellExtractedInfoCount/9; counter1++){
                if (cellExtractedInfo [counter1*9+3] != 2){
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+1], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+2], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+3], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+4], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+5], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+6], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+7], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+8], cellExtractedInfoSummaryCount++;
                }
                
                if (cellNoSummary != cellExtractedInfo [counter1*9+5] || lingNoSummary != cellExtractedInfo [counter1*9+6]){
                    cellNoSummary = cellExtractedInfo [counter1*9+5];
                    lingNoSummary = cellExtractedInfo [counter1*9+6];
                    
                    if (counter1 != 0 && cellExtractedInfo [(counter1-1)*9+3] == 2){
                        cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [(counter1-1)*9], cellExtractedInfoSummaryCount++;
                        cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [(counter1-1)*9+1], cellExtractedInfoSummaryCount++;
                        cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [(counter1-1)*9+2], cellExtractedInfoSummaryCount++;
                        cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [(counter1-1)*9+3], cellExtractedInfoSummaryCount++;
                        cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [(counter1-1)*9+4], cellExtractedInfoSummaryCount++;
                        cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [(counter1-1)*9+5], cellExtractedInfoSummaryCount++;
                        cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [(counter1-1)*9+6], cellExtractedInfoSummaryCount++;
                        cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [(counter1-1)*9+7], cellExtractedInfoSummaryCount++;
                        cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [(counter1-1)*9+8], cellExtractedInfoSummaryCount++;
                    }
                }
                
                if (counter1 == cellExtractedInfoCount/9-1 && cellExtractedInfoCount/9-1 != 0){
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+1], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+2], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+3], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+4], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+5], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+6], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+7], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+8], cellExtractedInfoSummaryCount++;
                }
            }
            
            int lineageFuseNo = 0;
            
            for (int counter1 = 0; counter1 < lineageLinkListLength; counter1++){
                if (arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1] != 0){
                    lineageFuseNo++;
                }
            }
            
            if (lineageFuseNo <= 3){
                string lineageNo = to_string(arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength]);
                
                for (int counter1 = 1; counter1 < lineageLinkListLength; counter1++){
                    if (arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1] != 0){
                        lineageNo = lineageNo+", "+to_string(arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1]);
                    }
                }
                
                lineageNo = "Lineage: "+lineageNo;
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(lineageNo.c_str()) attributes:attributesA];
                pointA.x = 30*magFactor;
                pointA.y = 625*magFactor;
                [attrStrA drawAtPoint:pointA];
            }
            else if (lineageFuseNo > 3 && lineageFuseNo <= 6){
                string lineageNo = "Lineage:";
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(lineageNo.c_str()) attributes:attributesA];
                pointA.x = 30*magFactor;
                pointA.y = 625*magFactor;
                [attrStrA drawAtPoint:pointA];
                
                lineageNo = to_string(arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength]);
                
                for (int counter1 = 1; counter1 < 3; counter1++){
                    if (arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1] != 0){
                        lineageNo = lineageNo+", "+to_string(arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1]);
                    }
                }
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(lineageNo.c_str()) attributes:attributesA];
                pointA.x = 85*magFactor;
                pointA.y = 632*magFactor;
                [attrStrA drawAtPoint:pointA];
                
                lineageNo = to_string(arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+3]);
                
                for (int counter1 = 4; counter1 < lineageLinkListLength; counter1++){
                    if (arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1] != 0){
                        lineageNo = lineageNo+", "+to_string(arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1]);
                    }
                }
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(lineageNo.c_str()) attributes:attributesA];
                pointA.x = 85*magFactor;
                pointA.y = 618*magFactor;
                [attrStrA drawAtPoint:pointA];
            }
            else if (lineageFuseNo > 6){
                string lineageNo = "";
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(lineageNo.c_str()) attributes:attributesA];
                pointA.x = 30*magFactor;
                pointA.y = 625*magFactor;
                [attrStrA drawAtPoint:pointA];
                
                lineageNo = to_string(arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength]);
                
                for (int counter1 = 1; counter1 < 3; counter1++){
                    if (arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1] != 0){
                        lineageNo = lineageNo+", "+to_string(arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1]);
                    }
                }
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(lineageNo.c_str()) attributes:attributesA];
                pointA.x = 85*magFactor;
                pointA.y = 632*magFactor;
                [attrStrA drawAtPoint:pointA];
                
                lineageNo = to_string(arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+3]);
                
                for (int counter1 = 4; counter1 < 6; counter1++){
                    if (arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1] != 0){
                        lineageNo = lineageNo+", "+to_string(arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1]);
                    }
                }
                
                lineageNo = lineageNo+"+";
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(lineageNo.c_str()) attributes:attributesA];
                pointA.x = 85*magFactor;
                pointA.y = 618*magFactor;
                [attrStrA drawAtPoint:pointA];
            }
            
            //for (int counterA = 0; counterA <= maxLingNo; counterA++){
            //    if (arrayLineageLinkList [counterA*lineageLinkListLength] != 0){
            //        for (int counterB = 0; counterB < lineageLinkListLength; counterB++) cout<<" "<<arrayLineageLinkList [counterA*lineageLinkListLength+counterB];
            //        cout<<" arrayLineageLinkList "<<counterA<<endl;
            //    }
            //}
            
            //for (int counterA = 0; counterA < cellExtractedInfoCount/9; counterA++){
            //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<to_string(cellExtractedInfo [counterA*9+counterB]);
            //    cout<<" cellExtractedInfo "<<counterA<<endl;
            //}
            
            //----Doubling time Calculation----
            int shortestDoublingTime = 1000000;
            int longestDoublingTime = 0;
            int meanDoublingTime = 0;
            int numberOfDoubling = 0;
            int timeTemp = 0;
            
            for (int counter1 = 0; counter1 < cellExtractedInfoSummaryCount/9; counter1++){
                if (cellExtractedInfoSummary [counter1*9+3] == 31 || cellExtractedInfoSummary [counter1*9+3] == 41 || cellExtractedInfoSummary [counter1*9+3] == 51){
                    timeTemp = (int)(cellExtractedInfoSummary [counter1*9+2]);
                    
                    for (int counter2 = 0; counter2 < cellExtractedInfoSummaryCount/9; counter2++){
                        if (cellExtractedInfoSummary [counter2*9+5] == cellExtractedInfoSummary [counter1*9+5] && cellExtractedInfoSummary [counter2*9+6] == cellExtractedInfoSummary [counter1*9+6] && (cellExtractedInfoSummary [counter2*9+3] == 32 || cellExtractedInfoSummary [counter2*9+3] == 42 || cellExtractedInfoSummary [counter2*9+3] == 52)){
                            if (cellExtractedInfoSummary [counter2*9+2]-timeTemp < shortestDoublingTime) shortestDoublingTime = (int)(cellExtractedInfoSummary [counter2*9+2]-timeTemp);
                            if (cellExtractedInfoSummary [counter2*9+2]-timeTemp > longestDoublingTime) longestDoublingTime = (int)(cellExtractedInfoSummary [counter2*9+2]-timeTemp);
                            meanDoublingTime = meanDoublingTime+(int)(cellExtractedInfoSummary [counter2*9+2]-timeTemp);
                            
                            numberOfDoubling++;
                            break;
                        }
                    }
                }
            }
            
            double shortestDoublingTimeDouble = 0;
            double longestDoublingTimeDouble = 0;
            double meanDoublingTimeDouble = 0;
            
            if (shortestDoublingTime == 1000000) shortestDoublingTime = 0;
            
            if (meanDoublingTime != 0) meanDoublingTimeDouble = meanDoublingTime/(double)numberOfDoubling;
            
            shortestDoublingTimeDouble = shortestDoublingTime*atoi(timeInterval.c_str())/(double)60;
            shortestDoublingTime = (int)(shortestDoublingTimeDouble*100);
            shortestDoublingTimeDouble = shortestDoublingTime/(double)100;
            
            longestDoublingTimeDouble = longestDoublingTime*atoi(timeInterval.c_str())/(double)60;
            longestDoublingTime = (int)(longestDoublingTimeDouble*100);
            longestDoublingTimeDouble = longestDoublingTime/(double)100;
            
            meanDoublingTimeDouble = meanDoublingTimeDouble*atoi(timeInterval.c_str())/(double)60;
            meanDoublingTime = (int)(meanDoublingTimeDouble*100);
            meanDoublingTimeDouble = meanDoublingTime/(double)100;
            
            stringstream extension1;
            extension1 << shortestDoublingTimeDouble;
            string shortestString = extension1.str();
            
            stringstream extension2;
            extension2 << longestDoublingTimeDouble;
            string longestString = extension2.str();
            
            stringstream extension3;
            extension3 << meanDoublingTimeDouble;
            string meanString = extension3.str();
            
            string doubling = "Doub. M: "+meanString;
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(doubling.c_str()) attributes:attributesA];
            pointA.x = 200*magFactor;
            pointA.y = 618*magFactor;
            [attrStrA drawAtPoint:pointA];
            
            if (longestString == "0") doubling = "Doub. T : 0";
            else doubling = "Doub. T : "+shortestString+"-"+longestString;
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(doubling.c_str()) attributes:attributesA];
            pointA.x = 200*magFactor;
            pointA.y = 632*magFactor;
            [attrStrA drawAtPoint:pointA];
            
            //for (int counterA = 0; counterA < ifDataExtractCount/4; counterA++){
            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<ifDataExtract [counterA*4+counterB];
            //    cout<<" ifDataExtract "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < ifTimeExtractCount/2; counterA++){
            //    for (int counterB = 0; counterB < 2; counterB++) cout<<" "<<ifTimeExtract [counterA*2+counterB];
            //    cout<<" iifTimeExtract "<<counterA<<endl;
            //}
            
            //----Lineage display Horizontal set----
            [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            
            int numberOfCellEntry = 0;
            int numberOfEventCount = 0;
            
            for (int counter1 = 0; counter1 < cellExtractedInfoSummaryCount/9; counter1++){
                if (cellExtractedInfoSummary [counter1*9+3] == 1 || cellExtractedInfoSummary [counter1*9+3] == 31 || cellExtractedInfoSummary [counter1*9+3] == 41 || cellExtractedInfoSummary [counter1*9+3] == 51){
                    numberOfCellEntry++;
                    numberOfEventCount++;
                }
                
                if (cellExtractedInfoSummary [counter1*9+3] == 32 || cellExtractedInfoSummary [counter1*9+3] == 42 || cellExtractedInfoSummary [counter1*9+3] == 52 || cellExtractedInfoSummary [counter1*9+3] == 91 || cellExtractedInfoSummary [counter1*9+3] == 6 || cellExtractedInfoSummary [counter1*9+3] == 92 || cellExtractedInfoSummary [counter1*9+3] == 8 || cellExtractedInfoSummary [counter1*9+3] == 10 || cellExtractedInfoSummary[counter1*9+3] == 11 || cellExtractedInfoSummary [counter1*9+3] == 7){
                    numberOfEventCount++;
                }
            }
            
            double *horizontalList = new double [numberOfCellEntry*7+50];
            int horizontalListCount = 0;
            double *eventList = new double [numberOfEventCount*5+50];
            int eventListCount = 0;
            
            int largestTimePoint = 0;
            int findFlag = 0;
            
            for (int counter1 = 0; counter1 < cellExtractedInfoSummaryCount/9; counter1++){
                if (cellExtractedInfoSummary [counter1*9+3] == 1 || cellExtractedInfoSummary [counter1*9+3] == 31 || cellExtractedInfoSummary [counter1*9+3] == 41 || cellExtractedInfoSummary [counter1*9+3] == 51){
                    horizontalList [horizontalListCount] = cellExtractedInfoSummary [counter1*9+5], horizontalListCount++;
                    horizontalList [horizontalListCount] = cellExtractedInfoSummary [counter1*9+6], horizontalListCount++;
                    horizontalList [horizontalListCount] = cellExtractedInfoSummary [counter1*9+8], horizontalListCount++;
                    horizontalList [horizontalListCount] = cellExtractedInfoSummary [counter1*9+2], horizontalListCount++;
                    
                    largestTimePoint = 0;
                    findFlag = 0;
                    
                    for (int counter2 = 0; counter2 < cellExtractedInfoSummaryCount/9; counter2++){
                        if ((cellExtractedInfoSummary [counter2*9+3] == 32 || cellExtractedInfoSummary [counter2*9+3] == 42 || cellExtractedInfoSummary [counter2*9+3] == 52 || cellExtractedInfoSummary [counter2*9+3] == 91 || cellExtractedInfoSummary [counter2*9+3] == 6 || cellExtractedInfoSummary [counter2*9+3] == 92 || cellExtractedInfoSummary [counter2*9+3] == 8 || cellExtractedInfoSummary [counter2*9+3] == 10 || cellExtractedInfoSummary [counter2*9+3] == 11 || cellExtractedInfoSummary [counter2*9+3] == 7) && cellExtractedInfoSummary [counter2*9+5] == cellExtractedInfoSummary [counter1*9+5] && cellExtractedInfoSummary [counter2*9+6] == cellExtractedInfoSummary [counter1*9+6]){
                            eventList [eventListCount] = cellExtractedInfoSummary [counter2*9+5], eventListCount++;
                            eventList [eventListCount] = cellExtractedInfoSummary [counter2*9+6], eventListCount++;
                            eventList [eventListCount] = cellExtractedInfoSummary [counter2*9+2], eventListCount++;
                            eventList [eventListCount] = cellExtractedInfoSummary [counter2*9+3], eventListCount++;
                            eventList [eventListCount] = 0, eventListCount++;
                        }
                    }
                    
                    for (int counter2 = 0; counter2 < cellExtractedInfoSummaryCount/9; counter2++){
                        if ((cellExtractedInfoSummary [counter2*9+3] == 32 || cellExtractedInfoSummary [counter2*9+3] == 42 || cellExtractedInfoSummary [counter2*9+3] == 52 || cellExtractedInfoSummary [counter2*9+3] == 91) && cellExtractedInfoSummary [counter2*9+5] == cellExtractedInfoSummary [counter1*9+5] && cellExtractedInfoSummary [counter2*9+6] == cellExtractedInfoSummary [counter1*9+6]){
                            horizontalList [horizontalListCount] = cellExtractedInfoSummary [counter2*9+2], horizontalListCount++;
                            horizontalList [horizontalListCount] = cellExtractedInfoSummary [counter2*9+3], horizontalListCount++;
                            findFlag = 1;
                            break;
                        }
                        else{
                            
                            if (cellExtractedInfoSummary [counter2*9+5] == cellExtractedInfoSummary [counter1*9+5] && cellExtractedInfoSummary [counter2*9+6] == cellExtractedInfoSummary [counter1*9+6]){
                                if (cellExtractedInfoSummary [counter2*9+2] > largestTimePoint) largestTimePoint = (int)(cellExtractedInfoSummary [counter2*9+2]);
                            }
                        }
                    }
                    
                    if (findFlag == 0){
                        horizontalList [horizontalListCount] = largestTimePoint, horizontalListCount++;
                        horizontalList [horizontalListCount] = 2, horizontalListCount++;
                    }
                    
                    if (cellExtractedInfoSummary [counter1*9+3] == 1) horizontalList [horizontalListCount] = 1, horizontalListCount++;
                    else horizontalList [horizontalListCount] = 0, horizontalListCount++;
                }
            }
            
            //for (int counterA = 0; counterA < horizontalListCount/7; counterA++){
            //    cout<<to_string(horizontalList [counterA*7])<<" "<<horizontalList [counterA*7+1]<<" "<<horizontalList [counterA*7+2]<<" "<<horizontalList [counterA*7+3]<<" "<<horizontalList [counterA*7+4]<<" horizontalList"<<endl;
            //}
            
            //for (int counterA = 0; counterA < eventListCount/5; counterA++){
            //    cout<<counterA<<" "<<to_string(eventList [counterA*5])<<" "<<eventList [counterA*5+1]<<" "<< eventList [counterA*5+2]<<" "<<eventList [counterA*5+3]<<" "<<eventList [counterA*5+4]<<"   eventList"<<endl;
            //}
            
            int terminationFlag = 0;
            int lineageSelect = 0;
            int cellSelectPosition = 0;
            int eventListCount2 = 0;
            double cellSelect = 0;
            
            double *horizontalList2 = new double [numberOfCellEntry*7+50];
            int horizontalListCount2 = 0;
            
            double *eventList2 = new double [numberOfEventCount*6+50];
            
            for (int counter1 = 0; counter1 < numberOfEventCount*6+50; counter1++) eventList2 [counter1] = 0;
            
            int entryOrder = 0;
            
            do{
                
                terminationFlag = 1;
                lineageSelect = 100000;
                
                for (int counter1 = 0; counter1 < horizontalListCount/7; counter1++){
                    if (horizontalList [counter1*7+1] != -1){
                        lineageSelect = (int)(horizontalList [counter1*7+1]);
                        break;
                    }
                }
                
                if (lineageSelect == 100000) terminationFlag = 0;
                else{
                    
                    cellSelect = 999999999999999;
                    cellSelectPosition = 0;
                    
                    for (int counter1 = 0; counter1 < horizontalListCount/7; counter1++){
                        if (horizontalList [counter1*7] != -1 && horizontalList [counter1*7+1] == lineageSelect && horizontalList [counter1*7] < cellSelect){
                            cellSelect = horizontalList [counter1*7];
                            cellSelectPosition = counter1;
                        }
                    }
                    
                    if (cellSelect != 999999999999999){
                        horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7], horizontalListCount2++; //----Cell no---
                        horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+1], horizontalListCount2++; //----Ling no----
                        horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+2], horizontalListCount2++; //----Rev cell no----
                        horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+3], horizontalListCount2++; //----Time start----
                        horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+4], horizontalListCount2++; //----Time end----
                        horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+5], horizontalListCount2++; //----Event last----
                        horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+6], horizontalListCount2++; //----Event I----
                        
                        for (int counter1 = 0; counter1 < eventListCount/5; counter1++){
                            if (eventList [counter1*5] == horizontalList [cellSelectPosition*7] && eventList [counter1*5+1] == horizontalList [cellSelectPosition*7+1]){
                                eventList2 [eventListCount2] = eventList [counter1 *5], eventListCount2++; //----Cell no----
                                eventList2 [eventListCount2] = eventList [counter1 *5+1], eventListCount2++; //----Ling no----
                                eventList2 [eventListCount2] = eventList [counter1 *5+2], eventListCount2++; //----Time----
                                eventList2 [eventListCount2] = eventList [counter1 *5+3], eventListCount2++; //----Event----
                                eventList2 [eventListCount2] = entryOrder, eventListCount2++; //----Entry order----
                            }
                        }
                        
                        horizontalList [cellSelectPosition*7] = -1;
                        horizontalList [cellSelectPosition*7+1] = -1;
                        
                        entryOrder++;
                    }
                }
                
            } while (terminationFlag == 1);
            
            //for (int counterA = 0; counterA < horizontalListCount2/7; counterA++){
            //    cout<<to_string(horizontalList2 [counterA*7])<<" "<<to_string(horizontalList2 [counterA*7+1])<<" "<<horizontalList2 [counterA*7+2]<<" "<<horizontalList2 [counterA*7+3]<<" "<<horizontalList2 [counterA*7+4]<<" horizontalList2"<<endl;
            //}
            
            //----Lineage display Vertical set----
            double *verticalList = new double [numberOfEventCount*9+50];
            int verticalListCount = 0;
            
            double parentCellNo = 0;
            double cellNoLow = 0;
            double cellNoHigh = 0;
            int cellNoLowPosition = 0;
            int cellNoHighPosition = 0;
            int matchFindFlag = 0;
            
            for (int counter1 = 0; counter1 < cellExtractedInfoSummaryCount/9; counter1++){
                if (cellExtractedInfoSummary [counter1*9+3] == 91){
                    matchFindFlag = 0;
                    
                    for (int counter2 = 0; counter2 < verticalListCount/9; counter2++){
                        if ((verticalList [counter2*9] == cellExtractedInfoSummary [counter1*9+5] && verticalList [counter2*9+1] == cellExtractedInfoSummary [counter1*9+6] && verticalList [counter2*9+2] == cellExtractedInfoSummary [counter1*9+2]) || (verticalList [counter2*9+3] == cellExtractedInfoSummary [counter1*9+5] && verticalList [counter2*9+4] == cellExtractedInfoSummary [counter1*9+6] && verticalList [counter2*9+5] == cellExtractedInfoSummary [counter1*9+2])){
                            matchFindFlag = 1;
                        }
                    }
                    
                    if (matchFindFlag == 0){
                        for (int counter2 = 0; counter2 < cellExtractedInfoSummaryCount/9; counter2++){
                            if (cellExtractedInfoSummary [counter2*9+3] == 92 && cellExtractedInfoSummary [counter1*9+4] == cellExtractedInfoSummary [counter2*9+5] && cellExtractedInfoSummary [counter1*9+7] == cellExtractedInfoSummary [counter2*9+6] && cellExtractedInfoSummary [counter2*9+2] == cellExtractedInfoSummary [counter1*9+2]){
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+5], verticalListCount++;
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+6], verticalListCount++;
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+2], verticalListCount++;
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+5], verticalListCount++;
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+6], verticalListCount++;
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+2], verticalListCount++;
                                verticalList [verticalListCount] = 0, verticalListCount++;
                                verticalList [verticalListCount] = 0, verticalListCount++;
                                verticalList [verticalListCount] = 91, verticalListCount++;
                                
                                break;
                            }
                        }
                    }
                }
                else if (cellExtractedInfoSummary [counter1*9+3] == 92){
                    matchFindFlag = 0;
                    
                    for (int counter2 = 0; counter2 < verticalListCount/9; counter2++){
                        if ((verticalList [counter2*9] == cellExtractedInfoSummary [counter1*9+5] && verticalList [counter2*9+1] == cellExtractedInfoSummary [counter1*9+6] && verticalList [counter2*9+2] == cellExtractedInfoSummary [counter1*9+2]) || (verticalList [counter2*9+3] == cellExtractedInfoSummary [counter1*9+5] && verticalList [counter2*9+4] == cellExtractedInfoSummary [counter1*9+6] && verticalList [counter2*9+5] == cellExtractedInfoSummary [counter1*9+2])){
                            matchFindFlag = 1;
                        }
                    }
                    
                    if (matchFindFlag == 0){
                        for (int counter2 = 0; counter2 < cellExtractedInfoSummaryCount/9; counter2++){
                            if (cellExtractedInfoSummary [counter2*9+3] == 91 && cellExtractedInfoSummary [counter1*9+4] == cellExtractedInfoSummary [counter2*9+5] && cellExtractedInfoSummary [counter1*9+7] == cellExtractedInfoSummary [counter2*9+6] && cellExtractedInfoSummary [counter2*9+2] == cellExtractedInfoSummary [counter1*9+2]){
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+5], verticalListCount++;
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+6], verticalListCount++;
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+2], verticalListCount++;
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+5], verticalListCount++;
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+6], verticalListCount++;
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+2], verticalListCount++;
                                verticalList [verticalListCount] = 0, verticalListCount++;
                                verticalList [verticalListCount] = 0, verticalListCount++;
                                verticalList [verticalListCount] = 91, verticalListCount++;
                                
                                break;
                            }
                        }
                    }
                }
                else if (cellExtractedInfoSummary [counter1*9+3] == 31){
                    parentCellNo = cellExtractedInfoSummary [counter1*9+4];
                    matchFindFlag = 0;
                    
                    for (int counter2 = 0; counter2 < verticalListCount/9; counter2++){
                        if ((verticalList [counter2*9] == cellExtractedInfoSummary [counter1*9+5] && verticalList [counter2*9+1] == cellExtractedInfoSummary [counter1*9+6] && verticalList [counter2*9+2] == cellExtractedInfoSummary [counter1*9+2]) || (verticalList [counter2*9+3] == cellExtractedInfoSummary [counter1*9+5] && verticalList [counter2*9+4] == cellExtractedInfoSummary [counter1*9+6] && verticalList [counter2*9+5] == cellExtractedInfoSummary [counter1*9+2])){
                            matchFindFlag = 1;
                        }
                    }
                    
                    if (matchFindFlag == 0){
                        for (int counter2 = 0; counter2 < cellExtractedInfoSummaryCount/9; counter2++){
                            if (cellExtractedInfoSummary [counter2*9+3] == 31 && cellExtractedInfoSummary [counter1*9+6] == cellExtractedInfoSummary [counter2*9+6] && cellExtractedInfoSummary [counter2*9+4] == parentCellNo && cellExtractedInfoSummary [counter2*9+5] != cellExtractedInfoSummary [counter1*9+5] && cellExtractedInfoSummary [counter2*9+2] == cellExtractedInfoSummary [counter1*9+2]){
                                
                                if (cellExtractedInfoSummary [counter2*9+5] > cellExtractedInfoSummary [counter1*9+5]){
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+5], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+6], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+2], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+5], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+6], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+2], verticalListCount++;
                                    verticalList [verticalListCount] = 0, verticalListCount++;
                                    verticalList [verticalListCount] = 0, verticalListCount++;
                                    verticalList [verticalListCount] = 31, verticalListCount++;
                                }
                                else{
                                    
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+5], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+6], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+2], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+5], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+6], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+2], verticalListCount++;
                                    verticalList [verticalListCount] = 0, verticalListCount++;
                                    verticalList [verticalListCount] = 0, verticalListCount++;
                                    verticalList [verticalListCount] = 31, verticalListCount++;
                                }
                                
                                break;
                            }
                        }
                    }
                }
                else if (cellExtractedInfoSummary [counter1*9+3] == 41){
                    parentCellNo = cellExtractedInfoSummary [counter1*9+4];
                    cellNoLow = cellExtractedInfoSummary [counter1*9+5];
                    cellNoHigh = cellExtractedInfoSummary [counter1*9+5];
                    cellNoLowPosition = counter1;
                    cellNoHighPosition = counter1;
                    
                    matchFindFlag = 0;
                    
                    for (int counter2 = 0; counter2 < verticalListCount/9; counter2++){
                        if ((verticalList [counter2*9] == cellExtractedInfoSummary [counter1*9+5] && verticalList [counter2*9+1] == cellExtractedInfoSummary [counter1*9+6] && verticalList [counter2*9+2] == cellExtractedInfoSummary [counter1*9+2]) || (verticalList [counter2*9+3] == cellExtractedInfoSummary [counter1*9+5] && verticalList [counter2*9+4] == cellExtractedInfoSummary [counter1*9+6] && verticalList [counter2*9+5] == cellExtractedInfoSummary [counter1*9+2])){
                            matchFindFlag = 1;
                        }
                    }
                    
                    if (matchFindFlag == 0){
                        for (int counter2 = 0; counter2 < cellExtractedInfoSummaryCount/9; counter2++){
                            if (cellExtractedInfoSummary [counter2*9+3] == 41 && cellExtractedInfoSummary [counter1*9+6] == cellExtractedInfoSummary [counter2*9+6] && cellExtractedInfoSummary [counter2*9+4] == parentCellNo && cellExtractedInfoSummary [counter2*9+5] != cellExtractedInfoSummary [counter1*9+5]){
                                if (cellExtractedInfoSummary [counter2*9+5] > cellNoHigh){
                                    cellNoHigh = cellExtractedInfoSummary [counter2*9+5];
                                    cellNoHighPosition = counter2;
                                }
                                
                                if (cellExtractedInfoSummary [counter2*9+5] < cellNoLow){
                                    cellNoHigh = cellExtractedInfoSummary [counter2*9+5];
                                    cellNoLowPosition = counter2;
                                }
                            }
                        }
                        
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoLowPosition*9+5], verticalListCount++;
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoLowPosition*9+6], verticalListCount++;
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoLowPosition*9+2], verticalListCount++;
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoHighPosition*9+5], verticalListCount++;
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoHighPosition*9+6], verticalListCount++;
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoHighPosition*9+2], verticalListCount++;
                        verticalList [verticalListCount] = 0, verticalListCount++;
                        verticalList [verticalListCount] = 0, verticalListCount++;
                        verticalList [verticalListCount] = 41, verticalListCount++;
                    }
                }
                else if (cellExtractedInfoSummary [counter1*9+3] == 51){
                    parentCellNo = cellExtractedInfoSummary [counter1*9+4];
                    cellNoLow = cellExtractedInfoSummary [counter1*9+5];
                    cellNoHigh = cellExtractedInfoSummary [counter1*9+5];
                    cellNoLowPosition = counter1;
                    cellNoHighPosition = counter1;
                    
                    matchFindFlag = 0;
                    
                    for (int counter2 = 0; counter2 < verticalListCount/9; counter2++){
                        if ((verticalList [counter2*9] == cellExtractedInfoSummary [counter1*9+5] && verticalList [counter2*9+1] == cellExtractedInfoSummary [counter1*9+6] && verticalList [counter2*9+2] == cellExtractedInfoSummary [counter1*9+2]) || (verticalList [counter2*9+3] == cellExtractedInfoSummary [counter1*9+5] && verticalList [counter2*9+4] == cellExtractedInfoSummary [counter1*9+6] && verticalList [counter2*9+5] == cellExtractedInfoSummary [counter1*9+2])){
                            matchFindFlag = 1;
                        }
                    }
                    
                    if (matchFindFlag == 0){
                        for (int counter2 = 0; counter2 < cellExtractedInfoSummaryCount/9; counter2++){
                            if (cellExtractedInfoSummary [counter2*9+3] == 51 && cellExtractedInfoSummary [counter1*9+6] == cellExtractedInfoSummary [counter2*9+6] && cellExtractedInfoSummary [counter2*9+4] == parentCellNo && cellExtractedInfoSummary [counter2*9+5] != cellExtractedInfoSummary [counter1*9+5]){
                                
                                if (cellExtractedInfoSummary [counter2*9+5] > cellNoHigh){
                                    cellNoHigh = cellExtractedInfoSummary [counter2*9+5];
                                    cellNoHighPosition = counter2;
                                }
                                
                                if (cellExtractedInfoSummary [counter2*9+5] < cellNoLow){
                                    cellNoLow = cellExtractedInfoSummary [counter2*9+5];
                                    cellNoLowPosition = counter2;
                                }
                            }
                        }
                        
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoLowPosition*9+5], verticalListCount++; //----Cell no 1----
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoLowPosition*9+6], verticalListCount++; //----Ling no 1----
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoLowPosition*9+2], verticalListCount++; //----Time 1----
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoHighPosition*9+5], verticalListCount++; //----Cell no 2----
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoHighPosition*9+6], verticalListCount++; //----Ling no 2----
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoHighPosition*9+2], verticalListCount++; //----Time 2----
                        verticalList [verticalListCount] = 0, verticalListCount++; //----Cell order 1----
                        verticalList [verticalListCount] = 0, verticalListCount++; //----Cell order 2----
                        verticalList [verticalListCount] = 51, verticalListCount++; //----Event----
                    }
                }
            }
            
            //for (int counterA = 0; counterA < verticalListCount/9; counterA++){
            //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<< to_string(verticalList [counterA*9+counterB]);
            //    cout<<" verticalList "<<counterA<<endl;
            //}
            
            for (int counter1 = 0; counter1 < verticalListCount/9; counter1++){
                for (int counter2 = 0; counter2 < horizontalListCount2/7; counter2++){
                    if (horizontalList2 [counter2*7] == verticalList [counter1*9] && horizontalList2 [counter2*7+1] == verticalList [counter1*9+1]){
                        verticalList [counter1*9+6] = counter2;
                        break;
                    }
                }
                
                for (int counter2 = 0; counter2 < horizontalListCount2/7; counter2++){
                    if (horizontalList2 [counter2*7] == verticalList [counter1*9+3] && horizontalList2 [counter2*7+1] == verticalList [counter1*9+4]){
                        verticalList [counter1*9+7] = counter2;
                        break;
                    }
                }
            }
            
            //for (int counterA = 0; counterA < verticalListCount/9; counterA++){
            //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<< to_string(verticalList [counterA*9+counterB]);
            //    cout<<" verticalList "<<counterA<<endl;
            //}
            
            double increment = (585-52)/(double)(numberOfCellEntry+1);
            double horizontalIncrement = (1000-40)/(double)horizontalTime;
            
            [[NSColor blackColor] set];
            [NSBezierPath setDefaultLineWidth:1*magFactor];
            
            [attributesA setObject:[NSFont boldSystemFontOfSize:9*magFactor] forKey:NSFontAttributeName];
            
            //for (int counterA = 0; counterA < eventListCount2/5; counterA++){
            //    cout<<eventList2 [counterA*5]<<" "<<eventList2 [counterA*5+1]<<" "<< eventList2 [counterA*5+2]<<" "<<eventList2 [counterA*5+3]<<" "<<eventList2 [counterA*5+4]<<"   eventList2"<<endl;
            //}
            
            //----Live vertical line----
            int roundNoGet = 0;
            int ifDataEntryGet = arrayIFTimeLineDataEntryHold [tableCurrentRowHold];
            int positionShiftA = 0;
            
            int *liveTimeList = new int [ifDataEntryGet/9+1];
            int liveTimeListCount = 0;
            
            //for (int counterA = 0; counterA < arrayIFTimeLineDataEntryHold [tableCurrentRowHold]/6; counterA++){
            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayIFTimeLineData [tableCurrentRowHold][counterA*6+counterB];
            //    cout<<" arrayIFTimeLineData "<<counterA<<endl;
            //}
            
            for (int counter1 = 0; counter1 < ifDataEntryGet/9; counter1++){
                if (arrayIFTimeLineData [tableCurrentRowHold][counter1*9+1] == -1){
                    liveTimeList [liveTimeListCount] = arrayIFTimeLineData [tableCurrentRowHold][counter1*9], liveTimeListCount++;
                    
                    if (blueLineFlag == 0){
                        [[NSColor blueColor] set];
                        
                        positionAA.x = 40*magFactor+arrayIFTimeLineData [tableCurrentRowHold][counter1*9]*horizontalIncrement*magFactor;
                        positionAA.y = 40*magFactor;
                        positionBB.x = 40*magFactor+arrayIFTimeLineData [tableCurrentRowHold][counter1*9]*horizontalIncrement*magFactor;
                        positionBB.y = 585*magFactor;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        if (to_string(arrayIFTimeLineData [tableCurrentRowHold][counter1*9]).length() == 1) positionShiftA = 2;
                        else if (to_string(arrayIFTimeLineData [tableCurrentRowHold][counter1*9]).length() == 2) positionShiftA = 4;
                        else if (to_string(arrayIFTimeLineData [tableCurrentRowHold][counter1*9]).length() == 3) positionShiftA = 6;
                        else if (to_string(arrayIFTimeLineData [tableCurrentRowHold][counter1*9]).length() == 4) positionShiftA = 8;
                        
                        attrStrA = [[NSAttributedString alloc] initWithString:@(to_string(arrayIFTimeLineData [tableCurrentRowHold][counter1*9]).c_str()) attributes:attributesA];
                        pointA.x = 40*magFactor+arrayIFTimeLineData [tableCurrentRowHold][counter1*9]*horizontalIncrement*magFactor-positionShiftA*magFactor;
                        pointA.y = 586*magFactor;
                        [attrStrA drawAtPoint:pointA];
                    }
                }
                
                if (arrayIFTimeLineData [tableCurrentRowHold][counter1*9] == ifCurrentTime) roundNoGet = arrayIFTimeLineData [tableCurrentRowHold][counter1*9+1];
            }
            
            if (ifDataExtractCount > 7){
                [[NSColor blackColor] set];
                
                positionAA.x = 40*magFactor+(ifDataExtract [7]-1)*horizontalIncrement*magFactor;
                positionAA.y = 40*magFactor;
                positionBB.x = 40*magFactor+(ifDataExtract [7]-1)*horizontalIncrement*magFactor;
                positionBB.y = 585*magFactor;
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                
                if (to_string(ifDataExtract [7]-1).length() == 1) positionShiftA = 2;
                else if (to_string(ifDataExtract [7]-1).length() == 2) positionShiftA = 5;
                else if (to_string(ifDataExtract [7]-1).length() == 3) positionShiftA = 8;
                else if (to_string(ifDataExtract [7]-1).length() == 4) positionShiftA = 11;
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(to_string(ifDataExtract [7]-1).c_str()) attributes:attributesA];
                pointA.x = 40*magFactor+(ifDataExtract [7]-1)*horizontalIncrement*magFactor-positionShiftA*magFactor;
                pointA.y = 586*magFactor;
                [attrStrA drawAtPoint:pointA];
            }
            
            //----Lineage Display Vertical----
            if (lineWidthFlag == 0) [NSBezierPath setDefaultLineWidth:2*magFactor];
            else if (lineWidthFlag == 1) [NSBezierPath setDefaultLineWidth:1*magFactor];
            else if (lineWidthFlag == 2) [NSBezierPath setDefaultLineWidth:0.5*magFactor];
            else if (lineWidthFlag == 3) [NSBezierPath setDefaultLineWidth:5*magFactor];
            else if (lineWidthFlag == 4) [NSBezierPath setDefaultLineWidth:4*magFactor];
            else if (lineWidthFlag == 5) [NSBezierPath setDefaultLineWidth:3*magFactor];
            
            for (int counter1 = 0; counter1 < verticalListCount/9; counter1++){
                if (verticalList [counter1*9+8] == 91) [[NSColor orangeColor] set];
                else if (verticalList [counter1*9+8] == 31) [[NSColor blackColor] set];
                else if (verticalList [counter1*9+8] == 41) [[NSColor redColor] set];
                else if (verticalList [counter1*9+8] == 51) [[NSColor redColor] set];
                
                positionAA.x = 40*magFactor+verticalList [counter1*9+2]*horizontalIncrement*magFactor;
                positionAA.y = 52*magFactor+increment*magFactor+verticalList [counter1*9+6]*increment*magFactor;
                positionBB.x = 40*magFactor+verticalList [counter1*9+5]*horizontalIncrement*magFactor;
                positionBB.y = 52*magFactor+increment*magFactor+verticalList [counter1*9+7]*increment*magFactor;
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
            }
            
            [attributesA setObject:[NSFont boldSystemFontOfSize:11*magFactor] forKey:NSFontAttributeName];
            [[NSColor blackColor] set];
            
            int findMainLength = arrayTableMainHold [tableCurrentRowHold];
            
            double *horizontalLineList = new double [horizontalListCount2/7*3+50];
            int horizontalLineListCount = 0;
            
            double *horizontalLineListValue = new double [horizontalListCount2/7*2+50];
            int horizontalLineListValueCount = 0;
            
            int cellNoOriginal = 0;
            int rangeNo = 0;
            int rangeAverageLow = 0;
            int rangeAverageHigh = 0;
            int rangeTotalLow = 0;
            int rangeTotalHigh = 0;
            
            if (drawingOptionHold == 3 || drawingOptionHold == 4){
                string ifName = "";
                
                for (int counter1 = 13; counter1 < findMainLength; counter1 = counter1+8){
                    if (atoi(arrayTableMain [tableCurrentRowHold][counter1].c_str()) == roundNoGet){
                        ifName = arrayTableMain [tableCurrentRowHold][counter1+ifCurrentCHNo+1];
                        break;
                    }
                }
                
                string roundExtract;
                
                for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryCount; counter1++){
                    roundExtract = arrayLineageFluorescentDataType [counter1][1];
                    roundExtract = roundExtract.substr(1);
                    
                    if (atoi(arrayLineageFluorescentDataType [counter1][0].c_str()) == tableCurrentRowHold+1 && atoi(roundExtract.c_str()) == roundNoGet && arrayLineageFluorescentDataType [counter1][2] == ifName){
                        rangeTotalLow = atoi(arrayLineageFluorescentDataType [counter1][6].c_str());
                        rangeTotalHigh = atoi(arrayLineageFluorescentDataType [counter1][7].c_str());
                        rangeAverageLow = atoi(arrayLineageFluorescentDataType [counter1][4].c_str());
                        rangeAverageHigh = atoi(arrayLineageFluorescentDataType [counter1][5].c_str());
                        break;
                    }
                }
                
                double *fluorescentEntry = new double [numberOfCellEntry*5+50];
                int fluorescentEntryCount = 0;
                
                for (int counter2 = 0; counter2 < horizontalListCount2/7; counter2++){
                    if (horizontalList2 [counter2*7+3] <= ifCurrentTime && horizontalList2 [counter2*7+4] >= ifCurrentTime){
                        fluorescentEntry [fluorescentEntryCount] = horizontalList2 [counter2*7], fluorescentEntryCount++; //----Cell no----
                        fluorescentEntry [fluorescentEntryCount] = horizontalList2 [counter2*7+1], fluorescentEntryCount++; //----Ling no----
                        fluorescentEntry [fluorescentEntryCount] = 0, fluorescentEntryCount++; //----AV----
                        fluorescentEntry [fluorescentEntryCount] = 0, fluorescentEntryCount++; //----Total----
                        fluorescentEntry [fluorescentEntryCount] = counter2, fluorescentEntryCount++; //----Cell order----
                    }
                }
                
                //for (int counterA = 0; counterA < horizontalListCount2/7; counterA++){
                //    cout<<horizontalList2 [counterA*7]<<" "<<horizontalList2 [counterA*7+1]<<" "<<horizontalList2 [counterA*7+2]<<" "<<horizontalList2 [counterA*7+3]<<" "<<horizontalList2 [counterA*7+4]<<" "<<horizontalList2 [counterA*7+5]<<" "<<horizontalList2 [counterA*7+6]<<"  horizontalList2"<<endl;
                //}
                
                //for (int counterA = 0; counterA < fluorescentEntryCount/5; counterA++){
                //    cout<<fluorescentEntry [counterA*5]<<" "<<fluorescentEntry [counterA*5+1]<<" "<< fluorescentEntry [counterA*5+2]<<" "<<fluorescentEntry [counterA*5+3]<<" "<<fluorescentEntry [counterA*5+4]<<"   fluorescentEntry"<<endl;
                //}
                
                //for (int counterA = 0; counterA < ifEntryCount/13; counterA++){
                //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<arrayIFData [tableCurrentRowHold][counterA*13+counterB];
                //    cout<<" arrayIFData "<<counterA<<endl;
                //}
                
                for (int counter1 = 0; counter1 < fluorescentEntryCount/5; counter1++){
                    cellNoOriginal = 0;
                    
                    for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                        if (fluorescentEntry [counter1*5] == cellNoList [counter2*4+2]){
                            cellNoOriginal = (int)(cellNoList [counter2*4]);
                            break;
                        }
                    }
                    
                    for (int counter2 = 0; counter2 < ifValueExtractCount/22; counter2++){
                        if (cellNoOriginal == ifValueExtract [counter2*22] && (int)(fluorescentEntry [counter1*5+1]) == ifValueExtract [counter2*22+1] && ifCurrentTime == ifValueExtract [counter2*22+2]){
                            if (ifCurrentCHNo == 1){
                                fluorescentEntry [counter1*5+2] = ifValueExtract [counter2*22+5];
                                fluorescentEntry [counter1*5+3] = ifValueExtract [counter2*22+5]*ifValueExtract [counter2*22+6];
                            }
                            else if (ifCurrentCHNo == 2){
                                fluorescentEntry [counter1*5+2] = ifValueExtract [counter2*22+8];
                                fluorescentEntry [counter1*5+3] = ifValueExtract [counter2*22+8]*ifValueExtract [counter2*22+9];
                            }
                            else if (ifCurrentCHNo == 3){
                                fluorescentEntry [counter1*5+2] = ifValueExtract [counter2*22+11];
                                fluorescentEntry [counter1*5+3] = ifValueExtract [counter2*22+11]*ifValueExtract [counter2*22+12];
                            }
                            else if (ifCurrentCHNo == 4){
                                fluorescentEntry [counter1*5+2] = ifValueExtract [counter2*22+14];
                                fluorescentEntry [counter1*5+3] = ifValueExtract [counter2*22+14]*ifValueExtract [counter2*22+15];
                            }
                            else if (ifCurrentCHNo == 5){
                                fluorescentEntry [counter1*5+2] = ifValueExtract [counter2*22+17];
                                fluorescentEntry [counter1*5+3] = ifValueExtract [counter2*22+17]*ifValueExtract [counter2*22+18];
                            }
                            else if (ifCurrentCHNo == 6){
                                fluorescentEntry [counter1*5+2] = ifValueExtract [counter2*22+20];
                                fluorescentEntry [counter1*5+3] = ifValueExtract [counter2*22+20]*ifValueExtract [counter2*22+21];
                            }
                            
                            break;
                        }
                    }
                }
                
                if (averageTotalFlag == 0){
                    double rangeDivisionAverage = (rangeAverageHigh-rangeAverageLow)/(double)25;
                    
                    for (int counter1 = 0; counter1 < fluorescentEntryCount/5; counter1++){
                        if (fluorescentEntry [counter1*5+2] <= rangeAverageLow+rangeDivisionAverage) rangeNo = 1;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*2) rangeNo = 2;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*3) rangeNo = 3;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*4) rangeNo = 4;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*5) rangeNo = 5;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*6) rangeNo = 6;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*7) rangeNo = 7;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*8) rangeNo = 8;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*9) rangeNo = 9;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*10) rangeNo = 10;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*11) rangeNo = 11;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*12) rangeNo = 12;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*13) rangeNo = 13;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*14) rangeNo = 14;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*15) rangeNo = 15;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*16) rangeNo = 16;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*17) rangeNo = 17;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*18) rangeNo = 18;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*19) rangeNo = 19;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*20) rangeNo = 20;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*21) rangeNo = 21;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*22) rangeNo = 22;
                        else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*23) rangeNo = 23;
                        else rangeNo = 24;
                        
                        [[NSColor colorWithCalibratedRed:arrayColorRange [(rangeNo-1)*3] green:arrayColorRange [(rangeNo-1)*3+1] blue:arrayColorRange [(rangeNo-1)*3+2] alpha:1] set];
                        
                        positionAA.x = 1065*magFactor;
                        positionAA.y = 52*magFactor+increment*magFactor+fluorescentEntry [counter1*5+4]*increment*magFactor;
                        positionBB.x = 1075*magFactor;
                        positionBB.y = 52*magFactor+increment*magFactor+fluorescentEntry [counter1*5+4]*increment*magFactor;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    }
                }
                else{
                    
                    double rangeDivisionTotal = (rangeTotalHigh-rangeTotalLow)/(double)25;
                    
                    for (int counter1 = 0; counter1 < fluorescentEntryCount/5; counter1++){
                        if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal) rangeNo = 1;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*2) rangeNo = 2;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*3) rangeNo = 3;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*4) rangeNo = 4;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*5) rangeNo = 5;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*6) rangeNo = 6;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*7) rangeNo = 7;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*8) rangeNo = 8;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*9) rangeNo = 9;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*10) rangeNo = 10;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*11) rangeNo = 11;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*12) rangeNo = 12;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*13) rangeNo = 13;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*14) rangeNo = 14;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*15) rangeNo = 15;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*16) rangeNo = 16;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*17) rangeNo = 17;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*18) rangeNo = 18;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*19) rangeNo = 19;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*20) rangeNo = 20;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*21) rangeNo = 21;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*22) rangeNo = 22;
                        else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*23) rangeNo = 23;
                        else rangeNo = 24;
                        
                        [[NSColor colorWithCalibratedRed:arrayColorRange [(rangeNo-1)*3] green:arrayColorRange [(rangeNo-1)*3+1] blue:arrayColorRange [(rangeNo-1)*3+2] alpha:1] set];
                        
                        positionAA.x = 1065*magFactor;
                        positionAA.y = 52*magFactor+increment*magFactor+fluorescentEntry [counter1*5+4]*increment*magFactor;
                        positionBB.x = 1075*magFactor;
                        positionBB.y = 52*magFactor+increment*magFactor+fluorescentEntry [counter1*5+4]*increment*magFactor;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    }
                }
                
                if (drawingOptionHold == 4){
                    for (int counter2 = 0; counter2 < horizontalListCount2/7*3+50; counter2++){
                        horizontalLineList [counter2] = 0;
                    }
                    
                    for (int counter2 = 0; counter2 < horizontalListCount2/7*2+50; counter2++){
                        horizontalLineListValue [counter2] = 0;
                    }
                    
                    horizontalLineListCount = 0;
                    horizontalLineListValueCount = 0;
                    
                    for (int counter2 = 0; counter2 < horizontalListCount2/7; counter2++){
                        horizontalLineList [horizontalLineListCount] = horizontalList2 [counter2*7], horizontalLineListCount++;
                        horizontalLineList [horizontalLineListCount] = horizontalList2 [counter2*7+1], horizontalLineListCount++;
                        horizontalLineList [horizontalLineListCount] = 0, horizontalLineListCount++;
                        
                        horizontalLineListValue [horizontalLineListValueCount] = -1, horizontalLineListValueCount++;
                        horizontalLineListValue [horizontalLineListValueCount] = -1, horizontalLineListValueCount++;
                    }
                    
                    //for (int counterA = 0; counterA < horizontalListCount2/7; counterA++){
                    //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<< horizontalList2 [counterA*7+counterB];
                    //    cout<<" horizontalList2 "<<counterA<<" "<<counter1<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < horizontalLineListCount/3; counterA++){
                    //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<< to_string(horizontalLineList [counterA*3+counterB]);
                    //    cout<<" horizontalLineList "<<counterA<<" "<<endl;
                    //}
                    
                    //----Enter fluorescent value at the end point----
                    if (lineageDisplayOption == 0){
                        for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                            for (int counter3 = 0; counter3 < fluorescentEntryCount/5; counter3++){
                                if (horizontalLineList [counter2*3] == fluorescentEntry [counter3*5] && horizontalLineList [counter2*3+1] == fluorescentEntry [counter3*5+1]){
                                    horizontalLineList [counter2*3+2] = 1;
                                    horizontalLineListValue [counter2*2] = fluorescentEntry [counter3*5+2];
                                    horizontalLineListValue [counter2*2+1] = fluorescentEntry [counter3*5+3];
                                    
                                    break;
                                }
                            }
                        }
                    }
                    else{
                        
                        for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                            for (int counter3 = 0; counter3 < fluorescentEntryCount/5; counter3++){
                                if (horizontalLineList [counter2*3] == fluorescentEntry [counter3*5] && horizontalLineList [counter2*3+1] == fluorescentEntry [counter3*5+1]){
                                    horizontalLineList [counter2*3+2] = 1;
                                    
                                    if (fluorescentEntry [counter3*5+2] == 0) horizontalLineListValue [counter2*2] = lowXlow;
                                    else if (fluorescentEntry [counter3*5+2] == 100) horizontalLineListValue [counter2*2] = highXhigh;
                                    else horizontalLineListValue [counter2*2] = -100;
                                    
                                    horizontalLineListValue [counter2*2+1] = fluorescentEntry [counter3*5+3];
                                    
                                    break;
                                }
                            }
                        }
                    }
                    
                    //----Set dummy value at CD, OF FU lines----
                    if (unknownOptionHold == 1 && lineageDisplayOption == 0){
                        for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                            if (horizontalLineList [counter2*3+2] == 0){
                                cellNoOriginal = 0;
                                
                                for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                                    if (horizontalLineList [counter2*3] == cellNoList [counter3*4+2]){
                                        cellNoOriginal = (int)(cellNoList [counter3*4]);
                                        break;
                                    }
                                }
                                
                                for (unsigned long counter3 = 0; counter3 < lineageExtractCount/9; counter3++){
                                    if (arrayLineageExtract [counter3*9+5] == cellNoOriginal && (arrayLineageExtract [counter3*9+3] == 7 || arrayLineageExtract [counter3*9+3] == 8 || arrayLineageExtract [counter3*9+3] == 91)){
                                        horizontalLineList [counter2*3+2] = 1;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    else if (lineageDisplayOption == 1){
                        for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                            if (horizontalLineList [counter2*3+2] == 0){
                                cellNoOriginal = 0;
                                
                                for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                                    if (horizontalLineList [counter2*3] == cellNoList [counter3*4+2]){
                                        cellNoOriginal = (int)(cellNoList [counter3*4]);
                                        break;
                                    }
                                }
                                
                                for (unsigned long counter3 = 0; counter3 < lineageExtractCount/9; counter3++){
                                    if (arrayLineageExtract [counter3*9+5] == cellNoOriginal && (arrayLineageExtract [counter3*9+3] == 7 || arrayLineageExtract [counter3*9+3] == 8 || arrayLineageExtract [counter3*9+3] == 91)){
                                        horizontalLineList [counter2*3+2] = 1;
                                        
                                        horizontalLineListValue [counter2*2] = -100;
                                        horizontalLineListValue [counter2*2+1] = 100;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < horizontalLineListCount/3; counterA++){
                    //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<< horizontalLineList [counterA*3+counterB];
                    //    cout<<" horizontalLineList "<<counterA<<" "<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < horizontalLineListCount/3; counterA++){
                    //    for (int counterB = 0; counterB < 2; counterB++) cout<<" "<< horizontalLineListValue [counterA*2+counterB];
                    //    cout<<" horizontalLineListValue "<<counterA<<" "<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < lineageExtractCount/9; counterA++){
                    //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayLineageExtract [counterA*9+counterB];
                    //    cout<<" arrayLineageExtract "<<counterA<<endl;
                    //}
                    
                    int expandLineage = 0;
                    int skipCount = 0;
                    int skipEntryCount = 0;
                    int divisionStatus = 0;
                    int dataEntryCheck = 0;
                    int endStatusCheck = 0;
                    int endStatusCheck2 = 0;
                    int colorCountTemp = 0;
                    int checkStart = 0;
                    int checkNoCheck = 0;
                    
                    double expandCell = 0;
                    double parentDoubleCell = 0;
                    double cellNoOriginal2 = 0;
                    double sumTotal = 0;
                    double sumAverage = 0;
                    double colorDataCount = 0;
                    
                    double *cellNoListTemp = new double [10];
                    int cellNoListTempCount = 0;
                    
                    int *endStatusHold = new int [20];
                    int endStatusHoldCount = 0;
                    
                    do{
                        
                        terminationFlag = 1;
                        expandLineage = 0;
                        skipEntryCount = skipCount;
                        
                        for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                            if (horizontalLineList [counter2*3+2] == 1 && skipEntryCount == 0){
                                expandLineage = (int)(horizontalLineList [counter2*3+1]);
                                expandCell = horizontalLineList [counter2*3];
                                break;
                            }
                            else if (horizontalLineList [counter2*3+2] == 1 && skipEntryCount >= 0) skipEntryCount--;
                        }
                        
                        if (expandLineage != 0){
                            parentCellNo = -1;
                            cellNoOriginal = 0;
                            
                            for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                                if (expandCell == cellNoList [counter2*4+2]){
                                    cellNoOriginal = (int)(cellNoList [counter2*4]);
                                    break;
                                }
                            }
                            
                            for (unsigned long counter2 = 0; counter2 < lineageExtractCount/9; counter2++){
                                if (arrayLineageExtract [counter2*9+3] == 31 || arrayLineageExtract [counter2*9+3] == 41 || arrayLineageExtract [counter2*9+3] == 51){
                                    if (arrayLineageExtract [counter2*9+6] == expandLineage && arrayLineageExtract [counter2*9+5] == cellNoOriginal){
                                        parentCellNo = arrayLineageExtract [counter2*9+4];
                                        break;
                                    }
                                }
                            }
                            
                            parentDoubleCell = 0;
                            
                            for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                                if (parentCellNo == cellNoList [counter2*4]){
                                    parentDoubleCell = cellNoList [counter2*4+2];
                                    break;
                                }
                            }
                            
                            if (parentCellNo != -1){
                                cellNoListTempCount = 0;
                                endStatusHoldCount = 0;
                                divisionStatus = 0;
                                
                                for (unsigned long counter2 = 0; counter2 < lineageExtractCount/9; counter2++){
                                    if (arrayLineageExtract [counter2*9+3] == 31 || arrayLineageExtract [counter2*9+3] == 41 || arrayLineageExtract [counter2*9+3] == 51){
                                        if (arrayLineageExtract [counter2*9+6] == expandLineage && arrayLineageExtract [counter2*9+4] == parentCellNo){
                                            cellNoOriginal2 = 0;
                                            
                                            for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                                                if (arrayLineageExtract [counter2*9+5] == cellNoList [counter3*4]){
                                                    cellNoOriginal2 = cellNoList [counter3*4+2];
                                                    break;
                                                }
                                            }
                                            
                                            if (arrayLineageExtract [counter2*9+3] == 31) divisionStatus = 2;
                                            else if (arrayLineageExtract [counter2*9+3] == 41) divisionStatus = 3;
                                            else if (arrayLineageExtract [counter2*9+3] == 51) divisionStatus = 4;
                                            
                                            cellNoListTemp [cellNoListTempCount] = cellNoOriginal2, cellNoListTempCount++;
                                            
                                            endStatusHold [endStatusHoldCount] = 0, endStatusHoldCount++;
                                            endStatusHold [endStatusHoldCount] = -1, endStatusHoldCount++;
                                            
                                            //----Check end status, enter 1 when end is CD, OF, FU----
                                            for (unsigned long counter3 = 0; counter3 < lineageExtractCount/9; counter3++){
                                                if (arrayLineageExtract [counter3*9+6] == expandLineage && arrayLineageExtract [counter3*9+5] == arrayLineageExtract [counter2*9+5] && (arrayLineageExtract [counter3*9+3] == 7 || arrayLineageExtract [counter3*9+3] == 8 || arrayLineageExtract [counter3*9+3] == 91)){
                                                    endStatusHold [endStatusHoldCount-2] = 1;
                                                    break;
                                                }
                                            }
                                            
                                            checkStart = 0;
                                            checkNoCheck = 0;
                                            
                                            //----Check progeny's end status, enter 1 when end is CD, OF, FU----
                                            for (unsigned long counter3 = 0; counter3 < lineageExtractCount/9; counter3++){
                                                if (arrayLineageExtract [counter3*9+6] == expandLineage && arrayLineageExtract [counter3*9+4] == arrayLineageExtract [counter2*9+5] && arrayLineageExtract [counter3*9+3] != 91 && arrayLineageExtract [counter3*9+4] != 92){
                                                    checkStart = 1;
                                                    checkNoCheck = arrayLineageExtract [counter3*9+5];
                                                }
                                                
                                                if (arrayLineageExtract [counter3*9+6] == expandLineage && arrayLineageExtract [counter3*9+5] == checkNoCheck && checkStart == 1 && (arrayLineageExtract [counter3*9+3] == 7 || arrayLineageExtract [counter3*9+3] == 8 || arrayLineageExtract [counter3*9+3] == 91)){
                                                    if (endStatusHold [endStatusHoldCount-1] == -1) endStatusHold [endStatusHoldCount-1] = 1;
                                                    checkStart = 0;
                                                }
                                                else if (arrayLineageExtract [counter3*9+6] == expandLineage && arrayLineageExtract [counter3*9+5] == checkNoCheck && checkStart == 1 && (arrayLineageExtract [counter3*9+3] == 32 || arrayLineageExtract [counter3*9+3] == 42 || arrayLineageExtract [counter3*9+3] == 52 || arrayLineageExtract [counter3*9+2] == arrayTableDetail [tableCurrentRowHold][3])){
                                                    
                                                    endStatusHold [endStatusHoldCount-1] = 0;
                                                    break;
                                                }
                                            }
                                            
                                            if (endStatusHold [endStatusHoldCount-1] == -1) endStatusHold [endStatusHoldCount-1] = 0;
                                        }
                                    }
                                }
                                
                                endStatusCheck = 0;
                                endStatusCheck2 = 0;
                                
                                for (int counter2 = 0; counter2 < endStatusHoldCount/2; counter2++){
                                    if (endStatusHold [counter2*2] == 1) endStatusCheck = 1;
                                    if (endStatusHold [counter2*2+1] == 1) endStatusCheck2 = 1;
                                }
                                
                                sumTotal = 0;
                                sumAverage = 0;
                                colorDataCount = 0;
                                colorCountTemp = 0;
                                
                                if (lineageDisplayOption == 1) sumAverage = -1;
                                
                                if (lineageDisplayOption == 0){
                                    if (unknownOptionHold == 0){
                                        if (endStatusCheck == 0){
                                            for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                    if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && horizontalLineListValue [counter3*2] != -1 && horizontalLineListValue [counter3*2+1] != -1){
                                                        sumTotal = sumTotal+horizontalLineListValue [counter3*2+1];
                                                        sumAverage = sumAverage+(int)horizontalLineListValue [counter3*2];
                                                        
                                                        horizontalLineList [counter3*3+2] = -1;
                                                        colorDataCount++;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else if (unknownOptionHold == 1){
                                        if (endStatusCheck == 0 && endStatusCheck2 == 0){
                                            for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                    if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && horizontalLineListValue [counter3*2] != -1 && horizontalLineListValue [counter3*2+1] != -1){
                                                        sumTotal = sumTotal+horizontalLineListValue [counter3*2+1];
                                                        sumAverage = sumAverage+(int)horizontalLineListValue [counter3*2];
                                                        
                                                        horizontalLineList [counter3*3+2] = -1;
                                                        colorDataCount++;
                                                    }
                                                }
                                            }
                                        }
                                        else{
                                            
                                            endStatusCheck = 0;
                                            dataEntryCheck = 0;
                                            
                                            for (int counter2 = 0; counter2 < endStatusHoldCount/2; counter2++){
                                                if (endStatusHold [counter2*2] == 0) endStatusCheck = 1;
                                                
                                                for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                    if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && endStatusHold [counter2*2] == 0 && endStatusHold [counter2*2+1] == 0 && horizontalLineListValue [counter3*2] == -1 && horizontalLineListValue [counter3*2+1] == -1){
                                                        dataEntryCheck = 1;
                                                    }
                                                }
                                            }
                                            
                                            if (endStatusCheck == 0){
                                                for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                    for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                        if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2]){
                                                            sumTotal = -2;
                                                            sumAverage = -2;
                                                            
                                                            horizontalLineListValue [counter3*2] = -1;
                                                            horizontalLineListValue [counter3*2+1] = -1;
                                                            horizontalLineList [counter3*3+2] = -1;
                                                            
                                                            colorDataCount++;
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                            else if (dataEntryCheck == 0){
                                                for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                    for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                        if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && horizontalLineListValue [counter3*2] != -1 && horizontalLineListValue [counter3*2+1] != -1){
                                                            sumTotal = sumTotal+horizontalLineListValue [counter3*2+1];
                                                            sumAverage = sumAverage+(int)horizontalLineListValue [counter3*2];
                                                            
                                                            horizontalLineList [counter3*3+2] = -1;
                                                            colorCountTemp++;
                                                            colorDataCount++;
                                                        }
                                                    }
                                                }
                                                
                                                for (int counter2 = 0; counter2 < endStatusHoldCount/2; counter2++){
                                                    if (endStatusHold [counter2*2] == 1 || endStatusHold [counter2*2+1] == 1){
                                                        for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                            if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2]){
                                                                horizontalLineListValue [counter3*2] = (int)(sumAverage/(double)colorCountTemp);
                                                                horizontalLineListValue [counter3*2+1] = sumTotal/(double)colorCountTemp;
                                                                horizontalLineList [counter3*3+2] = -1;
                                                                
                                                                colorDataCount++;
                                                                break;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                else if (lineageDisplayOption == 1){
                                    if (endStatusCheck == 0){
                                        for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                            for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && horizontalLineListValue [counter3*2] != -1 && horizontalLineListValue [counter3*2+1] != -1){
                                                    sumTotal = sumTotal+horizontalLineListValue [counter3*2+1];
                                                    
                                                    //cout<<highXhigh<<" "<<lowXlow<<" "<<lowXhigh<<" "<<valueUK<<" "<<sumAverage<<" "<<horizontalLineListValue [counter3*2]<<" "<<to_string(cellNoListTemp [counter2])<<" cellNoListTemp"<<endl;
                                                    
                                                    if (sumAverage == -1 && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXlow;
                                                    else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = highXhigh;
                                                    else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                    else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                    else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == -100) sumAverage = -100;
                                                    else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXlow;
                                                    else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = lowXhigh;
                                                    else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                    else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = valueUK;
                                                    else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = lowXlow;
                                                    else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                    else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXhigh;
                                                    else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = highXhigh;
                                                    else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                    else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = valueUK;
                                                    else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = highXhigh;
                                                    else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                    else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXhigh;
                                                    else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = lowXhigh;
                                                    else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                    else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = lowXhigh;
                                                    else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = lowXhigh;
                                                    else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                    else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXlow && unknownPriorityHold == 0) sumAverage = valueUK;
                                                    else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXlow && unknownPriorityHold == 1) sumAverage = lowXlow;
                                                    else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == highXhigh && unknownPriorityHold == 0) sumAverage = valueUK;
                                                    else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == highXhigh && unknownPriorityHold == 1) sumAverage = highXhigh;
                                                    else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXhigh && unknownPriorityHold == 0) sumAverage = lowXhigh;
                                                    else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXhigh && unknownPriorityHold == 1) sumAverage = lowXhigh;
                                                    else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                    else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                    else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = valueUK;
                                                    else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = valueUK;
                                                    else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = valueUK;
                                                    else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                    else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == -100) sumAverage = -100;
                                                    else sumAverage = -100;
                                                    
                                                    horizontalLineList [counter3*3+2] = -1;
                                                    colorDataCount++;
                                                }
                                            }
                                        }
                                    }
                                    else{
                                        
                                        endStatusCheck = 0;
                                        dataEntryCheck = 0;
                                        
                                        for (int counter2 = 0; counter2 < endStatusHoldCount/2; counter2++){
                                            if (endStatusHold [counter2*2] == 0) endStatusCheck = 1;
                                            
                                            for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && endStatusHold [counter2*2] == 0 && horizontalLineListValue [counter3*2] == -1 && horizontalLineListValue [counter3*2+1] == -1){
                                                    dataEntryCheck = 1;
                                                }
                                            }
                                        }
                                        
                                        if (endStatusCheck == 0){
                                            for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                    if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2]){
                                                        sumTotal = 0;
                                                        sumAverage = -100;
                                                        
                                                        horizontalLineListValue [counter3*2] = -100;
                                                        horizontalLineListValue [counter3*2+1] = 0;
                                                        horizontalLineList [counter3*3+2] = -1;
                                                        
                                                        colorDataCount++;
                                                        break;
                                                    }
                                                }
                                            }
                                        }
                                        else if (dataEntryCheck == 0){
                                            for (int counter2 = 0; counter2 < endStatusHoldCount/2; counter2++){
                                                if (endStatusHold [counter2*2] == 1){
                                                    for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                        if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2]){
                                                            sumAverage = -100;
                                                            
                                                            horizontalLineListValue [counter3*2] = -100;
                                                            horizontalLineListValue [counter3*2+1] = sumTotal/(double)colorCountTemp;
                                                            horizontalLineList [counter3*3+2] = -1;
                                                            
                                                            colorDataCount++;
                                                            
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                            
                                            for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                if (endStatusHold [counter2*2] == 0){
                                                    for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                        if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && horizontalLineListValue [counter3*2] != -1 && horizontalLineListValue [counter3*2+1] != -1){
                                                            
                                                            sumTotal = sumTotal+horizontalLineListValue [counter3*2+1];
                                                            
                                                            if (sumAverage == -1 && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXlow;
                                                            else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = highXhigh;
                                                            else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                            else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                            else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == -100) sumAverage = -100;
                                                            else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXlow;
                                                            else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = lowXhigh;
                                                            else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                            else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = valueUK;
                                                            else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = lowXlow;
                                                            else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                            else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXhigh;
                                                            else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = highXhigh;
                                                            else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                            else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = valueUK;
                                                            else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = highXhigh;
                                                            else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                            else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXhigh;
                                                            else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = lowXhigh;
                                                            else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                            else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = lowXhigh;
                                                            else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = lowXhigh;
                                                            else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                            else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXlow && unknownPriorityHold == 0) sumAverage = valueUK;
                                                            else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXlow && unknownPriorityHold == 1) sumAverage = lowXlow;
                                                            else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == highXhigh && unknownPriorityHold == 0) sumAverage = valueUK;
                                                            else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == highXhigh && unknownPriorityHold == 1) sumAverage = highXhigh;
                                                            else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXhigh && unknownPriorityHold == 0) sumAverage = lowXhigh;
                                                            else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXhigh && unknownPriorityHold == 1) sumAverage = lowXhigh;
                                                            else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                            else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                            else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = valueUK;
                                                            else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = valueUK;
                                                            else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = valueUK;
                                                            else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                            else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == -100) sumAverage = -100;
                                                            else sumAverage = -100;
                                                            
                                                            horizontalLineList [counter3*3+2] = -1;
                                                            colorCountTemp++;
                                                            colorDataCount++;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < horizontalLineListCount/3; counterA++){
                                //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<< horizontalLineList [counterA*3+counterB];
                                //    cout<<" horizontalLineList "<<counterA<<" "<<counter1<<endl;
                                //}
                                
                                if (colorDataCount == divisionStatus){
                                    skipCount = 0;
                                    
                                    if (lineageDisplayOption == 0){
                                        if (colorCountTemp == 0){
                                            sumTotal = sumTotal/(double)colorDataCount;
                                            sumAverage = (int)(sumAverage/(double)colorDataCount);
                                        }
                                        else{
                                            
                                            sumTotal = sumTotal/(double)colorCountTemp;
                                            sumAverage = (int)(sumAverage/(double)colorCountTemp);
                                        }
                                    }
                                    
                                    for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                                        if ((int)(horizontalLineList [counter2*3+1]) == expandLineage && horizontalLineList [counter2*3] == parentDoubleCell){
                                            horizontalLineListValue [counter2*2] = sumAverage;
                                            horizontalLineListValue [counter2*2+1] = sumTotal;
                                            horizontalLineList [counter2*3+2] = 1;
                                            break;
                                        }
                                    }
                                }
                                else skipCount++;
                            }
                            else{
                                
                                for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                    if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == expandCell){
                                        horizontalLineList [counter3*3+2] = -1;
                                    }
                                }
                            }
                        }
                        else terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                    
                    delete [] cellNoListTemp;
                    delete [] endStatusHold;
                }
                
                delete [] fluorescentEntry;
            }
            
            if (drawingOptionHold == 2){
                int liveIfLastTimePoint = 0;
                
                for (int counter2 = 0; counter2 < ifValueExtractCount/22; counter2++){
                    if (ifValueExtract [counter2*22+2] > liveIfLastTimePoint) liveIfLastTimePoint = ifValueExtract [counter2*22+2];
                }
                
                //cout<<liveCurrentCHNo<<" "<<ifCurrentTime<<" "<<ifCurrentCHNo<<" "<<lineageDisplayOption<<" "<<liveIfLastTimePoint<<" Channel"<<endl;
                
                double *fluorescentEntry = new double [numberOfCellEntry*5+50];
                int fluorescentEntryCount = 0;
                
                for (int counter2 = 0; counter2 < horizontalListCount2/7; counter2++){
                    if (horizontalList2 [counter2*7+3] <= arrayTableDetail [tableCurrentRowHold][3] && horizontalList2 [counter2*7+4] >= arrayTableDetail [tableCurrentRowHold][3]){
                        fluorescentEntry [fluorescentEntryCount] = horizontalList2 [counter2*7], fluorescentEntryCount++; //----Cell no----
                        fluorescentEntry [fluorescentEntryCount] = horizontalList2 [counter2*7+1], fluorescentEntryCount++; //----Ling no----
                        fluorescentEntry [fluorescentEntryCount] = 0, fluorescentEntryCount++; //----AV----
                        fluorescentEntry [fluorescentEntryCount] = 0, fluorescentEntryCount++; //----Total----
                        fluorescentEntry [fluorescentEntryCount] = counter2, fluorescentEntryCount++; //----Cell order----
                    }
                }
                
                //for (int counterA = 0; counterA < horizontalListCount2/7; counterA++){
                //    cout<<to_string(horizontalList2 [counterA*7])<<" "<<horizontalList2 [counterA*7+1]<<" "<<horizontalList2 [counterA*7+2]<<" "<<horizontalList2 [counterA*7+3]<<" "<<horizontalList2 [counterA*7+4]<<" "<<horizontalList2 [counterA*7+5]<<" "<<horizontalList2 [counterA*7+6]<<"  horizontalList2"<<endl;
                //}
                
                //for (int counterA = 0; counterA < fluorescentEntryCount/5; counterA++){
                //    cout<<to_string(fluorescentEntry [counterA*5])<<" "<<fluorescentEntry [counterA*5+1]<<" "<< fluorescentEntry [counterA*5+2]<<" "<<fluorescentEntry [counterA*5+3]<<" "<<fluorescentEntry [counterA*5+4]<<"   fluorescentEntry"<<endl;
                //}
                
                //for (int counterA = 0; counterA < ifEntryCount/13; counterA++){
                //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<arrayIFData [tableCurrentRowHold][counterA*13+counterB];
                //    cout<<" arrayIFData "<<counterA<<endl;
                //}
                
                for (int counter1 = 0; counter1 < fluorescentEntryCount/5; counter1++){
                    cellNoOriginal = 0;
                    
                    for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                        if (fluorescentEntry [counter1*5] == cellNoList [counter2*4+2]){
                            cellNoOriginal = (int)(cellNoList [counter2*4]);
                            break;
                        }
                    }
                    
                    for (int counter2 = 0; counter2 < ifValueExtractCount/22; counter2++){
                        if (cellNoOriginal == ifValueExtract [counter2*22] && (int)(fluorescentEntry [counter1*5+1]) == ifValueExtract [counter2*22+1] && liveIfLastTimePoint == ifValueExtract [counter2*22+2]){
                            if (liveCurrentCHNo == 1){
                                fluorescentEntry [counter1*5+2] = ifValueExtract [counter2*22+5];
                                fluorescentEntry [counter1*5+3] = ifValueExtract [counter2*22+5]*ifValueExtract [counter2*22+6];
                            }
                            else if (liveCurrentCHNo == 2){
                                fluorescentEntry [counter1*5+2] = ifValueExtract [counter2*22+8];
                                fluorescentEntry [counter1*5+3] = ifValueExtract [counter2*22+8]*ifValueExtract [counter2*22+9];
                            }
                            else if (liveCurrentCHNo == 3){
                                fluorescentEntry [counter1*5+2] = ifValueExtract [counter2*22+11];
                                fluorescentEntry [counter1*5+3] = ifValueExtract [counter2*22+11]*ifValueExtract [counter2*22+12];
                            }
                            else if (liveCurrentCHNo == 4){
                                fluorescentEntry [counter1*5+2] = ifValueExtract [counter2*22+14];
                                fluorescentEntry [counter1*5+3] = ifValueExtract [counter2*22+14]*ifValueExtract [counter2*22+15];
                            }
                            else if (liveCurrentCHNo == 5){
                                fluorescentEntry [counter1*5+2] = ifValueExtract [counter2*22+17];
                                fluorescentEntry [counter1*5+3] = ifValueExtract [counter2*22+17]*ifValueExtract [counter2*22+18];
                            }
                            else if (liveCurrentCHNo == 6){
                                fluorescentEntry [counter1*5+2] = ifValueExtract [counter2*22+20];
                                fluorescentEntry [counter1*5+3] = ifValueExtract [counter2*22+20]*ifValueExtract [counter2*22+21];
                            }
                            
                            break;
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < fluorescentEntryCount/5; counterA++){
                //    cout<<to_string(fluorescentEntry [counterA*5])<<" "<<fluorescentEntry [counterA*5+1]<<" "<< fluorescentEntry [counterA*5+2]<<" "<<fluorescentEntry [counterA*5+3]<<" "<<fluorescentEntry [counterA*5+4]<<"   fluorescentEntry"<<endl;
                //}
                
                for (int counter2 = 0; counter2 < horizontalListCount2/7*3+50; counter2++){
                    horizontalLineList [counter2] = 0;
                }
                
                for (int counter2 = 0; counter2 < horizontalListCount2/7*2+50; counter2++){
                    horizontalLineListValue [counter2] = 0;
                }
                
                horizontalLineListCount = 0;
                horizontalLineListValueCount = 0;
                
                for (int counter2 = 0; counter2 < horizontalListCount2/7; counter2++){
                    horizontalLineList [horizontalLineListCount] = horizontalList2 [counter2*7], horizontalLineListCount++;
                    horizontalLineList [horizontalLineListCount] = horizontalList2 [counter2*7+1], horizontalLineListCount++;
                    horizontalLineList [horizontalLineListCount] = 0, horizontalLineListCount++;
                    
                    horizontalLineListValue [horizontalLineListValueCount] = -1, horizontalLineListValueCount++;
                    horizontalLineListValue [horizontalLineListValueCount] = -1, horizontalLineListValueCount++;
                }
                
                //for (int counterA = 0; counterA < horizontalListCount2/7; counterA++){
                //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<< horizontalList2 [counterA*7+counterB];
                //    cout<<" horizontalList2 "<<counterA<<" "<<counter1<<endl;
                //}
                
                //for (int counterA = 0; counterA < horizontalLineListCount/3; counterA++){
                //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<< to_string(horizontalLineList [counterA*3+counterB]);
                //    cout<<" horizontalLineList "<<counterA<<" "<<endl;
                //}
                
                if (liveIfLastTimePoint == arrayTableDetail [tableCurrentRowHold][3]){
                    if (lineageDisplayOption == 0){
                        for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                            for (int counter3 = 0; counter3 < fluorescentEntryCount/5; counter3++){
                                if (horizontalLineList [counter2*3] == fluorescentEntry [counter3*5] && horizontalLineList [counter2*3+1] == fluorescentEntry [counter3*5+1]){
                                    horizontalLineList [counter2*3+2] = 1;
                                    horizontalLineListValue [counter2*2] = fluorescentEntry [counter3*5+2];
                                    horizontalLineListValue [counter2*2+1] = fluorescentEntry [counter3*5+3];
                                    
                                    break;
                                }
                            }
                        }
                    }
                    else{
                        
                        for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                            for (int counter3 = 0; counter3 < fluorescentEntryCount/5; counter3++){
                                if (horizontalLineList [counter2*3] == fluorescentEntry [counter3*5] && horizontalLineList [counter2*3+1] == fluorescentEntry [counter3*5+1]){
                                    horizontalLineList [counter2*3+2] = 1;
                                    
                                    if (fluorescentEntry [counter3*5+2] == 0) horizontalLineListValue [counter2*2] = lowXlow;
                                    else if (fluorescentEntry [counter3*5+2] == 100) horizontalLineListValue [counter2*2] = highXhigh;
                                    else horizontalLineListValue [counter2*2] = -100;
                                    
                                    horizontalLineListValue [counter2*2+1] = fluorescentEntry [counter3*5+3];
                                    
                                    break;
                                }
                            }
                        }
                    }
                    
                    //----Set dummy value at CD, OF FU lines----
                    if (unknownOptionHold == 1 && lineageDisplayOption == 0){
                        for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                            if (horizontalLineList [counter2*3+2] == 0){
                                cellNoOriginal = 0;
                                
                                for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                                    if (horizontalLineList [counter2*3] == cellNoList [counter3*4+2]){
                                        cellNoOriginal = (int)(cellNoList [counter3*4]);
                                        break;
                                    }
                                }
                                
                                for (unsigned long counter3 = 0; counter3 < lineageExtractCount/9; counter3++){
                                    if (arrayLineageExtract [counter3*9+5] == cellNoOriginal && (arrayLineageExtract [counter3*9+3] == 7 || arrayLineageExtract [counter3*9+3] == 8 || arrayLineageExtract [counter3*9+3] == 91)){
                                        horizontalLineList [counter2*3+2] = 1;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    else if (lineageDisplayOption == 1){
                        for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                            if (horizontalLineList [counter2*3+2] == 0){
                                cellNoOriginal = 0;
                                
                                for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                                    if (horizontalLineList [counter2*3] == cellNoList [counter3*4+2]){
                                        cellNoOriginal = (int)(cellNoList [counter3*4]);
                                        break;
                                    }
                                }
                                
                                for (unsigned long counter3 = 0; counter3 < lineageExtractCount/9; counter3++){
                                    if (arrayLineageExtract [counter3*9+5] == cellNoOriginal && (arrayLineageExtract [counter3*9+3] == 7 || arrayLineageExtract [counter3*9+3] == 8 || arrayLineageExtract [counter3*9+3] == 91)){
                                        horizontalLineList [counter2*3+2] = 1;
                                        
                                        horizontalLineListValue [counter2*2] = -100;
                                        horizontalLineListValue [counter2*2+1] = 100;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < horizontalLineListCount/3; counterA++){
                    //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<< horizontalLineList [counterA*3+counterB];
                    //    cout<<" horizontalLineList "<<counterA<<" "<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < horizontalLineListCount/3; counterA++){
                    //    for (int counterB = 0; counterB < 2; counterB++) cout<<" "<< horizontalLineListValue [counterA*2+counterB];
                    //    cout<<" horizontalLineListValue "<<counterA<<" "<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < lineageExtractCount/9; counterA++){
                    //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayLineageExtract [counterA*9+counterB];
                    //    cout<<" arrayLineageExtract "<<counterA<<endl;
                    //}
                    
                    int expandLineage = 0;
                    int skipCount = 0;
                    int skipEntryCount = 0;
                    int divisionStatus = 0;
                    int dataEntryCheck = 0;
                    int endStatusCheck = 0;
                    int endStatusCheck2 = 0;
                    int colorCountTemp = 0;
                    int checkStart = 0;
                    int checkNoCheck = 0;
                    
                    double expandCell = 0;
                    double parentDoubleCell = 0;
                    double cellNoOriginal2 = 0;
                    double sumTotal = 0;
                    double sumAverage = 0;
                    double colorDataCount = 0;
                    
                    double *cellNoListTemp = new double [10];
                    int cellNoListTempCount = 0;
                    
                    int *endStatusHold = new int [20];
                    int endStatusHoldCount = 0;
                    
                    do{
                        
                        terminationFlag = 1;
                        expandLineage = 0;
                        skipEntryCount = skipCount;
                        
                        for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                            if (horizontalLineList [counter2*3+2] == 1 && skipEntryCount == 0){
                                expandLineage = (int)(horizontalLineList [counter2*3+1]);
                                expandCell = horizontalLineList [counter2*3];
                                break;
                            }
                            else if (horizontalLineList [counter2*3+2] == 1 && skipEntryCount >= 0) skipEntryCount--;
                        }
                        
                        if (expandLineage != 0){
                            parentCellNo = -1;
                            cellNoOriginal = 0;
                            
                            for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                                if (expandCell == cellNoList [counter2*4+2]){
                                    cellNoOriginal = (int)(cellNoList [counter2*4]);
                                    break;
                                }
                            }
                            
                            for (unsigned long counter2 = 0; counter2 < lineageExtractCount/9; counter2++){
                                if (arrayLineageExtract [counter2*9+3] == 31 || arrayLineageExtract [counter2*9+3] == 41 || arrayLineageExtract [counter2*9+3] == 51){
                                    if (arrayLineageExtract [counter2*9+6] == expandLineage && arrayLineageExtract [counter2*9+5] == cellNoOriginal){
                                        parentCellNo = arrayLineageExtract [counter2*9+4];
                                        break;
                                    }
                                }
                            }
                            
                            parentDoubleCell = 0;
                            
                            for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                                if (parentCellNo == cellNoList [counter2*4]){
                                    parentDoubleCell = cellNoList [counter2*4+2];
                                    break;
                                }
                            }
                            
                            if (parentCellNo != -1){
                                cellNoListTempCount = 0;
                                endStatusHoldCount = 0;
                                divisionStatus = 0;
                                
                                for (unsigned long counter2 = 0; counter2 < lineageExtractCount/9; counter2++){
                                    if (arrayLineageExtract [counter2*9+3] == 31 || arrayLineageExtract [counter2*9+3] == 41 || arrayLineageExtract [counter2*9+3] == 51){
                                        if (arrayLineageExtract [counter2*9+6] == expandLineage && arrayLineageExtract [counter2*9+4] == parentCellNo){
                                            cellNoOriginal2 = 0;
                                            
                                            for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                                                if (arrayLineageExtract [counter2*9+5] == cellNoList [counter3*4]){
                                                    cellNoOriginal2 = cellNoList [counter3*4+2];
                                                    break;
                                                }
                                            }
                                            
                                            if (arrayLineageExtract [counter2*9+3] == 31) divisionStatus = 2;
                                            else if (arrayLineageExtract [counter2*9+3] == 41) divisionStatus = 3;
                                            else if (arrayLineageExtract [counter2*9+3] == 51) divisionStatus = 4;
                                            
                                            cellNoListTemp [cellNoListTempCount] = cellNoOriginal2, cellNoListTempCount++;
                                            
                                            endStatusHold [endStatusHoldCount] = 0, endStatusHoldCount++;
                                            endStatusHold [endStatusHoldCount] = -1, endStatusHoldCount++;
                                            
                                            for (unsigned long counter3 = 0; counter3 < lineageExtractCount/9; counter3++){
                                                if (arrayLineageExtract [counter3*9+6] == expandLineage && arrayLineageExtract [counter3*9+5] == arrayLineageExtract [counter2*9+5] && (arrayLineageExtract [counter3*9+3] == 7 || arrayLineageExtract [counter3*9+3] == 8 || arrayLineageExtract [counter3*9+3] == 91)){
                                                    endStatusHold [endStatusHoldCount-2] = 1;
                                                    break;
                                                }
                                            }
                                            
                                            checkStart = 0;
                                            checkNoCheck = 0;
                                            
                                            //----Check progeny's end status, enter 1 when end is CD, OF, FU----
                                            for (unsigned long counter3 = 0; counter3 < lineageExtractCount/9; counter3++){
                                                if (arrayLineageExtract [counter3*9+6] == expandLineage && arrayLineageExtract [counter3*9+4] == arrayLineageExtract [counter2*9+5] && arrayLineageExtract [counter3*9+3] != 91 && arrayLineageExtract [counter3*9+4] != 92){
                                                    checkStart = 1;
                                                    checkNoCheck = arrayLineageExtract [counter3*9+5];
                                                }
                                                
                                                if (arrayLineageExtract [counter3*9+6] == expandLineage && arrayLineageExtract [counter3*9+5] == checkNoCheck && checkStart == 1 && (arrayLineageExtract [counter3*9+3] == 7 || arrayLineageExtract [counter3*9+3] == 8 || arrayLineageExtract [counter3*9+3] == 91)){
                                                    if (endStatusHold [endStatusHoldCount-1] == -1) endStatusHold [endStatusHoldCount-1] = 1;
                                                    
                                                    checkStart = 0;
                                                }
                                                else if (arrayLineageExtract [counter3*9+6] == expandLineage && arrayLineageExtract [counter3*9+5] == checkNoCheck && checkStart == 1 && (arrayLineageExtract [counter3*9+3] == 32 || arrayLineageExtract [counter3*9+3] == 42 || arrayLineageExtract [counter3*9+3] == 52 || arrayLineageExtract [counter3*9+2] == arrayTableDetail [tableCurrentRowHold][3])){
                                                    endStatusHold [endStatusHoldCount-1] = 0;
                                                    break;
                                                }
                                            }
                                            
                                            if (endStatusHold [endStatusHoldCount-1] == -1) endStatusHold [endStatusHoldCount-1] = 0;
                                        }
                                    }
                                }
                                
                                endStatusCheck = 0;
                                endStatusCheck2 = 0;
                                
                                for (int counter2 = 0; counter2 < endStatusHoldCount; counter2++){
                                    if (endStatusHold [counter2] == 1) endStatusCheck = 1;
                                    if (endStatusHold [counter2*2+1] == 1) endStatusCheck2 = 1;
                                }
                                
                                sumTotal = 0;
                                sumAverage = -1;
                                colorDataCount = 0;
                                colorCountTemp = 0;
                                
                                if (lineageDisplayOption == 1) sumAverage = -1;
                                
                                if (lineageDisplayOption == 0){
                                    if (unknownOptionHold == 0){
                                        if (endStatusCheck == 0){
                                            for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                    if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && horizontalLineListValue [counter3*2] != -1 && horizontalLineListValue [counter3*2+1] != -1){
                                                        sumTotal = sumTotal+horizontalLineListValue [counter3*2+1];
                                                        sumAverage = sumAverage+(int)horizontalLineListValue [counter3*2];
                                                        
                                                        horizontalLineList [counter3*3+2] = -1;
                                                        colorDataCount++;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else if (unknownOptionHold == 1){
                                        if (endStatusCheck == 0 && endStatusCheck2 == 0){
                                            for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                    if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && horizontalLineListValue [counter3*2] != -1 && horizontalLineListValue [counter3*2+1] != -1){
                                                        sumTotal = sumTotal+horizontalLineListValue [counter3*2+1];
                                                        sumAverage = sumAverage+(int)horizontalLineListValue [counter3*2];
                                                        
                                                        horizontalLineList [counter3*3+2] = -1;
                                                        colorDataCount++;
                                                    }
                                                }
                                            }
                                        }
                                        else{
                                            
                                            endStatusCheck = 0;
                                            dataEntryCheck = 0;
                                            
                                            for (int counter2 = 0; counter2 < endStatusHoldCount/2; counter2++){
                                                if (endStatusHold [counter2*2] == 0) endStatusCheck = 1;
                                                
                                                for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                    if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && endStatusHold [counter2*2] == 0 && endStatusHold [counter2*2+1] == 0 && horizontalLineListValue [counter3*2] == -1 && horizontalLineListValue [counter3*2+1] == -1){
                                                        dataEntryCheck = 1;
                                                    }
                                                }
                                            }
                                            
                                            if (endStatusCheck == 0){
                                                for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                    for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                        if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2]){
                                                            sumTotal = -2;
                                                            sumAverage = -2;
                                                            
                                                            horizontalLineListValue [counter3*2] = -1;
                                                            horizontalLineListValue [counter3*2+1] = -1;
                                                            horizontalLineList [counter3*3+2] = -1;
                                                            
                                                            colorDataCount++;
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                            else if (dataEntryCheck == 0){
                                                for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                    for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                        if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && horizontalLineListValue [counter3*2] != -1 && horizontalLineListValue [counter3*2+1] != -1){
                                                            sumTotal = sumTotal+horizontalLineListValue [counter3*2+1];
                                                            sumAverage = sumAverage+(int)horizontalLineListValue [counter3*2];
                                                            
                                                            horizontalLineList [counter3*3+2] = -1;
                                                            colorCountTemp++;
                                                            colorDataCount++;
                                                        }
                                                    }
                                                }
                                                
                                                for (int counter2 = 0; counter2 < endStatusHoldCount/2; counter2++){
                                                    if (endStatusHold [counter2*2] == 1 || endStatusHold [counter2*2+1] == 1){
                                                        for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                            if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2]){
                                                                horizontalLineListValue [counter3*2] = (int)(sumAverage/(double)colorCountTemp);
                                                                horizontalLineListValue [counter3*2+1] = sumTotal/(double)colorCountTemp;
                                                                horizontalLineList [counter3*3+2] = -1;
                                                                
                                                                colorDataCount++;
                                                                
                                                                break;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                else if (lineageDisplayOption == 1){
                                    if (endStatusCheck == 0){
                                        for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                            for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && horizontalLineListValue [counter3*2] != -1 && horizontalLineListValue [counter3*2+1] != -1){
                                                    sumTotal = sumTotal+horizontalLineListValue [counter3*2+1];
                                                    
                                                    //cout<<highXhigh<<" "<<lowXlow<<" "<<lowXhigh<<" "<<sumAverage<<" "<<horizontalLineListValue [counter3*2]<<" "<<to_string(cellNoListTemp [counter2])<<" cellNoListTemp"<<endl;
                                                    
                                                    if (sumAverage == -1 && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXlow;
                                                    else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = highXhigh;
                                                    else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                    else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                    else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == -100) sumAverage = -100;
                                                    else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXlow;
                                                    else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = lowXhigh;
                                                    else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                    else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = valueUK;
                                                    else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = lowXlow;
                                                    else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                    else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXhigh;
                                                    else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = highXhigh;
                                                    else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                    else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = valueUK;
                                                    else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = highXhigh;
                                                    else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                    else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXhigh;
                                                    else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = lowXhigh;
                                                    else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                    else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = lowXhigh;
                                                    else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = lowXhigh;
                                                    else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                    else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXlow && unknownPriorityHold == 0) sumAverage = valueUK;
                                                    else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXlow && unknownPriorityHold == 1) sumAverage = lowXlow;
                                                    else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == highXhigh && unknownPriorityHold == 0) sumAverage = valueUK;
                                                    else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == highXhigh && unknownPriorityHold == 1) sumAverage = highXhigh;
                                                    else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXhigh && unknownPriorityHold == 0) sumAverage = lowXhigh;
                                                    else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXhigh && unknownPriorityHold == 1) sumAverage = lowXhigh;
                                                    else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                    else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                    else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = valueUK;
                                                    else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = valueUK;
                                                    else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = valueUK;
                                                    else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                    else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == -100) sumAverage = -100;
                                                    else sumAverage = -100;
                                                    
                                                    horizontalLineList [counter3*3+2] = -1;
                                                    colorDataCount++;
                                                }
                                            }
                                        }
                                    }
                                    else{
                                        
                                        endStatusCheck = 0;
                                        dataEntryCheck = 0;
                                        
                                        for (int counter2 = 0; counter2 < endStatusHoldCount/2; counter2++){
                                            if (endStatusHold [counter2*2] == 0) endStatusCheck = 1;
                                            
                                            for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && endStatusHold [counter2*2] == 0 && horizontalLineListValue [counter3*2] == -1 && horizontalLineListValue [counter3*2+1] == -1){
                                                    dataEntryCheck = 1;
                                                }
                                            }
                                        }
                                        
                                        if (endStatusCheck == 0){
                                            for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                    if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2]){
                                                        sumTotal = 0;
                                                        sumAverage = -100;
                                                        
                                                        horizontalLineListValue [counter3*2] = -100;
                                                        horizontalLineListValue [counter3*2+1] = 0;
                                                        horizontalLineList [counter3*3+2] = -1;
                                                        
                                                        colorDataCount++;
                                                        break;
                                                    }
                                                }
                                            }
                                        }
                                        else if (dataEntryCheck == 0){
                                            for (int counter2 = 0; counter2 < endStatusHoldCount/2; counter2++){
                                                if (endStatusHold [counter2*2] == 1){
                                                    for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                        if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2]){
                                                            sumAverage = -100;
                                                            
                                                            horizontalLineListValue [counter3*2] = -100;
                                                            horizontalLineListValue [counter3*2+1] = sumTotal/(double)colorCountTemp;
                                                            horizontalLineList [counter3*3+2] = -1;
                                                            
                                                            colorDataCount++;
                                                            
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                            
                                            for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                if (endStatusHold [counter2*2] == 0){
                                                    for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                        if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && horizontalLineListValue [counter3*2] != -1 && horizontalLineListValue [counter3*2+1] != -1){
                                                            sumTotal = sumTotal+horizontalLineListValue [counter3*2+1];
                                                            
                                                            if (sumAverage == -1 && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXlow;
                                                            else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = highXhigh;
                                                            else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                            else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                            else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == -100) sumAverage = -100;
                                                            else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXlow;
                                                            else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = lowXhigh;
                                                            else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                            else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = valueUK;
                                                            else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = lowXlow;
                                                            else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                            else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXhigh;
                                                            else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = highXhigh;
                                                            else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                            else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = valueUK;
                                                            else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = highXhigh;
                                                            else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                            else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXhigh;
                                                            else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = lowXhigh;
                                                            else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                            else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = lowXhigh;
                                                            else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = lowXhigh;
                                                            else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                            else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXlow && unknownPriorityHold == 0) sumAverage = valueUK;
                                                            else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXlow && unknownPriorityHold == 1) sumAverage = lowXlow;
                                                            else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == highXhigh && unknownPriorityHold == 0) sumAverage = valueUK;
                                                            else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == highXhigh && unknownPriorityHold == 1) sumAverage = highXhigh;
                                                            else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXhigh && unknownPriorityHold == 0) sumAverage = lowXhigh;
                                                            else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXhigh && unknownPriorityHold == 1) sumAverage = lowXhigh;
                                                            else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                            else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                            else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = valueUK;
                                                            else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = valueUK;
                                                            else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = valueUK;
                                                            else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                            else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == -100) sumAverage = -100;
                                                            else sumAverage = -100;
                                                            
                                                            horizontalLineList [counter3*3+2] = -1;
                                                            colorCountTemp++;
                                                            colorDataCount++;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < horizontalLineListCount/3; counterA++){
                                //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<< horizontalLineList [counterA*3+counterB];
                                //    cout<<" horizontalLineList "<<counterA<<" "<<counter1<<endl;
                                //}
                                
                                if (colorDataCount == divisionStatus){
                                    skipCount = 0;
                                    
                                    if (lineageDisplayOption == 0){
                                        if (colorCountTemp == 0){
                                            sumTotal = sumTotal/(double)colorDataCount;
                                            sumAverage = (int)(sumAverage/(double)colorDataCount);
                                        }
                                        else{
                                            
                                            sumTotal = sumTotal/(double)colorCountTemp;
                                            sumAverage = (int)(sumAverage/(double)colorCountTemp);
                                        }
                                    }
                                    
                                    for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                                        if ((int)(horizontalLineList [counter2*3+1]) == expandLineage && horizontalLineList [counter2*3] == parentDoubleCell){
                                            horizontalLineListValue [counter2*2] = sumAverage;
                                            horizontalLineListValue [counter2*2+1] = sumTotal;
                                            horizontalLineList [counter2*3+2] = 1;
                                            break;
                                        }
                                    }
                                }
                                else skipCount++;
                            }
                            else{
                                
                                for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                    if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == expandCell){
                                        horizontalLineList [counter3*3+2] = -1;
                                    }
                                }
                            }
                        }
                        else terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                    
                    delete [] cellNoListTemp;
                    delete [] endStatusHold;
                }
                
                delete [] fluorescentEntry;
            }
            
            //for (int counterA = 0; counterA < horizontalLineListCount/3; counterA++){
            //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<< horizontalLineList [counterA*3+counterB];
            //    cout<<" horizontalLineList "<<counterA<<" "<<endl;
            //}
            
            //for (int counterA = 0; counterA < horizontalLineListCount/3; counterA++){
            //    for (int counterB = 0; counterB < 2; counterB++) cout<<" "<< horizontalLineListValue [counterA*2+counterB];
            //    cout<<" horizontalLineListValue "<<counterA<<" "<<endl;
            //}
            
            string ifString = to_string(roundNoGet);
            
            [attributesA setObject:[NSFont boldSystemFontOfSize:9*magFactor] forKey:NSFontAttributeName];
            
            //----Color data range get----
            int rangeLiveAverageLow = 0;
            int rangeLiveAverageHigh = 0;
            int rangeLiveTotalLow = 0;
            int rangeLiveTotalHigh = 0;
            
            if (liveCurrentCHNo != 0){
                string liveName = "";
                
                if (liveCurrentCHNo == 1) liveName = arrayTableMain [tableCurrentRowHold][6];
                else if (liveCurrentCHNo == 2) liveName = arrayTableMain [tableCurrentRowHold][7];
                else if (liveCurrentCHNo == 3) liveName = arrayTableMain [tableCurrentRowHold][8];
                else if (liveCurrentCHNo == 4) liveName = arrayTableMain [tableCurrentRowHold][9];
                else if (liveCurrentCHNo == 5) liveName = arrayTableMain [tableCurrentRowHold][10];
                else if (liveCurrentCHNo == 6) liveName = arrayTableMain [tableCurrentRowHold][11];
                
                for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryCount; counter1++){
                    if (atoi(arrayLineageFluorescentDataType [counter1][0].c_str()) == tableCurrentRowHold+1 && arrayLineageFluorescentDataType [counter1][1] == "Live" && arrayLineageFluorescentDataType [counter1][2] == liveName){
                        rangeLiveTotalLow = atoi(arrayLineageFluorescentDataType [counter1][6].c_str());
                        rangeLiveTotalHigh = atoi(arrayLineageFluorescentDataType [counter1][7].c_str());
                        rangeLiveAverageLow = atoi(arrayLineageFluorescentDataType [counter1][4].c_str());
                        rangeLiveAverageHigh = atoi(arrayLineageFluorescentDataType [counter1][5].c_str());
                        break;
                    }
                }
            }
            
            //for (int counterA = 0; counterA < liveTimeListCount; counterA++){
            //    cout<<counterA<<" "<<liveTimeList [counterA] <<" liveTimeList"<<endl;
            //}
            
            string liveName = "";
            string cellNumberString;
            string horizontalString;
            
            NSBezierPath *pathCircle;
            
            int endType = 0;
            int startType = 0;
            int liveColorStart = 0;
            int liveColorEnd = 0;
            int liveValueGet = 0;
            int rangeNoHold = 0;
            int timeHold = 0;
            int timeHold2 = 0;
            int differenceInt = 0;
            double rangeDivision = 0;
            double difference = 0;
            double difference2 = 0;
            double markerSizeSet = 0;
            
            double *rangeList = new double [horizontalTime*3+30];
            int rangeListCount = 0;
            
            if (markSizeFlag == 0) markerSizeSet = 12;
            else if (markSizeFlag == 1) markerSizeSet = 6;
            else if (markSizeFlag == 2) markerSizeSet = 0;
            
            for (int counter1 = 0; counter1 < horizontalListCount2/7; counter1++){
                [[NSColor blackColor] set];
                
                cellNoOriginal = 0;
                
                for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                    if (horizontalList2 [counter1*7] == cellNoList [counter2*4+2]){
                        cellNoOriginal = (int)(cellNoList [counter2*4]);
                        break;
                    }
                }
                
                if (horizontalList2 [counter1*7+5] == 32 || horizontalList2 [counter1*7+3] == 42 || horizontalList2 [counter1*7+3] == 52) endType = 1;
                else endType = 0;
                
                if (horizontalList2 [counter1*7+6] == 1) startType = 1;
                else startType = 0;
                
                //cout<<counter1<<" "<<horizontalList2 [counter1*7]<<" "<<horizontalList2 [counter1*7+1]<<" TimeStartEnd"<<endl;
                
                //----Color data drawing----
                if (drawingOptionHold == 0 || drawingOptionHold == 3){
                    positionAA.x = 40*magFactor+horizontalList2 [counter1*7+3]*horizontalIncrement*magFactor;
                    positionAA.y = 52*magFactor+increment*magFactor+counter1*increment*magFactor;
                    
                    if (endType == 1) positionBB.x = 40*magFactor+(horizontalList2 [counter1*7+4]+1)*horizontalIncrement*magFactor;
                    else positionBB.x = 40*magFactor+horizontalList2 [counter1*7+4]*horizontalIncrement*magFactor;
                    
                    positionBB.y = 52*magFactor+increment*magFactor+counter1*increment*magFactor;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                }
                else if (drawingOptionHold == 1){
                    liveColorStart = -1;
                    liveColorEnd = -1;
                    
                    for (int counter2 = 0; counter2 < liveTimeListCount; counter2++){
                        if (liveColorStart == -1 && liveTimeList [counter2] >= horizontalList2 [counter1*7+3]) liveColorStart = counter2;
                        if (liveTimeList [counter2] <= horizontalList2 [counter1*7+4]) liveColorEnd = counter2;
                    }
                    
                    if (liveColorStart != -1 && liveColorStart == liveColorEnd){
                        liveValueGet = 0;
                        
                        for (int counter2 = 0; counter2 < ifValueExtractCount/22; counter2++){
                            if (cellNoOriginal == ifValueExtract [counter2*22] && (int)(horizontalList2 [counter1*7+1]) == ifValueExtract [counter2*22+1] && liveTimeList [liveColorStart] == ifValueExtract [counter2*22+2]){
                                
                                if (liveCurrentCHNo == 1){
                                    if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter2*22+5];
                                    else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter2*22+5]*ifValueExtract [counter2*22+6];
                                }
                                else if (liveCurrentCHNo == 2){
                                    if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter2*22+8];
                                    else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter2*22+8]*ifValueExtract [counter2*22+9];
                                }
                                else if (liveCurrentCHNo == 3){
                                    if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter2*22+11];
                                    else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter2*22+11]*ifValueExtract [counter2*22+12];
                                }
                                else if (liveCurrentCHNo == 4){
                                    if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter2*22+14];
                                    else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter2*22+14]*ifValueExtract [counter2*22+15];
                                }
                                else if (liveCurrentCHNo == 5){
                                    if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter2*22+17];
                                    else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter2*22+17]*ifValueExtract [counter2*22+18];
                                }
                                else if (liveCurrentCHNo == 6){
                                    if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter2*22+20];
                                    else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter2*22+20]*ifValueExtract [counter2*22+21];
                                }
                                
                                break;
                            }
                        }
                        
                        if (averageTotalFlag == 0){
                            rangeDivision = (rangeLiveAverageHigh-rangeLiveAverageLow)/(double)25;
                            
                            if (liveValueGet <= rangeLiveAverageLow+rangeDivision) rangeNo = 1;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*2) rangeNo = 2;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*3) rangeNo = 3;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*4) rangeNo = 4;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*5) rangeNo = 5;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*6) rangeNo = 6;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*7) rangeNo = 7;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*8) rangeNo = 8;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*9) rangeNo = 9;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*10) rangeNo = 10;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*11) rangeNo = 11;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*12) rangeNo = 12;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*13) rangeNo = 13;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*14) rangeNo = 14;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*15) rangeNo = 15;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*16) rangeNo = 16;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*17) rangeNo = 17;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*18) rangeNo = 18;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*19) rangeNo = 19;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*20) rangeNo = 20;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*21) rangeNo = 21;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*22) rangeNo = 22;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*23) rangeNo = 23;
                            else rangeNo = 24;
                            
                            if (liveValueGet == -1) rangeNo = 105/3+1;
                            
                            [[NSColor colorWithCalibratedRed:arrayColorRange [(rangeNo-1)*3] green:arrayColorRange [(rangeNo-1)*3+1] blue:arrayColorRange [(rangeNo-1)*3+2] alpha:1] set];
                            
                            positionAA.x = 40*magFactor+horizontalList2 [counter1*7+3]*horizontalIncrement*magFactor;
                            positionAA.y = 52*magFactor+increment*magFactor+counter1*increment*magFactor;
                            
                            if (endType == 1) positionBB.x = 40*magFactor+(horizontalList2 [counter1*7+4]+1)*horizontalIncrement*magFactor;
                            else positionBB.x = 40*magFactor+horizontalList2 [counter1*7+4]*horizontalIncrement*magFactor;
                            
                            positionBB.y = 52*magFactor+increment*magFactor+counter1*increment*magFactor;
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                        else{
                            
                            rangeDivision = (rangeLiveTotalHigh-rangeLiveTotalLow)/(double)25;
                            
                            if (liveValueGet <= rangeLiveTotalLow+rangeDivision) rangeNo = 1;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*2) rangeNo = 2;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*3) rangeNo = 3;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*4) rangeNo = 4;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*5) rangeNo = 5;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*6) rangeNo = 6;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*7) rangeNo = 7;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*8) rangeNo = 8;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*9) rangeNo = 9;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*10) rangeNo = 10;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*11) rangeNo = 11;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*12) rangeNo = 12;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*13) rangeNo = 13;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*14) rangeNo = 14;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*15) rangeNo = 15;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*16) rangeNo = 16;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*17) rangeNo = 17;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*18) rangeNo = 18;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*19) rangeNo = 19;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*20) rangeNo = 20;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*21) rangeNo = 21;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*22) rangeNo = 22;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*23) rangeNo = 23;
                            else rangeNo = 24;
                            
                            if (liveValueGet == -1) rangeNo = 105/3+1;
                            
                            [[NSColor colorWithCalibratedRed:arrayColorRange [(rangeNo-1)*3] green:arrayColorRange [(rangeNo-1)*3+1] blue:arrayColorRange [(rangeNo-1)*3+2] alpha:1] set];
                            
                            positionAA.x = 40*magFactor+horizontalList2 [counter1*7+3]*horizontalIncrement*magFactor;
                            positionAA.y = 52*magFactor+increment*magFactor+counter1*increment*magFactor;
                            
                            if (endType == 1) positionBB.x = 40*magFactor+(horizontalList2 [counter1*7+4]+1)*horizontalIncrement*magFactor;
                            else positionBB.x = 40*magFactor+horizontalList2 [counter1*7+4]*horizontalIncrement*magFactor;
                            
                            positionBB.y = 52*magFactor+increment*magFactor+counter1*increment*magFactor;
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                    } //----One live data/cell----
                    else if (liveColorStart != -1 && liveColorStart < liveColorEnd){ //----More than one live data/cell----
                        rangeListCount = 0;
                        
                        for (int counter2 = liveColorStart; counter2 <= liveColorEnd; counter2++){
                            liveValueGet = 0;
                            
                            for (int counter3 = 0; counter3 < ifValueExtractCount/22; counter3++){
                                if (cellNoOriginal == ifValueExtract [counter3*22] && (int)(horizontalList2 [counter1*7+1]) == ifValueExtract [counter3*22+1] && liveTimeList [counter2] == ifValueExtract [counter3*22+2]){
                                    
                                    if (liveCurrentCHNo == 1){
                                        if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter3*22+5];
                                        else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter3*22+5]*ifValueExtract [counter3*22+6];
                                    }
                                    else if (liveCurrentCHNo == 2){
                                        if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter3*22+8];
                                        else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter3*22+8]*ifValueExtract [counter3*22+9];
                                    }
                                    else if (liveCurrentCHNo == 3){
                                        if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter3*22+11];
                                        else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter3*22+11]*ifValueExtract [counter3*22+12];
                                    }
                                    else if (liveCurrentCHNo == 4){
                                        if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter3*22+14];
                                        else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter3*22+14]*ifValueExtract [counter3*22+15];
                                    }
                                    else if (liveCurrentCHNo == 5){
                                        if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter3*22+17];
                                        else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter3*22+17]*ifValueExtract [counter3*22+18];
                                    }
                                    else if (liveCurrentCHNo == 6){
                                        if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter3*22+20];
                                        else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter3*22+20]*ifValueExtract [counter3*22+21];
                                    }
                                    
                                    break;
                                }
                            }
                            
                            if (averageTotalFlag == 0){
                                rangeDivision = (rangeLiveAverageHigh-rangeLiveAverageLow)/(double)25;
                                
                                if (liveValueGet <= rangeLiveAverageLow+rangeDivision) rangeNo = 1;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*2) rangeNo = 2;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*3) rangeNo = 3;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*4) rangeNo = 4;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*5) rangeNo = 5;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*6) rangeNo = 6;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*7) rangeNo = 7;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*8) rangeNo = 8;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*9) rangeNo = 9;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*10) rangeNo = 10;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*11) rangeNo = 11;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*12) rangeNo = 12;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*13) rangeNo = 13;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*14) rangeNo = 14;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*15) rangeNo = 15;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*16) rangeNo = 16;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*17) rangeNo = 17;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*18) rangeNo = 18;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*19) rangeNo = 19;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*20) rangeNo = 20;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*21) rangeNo = 21;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*22) rangeNo = 22;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*23) rangeNo = 23;
                                else rangeNo = 23;
                                
                                if (liveValueGet == -1) rangeNo = 105/3+1;
                            }
                            else{
                                
                                rangeDivision = (rangeLiveTotalHigh-rangeLiveTotalLow)/(double)25;
                                
                                if (liveValueGet <= rangeLiveTotalLow+rangeDivision) rangeNo = 1;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*2) rangeNo = 2;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*3) rangeNo = 3;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*4) rangeNo = 4;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*5) rangeNo = 5;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*6) rangeNo = 6;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*7) rangeNo = 7;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*8) rangeNo = 8;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*9) rangeNo = 9;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*10) rangeNo = 10;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*11) rangeNo = 11;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*12) rangeNo = 12;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*13) rangeNo = 13;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*14) rangeNo = 14;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*15) rangeNo = 15;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*16) rangeNo = 16;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*17) rangeNo = 17;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*18) rangeNo = 18;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*19) rangeNo = 19;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*20) rangeNo = 20;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*21) rangeNo = 21;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*22) rangeNo = 22;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*23) rangeNo = 23;
                                else rangeNo = 23;
                                
                                if (liveValueGet == -1) rangeNo = 105/3+1;
                            }
                            
                            if (counter2 == liveColorStart){
                                rangeList [rangeListCount] = horizontalList2 [counter1*7+3], rangeListCount++;
                                rangeList [rangeListCount] = liveTimeList [counter2], rangeListCount++;
                                rangeList [rangeListCount] = rangeNo, rangeListCount++;
                                
                                rangeNoHold = rangeNo;
                                timeHold = liveTimeList [counter2];
                            }
                            else if (counter2 == liveColorEnd){
                                difference = (rangeNo-rangeNoHold)/(double)(liveTimeList [counter2]-timeHold);
                                
                                if (liveTimeList [counter2]-timeHold < 5){
                                    rangeList [rangeListCount] = horizontalList2 [counter1*7+3], rangeListCount++;
                                    rangeList [rangeListCount] = liveTimeList [counter2], rangeListCount++;
                                    rangeList [rangeListCount] = rangeNo, rangeListCount++;
                                }
                                else{
                                    
                                    difference2 = difference;
                                    timeHold2 = timeHold;
                                    
                                    for (int counter3 = timeHold+1; counter3 <= liveTimeList [counter2]; counter3++){
                                        if (counter3 == liveTimeList [counter2]){
                                            
                                            rangeList [rangeListCount] = timeHold2, rangeListCount++;
                                            rangeList [rangeListCount] = counter3, rangeListCount++;
                                            rangeList [rangeListCount] = rangeNo, rangeListCount++;
                                        }
                                        else if (difference2 >= 1){
                                            differenceInt = (int)difference2;
                                            
                                            rangeList [rangeListCount] = timeHold2, rangeListCount++;
                                            rangeList [rangeListCount] = counter3, rangeListCount++;
                                            rangeList [rangeListCount] = rangeNoHold+differenceInt, rangeListCount++;
                                            
                                            difference2 = difference;
                                            rangeNoHold = rangeNoHold+differenceInt;
                                            timeHold2 = counter3;
                                        }
                                        else difference2 = difference2+difference;
                                    }
                                }
                                
                                rangeList [rangeListCount] = liveTimeList [counter2], rangeListCount++;
                                
                                if (endType == 1) rangeList [rangeListCount] = horizontalList2 [counter1*7+4]+1, rangeListCount++;
                                else rangeList [rangeListCount] = horizontalList2 [counter1*7+4], rangeListCount++;
                                
                                rangeList [rangeListCount] = rangeNo, rangeListCount++;
                            }
                            else{
                                
                                difference = (rangeNo-rangeNoHold)/(double)(liveTimeList [counter2]-timeHold);
                                
                                if (liveTimeList [counter2]-timeHold < 5){
                                    rangeList [rangeListCount] = horizontalList2 [counter1*7+3], rangeListCount++;
                                    rangeList [rangeListCount] = liveTimeList [counter2], rangeListCount++;
                                    rangeList [rangeListCount] = rangeNo, rangeListCount++;
                                }
                                else{
                                    
                                    difference2 = difference;
                                    timeHold2 = timeHold;
                                    
                                    for (int counter3 = timeHold+1; counter3 <= liveTimeList [counter2]; counter3++){
                                        if (counter3 == liveTimeList [counter2]){
                                            rangeList [rangeListCount] = timeHold2, rangeListCount++;
                                            rangeList [rangeListCount] = counter3, rangeListCount++;
                                            rangeList [rangeListCount] = rangeNo, rangeListCount++;
                                        }
                                        else if (difference2 >= 1){
                                            differenceInt = (int)difference2;
                                            
                                            rangeList [rangeListCount] = timeHold2, rangeListCount++;
                                            rangeList [rangeListCount] = counter3, rangeListCount++;
                                            rangeList [rangeListCount] = rangeNoHold+differenceInt, rangeListCount++;
                                            
                                            difference2 = difference;
                                            rangeNoHold = rangeNoHold+differenceInt;
                                            timeHold2 = counter3;
                                        }
                                        else difference2 = difference2+difference;
                                    }
                                }
                                
                                rangeNoHold = rangeNo;
                                timeHold = liveTimeList [counter2];
                            }
                        }
                        
                        for (int counter2 = 0; counter2 < rangeListCount/3; counter2++){
                            [[NSColor colorWithCalibratedRed:arrayColorRange [(int)(rangeList [counter2*3+2])*3] green:arrayColorRange [(int)(rangeList [counter2*3+2])*3+1] blue:arrayColorRange [(int)(rangeList [counter2*3+2])*3+2] alpha:1] set];
                            
                            positionAA.x = 40*magFactor+rangeList [counter2*3]*horizontalIncrement*magFactor;
                            positionAA.y = 52*magFactor+increment*magFactor+counter1*increment*magFactor;
                            positionBB.x = 40*magFactor+rangeList [counter2*3+1]*horizontalIncrement*magFactor;
                            positionBB.y = 52*magFactor+increment*magFactor+counter1*increment*magFactor;
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                    }
                    else{
                        
                        positionAA.x = 40*magFactor+horizontalList2 [counter1*7+3]*horizontalIncrement*magFactor;
                        positionAA.y = 52*magFactor+increment*magFactor+counter1*increment*magFactor;
                        
                        if (endType == 1) positionBB.x = 40*magFactor+(horizontalList2 [counter1*7+4]+1)*horizontalIncrement*magFactor;
                        else positionBB.x = 40*magFactor+horizontalList2 [counter1*7+4]*horizontalIncrement*magFactor;
                        
                        positionBB.y = 52*magFactor+increment*magFactor+counter1*increment*magFactor;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    }
                }
                else if (drawingOptionHold == 2){
                    if (lineageDisplayOption == 0){
                        if (averageTotalFlag == 0) liveValueGet = (int)horizontalLineListValue [counter1*2];
                        else liveValueGet = (int)horizontalLineListValue [counter1*2+1];
                        
                        if (averageTotalFlag == 0){
                            rangeDivision = (rangeLiveAverageHigh-rangeLiveAverageLow)/(double)25;
                            
                            if (liveValueGet <= rangeLiveAverageLow+rangeDivision) rangeNo = 1;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*2) rangeNo = 2;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*3) rangeNo = 3;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*4) rangeNo = 4;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*5) rangeNo = 5;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*6) rangeNo = 6;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*7) rangeNo = 7;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*8) rangeNo = 8;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*9) rangeNo = 9;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*10) rangeNo = 10;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*11) rangeNo = 11;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*12) rangeNo = 12;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*13) rangeNo = 13;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*14) rangeNo = 14;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*15) rangeNo = 15;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*16) rangeNo = 16;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*17) rangeNo = 17;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*18) rangeNo = 18;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*19) rangeNo = 19;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*20) rangeNo = 20;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*21) rangeNo = 21;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*22) rangeNo = 22;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*23) rangeNo = 23;
                            else rangeNo = 24;
                            
                            if (liveValueGet == -1) rangeNo = 105/3+1;
                            
                            [[NSColor colorWithCalibratedRed:arrayColorRange [(rangeNo-1)*3] green:arrayColorRange [(rangeNo-1)*3+1] blue:arrayColorRange [(rangeNo-1)*3+2] alpha:1] set];
                            
                            positionAA.x = 40*magFactor+horizontalList2 [counter1*7+3]*horizontalIncrement*magFactor;
                            positionAA.y = 52*magFactor+increment*magFactor+counter1*increment*magFactor;
                            
                            if (endType == 1) positionBB.x = 40*magFactor+(horizontalList2 [counter1*7+4]+1)*horizontalIncrement*magFactor;
                            else positionBB.x = 40*magFactor+horizontalList2 [counter1*7+4]*horizontalIncrement*magFactor;
                            
                            positionBB.y = 52*magFactor+increment+counter1*increment*magFactor;
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                        else{
                            
                            rangeDivision = (rangeLiveTotalHigh-rangeLiveTotalLow)/(double)25;
                            
                            if (liveValueGet <= rangeLiveTotalLow+rangeDivision) rangeNo = 1;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*2) rangeNo = 2;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*3) rangeNo = 3;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*4) rangeNo = 4;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*5) rangeNo = 5;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*6) rangeNo = 6;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*7) rangeNo = 7;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*8) rangeNo = 8;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*9) rangeNo = 9;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*10) rangeNo = 10;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*11) rangeNo = 11;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*12) rangeNo = 12;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*13) rangeNo = 13;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*14) rangeNo = 14;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*15) rangeNo = 15;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*16) rangeNo = 16;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*17) rangeNo = 17;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*18) rangeNo = 18;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*19) rangeNo = 19;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*20) rangeNo = 20;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*21) rangeNo = 21;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*22) rangeNo = 22;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*23) rangeNo = 23;
                            else rangeNo = 24;
                            
                            if (liveValueGet == -1) rangeNo = 105/3+1;
                            
                            [[NSColor colorWithCalibratedRed:arrayColorRange [(rangeNo-1)*3] green:arrayColorRange [(rangeNo-1)*3+1] blue:arrayColorRange [(rangeNo-1)*3+2] alpha:1] set];
                            
                            positionAA.x = 40*magFactor+horizontalList2 [counter1*7+3]*horizontalIncrement*magFactor;
                            positionAA.y = 52*magFactor+increment*magFactor+counter1*increment*magFactor;
                            
                            if (endType == 1) positionBB.x = 40*magFactor+(horizontalList2 [counter1*7+4]+1)*horizontalIncrement*magFactor;
                            else positionBB.x = 40*magFactor+horizontalList2 [counter1*7+4]*horizontalIncrement*magFactor;
                            
                            positionBB.y = 52*magFactor+increment*magFactor+counter1*increment*magFactor;
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                    }
                    else{
                        
                        if (horizontalLineListValue [counter1*2] == -1 || horizontalLineListValue [counter1*2] == -100) rangeNo = 105;
                        else rangeNo = (int)(horizontalLineListValue [counter1*2]);
                        
                        [[NSColor colorWithCalibratedRed:arrayColorRange [rangeNo] green:arrayColorRange [rangeNo+1] blue:arrayColorRange [rangeNo+2] alpha:1] set];
                        
                        positionAA.x = 40*magFactor+horizontalList2 [counter1*7+3]*horizontalIncrement*magFactor;
                        positionAA.y = 52*magFactor+increment*magFactor+counter1*increment*magFactor;
                        
                        if (endType == 1) positionBB.x = 40*magFactor+(horizontalList2 [counter1*7+4]+1)*horizontalIncrement*magFactor;
                        else positionBB.x = 40*magFactor+horizontalList2 [counter1*7+4]*horizontalIncrement*magFactor;
                        
                        positionBB.y = 52*magFactor+increment*magFactor+counter1*increment*magFactor;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    }
                }
                else if (drawingOptionHold == 4){
                    if (lineageDisplayOption == 0){
                        if (averageTotalFlag == 0) liveValueGet = (int)horizontalLineListValue [counter1*2];
                        else liveValueGet = (int)horizontalLineListValue [counter1*2+1];
                        
                        if (averageTotalFlag == 0){
                            rangeDivision = (rangeAverageHigh-rangeAverageLow)/(double)25;
                            
                            if (liveValueGet <= rangeAverageLow+rangeDivision) rangeNo = 1;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*2) rangeNo = 2;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*3) rangeNo = 3;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*4) rangeNo = 4;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*5) rangeNo = 5;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*6) rangeNo = 6;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*7) rangeNo = 7;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*8) rangeNo = 8;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*9) rangeNo = 9;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*10) rangeNo = 10;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*11) rangeNo = 11;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*12) rangeNo = 12;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*13) rangeNo = 13;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*14) rangeNo = 14;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*15) rangeNo = 15;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*16) rangeNo = 16;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*17) rangeNo = 17;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*18) rangeNo = 18;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*19) rangeNo = 19;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*20) rangeNo = 20;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*21) rangeNo = 21;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*22) rangeNo = 22;
                            else if (liveValueGet < rangeAverageLow+rangeDivision*23) rangeNo = 23;
                            else rangeNo = 24;
                            
                            if (liveValueGet == -1) rangeNo = 105/3+1;
                            
                            [[NSColor colorWithCalibratedRed:arrayColorRange [(rangeNo-1)*3] green:arrayColorRange [(rangeNo-1)*3+1] blue:arrayColorRange [(rangeNo-1)*3+2] alpha:1] set];
                            
                            positionAA.x = 40*magFactor+horizontalList2 [counter1*7+3]*horizontalIncrement*magFactor;
                            positionAA.y = 52*magFactor+increment*magFactor+counter1*increment*magFactor;
                            
                            if (endType == 1) positionBB.x = 40*magFactor+(horizontalList2 [counter1*7+4]+1)*horizontalIncrement*magFactor;
                            else positionBB.x = 40*magFactor+horizontalList2 [counter1*7+4]*horizontalIncrement*magFactor;
                            
                            positionBB.y = 52*magFactor+increment*magFactor+counter1*increment*magFactor;
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                        else{
                            
                            rangeDivision = (rangeTotalHigh-rangeTotalLow)/(double)25;
                            
                            if (liveValueGet < rangeLiveTotalLow+rangeDivision) rangeNo = 1;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*2) rangeNo = 2;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*3) rangeNo = 3;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*4) rangeNo = 4;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*5) rangeNo = 5;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*6) rangeNo = 6;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*7) rangeNo = 7;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*8) rangeNo = 8;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*9) rangeNo = 9;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*10) rangeNo = 10;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*11) rangeNo = 11;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*12) rangeNo = 12;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*13) rangeNo = 13;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*14) rangeNo = 14;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*15) rangeNo = 15;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*16) rangeNo = 16;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*17) rangeNo = 17;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*18) rangeNo = 18;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*19) rangeNo = 19;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*20) rangeNo = 20;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*21) rangeNo = 21;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*22) rangeNo = 22;
                            else if (liveValueGet < rangeTotalLow+rangeDivision*23) rangeNo = 23;
                            else rangeNo = 24;
                            
                            if (liveValueGet == -1) rangeNo = 105/3+1;
                            
                            [[NSColor colorWithCalibratedRed:arrayColorRange [(rangeNo-1)*3] green:arrayColorRange [(rangeNo-1)*3+1] blue:arrayColorRange [(rangeNo-1)*3+2] alpha:1] set];
                            
                            positionAA.x = 40*magFactor+horizontalList2 [counter1*7+3]*horizontalIncrement*magFactor;
                            positionAA.y = 52*magFactor+increment*magFactor+counter1*increment*magFactor;
                            
                            if (endType == 1) positionBB.x = 40*magFactor+(horizontalList2 [counter1*7+4]+1)*horizontalIncrement*magFactor;
                            else positionBB.x = 40*magFactor+horizontalList2 [counter1*7+4]*horizontalIncrement*magFactor;
                            
                            positionBB.y = 52*magFactor+increment*magFactor+counter1*increment*magFactor;
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                    }
                    else{
                        
                        if (horizontalLineListValue [counter1*2] == -1 || horizontalLineListValue [counter1*2] == -100) rangeNo = 105;
                        else rangeNo = (int)(horizontalLineListValue [counter1*2]);
                        
                        [[NSColor colorWithCalibratedRed:arrayColorRange [rangeNo] green:arrayColorRange [rangeNo+1] blue:arrayColorRange [rangeNo+2] alpha:1] set];
                        
                        positionAA.x = 40*magFactor+horizontalList2 [counter1*7+3]*horizontalIncrement*magFactor;
                        positionAA.y = 52*magFactor+increment*magFactor+counter1*increment*magFactor;
                        
                        if (endType == 1) positionBB.x = 40*magFactor+(horizontalList2 [counter1*7+4]+1)*horizontalIncrement*magFactor;
                        else positionBB.x = 40*magFactor+horizontalList2 [counter1*7+4]*horizontalIncrement*magFactor;
                        
                        positionBB.y = 52*magFactor+increment*magFactor+counter1*increment*magFactor;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    }
                }
                
                for (int counter2 = 0; counter2 < eventListCount2/5; counter2++){
                    if (eventList2 [counter2*5+4] == counter1){
                        if (eventList2 [counter2*5+3] == 91 || eventList2 [counter2*5+3] == 92){
                            [[NSColor orangeColor] set];
                            pathCircle = [NSBezierPath bezierPathWithOvalInRect:NSMakeRect(40*magFactor+eventList2 [counter2*5+2]*horizontalIncrement*magFactor-6*magFactor, 48*magFactor+increment*magFactor+counter1*increment*magFactor, markerSizeSet*magFactor, markerSizeSet*magFactor)];
                            
                            [pathCircle fill];
                        }
                        else if (eventList2 [counter2*5+3] == 6){
                            [[NSColor cyanColor] set];
                            pathCircle = [NSBezierPath bezierPathWithOvalInRect:NSMakeRect(40*magFactor+eventList2 [counter2*5+2]*horizontalIncrement*magFactor-6*magFactor, 48*magFactor+increment*magFactor+counter1*increment*magFactor, markerSizeSet*magFactor, markerSizeSet*magFactor)];
                            [pathCircle fill];
                        }
                        else if (eventList2 [counter2*5+3] == 7){
                            [[NSColor magentaColor] set];
                            path = [NSBezierPath bezierPathWithRect: NSMakeRect(40*magFactor+eventList2 [counter2*5+2]*horizontalIncrement*magFactor-6*magFactor, 48*magFactor+increment*magFactor+counter1*increment*magFactor, markerSizeSet*magFactor, markerSizeSet*magFactor)];
                            [path fill];
                        }
                        else if (eventList2 [counter2*5+3] == 8){
                            [[NSColor grayColor] set];
                            path = [NSBezierPath bezierPathWithRect: NSMakeRect(40*magFactor+eventList2 [counter2*5+2]*horizontalIncrement*magFactor-6*magFactor, 48*magFactor+increment*magFactor+counter1*increment*magFactor, markerSizeSet*magFactor, markerSizeSet*magFactor)];
                            [path fill];
                        }
                        else if (eventList2 [counter2*5+3] == 10){
                            [[NSColor redColor] set];
                            path = [NSBezierPath bezierPathWithRect: NSMakeRect(40*magFactor+eventList2 [counter2*5+2]*horizontalIncrement*magFactor-6*magFactor, 48*magFactor+increment*magFactor+counter1*increment*magFactor, markerSizeSet*magFactor, markerSizeSet*magFactor)];
                            [path stroke];
                        }
                        else if (eventList2 [counter2*5+3] == 11){
                            [[NSColor blueColor] set];
                            path = [NSBezierPath bezierPathWithRect: NSMakeRect(40*magFactor+eventList2 [counter2*5+2]*horizontalIncrement*magFactor-6*magFactor, 48*magFactor+increment*magFactor+counter1*increment*magFactor, markerSizeSet*magFactor, markerSizeSet*magFactor)];
                            [path fill];
                        }
                    }
                }
                
                if (startType == 0){
                    if (to_string(horizontalList2 [counter1*7+3]).length() == 1) positionShiftA = 7;
                    else if (to_string(horizontalList2 [counter1*7+3]).length() == 2) positionShiftA = 14;
                    else if (to_string(horizontalList2 [counter1*7+3]).length() == 3) positionShiftA = 21;
                    else if (to_string(horizontalList2 [counter1*7+3]).length() == 4) positionShiftA = 28;
                    
                    if ((int)to_string(horizontalList2 [counter1*7+3]).find (".") != -1) horizontalString = to_string(horizontalList2 [counter1*7+3]).substr(0, to_string(horizontalList2 [counter1*7+3]).find ("."));
                    else horizontalString = to_string(horizontalList2 [counter1*7+3]);
                    
                    attrStrA = [[NSAttributedString alloc] initWithString:@(horizontalString.c_str()) attributes:attributesA];
                    pointA.x = 40*magFactor+horizontalList2 [counter1*7+3]*horizontalIncrement*magFactor-positionShiftA*magFactor;
                    pointA.y = 47*magFactor+increment*magFactor+counter1*increment*magFactor;
                    [attrStrA drawAtPoint:pointA];
                }
                else{
                    
                    [attributesA setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
                    
                    if (to_string(horizontalList2 [counter1*7+1]).length() == 1) positionShiftA = 7;
                    else if (to_string(horizontalList2 [counter1*7+1]).length() == 2) positionShiftA = 11;
                    else if (to_string(horizontalList2 [counter1*7+1]).length() == 3) positionShiftA = 17;
                    else if (to_string(horizontalList2 [counter1*7+1]).length() == 4) positionShiftA = 24;
                    
                    if ((int)to_string(horizontalList2 [counter1*7+1]).find (".") != -1) horizontalString = to_string(horizontalList2 [counter1*7+1]).substr(0, to_string(horizontalList2 [counter1*7+1]).find ("."));
                    else horizontalString = to_string(horizontalList2 [counter1*7+1]);
                    
                    attrStrA = [[NSAttributedString alloc] initWithString:@(horizontalString.c_str()) attributes:attributesA];
                    pointA.x = 40*magFactor+horizontalList2 [counter1*7+3]*horizontalIncrement*magFactor-positionShiftA*magFactor;
                    pointA.y = 47*magFactor+increment*magFactor+counter1*increment*magFactor;
                    [attrStrA drawAtPoint:pointA];
                }
                
                [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                
                if (endType == 1){
                    if (to_string(horizontalList2 [counter1*7+4]+1).length() == 1) positionShiftA = 1;
                    else if (to_string(horizontalList2 [counter1*7+4]+1).length() == 2) positionShiftA = 2;
                    else if (to_string(horizontalList2 [counter1*7+4]+1).length() == 3) positionShiftA = 3;
                    else if (to_string(horizontalList2 [counter1*7+4]+1).length() == 4) positionShiftA = 4;
                    
                    if ((int)to_string(horizontalList2 [counter1*7+4]).find (".") != -1) horizontalString = to_string(horizontalList2 [counter1*7+4]).substr(0, to_string(horizontalList2 [counter1*7+4]).find ("."));
                    else horizontalString = to_string(horizontalList2 [counter1*7+4]);
                    
                    if (endNumberFlag == 0){
                        attrStrA = [[NSAttributedString alloc] initWithString:@(horizontalString.c_str()) attributes:attributesA];
                        pointA.x = 40*magFactor+(horizontalList2 [counter1*7+4]+1)*horizontalIncrement*magFactor+positionShiftA*magFactor;
                        pointA.y = 47*magFactor+increment*magFactor+counter1*increment*magFactor;
                        [attrStrA drawAtPoint:pointA];
                    }
                }
                else{
                    
                    if (to_string(horizontalList2 [counter1*7+4]).length() == 1) positionShiftA = 1;
                    else if (to_string(horizontalList2 [counter1*7+4]).length() == 2) positionShiftA = 2;
                    else if (to_string(horizontalList2 [counter1*7+4]).length() == 3) positionShiftA = 3;
                    else if (to_string(horizontalList2 [counter1*7+4]).length() == 4) positionShiftA = 4;
                    
                    if ((int)to_string(horizontalList2 [counter1*7+4]).find (".") != -1) horizontalString = to_string(horizontalList2 [counter1*7+4]).substr(0, to_string(horizontalList2 [counter1*7+4]).find ("."));
                    else horizontalString = to_string(horizontalList2 [counter1*7+4]);
                    
                    if (endNumberFlag == 0){
                        attrStrA = [[NSAttributedString alloc] initWithString:@(horizontalString.c_str()) attributes:attributesA];
                        pointA.x = 40*magFactor+horizontalList2 [counter1*7+4]*horizontalIncrement*magFactor+positionShiftA*magFactor;
                        pointA.y = 47*magFactor+increment*magFactor+counter1*increment*magFactor;
                        [attrStrA drawAtPoint:pointA];
                    }
                }
                
                if ((int)to_string(horizontalList2 [counter1*7+2]).find (".") != -1) horizontalString = to_string(horizontalList2 [counter1*7+2]).substr(0, to_string(horizontalList2 [counter1*7+2]).find ("."));
                else horizontalString = to_string(horizontalList2 [counter1*7+2]);
                
                cellNumberString = "C"+horizontalString;
                
                if (cellNumberFlag == 0){
                    attrStrA = [[NSAttributedString alloc] initWithString:@(cellNumberString.c_str()) attributes:attributesA];
                    pointA.x = 40*magFactor+((horizontalList2 [counter1*7+4]+horizontalList2 [counter1*7+3])/(double)2)*horizontalIncrement*magFactor-5*magFactor;
                    pointA.y = 53*magFactor+increment*magFactor+counter1*increment*magFactor;
                    [attrStrA drawAtPoint:pointA];
                }
            }
            
            //for (int counterA = 0; counterA < lineageFluorescentDataTypeEntryCount; counterA++){
            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageFluorescentDataType [counterA][counterB];
            //    cout<<" arrayLineageFluorescentDataType "<<counterA+1<<endl;
            //}
            
            //for (int counterA = 0; counterA < 1; counterA++){
            //    for (int counterB = 0; counterB < findMainLength; counterB++) cout<<" "<< arrayTableMain [tableCurrentRowHold][counterA+counterB];
            //    cout<<"  arrayTableMain "<<counterA<<endl;
            //}
            
            delete [] horizontalList;
            delete [] horizontalList2;
            delete [] eventList;
            delete [] eventList2;
            delete [] verticalList;
            delete [] liveTimeList;
            delete [] rangeList;
            delete [] cellExtractedInfo;
            delete [] cellNoList;
            delete [] horizontalLineList;
            delete [] horizontalLineListValue;
            delete [] cellExtractedInfoSummary;
        }
        
        [NSGraphicsContext restoreGraphicsState];
        
        NSData *imageExportData;
        imageExportData = [bitmapReps TIFFRepresentation];
        
        [imageExportData writeToFile:@(exportResultPath.c_str()) atomically:YES];
        
        exportFlag8 = 2;
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToMainWindowMagnification object:nil];
}

@end
