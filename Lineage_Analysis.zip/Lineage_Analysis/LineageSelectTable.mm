//
//  LineageSelectTable.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2017-06-08.
//
//

#import "LineageSelectTable.h"

NSString *notificationToLineageSelectTable = @"notificationExecuteLineageSelectTable";

@implementation LineageSelectTable

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToLineageSelectTable object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    [lineageSelectTable setDataSource:self];
    [lineageSelectTable reloadData];
}

-(int)numberOfRowsInTableView:(NSTableView *)aTableView{
    int tableViewContent = lineageSelectHoldCount/4;
    return tableViewContent;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    NSAttributedString *attrStr;
    
    if (initialArraySet == 1){
        string displayData1 = arrayLineageSelectHold [rowIndex*4];
        string displayData2 = arrayLineageSelectHold [rowIndex*4+1];
        string displayData3 = arrayLineageSelectHold [rowIndex*4+2];
        string displayData4 = arrayLineageSelectHold [rowIndex*4+3];
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData2.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL3"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData3.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL4"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData4.c_str()) attributes:attributes];
        }
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    else{
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL3"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL4"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    
    return attrStr;
}

-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex{
    lineageSelectOperationTableCount++;
    lineageSelectOperationTableCurrentRow = rowIndex;
    
    if (lineageSelectOperationTableCount == 2){
        if (upLoadingProgress == 0){
            lineageSelectOperationTableCurrentRow = rowLineageSelectOperationTable;
            
            if (arrayLineageSelectHold [trimOperationTableCurrentRow*4] != "SO"){
                unsigned long lineageEntrySize = arrayLineageDataEntryHold [lineageSelectOperationTableCurrentRow];
                
                int lineageEntryNo = 0;
                
                for (unsigned long counter3 = 0; counter3 < lineageEntrySize/9; counter3++){
                    if (arrayLineageData [lineageSelectOperationTableCurrentRow][counter3*9+6] > lineageEntryNo){
                        lineageEntryNo = arrayLineageData [lineageSelectOperationTableCurrentRow][counter3*9+6];
                    }
                }
                
                int *lineageSelList = new int [lineageEntryNo+10];
                
                for (int counter3 = 0; counter3 < lineageEntryNo+10; counter3++) lineageSelList [counter3] = -1;
                
                for (unsigned long counter3 = 0; counter3 < lineageEntrySize/9; counter3++){
                    lineageSelList [arrayLineageData [lineageSelectOperationTableCurrentRow][counter3*9+6]] = 0;
                }
                
                if (lineageEntryNo*3+10 > lineageSelectLineageHoldLimit){
                    delete [] arrayLineageSelectLineageHold;
                    arrayLineageSelectLineageHold = new int [lineageEntryNo*2+10];
                    lineageSelectLineageHoldLimit = lineageEntryNo*2+10;
                }
                
                lineageSelectLineageHoldCount = 0;
                
                for (int counter3 = 1; counter3 <= lineageEntryNo; counter3++){
                    if (lineageSelList [counter3] == 0){
                        arrayLineageSelectLineageHold [lineageSelectLineageHoldCount] = counter3, lineageSelectLineageHoldCount++;
                        arrayLineageSelectLineageHold [lineageSelectLineageHoldCount] = 1, lineageSelectLineageHoldCount++;
                    }
                    else{
                        
                        arrayLineageSelectLineageHold [lineageSelectLineageHoldCount] = counter3, lineageSelectLineageHoldCount++;
                        arrayLineageSelectLineageHold [lineageSelectLineageHoldCount] = 0, lineageSelectLineageHoldCount++;
                    }
                }
                
                delete [] lineageSelList;
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLineageSelectTable2 object:self];
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLineageSelectTable3 object:self];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Uploading In Progress"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        if (upLoadingProgress == 0){
            lineageSelectOperationTableCurrentRow = rowIndex;
            
            if (arrayLineageSelectHold [trimOperationTableCurrentRow*4] != "SO"){
                unsigned long lineageEntrySize = arrayLineageDataEntryHold [lineageSelectOperationTableCurrentRow];
                
                int lineageEntryNo = 0;
                
                for (unsigned long counter3 = 0; counter3 < lineageEntrySize/9; counter3++){
                    if (arrayLineageData [lineageSelectOperationTableCurrentRow][counter3*9+6] > lineageEntryNo){
                        lineageEntryNo = arrayLineageData [lineageSelectOperationTableCurrentRow][counter3*9+6];
                    }
                }
                
                int *lineageSelList = new int [lineageEntryNo+10];
                
                for (int counter3 = 0; counter3 < lineageEntryNo+10; counter3++) lineageSelList [counter3] = -1;
                
                for (unsigned long counter3 = 0; counter3 < lineageEntrySize/9; counter3++){
                    lineageSelList [arrayLineageData [lineageSelectOperationTableCurrentRow][counter3*9+6]] = 0;
                }
                
                if (lineageEntryNo*3+10 > lineageSelectLineageHoldLimit){
                    delete [] arrayLineageSelectLineageHold;
                    arrayLineageSelectLineageHold = new int [lineageEntryNo*2+10];
                    lineageSelectLineageHoldLimit = lineageEntryNo*2+10;
                }
                
                lineageSelectLineageHoldCount = 0;
                
                for (int counter3 = 1; counter3 <= lineageEntryNo; counter3++){
                    if (lineageSelList [counter3] == 0){
                        arrayLineageSelectLineageHold [lineageSelectLineageHoldCount] = counter3, lineageSelectLineageHoldCount++;
                        arrayLineageSelectLineageHold [lineageSelectLineageHoldCount] = 1, lineageSelectLineageHoldCount++;
                    }
                    else{
                        
                        arrayLineageSelectLineageHold [lineageSelectLineageHoldCount] = counter3, lineageSelectLineageHoldCount++;
                        arrayLineageSelectLineageHold [lineageSelectLineageHoldCount] = 0, lineageSelectLineageHoldCount++;
                    }
                }
                
                delete [] lineageSelList;
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLineageSelectTable2 object:self];
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLineageSelectTable3 object:self];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Uploading In Progress"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    
    return YES;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToLineageSelectTable object:nil];
}

@end
