//
//  LineageDataTable.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 9/7/16.
//
//

#ifndef LINEAGEDATATABLE_H
#define LINEAGEDATATABLE_H
#import "Controller.h"
#endif

@interface LineageDataTable : NSObject <NSTableViewDataSource>{
    int tableCallLTCount; //Table operation
    int tableCurrentLTRowHold; //Table operation
    int rowIndexLTHold; //Table operation
    int tableViewLTCall; //Table operation
    
    IBOutlet NSTableView *tableViewLTList;
    
    NSTimer *lineageDataTableTimer;
}

-(id)init;
-(void)dealloc;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;
-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex;
-(void)tableView:(NSTableView *)aTableView setObjectValue:(id)anObject forTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;

@end
