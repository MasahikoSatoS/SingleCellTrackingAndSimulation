//
//  ProgenyNoTable.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2017-05-10.
//
//

#ifndef PROGENYNOTABLE_H
#define PROGENYNOTABLE_H
#import "Controller.h" 
#endif

@interface ProgenyNoTable : NSObject <NSTableViewDataSource>{
    IBOutlet NSTableView *categoryProgenyTable;
}

-(id)init;
-(void)dealloc;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;

@end
