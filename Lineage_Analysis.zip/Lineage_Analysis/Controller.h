//
//  Controller.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 10/11/19.
//  Copyright 2010 Masahiko Sato. All rights reserved.
//

#ifndef CONTROLLER_H
#define CONTROLLER_H
#import <Cocoa/Cocoa.h>
#import "DetailTable.h"
#import "MainLineage.h"
#import "TypeDefinitionSet.h"
#import "LineageDataType.h"
#import "LineageDataFluorescent.h"
#import "LineageDataTable.h"
#import "DataUploading.h"
#import "SourceS.h"
#import "SourceSA.h"
#import "SourceSAT.h"
#import "StartAnalysis.h"
#import "SearchController.h"
#import "SearchOperationTable.h"
#import "LineageController.h"
#import "LineageDisplay.h"
#import "LineageListCondition.h"
#import "CellGrowthController.h"
#import "CellGrowthDisplay.h"
#import "CellGrowthCurveAddition.h"
#import "CellDivisionController.h"
#import "CellDivisionDisplay.h"
#import "DoublingTimeController.h"
#import "DoublingTimeDisplay.h"
#import "DoublingTimeAddition.h"
#import "ASCIIconversion.h"
#import "ProgenyNoController.h"
#import "ProgenyNoTable.h"
#import "ProgenyNoTable2.h"
#import "ProgenyAnalysisController.h"
#import "ProgenyAnalysisTable.h"
#import "ProgenyAnalysisTable2.h"
#import "EndTrimController.h"
#import "EndTrimTable.h"
#import "EndTrimTable2.h"
#import "LineageSelectController.h"
#import "LineageSelectTable.h"
#import "LineageSelectTable2.h"
#import "LineageSelectTable3.h"
#import "EventAnalysisController.h"
#import "EventAnalysisTable.h"
#import "MainWindowMagnificationController.h"
#import "MainWindowMagnification.h"
#import "DoubCompController.h"
#import "DoubCompTable.h"
#import "DoubCompTable2.h"
#import "MotilityController.h"
#import "MotilityDisplay.h"
#import "MotilityTable.h"
#import "MotilityDataSet.h"
#import "SimulationController.h"
#import "SimulationDisplay.h"
#import "SimulationTable.h"
#import "SimulationProcess.h"
#import "SimulationPerform.h"
#import "SimulationPerformMid.h"
#import "SimulationPerformProg.h"
#import "CreateNewCellNo.h"
#include <iostream>
#include <dirent.h>
#include <sys/stat.h>
#include <fstream>
#include <sstream>
#include <math.h>
#endif

using namespace std;

extern NSString *notificationToDetailTable;
extern NSString *notificationToMainLineage;
extern NSString *notificationToTypeDefinition;
extern NSString *notificationToLineageDataType;
extern NSString *notificationToLineageDataTable;
extern NSString *notificationToLineageDataFluorescentType;
extern NSString *notificationToDataUploading;

extern NSString *notificationToSearchController;
extern NSString *notificationToSearchOperationTable;
extern NSString *notificationToLineageController;
extern NSString *notificationToLineageListCondition;
extern NSString *notificationToLineageDisplay;

extern NSString *notificationToGrowthCurveController;
extern NSString *notificationToGrowthCurveDisplay;
extern NSString *notificationToGrowthCurveAddition;

extern NSString *notificationToCellDivisionController;
extern NSString *notificationToCellDivisionDisplay;
extern NSString *notificationToCellDivisionAddition;

extern NSString *notificationToDoublingTimeController;
extern NSString *notificationToDoublingTimeDisplay;
extern NSString *notificationToDoublingTimeAddition;

extern NSString *notificationToProgenyNoController;
extern NSString *notificationToProgenyNoTable;
extern NSString *notificationToProgenyNoTable2;

extern NSString *notificationToProgenyAnalysisController;
extern NSString *notificationToProgenyAnalysisTable;
extern NSString *notificationToProgenyAnalysisTable2;

extern NSString *notificationToTrimController;
extern NSString *notificationToTrimTable;
extern NSString *notificationToTrimTable2;

extern NSString *notificationToEventAnalysisController;
extern NSString *notificationToEventAnalysisTable;

extern NSString *notificationToLineageSelectController;
extern NSString *notificationToLineageSelectTable;
extern NSString *notificationToLineageSelectTable2;
extern NSString *notificationToLineageSelectTable3;

extern NSString *notificationToMainWindowMagnificationController;
extern NSString *notificationToMainWindowMagnification;

extern NSString *notificationToDoubCompController;
extern NSString *notificationToDoubCompTable;
extern NSString *notificationToDoubCompTable2;

extern NSString *notificationToMotilityController;
extern NSString *notificationToMotilityDisplay;
extern NSString *notificationToMotilityTable;
extern NSString *notificationToMotilityDataSet;

extern NSString *notificationToSimulationController;
extern NSString *notificationToSimulationDisplay;
extern NSString *notificationToSimulationTable;

//----Basic info----
extern int sourceStatusHold; //Source/Analysis status hold
extern int tableViewCall; //Table view call
extern int tableCurrentRowHold; //Table control
extern int progressTiming; //Progress indicator
extern int progressValue; //Progress value
extern int upLoadingProgress; //Upload progress
extern int upLoadingFlag; //Upload flag
extern string pathNameString; //Path name
extern string trackDataFolderPath; //Track data path
extern string analysisDataFolderPath; //Analysis data path
extern string seriesName; //Series name
extern string analysisID; //Analysis ID
extern string treatName; //Treat name
extern string exportResultPath; //Export path

//----Arrays----
extern string *arrayDirectoryInfo; //For file sorting
extern int directoryInfoCount;
extern int directoryInfoLimit;
extern int **arrayLineageData; //Hold Lineage data
extern unsigned long *arrayLineageDataEntryHold; //Hold no of Lineage data entry
extern int **arrayIFData; //Hold IF data, value and area, original
extern int *arrayIFDataEntryHold; //Hold IF data, no of value and area, original, entry hold
extern int **arrayIFTimeLineData; //IF data, Time point sorted
extern int *arrayIFTimeLineDataEntryHold; //IF data, Time point sorted, entry hold
extern string **arrayTableMain; //Main table info
extern int *arrayTableMainHold; //Main Table Entry no Hold
extern int **arrayTableDetail; //Detail table
extern int lineageDataEntryCount; //No of entered lineage data
extern int **arrayIfTimeStatus; //IF Time Status, 0, inc, 1: exc
extern int *arrayIfTimeStatusHold; //Hold number of entry of arrayIfTimeStatus
extern int **arrayAreaData; //Area data
extern int *arrayAreaDataHold; //Hold Number of Entry
extern int **arrayLineageLink; //Lineage link (fusion) list
extern int *lineageLinkHold; //Hold no of Lineage link (fusion) list entry
extern int firstReadFlag; //First array set flag
extern int initialArraySet; //Array set status hold
extern int *arraySelectedLing; //Hold selected lineage info

//----Type Definition----
extern string *arrayTypeDefinitionHold; //Hold Type Definition
extern int typeDefinitionCount;
extern int typeDefinitionLimit;
extern string *arrayTypeDefinitionHold2; //Hold Type Definition
extern int typeDefinitionCount2;
extern int typeDefinitionLimit2;
extern int typeDefTimerAdjustOperation; //Type Def window operation

//----Lineage Data Set----
extern string **arrayLineageDataType; //Hold Type Definition
extern string **arrayLineageFluorescentDataType; //Hold Type Definition
extern int lineageFluorescentDataTypeEntryCount;
extern int lineageFluorescentDataTypeEntryLimit;
extern int lineageDataAdjustOperation; //Lineage data type operation flag
extern int noOfFluorescentDisplay; //No of fluorescent for display
extern int displayEntryNo; //Display entry no
extern int lineageDataOpen; //Lineage data open status

//----Data uploading----
extern string analysisIDSelect; //Analysis ID (temp)
extern int analysisLoadOperation; //Analysis load window operation
extern string sourceAnalysisPath; //Source analysis path
extern string analysisSeriesNameSelect; //Analysis series name
extern string analysisImageNameSelect; //Analysis image name

//----Main Lineage Draw----
extern int *arrayLineageExtract; //Lineage extract array
extern unsigned long lineageExtractCount;
extern unsigned long lineageExtractLimit;
extern int *arrayLineageLinkList; //Lineage link (fusion) list
extern int lineageLinkListCount;
extern int lineageLinkListLimit;
extern int lineageLinkListLength;
extern int lineageDisplayPosition; //Hold Lineage no for display
extern int maxLingNo; //Hold no of Lineage
extern int liveCurrentCHNo; //Hold Live, CH no
extern int *ifDataExtract; //Hold IF data, CH no etc
extern int ifDataExtractCount;
extern int ifDataExtractLimit;
extern int *ifValueExtract; //Hold selected lineage of arrayIFData
extern int ifValueExtractCount;
extern int ifValueExtractLimit;
extern int *ifTimeExtract; //Hold IF time status info
extern int ifTimeExtractCount;
extern int ifTimeExtractLimit;
extern int *areaExtract; //Hold area info
extern int areaExtractCount;
extern int areaExtractLimit;
extern int ifCurrentCHNo; //Hold IF CH no
extern int ifCurrentTime; //Hold IF time

extern int *holdReviseLineage; //Revised lineage
extern unsigned long holdReviseLineageCount;
extern unsigned long holdReviseLineageLimit;
extern int holdReviseLineageStatus;
extern int *holdReviseIfData; //Revised IF data
extern int holdReviseIfDataCount;
extern int holdReviseIfDataLimit;
extern int holdReviseIfDataStatus;
extern int *holdReviseAreaData; //Revised area data
extern int holdReviseAreaDataCount;
extern int holdReviseAreaDataLimit;
extern int holdReviseAreaDataStatus;

extern int averageTotalFlag; //Display flag for Average/Total
extern int includeExcludeFlag; //Display flag for Include/Exclude Time point
extern int includeExcludeModification; //When inc/exc. is changes set the flag, for display warning
extern int lineageModification; //When lineage is changes set the flag, for display warning
extern int blueLineFlag; //Display flag for Vertical blue line
extern int cellNumberFlag; //Display flag for CellNumber
extern int lineWidthFlag; //Display flag for Line Width
extern int endNumberFlag; //Display flag for EndNumber
extern int markSizeFlag; //Display flag for Mark size

//----Others----
extern string *arrayFileDelete; //File sorting
extern int fileDeleteCount;
extern int fileDeleteLimit;
extern CGFloat *arrayColorRange; //Color range
extern CGFloat *arrayColorRange2; //Color range
extern int exportFlag1; //Data export flag
extern int exportFlag3; //Data export flag
extern int exportFlag5; //Data export flag
extern int exportFlag6; //Data export flag
extern int exportFlag7; //Data export flag
extern int exportFlag8; //Data export flag
extern int exportFlag9; //Data export flag
extern int exportFlag10; //Data export flag
extern int exportTiming; //export timing 

//----Search----
extern int searchWindowOperation; //Search Window Display status
extern string *arraySearchResultsHold; //Hold Search Results
extern int searchResultsHoldStatus;
extern int searchResultsHoldCount;
extern int searchResultsHoldLimit;
extern string *arrayDisplayForSearch; //For search display of main table
extern int displayForSearchStatus;
extern int displayForSearchCount;
extern int displayForSearchLimit;
extern string searchStatus1; //Logic parameters
extern string searchStatus2; //Logic parameters
extern string searchStatus3; //Logic parameters
extern string searchStatus4; //Logic parameters
extern string typeSearchName; //Display selections, info hold
extern string seriesSearchName; //Series name
extern string analysisSearchName; //Analysis name
extern string treatSearchName; //Treat name
extern int searchOperationTableCount; //Table operation
extern int rowSearchOperationTable; //Table operation
extern int searchOperationTableCurrentRow; //Table operation

//----Lineage----
extern int lineageWindowOperation; //Lineage Window Display status
extern int liveDisplayHold; //Display parameters, live
extern int ifOneAllHold; //IF one all status
extern int averageTotalSetHold; //Total average select
extern int blueLineDisplayHold; //Blue line display
extern int lingLineWidthHold; //Line width
extern int lineageOpen; //Set when Lineage is activated
extern string typeLing; //Ling type
extern string seriesLing; //Seriese Ling
extern string analysisLing; //Analysis Ling
extern string treatLing; //Treat ling
extern string displayNameCellLing; //Display name cell
extern string displayNameTreatLing; //Display name treat
extern string displayNameSeriesLing; //Display name series
extern string ifRangeLing;  //Display name if
extern int ifRangeHigh; //If high
extern int ifRangeLow; //If low
extern int ifStepperHold; //If stepper
extern int *arrayNoOfChList; //Time/ch array for lineage
extern int noOfChListStatus;
extern int noOfChListCount;
extern int selectCurrentLineage; //Select current position
extern int lineageCurrentPosition; //Lineage display start position
extern int lineageCurrentPositionHold; //Lineage display start position hold
extern int lingNo1; //Display lineage no
extern int lingNo2; //Display lineage no
extern int lingNo3; //Display lineage no
extern int lingNo4; //Display lineage no
extern int lingNo5; //Display lineage no
extern int lingNo6; //Display lineage no
extern int lingNo7; //Display lineage no
extern int lingNo8; //Display lineage no
extern int chNo1; //Display ch no
extern int siblingLingHold; //Sib ling no
extern int colorOptionLingHold; //Color option
extern int lineageListCall; //Execute lineage controller
extern int saveFlag; //Lineage display save flag
extern int *arrayLineageLinkListLGL; //Lineage link (fusion) list for ling display
extern int lineageLinkListLGLCount;
extern int lineageLinkListLGLLimit;
extern int lineageLinkListLGLLength;

//----Growth curve----
extern int growthCurveWindowOperation; //Window Display operation
extern int verticalScaleLowHold; //Vertical scale low
extern int verticalScaleHighHold; //Vertical scale high
extern int horizontalScaleLowHold; //Horizontal scale low
extern int horizontalScaleHighHold; //Horizontal scale high
extern int individualOverLayHold; //Individual overlay status
extern int normalizeStatusHold; //Normalize status
extern int verticalScaleMaxHold; //Vertical scale max
extern int horizontalScaleMaxHold; //Horizontal scale max
extern int growthCurveCall; //Growth curve cell
extern int growthCurveOpen; //Growth curve window open

//----Cell Division----
extern int cellDivisionWindowOperation; //Window Display operation
extern int horizontalScaleLowDivisionHold; //Horizontal scale low
extern int horizontalScaleHighDivisionHold; //Horizontal scale high
extern int verticalScaleHighUpDivisionHold; //Vertical scale low
extern int verticalScaleHighDownDivisionHold; //Vertical scale high
extern int belowDisplayType; //Below display type
extern int verticalScaleMaxUpDivisionHold; //Vertical scale up max
extern int verticalScaleMaxDownDivisionHold; //Vertical scale down max
extern int horizontalScaleMaxDivisionHold; //Horizontal scale max
extern int cellDivisionCall; //Cell division call
extern int cellDivisionOpen; //Cell division window open
extern int maxDDNumberHold; //Max division number
extern int maxOtherHold; //Max others

//----Doubling time----
extern int doublingTimeWindowOperation; //Window Display operation
extern int horizontalScaleLowDoublingTimeHold; //Horizontal scale low
extern int horizontalScaleHighDoublingTimeHold; //Horizontal scale high
extern int verticalScaleHighDoublingHold; //Vertical scale low
extern int verticalScaleMaxDoublingTimeHold; //Vertical scale high
extern int horizontalScaleMaxDoublingTimeHold; //Horizontal scale max
extern int doublingTimeCall; //Doubling time call
extern int doublingTimeOpen; //Doubling time window open
extern int rangeDoubleSt1; //Range start
extern int rangeDoubleSt2; //Range start
extern int rangeDoubleSt3; //Range start
extern int rangeDoubleSt4; //Range start
extern int rangeDoubleEd1; //Range end
extern int rangeDoubleEd2; //Range end
extern int rangeDoubleEd3; //Range end
extern int rangeDoubleEd4; //Range end

//----Progeny No----
extern int progenyNoWindowOperation; //Window Display operation
extern string *arrayCategoryResultsHold; //Hold category Results
extern int categoryResultsHoldStatus;
extern int categoryResultsHoldCount;
extern int categoryResultsHoldLimit;
extern int *arrayCategoryRangeHold; //Hold category range Results
extern int categoryRangeHoldStatus;
extern int categoryRangeHoldCount;

//----Progeny Analysis----
extern int progenyAnalysisWindowOperation; //Window Display operation
extern string *arrayProgenyAnalysisResultsHold; //Hold category Results
extern int progenyAnalysisResultsHoldStatus;
extern int progenyAnalysisResultsHoldCount;
extern int progenyAnalysisResultsHoldLimit;
extern int *arrayProgenyAnalysisRangeHold; //Hold category range Results
extern int progenyAnalysisRangeHoldStatus;
extern int progenyAnalysisRangeHoldCount;

//----Trim and merge----
extern int trimWindowOperation; //Window Display operation
extern string *arrayTrimResultsHold; //Hold Trim Results
extern int trimResultsHoldStatus;
extern int trimResultsHoldCount;
extern string *arrayMergeResultsHold; //Hold Trim Results
extern int mergeResultsHoldStatus;
extern int mergeResultsHoldCount;
extern int trimOperationTableCount; //Trim table operation
extern int rowTrimOperationTable; //Trim table operation
extern int trimOperationTableCurrentRow; //Trim table operation
extern int mergeOperationTableCount; //Merge table operation
extern int rowMergeOperationTable; //Merge table operation
extern int mergeOperationTableCurrentRow; //Merge table operation
extern int trimCall; //Trim call
extern int trimOpen; //Trim window open
extern int includeTDHDStatusHold; //TD HD include status
extern int doublingTimeSimulateHold; //Doubling time simulation gold
extern int lineageCutStatusHold; //Lineage cut status
extern int progenitorIncludeHold; //Progenitor include status

//----Event Analysis----
extern int eventAnalysisWindowOperation; //Window Display operation
extern string *arrayEventAnalysisResultsHold; //Hold event analysis Results
extern int eventAnalysisResultsHoldStatus;
extern int eventAnalysisResultsHoldCount;
extern int eventAnalysisResultsHoldLimit;

//----Lineage select----
extern int lineageSelectWindowOperation; //Window Display operation
extern string *arrayLineageSelectHold; //Hold Analysis/Series info
extern int lineageSelectHoldStatus;
extern int lineageSelectHoldCount;
extern int *arrayLineageSelectLineageHold; //Hold selected/non selected ling info
extern int lineageSelectLineageHoldStatus;
extern int lineageSelectLineageHoldCount;
extern int lineageSelectLineageHoldLimit;
extern int lineageSelectOperationTableCount; //Select table operation
extern int rowLineageSelectOperationTable; //Select table operation
extern int lineageSelectOperationTableCurrentRow; //Select table operation
extern int lineageSelectNonSelOperationTableCount; //Non select table operation
extern int rowLineageSelectNonOperationTable; //non select table operation
extern int lineageSelectNonOperationTableCurrentRow; //Non select table operation
extern int lineageSelectSelOperationTableCount; //Select selected table operation
extern int rowLineageSelectSelOperationTable; //Select selected table operation
extern int lineageSelectSelOperationTableCurrentRow; //Select selected table operation
extern int lineageSelectCall; //Lineage selection call
extern int lineageSelectOpen; //Lineage selection window open
extern int fusionMoveStatus; //Fusion move status

//----For PDF call/data export----
extern string ascIIstring; //AscII string data

//----Main Window Magnification ----
extern int mainWindowMagOperation; //Window Display operation
extern int lineageDisplayOption; //Hold Lineage Display option
extern int lowXlow; //Low x Low parameter
extern int highXhigh; //High x High parameter
extern int lowXhigh; //Low x High parameter
extern int valueUK; //Value unknown
extern int mainWindowMagOpen; //Main window open
extern int drawingOptionHold; //Drawing option
extern int unknownOptionHold; //Unknown option
extern int unknownPriorityHold; //Unknown priority

//----Doubling time comparison ----
extern int doubCompOperation; //Window Display operation
extern int *arrayDoubleCompRangeHold; //Hold category range Results
extern int progenyDoubleCompHoldStatus;
extern int progenyDoubleCompHoldCount;
extern string *arrayProgenyDoubleCompResultsHold; //Hold category Results
extern int progenyDoubleCompResultsHoldStatus;
extern int progenyDoubleCompResultsHoldCount;
extern int progenyDoubleCompResultsHoldLimit;

//----Motility ----
extern int motilityOperation; //Window Display operation
extern string *arrayMotilityResultsHold; //Hold category range Results
extern int motilityResultsHoldStatus;
extern int motilityResultsHoldCount;
extern int motilityResultsHoldLimit;
extern int motilityColorHold; //Motility color
extern int markerStartColorHold; //Marker Start color
extern int markerEndColorHold; //Marker End color
extern int markerMidColorHold; //Marker Mid color
extern int markerMidValueHold; //Marker Mid value
extern int motilityColorStatusHold; //Motility color status
extern int motilityDisplayScaleMaxHold; //Display scale max
extern int motilityVerticalStartHold; //Vertical start
extern int motilityHorizontalStartHold; //Horizontal start
extern int motilityTimeStartHold; //Motility time start
extern int motilityTimeEndHold; //Motility time end
extern int motilityTableCategoryHold; //Table category
extern string motilityLineageHold; //Motility lineage
extern int motilityCellNoHold; //Motility Cell no
extern int motilityAnalysisPerformHold; //Motility analysis perform
extern string motilityTreatmentHold; //Motility treatment
extern int motilityOperationTableCount; //Motility table operation
extern int rowMotilityOperationTable; //Motility table operation
extern int motilityOperationTableCurrentRow; //Motility table operation
extern string motilityRangeVertical; //Motility range vertical
extern string motilityRangeHorizontal; //Motility range horizontal

extern int activationStatus; //Activation status
extern int displayOptionStatus; //Display option
extern int fixSizeHold; //Fixed size
extern double shiftX; //x Shift
extern double shiftY; //y Shift
extern int lingLineWidthMortHold; //Line width Print
extern int lingLineWidthDisplayMortHold; //Line width Display

//----SIMULATION ----
extern int simulationOperation; //Window Display operation
extern double fitA1Hold; //Fit line
extern double fitA2Hold; //Fit line
extern double fitA3Hold; //Fit line
extern double fitA4Hold; //Fit line
extern double fitB1Hold; //Fit line
extern double fitB2Hold; //Fit line
extern double fitB3Hold; //Fit line
extern double fitB4Hold; //Fit line
extern int fitCycleHold; //Fit cycle
extern double fitRangeBEndHold; //Fit range
extern int fitTimeStartHold; //Fit time
extern int fitModeStatusHold; //Fit mode

extern int colorNoSimHold; //Color no
extern int *simColorDataHold; //Color data
extern int simColorDataHoldStatus;
extern int simStartModeHold;
extern double *simProcessDataBaseHold; //Sim data base
extern double *simProcessDataMiddleHold; //Sim data middle
extern double *simProcessDataProgHold; //Sim data prog
extern double *simProcessDataAddHold; //Sim data add
extern int simProcessDataHoldStatus; //Sim data status

extern int growthProgTimeStartHold; //Growth prog start time
extern int growthProgTimeEndHold; //Growth prog time end
extern int growthMidTimeStartHold; //Growth mid time
extern int growthCycleHold; //Growth cycle
extern int growthInitHold; //Growth initial cell number

extern string *arraySimListHold; //Treat list for sim
extern int simListHoldStatus;
extern int simListHoldCount;
extern int simOperationTableCurrentRow; //Table operation
extern double *arrayFitDataHold; //File sort
extern int fitDataHoldStatus;
extern int fitDataHoldCount;
extern int processSimType; //Process type
extern int limitSimType; //Limit set
extern int simulationCall; //Simulation call
extern int simulationOpen; //Simulation window open

extern int *simulationDistributionData; //Sim distribution data base
extern int simulationDistributionDataCount;
extern int *simulationFluorescentData; //Sim fluorescent data base
extern int simulationFluorescentDataCount;
extern int *simulationDistributionProgData; //Sim distribution data prog
extern int simulationDistributionProgDataCount;
extern int *simulationDistributionMidData; //Sim distribution data mid
extern int simulationDistributionMidDataCount;
extern int *simulationDistributionAddData; //Sim distribution data add
extern int simulationDistributionAddDataCount;
extern int simulationDistributionDataStatus; //Data status
extern int simulationFluorescentDataStatus; //Data status

extern int recoveryCalculationPercentHold; //Recovery percent
extern int *activeCellStatusList; //Active cell list
extern int activeCellStatusListCount;
extern int activeCellStatusListLimitHold;
extern int *cellLineageTempArray; //Temp lineage
extern unsigned long cellLineageTempArrayCount;
extern unsigned long cellLineageTempArrayLimit;
extern long *cellLineageSummaryArray; //Cell lineage summary
extern unsigned long cellLineageSummaryArrayCount;
extern unsigned long cellLineageSummaryArrayLimit;
extern int performDataStatus; //Perform data status
extern int *activeCellStatusListKeep; //Active cell kept
extern unsigned long activeCellStatusListKeepCount;
extern unsigned long activeCellStatusListKeepLimit;
extern int *cellNoLingNoList; //Cell no list
extern unsigned long cellNoLingNoListCount;
extern unsigned long cellNoLingNoListLimit;

extern int terminateSimFlag; //Terminate flag
extern int terminateSimFlag2; //Terminate flag
extern int backSaveOn; //Progress monitor
extern int backSaveOn2; //Progress monitor
extern int simulationProgress; //Simulation progress
extern string processingStatus; //Progress status
extern int processingStatusCall; //Progress status call
extern string processingStatus2; //Progress status
extern int processingStatusCall2; //Progress status call
extern string processingStatus3; //Progress status
extern int processingStatusCall3; //Progress status call
extern string processingStatus4; //Progress status
extern int processingStatusCall4; //Progress status call
extern string messageStringSim; //Message
extern string messageStringSim2; //Message
extern string messageStringSim3; //Message
extern string messageStringSim4; //Message

extern int *cellGrowthCount; //Cell growth count
extern int *cellNoListForSelectLing; //Cell no list
extern int cellNoListForSelectLingCount;
extern int cellGrowthCountTimeEnd; //Cell growth count end
extern int timingSimCount; //Trimming
extern int simDimension; //Sim dimension
extern string displayImageAllPath; //Image path
extern string displayImageSavePath; //Save path
extern int **mapPositionHeld; //Map position
extern int **mapCellNoHeld; //Map cell
extern int **mapLingNoHeld; //Map lineage
extern int *cellEventTypeListTime; //Event type list
extern int cellEventTypeListTimeCount;
extern int movieDistanceSet; //Movie distance set
extern int movieDistanceHold; //Movie distance
extern int movieDistanceHold2; //Movie distance
extern int movieDistanceHold3; //Movie distance time
extern int movieDistanceTime2; //Movie distance time
extern int movieDistanceTime3; //Movie distance time
extern int movieDistanceRedStatus; //Movie distance reduction
extern int circleSizeHold; //Circle size
extern int circleSizeRedStatus; //Circle size status
extern int videoColorStatus; //Video color

extern int doseSimStatusHold; //Dose sim status
extern double doseBaseHold; //Dose base
extern double doseMiddleHold; //Dose mid
extern double doseTargetHold; //Dose target
extern double endVariationHold; //End variation
extern int selectLingNoHold; //Selected ling no
extern int lingSetDisplayCall; //Ling set display call
extern int *lingNoAssignSim; //Ling no assign
extern int lingNoAssignSimCount;
extern int lingNoAssignSimStatus;

extern string messageLingSim; //Message
extern string messageLingSim2; //Message
extern string messageLingSim3; //Message
extern string messageLingSim4; //Message
extern string messageLingSim5; //Message
extern string messageLingSim6; //Message
extern string messageLingSim7; //Message
extern string messageLingSim8; //Message
extern int databaseLoadOptionHold; //Database load option
extern int circleMinHold; //Circle min hold
extern int simGraphModeHold; //Sim graph mode
extern int titleFontExport; //Title font
extern int videoImageSizeHold; //Video image size
extern int videoImageSizeOptionHold; //Video image option
extern int colorToneChangeTimeHold; //Color tone change
extern int colorToneChangeOptionHold; //Color tone change option

extern int imageSimNoCount; //Image sim no count
extern int drawFlag; //Drawing flag
extern int lingNoSim; //Ling no sim
extern double *lingColorListSim; //Ling color list
extern int fluorescentSimSetNo; //Fluorescent no sim
extern int fluorescentDropHold; //Fluorescent drop frequency (0-100)

extern int maxEntryNoList;
extern int listEntryNoList;

//**********arrayLineageData**********
//1. X Position
//2. Y Position
//3. Time Point
//4. Event Type
//[1: I, 2: P, DStart:31, DEnd: 32, 33, TStart:41, TEnd: 42, 43, 44, HStart: 51, HEnd: 52, 53, 54, 55, M: 6, CD: 7, OF: 8, FUEnd: 91, FUCont: 92]
//[FMark: 10, MD: 11, EF: 12, NE: 13 (in the event that cell enter image, create Dummy entry mark in Time One]
//5. Parent Cell Number/Fusion: Hold cell number of fusion partner: 
//6. Cell Number
//7. Cell Lineage No
//8. For Fusion, Hold cell lineage No of fusion partner
//9. Cell no-revise

//Insert Dummy: -1, -1, Time point, event type: 13, 0, -1, ling no, 0

//ArrayLineageExtract----Extract for specific lineage data----

//Variable length of two D array. Each length of 1D array is held by arrayLineageDataEntryHold

//**********arrayIFData**********
//1. Cell Number (1+-4 bytes)
//2. Cell Lineage No (3)
//3. Time Point (2)
//4. Live/IF: Live: 1, IF: 2 (1), Simulation 3
//5. CH1-no (1)
//6. CH1-Value (3)
//7. CH1-Area (3)
//8. CH2-no (1)
//9. CH2-Value (3)
//10. CH2-Area (3)
//11. CH3-no (1)
//12. CH3-Value (3)
//13. CH3-Area (3)
//14. CH4-no (1)
//15. CH4-Value (3)
//16. CH4-Area (3)
//17. CH5-no (1)
//18. CH5-Value (3)
//19. CH5-Area (3)
//20. CH6-no (1)
//21. CH6-Value (3)
//22. CH6-Area (3)

//31 bytes

//ArrayIFData--Source IF data--
//ArrayIFCurrentData--Selected IF data--

//ifDataExtract----Extract, CH no etc----
//1. Time
//2. CH1
//3. CH2
//4. CH3
//5. CH4
//6. CH5
//7. CH6

//ifValueExtract----Extract IF Data for specific lineage

//**********arrayIFTimeLineData**********
//1. Time
//2. Round mark: Live -1, IF round 1, 2, ...
//3. No of ch
//4. Ch 1, No
//5. Ch 2, No
//6. Ch 3, No
//7. Ch 4, No
//8. Ch 5, No
//9. Ch 6, No

//ArrayIFTimeLineDataEntryHold

//**********arrayTableMain**********
//1. Entry no
//2. Add new data types (SO, AN, SE, SY) as they are created----
//   SO: Source, AN: Analysis Saved data, SE: Search Result Data
//3. Series
//4. Analysis ID
//5. Treat
//6. Fluorescent no of Ch
//7. Ch 1 name
//8. Ch 2 name
//9. Ch 3 name
//10. Ch 4 name
//11. Ch 5 name
//12. Ch 6 name
//13. IF Round entry no-10
//14. RoundNo-11
//15. IF no of Ch-12
//16. Ch 1 name-13
//17. Ch 2 name-14
//18. Ch 3 name-15
//19. Ch 4 name
//20. Ch 5 name
//21. Ch 6 name

//22-29 Round 2....

//**********arrayTableDetail**********
//1. Entry no
//2. No of Ling
//3. Time Start
//4. Time End
//5. IF Start
//6. IF End
//7. Cell No TStart
//8. Cell No TEnd
//9. Fold (data format fold e.g. 1.1*10 >> 11 +1 >> 12)
//10. Total No of cells
//11. DD
//12. TD
//13. HD
//14. TotalDV
//15. MI
//16. FU
//17. CD

//**********arrayIfTimeStatus************
//1. Time
//2. Status, 0: Include, 1: Exclude

//ifTimeExtract--Array extract specific lineage data

//********arrayAreaData************
//1. Ling no
//2. Cell no
//3. Total area
//4. Average
//5. Time point

//areaExtract--Array extract specific lineage data

//********arrayLineageLink**********
//First set: blank (0), except [0]: hold length of fused cell entry
//1.Ling no, if fused others: -1, if no corresponding Ling data: 0
//2> Fused Ling no

//length is expandable.

//----arrayLineageLinkList----

//***********arrayLineageDataTypeHold********
//1. Entry No
//2. Type
//3. Series
//4. Analysis
//5. Treat
//6. Interval
//7. Comments

//*********arrayLineageFluorescentDataType*********
//1. Entry No
//2. Round
//3. Fluorescent Name
//4. Chanel no
//5. Range Row Low
//6. Range Row High
//7. Range Average Low
//8. Range Average High

//**********Color Value*********
//16 22 255
//31 49 237
//54 88 255
//43 136 255
//65 178 236
//77 228 249
//109 250 234
//104 250 203
//105 247 175
//104 242 119
//102 242 93
//108 244 58
//120 242 33
//110 250 53
//132 255 43
//166 254 46
//199 255 72
//244 251 51
//234 225 58
//234 185 44
//240 136 39
//229 93 41
//222 64 25
//246 20 40

//*******Old data and New data format*********
//Old data: Time point end of Cell A and of the beginning of daughter cells B and C are same. So when cal.the number of cells, do not include the end.
//New data: Time point end of Cell A is the -1 of the beginning of daughter cells B and C.

@interface Controller : NSObject <NSTableViewDataSource>{
    int maxEntryNo; //Max entry no
    int listEntryNo; //List entry no
    int tableCallCount; //Table control
    int rowIndexHold; //Table control
    int setStatus2; //Call browse
    
    IBOutlet NSTextField *clearTypeInput;
    IBOutlet NSTextField *activateTypeInput;
    IBOutlet NSTextField *sourceStatus;
    
    IBOutlet NSTextField *liveLineOnOffDisplay;
    
    IBOutlet NSBrowser *listBrowser;
    IBOutlet NSTableView *tableViewList;
    IBOutlet NSProgressIndicator *progressIndicator;
    IBOutlet NSProgressIndicator *backSave;
    
    IBOutlet NSWindow *controller;
    
    NSTimer *timerLA;
    
    id sourceS;
    id sourceSA;
    id sourceSAT;
    id ascIIconversion;
}

-(id)init;
-(void)dealloc;
-(void)display;
-(void)directoryInfoUpDate;
-(void)dataSave;
-(void)dataSave2:(int)type :(int)number;
-(void)lineageFluorescentDataTypeUpDate;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;
-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex;

-(IBAction)sourceAnalysisSet:(id)sender;
-(IBAction)clearAll:(id)sender;
-(IBAction)clearSelect:(id)sender;
-(IBAction)clearType:(id)sender;
-(IBAction)activateAll:(id)sender;
-(IBAction)clearActive:(id)sender;
-(IBAction)activateType:(id)sender;
-(IBAction)quitAnalysis:(id)sender;
-(IBAction)typeDefinitionSet:(id)sender;
-(IBAction)lineageDataTypeSet:(id)sender;
-(IBAction)saveMain:(id)sender;
-(IBAction)saveAsMain:(id)sender;
-(IBAction)searchOperationStart:(id)sender;

-(IBAction)printPDF:(id)sender;
-(IBAction)printAllPDF:(id)sender;
-(IBAction)lineageLowDataExport:(id)sender;
-(IBAction)lineageFluorescentDataExport:(id)sender;
-(IBAction)lineageFluorescentDataExport2:(id)sender;

@end
