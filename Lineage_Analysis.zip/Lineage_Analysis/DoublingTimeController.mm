//
//  DoublingTimeController.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 12/16/16.
//
//

#import "DoublingTimeController.h"

NSString *notificationToDoublingTimeController = @"notificationExecuteDoublingTimeController";

@implementation DoublingTimeController

-(id)init{
    self = [super init];
    
    if (self != nil){
        everyConvert = 10;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToDoublingTimeController object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    doublingTimeWindowController = [[NSWindowController alloc] initWithWindowNibName:@"DoublingTime"];
    [doublingTimeWindowController showWindow:nil];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDoublingTimeDisplay object:nil];
}

- (void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [doublingTimeWindow frame];
    CGFloat windowHeight = windowSize.size.height;
    
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [doublingTimeWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    [horizontalLow setDelegate:self];
    [horizontalHigh setDelegate:self];
    [verticalHigh setDelegate:self];
    [rangeDoubleStDisplay1 setDelegate:self];
    [rangeDoubleStDisplay2 setDelegate:self];
    [rangeDoubleStDisplay3 setDelegate:self];
    [rangeDoubleStDisplay4 setDelegate:self];
    [rangeDoubleEdDisplay1 setDelegate:self];
    [rangeDoubleEdDisplay2 setDelegate:self];
    [rangeDoubleEdDisplay3 setDelegate:self];
    [rangeDoubleEdDisplay4 setDelegate:self];
    [pointConvertDisplay setDelegate:self];
    [minConvertDisplay setDelegate:self];
    [hrConvertDisplay setDelegate:self];
    [everyConvertDisplay setDelegate:self];
    
    [horizontalLow setIntegerValue:horizontalScaleLowDoublingTimeHold];
    [horizontalHigh setIntegerValue:horizontalScaleHighDoublingTimeHold];
    [verticalHigh setIntegerValue:verticalScaleMaxDoublingTimeHold];
    [rangeDoubleStDisplay1 setStringValue:@"0"];
    [rangeDoubleStDisplay2 setStringValue:@"0"];
    [rangeDoubleStDisplay3 setStringValue:@"0"];
    [rangeDoubleStDisplay4 setStringValue:@"0"];
    [rangeDoubleEdDisplay1 setStringValue:@"0"];
    [rangeDoubleEdDisplay2 setStringValue:@"0"];
    [rangeDoubleEdDisplay3 setStringValue:@"0"];
    [rangeDoubleEdDisplay4 setStringValue:@"0"];
    [pointConvertDisplay setIntegerValue:0];
    [minConvertDisplay setIntegerValue:0];
    [hrConvertDisplay setIntegerValue:0];
    [everyConvertDisplay setIntegerValue:10];
}

-(void)controlTextDidChange:(NSNotification *)aNotification{
    if ([[aNotification name] isEqualToString:@"NSControlTextDidChangeNotification"]){
        if ([aNotification object] == horizontalLow){
            if ([horizontalLow intValue] >= 0 && [horizontalLow intValue] < horizontalScaleHighDoublingTimeHold){
                horizontalScaleLowDoublingTimeHold = [horizontalLow intValue];
                [horizontalLow setIntegerValue:horizontalScaleLowDoublingTimeHold];
            }
        }
        
        if ([aNotification object] == horizontalHigh){
            if ([horizontalHigh intValue] >= 0 && [horizontalHigh intValue] <= horizontalScaleMaxDoublingTimeHold){
                horizontalScaleHighDoublingTimeHold = [horizontalHigh intValue];
                [horizontalHigh setIntegerValue:horizontalScaleHighDoublingTimeHold];
            }
            else{
                
                horizontalScaleHighDoublingTimeHold = horizontalScaleMaxDoublingTimeHold;
                [horizontalHigh setIntegerValue:horizontalScaleHighDoublingTimeHold];
            }
        }
        
        if ([aNotification object] == verticalHigh){
            if ([verticalHigh intValue] > 0 && [verticalHigh intValue] <= verticalScaleMaxDoublingTimeHold){
                verticalScaleHighDoublingHold = [verticalHigh intValue];
                [verticalHigh setIntegerValue:verticalScaleHighDoublingHold];
            }
            else{
                
                verticalScaleHighDoublingHold = verticalScaleMaxDoublingTimeHold;
                [verticalHigh setIntegerValue:verticalScaleHighDoublingHold];
            }
        }
        
        if ([aNotification object] == rangeDoubleStDisplay1){
            if ([rangeDoubleStDisplay1 intValue] >= 0 && [rangeDoubleStDisplay1 intValue] <= horizontalScaleMaxDoublingTimeHold){
                rangeDoubleSt1 = [rangeDoubleStDisplay1 intValue];
            }
        }
        
        if ([aNotification object] == rangeDoubleStDisplay2){
            if ([rangeDoubleStDisplay2 intValue] >= 0 && [rangeDoubleStDisplay2 intValue] <= horizontalScaleMaxDoublingTimeHold){
                rangeDoubleSt2 = [rangeDoubleStDisplay2 intValue];
            }
        }
        
        if ([aNotification object] == rangeDoubleStDisplay3){
            if ([rangeDoubleStDisplay3 intValue] >= 0 && [rangeDoubleStDisplay3 intValue] <= horizontalScaleMaxDoublingTimeHold){
                rangeDoubleSt3 = [rangeDoubleStDisplay3 intValue];
            }
        }
        
        if ([aNotification object] == rangeDoubleStDisplay4){
            if ([rangeDoubleStDisplay4 intValue] >= 0 && [rangeDoubleStDisplay4 intValue] <= horizontalScaleMaxDoublingTimeHold){
                rangeDoubleSt4 = [rangeDoubleStDisplay4 intValue];
            }
        }
        
        if ([aNotification object] == rangeDoubleEdDisplay1){
            if ([rangeDoubleEdDisplay1 intValue] >= 0 && [rangeDoubleEdDisplay1 intValue] <= horizontalScaleMaxDoublingTimeHold){
                rangeDoubleEd1 = [rangeDoubleEdDisplay1 intValue];
            }
        }
        
        if ([aNotification object] == rangeDoubleEdDisplay2){
            if ([rangeDoubleEdDisplay2 intValue] >= 0 && [rangeDoubleEdDisplay2 intValue] <= horizontalScaleMaxDoublingTimeHold){
                rangeDoubleEd2 = [rangeDoubleEdDisplay2 intValue];
            }
        }
        
        if ([aNotification object] == rangeDoubleEdDisplay3){
            if ([rangeDoubleEdDisplay3 intValue] >= 0 && [rangeDoubleEdDisplay3 intValue] <= horizontalScaleMaxDoublingTimeHold){
                rangeDoubleEd3 = [rangeDoubleEdDisplay3 intValue];
            }
        }
        
        if ([aNotification object] == rangeDoubleEdDisplay4){
            if ([rangeDoubleEdDisplay4 intValue] >= 0 && [rangeDoubleEdDisplay4 intValue] <= horizontalScaleMaxDoublingTimeHold){
                rangeDoubleEd4 = [rangeDoubleEdDisplay4 intValue];
            }
        }
        
        if ([aNotification object] == everyConvertDisplay){
            if ([everyConvertDisplay intValue] > 0 && [everyConvertDisplay intValue] <= 100){
                everyConvert = [everyConvertDisplay intValue];
                [everyConvertDisplay setIntegerValue:everyConvert];
                
                minConvert = pointConvert*everyConvert;
                hrConvert = (pointConvert*everyConvert)/(double)60;
                int hrConvertInt = (int)(hrConvert*100);
                hrConvert = hrConvertInt/(double)100;
                
                [minConvertDisplay setIntegerValue:minConvert];
                [hrConvertDisplay setDoubleValue:hrConvert];
            }
            else [everyConvertDisplay setIntegerValue:everyConvert];
        }
        
        if ([aNotification object] == pointConvertDisplay){
            if ([pointConvertDisplay intValue] >= 0 && [pointConvertDisplay intValue] <= 10000){
                pointConvert = [pointConvertDisplay intValue];
                [pointConvertDisplay setIntegerValue:pointConvert];
                
                minConvert = pointConvert*everyConvert;
                hrConvert = (pointConvert*everyConvert)/(double)60;
                int hrConvertInt = (int)(hrConvert*100);
                hrConvert = hrConvertInt/(double)100;
                
                [minConvertDisplay setIntegerValue:minConvert];
                [hrConvertDisplay setDoubleValue:hrConvert];
            }
            else [pointConvertDisplay setIntegerValue:pointConvert];
        }
        
        if ([aNotification object] == minConvertDisplay){
            if ([minConvertDisplay intValue] >= 0 && [minConvertDisplay intValue] <= 100000){
                minConvert = [minConvertDisplay intValue];
                [minConvertDisplay setIntegerValue:minConvert];
                
                pointConvert = (int)(minConvert/(double)everyConvert);
                hrConvert = minConvert/(double)60;
                int hrConvertInt = (int)(hrConvert*100);
                hrConvert = hrConvertInt/(double)100;
                
                [pointConvertDisplay setIntegerValue:pointConvert];
                [hrConvertDisplay setDoubleValue:hrConvert];
            }
            else [minConvertDisplay setIntegerValue:minConvert];
        }
        
        if ([aNotification object] == hrConvertDisplay){
            if ([hrConvertDisplay intValue] >= 0 && [hrConvertDisplay intValue] <= 10000){
                hrConvert = [hrConvertDisplay intValue];
                [hrConvertDisplay setDoubleValue:hrConvert];
                
                pointConvert = (int)((hrConvert*60)/(double)everyConvert);
                minConvert = (int)(hrConvert*60);
                
                [pointConvertDisplay setIntegerValue:pointConvert];
                [minConvertDisplay setIntegerValue:minConvert];
            }
            else [hrConvertDisplay setDoubleValue:hrConvert];
        }
    }
}

-(IBAction)createExcelFileStatistics:(id)sender{
    string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
    mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
    
    string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Doubling_Time";
    mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
    
    DIR *dir;
    struct dirent *dent;
    
    string entry;
    string extractString;
    int maxEntryNo = 0;
    
    dir = opendir(resultSavePath2.c_str());
    
    if (dir != NULL){
        while ((dent = readdir(dir))){
            entry = dent -> d_name;
            
            if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("Doubling_Time") != -1){
                extractString = entry.substr(entry.find("DT")+2, entry.find(".txt")-entry.find("DT")-2);
                
                if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
            }
        }
        
        closedir(dir);
    }
    
    maxEntryNo++;
    
    string path = resultSavePath2+"/Doubling_TimeStat-DT"+to_string(maxEntryNo)+".txt";
    
    int **cellNumberHold = new int *[15];
    
    for (int counter2 = 0; counter2 < 15; counter2++){
        cellNumberHold [counter2] = new int [horizontalScaleMaxDoublingTimeHold+50];
    }
    
    for (int counter2 = 0; counter2 < 15; counter2++){
        for (int counter3 = 0; counter3 < horizontalScaleMaxDoublingTimeHold+50; counter3++){
            cellNumberHold [counter2][counter3] = -1;
        }
    }
    
    for (int counter3 = 0; counter3 <= horizontalScaleMaxDoublingTimeHold; counter3++){
        cellNumberHold [0][counter3] = counter3;
    }
    
    string *nameHold = new string [15];
    int nameHoldCount = 0;
    
    int rangeFlag = 0;
    
    int rangeSt1 = 0;
    int rangeEd1 = 0;
    
    int rangeSt2 = 0;
    int rangeEd2 = 0;
    
    int rangeSt3 = 0;
    int rangeEd3 = 0;
    
    int rangeSt4 = 0;
    int rangeEd4 = 0;
    
    if (rangeDoubleSt1 > 0 && rangeDoubleEd1 > 0 && rangeDoubleSt1+10 < rangeDoubleEd1){
        rangeSt1 = rangeDoubleSt1;
        rangeEd1 = rangeDoubleEd1;
        rangeFlag = 1;
    }
    
    if (rangeDoubleSt2 > 0 && rangeDoubleEd2 > 0 && rangeDoubleSt2+10 < rangeDoubleEd2){
        rangeSt2 = rangeDoubleSt2;
        rangeEd2 = rangeDoubleEd2;
        rangeFlag = 2;
    }
    
    if (rangeDoubleSt3 > 0 && rangeDoubleEd3 > 0 && rangeDoubleSt3+10 < rangeDoubleEd3){
        rangeSt3 = rangeDoubleSt3;
        rangeEd3 = rangeDoubleEd3;
        rangeFlag = 3;
    }
    
    if (rangeDoubleSt4 > 0 && rangeDoubleEd4 > 0 && rangeDoubleSt4+10 < rangeDoubleEd4){
        rangeSt4 = rangeDoubleSt4;
        rangeEd4 = rangeDoubleEd4;
        rangeFlag = 4;
    }
    
    int endTime = 0;
    int maxEntry = 0;
    int entryCount = 1;
    int rangeStartProcess = 0;
    int rangeEndProcess = 0;
    
    if (rangeFlag == 0){
        nameHold [0] = "Doubling Time-min ", nameHoldCount++;
        
        for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
            if (arraySelectedLing [counter2] == 1 && maxEntry <= 12){
                nameHold [nameHoldCount] = arrayTableMain [counter2][4].substr(arrayTableMain [counter2][4].find("-")+1), nameHoldCount++;
                
                for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [counter2]/9; counter3++){
                    if (arrayLineageData [counter2][counter3*9+3] == 31 || arrayLineageData [counter2][counter3*9+3] == 41 || arrayLineageData [counter2][counter3*9+3] == 51){
                        endTime = 0;
                        
                        for (unsigned long counter4 = counter3+1; counter4 < arrayLineageDataEntryHold [counter2]/9; counter4++){
                            if (arrayLineageData [counter2][counter3*9+5] == arrayLineageData [counter2][counter4*9+5] && arrayLineageData [counter2][counter3*9+6] == arrayLineageData [counter2][counter4*9+6] && (arrayLineageData [counter2][counter4*9+3] == 32 || arrayLineageData [counter2][counter4*9+3] == 42 || arrayLineageData [counter2][counter4*9+3] == 52)){
                                endTime = arrayLineageData [counter2][counter4*9+2];
                            }
                            else if (arrayLineageData [counter2][counter3*9+5] != arrayLineageData [counter2][counter4*9+5] || arrayLineageData [counter2][counter3*9+6] != arrayLineageData [counter2][counter4*9+6]){
                                break;
                            }
                        }
                        
                        if (endTime != 0){
                            if (cellNumberHold [entryCount][(endTime-arrayLineageData [counter2][counter3*9+2])*atoi(arrayLineageDataType [counter2][5].c_str())] == -1) cellNumberHold [entryCount][(endTime-arrayLineageData [counter2][counter3*9+2])*atoi(arrayLineageDataType [counter2][5].c_str())] = 1;
                            else cellNumberHold [entryCount][(endTime-arrayLineageData [counter2][counter3*9+2])*atoi(arrayLineageDataType [counter2][5].c_str())]++;
                        }
                    }
                }
                
                entryCount++;
            }
        }
    }
    else{
        
        for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
            if (arraySelectedLing [counter2] == 1){
                for (int counter3 = 0; counter3 < rangeFlag; counter3++){
                    if (counter3 == 0){
                        rangeStartProcess = rangeSt1;
                        rangeEndProcess = rangeEd1;
                        
                        nameHold [0] = "Doubling Time-min "+arrayTableMain [counter2][4].substr(arrayTableMain [counter2][4].find("-")+1), nameHoldCount++;
                        nameHold [nameHoldCount] = "TP "+to_string(rangeStartProcess)+"-"+to_string(rangeEndProcess), nameHoldCount++;
                        
                        entryCount = 1;
                    }
                    else if (counter3 == 1){
                        rangeStartProcess = rangeSt2;
                        rangeEndProcess = rangeEd2;
                        
                        nameHold [nameHoldCount] = "TP "+to_string(rangeStartProcess)+"-"+to_string(rangeEndProcess), nameHoldCount++;
                        
                        entryCount = 2;
                    }
                    else if (counter3 == 2){
                        rangeStartProcess = rangeSt3;
                        rangeEndProcess = rangeEd3;
                        
                        nameHold [nameHoldCount] = "TP "+to_string(rangeStartProcess)+"-"+to_string(rangeEndProcess), nameHoldCount++;
                        
                        entryCount = 3;
                    }
                    else if (counter3 == 3){
                        rangeStartProcess = rangeSt4;
                        rangeEndProcess = rangeEd4;
                        
                        nameHold [nameHoldCount] = "TP "+to_string(rangeStartProcess)+"-"+to_string(rangeEndProcess), nameHoldCount++;
                        
                        entryCount = 4;
                    }
                    
                    for (unsigned long counter4 = 0; counter4 < arrayLineageDataEntryHold [counter2]/9; counter4++){
                        if (arrayLineageData [counter2][counter4*9+3] == 31 || arrayLineageData [counter2][counter4*9+3] == 41 || arrayLineageData [counter2][counter4*9+3] == 51){
                            endTime = 0;
                            
                            for (unsigned long counter5 = counter4+1; counter5 < arrayLineageDataEntryHold [counter2]/9; counter5++){
                                if (arrayLineageData [counter2][counter4*9+5] == arrayLineageData [counter2][counter5*9+5] && arrayLineageData [counter2][counter4*9+6] == arrayLineageData [counter2][counter5*9+6] && (arrayLineageData [counter2][counter5*9+3] == 32 || arrayLineageData [counter2][counter5*9+3] == 42 || arrayLineageData [counter2][counter5*9+3] == 52) && arrayLineageData [counter2][counter4*9+2] >= rangeStartProcess && arrayLineageData [counter2][counter4*9+2] <= rangeEndProcess){
                                    endTime = arrayLineageData [counter2][counter5*9+2];
                                }
                                else if (arrayLineageData [counter2][counter4*9+5] != arrayLineageData [counter2][counter5*9+5] || arrayLineageData [counter2][counter4*9+6] != arrayLineageData [counter2][counter5*9+6]){
                                    break;
                                }
                            }
                            
                            if (endTime != 0){
                                if (cellNumberHold [entryCount][(endTime-arrayLineageData [counter2][counter4*9+2])*atoi(arrayLineageDataType [counter2][5].c_str())] == -1) cellNumberHold [entryCount][(endTime-arrayLineageData [counter2][counter4*9+2])*atoi(arrayLineageDataType [counter2][5].c_str())] = 1;
                                else cellNumberHold [entryCount][(endTime-arrayLineageData [counter2][counter4*9+2])*atoi(arrayLineageDataType [counter2][5].c_str())]++;
                            }
                        }
                    }
                }
                
                entryCount++;
                
                break;
            }
        }
    }
    
    ofstream oin;
    oin.open(path.c_str(), ios::out | ios::binary);
    
    int *arrayAscIIintData = new int [100], ascIIintDataCount = 0;
    
    ascIIconversion = [[ASCIIconversion alloc] init];
    
    for (int counter2 = 1; counter2 < entryCount; counter2++){
        ascIIstring = nameHold [counter2];
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        for (int counter3 = 0; counter3 <= horizontalScaleMaxDoublingTimeHold; counter3++){
            if (cellNumberHold [counter2][counter3] != -1){
                for (int counter4 = 0; counter4 <= cellNumberHold [counter2][counter3]; counter4++){
                    ascIIstring = to_string(counter3);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter5 = 0; counter5 < ascIIintDataCount; counter5++) oin.put((char)arrayAscIIintData [counter5]);
                    
                    oin.put(9);
                }
            }
        }
        
        oin.put(13);
        oin.put(10);
    }
    
    for (int counter2 = 0; counter2 < 15; counter2++){
        delete [] cellNumberHold [counter2];
    }
    
    delete [] cellNumberHold;
    
    delete [] nameHold;
    delete [] arrayAscIIintData;
    
    oin.close();
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)createExcelFileDoubleAtATime:(id)sender{
    string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
    mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
    
    string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Doubling_Time";
    mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
    
    DIR *dir;
    struct dirent *dent;
    
    string entry;
    string extractString;
    int maxEntryNo = 0;
    
    dir = opendir(resultSavePath2.c_str());
    
    if (dir != NULL){
        while ((dent = readdir(dir))){
            entry = dent -> d_name;
            
            if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("Doubling_Time") != -1){
                extractString = entry.substr(entry.find("DT")+2, entry.find(".txt")-entry.find("DT")-2);
                
                if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
            }
        }
        
        closedir(dir);
    }
    
    maxEntryNo++;
    
    string path = resultSavePath2+"/Doubling_TimeStat-DT"+to_string(maxEntryNo)+".txt";
    
    int totalNoOfCells = 0;
    
    for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
        if (arraySelectedLing [counter2] == 1){
            if (totalNoOfCells < arrayTableDetail [counter2][9]) totalNoOfCells = arrayTableDetail [counter2][9];
        }
    }
    
    int **cellNumberHold = new int *[15];
    
    for (int counter2 = 0; counter2 < 15; counter2++){
        cellNumberHold [counter2] = new int [totalNoOfCells*2+1];
    }
    
    for (int counter2 = 0; counter2 < 15; counter2++){
        for (int counter3 = 0; counter3 < totalNoOfCells*2+1; counter3++){
            cellNumberHold [counter2][counter3] = -1;
        }
    }
    
    string *nameHold = new string [15];
    int nameHoldCount = 0;
    
    int endTime = 0;
    int maxEntry = 0;
    int entryCount = 0;
    
    for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
        if (arraySelectedLing [counter2] == 1 && maxEntry <= 12){
            nameHold [nameHoldCount] = arrayTableMain [counter2][4].substr(arrayTableMain [counter2][4].find("-")+1), nameHoldCount++;
            
            for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [counter2]/9; counter3++){
                if (arrayLineageData [counter2][counter3*9+3] == 31 || arrayLineageData [counter2][counter3*9+3] == 41 || arrayLineageData [counter2][counter3*9+3] == 51){
                    endTime = 0;
                    
                    for (unsigned long counter4 = counter3+1; counter4 < arrayLineageDataEntryHold [counter2]/9; counter4++){
                        if (arrayLineageData [counter2][counter3*9+5] == arrayLineageData [counter2][counter4*9+5] && arrayLineageData [counter2][counter3*9+6] == arrayLineageData [counter2][counter4*9+6] && (arrayLineageData [counter2][counter4*9+3] == 32 || arrayLineageData [counter2][counter4*9+3] == 42 || arrayLineageData [counter2][counter4*9+3] == 52)){
                            endTime = arrayLineageData [counter2][counter4*9+2];
                        }
                        else if (arrayLineageData [counter2][counter3*9+5] != arrayLineageData [counter2][counter4*9+5] || arrayLineageData [counter2][counter3*9+6] != arrayLineageData [counter2][counter4*9+6]){
                            break;
                        }
                    }
                    
                    if (endTime != 0){
                        for (int counter4 = 0; counter4 < totalNoOfCells/2; counter4++){
                            if (cellNumberHold [entryCount][counter4*2] == -1){
                                cellNumberHold [entryCount][counter4*2] = endTime;
                                cellNumberHold [entryCount][counter4*2+1] = (endTime-arrayLineageData [counter2][counter3*9+2])*atoi(arrayLineageDataType [counter2][5].c_str());
                                break;
                            }
                        }
                    }
                }
            }
            
            entryCount++;
        }
    }
    
    ofstream oin;
    oin.open(path.c_str(), ios::out | ios::binary);
    
    int *arrayAscIIintData = new int [100], ascIIintDataCount = 0;
    
    ascIIconversion = [[ASCIIconversion alloc] init];
    
    ascIIstring = "Time";
    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
    
    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
    
    oin.put(9);
    
    ascIIstring = "Doubling time";
    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
    
    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
    
    oin.put(13);
    oin.put(10);
    
    for (int counter2 = 0; counter2 < entryCount; counter2++){
        ascIIstring = nameHold [counter2];
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        oin.put(13);
        oin.put(10);
        
        for (int counter3 = 0; counter3 < totalNoOfCells/2; counter3++){
            if (cellNumberHold [counter2][counter3*2] != -1){
                ascIIstring = to_string(cellNumberHold [counter2][counter3*2]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter5 = 0; counter5 < ascIIintDataCount; counter5++) oin.put((char)arrayAscIIintData [counter5]);
                
                oin.put(9);
                
                ascIIstring = to_string(cellNumberHold [counter2][counter3*2+1]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter5 = 0; counter5 < ascIIintDataCount; counter5++) oin.put((char)arrayAscIIintData [counter5]);
                
                oin.put(9);
                
                oin.put(13);
                oin.put(10);
            }
        }
        
        oin.put(13);
        oin.put(10);
    }
    
    oin.put(13);
    oin.put(10);
    
    for (int counter2 = 0; counter2 < 15; counter2++){
        delete [] cellNumberHold [counter2];
    }
    
    delete [] cellNumberHold;
    
    delete [] nameHold;
    delete [] arrayAscIIintData;
    
    oin.close();
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)createExcelFile:(id)sender{
    string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
    mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
    
    string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Doubling_Time";
    mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
    
    DIR *dir;
    struct dirent *dent;
    
    string entry;
    string extractString;
    int maxEntryNo = 0;
    
    dir = opendir(resultSavePath2.c_str());
    
    if (dir != NULL){
        while ((dent = readdir(dir))){
            entry = dent -> d_name;
            
            if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("Doubling_Time") != -1){
                extractString = entry.substr(entry.find("DT")+2, entry.find(".txt")-entry.find("DT")-2);
                
                if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
            }
        }
        
        closedir(dir);
    }
    
    maxEntryNo++;
    
    string path = resultSavePath2+"/Doubling_Time-DT"+to_string(maxEntryNo)+".txt";
    
    int **cellNumberHold = new int *[15];
    
    for (int counter2 = 0; counter2 < 15; counter2++){
        cellNumberHold [counter2] = new int [horizontalScaleMaxDoublingTimeHold+50];
    }
    
    for (int counter2 = 0; counter2 < 15; counter2++){
        for (int counter3 = 0; counter3 < horizontalScaleMaxDoublingTimeHold+50; counter3++){
            cellNumberHold [counter2][counter3] = -1;
        }
    }
    
    for (int counter3 = 0; counter3 <= horizontalScaleMaxDoublingTimeHold; counter3++){
        cellNumberHold [0][counter3] = counter3;
    }
    
    string *nameHold = new string [15];
    int nameHoldCount = 0;
    
    int rangeFlag = 0;
    
    int rangeSt1 = 0;
    int rangeEd1 = 0;
    
    int rangeSt2 = 0;
    int rangeEd2 = 0;
    
    int rangeSt3 = 0;
    int rangeEd3 = 0;
    
    int rangeSt4 = 0;
    int rangeEd4 = 0;
    
    if (rangeDoubleSt1 > 0 && rangeDoubleEd1 > 0 && rangeDoubleSt1+10 < rangeDoubleEd1){
        rangeSt1 = rangeDoubleSt1;
        rangeEd1 = rangeDoubleEd1;
        rangeFlag = 1;
    }
    
    if (rangeDoubleSt2 > 0 && rangeDoubleEd2 > 0 && rangeDoubleSt2+10 < rangeDoubleEd2){
        rangeSt2 = rangeDoubleSt2;
        rangeEd2 = rangeDoubleEd2;
        rangeFlag = 2;
    }
    
    if (rangeDoubleSt3 > 0 && rangeDoubleEd3 > 0 && rangeDoubleSt3+10 < rangeDoubleEd3){
        rangeSt3 = rangeDoubleSt3;
        rangeEd3 = rangeDoubleEd3;
        rangeFlag = 3;
    }
    
    if (rangeDoubleSt4 > 0 && rangeDoubleEd4 > 0 && rangeDoubleSt4+10 < rangeDoubleEd4){
        rangeSt4 = rangeDoubleSt4;
        rangeEd4 = rangeDoubleEd4;
        rangeFlag = 4;
    }
    
    int endTime = 0;
    int maxEntry = 0;
    int entryCount = 1;
    int rangeStartProcess = 0;
    int rangeEndProcess = 0;
    
    if (rangeFlag == 0){
        nameHold [0] = "Doubling Time-min ", nameHoldCount++;
        
        for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
            if (arraySelectedLing [counter2] == 1 && maxEntry <= 12){
                nameHold [nameHoldCount] = arrayTableMain [counter2][4].substr(arrayTableMain [counter2][4].find("-")+1), nameHoldCount++;
                
                for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [counter2]/9; counter3++){
                    if (arrayLineageData [counter2][counter3*9+3] == 31 || arrayLineageData [counter2][counter3*9+3] == 41 || arrayLineageData [counter2][counter3*9+3] == 51){
                        endTime = 0;
                        
                        for (unsigned long counter4 = counter3+1; counter4 < arrayLineageDataEntryHold [counter2]/9; counter4++){
                            if (arrayLineageData [counter2][counter3*9+5] == arrayLineageData [counter2][counter4*9+5] && arrayLineageData [counter2][counter3*9+6] == arrayLineageData [counter2][counter4*9+6] && (arrayLineageData [counter2][counter4*9+3] == 32 || arrayLineageData [counter2][counter4*9+3] == 42 || arrayLineageData [counter2][counter4*9+3] == 52)){
                                endTime = arrayLineageData [counter2][counter4*9+2];
                            }
                            else if (arrayLineageData [counter2][counter3*9+5] != arrayLineageData [counter2][counter4*9+5] || arrayLineageData [counter2][counter3*9+6] != arrayLineageData [counter2][counter4*9+6]){
                                break;
                            }
                        }
                        
                        if (endTime != 0){
                            if (cellNumberHold [entryCount][(endTime-arrayLineageData [counter2][counter3*9+2])*atoi(arrayLineageDataType [counter2][5].c_str())] == -1) cellNumberHold [entryCount][(endTime-arrayLineageData [counter2][counter3*9+2])*atoi(arrayLineageDataType [counter2][5].c_str())] = 1;
                            else cellNumberHold [entryCount][(endTime-arrayLineageData [counter2][counter3*9+2])*atoi(arrayLineageDataType [counter2][5].c_str())]++;
                        }
                    }
                }
                
                entryCount++;
            }
        }
    }
    else{
        
        for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
            if (arraySelectedLing [counter2] == 1){
                for (int counter3 = 0; counter3 < rangeFlag; counter3++){
                    if (counter3 == 0){
                        rangeStartProcess = rangeSt1;
                        rangeEndProcess = rangeEd1;
                        
                        nameHold [0] = "Doubling Time-min "+arrayTableMain [counter2][4].substr(arrayTableMain [counter2][4].find("-")+1), nameHoldCount++;
                        nameHold [nameHoldCount] = "TP "+to_string(rangeStartProcess)+"-"+to_string(rangeEndProcess), nameHoldCount++;
                        
                        entryCount = 1;
                    }
                    else if (counter3 == 1){
                        rangeStartProcess = rangeSt2;
                        rangeEndProcess = rangeEd2;
                        
                        nameHold [nameHoldCount] = "TP "+to_string(rangeStartProcess)+"-"+to_string(rangeEndProcess), nameHoldCount++;
                        
                        entryCount = 2;
                    }
                    else if (counter3 == 2){
                        rangeStartProcess = rangeSt3;
                        rangeEndProcess = rangeEd3;
                        
                        nameHold [nameHoldCount] = "TP "+to_string(rangeStartProcess)+"-"+to_string(rangeEndProcess), nameHoldCount++;
                        
                        entryCount = 3;
                    }
                    else if (counter3 == 3){
                        rangeStartProcess = rangeSt4;
                        rangeEndProcess = rangeEd4;
                        
                        nameHold [nameHoldCount] = "TP "+to_string(rangeStartProcess)+"-"+to_string(rangeEndProcess), nameHoldCount++;
                        
                        entryCount = 4;
                    }
                    
                    for (unsigned long counter4 = 0; counter4 < arrayLineageDataEntryHold [counter2]/9; counter4++){
                        if (arrayLineageData [counter2][counter4*9+3] == 31 || arrayLineageData [counter2][counter4*9+3] == 41 || arrayLineageData [counter2][counter4*9+3] == 51){
                            endTime = 0;
                            
                            for (unsigned long counter5 = counter4+1; counter5 < arrayLineageDataEntryHold [counter2]/9; counter5++){
                                if (arrayLineageData [counter2][counter4*9+5] == arrayLineageData [counter2][counter5*9+5] && arrayLineageData [counter2][counter4*9+6] == arrayLineageData [counter2][counter5*9+6] && (arrayLineageData [counter2][counter5*9+3] == 32 || arrayLineageData [counter2][counter5*9+3] == 42 || arrayLineageData [counter2][counter5*9+3] == 52) && arrayLineageData [counter2][counter4*9+2] >= rangeStartProcess && arrayLineageData [counter2][counter4*9+2] <= rangeEndProcess){
                                    endTime = arrayLineageData [counter2][counter5*9+2];
                                }
                                else if (arrayLineageData [counter2][counter4*9+5] != arrayLineageData [counter2][counter5*9+5] || arrayLineageData [counter2][counter4*9+6] != arrayLineageData [counter2][counter5*9+6]){
                                    break;
                                }
                            }
                            
                            if (endTime != 0){
                                if (cellNumberHold [entryCount][(endTime-arrayLineageData [counter2][counter4*9+2])*atoi(arrayLineageDataType [counter2][5].c_str())] == -1) cellNumberHold [entryCount][(endTime-arrayLineageData [counter2][counter4*9+2])*atoi(arrayLineageDataType [counter2][5].c_str())] = 1;
                                else cellNumberHold [entryCount][(endTime-arrayLineageData [counter2][counter4*9+2])*atoi(arrayLineageDataType [counter2][5].c_str())]++;
                            }
                        }
                    }
                }
                
                entryCount++;
                
                break;
            }
        }
    }
    
    ofstream oin;
    oin.open(path.c_str(), ios::out | ios::binary);
    
    int *arrayAscIIintData = new int [100], ascIIintDataCount = 0;
    
    ascIIconversion = [[ASCIIconversion alloc] init];
    
    for (int counter2 = 0; counter2 < nameHoldCount; counter2++){
        //0D--13
        //***09***09***0D0A
        //***09***09
        
        ascIIstring = nameHold [counter2];
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
    }
    
    oin.put(13);
    oin.put(10);
    
    for (int counter1 = 0; counter1 <= horizontalScaleMaxDoublingTimeHold; counter1++){
        for (int counter2 = 0; counter2 < entryCount; counter2++){
            if (cellNumberHold [counter2][counter1] != -1){
                ascIIstring = to_string(cellNumberHold [counter2][counter1]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            }
            
            oin.put(9);
        }
        
        oin.put(13);
        oin.put(10);
    }
    
    for (int counter2 = 0; counter2 < 15; counter2++){
        delete [] cellNumberHold [counter2];
    }
    
    delete [] cellNumberHold;
    
    delete [] nameHold;
    delete [] arrayAscIIintData;
    
    oin.close();
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)rangeClearSet:(id)sender{
    [rangeDoubleStDisplay1 setStringValue:@"0"];
    [rangeDoubleStDisplay2 setStringValue:@"0"];
    [rangeDoubleStDisplay3 setStringValue:@"0"];
    [rangeDoubleStDisplay4 setStringValue:@"0"];
    [rangeDoubleEdDisplay1 setStringValue:@"0"];
    [rangeDoubleEdDisplay2 setStringValue:@"0"];
    [rangeDoubleEdDisplay3 setStringValue:@"0"];
    [rangeDoubleEdDisplay4 setStringValue:@"0"];
    
    rangeDoubleSt1 = 0;
    rangeDoubleSt2 = 0;
    rangeDoubleSt3 = 0;
    rangeDoubleSt4 = 0;
    rangeDoubleEd1 = 0;
    rangeDoubleEd2 = 0;
    rangeDoubleEd3 = 0;
    rangeDoubleEd4 = 0;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)closeWindow:(id)sender{
    [doublingTimeWindow orderOut:nil];
    doublingTimeWindowOperation = 2;
    doublingTimeTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
}

-(void)reDisplayWindow{
    if (doublingTimeWindowOperation == 3){
        [doublingTimeWindow makeKeyAndOrderFront:nil];
        doublingTimeWindowOperation = 1;
        [doublingTimeTimer invalidate];
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToDoublingTimeController object:nil];
}

@end
