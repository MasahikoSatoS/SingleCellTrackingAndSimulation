//
//  LineageListCondition.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 11/26/16.
//
//

#ifndef LINEAGELISTCONDITION_H
#define LINEAGELISTCONDITION_H
#import "Controller.h" 
#endif

@interface LineageListCondition : NSObject{
    IBOutlet NSTextField *typeDisplayLing;
    IBOutlet NSTextField *seriesDisplayLing;
    IBOutlet NSTextField *analysisDisplayLing;
    IBOutlet NSTextField *treatDisplayLing;
    IBOutlet NSTextField *cellNameForDisplay;
    IBOutlet NSTextField *treatNameForDisplay;
    IBOutlet NSTextField *ifRangeForDisplay;
    IBOutlet NSTextField *liveDisplayLing;
    IBOutlet NSTextField *ifOneAllLing;
    IBOutlet NSTextField *channelDisplayLing;
    IBOutlet NSTextField *siblingDisplayLing;
    IBOutlet NSTextField *colorOptionDisplayLing;
    
    IBOutlet NSStepper *stepperTime;
}

-(id)init;
-(void)dealloc;

-(IBAction)stepperActionTime:(id)sender;

@end
