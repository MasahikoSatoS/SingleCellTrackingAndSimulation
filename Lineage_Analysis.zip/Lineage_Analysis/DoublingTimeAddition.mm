//
//  DoublingTimeAddition.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 12/16/16.
//
//

#import "DoublingTimeAddition.h"

NSString *notificationToDoublingTimeAddition = @"notificationExecuteDoublingTimeAddition";

@implementation DoublingTimeAddition

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToDoublingTimeAddition object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    [horizontalLow setIntegerValue:horizontalScaleLowDoublingTimeHold];
    [horizontalHigh setIntegerValue:horizontalScaleHighDoublingTimeHold];
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToDoublingTimeAddition object:nil];
}

@end
