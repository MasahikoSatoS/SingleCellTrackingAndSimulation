//
//  EndTrimTable.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2017-05-31.
//
//

#ifndef ENDTRIMTABLE_H
#define ENDTRIMTABLE_H
#import "Controller.h" 
#endif

@interface EndTrimTable : NSObject <NSTableViewDataSource>{
    IBOutlet NSTableView *endTrimTable;
}

-(id)init;
-(void)dealloc;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;
-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex;

@end
