//
//  ProgenyAnalysisTable.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2017-05-22.
//
//

#ifndef PROGENYANALYSISTABLE_H
#define PROGENYANALYSISTABLE_H
#import "Controller.h" 
#endif

@interface ProgenyAnalysisTable : NSObject <NSTableViewDataSource>{
    IBOutlet NSTableView *progenyAnalysisProgenyTable;
}

-(id)init;
-(void)dealloc;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;

@end
