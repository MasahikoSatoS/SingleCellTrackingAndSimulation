//
//  SimulationController.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2020-10-29.
//

#ifndef SIMULATIONCONTROLLER_H
#define SIMULATIONCONTROLLER_H
#import "Controller.h"
#endif

@interface SimulationController : NSObject<NSTextFieldDelegate>{
    IBOutlet NSTextField *formulaA1Display;
    IBOutlet NSTextField *formulaA2Display;
    IBOutlet NSTextField *formulaA3Display;
    IBOutlet NSTextField *formulaA4Display;
    IBOutlet NSTextField *formulaB1Display;
    IBOutlet NSTextField *formulaB2Display;
    IBOutlet NSTextField *formulaB3Display;
    IBOutlet NSTextField *formulaB4Display;
    IBOutlet NSTextField *cycleFitDisplay;
    IBOutlet NSTextField *fitRangeBEndDisplay;
    IBOutlet NSTextField *fitTimeStartDisplay;
    IBOutlet NSTextField *fitModeDisplay;
    IBOutlet NSTextField *limitSimDisplay;
    
    IBOutlet NSTextField *growthTimeBDDisplay;
    IBOutlet NSTextField *growthTimeTDDisplay;
    IBOutlet NSTextField *growthTimeCFDisplay;
    IBOutlet NSTextField *growthBDDisplay;
    IBOutlet NSTextField *growthTDDisplay;
    IBOutlet NSTextField *growthBDCDDisplay;
    IBOutlet NSTextField *growthNOCDDisplay;
    IBOutlet NSTextField *growthBDCFDisplay;
    IBOutlet NSTextField *growthBDCFBDDisplay;
    IBOutlet NSTextField *growthBDCFTDDisplay;
    IBOutlet NSTextField *growthBDCFCDDisplay;
    IBOutlet NSTextField *growthTDCFDisplay;
    IBOutlet NSTextField *growthTDCFBDDisplay;
    IBOutlet NSTextField *growthTDCFTDDisplay;
    IBOutlet NSTextField *growthTDCFCDDisplay;
    IBOutlet NSTextField *growthTDBDDisplay;
    IBOutlet NSTextField *growthTDTDDisplay;
    IBOutlet NSTextField *growthTDCDDisplay;
    IBOutlet NSTextField *growthMulTDTDDisplay;
    IBOutlet NSTextField *growthSupTDBDDisplay;
    IBOutlet NSTextField *growthNoDivDisplay;
    IBOutlet NSTextField *growthRecoveryDisplay;
    
    IBOutlet NSTextField *growthPrgTimeBDDisplay;
    IBOutlet NSTextField *growthPrgTimeTDDisplay;
    IBOutlet NSTextField *growthPrgTimeCFDisplay;
    IBOutlet NSTextField *growthPrgBDDisplay;
    IBOutlet NSTextField *growthPrgTDDisplay;
    IBOutlet NSTextField *growthPrgBDCDDisplay;
    IBOutlet NSTextField *growthPrgNOCDDisplay;
    IBOutlet NSTextField *growthPrgBDCFDisplay;
    IBOutlet NSTextField *growthPrgBDCFBDDisplay;
    IBOutlet NSTextField *growthPrgBDCFTDDisplay;
    IBOutlet NSTextField *growthPrgBDCFCDDisplay;
    IBOutlet NSTextField *growthPrgTDCFDisplay;
    IBOutlet NSTextField *growthPrgTDCFBDDisplay;
    IBOutlet NSTextField *growthPrgTDCFTDDisplay;
    IBOutlet NSTextField *growthPrgTDCFCDDisplay;
    IBOutlet NSTextField *growthPrgTDBDDisplay;
    IBOutlet NSTextField *growthPrgTDTDDisplay;
    IBOutlet NSTextField *growthPrgTDCDDisplay;
    IBOutlet NSTextField *growthPrgMulTDTDDisplay;
    IBOutlet NSTextField *growthPrgSupTDBDDisplay;
    IBOutlet NSTextField *growthPrgNoDivDisplay;
    IBOutlet NSTextField *growthPrgRecoveryDisplay;
    
    IBOutlet NSTextField *growthMidTimeBDDisplay;
    IBOutlet NSTextField *growthMidTimeTDDisplay;
    IBOutlet NSTextField *growthMidTimeCFDisplay;
    IBOutlet NSTextField *growthMidBDDisplay;
    IBOutlet NSTextField *growthMidTDDisplay;
    IBOutlet NSTextField *growthMidBDCDDisplay;
    IBOutlet NSTextField *growthMidNOCDDisplay;
    IBOutlet NSTextField *growthMidBDCFDisplay;
    IBOutlet NSTextField *growthMidBDCFBDDisplay;
    IBOutlet NSTextField *growthMidBDCFTDDisplay;
    IBOutlet NSTextField *growthMidBDCFCDDisplay;
    IBOutlet NSTextField *growthMidTDCFDisplay;
    IBOutlet NSTextField *growthMidTDCFBDDisplay;
    IBOutlet NSTextField *growthMidTDCFTDDisplay;
    IBOutlet NSTextField *growthMidTDCFCDDisplay;
    IBOutlet NSTextField *growthMidTDBDDisplay;
    IBOutlet NSTextField *growthMidTDTDDisplay;
    IBOutlet NSTextField *growthMidTDCDDisplay;
    IBOutlet NSTextField *growthMidMulTDTDDisplay;
    IBOutlet NSTextField *growthMidSupTDBDDisplay;
    IBOutlet NSTextField *growthMidNoDivDisplay;
    IBOutlet NSTextField *growthMidRecoveryDisplay;
    
    IBOutlet NSTextField *growthAddTimeBDDisplay;
    IBOutlet NSTextField *growthAddTimeTDDisplay;
    IBOutlet NSTextField *growthAddTimeCFDisplay;
    IBOutlet NSTextField *growthAddBDDisplay;
    IBOutlet NSTextField *growthAddTDDisplay;
    IBOutlet NSTextField *growthAddBDCDDisplay;
    IBOutlet NSTextField *growthAddNOCDDisplay;
    IBOutlet NSTextField *growthAddBDCFDisplay;
    IBOutlet NSTextField *growthAddBDCFBDDisplay;
    IBOutlet NSTextField *growthAddBDCFTDDisplay;
    IBOutlet NSTextField *growthAddBDCFCDDisplay;
    IBOutlet NSTextField *growthAddTDCFDisplay;
    IBOutlet NSTextField *growthAddTDCFBDDisplay;
    IBOutlet NSTextField *growthAddTDCFTDDisplay;
    IBOutlet NSTextField *growthAddTDCFCDDisplay;
    IBOutlet NSTextField *growthAddTDBDDisplay;
    IBOutlet NSTextField *growthAddTDTDDisplay;
    IBOutlet NSTextField *growthAddTDCDDisplay;
    IBOutlet NSTextField *growthAddMulTDTDDisplay;
    IBOutlet NSTextField *growthAddSupTDBDDisplay;
    IBOutlet NSTextField *growthAddNoDivDisplay;
    IBOutlet NSTextField *growthAddRecoveryDisplay;
    
    IBOutlet NSTextField *growthCycleDisplay;
    IBOutlet NSTextField *growthTimeStartDisplay;
    IBOutlet NSTextField *growthInitNoDisplay;
    
    IBOutlet NSTextField *startDisplay;
    IBOutlet NSTextField *recoveryPercDisplay;
    IBOutlet NSTextField *growthTimeEndDisplay;
    IBOutlet NSTextField *growthMidTimeStartDisplay;
    IBOutlet NSTextField *terminateDisplay;
    IBOutlet NSTextField *processStatusDisplay;
    IBOutlet NSTextField *processStatusDisplay2;
    IBOutlet NSTextField *processStatusDisplay3;
    IBOutlet NSTextField *processStatusDisplay4;
    
    IBOutlet NSTextField *movieDistanceDisplay;
    IBOutlet NSTextField *movieDistanceDisplay2;
    IBOutlet NSTextField *movieDistanceDisplay3;
    IBOutlet NSTextField *movieDistanceTimeDisplay2;
    IBOutlet NSTextField *movieDistanceTimeDisplay3;
    IBOutlet NSTextField *circleSizeDisplay;
    IBOutlet NSTextField *circleSizeMinDisplay;
    IBOutlet NSTextField *movieDistanceRedDisplay;
    IBOutlet NSTextField *circleReductionDisplay;
    IBOutlet NSTextField *colorOptionDisplay;
    IBOutlet NSTextField *graphColorTypeDisplay;
    
    IBOutlet NSTextField *currentNameDisplay;
    IBOutlet NSTextField *currentTreatDisplay;
    
    IBOutlet NSButton *colorButton;
    
    IBOutlet NSButton *colorButtonGraph1;
    IBOutlet NSButton *colorButtonGraph2;
    IBOutlet NSButton *colorButtonGraph3;
    IBOutlet NSButton *colorButtonGraph4;
    IBOutlet NSButton *colorButtonGraph5;
    IBOutlet NSButton *colorButtonGraph6;
    IBOutlet NSButton *colorButtonGraph7;
    IBOutlet NSButton *colorButtonGraph8;
    IBOutlet NSButton *colorButtonGraph9;
    IBOutlet NSButton *colorButtonGraph10;
    IBOutlet NSButton *colorButtonGraph11;
    
    IBOutlet NSButton *colorButtonVideo1;
    IBOutlet NSButton *colorButtonVideo2;
    IBOutlet NSButton *colorButtonVideo3;
    IBOutlet NSButton *colorButtonVideo4;
    IBOutlet NSButton *colorButtonVideo5;
    IBOutlet NSButton *colorButtonVideo6;
    IBOutlet NSButton *colorButtonVideo7;
    IBOutlet NSButton *colorButtonVideo8;
    IBOutlet NSButton *colorButtonVideo9;
    IBOutlet NSButton *colorButtonVideo10;
    IBOutlet NSButton *colorButtonVideo11;
    
    IBOutlet NSTextField *growthTreatDisplay;
    IBOutlet NSTextField *growthPrgTreatDisplay;
    IBOutlet NSTextField *growthMidTreatDisplay;
    IBOutlet NSTextField *growthAddTreatDisplay;
    IBOutlet NSTextField *doseBaseDisplay;
    IBOutlet NSTextField *doseMiddleDisplay;
    IBOutlet NSTextField *doseTargetDisplay;
    IBOutlet NSTextField *doseModeDisplay;
    IBOutlet NSTextField *endVariationDisplay;
    IBOutlet NSTextField *selectLingNoDisplay;
    IBOutlet NSTextField *dataBaseOptionDisplay;
    
    IBOutlet NSTextField *lingNoDisplay;
    IBOutlet NSTextField *lingNoDisplay2;
    IBOutlet NSTextField *lingNoDisplay3;
    IBOutlet NSTextField *lingNoDisplay4;
    IBOutlet NSTextField *lingNoDisplay5;
    IBOutlet NSTextField *lingNoDisplay6;
    IBOutlet NSTextField *lingNoDisplay7;
    IBOutlet NSTextField *lingNoDisplay8;
    
    IBOutlet NSTextField *titleFontDisplay;
    IBOutlet NSTextField *videoImageSizeDisplay;
    IBOutlet NSTextField *videoImageSizeOptionDisplay;
    IBOutlet NSTextField *colorToneDisplay;
    IBOutlet NSTextField *colorToneOptionDisplay;
    IBOutlet NSTextField *fluorescentOptionDisplay;
    IBOutlet NSTextField *fluorescentBiasDisplay;
    IBOutlet NSTextField *fluorescentDropDisplay;
    
    IBOutlet NSTextField *fluorescentProgDisplay;
    IBOutlet NSTextField *fluorescentMidDisplay;
    IBOutlet NSTextField *fluorescentAddDisplay;
    
    IBOutlet NSWindow *mainWindowSimWindow;
    IBOutlet NSProgressIndicator *backSave;
    IBOutlet NSProgressIndicator *backSave2;
    
    NSWindowController *mainWindowSimController;
    
    NSTimer *simControllerTimer;
    NSTimer *simControllerTimer2;
    
    id ascIIconversion;
}

-(IBAction)fitModeSet:(id)sender;
-(IBAction)fitPerformSet:(id)sender;
-(IBAction)limitSimSet:(id)sender;
-(IBAction)exportSimdata:(id)sender;

-(IBAction)colorBDSet:(id)sender;
-(IBAction)colorTDSet:(id)sender;
-(IBAction)colorBDCFSet:(id)sender;
-(IBAction)colorBDCFBDSet:(id)sender;
-(IBAction)colorBDCFTDSet:(id)sender;
-(IBAction)colorTDCFSet:(id)sender;
-(IBAction)colorTDCFBDSet:(id)sender;
-(IBAction)colorTDCFTDSet:(id)sender;
-(IBAction)colorTDBDSet:(id)sender;
-(IBAction)colorTDTDSet:(id)sender;
-(IBAction)colorNonDivSet:(id)sender;

-(IBAction)drawBDSet:(id)sender;
-(IBAction)drawTDSet:(id)sender;
-(IBAction)drawBDCFSet:(id)sender;
-(IBAction)drawBDCFBDSet:(id)sender;
-(IBAction)drawBDCFTDSet:(id)sender;
-(IBAction)drawTDCFSet:(id)sender;
-(IBAction)drawTDCFBDSet:(id)sender;
-(IBAction)drawTDCFTDSet:(id)sender;
-(IBAction)drawTDBDSet:(id)sender;
-(IBAction)drawTDTDSet:(id)sender;
-(IBAction)drawNonDivSet:(id)sender;

-(IBAction)color1Set:(id)sender;
-(IBAction)color2Set:(id)sender;
-(IBAction)color3Set:(id)sender;
-(IBAction)color4Set:(id)sender;
-(IBAction)color5Set:(id)sender;
-(IBAction)color6Set:(id)sender;
-(IBAction)color7Set:(id)sender;
-(IBAction)color8Set:(id)sender;
-(IBAction)color9Set:(id)sender;
-(IBAction)color10Set:(id)sender;
-(IBAction)color11Set:(id)sender;
-(IBAction)color12Set:(id)sender;
-(IBAction)color13Set:(id)sender;
-(IBAction)color14Set:(id)sender;
-(IBAction)color15Set:(id)sender;
-(IBAction)color16Set:(id)sender;

-(IBAction)growthInitModeSet:(id)sender;
-(IBAction)recoveryPercentSet:(id)sender;
-(IBAction)dataExportSet:(id)sender;
-(IBAction)parameterExportSet:(id)sender;

-(IBAction)clearSet:(id)sender;
-(IBAction)clearSetA:(id)sender;
-(IBAction)clearSetB:(id)sender;
-(IBAction)clearSetC:(id)sender;
-(IBAction)clearSetD:(id)sender;

-(IBAction)terminateSim:(id)sender;
-(IBAction)distanceRedSet:(id)sender;
-(IBAction)circleSizeRedSet:(id)sender;
-(IBAction)colorModeSet:(id)sender;
-(IBAction)doseModeSet:(id)sender;
-(IBAction)lingNoDataExport:(id)sender;
-(IBAction)targetDataExport:(id)sender;
-(IBAction)databaseLoadOption:(id)sender;
-(IBAction)graphColorOption:(id)sender;
-(IBAction)imageSizeOption:(id)sender;
-(IBAction)mixedLingNoGet:(id)sender;
-(IBAction)colorToneChangeSet:(id)sender;
-(IBAction)fluorescentSimulationSet:(id)sender;

-(void)reDisplayWindow;
-(IBAction)closeWindow:(id)sender;

@end
