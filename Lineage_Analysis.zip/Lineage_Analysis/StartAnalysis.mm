//
//  StartAnalysis.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 10/22/16.
//
//

#import "StartAnalysis.h"

@implementation StartAnalysis

-(IBAction)cellLineageList:(id)sender{
    if (upLoadingProgress == 0){
        if (lineageDataEntryCount != 0){
            if (lineageWindowOperation == 0){
                lineageWindowOperation = 1;
                lineageOpen = 1;
                selectCurrentLineage = -1;
                saveFlag = 0;
                
                lingNo1 = -1;
                lingNo2 = -1;
                lingNo3 = -1;
                lingNo4 = -1;
                lingNo5 = -1;
                lingNo6 = -1;
                lingNo7 = -1;
                lingNo8 = -1;
                
                chNo1 = 1;
                siblingLingHold = 0;
                colorOptionLingHold = 0;
                
                for (int counter1 = 0; counter1 < lineageDataEntryCount; counter1++){
                    if (arraySelectedLing [counter1] == 1){
                        selectCurrentLineage = counter1;
                        break;
                    }
                }
                
                if (selectCurrentLineage != -1){
                    typeLing = arrayTableMain [selectCurrentLineage][1];
                    seriesLing = arrayTableMain [selectCurrentLineage][2];
                    analysisLing = arrayTableMain [selectCurrentLineage][3];
                    treatLing = arrayTableMain [selectCurrentLineage][4];
                    
                    displayNameTreatLing = "nil";
                    displayNameSeriesLing = "nil";
                    displayNameCellLing = "nil";
                    
                    if (typeLing == "LN"){
                        string lineageKListPath = analysisDataFolderPath+"/"+seriesLing+"_AnalysisResults"+"/"+analysisLing+"_IDResults/"+treatLing+"_Results/"+"DisplayNames";
                        string getString;
                        
                        ifstream fin;
                        
                        fin.open(lineageKListPath.c_str(), ios::in);
                        
                        if (fin.is_open()){
                            getline(fin, getString);
                            if (getString != "nil") displayNameCellLing = getString;
                            
                            getline(fin, getString);
                            
                            if (getString != "nil") displayNameTreatLing = getString;
                            
                            getline(fin, getString);
                            
                            if (getString != "nil") displayNameSeriesLing = getString;
                            
                            fin.close();
                        }
                    }
                    
                    liveDisplayHold = 0;
                    
                    int ifNoOfEntry = atoi(arrayTableMain [selectCurrentLineage][12].c_str());
                    
                    //for (int counterA = 0; counterA < 1; counterA++){
                    //    for (int counterB = 0; counterB < arrayTableMainHold [lineageDataEntryCount-1] ; counterB++) cout<<" "<< arrayTableMain [selectCurrentLineage][counterA+counterB];
                    //    cout<<" arrayTableMain "<<counterA<<endl;
                    //}
                    
                    ifOneAllHold = -1;
                    
                    if (arrayTableDetail [selectCurrentLineage][4] != 0){
                        ifRangeLing = to_string(arrayTableDetail [selectCurrentLineage][4])+"-"+to_string(arrayTableDetail [selectCurrentLineage][5]);
                        
                        ifRangeHigh = arrayTableDetail [selectCurrentLineage][5];
                        ifRangeLow = arrayTableDetail [selectCurrentLineage][4];
                    }
                    else{
                        
                        ifRangeLing = "nil-nil";
                        ifRangeHigh = 0;
                        ifRangeLow = 0;
                    }
                    
                    if (noOfChListStatus == 0){
                        arrayNoOfChList = new int [ifNoOfEntry*2+10];
                        noOfChListStatus = 1;
                        noOfChListCount = 0;
                    }
                    else{
                        
                        delete [] arrayNoOfChList;
                        arrayNoOfChList = new int [ifNoOfEntry*2+10];
                        noOfChListStatus = 1;
                        noOfChListCount = 0;
                    }
                    
                    //for (int counterA = 0; counterA < arrayIFTimeLineDataEntryHold [selectCurrentLineage]/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayIFTimeLineData [selectCurrentLineage][counterA*6+counterB];
                    //    cout<<" arrayIFTimeLineData "<<counterA+1<<endl;
                    //}
                    
                    for (int counter1 = 0; counter1 < arrayIFTimeLineDataEntryHold [selectCurrentLineage]/9; counter1++){
                        if (arrayIFTimeLineData [selectCurrentLineage][counter1*9+2] != 0 && arrayIFTimeLineData [selectCurrentLineage][counter1*9+1] >= 1){
                            for (int counter2 = 0; counter2 < arrayIfTimeStatusHold [selectCurrentLineage]/2; counter2++){
                                if (arrayIFTimeLineData [selectCurrentLineage][counter1*9] == arrayIfTimeStatus [selectCurrentLineage][counter2*2] && arrayIfTimeStatus [selectCurrentLineage][counter2*2+1] == 0){
                                    arrayNoOfChList [noOfChListCount] = arrayIfTimeStatus [selectCurrentLineage][counter2*2], noOfChListCount++;
                                    arrayNoOfChList [noOfChListCount] = arrayIFTimeLineData [selectCurrentLineage][counter1*9+2], noOfChListCount++;
                                }
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < noOfChListCount/2; counterA++){
                    //    cout<<counterA<<" "<<arrayNoOfChList [counterA*2] <<" "<<arrayNoOfChList [counterA*2+1] <<" NoOfChList"<<endl;
                    //}
                    
                    lineageCurrentPosition = 1;
                    int lineageLinkListLengthLing = arrayLineageLink [selectCurrentLineage][0];
                    int lastCounterPosition = -1;
                    
                    for (int counter1 = 1; counter1 < lineageLinkHold [selectCurrentLineage]/lineageLinkListLengthLing; counter1++){
                        if (arrayLineageLink [selectCurrentLineage][counter1*lineageLinkListLengthLing] > 0){
                            lineageCurrentPosition = counter1;
                            break;
                        }
                    }
                    
                    lineageCurrentPositionHold = lineageCurrentPosition;
                    
                    int displayCount = 0;
                    
                    for (int counter1 = 1; counter1 < lineageLinkHold [selectCurrentLineage]/lineageLinkListLengthLing; counter1++){
                        if (arrayLineageLink [selectCurrentLineage][counter1*lineageLinkListLengthLing] > 0){
                            lastCounterPosition = counter1;
                            
                            if (displayCount == 0) lingNo1 = counter1, displayCount++;
                            else if (displayCount == 1) lingNo2 = counter1, displayCount++;
                            else if (displayCount == 2) lingNo3 = counter1, displayCount++;
                            else if (displayCount == 3) lingNo4 = counter1, displayCount++;
                            else if (displayCount == 4) lingNo5 = counter1, displayCount++;
                            else if (displayCount == 5) lingNo6 = counter1, displayCount++;
                            else if (displayCount == 6) lingNo7 = counter1, displayCount++;
                            else if (displayCount == 7){
                                lingNo8 = counter1;
                                displayCount++;
                                break;
                            }
                        }
                    }
                    
                    if (lastCounterPosition != -1) lineageCurrentPosition = lastCounterPosition;
                    
                    int maxLingNoTemp = 0;
                    
                    for (unsigned long counter1 = 0; counter1 < arrayLineageDataEntryHold [selectCurrentLineage]/9; counter1++){
                        if (maxLingNoTemp < arrayLineageData [selectCurrentLineage][counter1*9+6]) maxLingNoTemp = arrayLineageData [selectCurrentLineage][counter1*9+6];
                    }
                    
                    lineageLinkListLGLLength = arrayLineageLink [selectCurrentLineage][0];
                    
                    delete [] arrayLineageLinkListLGL;
                    arrayLineageLinkListLGL = new int [(maxLingNoTemp+1)*lineageLinkListLGLLength+11];
                    lineageLinkListLGLCount = 0;
                    lineageLinkListLGLLimit = (maxLingNoTemp+1)*lineageLinkListLGLLength+11;
                    
                    for (int counter1 = 0; counter1 < (maxLingNoTemp+1)*lineageLinkListLGLLength+11; counter1++) arrayLineageLinkListLGL [counter1] = 0;
                    
                    for (int counter1 = 0; counter1 < lineageLinkHold [selectCurrentLineage]; counter1++){
                        arrayLineageLinkListLGL [lineageLinkListLGLCount] = arrayLineageLink [selectCurrentLineage][counter1], lineageLinkListLGLCount++;
                    }
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLineageController object:self];
                }
            }
            
            if (lineageWindowOperation == 2) lineageWindowOperation = 3;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Lineage Data Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)growthCurve:(id)sender{
    if (upLoadingProgress == 0){
        if (lineageDataEntryCount != 0){
            if (growthCurveWindowOperation == 0){
                growthCurveWindowOperation = 1;
                growthCurveOpen = 1;
                
                verticalScaleLowHold = 0;
                verticalScaleHighHold = 0;
                horizontalScaleLowHold = 0;
                horizontalScaleHighHold = 0;
                individualOverLayHold = 0;
                normalizeStatusHold = 0;
                includeTDHDStatusHold = 0;
                doublingTimeSimulateHold = 0;
                
                int timeMax = 0;
                int maxEntry = 0;
                
                for (int counter1 = 0; counter1 < lineageDataEntryCount; counter1++){
                    if (arraySelectedLing [counter1] == 1 && maxEntry < 32){
                        if (timeMax < arrayTableDetail [counter1][3]*atoi(arrayLineageDataType [counter1][5].c_str())){
                            timeMax = arrayTableDetail [counter1][3]*atoi(arrayLineageDataType [counter1][5].c_str());
                            maxEntry++;
                        }
                    }
                }
                
                if (timeMax != 0){
                    horizontalScaleMaxHold = timeMax+50;
                    horizontalScaleHighHold = horizontalScaleMaxHold;
                    
                    int *cellNumberHold = new int [horizontalScaleHighHold+50];
                    int actualTime = 0;
                    int maxCellNo = 0;
                    int timeEnd = 0;
                    maxEntry = 0;
                    
                    for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
                        if (arraySelectedLing [counter2] == 1 && maxEntry < 32){
                            for (int counter3 = 0; counter3 < horizontalScaleHighHold+50; counter3++){
                                cellNumberHold [counter3] = 0;
                            }
                            
                            timeEnd = arrayTableDetail [counter2][3];
                            
                            for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [counter2]/9; counter3++){
                                actualTime = arrayLineageData [counter2][counter3*9+2]*atoi(arrayLineageDataType [counter2][5].c_str());
                                
                                if (arrayLineageData [counter2][counter3*9+2] <= timeEnd){
                                    cellNumberHold [actualTime]++;
                                }
                            }
                            
                            for (int counter3 = 0; counter3 < horizontalScaleHighHold+50; counter3++){
                                if (cellNumberHold [counter3] > maxCellNo) maxCellNo = cellNumberHold [counter3] ;
                            }
                            
                            maxEntry++;
                        }
                    }
                    
                    delete [] cellNumberHold;
                    
                    if (maxCellNo < 100) verticalScaleMaxHold = 500;
                    else verticalScaleMaxHold = maxCellNo+50;
                    
                    verticalScaleHighHold = verticalScaleMaxHold;
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToGrowthCurveController object:self];
                }
            }
            
            if (growthCurveWindowOperation == 2) growthCurveWindowOperation = 3;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Lineage Data Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)cellDivision:(id)sender{
    if (upLoadingProgress == 0){
        if (lineageDataEntryCount != 0){
            if (cellDivisionWindowOperation == 0){
                cellDivisionWindowOperation = 1;
                cellDivisionOpen = 1;
                
                horizontalScaleLowDivisionHold = 0;
                horizontalScaleHighDivisionHold = 0;
                verticalScaleHighUpDivisionHold = 0;
                verticalScaleHighDownDivisionHold = 0;
                belowDisplayType = 0;
                maxDDNumberHold = 0;
                maxOtherHold = 0;
                
                int timeMax = 0;
                int maxEntry = 0;
                
                for (int counter1 = 0; counter1 < lineageDataEntryCount; counter1++){
                    if (arraySelectedLing [counter1] == 1){
                        if (timeMax < arrayTableDetail [counter1][3]*atoi(arrayLineageDataType [counter1][5].c_str())){
                            timeMax = arrayTableDetail [counter1][3]*atoi(arrayLineageDataType [counter1][5].c_str());
                            maxEntry++;
                        }
                    }
                }
                
                if (timeMax != 0){
                    horizontalScaleMaxDivisionHold = timeMax+50;
                    horizontalScaleHighDivisionHold = horizontalScaleMaxDivisionHold;
                    
                    int *cellNumberHold = new int [horizontalScaleHighDivisionHold+50];
                    int *cellNumberHold2 = new int [horizontalScaleHighDivisionHold+50];
                    int actualTime = 0;
                    int maxCellNoDD = 0;
                    int maxCellNoOther = 0;
                    int timeEnd = 0;
                    maxEntry = 0;
                    
                    for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
                        if (arraySelectedLing [counter2] == 1 && maxEntry < 8){
                            for (int counter3 = 0; counter3 < horizontalScaleHighDivisionHold+50; counter3++){
                                cellNumberHold [counter3] = 0;
                                cellNumberHold2 [counter3] = 0;
                            }
                            
                            timeEnd = arrayTableDetail [counter2][3];
                            
                            for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [counter2]/9; counter3++){
                                actualTime = arrayLineageData [counter2][counter3*9+2]*atoi(arrayLineageDataType [counter2][5].c_str());
                                
                                if (arrayLineageData [counter2][counter3*9+2] <= timeEnd){
                                    if (arrayLineageData [counter2][counter3*9+3] == 31){
                                        cellNumberHold [actualTime]++;
                                    }
                                    
                                    if (arrayLineageData [counter2][counter3*9+3] == 41 || arrayLineageData [counter2][counter3*9+3] == 51 || arrayLineageData [counter2][counter3*9+3] == 7 || arrayLineageData [counter2][counter3*9+3] == 91){
                                        cellNumberHold2 [actualTime]++;
                                    }
                                }
                            }
                            
                            for (int counter3 = 0; counter3 < horizontalScaleHighDivisionHold+50; counter3++){
                                if (cellNumberHold [counter3] > maxCellNoDD) maxCellNoDD = cellNumberHold [counter3];
                                if (cellNumberHold2 [counter3] > maxCellNoOther) maxCellNoOther = cellNumberHold2 [counter3];
                            }
                            
                            maxEntry++;
                        }
                    }
                    
                    delete [] cellNumberHold;
                    delete [] cellNumberHold2;
                    
                    if (maxCellNoDD < 20) maxDDNumberHold = 20;
                    else maxDDNumberHold = maxCellNoDD+10;
                    
                    if (maxCellNoOther < 10) maxOtherHold = 10;
                    else maxOtherHold = maxCellNoOther+10;
                    
                    verticalScaleMaxUpDivisionHold = maxDDNumberHold;
                    verticalScaleHighUpDivisionHold = verticalScaleMaxUpDivisionHold;
                    
                    verticalScaleMaxDownDivisionHold = maxOtherHold;
                    verticalScaleHighDownDivisionHold = verticalScaleMaxDownDivisionHold;
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToCellDivisionController object:self];
                }
            }
            
            if (cellDivisionWindowOperation == 2) cellDivisionWindowOperation = 3;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Lineage Data Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)doublingTime:(id)sender{
    if (upLoadingProgress == 0){
        if (lineageDataEntryCount != 0){
            if (doublingTimeWindowOperation == 0){
                doublingTimeWindowOperation = 1;
                doublingTimeOpen = 1;
                
                horizontalScaleLowDoublingTimeHold = 0;
                horizontalScaleHighDoublingTimeHold = 0;
                verticalScaleHighDoublingHold = 0;
                
                int timeMax = 0;
                int maxEntry = 0;
                
                for (int counter1 = 0; counter1 < lineageDataEntryCount; counter1++){
                    if (arraySelectedLing [counter1] == 1 && maxEntry < 12){
                        if (timeMax < arrayTableDetail [counter1][3]*atoi(arrayLineageDataType [counter1][5].c_str())){
                            timeMax = arrayTableDetail [counter1][3]*atoi(arrayLineageDataType [counter1][5].c_str());
                            maxEntry++;
                        }
                    }
                }
                
                int *cellNumberHold = new int [timeMax+50];
                int endTime = 0;
                maxEntry = 0;
                
                int maxTimeSet = 0;
                int maxTimeSetHold = 0;
                int maxEntrySet = 0;
                int maxEntrySetHold = 0;
                
                for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
                    if (arraySelectedLing [counter2] == 1 && maxEntry < 12){
                        for (int counter3 = 0; counter3 < timeMax+50; counter3++){
                            cellNumberHold [counter3] = 0;
                        }
                        
                        for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [counter2]/9; counter3++){
                            if ((arrayLineageData [counter2][counter3*9+3] == 31 || arrayLineageData [counter2][counter3*9+3] == 41 || arrayLineageData [counter2][counter3*9+3] == 51)){
                                endTime = 0;
                                
                                for (unsigned long counter4 = counter3+1; counter4 < arrayLineageDataEntryHold [counter2]/9; counter4++){
                                    if (arrayLineageData [counter2][counter3*9+5] == arrayLineageData [counter2][counter4*9+5] && arrayLineageData [counter2][counter3*9+6] == arrayLineageData [counter2][counter4*9+6] && (arrayLineageData [counter2][counter4*9+3] == 32 || arrayLineageData [counter2][counter4*9+3] == 42 || arrayLineageData [counter2][counter4*9+3] == 52)){
                                        endTime = arrayLineageData [counter2][counter4*9+2];
                                    }
                                    else if (arrayLineageData [counter2][counter3*9+5] != arrayLineageData [counter2][counter4*9+5] || arrayLineageData [counter2][counter3*9+6] != arrayLineageData [counter2][counter4*9+6]){
                                        break;
                                    }
                                }
                                
                                if (endTime != 0){
                                    cellNumberHold [(endTime-arrayLineageData [counter2][counter3*9+2])*atoi(arrayLineageDataType [counter2][5].c_str())]++;
                                }
                            }
                        }
                        
                        for (int counter3 = timeMax; counter3 > 0; counter3--){
                            if (cellNumberHold [counter3] != 0){
                                maxTimeSet = counter3;
                                break;
                            }
                        }
                        
                        if (maxTimeSet > maxTimeSetHold) maxTimeSetHold = maxTimeSet;
                        
                        maxEntrySet = 0;
                        
                        for (int counter3 = 0; counter3 <= timeMax; counter3++){
                            if (cellNumberHold [counter3] > maxEntrySet){
                                maxEntrySet = cellNumberHold [counter3];
                            }
                        }
                        
                        if (maxEntrySet > maxEntrySetHold) maxEntrySetHold = maxEntrySet;
                        
                        maxEntry++;
                    }
                }
                
                horizontalScaleMaxDoublingTimeHold = maxTimeSetHold+50;
                horizontalScaleHighDoublingTimeHold = maxTimeSetHold+50;
                verticalScaleMaxDoublingTimeHold = maxEntrySetHold+10;
                verticalScaleHighDoublingHold = maxEntrySetHold+10;
                
                rangeDoubleSt1 = 0;
                rangeDoubleSt2 = 0;
                rangeDoubleSt3 = 0;
                rangeDoubleSt4 = 0;
                rangeDoubleEd1 = 0;
                rangeDoubleEd2 = 0;
                rangeDoubleEd3 = 0;
                rangeDoubleEd4 = 0;
                
                delete [] cellNumberHold;
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDoublingTimeController object:nil];
            }
            
            if (doublingTimeWindowOperation == 2) doublingTimeWindowOperation = 3;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Lineage Data Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)categoryAnalysis:(id)sender{
    if (upLoadingProgress == 0){
        if (lineageDataEntryCount != 0){
            if (progenyNoWindowOperation == 0){
                progenyNoWindowOperation = 1;
                
                if (categoryResultsHoldStatus == 0){
                    arrayCategoryResultsHold = new string [600];
                    categoryResultsHoldCount = 0;
                    categoryResultsHoldLimit = 600;
                    categoryResultsHoldStatus = 1;
                }
                
                if (categoryRangeHoldStatus == 0){
                    arrayCategoryRangeHold = new int [350];
                    categoryRangeHoldCount = 0;
                    categoryRangeHoldStatus = 1;
                    
                    arrayCategoryRangeHold [0] = 1, categoryRangeHoldCount++;
                    arrayCategoryRangeHold [1] = 0, categoryRangeHoldCount++;
                    arrayCategoryRangeHold [2] = 0, categoryRangeHoldCount++;
                    
                    int rangeStart = 1;
                    int rangeEnd = 10;
                    int rangeIncrement = 0;
                    
                    for (int counter1 = 1; counter1 <= 5; counter1++){
                        arrayCategoryRangeHold [counter1*3] = counter1+1, categoryRangeHoldCount++;
                        arrayCategoryRangeHold [counter1*3+1] = rangeStart+rangeIncrement, categoryRangeHoldCount++;
                        arrayCategoryRangeHold [counter1*3+2] = rangeEnd+rangeIncrement, categoryRangeHoldCount++;
                        
                        rangeIncrement = rangeIncrement+10;
                    }
                    
                    arrayCategoryRangeHold [categoryRangeHoldCount] = 7, categoryRangeHoldCount++;
                    arrayCategoryRangeHold [categoryRangeHoldCount] = rangeEnd+rangeIncrement-10+1, categoryRangeHoldCount++;
                    arrayCategoryRangeHold [categoryRangeHoldCount] = 100000000, categoryRangeHoldCount++;
                }
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToProgenyNoController object:self];
            }
            
            if (progenyNoWindowOperation == 2) progenyNoWindowOperation = 3;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Lineage Data Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)progenyAnalysis:(id)sender{
    if (upLoadingProgress == 0){
        if (lineageDataEntryCount != 0){
            if (progenyAnalysisWindowOperation == 0){
                progenyAnalysisWindowOperation = 1;
                
                if (progenyAnalysisResultsHoldStatus == 0){
                    arrayProgenyAnalysisResultsHold = new string [600];
                    progenyAnalysisResultsHoldCount = 0;
                    progenyAnalysisResultsHoldLimit = 600;
                    progenyAnalysisResultsHoldStatus = 1;
                }
                
                if (progenyAnalysisRangeHoldStatus == 0){
                    arrayProgenyAnalysisRangeHold = new int [350];
                    progenyAnalysisRangeHoldCount = 0;
                    progenyAnalysisRangeHoldStatus = 1;
                    
                    arrayProgenyAnalysisRangeHold [0] = 1, progenyAnalysisRangeHoldCount++;
                    arrayProgenyAnalysisRangeHold [1] = 0, progenyAnalysisRangeHoldCount++;
                    arrayProgenyAnalysisRangeHold [2] = 0, progenyAnalysisRangeHoldCount++;
                    
                    int rangeStart = 1;
                    int rangeEnd = 10;
                    int rangeIncrement = 0;
                    
                    for (int counter1 = 1; counter1 <= 5; counter1++){
                        arrayProgenyAnalysisRangeHold [counter1*3] = counter1+1, progenyAnalysisRangeHoldCount++;
                        arrayProgenyAnalysisRangeHold [counter1*3+1] = rangeStart+rangeIncrement, progenyAnalysisRangeHoldCount++;
                        arrayProgenyAnalysisRangeHold [counter1*3+2] = rangeEnd+rangeIncrement, progenyAnalysisRangeHoldCount++;
                        
                        rangeIncrement = rangeIncrement+10;
                    }
                    
                    arrayProgenyAnalysisRangeHold [progenyAnalysisRangeHoldCount] = 7, progenyAnalysisRangeHoldCount++;
                    arrayProgenyAnalysisRangeHold [progenyAnalysisRangeHoldCount] = rangeEnd+rangeIncrement-10+1, progenyAnalysisRangeHoldCount++;
                    arrayProgenyAnalysisRangeHold [progenyAnalysisRangeHoldCount] = 100000000, progenyAnalysisRangeHoldCount++;
                }
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToProgenyAnalysisController object:self];
            }
            
            if (progenyAnalysisWindowOperation == 2) progenyAnalysisWindowOperation = 3;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Lineage Data Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)trimMerge:(id)sender{
    if (upLoadingProgress == 0){
        if (lineageDataEntryCount != 0){
            if (trimWindowOperation == 0){
                trimWindowOperation = 1;
                trimOpen = 1;
                
                if (trimResultsHoldStatus == 0){
                    arrayTrimResultsHold = new string [700];
                    trimResultsHoldCount = 0;
                    trimResultsHoldStatus = 1;
                }
                
                if (mergeResultsHoldStatus == 0){
                    arrayMergeResultsHold = new string [700];
                    mergeResultsHoldCount = 0;
                    mergeResultsHoldStatus = 1;
                }
                
                for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
                    arrayTrimResultsHold [trimResultsHoldCount] = arrayTableMain [counter2][1], trimResultsHoldCount++;
                    arrayTrimResultsHold [trimResultsHoldCount] = arrayTableMain [counter2][2], trimResultsHoldCount++;
                    arrayTrimResultsHold [trimResultsHoldCount] = arrayTableMain [counter2][3], trimResultsHoldCount++;
                    arrayTrimResultsHold [trimResultsHoldCount] = arrayTableMain [counter2][4], trimResultsHoldCount++;
                    arrayTrimResultsHold [trimResultsHoldCount] = to_string(arrayTableDetail [counter2][3]), trimResultsHoldCount++;
                    arrayTrimResultsHold [trimResultsHoldCount] = "", trimResultsHoldCount++;
                    
                    arrayMergeResultsHold [mergeResultsHoldCount] = arrayTableMain [counter2][1], mergeResultsHoldCount++;
                    arrayMergeResultsHold [mergeResultsHoldCount] = arrayTableMain [counter2][2], mergeResultsHoldCount++;
                    arrayMergeResultsHold [mergeResultsHoldCount] = arrayTableMain [counter2][3], mergeResultsHoldCount++;
                    arrayMergeResultsHold [mergeResultsHoldCount] = arrayTableMain [counter2][4], mergeResultsHoldCount++;
                    arrayMergeResultsHold [mergeResultsHoldCount] = to_string(arrayTableDetail [counter2][3]), mergeResultsHoldCount++;
                    arrayMergeResultsHold [mergeResultsHoldCount] = "", mergeResultsHoldCount++;
                }
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTrimController object:self];
            }
            
            if (trimWindowOperation == 2) trimWindowOperation = 3;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Lineage Data Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)eventAnalysis:(id)sender{
    if (upLoadingProgress == 0){
        if (lineageDataEntryCount != 0){
            if (eventAnalysisWindowOperation == 0){
                eventAnalysisWindowOperation = 1;
                
                if (eventAnalysisResultsHoldStatus == 0){
                    arrayEventAnalysisResultsHold = new string [600];
                    eventAnalysisResultsHoldCount = 0;
                    eventAnalysisResultsHoldStatus = 1;
                }
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToEventAnalysisController object:self];
            }
            
            if (eventAnalysisWindowOperation == 2) eventAnalysisWindowOperation = 3;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Lineage Data Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)lineageSelect:(id)sender{
    if (upLoadingProgress == 0){
        if (lineageDataEntryCount != 0){
            if (lineageSelectWindowOperation == 0){
                lineageSelectWindowOperation = 1;
                lineageSelectOpen = 1;
                fusionMoveStatus = 0;
                
                if (lineageSelectHoldStatus == 0){
                    arrayLineageSelectHold = new string [600];
                    lineageSelectHoldCount = 0;
                    lineageSelectHoldStatus = 1;
                }
                
                for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
                    arrayLineageSelectHold [lineageSelectHoldCount] = arrayTableMain [counter2][1], lineageSelectHoldCount++;
                    arrayLineageSelectHold [lineageSelectHoldCount] = arrayTableMain [counter2][2], lineageSelectHoldCount++;
                    arrayLineageSelectHold [lineageSelectHoldCount] = arrayTableMain [counter2][3], lineageSelectHoldCount++;
                    arrayLineageSelectHold [lineageSelectHoldCount] = arrayTableMain [counter2][4], lineageSelectHoldCount++;
                }
                
                if (lineageSelectLineageHoldStatus == 0){
                    arrayLineageSelectLineageHold = new int[600];
                    lineageSelectLineageHoldCount = 0;
                    lineageSelectLineageHoldLimit = 600;
                    lineageSelectLineageHoldStatus = 1;
                }
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLineageSelectController object:self];
            }
            
            if (lineageSelectWindowOperation == 2) lineageSelectWindowOperation = 3;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Lineage Data Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)mainWindowMagSet:(id)sender{
    if (upLoadingProgress == 0){
        if (lineageDataEntryCount != 0){
            if (mainWindowMagOperation == 0){
                mainWindowMagOperation = 1;
                mainWindowMagOpen = 1;
                lowXlow = 0;
                highXhigh = 0;
                lowXhigh = 0;
                valueUK = 0;
                lineageDisplayOption = 0;
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMainWindowMagnificationController object:self];
            }
            
            if (mainWindowMagOperation == 2) mainWindowMagOperation = 3;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Lineage Data Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)doubCompSet:(id)sender{
    if (upLoadingProgress == 0){
        if (lineageDataEntryCount != 0){
            if (doubCompOperation == 0){
                doubCompOperation = 1;
                
                if (progenyDoubleCompResultsHoldStatus == 0){
                    arrayProgenyDoubleCompResultsHold = new string [600];
                    progenyDoubleCompResultsHoldCount = 0;
                    progenyDoubleCompResultsHoldLimit = 600;
                    progenyDoubleCompResultsHoldStatus = 1;
                }
                
                if (progenyDoubleCompHoldStatus == 0){
                    arrayDoubleCompRangeHold = new int [350];
                    progenyDoubleCompHoldCount = 0;
                    progenyDoubleCompHoldStatus = 1;
                    
                    int rangeStart = 0;
                    int rangeEnd = 100;
                    int rangeIncrement = 0;
                    
                    for (int counter1 = 0; counter1 <= 4; counter1++){
                        arrayDoubleCompRangeHold [counter1*3] = counter1+1, progenyDoubleCompHoldCount++;
                        arrayDoubleCompRangeHold [counter1*3+1] = rangeStart+rangeIncrement, progenyDoubleCompHoldCount++;
                        arrayDoubleCompRangeHold [counter1*3+2] = rangeEnd+rangeIncrement-1, progenyDoubleCompHoldCount++;
                        
                        rangeIncrement = rangeIncrement+100;
                    }
                    
                    arrayDoubleCompRangeHold [progenyDoubleCompHoldCount] = 6, progenyDoubleCompHoldCount++;
                    arrayDoubleCompRangeHold [progenyDoubleCompHoldCount] = rangeEnd+rangeIncrement-100, progenyDoubleCompHoldCount++;
                    arrayDoubleCompRangeHold [progenyDoubleCompHoldCount] = 100000000, progenyDoubleCompHoldCount++;
                }
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDoubCompController object:self];
            }
            
            if (doubCompOperation == 2) doubCompOperation = 3;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Lineage Data Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)motilitySet:(id)sender{
    if (upLoadingProgress == 0){
        if (lineageDataEntryCount != 0){
            if (motilityOperation == 0){
                motilityOperation = 1;
                
                motilityColorHold = 0;
                markerStartColorHold = 105;
                markerEndColorHold = 105;
                markerMidColorHold = 105;
                markerMidValueHold = 0;
                motilityColorStatusHold = 0;
                motilityDisplayScaleMaxHold = 0;
                motilityVerticalStartHold = 0;
                motilityHorizontalStartHold = 0;
                motilityTimeStartHold = 1;
                motilityTimeEndHold = 1000;
                motilityTableCategoryHold = 0;
                motilityCellNoHold = 0;
                motilityAnalysisPerformHold = 0;
                fixSizeHold = 0;
                lingLineWidthMortHold = 1;
                lingLineWidthDisplayMortHold = 1;
                shiftX = 0;
                shiftY = 0;
                
                arrayMotilityResultsHold = new string [1000];
                motilityResultsHoldStatus = 1;
                motilityResultsHoldCount = 0;
                motilityResultsHoldLimit = 1000;
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMotilityController object:self];
            }
            
            if (motilityOperation == 2) motilityOperation = 3;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Lineage Data Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)simulationSet:(id)sender{
    if (upLoadingProgress == 0){
        if (lineageDataEntryCount != 0){
            if (simulationOperation == 0){
                simulationOperation = 1;
                simulationOpen = 1;
                fitA1Hold = 0;
                fitA2Hold = 0;
                fitA3Hold = 0;
                fitA4Hold = 0;
                fitB1Hold = 0;
                fitB2Hold = 0;
                fitB3Hold = 0;
                fitB4Hold = 0;
                fitCycleHold = 0;
                fitRangeBEndHold = 0;
                fitTimeStartHold = 0;
                fitModeStatusHold = 0;
                colorNoSimHold = 0;
                simStartModeHold = 0;
                growthProgTimeStartHold = 0;
                growthCycleHold = 0;
                growthInitHold = 0;
                limitSimType = 0;
                recoveryCalculationPercentHold = 20;
                growthProgTimeEndHold = 0;
                growthMidTimeStartHold = 0;
                
                simColorDataHold = new int [30];
                
                for (int counter1 = 0; counter1 < 30; counter1++){
                    simColorDataHold [counter1] = 0;
                }
                
                simColorDataHoldStatus = 1;
                
                simProcessDataBaseHold = new double [100];
                simProcessDataMiddleHold = new double [100];
                simProcessDataProgHold = new double [100];
                simProcessDataAddHold = new double [100];
                
                for (int counter1 = 0; counter1 < 100; counter1++){
                    simProcessDataBaseHold [counter1] = 0;
                    simProcessDataMiddleHold [counter1] = 0;
                    simProcessDataProgHold [counter1] = 0;
                    simProcessDataAddHold [counter1] = 0;
                }
                
                simProcessDataHoldStatus = 1;
                
                if (simListHoldStatus == 0){
                    arraySimListHold = new string [700];
                    simListHoldCount = 0;
                    simListHoldStatus = 1;
                }
                
                for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
                    arraySimListHold [simListHoldCount] = arrayTableMain [counter2][3], simListHoldCount++;
                    arraySimListHold [simListHoldCount] = arrayTableMain [counter2][4], simListHoldCount++;
                }
                
                simulationDistributionData = new int [100];
                simulationDistributionDataCount = 0;
                simulationDistributionProgData = new int [100];
                simulationDistributionProgDataCount = 0;
                simulationDistributionMidData = new int [100];
                simulationDistributionMidDataCount = 0;
                simulationDistributionAddData = new int [100];
                simulationDistributionAddDataCount = 0;
                simulationDistributionDataStatus = 1;
                simulationFluorescentData = new int [100];
                simulationFluorescentDataCount = 0;
                simulationFluorescentDataStatus = 1;
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSimulationController object:self];
            }
            
            if (simulationOperation == 2) simulationOperation = 3;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Lineage Data Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

@end
