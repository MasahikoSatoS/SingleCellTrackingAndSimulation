//
//  MotilityDisplay.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2018-03-06.
//
//

#ifndef MOTILITYDISPLAY_H
#define MOTILITYDISPLAY_H
#import "Controller.h" 
#endif

@interface MotilityDisplay : NSView{
    int mouseDragFlag; //Display control
    double xPointDownDisplay; //Display control
    double yPointDownDisplay; //Display control
    double xPositionAdjustDisplay; //Display control
    double yPositionAdjustDisplay; //Display control
    double xPointDragDisplay; //Display control
    double yPointDragDisplay; //Display control
    double xPositionMoveDisplay; //Display control
    double yPositionMoveDisplay; //Display control
    double xPositionDisplay; //X Position Image Origin
    double yPositionDisplay; //Y Position Image Origin
    int imageWidthDisplay; //Image width hold
    int imageHeightDisplay; //Image Height
    int magnificationDisplay; //Magnification fold
    double windowWidthDisplay; //Window/Image position adjust
    double windowHeightDisplay; //Window/Image position adjust
    
    IBOutlet NSWindow *motilityWindow;
}

-(void)dealloc;
-(void)mouseDown:(NSEvent *)event;
-(void)mouseUp:(NSEvent *)event;
-(void)mouseDraged:(NSEvent *)event;
-(void)keyDown:(NSEvent *)event;

-(BOOL)acceptsFirstResponder;

@end
