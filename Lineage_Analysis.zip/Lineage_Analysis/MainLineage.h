//
//  MainLineage.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 9/1/16.
//
//

#ifndef MAINLINEAGE_H
#define MAINLINEAGE_H
#import "Controller.h" 
#endif

@interface MainLineage : NSView{
    double xPositionAdjustDisplay; //X Position Magnification Adjust
    double yPositionAdjustDisplay; //Y Position Magnification Adjust
    double xPointDownDisplay; //X Position Mouse Down
    double yPointDownDisplay; //Y Position Mouse Down
    double xPointDragDisplay; //X Position Mouse drag
    double yPointDragDisplay; //Y Position Mouse drag
    double xPositionMoveDisplay; //X Position Total Move by Drag
    double yPositionMoveDisplay; //Y Position Total Move by Drag
    
    int lingNoForFuse1; //Ling no for fuse
    int cellNoForFuse1; //Cell no for fuse
    double cellNoCurrent1; //Cell number current
    int lingNoForFuse2; //Ling no for fuse
    int cellNoForFuse2; //Cell no for fuse
    double cellNoCurrent2; //Cell number current
    int fusionSetFlag; //Fusion set flag
    int fusionSetCount; //Fusion set count
    
    IBOutlet NSWindow *displayLineageWindow;
}

-(void)dealloc;
-(BOOL)acceptsFirstResponder;

-(void)mouseDown:(NSEvent *)event;
-(void)keyDown:(NSEvent *)event;

@end
