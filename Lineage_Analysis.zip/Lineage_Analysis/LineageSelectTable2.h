//
//  LineageSelectTable2.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2017-06-08.
//
//

#ifndef LINEAGESELECTTABLE2_H
#define LINEAGESELECTTABLE2_H
#import "Controller.h" 
#endif

@interface LineageSelectTable2 : NSObject <NSTableViewDataSource>{
    IBOutlet NSTableView *lineageSelectTable2;
}

-(id)init;
-(void)dealloc;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;
-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex;

@end
