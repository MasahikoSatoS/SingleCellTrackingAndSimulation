//
//  main.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 10/11/18.
//  Copyright Masahiko Sato 2010. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[]){
    return NSApplicationMain(argc,  (const char **) argv);
}
