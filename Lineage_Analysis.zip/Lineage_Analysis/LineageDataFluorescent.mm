//
//  LineageDataFluorescent.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 9/5/16.
//
//

#import "LineageDataFluorescent.h"

NSString *notificationToLineageDataFluorescentType = @"notificationExecuteLineageDataFluorescentType";

@implementation LineageDataFluorescent

-(id)init{
    self = [super init];
    
    if (self != nil){
        tableCallLFCount = 0;
        tableCurrentLFRowHold = 0;
        rowIndexLFHold = 0;
        tableViewLFCall = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToLineageDataFluorescentType object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    LineageDataFluorescentTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(display) userInfo:nil repeats:YES];
    
    [tableViewLFList setDataSource:self];
    [tableViewLFList reloadData];
}

-(void)display{
    if (tableCallLFCount == 1){
        tableCallLFCount = 0;
        rowIndexLFHold = tableCurrentLFRowHold;
    }
    
    if (tableCallLFCount > 1) tableCallLFCount = 0;
    
    if (tableViewLFCall == 1){
        tableViewLFCall = 0;
        
        [rangeLowDisplay setStringValue:@"nil"];
        [rangeHighDisplay setStringValue:@"nil"];
        [rangeLowAreaDisplay setStringValue:@"nil"];
        [rangeHighAreaDisplay setStringValue:@"nil"];
        
        [tableViewLFList reloadData];
    }
}

-(int)numberOfRowsInTableView:(NSTableView *)aTableView{
    int tableViewContent = displayEntryNo;
    return tableViewContent;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    NSAttributedString *attrStr;
    
    if (initialArraySet == 1){
        int findOrder = (int)rowIndex+1;
        int findCount = 0;
        
        string displayData1 = "";
        string displayData2 = "";
        string displayData3 = "";
        string displayData4 = "";
        string displayData5 = "";
        string displayData6 = "";
        string displayData7 = "";
        string displayData8 = "";
        
        for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryCount; counter1++){
            if (arrayLineageFluorescentDataType != 0 && atoi(arrayLineageFluorescentDataType [counter1][0].c_str()) == noOfFluorescentDisplay){
                findCount++;
                
                if (findCount == findOrder){
                    displayData1 = arrayLineageFluorescentDataType [counter1][0];
                    displayData2 = arrayLineageFluorescentDataType [counter1][1];
                    displayData3 = arrayLineageFluorescentDataType [counter1][2];
                    displayData4 = arrayLineageFluorescentDataType [counter1][3];
                    displayData5 = arrayLineageFluorescentDataType [counter1][4];
                    displayData6 = arrayLineageFluorescentDataType [counter1][5];
                    displayData7 = arrayLineageFluorescentDataType [counter1][6];
                    displayData8 = arrayLineageFluorescentDataType [counter1][7];
                    
                    break;
                }
            }
        }
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        
        [attributes setObject:[NSFont boldSystemFontOfSize:10] forKey:NSFontAttributeName];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]){
            [attributes setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData2.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL3"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData3.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL4"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData4.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL5"]){
            [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData5.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL6"]){
            [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData6.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL7"]){
            [attributes setObject:[NSColor brownColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData7.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL8"]){
            [attributes setObject:[NSColor brownColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData8.c_str()) attributes:attributes];
        }
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    else{
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL3"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL4"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL5"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL6"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL7"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL8"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    
    return attrStr;
}

-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex{
    tableCallLFCount++;
    tableCurrentLFRowHold = rowIndex;
    
    if (tableCallLFCount == 2){
        if (upLoadingProgress == 0){
            tableCurrentLFRowHold = rowIndexLFHold;
            
            int findOrder = (int)tableCurrentLFRowHold+1;
            int findCount = 0;
            int entryPoint = 0;
            
            for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryCount; counter1++){
                if (atoi(arrayLineageFluorescentDataType [counter1][0].c_str()) == noOfFluorescentDisplay){
                    findCount++;
                    
                    if (findCount == findOrder){
                        entryPoint = counter1;
                        break;
                    }
                }
            }
            
            if (arrayLineageFluorescentDataType != 0 && arrayLineageFluorescentDataType [entryPoint][4] != "nil"){
                [rangeLowDisplay setStringValue:@(arrayLineageFluorescentDataType [entryPoint][4].c_str())];
                [rangeHighDisplay setStringValue:@(arrayLineageFluorescentDataType [entryPoint][5].c_str())];
                [rangeLowAreaDisplay setStringValue:@(arrayLineageFluorescentDataType [entryPoint][6].c_str())];
                [rangeHighAreaDisplay setStringValue:@(arrayLineageFluorescentDataType [entryPoint][7].c_str())];
            }
            else{
                
                [rangeLowDisplay setStringValue:@"nil"];
                [rangeHighDisplay setStringValue:@"nil"];
                [rangeLowAreaDisplay setStringValue:@"nil"];
                [rangeHighAreaDisplay setStringValue:@"nil"];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Uploading In Progress"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else if (tableCallLFCount == 1){
        if (upLoadingProgress == 0){
            tableCurrentLFRowHold = rowIndex;
            
            int findOrder = (int)tableCurrentLFRowHold+1;
            int findCount = 0;
            int entryPoint = 0;
            
            for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryCount; counter1++){
                if (atoi(arrayLineageFluorescentDataType [counter1][0].c_str()) == noOfFluorescentDisplay){
                    findCount++;
                    
                    if (findCount == findOrder){
                        entryPoint = counter1;
                        break;
                    }
                }
            }
            
            if (arrayLineageFluorescentDataType != 0 && arrayLineageFluorescentDataType [entryPoint][4] != "nil"){
                [rangeLowDisplay setStringValue:@(arrayLineageFluorescentDataType [entryPoint][4].c_str())];
                [rangeHighDisplay setStringValue:@(arrayLineageFluorescentDataType [entryPoint][5].c_str())];
                [rangeLowAreaDisplay setStringValue:@(arrayLineageFluorescentDataType [entryPoint][6].c_str())];
                [rangeHighAreaDisplay setStringValue:@(arrayLineageFluorescentDataType [entryPoint][7].c_str())];
            }
            else{
                
                [rangeLowDisplay setStringValue:@"nil"];
                [rangeHighDisplay setStringValue:@"nil"];
                [rangeLowAreaDisplay setStringValue:@"nil"];
                [rangeHighAreaDisplay setStringValue:@"nil"];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Uploading In Progress"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    
    return YES;
}

-(void)tableView:(NSTableView *)aTableView setObjectValue:(id)anObject forTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    int findOrder = (int)rowIndex+1;
    int findCount = 0;
    int entryPoint = -1;
    
    if (upLoadingProgress == 0){
        for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryCount; counter1++){
            if (atoi(arrayLineageFluorescentDataType [counter1][0].c_str()) == noOfFluorescentDisplay){
                findCount++;
                
                if (findCount == findOrder){
                    entryPoint = counter1;
                    break;
                }
            }
        }
        
        NSString *columnIdentifier = [aTableColumn identifier];
        NSString *objectInfo = anObject;
        
        string stringExtract;
        
        if (arrayLineageFluorescentDataType != 0 && [columnIdentifier isEqualToString:@"COL5"] && displayEntryNo > rowIndex && arrayLineageFluorescentDataType [entryPoint][4] != "nil" && entryPoint != -1){
            string nameCheckString = [objectInfo UTF8String];
            
            if (atof(nameCheckString.c_str()) >= 0 && atof(nameCheckString.c_str()) <= 255){
                if (atoi(arrayLineageFluorescentDataType [entryPoint][5].c_str()) > atoi(nameCheckString.c_str())){
                    int ifData = atoi(nameCheckString.c_str());
                    
                    arrayLineageFluorescentDataType [entryPoint][4] = to_string(ifData);
                    
                    [rangeLowDisplay setStringValue:@(arrayLineageFluorescentDataType [entryPoint][4].c_str())];
                    [rangeHighDisplay setStringValue:@(arrayLineageFluorescentDataType [entryPoint][5].c_str())];
                    [rangeLowAreaDisplay setStringValue:@(arrayLineageFluorescentDataType [entryPoint][6].c_str())];
                    [rangeHighAreaDisplay setStringValue:@(arrayLineageFluorescentDataType [entryPoint][7].c_str())];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else{
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else if (arrayLineageFluorescentDataType != 0 && [columnIdentifier isEqualToString:@"COL6"] && displayEntryNo > rowIndex && arrayLineageFluorescentDataType [entryPoint][5] != "nil" && entryPoint != -1){
            string nameCheckString = [objectInfo UTF8String];
            
            if (atof(nameCheckString.c_str()) >= 0 && atof(nameCheckString.c_str()) <= 255){
                if (atoi(arrayLineageFluorescentDataType [entryPoint][4].c_str()) < atoi(nameCheckString.c_str())){
                    int ifData = atoi(nameCheckString.c_str());
                    
                    arrayLineageFluorescentDataType [entryPoint][5] = to_string(ifData);
                    
                    [rangeLowDisplay setStringValue:@(arrayLineageFluorescentDataType [entryPoint][4].c_str())];
                    [rangeHighDisplay setStringValue:@(arrayLineageFluorescentDataType [entryPoint][5].c_str())];
                    [rangeLowAreaDisplay setStringValue:@(arrayLineageFluorescentDataType [entryPoint][6].c_str())];
                    [rangeHighAreaDisplay setStringValue:@(arrayLineageFluorescentDataType [entryPoint][7].c_str())];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else{
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else if (arrayLineageFluorescentDataType != 0 && [columnIdentifier isEqualToString:@"COL7"] && displayEntryNo > rowIndex && arrayLineageFluorescentDataType [entryPoint][6] != "nil" && entryPoint != -1){
            string nameCheckString = [objectInfo UTF8String];
            
            if (atof(nameCheckString.c_str()) >= 0 && atof(nameCheckString.c_str()) <= 999999){
                if (atof(arrayLineageFluorescentDataType [entryPoint][7].c_str()) > atof(nameCheckString.c_str())){
                    int ifData = atoi(nameCheckString.c_str());
                    
                    arrayLineageFluorescentDataType [entryPoint][6] = to_string(ifData);
                    
                    [rangeLowDisplay setStringValue:@(arrayLineageFluorescentDataType [entryPoint][4].c_str())];
                    [rangeHighDisplay setStringValue:@(arrayLineageFluorescentDataType [entryPoint][5].c_str())];
                    [rangeLowAreaDisplay setStringValue:@(arrayLineageFluorescentDataType [entryPoint][6].c_str())];
                    [rangeHighAreaDisplay setStringValue:@(arrayLineageFluorescentDataType [entryPoint][7].c_str())];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else{
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else if (arrayLineageFluorescentDataType != 0 && [columnIdentifier isEqualToString:@"COL8"] && displayEntryNo > rowIndex && arrayLineageFluorescentDataType [entryPoint][7] != "nil" && entryPoint != -1){
            string nameCheckString = [objectInfo UTF8String];
            
            if (atof(nameCheckString.c_str()) >= 0 && atof(nameCheckString.c_str()) <= 9999999){
                if (atoi(arrayLineageFluorescentDataType [entryPoint][6].c_str()) < atoi(nameCheckString.c_str())){
                    int ifData = atoi(nameCheckString.c_str());
                    
                    arrayLineageFluorescentDataType [entryPoint][7] = to_string(ifData);
                    
                    [rangeLowDisplay setStringValue:@(arrayLineageFluorescentDataType [entryPoint][4].c_str())];
                    [rangeHighDisplay setStringValue:@(arrayLineageFluorescentDataType [entryPoint][5].c_str())];
                    [rangeLowAreaDisplay setStringValue:@(arrayLineageFluorescentDataType [entryPoint][6].c_str())];
                    [rangeHighAreaDisplay setStringValue:@(arrayLineageFluorescentDataType [entryPoint][7].c_str())];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                }
                else{
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else if (arrayLineageFluorescentDataType != 0 && [columnIdentifier isEqualToString:@"COL3"] && arrayLineageFluorescentDataType [entryPoint][2] != "nil" && entryPoint != -1){
            string nameCheckString = [objectInfo UTF8String];
            
            if ((int)(nameCheckString.length()) <= 15){
                string ifNameTemp = arrayLineageFluorescentDataType [entryPoint][2];
                arrayLineageFluorescentDataType [entryPoint][2] = nameCheckString;
                
                //for (int counterA = 0; counterA < lineageDataEntryCount; counterA++){
                //    cout<<counterA<<" "<< arrayTableMainHold [counterA]<<" arrayTableMainHold"<<endl;
                //}
                
                for (int counter1 = 0; counter1 < arrayTableMainHold [noOfFluorescentDisplay-1]; counter1++){
                    if (arrayTableMain [noOfFluorescentDisplay-1][counter1] == arrayLineageFluorescentDataType [entryPoint][1].substr(1)){
                        for (int counter2 = counter1; counter2 < arrayTableMainHold [noOfFluorescentDisplay-1]; counter2++){
                            if (arrayTableMain [noOfFluorescentDisplay-1][counter2] == ifNameTemp){
                                arrayTableMain [noOfFluorescentDisplay-1][counter2] = nameCheckString;
                                break;
                            }
                        }
                        
                        break;
                    }
                }
                
                string analysisDataSavePath2 = analysisDataFolderPath+"/"+arrayTableMain [noOfFluorescentDisplay-1][2]+"_AnalysisResults/"+arrayTableMain [noOfFluorescentDisplay-1][3]+"_IDResults/"+arrayTableMain [noOfFluorescentDisplay-1][4]+"_Results/"+"MainTable";
                
                //for (int counterA = 0; counterA < arrayTableMainHold [noOfFluorescentDisplay-1]; counterA++){
                //    cout<<arrayTableMain [noOfFluorescentDisplay-1][counterA]<<" arrayTableMain"<<endl;
                //}
                
                ofstream oin;
                
                oin.open(analysisDataSavePath2.c_str(), ios::out | ios::binary);
                
                for (int counter2 = 0; counter2 < arrayTableMainHold [noOfFluorescentDisplay-1]; counter2++){
                    oin<<arrayTableMain [noOfFluorescentDisplay-1][counter2]<<endl;
                }
                
                oin.close();
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
                
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        
        tableViewLFCall = 1;
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)dealloc{
    if (LineageDataFluorescentTimer) [LineageDataFluorescentTimer invalidate];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToLineageDataFluorescentType object:nil];
}

@end
