//
//  CellGrowthDisplay.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 12/2/16.
//
//

#ifndef CELLGROWTHDISPLAY_H
#define CELLGROWTHDISPLAY_H
#import "Controller.h" 
#endif

@interface CellGrowthDisplay : NSView{
    IBOutlet NSWindow *growthCurveListWindow;
}

-(void)dealloc;
-(BOOL)acceptsFirstResponder;
-(void)mouseDown:(NSEvent *)event;

@end
