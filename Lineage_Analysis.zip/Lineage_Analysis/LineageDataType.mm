//
//  LineageDataType.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 9/2/16.
//
//

#import "LineageDataType.h"

NSString *notificationToLineageDataType = @"notificationExecuteLineageDataType";

@implementation LineageDataType

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToLineageDataType object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    lineageDataWindowController = [[NSWindowController alloc] initWithWindowNibName:@"LineageDataInput"];
    [lineageDataWindowController showWindow:self];
    
    //for (int counterA = 0; counterA < lineageDataEntryCount; counterA++){
    //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayLineageDataType [counterA][counterB];
    //    cout<<" arrayLineageDataType "<<counterA+1<<endl;
    //}
    
    //for (int counterA = 0; counterA < lineageFluorescentDataTypeEntryCount; counterA++){
    //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageFluorescentDataType [counterA][counterB];
    //    cout<<" arrayLineageFluorescentDataType "<<counterA+1<<endl;
    //}
    
    lineageDataOpen = 1;
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLineageDataTable object:self];
}

- (void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [lineageDataWindow frame];
    CGFloat windowHeight = windowSize.size.height;
    
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [lineageDataWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
}

-(IBAction)saveEntry:(id)sender{
    if (upLoadingProgress == 0){
        if (lineageDataEntryCount != 0){
            string savePath;
            
            ofstream oin;
            
            for (int counter1 = 0; counter1 < lineageDataEntryCount; counter1++){
                if (arrayTableMain [counter1][1] == "SO"){
                    savePath = trackDataFolderPath+"/"+arrayLineageDataType [counter1][2]+"_Series/"+arrayLineageDataType [counter1][3]+"_TrackData/*LineageDataAddition-"+arrayLineageDataType [counter1][4]+".dat";
                }
                else savePath = analysisDataFolderPath+"/"+arrayLineageDataType [counter1][2]+"_AnalysisResults/"+arrayLineageDataType [counter1][3]+"_IDResults/"+arrayTableMain [counter1][4]+"_Results/"+"*LineageDataAddition.dat";
                
                oin.open(savePath.c_str(), ios::out);
                oin<<arrayLineageDataType [counter1][0]<<endl;
                oin<<arrayLineageDataType [counter1][1]<<endl;
                oin<<arrayLineageDataType [counter1][2]<<endl;
                oin<<arrayLineageDataType [counter1][3]<<endl;
                oin<<arrayLineageDataType [counter1][4]<<endl;
                oin<<arrayLineageDataType [counter1][5]<<endl;
                oin<<arrayLineageDataType [counter1][6]<<endl;
                
                for (int counter2 = 0; counter2 < lineageFluorescentDataTypeEntryCount; counter2++){
                    if (arrayLineageFluorescentDataType [counter2][0] == arrayLineageDataType [counter1][0]){
                        oin<<arrayLineageFluorescentDataType [counter2][0]<<endl;
                        oin<<arrayLineageFluorescentDataType [counter2][1]<<endl;
                        oin<<arrayLineageFluorescentDataType [counter2][2]<<endl;
                        oin<<arrayLineageFluorescentDataType [counter2][3]<<endl;
                        oin<<arrayLineageFluorescentDataType [counter2][4]<<endl;
                        oin<<arrayLineageFluorescentDataType [counter2][5]<<endl;
                        oin<<arrayLineageFluorescentDataType [counter2][6]<<endl;
                        oin<<arrayLineageFluorescentDataType [counter2][7]<<endl;
                    }
                }
                
                oin.close();
            }
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Lineage Data Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)closeWindow:(id)sender{
    [lineageDataWindow orderOut:self];
    lineageDataAdjustOperation = 2;
    lineageDataTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
}

-(void)reDisplayWindow{
    if (lineageDataAdjustOperation == 3){
        [lineageDataWindow makeKeyAndOrderFront:self];
        lineageDataAdjustOperation = 1;
        [lineageDataTimer invalidate];
    }
}

-(void)dealloc{
    if (lineageDataTimer) [lineageDataTimer invalidate];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToLineageDataType object:nil];
}

@end
