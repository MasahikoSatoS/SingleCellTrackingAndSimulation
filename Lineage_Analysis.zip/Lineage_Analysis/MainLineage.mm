//
//  MainLineage.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 9/1/16.
//
//

#import "MainLineage.h"

NSString *notificationToMainLineage = @"notificationExecuteMainLineage";

@implementation MainLineage

-(id)initWithFrame:(NSRect)frame{
    self = [super initWithFrame:frame];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToMainLineage object:nil];
    }
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    lingNoForFuse1 = -1;
    cellNoForFuse1 = -1;
    cellNoCurrent1 = -1;
    lingNoForFuse2 = -1;
    cellNoForFuse2 = -1;
    cellNoCurrent2 = -1;
    fusionSetFlag = 0;
    fusionSetCount = 0;
    
    [self setNeedsDisplay:YES];
}

-(void)mouseDown:(NSEvent *)event{
    NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
    xPointDownDisplay = clickPoint.x;
    yPointDownDisplay = clickPoint.y;
    int clickFlag = 0;
    
    if (upLoadingProgress == 0){
        if (xPointDownDisplay > 410 && xPointDownDisplay < 423 && yPointDownDisplay > 330 && yPointDownDisplay < 343){ //----Live 1----
            liveCurrentCHNo = 0;
            clickFlag = 1;
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else if (xPointDownDisplay > 424 && xPointDownDisplay < 437 && yPointDownDisplay > 330 && yPointDownDisplay < 343){ //----Live 2----
            if (ifDataExtract [1] != 0 && fusionSetFlag == 0){
                liveCurrentCHNo = 1;
                clickFlag = 1;
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
        else if (xPointDownDisplay > 438 && xPointDownDisplay < 451 && yPointDownDisplay > 330 && yPointDownDisplay < 343){ //----Live 3----
            if (ifDataExtract [2] != 0 && fusionSetFlag == 0){
                liveCurrentCHNo = 2;
                clickFlag = 1;
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
        else if (xPointDownDisplay > 452 && xPointDownDisplay < 465 && yPointDownDisplay > 330 && yPointDownDisplay < 343){  //----Live 4----
            if (ifDataExtract [4] != 0 && fusionSetFlag == 0){
                liveCurrentCHNo = 3;
                clickFlag = 1;
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
        else if (xPointDownDisplay > 466 && xPointDownDisplay < 479 && yPointDownDisplay > 330 && yPointDownDisplay < 343){  //----Live 5----
            if (ifDataExtract [5] != 0 && fusionSetFlag == 0){
                liveCurrentCHNo = 4;
                clickFlag = 1;
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
        else if (xPointDownDisplay > 480 && xPointDownDisplay < 493 && yPointDownDisplay > 330 && yPointDownDisplay < 343){  //----Live 6----
            if (ifDataExtract [6] != 0 && fusionSetFlag == 0){
                liveCurrentCHNo = 5;
                clickFlag = 1;
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
        else if (xPointDownDisplay > 494 && xPointDownDisplay < 507 && yPointDownDisplay > 330 && yPointDownDisplay < 343){  //----Live 7----
            if (ifDataExtract [7] != 0 && fusionSetFlag == 0){
                liveCurrentCHNo = 6;
                clickFlag = 1;
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
        else if (xPointDownDisplay > 592 && xPointDownDisplay < 605 && yPointDownDisplay > 330 && yPointDownDisplay < 343){ //----IF 1----
            int entryPosition = 0;
            
            for (int counter2 = 1; counter2 < ifDataExtractCount/7; counter2++){
                if (ifDataExtract [counter2*7] == ifCurrentTime){
                    entryPosition = counter2;
                    break;
                }
            }
            
            if (ifDataExtract [entryPosition*7+1] != 0){
                ifCurrentCHNo = 1;
                clickFlag = 1;
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
        else if (xPointDownDisplay > 606 && xPointDownDisplay < 619 && yPointDownDisplay > 330 && yPointDownDisplay < 343){ //----IF 2----
            int entryPosition = 0;
            
            for (int counter2 = 1; counter2 < ifDataExtractCount/7; counter2++){
                if (ifDataExtract [counter2*7] == ifCurrentTime){
                    entryPosition = counter2;
                    break;
                }
            }
            
            if (ifDataExtract [entryPosition*7+2] != 0){
                ifCurrentCHNo = 2;
                clickFlag = 1;
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
        else if (xPointDownDisplay > 620 && xPointDownDisplay < 633 && yPointDownDisplay > 330 && yPointDownDisplay < 343){ //----IF 3----
            int entryPosition = 0;
            
            for (int counter2 = 1; counter2 < ifDataExtractCount/7; counter2++){
                if (ifDataExtract [counter2*7] == ifCurrentTime){
                    entryPosition = counter2;
                    break;
                }
            }
            
            if (ifDataExtract [entryPosition*7+3] != 0){
                ifCurrentCHNo = 3;
                clickFlag = 1;
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
        else if (xPointDownDisplay > 634 && xPointDownDisplay < 647 && yPointDownDisplay > 330 && yPointDownDisplay < 343){ //----IF 4----
            int entryPosition = 0;
            
            for (int counter2 = 1; counter2 < ifDataExtractCount/7; counter2++){
                if (ifDataExtract [counter2*7] == ifCurrentTime){
                    entryPosition = counter2;
                    break;
                }
            }
            
            if (ifDataExtract [entryPosition*7+3] != 0){
                ifCurrentCHNo = 4;
                clickFlag = 1;
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
        else if (xPointDownDisplay > 648 && xPointDownDisplay < 661 && yPointDownDisplay > 330 && yPointDownDisplay < 343){ //----IF 5----
            int entryPosition = 0;
            
            for (int counter2 = 1; counter2 < ifDataExtractCount/7; counter2++){
                if (ifDataExtract [counter2*7] == ifCurrentTime){
                    entryPosition = counter2;
                    break;
                }
            }
            
            if (ifDataExtract [entryPosition*7+3] != 0){
                ifCurrentCHNo = 5;
                clickFlag = 1;
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
        else if (xPointDownDisplay > 662 && xPointDownDisplay < 675 && yPointDownDisplay > 330 && yPointDownDisplay < 343){ //----IF 6----
            int entryPosition = 0;
            
            for (int counter2 = 1; counter2 < ifDataExtractCount/7; counter2++){
                if (ifDataExtract [counter2*7] == ifCurrentTime){
                    entryPosition = counter2;
                    break;
                }
            }
            
            if (ifDataExtract [entryPosition*7+3] != 0){
                ifCurrentCHNo = 6;
                clickFlag = 1;
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
        else if (xPointDownDisplay > 880 && xPointDownDisplay < 900 && yPointDownDisplay > 330 && yPointDownDisplay < 341){  //----Average/Toal----
            if (averageTotalFlag == 0) averageTotalFlag = 1;
            else averageTotalFlag = 0;
            
            clickFlag = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else if (xPointDownDisplay > 880 && xPointDownDisplay < 901 && yPointDownDisplay > 240 && yPointDownDisplay < 254){  //----Blue Line----
            if (blueLineFlag == 0) blueLineFlag = 1;
            else blueLineFlag = 0;
            
            clickFlag = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else if (xPointDownDisplay > 880 && xPointDownDisplay < 901 && yPointDownDisplay > 220 && yPointDownDisplay < 231){  //----Line Width----
            if (lineWidthFlag == 0) lineWidthFlag = 1;
            else if (lineWidthFlag == 1) lineWidthFlag = 2;
            else if (lineWidthFlag == 2) lineWidthFlag = 3;
            else if (lineWidthFlag == 3) lineWidthFlag = 4;
            else if (lineWidthFlag == 4) lineWidthFlag = 5;
            else lineWidthFlag = 0;
            
            clickFlag = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else if (xPointDownDisplay > 880 && xPointDownDisplay < 901 && yPointDownDisplay > 200 && yPointDownDisplay < 214){  //----Cell number----
            if (cellNumberFlag == 0) cellNumberFlag = 1;
            else cellNumberFlag = 0;
            
            clickFlag = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else if (xPointDownDisplay > 880 && xPointDownDisplay < 901 && yPointDownDisplay > 180 && yPointDownDisplay < 194){  //----End number----
            if (endNumberFlag == 0) endNumberFlag = 1;
            else endNumberFlag = 0;
            
            clickFlag = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else if (xPointDownDisplay > 880 && xPointDownDisplay < 901 && yPointDownDisplay > 160 && yPointDownDisplay < 174){  //----Mark Size----
            if (markSizeFlag == 0) markSizeFlag = 1;
            else if (markSizeFlag == 1) markSizeFlag = 2;
            else markSizeFlag = 0;
            
            clickFlag = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else if (xPointDownDisplay > 684 && xPointDownDisplay < 719 && yPointDownDisplay > 330 && yPointDownDisplay < 341){ //----Include----
            for (int counter1 = 0; counter1 < ifTimeExtractCount/2; counter1++){
                if (ifTimeExtract [counter1*2] == ifCurrentTime){
                    ifTimeExtract [counter1*2+1] = 0;
                    includeExcludeFlag = 0;
                    includeExcludeModification = 1;
                    clickFlag = 1;
                    break;
                }
            }
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else if (xPointDownDisplay > 723 && xPointDownDisplay < 758 && yPointDownDisplay > 330 && yPointDownDisplay < 341){ //----Exclude----
            for (int counter1 = 0; counter1 < ifTimeExtractCount/2; counter1++){
                if (ifTimeExtract [counter1*2] == ifCurrentTime){
                    ifTimeExtract [counter1*2+1] = 1;
                    includeExcludeFlag = 1;
                    includeExcludeModification = 1;
                    clickFlag = 1;
                    break;
                }
            }
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else if (xPointDownDisplay > 765 && xPointDownDisplay < 785 && yPointDownDisplay > 330 && yPointDownDisplay < 341 && fusionSetFlag == 0){ //----Select Set, first time----
            if (fusionSetFlag == 0){
                fusionSetFlag = 1;
                liveCurrentCHNo = 0;
                lingNoForFuse1 = -1;
                cellNoForFuse1 = -1;
                cellNoCurrent1 = -1;
                lingNoForFuse2 = -1;
                cellNoForFuse2 = -1;
                cellNoCurrent2 = -1;
                fusionSetCount = 1;
                clickFlag = 1;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        } //----Select Set----
        else if (xPointDownDisplay > 765 && xPointDownDisplay < 785 && yPointDownDisplay > 330 && yPointDownDisplay < 341 && fusionSetFlag == 1){ //----Select Set----
            fusionSetFlag = 1;
            liveCurrentCHNo = 0;
            lingNoForFuse1 = -1;
            cellNoForFuse1 = -1;
            cellNoCurrent1 = -1;
            lingNoForFuse2 = -1;
            cellNoForFuse2 = -1;
            cellNoCurrent2 = -1;
            fusionSetCount = 1;
            clickFlag = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        } //----Select Set----
        else if (xPointDownDisplay > 788 && xPointDownDisplay < 808 && yPointDownDisplay > 330 && yPointDownDisplay < 341 && fusionSetFlag == 1){ //----Clear Set----
            fusionSetFlag = 0;
            liveCurrentCHNo = 0;
            lingNoForFuse1 = -1;
            cellNoForFuse1 = -1;
            cellNoCurrent1 = -1;
            lingNoForFuse2 = -1;
            cellNoForFuse2 = -1;
            cellNoCurrent2 = -1;
            fusionSetCount = 0;
            clickFlag = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else if (xPointDownDisplay > 833 && xPointDownDisplay < 853 && yPointDownDisplay > 330 && yPointDownDisplay < 341){ //----Reset Set----
            //----Link data sort----
            if (arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength] > 0 && arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+1] != 0){
                int *numberOfEntryList = new int [lineageLinkListLength+1];
                int *numberOfEntryList2 = new int [lineageLinkListLength+1];
                
                for (int counter2 = 0; counter2 < lineageLinkListLength; counter2++){
                    if (arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter2] != 0){
                        numberOfEntryList [counter2] = arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter2];
                    }
                    else numberOfEntryList [counter2] = 0;
                    
                    numberOfEntryList2 [counter2] = 0;
                }
                
                int terminationFlag = 0;
                int smallestEntry2 = 0;
                int smallestEntry = 0;
                int smallestEntryPosition = 0;
                int remainingFlag = 0;
                
                do{
                    
                    terminationFlag = 1;
                    remainingFlag = 0;
                    smallestEntry = 100000;
                    smallestEntryPosition = 0;
                    
                    for (int counter2 = 0; counter2 < lineageLinkListLength; counter2++){
                        if (numberOfEntryList [counter2] != 0 && numberOfEntryList [counter2] < smallestEntry){
                            smallestEntry = numberOfEntryList [counter2];
                            smallestEntryPosition = counter2;
                            remainingFlag = 1;
                        }
                    }
                    
                    if (remainingFlag == 0) terminationFlag = 0;
                    else{
                        
                        numberOfEntryList2 [smallestEntry2] = numberOfEntryList [smallestEntryPosition], smallestEntry2++;
                        numberOfEntryList [smallestEntryPosition] = 0;
                    }
                    
                } while (terminationFlag == 1);
                
                for (int counter2 = 0; counter2 < lineageLinkListLength; counter2++){
                    arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter2] = numberOfEntryList2 [counter2];
                }
                
                delete [] numberOfEntryList;
                delete [] numberOfEntryList2;
                
                //----Lineage link data get----
                int extractCount = 0;
                
                int *lineageSelect = new int [lineageLinkListLength+5];
                
                lineageSelect [extractCount] = arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength];
                extractCount++;
                
                for (int counter2 = 1; counter2 < lineageLinkListLength; counter2++){
                    if (arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter2] != 0){
                        lineageSelect [extractCount] = arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter2];
                        extractCount++;
                    }
                }
                
                //----Hold Lineage data clear----
                int lineageNoFind = 0;
                
                for (int counter1 = 0; counter1 < extractCount; counter1++){
                    lineageNoFind = lineageSelect [counter1];
                    
                    for (unsigned long counter2 = 0; counter2 < holdReviseLineageCount/9; counter2++){
                        if (holdReviseLineage [counter2*9+6] == lineageNoFind){
                            holdReviseLineage [counter2*9+6] = 0;
                        }
                    }
                }
                
                int lineageHoldCount = 0;
                
                for (unsigned long counter2 = 0; counter2 < holdReviseLineageCount/9; counter2++){
                    if (holdReviseLineage [counter2*9+6] != 0){
                        holdReviseLineage [lineageHoldCount] = holdReviseLineage [counter2*9], lineageHoldCount++;
                        holdReviseLineage [lineageHoldCount] = holdReviseLineage [counter2*9+1], lineageHoldCount++;
                        holdReviseLineage [lineageHoldCount] = holdReviseLineage [counter2*9+2], lineageHoldCount++;
                        holdReviseLineage [lineageHoldCount] = holdReviseLineage [counter2*9+3], lineageHoldCount++;
                        holdReviseLineage [lineageHoldCount] = holdReviseLineage [counter2*9+4], lineageHoldCount++;
                        holdReviseLineage [lineageHoldCount] = holdReviseLineage [counter2*9+5], lineageHoldCount++;
                        holdReviseLineage [lineageHoldCount] = holdReviseLineage [counter2*9+6], lineageHoldCount++;
                        holdReviseLineage [lineageHoldCount] = holdReviseLineage [counter2*9+7], lineageHoldCount++;
                        holdReviseLineage [lineageHoldCount] = holdReviseLineage [counter2*9+8], lineageHoldCount++;
                    }
                }
                
                holdReviseLineageCount = (unsigned long)lineageHoldCount;
                
                //----Hold IF data clear----
                for (int counter1 = 0; counter1 < extractCount; counter1++){
                    lineageNoFind = lineageSelect [counter1];
                    
                    for (int counter2 = 0; counter2 < holdReviseIfDataCount/22; counter2++){
                        if (holdReviseIfData [counter2*22+1] == lineageNoFind){
                            holdReviseIfData [counter2*22+1] = 0;
                        }
                    }
                }
                
                lineageHoldCount = 0;
                
                for (int counter2 = 0; counter2 < holdReviseIfDataCount/22; counter2++){
                    if (holdReviseIfData [counter2*22+1] != 0){
                        holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22], lineageHoldCount++;
                        holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+1], lineageHoldCount++;
                        holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+2], lineageHoldCount++;
                        holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+3], lineageHoldCount++;
                        holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+4], lineageHoldCount++;
                        holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+5], lineageHoldCount++;
                        holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+6], lineageHoldCount++;
                        holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+7], lineageHoldCount++;
                        holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+8], lineageHoldCount++;
                        holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+9], lineageHoldCount++;
                        holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+10], lineageHoldCount++;
                        holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+11], lineageHoldCount++;
                        holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+12], lineageHoldCount++;
                        holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+13], lineageHoldCount++;
                        holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+14], lineageHoldCount++;
                        holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+15], lineageHoldCount++;
                        holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+16], lineageHoldCount++;
                        holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+17], lineageHoldCount++;
                        holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+18], lineageHoldCount++;
                        holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+19], lineageHoldCount++;
                        holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+20], lineageHoldCount++;
                        holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+21], lineageHoldCount++;
                    }
                }
                
                holdReviseIfDataCount = lineageHoldCount;
                
                //----Area data clear----
                for (int counter1 = 0; counter1 < extractCount; counter1++){
                    lineageNoFind = lineageSelect [counter1];
                    
                    for (int counter2 = 0; counter2 < holdReviseAreaDataCount/5; counter2++){
                        if (holdReviseAreaData [counter2*5] == lineageNoFind){
                            holdReviseAreaData [counter2*5] = 0;
                        }
                    }
                }
                
                lineageHoldCount = 0;
                
                for (int counter2 = 0; counter2 < holdReviseAreaDataCount/5; counter2++){
                    if (holdReviseAreaData [counter2*5] != 0){
                        holdReviseAreaData [lineageHoldCount] = holdReviseAreaData [counter2*5], lineageHoldCount++;
                        holdReviseAreaData [lineageHoldCount] = holdReviseAreaData [counter2*5+1], lineageHoldCount++;
                        holdReviseAreaData [lineageHoldCount] = holdReviseAreaData [counter2*5+2], lineageHoldCount++;
                        holdReviseAreaData [lineageHoldCount] = holdReviseAreaData [counter2*5+3], lineageHoldCount++;
                        holdReviseAreaData [lineageHoldCount] = holdReviseAreaData [counter2*5+4], lineageHoldCount++;
                    }
                }
                
                holdReviseAreaDataCount = lineageHoldCount;
                
                //========Load lineage data========
                lineageExtractCount = 0;
                
                for (int counter1 = 0; counter1 < extractCount; counter1++){
                    lineageNoFind = lineageSelect [counter1];
                    
                    for (unsigned long counter2 = 0; counter2 < arrayLineageDataEntryHold [tableCurrentRowHold]/9; counter2++){
                        if (arrayLineageData [tableCurrentRowHold][counter2*9+6] == lineageNoFind){
                            if (lineageExtractCount+10 > lineageExtractLimit){
                                int *arrayUpDate = new int [lineageExtractCount+10];
                                
                                for (unsigned long counter3 = 0; counter3 < lineageExtractCount; counter3++) arrayUpDate [counter3] = arrayLineageExtract [counter3];
                                
                                delete [] arrayLineageExtract;
                                lineageExtractLimit = lineageExtractCount+arrayLineageDataEntryHold [tableCurrentRowHold]+5000;
                                arrayLineageExtract = new int [lineageExtractLimit];
                                
                                for (unsigned long counter3 = 0; counter3 < lineageExtractCount; counter3++) arrayLineageExtract [counter3] = arrayUpDate [counter3];
                                delete [] arrayUpDate;
                            }
                            
                            arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9], lineageExtractCount++;
                            arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+1], lineageExtractCount++;
                            arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+2], lineageExtractCount++;
                            arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+3], lineageExtractCount++;
                            arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+4], lineageExtractCount++;
                            arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+5], lineageExtractCount++;
                            arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+6], lineageExtractCount++;
                            arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+7], lineageExtractCount++;
                            arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+8], lineageExtractCount++;
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < lineageExtractCount/9; counterA++){
                //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayLineageExtract [counterA*9+counterB];
                //    cout<<" arrayLineageExtract "<<counterA<<endl;
                //}
                
                //========Load IF data========
                int ifEntryCount = arrayIFDataEntryHold [tableCurrentRowHold];
                
                ifValueExtractCount = 0;
                
                for (int counter1 = 0; counter1 < extractCount; counter1++){
                    lineageNoFind = lineageSelect [counter1];
                    
                    for (int counter2 = 0; counter2 < ifEntryCount/22; counter2++){
                        if (arrayIFData [tableCurrentRowHold][counter2*22+1] == lineageNoFind){
                            if (ifValueExtractCount+50 > ifValueExtractLimit){
                                int *arrayUpDate = new int [ifValueExtractCount+50];
                                
                                for (int counter3 = 0; counter3 < ifValueExtractCount; counter3++) arrayUpDate [counter3] = ifValueExtract [counter3];
                                
                                delete [] ifValueExtract;
                                ifValueExtractLimit = ifValueExtractCount+5000;
                                ifValueExtract = new int [ifValueExtractLimit];
                                
                                for (int counter3 = 0; counter3 < ifValueExtractCount; counter3++) ifValueExtract [counter3] = arrayUpDate [counter3];
                                delete [] arrayUpDate;
                            }
                            
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+1], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+2], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+3], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+4], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+5], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+6], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+7], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+8], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+9], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+10], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+11], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+12], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+13], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+14], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+15], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+16], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+17], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+18], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+19], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+20], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+21], ifValueExtractCount++;
                        }
                    }
                }
                
                //========arrayAreaData========
                int areaEntryCount = arrayAreaDataHold [tableCurrentRowHold];
                
                areaExtractCount = 0;
                
                for (int counter1 = 0; counter1 < extractCount; counter1++){
                    lineageNoFind = lineageSelect [counter1];
                    
                    for (int counter2 = 0; counter2 < areaEntryCount/5; counter2++){
                        if (arrayAreaData [tableCurrentRowHold][counter2*5] == lineageNoFind){
                            if (areaExtractCount+10 > areaExtractLimit){
                                int *arrayUpDate = new int [areaExtractCount+10];
                                
                                for (int counter3 = 0; counter3 < areaExtractCount; counter3++) arrayUpDate [counter3] = areaExtract [counter3];
                                
                                delete [] areaExtract;
                                areaExtractLimit = areaExtractCount+5000;
                                areaExtract = new int [areaExtractLimit];
                                
                                for (int counter3 = 0; counter3 < areaExtractCount; counter3++) areaExtract [counter3] = arrayUpDate [counter3];
                                delete [] arrayUpDate;
                            }
                            
                            areaExtract [areaExtractCount] = arrayAreaData [tableCurrentRowHold][counter2*5], areaExtractCount++;
                            areaExtract [areaExtractCount] = arrayAreaData [tableCurrentRowHold][counter2*5+1], areaExtractCount++;
                            areaExtract [areaExtractCount] = arrayAreaData [tableCurrentRowHold][counter2*5+2], areaExtractCount++;
                            areaExtract [areaExtractCount] = arrayAreaData [tableCurrentRowHold][counter2*5+3], areaExtractCount++;
                            areaExtract [areaExtractCount] = arrayAreaData [tableCurrentRowHold][counter2*5+4], areaExtractCount++;
                        }
                    }
                }
                
                delete [] lineageSelect;
                
                liveCurrentCHNo = 0;
                fusionSetFlag = 0;
                lingNoForFuse1 = -1;
                cellNoForFuse1 = -1;
                cellNoCurrent1 = -1;
                lingNoForFuse2 = -1;
                cellNoForFuse2 = -1;
                cellNoCurrent2 = -1;
                fusionSetCount = 0;
                clickFlag = 1;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
        else if (xPointDownDisplay > 811 && xPointDownDisplay < 830 && yPointDownDisplay > 330 && yPointDownDisplay < 341 && fusionSetFlag == 1){ //----Flip Set----
            if (fusionSetCount == 3){
                if (lingNoForFuse1 != lingNoForFuse2){
                    if (cellNoForFuse1 == 0 && cellNoForFuse2 == 0){
                        int lingNoForFusePosition1 = 0;
                        int lingNoForFusePosition2 = 0;
                        
                        for (int counter2 = 0; counter2 < lineageLinkListLength; counter2++){
                            if (arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter2] == lingNoForFuse1){
                                lingNoForFusePosition1 = counter2;
                            }
                            
                            if (arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter2] == lingNoForFuse2){
                                lingNoForFusePosition2 = counter2;
                            }
                        }
                        
                        if (lingNoForFusePosition1 == lingNoForFusePosition2-1 || lingNoForFusePosition1 == lingNoForFusePosition2+1){
                            arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+lingNoForFusePosition1] = lingNoForFuse2;
                            arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+lingNoForFusePosition2] = lingNoForFuse1;
                            
                            int extractCount = 0;
                            int *lineageSelect = new int [lineageLinkListLength+5];
                            
                            lineageSelect [extractCount] = arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength];
                            extractCount++;
                            
                            for (int counter2 = 1; counter2 < lineageLinkListLength; counter2++){
                                if (arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter2] != 0){
                                    lineageSelect [extractCount] = arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter2];
                                    extractCount++;
                                }
                            }
                            
                            int *arrayLineageExtractTemp = new int [lineageExtractCount+50];
                            int arrayLineageExtractTempCount = 0;
                            
                            int lineageNoFind = 0;
                            
                            for (int counter1 = 0; counter1 < extractCount; counter1++){
                                lineageNoFind = lineageSelect [counter1];
                                
                                for (unsigned long counter2 = 0; counter2 < lineageExtractCount/9; counter2++){
                                    if (arrayLineageExtract [counter2*9+6] == lineageNoFind){
                                        arrayLineageExtractTemp [arrayLineageExtractTempCount] = arrayLineageExtract [counter2*9], arrayLineageExtractTempCount++;
                                        arrayLineageExtractTemp [arrayLineageExtractTempCount] = arrayLineageExtract [counter2*9+1], arrayLineageExtractTempCount++;
                                        arrayLineageExtractTemp [arrayLineageExtractTempCount] = arrayLineageExtract [counter2*9+2], arrayLineageExtractTempCount++;
                                        arrayLineageExtractTemp [arrayLineageExtractTempCount] = arrayLineageExtract [counter2*9+3], arrayLineageExtractTempCount++;
                                        arrayLineageExtractTemp [arrayLineageExtractTempCount] = arrayLineageExtract [counter2*9+4], arrayLineageExtractTempCount++;
                                        arrayLineageExtractTemp [arrayLineageExtractTempCount] = arrayLineageExtract [counter2*9+5], arrayLineageExtractTempCount++;
                                        arrayLineageExtractTemp [arrayLineageExtractTempCount] = arrayLineageExtract [counter2*9+6], arrayLineageExtractTempCount++;
                                        arrayLineageExtractTemp [arrayLineageExtractTempCount] = arrayLineageExtract [counter2*9+7], arrayLineageExtractTempCount++;
                                        arrayLineageExtractTemp [arrayLineageExtractTempCount] = arrayLineageExtract [counter2*9+8], arrayLineageExtractTempCount++;
                                    }
                                }
                            }
                            
                            lineageExtractCount = 0;
                            
                            for (int counter1 = 0; counter1 < arrayLineageExtractTempCount; counter1++) arrayLineageExtract [lineageExtractCount] = arrayLineageExtractTemp [counter1], lineageExtractCount++;
                            
                            delete [] lineageSelect;
                            delete [] arrayLineageExtractTemp;
                            
                            fusionSetFlag = 0;
                            lingNoForFuse1 = -1;
                            cellNoForFuse1 = -1;
                            cellNoCurrent1 = -1;
                            lingNoForFuse2 = -1;
                            cellNoForFuse2 = -1;
                            cellNoCurrent2 = -1;
                            fusionSetCount = 0;
                            lineageModification = 1;
                            lineageModification = 1;
                            clickFlag = 1;
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Select Lineage: One Before Or After"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Select Progeny Cells"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    int parentCellNo1 = -1;
                    int parentCellNo2 = -1;
                    
                    //for (int counterA = 0; counterA < lineageExtractCount/9; counterA++){
                    //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayLineageExtract [counterA*9+counterB];
                    //    cout<<" arrayLineageExtract "<<counterA<<endl;
                    //}
                    
                    for (unsigned long counter1 = 0; counter1 < lineageExtractCount/9; counter1++){
                        if (arrayLineageExtract [counter1*9+3] == 31 || arrayLineageExtract [counter1*9+3] == 41 || arrayLineageExtract [counter1*9+3] == 51){
                            if (arrayLineageExtract [counter1*9+6] == lingNoForFuse1 && arrayLineageExtract [counter1*9+5] == cellNoForFuse1){
                                parentCellNo1 = arrayLineageExtract [counter1*9+4];
                            }
                            
                            if (arrayLineageExtract [counter1*9+6] == lingNoForFuse2 && arrayLineageExtract [counter1*9+5] == cellNoForFuse2){
                                parentCellNo2 = arrayLineageExtract [counter1*9+4];
                            }
                        }
                    }
                    
                    if (parentCellNo1 == parentCellNo2){
                        int terminationFlag = 0;
                        
                        int *cellNumberModificationRef = new int [lineageExtractCount];
                        int cellNumberModificationRefCount = 8;
                        
                        int *cellNumberModificationTemp = new int [lineageExtractCount];
                        int cellNumberModificationTempCount = 4;
                        
                        int *cellNumberModificationTemp2 = new int [10];
                        int cellNumberModificationTempCount2 = 0;
                        int *cellNumberModificationTemp3 = new int [20];
                        
                        cellNumberModificationRef [0] = lingNoForFuse1;
                        cellNumberModificationRef [1] = cellNoForFuse1;
                        cellNumberModificationRef [2] = lingNoForFuse2;
                        cellNumberModificationRef [3] = cellNoForFuse2;
                        cellNumberModificationRef [4] = lingNoForFuse2;
                        cellNumberModificationRef [5] = cellNoForFuse2;
                        cellNumberModificationRef [6] = lingNoForFuse1;
                        cellNumberModificationRef [7] = cellNoForFuse1;
                        
                        int nextParentCellNo = cellNoForFuse1;
                        int nextParentCellRevNo = cellNoForFuse2;
                        int numberOfCells = 0;
                        int newCellNo1 = 0;
                        int newCellNo2 = 0;
                        int newCellNo3 = 0;
                        int newCellNo4 = 0;
                        int positionFlag = 0;
                        
                        cellNumberModificationTemp [0] = cellNoForFuse1;
                        cellNumberModificationTemp [1] = 0;
                        cellNumberModificationTemp [2] = cellNoForFuse2;
                        cellNumberModificationTemp [3] = 0;
                        
                        int *largeCellNumberList = new int [lineageExtractCount*2+10];
                        int largeCellNumberListCount = 0;
                        
                        int nextCellNo = 0;
                        
                        largeCellNumberList [largeCellNumberListCount] = cellNoForFuse1, largeCellNumberListCount++;
                        largeCellNumberList [largeCellNumberListCount] = 0, largeCellNumberListCount++;
                        
                        do{
                            
                            terminationFlag = 1;
                            nextCellNo = 0;
                            
                            for (int counter1 = 0; counter1 < largeCellNumberListCount/2; counter1++){
                                if (largeCellNumberList [counter1*2+1] == 0){
                                    nextCellNo = largeCellNumberList [counter1*2];
                                    largeCellNumberList [counter1*2+1] = 1;
                                    break;
                                }
                            }
                            
                            if (nextCellNo != 0){
                                for (unsigned long counter1 = 0; counter1 < lineageExtractCount/9; counter1++){
                                    if ((arrayLineageExtract [counter1*9+3] == 31 || arrayLineageExtract [counter1*9+3] == 41 || arrayLineageExtract [counter1*9+3] == 51) && arrayLineageExtract [counter1*9+4] == nextCellNo && arrayLineageExtract [counter1*9+6] == lingNoForFuse1){
                                        largeCellNumberList [largeCellNumberListCount] = arrayLineageExtract [counter1*9+5], largeCellNumberListCount++;
                                        largeCellNumberList [largeCellNumberListCount] = 0, largeCellNumberListCount++;
                                    }
                                }
                            }
                            else terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                        
                        largeCellNumberList [largeCellNumberListCount] = cellNoForFuse2, largeCellNumberListCount++;
                        largeCellNumberList [largeCellNumberListCount] = 0, largeCellNumberListCount++;
                        
                        do{
                            
                            terminationFlag = 1;
                            nextCellNo = 0;
                            
                            for (int counter1 = 0; counter1 < largeCellNumberListCount/2; counter1++){
                                if (largeCellNumberList [counter1*2+1] == 0){
                                    nextCellNo = largeCellNumberList [counter1*2];
                                    largeCellNumberList [counter1*2+1] = 1;
                                    break;
                                }
                            }
                            
                            if (nextCellNo != 0){
                                for (unsigned long counter1 = 0; counter1 < lineageExtractCount/9; counter1++){
                                    if ((arrayLineageExtract [counter1*9+3] == 31 || arrayLineageExtract [counter1*9+3] == 41 || arrayLineageExtract [counter1*9+3] == 51) && arrayLineageExtract [counter1*9+4] == nextCellNo && arrayLineageExtract [counter1*9+6] == lingNoForFuse2){
                                        largeCellNumberList [largeCellNumberListCount] = arrayLineageExtract [counter1*9+5], largeCellNumberListCount++;
                                        largeCellNumberList [largeCellNumberListCount] = 0, largeCellNumberListCount++;
                                    }
                                }
                            }
                            else terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                        
                        //for (int counterA = 0; counterA < largeCellNumberListCount/2; counterA++){
                        //    cout<<largeCellNumberList [counterA*2]<<" "<<largeCellNumberList [counterA*2+1]<<" lineageList"<<endl;
                        //}
                        
                        int *largeCellNumberList2 = new int [largeCellNumberListCount+10];
                        int largeCellNumberListCount2 = 0;
                        
                        for (int counter1 = 0; counter1 < largeCellNumberListCount/2; counter1++){
                            if (largeCellNumberList [counter1*2] >= 300000000 && (int)(to_string(largeCellNumberList [counter1*2]).length()) == 9 && to_string(largeCellNumberList [counter1*2]).substr(7, 2) == "00"){
                                largeCellNumberList2 [largeCellNumberListCount2] = largeCellNumberList [counter1*2], largeCellNumberListCount2++;
                            }
                            
                            if (largeCellNumberList [counter1*2] <= -300000000 && (int)(to_string(largeCellNumberList [counter1*2]).length()) == 9 && to_string(largeCellNumberList [counter1*2]).substr(8, 2) == "00"){
                                largeCellNumberList2 [largeCellNumberListCount2] = largeCellNumberList [counter1*2], largeCellNumberListCount2++;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < largeCellNumberListCount2; counterA++){
                        //    cout<<largeCellNumberList2 [counterA]<<" list2"<<endl;
                        //}
                        
                        largeCellNumberListCount = 0;
                        
                        for (unsigned long counter1 = 0; counter1 < lineageExtractCount/9; counter1++){
                            if ((arrayLineageExtract [counter1*9+3] == 31 || arrayLineageExtract [counter1*9+3] == 41 || arrayLineageExtract [counter1*9+3] == 51) && arrayLineageExtract [counter1*9+6] == lingNoForFuse1){
                                largeCellNumberList [largeCellNumberListCount] = arrayLineageExtract [counter1*9+5], largeCellNumberListCount++;
                                largeCellNumberList [largeCellNumberListCount] = 0, largeCellNumberListCount++;
                            }
                        }
                        
                        int *largeCellNumberList3 = new int [largeCellNumberListCount+10];
                        int largeCellNumberListCount3 = 0;
                        
                        for (int counter1 = 0; counter1 < largeCellNumberListCount/2; counter1++){
                            if (largeCellNumberList [counter1*2] >= 300000000 && (int)(to_string(largeCellNumberList [counter1*2]).length()) == 9 && to_string(largeCellNumberList [counter1*2]).substr(7, 2) == "00"){
                                largeCellNumberList3 [largeCellNumberListCount3] = largeCellNumberList [counter1*2], largeCellNumberListCount3++;
                                largeCellNumberList3 [largeCellNumberListCount3] = 1, largeCellNumberListCount3++;
                            }
                            
                            if (largeCellNumberList [counter1*2] <= -300000000 && (int)(to_string(largeCellNumberList [counter1*2]).length()) == 9 && to_string(largeCellNumberList [counter1*2]).substr(8, 2) == "00"){
                                largeCellNumberList3 [largeCellNumberListCount3] = largeCellNumberList [counter1*2], largeCellNumberListCount3++;
                                largeCellNumberList3 [largeCellNumberListCount3] = 1, largeCellNumberListCount3++;
                            }
                        }
                        
                        for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                            for (int counter2 = 0; counter2 < largeCellNumberListCount2; counter2++){
                                if (largeCellNumberList3 [counter1*2] == largeCellNumberList2 [counter2]){
                                    largeCellNumberList3 [counter1*2+1] = 0;
                                    break;
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < largeCellNumberListCount3/2; counterA++){
                        //    cout<<largeCellNumberList3 [counterA*2]<<" "<<largeCellNumberList3 [counterA*2+1]<<" list3"<<endl;
                        //}
                        
                        delete [] largeCellNumberList;
                        
                        do{
                            
                            terminationFlag = 1;
                            cellNumberModificationTempCount2 = 0;
                            
                            //for (int counterA = 0; counterA < cellNumberModificationRefCount/4; counterA++){
                            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<cellNumberModificationRef [counterA*4+counterB];
                            //    cout<<" cellNumberModificationRef "<<counterA<<endl;
                            //}
                            
                            for (unsigned long counter1 = 0; counter1 < lineageExtractCount/9; counter1++){
                                if (arrayLineageExtract [counter1*9+3] == 31 || arrayLineageExtract [counter1*9+3] == 41 || arrayLineageExtract [counter1*9+3] == 51){
                                    if (arrayLineageExtract [counter1*9+6] == lingNoForFuse1 && arrayLineageExtract [counter1*9+4] == nextParentCellNo){
                                        cellNumberModificationTemp [cellNumberModificationTempCount] = arrayLineageExtract [counter1*9+5], cellNumberModificationTempCount++;
                                        cellNumberModificationTemp [cellNumberModificationTempCount] = 0, cellNumberModificationTempCount++;
                                        cellNumberModificationTemp2 [cellNumberModificationTempCount2] = arrayLineageExtract [counter1*9+5], cellNumberModificationTempCount2++;
                                    }
                                }
                            }
                            
                            //for (int counterA = 0; counterA < cellNumberModificationTempCount/2; counterA++){
                            //    for (int counterB = 0; counterB < 2; counterB++) cout<<" "<<cellNumberModificationTemp [counterA*2+counterB];
                            //    cout<<" cellNumberModificationTemp "<<counterA<<endl;
                            //}
                            
                            if (cellNumberModificationTempCount2 != 0){
                                newCellNo1 = 0;
                                newCellNo2 = 0;
                                newCellNo3 = 0;
                                newCellNo4 = 0;
                                
                                numberOfCells = cellNumberModificationTempCount2;
                                
                                if (numberOfCells >= 2){
                                    int numberLength = (int)to_string(nextParentCellRevNo).length();
                                    int zeroPoint = -1;
                                    int digitNumber = 0;
                                    int checkFlag = 0;
                                    
                                    if (nextParentCellRevNo == 0) newCellNo1 = -100000000;
                                    else{
                                        
                                        string digitExtract;
                                        
                                        for (int counter1 = 0; counter1 < numberLength; counter1++){
                                            digitExtract = to_string(nextParentCellRevNo).substr((unsigned long)counter1, 1);
                                            
                                            if (checkFlag == 0 && digitExtract == "0"){
                                                zeroPoint = counter1;
                                                checkFlag = 1;
                                            }
                                            else if (checkFlag == 1 && digitExtract != "0"){
                                                zeroPoint = -1;
                                                checkFlag = 0;
                                            }
                                        }
                                        
                                        if (zeroPoint != -1){
                                            digitNumber = numberLength-zeroPoint;
                                            
                                            if (digitNumber == 8) newCellNo1 = nextParentCellRevNo+10000000;
                                            else if (digitNumber == 7) newCellNo1 = nextParentCellRevNo+1000000;
                                            else if (digitNumber == 6) newCellNo1 = nextParentCellRevNo+100000;
                                            else if (digitNumber == 5) newCellNo1 = nextParentCellRevNo+10000;
                                            else if (digitNumber == 4) newCellNo1 = nextParentCellRevNo+1000;
                                            else if (digitNumber == 3) newCellNo1 = nextParentCellRevNo+100;
                                            else if (digitNumber == 2) newCellNo1 = nextParentCellRevNo+10;
                                            else if (digitNumber == 1) newCellNo1 = nextParentCellRevNo+1;
                                        }
                                        else{
                                            
                                            int lowestCellCount = 100000;
                                            int maxCellCount = 0;
                                            int lowestCellPosition = 0;
                                            
                                            string nextParentCellRevNoString = to_string(nextParentCellRevNo);
                                            
                                            if (nextParentCellRevNo > 0){
                                                if ((int)nextParentCellRevNoString.length() == 8){
                                                    nextParentCellRevNoString = "0"+nextParentCellRevNoString;
                                                }
                                            }
                                            else{
                                                
                                                if ((int)nextParentCellRevNoString.length() == 9){
                                                    nextParentCellRevNoString = "-0"+nextParentCellRevNoString.substr(1);
                                                }
                                            }
                                            
                                            if (nextParentCellRevNo > 0){
                                                if (nextParentCellRevNoString.substr(0, 1) == "0"){
                                                    for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                                        if ((to_string(largeCellNumberList3 [counter1*2])).substr(0, 1) == "3" && (largeCellNumberList3 [counter1*2+1] == 0 || largeCellNumberList3 [counter1*2+1] == 2)){
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str()) < lowestCellCount){
                                                                lowestCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str());
                                                                lowestCellPosition = counter1;
                                                            }
                                                            
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str()) > maxCellCount){
                                                                maxCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str());
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (lowestCellCount == 0){
                                                        maxCellCount++;
                                                        lowestCellCount = maxCellCount;
                                                    }
                                                    else largeCellNumberList3 [lowestCellPosition*2+1] = 2;
                                                    
                                                    string newExtensionEntryNo = to_string(lowestCellCount);
                                                    
                                                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "30000"+newExtensionEntryNo+"700";
                                                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "3000"+newExtensionEntryNo+"700";
                                                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "300"+newExtensionEntryNo+"700";
                                                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "30"+newExtensionEntryNo+"700";
                                                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "3"+newExtensionEntryNo+"700";
                                                    
                                                    newCellNo1 = atoi(newExtensionEntryNo.c_str());
                                                }
                                                
                                                if (nextParentCellRevNoString.substr(0, 1) == "1"){
                                                    for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                                        if ((to_string(largeCellNumberList3 [counter1*2])).substr(0, 1) == "4" && (largeCellNumberList3 [counter1*2+1] == 0 || largeCellNumberList3 [counter1*2+1] == 2)){
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str()) < lowestCellCount){
                                                                lowestCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str());
                                                                lowestCellPosition = counter1;
                                                            }
                                                            
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str()) > maxCellCount){
                                                                maxCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str());
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (lowestCellCount == 0){
                                                        maxCellCount++;
                                                        lowestCellCount = maxCellCount;
                                                    }
                                                    else largeCellNumberList3 [lowestCellPosition*2+1] = 2;
                                                    
                                                    string newExtensionEntryNo = to_string(lowestCellCount);
                                                    
                                                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "40000"+newExtensionEntryNo+"700";
                                                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "4000"+newExtensionEntryNo+"700";
                                                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "400"+newExtensionEntryNo+"700";
                                                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "40"+newExtensionEntryNo+"700";
                                                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "4"+newExtensionEntryNo+"700";
                                                    
                                                    newCellNo1 = atoi(newExtensionEntryNo.c_str());
                                                }
                                                
                                                if (nextParentCellRevNoString.substr(0, 1) == "3"){
                                                    for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                                        if ((to_string(largeCellNumberList3 [counter1*2])).substr(0, 1) == "5" && (largeCellNumberList3 [counter1*2+1] == 0 || largeCellNumberList3 [counter1*2+1] == 2)){
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str()) < lowestCellCount){
                                                                lowestCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str());
                                                                lowestCellPosition = counter1;
                                                            }
                                                            
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str()) > maxCellCount){
                                                                maxCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str());
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (lowestCellCount == 0){
                                                        maxCellCount++;
                                                        lowestCellCount = maxCellCount;
                                                    }
                                                    else largeCellNumberList3 [lowestCellPosition*2+1] = 2;
                                                    
                                                    string newExtensionEntryNo = to_string(lowestCellCount);
                                                    
                                                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "50000"+newExtensionEntryNo+"700";
                                                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "5000"+newExtensionEntryNo+"700";
                                                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "500"+newExtensionEntryNo+"700";
                                                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "50"+newExtensionEntryNo+"700";
                                                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "5"+newExtensionEntryNo+"700";
                                                    
                                                    newCellNo1 = atoi(newExtensionEntryNo.c_str());
                                                }
                                                
                                                if (nextParentCellRevNoString.substr(0, 1) == "4"){
                                                    for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                                        if ((to_string(largeCellNumberList3 [counter1*2])).substr(0, 1) == "6" && (largeCellNumberList3 [counter1*2+1] == 0 || largeCellNumberList3 [counter1*2+1] == 2)){
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str()) < lowestCellCount){
                                                                lowestCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str());
                                                                lowestCellPosition = counter1;
                                                            }
                                                            
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str()) > maxCellCount){
                                                                maxCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str());
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (lowestCellCount == 0){
                                                        maxCellCount++;
                                                        lowestCellCount = maxCellCount;
                                                    }
                                                    
                                                    largeCellNumberList3 [lowestCellPosition*2+1] = 2;
                                                    
                                                    string newExtensionEntryNo = to_string(lowestCellCount);
                                                    
                                                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "60000"+newExtensionEntryNo+"700";
                                                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "6000"+newExtensionEntryNo+"700";
                                                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "600"+newExtensionEntryNo+"700";
                                                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "60"+newExtensionEntryNo+"700";
                                                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "6"+newExtensionEntryNo+"700";
                                                    
                                                    newCellNo1 = atoi(newExtensionEntryNo.c_str());
                                                }
                                            }
                                            else{
                                                
                                                if (nextParentCellRevNoString.substr(1, 1) == "0"){
                                                    for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                                        if ((to_string(largeCellNumberList3 [counter1*2])).substr(0, 2) == "-3" && (largeCellNumberList3 [counter1*2+1] == 0 || largeCellNumberList3 [counter1*2+1] == 2)){
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str()) < lowestCellCount){
                                                                lowestCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str());
                                                                lowestCellPosition = counter1;
                                                            }
                                                            
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str()) > maxCellCount){
                                                                maxCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str());
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (lowestCellCount == 0){
                                                        maxCellCount++;
                                                        lowestCellCount = maxCellCount;
                                                    }
                                                    else largeCellNumberList3 [lowestCellPosition*2+1] = 2;
                                                    
                                                    string newExtensionEntryNo = to_string(lowestCellCount);
                                                    
                                                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-30000"+newExtensionEntryNo+"700";
                                                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-3000"+newExtensionEntryNo+"700";
                                                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-300"+newExtensionEntryNo+"700";
                                                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-30"+newExtensionEntryNo+"700";
                                                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-3"+newExtensionEntryNo+"700";
                                                    
                                                    newCellNo1 = atoi(newExtensionEntryNo.c_str());
                                                }
                                                
                                                if (nextParentCellRevNoString.substr(1, 1) == "1"){
                                                    for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                                        if ((to_string(largeCellNumberList3 [counter1*2])).substr(0, 2) == "-4" && (largeCellNumberList3 [counter1*2+1] == 0 || largeCellNumberList3 [counter1*2+1] == 2)){
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str()) < lowestCellCount){
                                                                lowestCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str());
                                                                lowestCellPosition = counter1;
                                                            }
                                                            
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str()) > maxCellCount){
                                                                maxCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str());
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (lowestCellCount == 0){
                                                        maxCellCount++;
                                                        lowestCellCount = maxCellCount;
                                                    }
                                                    else largeCellNumberList3 [lowestCellPosition*2+1] = 2;
                                                    
                                                    string newExtensionEntryNo = to_string(lowestCellCount);
                                                    
                                                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-40000"+newExtensionEntryNo+"700";
                                                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-4000"+newExtensionEntryNo+"700";
                                                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-400"+newExtensionEntryNo+"700";
                                                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-40"+newExtensionEntryNo+"700";
                                                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-4"+newExtensionEntryNo+"700";
                                                    
                                                    newCellNo1 = atoi(newExtensionEntryNo.c_str());
                                                }
                                                
                                                if (nextParentCellRevNoString.substr(1, 1) == "3"){
                                                    for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                                        if ((to_string(largeCellNumberList3 [counter1*2])).substr(0, 2) == "-5" && (largeCellNumberList3 [counter1*2+1] == 0 || largeCellNumberList3 [counter1*2+1] == 2)){
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str()) < lowestCellCount){
                                                                lowestCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str());
                                                                lowestCellPosition = counter1;
                                                            }
                                                            
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str()) > maxCellCount){
                                                                maxCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str());
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (lowestCellCount == 0){
                                                        maxCellCount++;
                                                        lowestCellCount = maxCellCount;
                                                    }
                                                    else largeCellNumberList3 [lowestCellPosition*2+1] = 2;
                                                    
                                                    string newExtensionEntryNo = to_string(lowestCellCount);
                                                    
                                                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-50000"+newExtensionEntryNo+"700";
                                                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-5000"+newExtensionEntryNo+"700";
                                                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-500"+newExtensionEntryNo+"700";
                                                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-50"+newExtensionEntryNo+"700";
                                                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-5"+newExtensionEntryNo+"700";
                                                    
                                                    newCellNo1 = atoi(newExtensionEntryNo.c_str());
                                                }
                                                
                                                if (nextParentCellRevNoString.substr(1, 1) == "4"){
                                                    for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                                        if ((to_string(largeCellNumberList3 [counter1*2])).substr(0, 2) == "-6" && (largeCellNumberList3 [counter1*2+1] == 0 || largeCellNumberList3 [counter1*2+1] == 2)){
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str()) < lowestCellCount){
                                                                lowestCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str());
                                                                lowestCellPosition = counter1;
                                                            }
                                                            
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str()) > maxCellCount){
                                                                maxCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str());
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (lowestCellCount == 0){
                                                        maxCellCount++;
                                                        lowestCellCount = maxCellCount;
                                                    }
                                                    else largeCellNumberList3 [lowestCellPosition*2+1] = 2;
                                                    
                                                    string newExtensionEntryNo = to_string(lowestCellCount);
                                                    
                                                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-60000"+newExtensionEntryNo+"700";
                                                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-6000"+newExtensionEntryNo+"700";
                                                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-600"+newExtensionEntryNo+"700";
                                                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-60"+newExtensionEntryNo+"700";
                                                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-6"+newExtensionEntryNo+"700";
                                                    
                                                    newCellNo1 = atoi(newExtensionEntryNo.c_str());
                                                }
                                            }
                                        }
                                    }
                                    
                                    zeroPoint = -1;
                                    checkFlag = 0;
                                    
                                    if (nextParentCellRevNo == 0) newCellNo2 = 100000000;
                                    else{
                                        
                                        string digitExtract;
                                        
                                        for (int counter1 = 0; counter1 < numberLength; counter1++){
                                            digitExtract = to_string(nextParentCellRevNo).substr((unsigned long)counter1, 1);
                                            
                                            if (checkFlag == 0 && digitExtract == "0"){
                                                zeroPoint = counter1;
                                                checkFlag = 1;
                                            }
                                            else if (checkFlag == 1 && digitExtract != "0"){
                                                zeroPoint = -1;
                                                checkFlag = 0;
                                            }
                                        }
                                        
                                        if (zeroPoint != -1){
                                            digitNumber = numberLength-zeroPoint;
                                            
                                            if (digitNumber == 8) newCellNo2 = nextParentCellRevNo-10000000;
                                            else if (digitNumber == 7) newCellNo2 = nextParentCellRevNo-1000000;
                                            else if (digitNumber == 6) newCellNo2 = nextParentCellRevNo-100000;
                                            else if (digitNumber == 5) newCellNo2 = nextParentCellRevNo-10000;
                                            else if (digitNumber == 4) newCellNo2 = nextParentCellRevNo-1000;
                                            else if (digitNumber == 3) newCellNo2 = nextParentCellRevNo-100;
                                            else if (digitNumber == 2) newCellNo2 = nextParentCellRevNo-10;
                                            else if (digitNumber == 1) newCellNo2 = nextParentCellRevNo-1;
                                        }
                                        else{
                                            
                                            int lowestCellCount = 100000;
                                            int maxCellCount = 0;
                                            int lowestCellPosition = 0;
                                            
                                            string nextParentCellRevNoString = to_string(nextParentCellRevNo);
                                            
                                            if (nextParentCellRevNo > 0){
                                                if ((int)nextParentCellRevNoString.length() == 8){
                                                    nextParentCellRevNoString = "0"+nextParentCellRevNoString;
                                                }
                                            }
                                            else{
                                                
                                                if ((int)nextParentCellRevNoString.length() == 9){
                                                    nextParentCellRevNoString = "-0"+nextParentCellRevNoString.substr(1);
                                                }
                                            }
                                            
                                            if (nextParentCellRevNo > 0){
                                                if (nextParentCellRevNoString.substr(0, 1) == "0"){
                                                    for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                                        if ((to_string(largeCellNumberList3 [counter1*2])).substr(0, 1) == "3" && (largeCellNumberList3 [counter1*2+1] == 0 || largeCellNumberList3 [counter1*2+1] == 2)){
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str()) < lowestCellCount){
                                                                lowestCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str());
                                                                lowestCellPosition = counter1;
                                                            }
                                                            
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str()) > maxCellCount){
                                                                maxCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str());
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (lowestCellCount == 0){
                                                        maxCellCount++;
                                                        lowestCellCount = maxCellCount;
                                                    }
                                                    else largeCellNumberList3 [lowestCellPosition*2+1] = 2;
                                                    
                                                    string newExtensionEntryNo = to_string(lowestCellCount);
                                                    
                                                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "30000"+newExtensionEntryNo+"300";
                                                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "3000"+newExtensionEntryNo+"300";
                                                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "300"+newExtensionEntryNo+"300";
                                                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "30"+newExtensionEntryNo+"300";
                                                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "3"+newExtensionEntryNo+"300";
                                                    
                                                    newCellNo2 = atoi(newExtensionEntryNo.c_str());
                                                }
                                                
                                                if (nextParentCellRevNoString.substr(0, 1) == "1"){
                                                    for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                                        if ((to_string(largeCellNumberList3 [counter1*2])).substr(0, 1) == "4" && (largeCellNumberList3 [counter1*2+1] == 0 || largeCellNumberList3 [counter1*2+1] == 2)){
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str()) < lowestCellCount){
                                                                lowestCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str());
                                                                lowestCellPosition = counter1;
                                                            }
                                                            
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str()) > maxCellCount){
                                                                maxCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str());
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (lowestCellCount == 0){
                                                        maxCellCount++;
                                                        lowestCellCount = maxCellCount;
                                                    }
                                                    else largeCellNumberList3 [lowestCellPosition*2+1] = 2;
                                                    
                                                    string newExtensionEntryNo = to_string(lowestCellCount);
                                                    
                                                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "40000"+newExtensionEntryNo+"300";
                                                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "4000"+newExtensionEntryNo+"300";
                                                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "400"+newExtensionEntryNo+"300";
                                                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "40"+newExtensionEntryNo+"300";
                                                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "4"+newExtensionEntryNo+"300";
                                                    
                                                    newCellNo2 = atoi(newExtensionEntryNo.c_str());
                                                }
                                                
                                                if (nextParentCellRevNoString.substr(0, 1) == "3"){
                                                    for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                                        if ((to_string(largeCellNumberList3 [counter1*2])).substr(0, 1) == "5" && (largeCellNumberList3 [counter1*2+1] == 0 || largeCellNumberList3 [counter1*2+1] == 2)){
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str()) < lowestCellCount){
                                                                lowestCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str());
                                                                lowestCellPosition = counter1;
                                                            }
                                                            
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str()) > maxCellCount){
                                                                maxCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str());
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (lowestCellCount == 0){
                                                        maxCellCount++;
                                                        lowestCellCount = maxCellCount;
                                                    }
                                                    else largeCellNumberList3 [lowestCellPosition*2+1] = 2;
                                                    
                                                    string newExtensionEntryNo = to_string(lowestCellCount);
                                                    
                                                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "50000"+newExtensionEntryNo+"300";
                                                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "5000"+newExtensionEntryNo+"300";
                                                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "500"+newExtensionEntryNo+"300";
                                                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "50"+newExtensionEntryNo+"300";
                                                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "5"+newExtensionEntryNo+"300";
                                                    
                                                    newCellNo2 = atoi(newExtensionEntryNo.c_str());
                                                }
                                                
                                                if (nextParentCellRevNoString.substr(0, 1) == "4"){
                                                    for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                                        if ((to_string(largeCellNumberList3 [counter1*2])).substr(0, 1) == "6" && (largeCellNumberList3 [counter1*2+1] == 0 || largeCellNumberList3 [counter1*2+1] == 2)){
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str()) < lowestCellCount){
                                                                lowestCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str());
                                                                lowestCellPosition = counter1;
                                                            }
                                                            
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str()) > maxCellCount){
                                                                maxCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str());
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (lowestCellCount == 0){
                                                        maxCellCount++;
                                                        lowestCellCount = maxCellCount;
                                                    }
                                                    else largeCellNumberList3 [lowestCellPosition*2+1] = 2;
                                                    
                                                    string newExtensionEntryNo = to_string(lowestCellCount);
                                                    
                                                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "60000"+newExtensionEntryNo+"300";
                                                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "6000"+newExtensionEntryNo+"300";
                                                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "600"+newExtensionEntryNo+"300";
                                                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "60"+newExtensionEntryNo+"300";
                                                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "6"+newExtensionEntryNo+"300";
                                                    
                                                    newCellNo2 = atoi(newExtensionEntryNo.c_str());
                                                }
                                            }
                                            else{
                                                
                                                if (nextParentCellRevNoString.substr(1, 1) == "0"){
                                                    for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                                        if ((to_string(largeCellNumberList3 [counter1*2])).substr(0, 2) == "-3" && (largeCellNumberList3 [counter1*2+1] == 0 || largeCellNumberList3 [counter1*2+1] == 2)){
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str()) < lowestCellCount){
                                                                lowestCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str());
                                                                lowestCellPosition = counter1;
                                                            }
                                                            
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str()) > maxCellCount){
                                                                maxCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str());
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (lowestCellCount == 0){
                                                        maxCellCount++;
                                                        lowestCellCount = maxCellCount;
                                                    }
                                                    else largeCellNumberList3 [lowestCellPosition*2+1] = 2;
                                                    
                                                    string newExtensionEntryNo = to_string(lowestCellCount);
                                                    
                                                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-30000"+newExtensionEntryNo+"300";
                                                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-3000"+newExtensionEntryNo+"300";
                                                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-300"+newExtensionEntryNo+"300";
                                                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-30"+newExtensionEntryNo+"300";
                                                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-3"+newExtensionEntryNo+"300";
                                                    
                                                    newCellNo2 = atoi(newExtensionEntryNo.c_str());
                                                }
                                                
                                                if (nextParentCellRevNoString.substr(1, 1) == "1"){
                                                    for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                                        if ((to_string(largeCellNumberList3 [counter1*2])).substr(0, 2) == "-4" && (largeCellNumberList3 [counter1*2+1] == 0 || largeCellNumberList3 [counter1*2+1] == 2)){
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str()) < lowestCellCount){
                                                                lowestCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str());
                                                                lowestCellPosition = counter1;
                                                            }
                                                            
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str()) > maxCellCount){
                                                                maxCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str());
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (lowestCellCount == 0){
                                                        maxCellCount++;
                                                        lowestCellCount = maxCellCount;
                                                    }
                                                    else largeCellNumberList3 [lowestCellPosition*2+1] = 2;
                                                    
                                                    string newExtensionEntryNo = to_string(lowestCellCount);
                                                    
                                                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-40000"+newExtensionEntryNo+"300";
                                                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-4000"+newExtensionEntryNo+"300";
                                                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-400"+newExtensionEntryNo+"300";
                                                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-40"+newExtensionEntryNo+"300";
                                                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-4"+newExtensionEntryNo+"300";
                                                    
                                                    newCellNo2 = atoi(newExtensionEntryNo.c_str());
                                                }
                                                
                                                if (nextParentCellRevNoString.substr(1, 1) == "3"){
                                                    for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                                        if ((to_string(largeCellNumberList3 [counter1*2])).substr(0, 2) == "-5" && (largeCellNumberList3 [counter1*2+1] == 0 || largeCellNumberList3 [counter1*2+1] == 2)){
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str()) < lowestCellCount){
                                                                lowestCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str());
                                                                lowestCellPosition = counter1;
                                                            }
                                                            
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str()) > maxCellCount){
                                                                maxCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str());
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (lowestCellCount == 0){
                                                        maxCellCount++;
                                                        lowestCellCount = maxCellCount;
                                                    }
                                                    else largeCellNumberList3 [lowestCellPosition*2+1] = 2;
                                                    
                                                    string newExtensionEntryNo = to_string(lowestCellCount);
                                                    
                                                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-50000"+newExtensionEntryNo+"300";
                                                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-5000"+newExtensionEntryNo+"300";
                                                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-500"+newExtensionEntryNo+"300";
                                                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-50"+newExtensionEntryNo+"300";
                                                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-5"+newExtensionEntryNo+"300";
                                                    
                                                    newCellNo2 = atoi(newExtensionEntryNo.c_str());
                                                }
                                                
                                                if (nextParentCellRevNoString.substr(1, 1) == "4"){
                                                    for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                                        if ((to_string(largeCellNumberList3 [counter1*2])).substr(0, 2) == "-6" && (largeCellNumberList3 [counter1*2+1] == 0 || largeCellNumberList3 [counter1*2+1] == 2)){
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str()) < lowestCellCount){
                                                                lowestCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str());
                                                                lowestCellPosition = counter1;
                                                            }
                                                            
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str()) > maxCellCount){
                                                                maxCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str());
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (lowestCellCount == 0){
                                                        maxCellCount++;
                                                        lowestCellCount = maxCellCount;
                                                    }
                                                    else largeCellNumberList3 [lowestCellPosition*2+1] = 2;
                                                    
                                                    string newExtensionEntryNo = to_string(lowestCellCount);
                                                    
                                                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-60000"+newExtensionEntryNo+"300";
                                                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-6000"+newExtensionEntryNo+"300";
                                                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-600"+newExtensionEntryNo+"300";
                                                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-60"+newExtensionEntryNo+"300";
                                                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-6"+newExtensionEntryNo+"300";
                                                    
                                                    newCellNo2 = atoi(newExtensionEntryNo.c_str());
                                                }
                                            }
                                        }
                                    }
                                    
                                    if (numberOfCells == 2){
                                        string cellNumberTemp;
                                        int cellNumberInt = 0;
                                        
                                        for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                            if (largeCellNumberList3 [counter1*2+1] == 2){
                                                largeCellNumberList3 [counter1*2+1] = 1;
                                                cellNumberInt = largeCellNumberList3 [counter1*2];
                                                cellNumberTemp = to_string(largeCellNumberList3 [counter1*2]);
                                                break;
                                            }
                                        }
                                        
                                        if (cellNumberInt > 0){
                                            cellNumberTemp = cellNumberTemp.substr(0, 6);
                                            
                                            for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                                if (to_string(largeCellNumberList3 [counter1*2]).substr(0, 6) == cellNumberTemp){
                                                    largeCellNumberList3 [counter1*2+1] = 1;
                                                }
                                            }
                                        }
                                        else{
                                            
                                            cellNumberTemp = cellNumberTemp.substr(0, 7);
                                            
                                            for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                                if (to_string(largeCellNumberList3 [counter1*2]).substr(0, 7) == cellNumberTemp){
                                                    largeCellNumberList3 [counter1*2+1] = 1;
                                                }
                                            }
                                        }
                                    }
                                }
                                
                                if (numberOfCells >= 3){
                                    int numberLength = (int)to_string(nextParentCellRevNo).length();
                                    int zeroPoint = -1;
                                    int digitNumber = 0;
                                    int checkFlag = 0;
                                    
                                    if (nextParentCellRevNo == 0) newCellNo3 = -200000000;
                                    else{
                                        
                                        string digitExtract;
                                        
                                        for (int counter1 = 0; counter1 < numberLength; counter1++){
                                            digitExtract = to_string(nextParentCellRevNo).substr((unsigned long)counter1, 1);
                                            
                                            if (checkFlag == 0 && digitExtract == "0"){
                                                zeroPoint = counter1;
                                                checkFlag = 1;
                                            }
                                            else if (checkFlag == 1 && digitExtract != "0"){
                                                zeroPoint = -1;
                                                checkFlag = 0;
                                            }
                                        }
                                        
                                        if (zeroPoint != -1){
                                            digitNumber = numberLength-zeroPoint;
                                            
                                            if (digitNumber == 8) newCellNo3 = nextParentCellRevNo+20000000;
                                            else if (digitNumber == 7) newCellNo3 = nextParentCellRevNo+2000000;
                                            else if (digitNumber == 6) newCellNo3 = nextParentCellRevNo+200000;
                                            else if (digitNumber == 5) newCellNo3 = nextParentCellRevNo+20000;
                                            else if (digitNumber == 4) newCellNo3 = nextParentCellRevNo+2000;
                                            else if (digitNumber == 3) newCellNo3 = nextParentCellRevNo+200;
                                            else if (digitNumber == 2) newCellNo3 = nextParentCellRevNo+20;
                                            else if (digitNumber == 1) newCellNo3 = nextParentCellRevNo+2;
                                        }
                                        else{
                                            
                                            int lowestCellCount = 100000;
                                            int maxCellCount = 0;
                                            int lowestCellPosition = 0;
                                            
                                            string nextParentCellRevNoString = to_string(nextParentCellRevNo);
                                            
                                            if (nextParentCellRevNo > 0){
                                                if ((int)nextParentCellRevNoString.length() == 8){
                                                    nextParentCellRevNoString = "0"+nextParentCellRevNoString;
                                                }
                                            }
                                            else{
                                                
                                                if ((int)nextParentCellRevNoString.length() == 9){
                                                    nextParentCellRevNoString = "-0"+nextParentCellRevNoString.substr(1);
                                                }
                                            }
                                            
                                            if (nextParentCellRevNo > 0){
                                                if (nextParentCellRevNoString.substr(0, 1) == "0"){
                                                    for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                                        if ((to_string(largeCellNumberList3 [counter1*2])).substr(0, 1) == "3" && (largeCellNumberList3 [counter1*2+1] == 0 || largeCellNumberList3 [counter1*2+1] == 2)){
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str()) < lowestCellCount){
                                                                lowestCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str());
                                                                lowestCellPosition = counter1;
                                                            }
                                                            
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str()) > maxCellCount){
                                                                maxCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str());
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (lowestCellCount == 0){
                                                        maxCellCount++;
                                                        lowestCellCount = maxCellCount;
                                                    }
                                                    else largeCellNumberList3 [lowestCellPosition*2+1] = 2;
                                                    
                                                    string newExtensionEntryNo = to_string(lowestCellCount);
                                                    
                                                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "30000"+newExtensionEntryNo+"600";
                                                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "3000"+newExtensionEntryNo+"600";
                                                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "300"+newExtensionEntryNo+"600";
                                                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "30"+newExtensionEntryNo+"600";
                                                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "3"+newExtensionEntryNo+"600";
                                                    
                                                    newCellNo3 = atoi(newExtensionEntryNo.c_str());
                                                }
                                                
                                                if (nextParentCellRevNoString.substr(0, 1) == "1"){
                                                    for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                                        if ((to_string(largeCellNumberList3 [counter1*2])).substr(0, 1) == "4" && (largeCellNumberList3 [counter1*2+1] == 0 || largeCellNumberList3 [counter1*2+1] == 2)){
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str()) < lowestCellCount){
                                                                lowestCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str());
                                                                lowestCellPosition = counter1;
                                                            }
                                                            
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str()) > maxCellCount){
                                                                maxCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str());
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (lowestCellCount == 0){
                                                        maxCellCount++;
                                                        lowestCellCount = maxCellCount;
                                                    }
                                                    else largeCellNumberList3 [lowestCellPosition*2+1] = 2;
                                                    
                                                    string newExtensionEntryNo = to_string(lowestCellCount);
                                                    
                                                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "40000"+newExtensionEntryNo+"600";
                                                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "4000"+newExtensionEntryNo+"600";
                                                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "400"+newExtensionEntryNo+"600";
                                                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "40"+newExtensionEntryNo+"600";
                                                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "4"+newExtensionEntryNo+"600";
                                                    
                                                    newCellNo3 = atoi(newExtensionEntryNo.c_str());
                                                }
                                                
                                                if (nextParentCellRevNoString.substr(0, 1) == "3"){
                                                    for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                                        if ((to_string(largeCellNumberList3 [counter1*2])).substr(0, 1) == "5" && (largeCellNumberList3 [counter1*2+1] == 0 || largeCellNumberList3 [counter1*2+1] == 2)){
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str()) < lowestCellCount){
                                                                lowestCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str());
                                                                lowestCellPosition = counter1;
                                                            }
                                                            
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str()) > maxCellCount){
                                                                maxCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str());
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (lowestCellCount == 0){
                                                        maxCellCount++;
                                                        lowestCellCount = maxCellCount;
                                                    }
                                                    else largeCellNumberList3 [lowestCellPosition*2+1] = 2;
                                                    
                                                    string newExtensionEntryNo = to_string(lowestCellCount);
                                                    
                                                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "50000"+newExtensionEntryNo+"600";
                                                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "5000"+newExtensionEntryNo+"600";
                                                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "500"+newExtensionEntryNo+"600";
                                                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "50"+newExtensionEntryNo+"600";
                                                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "5"+newExtensionEntryNo+"600";
                                                    
                                                    newCellNo3 = atoi(newExtensionEntryNo.c_str());
                                                }
                                                
                                                if (nextParentCellRevNoString.substr(0, 1) == "4"){
                                                    for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                                        if ((to_string(largeCellNumberList3 [counter1*2])).substr(0, 1) == "6" && (largeCellNumberList3 [counter1*2+1] == 0 || largeCellNumberList3 [counter1*2+1] == 2)){
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str()) < lowestCellCount){
                                                                lowestCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str());
                                                                lowestCellPosition = counter1;
                                                            }
                                                            
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str()) > maxCellCount){
                                                                maxCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str());
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (lowestCellCount == 0){
                                                        maxCellCount++;
                                                        lowestCellCount = maxCellCount;
                                                    }
                                                    else largeCellNumberList3 [lowestCellPosition*2+1] = 2;
                                                    
                                                    string newExtensionEntryNo = to_string(lowestCellCount);
                                                    
                                                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "60000"+newExtensionEntryNo+"600";
                                                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "6000"+newExtensionEntryNo+"600";
                                                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "600"+newExtensionEntryNo+"600";
                                                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "60"+newExtensionEntryNo+"600";
                                                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "6"+newExtensionEntryNo+"600";
                                                    
                                                    newCellNo3 = atoi(newExtensionEntryNo.c_str());
                                                }
                                            }
                                            else{
                                                
                                                if (nextParentCellRevNoString.substr(1, 1) == "0"){
                                                    for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                                        if ((to_string(largeCellNumberList3 [counter1*2])).substr(0, 2) == "-3" && (largeCellNumberList3 [counter1*2+1] == 0 || largeCellNumberList3 [counter1*2+1] == 2)){
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str()) < lowestCellCount){
                                                                lowestCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str());
                                                                lowestCellPosition = counter1;
                                                            }
                                                            
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str()) > maxCellCount){
                                                                maxCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str());
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (lowestCellCount == 0){
                                                        maxCellCount++;
                                                        lowestCellCount = maxCellCount;
                                                    }
                                                    else largeCellNumberList3 [lowestCellPosition*2+1] = 2;
                                                    
                                                    string newExtensionEntryNo = to_string(lowestCellCount);
                                                    
                                                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-30000"+newExtensionEntryNo+"600";
                                                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-3000"+newExtensionEntryNo+"600";
                                                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-300"+newExtensionEntryNo+"600";
                                                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-30"+newExtensionEntryNo+"600";
                                                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-3"+newExtensionEntryNo+"600";
                                                    
                                                    newCellNo3 = atoi(newExtensionEntryNo.c_str());
                                                }
                                                
                                                if (nextParentCellRevNoString.substr(1, 1) == "1"){
                                                    for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                                        if ((to_string(largeCellNumberList3 [counter1*2])).substr(0, 2) == "-4" && (largeCellNumberList3 [counter1*2+1] == 0 || largeCellNumberList3 [counter1*2+1] == 2)){
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str()) < lowestCellCount){
                                                                lowestCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str());
                                                                lowestCellPosition = counter1;
                                                            }
                                                            
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str()) > maxCellCount){
                                                                maxCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str());
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (lowestCellCount == 0){
                                                        maxCellCount++;
                                                        lowestCellCount = maxCellCount;
                                                    }
                                                    else largeCellNumberList3 [lowestCellPosition*2+1] = 2;
                                                    
                                                    string newExtensionEntryNo = to_string(lowestCellCount);
                                                    
                                                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-40000"+newExtensionEntryNo+"600";
                                                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-4000"+newExtensionEntryNo+"600";
                                                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-400"+newExtensionEntryNo+"600";
                                                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-40"+newExtensionEntryNo+"600";
                                                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-4"+newExtensionEntryNo+"600";
                                                    
                                                    newCellNo3 = atoi(newExtensionEntryNo.c_str());
                                                }
                                                
                                                if (nextParentCellRevNoString.substr(1, 1) == "3"){
                                                    for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                                        if ((to_string(largeCellNumberList3 [counter1*2])).substr(0, 2) == "-5" && (largeCellNumberList3 [counter1*2+1] == 0 || largeCellNumberList3 [counter1*2+1] == 2)){
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str()) < lowestCellCount){
                                                                lowestCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str());
                                                                lowestCellPosition = counter1;
                                                            }
                                                            
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str()) > maxCellCount){
                                                                maxCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str());
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (lowestCellCount == 0){
                                                        maxCellCount++;
                                                        lowestCellCount = maxCellCount;
                                                    }
                                                    else largeCellNumberList3 [lowestCellPosition*2+1] = 2;
                                                    
                                                    string newExtensionEntryNo = to_string(lowestCellCount);
                                                    
                                                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-50000"+newExtensionEntryNo+"600";
                                                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-5000"+newExtensionEntryNo+"600";
                                                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-500"+newExtensionEntryNo+"600";
                                                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-50"+newExtensionEntryNo+"600";
                                                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-5"+newExtensionEntryNo+"600";
                                                    
                                                    newCellNo3 = atoi(newExtensionEntryNo.c_str());
                                                }
                                                
                                                if (nextParentCellRevNoString.substr(1, 1) == "4"){
                                                    for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                                        if ((to_string(largeCellNumberList3 [counter1*2])).substr(0, 2) == "-6" && (largeCellNumberList3 [counter1*2+1] == 0 || largeCellNumberList3 [counter1*2+1] == 2)){
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str()) < lowestCellCount){
                                                                lowestCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str());
                                                                lowestCellPosition = counter1;
                                                            }
                                                            
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str()) > maxCellCount){
                                                                maxCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str());
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (lowestCellCount == 0){
                                                        maxCellCount++;
                                                        lowestCellCount = maxCellCount;
                                                    }
                                                    else largeCellNumberList3 [lowestCellPosition*2+1] = 2;
                                                    
                                                    string newExtensionEntryNo = to_string(lowestCellCount);
                                                    
                                                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-60000"+newExtensionEntryNo+"600";
                                                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-6000"+newExtensionEntryNo+"600";
                                                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-600"+newExtensionEntryNo+"600";
                                                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-60"+newExtensionEntryNo+"600";
                                                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-6"+newExtensionEntryNo+"600";
                                                    
                                                    newCellNo3 = atoi(newExtensionEntryNo.c_str());
                                                }
                                            }
                                        }
                                    }
                                    
                                    if (numberOfCells == 3){
                                        string cellNumberTemp;
                                        int cellNumberInt = 0;
                                        
                                        for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                            if (largeCellNumberList3 [counter1*2+1] == 2){
                                                largeCellNumberList3 [counter1*2+1] = 1;
                                                cellNumberInt = largeCellNumberList3 [counter1*2];
                                                cellNumberTemp = to_string(largeCellNumberList3 [counter1*2]);
                                                break;
                                            }
                                        }
                                        
                                        if (cellNumberInt > 0){
                                            cellNumberTemp = cellNumberTemp.substr(0, 6);
                                            
                                            for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                                if (to_string(largeCellNumberList3 [counter1*2]).substr(0, 6) == cellNumberTemp){
                                                    largeCellNumberList3 [counter1*2+1] = 1;
                                                }
                                            }
                                        }
                                        else{
                                            
                                            cellNumberTemp = cellNumberTemp.substr(0, 7);
                                            
                                            for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                                if (to_string(largeCellNumberList3 [counter1*2]).substr(0, 7) == cellNumberTemp){
                                                    largeCellNumberList3 [counter1*2+1] = 1;
                                                }
                                            }
                                        }
                                    }
                                }
                                
                                if (numberOfCells == 4){
                                    int numberLength = (int)to_string(nextParentCellRevNo).length();
                                    int zeroPoint = -1;
                                    int digitNumber = 0;
                                    int checkFlag = 0;
                                    
                                    if (nextParentCellRevNo == 0) newCellNo4 = 200000000;
                                    else{
                                        
                                        string digitExtract;
                                        
                                        for (int counter1 = 0; counter1 < numberLength; counter1++){
                                            digitExtract = to_string(nextParentCellRevNo).substr((unsigned long)counter1, 1);
                                            
                                            if (checkFlag == 0 && digitExtract == "0"){
                                                zeroPoint = counter1;
                                                checkFlag = 1;
                                            }
                                            else if (checkFlag == 1 && digitExtract != "0"){
                                                zeroPoint = -1;
                                                checkFlag = 0;
                                            }
                                        }
                                        
                                        if (zeroPoint != -1){
                                            digitNumber = numberLength-zeroPoint;
                                            
                                            if (digitNumber == 8) newCellNo4 = nextParentCellRevNo-20000000;
                                            else if (digitNumber == 7) newCellNo4 = nextParentCellRevNo-2000000;
                                            else if (digitNumber == 6) newCellNo4 = nextParentCellRevNo-200000;
                                            else if (digitNumber == 5) newCellNo4 = nextParentCellRevNo-20000;
                                            else if (digitNumber == 4) newCellNo4 = nextParentCellRevNo-2000;
                                            else if (digitNumber == 3) newCellNo4 = nextParentCellRevNo-200;
                                            else if (digitNumber == 2) newCellNo4 = nextParentCellRevNo-20;
                                            else if (digitNumber == 1) newCellNo4 = nextParentCellRevNo-2;
                                        }
                                        else{
                                            
                                            int lowestCellCount = 100000;
                                            int maxCellCount = 0;
                                            int lowestCellPosition = 0;
                                            
                                            string nextParentCellRevNoString = to_string(nextParentCellRevNo);
                                            
                                            if (nextParentCellRevNo > 0){
                                                if ((int)nextParentCellRevNoString.length() == 8){
                                                    nextParentCellRevNoString = "0"+nextParentCellRevNoString;
                                                }
                                            }
                                            else{
                                                
                                                if ((int)nextParentCellRevNoString.length() == 9){
                                                    nextParentCellRevNoString = "-0"+nextParentCellRevNoString.substr(1);
                                                }
                                            }
                                            
                                            if (nextParentCellRevNo > 0){
                                                if (nextParentCellRevNoString.substr(0, 1) == "0"){
                                                    for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                                        if ((to_string(largeCellNumberList3 [counter1*2])).substr(0, 1) == "3" && (largeCellNumberList3 [counter1*2+1] == 0 || largeCellNumberList3 [counter1*2+1] == 2)){
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str()) < lowestCellCount){
                                                                lowestCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str());
                                                                lowestCellPosition = counter1;
                                                            }
                                                            
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str()) > maxCellCount){
                                                                maxCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str());
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (lowestCellCount == 0){
                                                        maxCellCount++;
                                                        lowestCellCount = maxCellCount;
                                                    }
                                                    else largeCellNumberList3 [lowestCellPosition*2+1] = 2;
                                                    
                                                    string newExtensionEntryNo = to_string(lowestCellCount);
                                                    
                                                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "30000"+newExtensionEntryNo+"400";
                                                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "3000"+newExtensionEntryNo+"400";
                                                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "300"+newExtensionEntryNo+"400";
                                                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "30"+newExtensionEntryNo+"400";
                                                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "3"+newExtensionEntryNo+"400";
                                                    
                                                    newCellNo4 = atoi(newExtensionEntryNo.c_str());
                                                }
                                                
                                                if (nextParentCellRevNoString.substr(0, 1) == "1"){
                                                    for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                                        if ((to_string(largeCellNumberList3 [counter1*2])).substr(0, 1) == "4" && (largeCellNumberList3 [counter1*2+1] == 0 || largeCellNumberList3 [counter1*2+1] == 2)){
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str()) < lowestCellCount){
                                                                lowestCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str());
                                                                lowestCellPosition = counter1;
                                                            }
                                                            
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str()) > maxCellCount){
                                                                maxCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str());
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (lowestCellCount == 0){
                                                        maxCellCount++;
                                                        lowestCellCount = maxCellCount;
                                                    }
                                                    else largeCellNumberList3 [lowestCellPosition*2+1] = 2;
                                                    
                                                    string newExtensionEntryNo = to_string(lowestCellCount);
                                                    
                                                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "40000"+newExtensionEntryNo+"400";
                                                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "4000"+newExtensionEntryNo+"400";
                                                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "400"+newExtensionEntryNo+"400";
                                                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "40"+newExtensionEntryNo+"400";
                                                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "4"+newExtensionEntryNo+"400";
                                                    
                                                    newCellNo4 = atoi(newExtensionEntryNo.c_str());
                                                }
                                                
                                                if (nextParentCellRevNoString.substr(0, 1) == "3"){
                                                    for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                                        if ((to_string(largeCellNumberList3 [counter1*2])).substr(0, 1) == "5" && (largeCellNumberList3 [counter1*2+1] == 0 || largeCellNumberList3 [counter1*2+1] == 2)){
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str()) < lowestCellCount){
                                                                lowestCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str());
                                                                lowestCellPosition = counter1;
                                                            }
                                                            
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str()) > maxCellCount){
                                                                maxCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str());
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (lowestCellCount == 0){
                                                        maxCellCount++;
                                                        lowestCellCount = maxCellCount;
                                                    }
                                                    else largeCellNumberList3 [lowestCellPosition*2+1] = 2;
                                                    
                                                    string newExtensionEntryNo = to_string(lowestCellCount);
                                                    
                                                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "50000"+newExtensionEntryNo+"400";
                                                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "5000"+newExtensionEntryNo+"400";
                                                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "500"+newExtensionEntryNo+"400";
                                                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "50"+newExtensionEntryNo+"400";
                                                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "5"+newExtensionEntryNo+"400";
                                                    
                                                    newCellNo4 = atoi(newExtensionEntryNo.c_str());
                                                }
                                                
                                                if (nextParentCellRevNoString.substr(0, 1) == "4"){
                                                    for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                                        if ((to_string(largeCellNumberList3 [counter1*2])).substr(0, 1) == "6" && (largeCellNumberList3 [counter1*2+1] == 0 || largeCellNumberList3 [counter1*2+1] == 2)){
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str()) < lowestCellCount){
                                                                lowestCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str());
                                                                lowestCellPosition = counter1;
                                                            }
                                                            
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str()) > maxCellCount){
                                                                maxCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(1, 5).c_str());
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (lowestCellCount == 0){
                                                        maxCellCount++;
                                                        lowestCellCount = maxCellCount;
                                                    }
                                                    else largeCellNumberList3 [lowestCellPosition*2+1] = 2;
                                                    
                                                    string newExtensionEntryNo = to_string(lowestCellCount);
                                                    
                                                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "60000"+newExtensionEntryNo+"400";
                                                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "6000"+newExtensionEntryNo+"400";
                                                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "600"+newExtensionEntryNo+"400";
                                                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "60"+newExtensionEntryNo+"400";
                                                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "6"+newExtensionEntryNo+"400";
                                                    
                                                    newCellNo4 = atoi(newExtensionEntryNo.c_str());
                                                }
                                            }
                                            else{
                                                
                                                if (nextParentCellRevNoString.substr(1, 1) == "0"){
                                                    for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                                        if ((to_string(largeCellNumberList3 [counter1*2])).substr(0, 2) == "-3" && (largeCellNumberList3 [counter1*2+1] == 0 || largeCellNumberList3 [counter1*2+1] == 2)){
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str()) < lowestCellCount){
                                                                lowestCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str());
                                                                lowestCellPosition = counter1;
                                                            }
                                                            
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str()) > maxCellCount){
                                                                maxCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str());
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (lowestCellCount == 0){
                                                        maxCellCount++;
                                                        lowestCellCount = maxCellCount;
                                                    }
                                                    else largeCellNumberList3 [lowestCellPosition*2+1] = 2;
                                                    
                                                    string newExtensionEntryNo = to_string(lowestCellCount);
                                                    
                                                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-30000"+newExtensionEntryNo+"400";
                                                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-3000"+newExtensionEntryNo+"400";
                                                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-300"+newExtensionEntryNo+"400";
                                                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-30"+newExtensionEntryNo+"400";
                                                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-3"+newExtensionEntryNo+"400";
                                                    
                                                    newCellNo4 = atoi(newExtensionEntryNo.c_str());
                                                }
                                                
                                                if (nextParentCellRevNoString.substr(1, 1) == "1"){
                                                    for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                                        if ((to_string(largeCellNumberList3 [counter1*2])).substr(0, 2) == "-4" && (largeCellNumberList3 [counter1*2+1] == 0 || largeCellNumberList3 [counter1*2+1] == 2)){
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str()) < lowestCellCount){
                                                                lowestCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str());
                                                                lowestCellPosition = counter1;
                                                            }
                                                            
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str()) > maxCellCount){
                                                                maxCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str());
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (lowestCellCount == 0){
                                                        maxCellCount++;
                                                        lowestCellCount = maxCellCount;
                                                    }
                                                    else largeCellNumberList3 [lowestCellPosition*2+1] = 2;
                                                    
                                                    string newExtensionEntryNo = to_string(lowestCellCount);
                                                    
                                                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-40000"+newExtensionEntryNo+"400";
                                                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-4000"+newExtensionEntryNo+"400";
                                                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-400"+newExtensionEntryNo+"400";
                                                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-40"+newExtensionEntryNo+"400";
                                                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-4"+newExtensionEntryNo+"400";
                                                    
                                                    newCellNo4 = atoi(newExtensionEntryNo.c_str());
                                                }
                                                
                                                if (nextParentCellRevNoString.substr(1, 1) == "3"){
                                                    for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                                        if ((to_string(largeCellNumberList3 [counter1*2])).substr(0, 2) == "-5" && (largeCellNumberList3 [counter1*2+1] == 0 || largeCellNumberList3 [counter1*2+1] == 2)){
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str()) < lowestCellCount){
                                                                lowestCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str());
                                                                lowestCellPosition = counter1;
                                                            }
                                                            
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str()) > maxCellCount){
                                                                maxCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str());
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (lowestCellCount == 0){
                                                        maxCellCount++;
                                                        lowestCellCount = maxCellCount;
                                                    }
                                                    else largeCellNumberList3 [lowestCellPosition*2+1] = 2;
                                                    
                                                    string newExtensionEntryNo = to_string(lowestCellCount);
                                                    
                                                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-50000"+newExtensionEntryNo+"400";
                                                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-5000"+newExtensionEntryNo+"400";
                                                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-500"+newExtensionEntryNo+"400";
                                                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-50"+newExtensionEntryNo+"400";
                                                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-5"+newExtensionEntryNo+"400";
                                                    
                                                    newCellNo4 = atoi(newExtensionEntryNo.c_str());
                                                }
                                                
                                                if (nextParentCellRevNoString.substr(1, 1) == "4"){
                                                    for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                                        if ((to_string(largeCellNumberList3 [counter1*2])).substr(0, 2) == "-6" && (largeCellNumberList3 [counter1*2+1] == 0 || largeCellNumberList3 [counter1*2+1] == 2)){
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str()) < lowestCellCount){
                                                                lowestCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str());
                                                                lowestCellPosition = counter1;
                                                            }
                                                            
                                                            if (atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str()) > maxCellCount){
                                                                maxCellCount = atoi((to_string(largeCellNumberList3 [counter1*2])).substr(2, 5).c_str());
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (lowestCellCount == 0){
                                                        maxCellCount++;
                                                        lowestCellCount = maxCellCount;
                                                    }
                                                    else largeCellNumberList3 [lowestCellPosition*2+1] = 2;
                                                    
                                                    string newExtensionEntryNo = to_string(lowestCellCount);
                                                    
                                                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-60000"+newExtensionEntryNo+"400";
                                                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-6000"+newExtensionEntryNo+"400";
                                                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-600"+newExtensionEntryNo+"400";
                                                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-60"+newExtensionEntryNo+"400";
                                                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-6"+newExtensionEntryNo+"400";
                                                    
                                                    newCellNo4 = atoi(newExtensionEntryNo.c_str());
                                                }
                                            }
                                        }
                                    }
                                    
                                    if (numberOfCells == 4){
                                        string cellNumberTemp;
                                        int cellNumberInt = 0;
                                        
                                        for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                            if (largeCellNumberList3 [counter1*2+1] == 2){
                                                largeCellNumberList3 [counter1*2+1] = 1;
                                                cellNumberInt = largeCellNumberList3 [counter1*2];
                                                cellNumberTemp = to_string(largeCellNumberList3 [counter1*2]);
                                                break;
                                            }
                                        }
                                        
                                        if (cellNumberInt > 0){
                                            cellNumberTemp = cellNumberTemp.substr(0, 6);
                                            
                                            for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                                if (to_string(largeCellNumberList3 [counter1*2]).substr(0, 6) == cellNumberTemp){
                                                    largeCellNumberList3 [counter1*2+1] = 1;
                                                }
                                            }
                                        }
                                        else{
                                            
                                            cellNumberTemp = cellNumberTemp.substr(0, 7);
                                            
                                            for (int counter1 = 0; counter1 < largeCellNumberListCount3/2; counter1++){
                                                if (to_string(largeCellNumberList3 [counter1*2]).substr(0, 7) == cellNumberTemp){
                                                    largeCellNumberList3 [counter1*2+1] = 1;
                                                }
                                            }
                                        }
                                    }
                                }
                                
                                if (numberOfCells == 2){
                                    if (cellNumberModificationTemp2 [0] < cellNumberModificationTemp2 [1]){
                                        cellNumberModificationTemp3 [0] = cellNumberModificationTemp2 [0];
                                        cellNumberModificationTemp3 [2] = cellNumberModificationTemp2 [1];
                                    }
                                    else{
                                        
                                        cellNumberModificationTemp3 [0] = cellNumberModificationTemp2 [1];
                                        cellNumberModificationTemp3 [2] = cellNumberModificationTemp2 [0];
                                    }
                                    
                                    if (newCellNo1 < newCellNo2){
                                        cellNumberModificationTemp3 [1] = newCellNo1;
                                        cellNumberModificationTemp3 [3] = newCellNo2;
                                    }
                                    else{
                                        
                                        cellNumberModificationTemp3 [1] = newCellNo2;
                                        cellNumberModificationTemp3 [3] = newCellNo1;
                                    }
                                }
                                else if (numberOfCells == 3){
                                    if (cellNumberModificationTemp2 [0] < cellNumberModificationTemp2 [1] && cellNumberModificationTemp2 [0] < cellNumberModificationTemp2 [2]){
                                        cellNumberModificationTemp3 [0] = cellNumberModificationTemp2 [0];
                                        
                                        if (cellNumberModificationTemp2 [1] < cellNumberModificationTemp2 [2]){
                                            cellNumberModificationTemp3 [2] = cellNumberModificationTemp2 [1];
                                            cellNumberModificationTemp3 [4] = cellNumberModificationTemp2 [2];
                                        }
                                        else{
                                            
                                            cellNumberModificationTemp3 [2] = cellNumberModificationTemp2 [2];
                                            cellNumberModificationTemp3 [4] = cellNumberModificationTemp2 [1];
                                        }
                                    }
                                    else if (cellNumberModificationTemp2 [1] < cellNumberModificationTemp2 [2] && cellNumberModificationTemp2 [1] < cellNumberModificationTemp2 [0]){
                                        cellNumberModificationTemp3 [0] = cellNumberModificationTemp2 [1];
                                        
                                        if (cellNumberModificationTemp2 [0] < cellNumberModificationTemp2 [2]){
                                            cellNumberModificationTemp3 [2] = cellNumberModificationTemp2 [0];
                                            cellNumberModificationTemp3 [4] = cellNumberModificationTemp2 [2];
                                        }
                                        else{
                                            
                                            cellNumberModificationTemp3 [2] = cellNumberModificationTemp2 [2];
                                            cellNumberModificationTemp3 [4] = cellNumberModificationTemp2 [0];
                                        }
                                        
                                    }
                                    else if (cellNumberModificationTemp2 [2] < cellNumberModificationTemp2 [0] && cellNumberModificationTemp2 [2] < cellNumberModificationTemp2 [1]){
                                        cellNumberModificationTemp3 [0] = cellNumberModificationTemp2 [2];
                                        
                                        if (cellNumberModificationTemp2 [0] < cellNumberModificationTemp2 [1]){
                                            cellNumberModificationTemp3 [2] = cellNumberModificationTemp2 [0];
                                            cellNumberModificationTemp3 [4] = cellNumberModificationTemp2 [1];
                                        }
                                        else{
                                            
                                            cellNumberModificationTemp3 [2] = cellNumberModificationTemp2 [1];
                                            cellNumberModificationTemp3 [4] = cellNumberModificationTemp2 [0];
                                        }
                                    }
                                    
                                    if (newCellNo1 < newCellNo2 && newCellNo1 < newCellNo3){
                                        cellNumberModificationTemp3 [1] = newCellNo1;
                                        
                                        if (newCellNo2 < newCellNo3){
                                            cellNumberModificationTemp3 [3] = newCellNo2;
                                            cellNumberModificationTemp3 [5] = newCellNo3;
                                        }
                                        else{
                                            
                                            cellNumberModificationTemp3 [3] = newCellNo3;
                                            cellNumberModificationTemp3 [5] = newCellNo2;
                                        }
                                    }
                                    else if (newCellNo2 < newCellNo3 && newCellNo2 < newCellNo1){
                                        cellNumberModificationTemp3 [1] = newCellNo2;
                                        
                                        if (newCellNo1 < newCellNo3){
                                            cellNumberModificationTemp3 [3] = newCellNo1;
                                            cellNumberModificationTemp3 [5] = newCellNo3;
                                        }
                                        else{
                                            
                                            cellNumberModificationTemp3 [3] = newCellNo3;
                                            cellNumberModificationTemp3 [5] = newCellNo1;
                                        }
                                    }
                                    else if (newCellNo3 < newCellNo1 && newCellNo3 < newCellNo2){
                                        cellNumberModificationTemp3 [1] = newCellNo3;
                                        
                                        if (newCellNo1 < newCellNo2){
                                            cellNumberModificationTemp3 [3] = newCellNo1;
                                            cellNumberModificationTemp3 [5] = newCellNo2;
                                        }
                                        else{
                                            
                                            cellNumberModificationTemp3 [3] = newCellNo2;
                                            cellNumberModificationTemp3 [5] = newCellNo1;
                                        }
                                    }
                                }
                                else if (numberOfCells == 4){
                                    if (cellNumberModificationTemp2 [0] < cellNumberModificationTemp2 [1] && cellNumberModificationTemp2 [0] < cellNumberModificationTemp2 [2] && cellNumberModificationTemp2 [0] < cellNumberModificationTemp2 [3]){
                                        cellNumberModificationTemp3 [0] = cellNumberModificationTemp2 [0];
                                        
                                        if (cellNumberModificationTemp2 [1] < cellNumberModificationTemp2 [2] && cellNumberModificationTemp2 [1] < cellNumberModificationTemp2 [3]){
                                            cellNumberModificationTemp3 [2] = cellNumberModificationTemp2 [1];
                                            
                                            if (cellNumberModificationTemp2 [2] < cellNumberModificationTemp2 [3]){
                                                cellNumberModificationTemp3 [4] = cellNumberModificationTemp2 [2];
                                                cellNumberModificationTemp3 [6] = cellNumberModificationTemp2 [3];
                                            }
                                            else{
                                                
                                                cellNumberModificationTemp3 [4] = cellNumberModificationTemp2 [3];
                                                cellNumberModificationTemp3 [6] = cellNumberModificationTemp2 [2];
                                            }
                                        }
                                        else if (cellNumberModificationTemp2 [2] < cellNumberModificationTemp2 [1] && cellNumberModificationTemp2 [2] < cellNumberModificationTemp2 [3]){
                                            cellNumberModificationTemp3 [2] = cellNumberModificationTemp2 [2];
                                            
                                            if (cellNumberModificationTemp2 [1] < cellNumberModificationTemp2 [3]){
                                                cellNumberModificationTemp3 [4] = cellNumberModificationTemp2 [1];
                                                cellNumberModificationTemp3 [6] = cellNumberModificationTemp2 [3];
                                            }
                                            else{
                                                
                                                cellNumberModificationTemp3 [4] = cellNumberModificationTemp2 [3];
                                                cellNumberModificationTemp3 [6] = cellNumberModificationTemp2 [1];
                                            }
                                        }
                                        else if (cellNumberModificationTemp2 [3] < cellNumberModificationTemp2 [1] && cellNumberModificationTemp2 [3] < cellNumberModificationTemp2 [2]){
                                            cellNumberModificationTemp3 [2] = cellNumberModificationTemp2 [3];
                                            
                                            if (cellNumberModificationTemp2 [1] < cellNumberModificationTemp2 [2]){
                                                cellNumberModificationTemp3 [4] = cellNumberModificationTemp2 [1];
                                                cellNumberModificationTemp3 [6] = cellNumberModificationTemp2 [2];
                                            }
                                            else{
                                                
                                                cellNumberModificationTemp3 [4] = cellNumberModificationTemp2 [2];
                                                cellNumberModificationTemp3 [6] = cellNumberModificationTemp2 [1];
                                            }
                                        }
                                    }
                                    else if (cellNumberModificationTemp2 [1] < cellNumberModificationTemp2 [0] && cellNumberModificationTemp2 [1] < cellNumberModificationTemp2 [2] && cellNumberModificationTemp2 [1] < cellNumberModificationTemp2 [3]){
                                        cellNumberModificationTemp3 [0] = cellNumberModificationTemp2 [1];
                                        
                                        if (cellNumberModificationTemp2 [0] < cellNumberModificationTemp2 [2] && cellNumberModificationTemp2 [0] < cellNumberModificationTemp2 [3]){
                                            cellNumberModificationTemp3 [2] = cellNumberModificationTemp2 [0];
                                            
                                            if (cellNumberModificationTemp2 [2] < cellNumberModificationTemp2 [3]){
                                                cellNumberModificationTemp3 [4] = cellNumberModificationTemp2 [2];
                                                cellNumberModificationTemp3 [6] = cellNumberModificationTemp2 [3];
                                            }
                                            else{
                                                
                                                cellNumberModificationTemp3 [4] = cellNumberModificationTemp2 [3];
                                                cellNumberModificationTemp3 [6] = cellNumberModificationTemp2 [2];
                                            }
                                        }
                                        else if (cellNumberModificationTemp2 [2] < cellNumberModificationTemp2 [0] && cellNumberModificationTemp2 [2] < cellNumberModificationTemp2 [3]){
                                            cellNumberModificationTemp3 [2] = cellNumberModificationTemp2 [2];
                                            
                                            if (cellNumberModificationTemp2 [0] < cellNumberModificationTemp2 [3]){
                                                cellNumberModificationTemp3 [4] = cellNumberModificationTemp2 [0];
                                                cellNumberModificationTemp3 [6] = cellNumberModificationTemp2 [3];
                                            }
                                            else{
                                                
                                                cellNumberModificationTemp3 [4] = cellNumberModificationTemp2 [3];
                                                cellNumberModificationTemp3 [6] = cellNumberModificationTemp2 [0];
                                            }
                                        }
                                        else if (cellNumberModificationTemp2 [3] < cellNumberModificationTemp2 [0] && cellNumberModificationTemp2 [3] < cellNumberModificationTemp2 [2]){
                                            cellNumberModificationTemp3 [2] = cellNumberModificationTemp2 [3];
                                            
                                            if (cellNumberModificationTemp2 [0] < cellNumberModificationTemp2 [2]){
                                                cellNumberModificationTemp3 [4] = cellNumberModificationTemp2 [0];
                                                cellNumberModificationTemp3 [6] = cellNumberModificationTemp2 [2];
                                            }
                                            else{
                                                
                                                cellNumberModificationTemp3 [4] = cellNumberModificationTemp2 [2];
                                                cellNumberModificationTemp3 [6] = cellNumberModificationTemp2 [0];
                                            }
                                        }
                                    }
                                    else if (cellNumberModificationTemp2 [2] < cellNumberModificationTemp2 [0] && cellNumberModificationTemp2 [2] < cellNumberModificationTemp2 [1] && cellNumberModificationTemp2 [2] < cellNumberModificationTemp2 [3]){
                                        cellNumberModificationTemp3 [0] = cellNumberModificationTemp2 [2];
                                        
                                        if (cellNumberModificationTemp2 [0] < cellNumberModificationTemp2 [1] && cellNumberModificationTemp2 [0] < cellNumberModificationTemp2 [3]){
                                            cellNumberModificationTemp3 [2] = cellNumberModificationTemp2 [0];
                                            
                                            if (cellNumberModificationTemp2 [1] < cellNumberModificationTemp2 [3]){
                                                cellNumberModificationTemp3 [4] = cellNumberModificationTemp2 [1];
                                                cellNumberModificationTemp3 [6] = cellNumberModificationTemp2 [3];
                                            }
                                            else{
                                                
                                                cellNumberModificationTemp3 [4] = cellNumberModificationTemp2 [3];
                                                cellNumberModificationTemp3 [6] = cellNumberModificationTemp2 [1];
                                            }
                                        }
                                        else if (cellNumberModificationTemp2 [1] < cellNumberModificationTemp2 [0] && cellNumberModificationTemp2 [1] < cellNumberModificationTemp2 [3]){
                                            cellNumberModificationTemp3 [2] = cellNumberModificationTemp2 [1];
                                            
                                            if (cellNumberModificationTemp2 [0] < cellNumberModificationTemp2 [1]){
                                                cellNumberModificationTemp3 [4] = cellNumberModificationTemp2 [0];
                                                cellNumberModificationTemp3 [6] = cellNumberModificationTemp2 [1];
                                            }
                                            else{
                                                
                                                cellNumberModificationTemp3 [4] = cellNumberModificationTemp2 [1];
                                                cellNumberModificationTemp3 [6] = cellNumberModificationTemp2 [0];
                                            }
                                        }
                                        else if (cellNumberModificationTemp2 [3] < cellNumberModificationTemp2 [0] && cellNumberModificationTemp2 [3] < cellNumberModificationTemp2 [1]){
                                            cellNumberModificationTemp3 [2] = cellNumberModificationTemp2 [3];
                                            
                                            if (cellNumberModificationTemp2 [0] < cellNumberModificationTemp2 [1]){
                                                cellNumberModificationTemp3 [4] = cellNumberModificationTemp2 [0];
                                                cellNumberModificationTemp3 [6] = cellNumberModificationTemp2 [1];
                                            }
                                            else{
                                                
                                                cellNumberModificationTemp3 [4] = cellNumberModificationTemp2 [1];
                                                cellNumberModificationTemp3 [6] = cellNumberModificationTemp2 [0];
                                            }
                                        }
                                    }
                                    else if (cellNumberModificationTemp2 [3] < cellNumberModificationTemp2 [0] && cellNumberModificationTemp2 [3] < cellNumberModificationTemp2 [1] && cellNumberModificationTemp2 [3] < cellNumberModificationTemp2 [2]){
                                        cellNumberModificationTemp3 [0] = cellNumberModificationTemp2 [3];
                                        
                                        if (cellNumberModificationTemp2 [0] < cellNumberModificationTemp2 [1] && cellNumberModificationTemp2 [0] < cellNumberModificationTemp2 [2]){
                                            cellNumberModificationTemp3 [2] = cellNumberModificationTemp2 [0];
                                            
                                            if (cellNumberModificationTemp2 [1] < cellNumberModificationTemp2 [2]){
                                                cellNumberModificationTemp3 [4] = cellNumberModificationTemp2 [1];
                                                cellNumberModificationTemp3 [6] = cellNumberModificationTemp2 [2];
                                            }
                                            else{
                                                
                                                cellNumberModificationTemp3 [4] = cellNumberModificationTemp2 [2];
                                                cellNumberModificationTemp3 [6] = cellNumberModificationTemp2 [1];
                                            }
                                        }
                                        else if (cellNumberModificationTemp2 [1] < cellNumberModificationTemp2 [0] && cellNumberModificationTemp2 [1] < cellNumberModificationTemp2 [2]){
                                            cellNumberModificationTemp3 [2] = cellNumberModificationTemp2 [1];
                                            
                                            if (cellNumberModificationTemp2 [0] < cellNumberModificationTemp2 [2]){
                                                cellNumberModificationTemp3 [4] = cellNumberModificationTemp2 [0];
                                                cellNumberModificationTemp3 [6] = cellNumberModificationTemp2 [2];
                                            }
                                            else{
                                                
                                                cellNumberModificationTemp3 [4] = cellNumberModificationTemp2 [2];
                                                cellNumberModificationTemp3 [6] = cellNumberModificationTemp2 [0];
                                            }
                                        }
                                        else if (cellNumberModificationTemp2 [2] < cellNumberModificationTemp2 [0] && cellNumberModificationTemp2 [2] < cellNumberModificationTemp2 [1]){
                                            cellNumberModificationTemp3 [2] = cellNumberModificationTemp2 [2];
                                            
                                            if (cellNumberModificationTemp2 [0] < cellNumberModificationTemp2 [1]){
                                                cellNumberModificationTemp3 [4] = cellNumberModificationTemp2 [0];
                                                cellNumberModificationTemp3 [6] = cellNumberModificationTemp2 [1];
                                            }
                                            else{
                                                
                                                cellNumberModificationTemp3 [4] = cellNumberModificationTemp2 [1];
                                                cellNumberModificationTemp3 [6] = cellNumberModificationTemp2 [0];
                                            }
                                        }
                                    }
                                    
                                    if (newCellNo1 < newCellNo2 && newCellNo1 < newCellNo3 && newCellNo1 < newCellNo4){
                                        cellNumberModificationTemp3 [1] = newCellNo1;
                                        
                                        if (newCellNo2 < newCellNo3 && newCellNo2 < newCellNo4){
                                            cellNumberModificationTemp3 [3] = newCellNo2;
                                            
                                            if (newCellNo3 < newCellNo4){
                                                cellNumberModificationTemp3 [5] = newCellNo3;
                                                cellNumberModificationTemp3 [7] = newCellNo4;
                                            }
                                            else{
                                                
                                                cellNumberModificationTemp3 [5] = newCellNo4;
                                                cellNumberModificationTemp3 [7] = newCellNo3;
                                            }
                                        }
                                        else if (newCellNo3 < newCellNo2 && newCellNo3 < newCellNo4){
                                            cellNumberModificationTemp3 [3] = newCellNo3;
                                            
                                            if (newCellNo2 < newCellNo4){
                                                cellNumberModificationTemp3 [5] = newCellNo2;
                                                cellNumberModificationTemp3 [7] = newCellNo4;
                                            }
                                            else{
                                                
                                                cellNumberModificationTemp3 [5] = newCellNo4;
                                                cellNumberModificationTemp3 [7] = newCellNo2;
                                            }
                                        }
                                        else if (newCellNo4 < newCellNo2 && newCellNo4 < newCellNo3){
                                            cellNumberModificationTemp3 [3] = newCellNo4;
                                            
                                            if (newCellNo2 < newCellNo3){
                                                cellNumberModificationTemp3 [5] = newCellNo2;
                                                cellNumberModificationTemp3 [7] = newCellNo3;
                                            }
                                            else{
                                                
                                                cellNumberModificationTemp3 [5] = newCellNo3;
                                                cellNumberModificationTemp3 [7] = newCellNo2;
                                            }
                                        }
                                    }
                                    else if (newCellNo2 < newCellNo1 && newCellNo2 < newCellNo3 && newCellNo2 < newCellNo4){
                                        cellNumberModificationTemp3 [1] = newCellNo2;
                                        
                                        if (newCellNo1 < newCellNo3 && newCellNo1 < newCellNo4){
                                            cellNumberModificationTemp3 [3] = newCellNo1;
                                            
                                            if (newCellNo3 < newCellNo4){
                                                cellNumberModificationTemp3 [5] = newCellNo3;
                                                cellNumberModificationTemp3 [7] = newCellNo4;
                                            }
                                            else{
                                                
                                                cellNumberModificationTemp3 [5] = newCellNo4;
                                                cellNumberModificationTemp3 [7] = newCellNo3;
                                            }
                                        }
                                        else if (newCellNo3 < newCellNo1 && newCellNo3 < newCellNo4){
                                            cellNumberModificationTemp3 [3] = newCellNo3;
                                            
                                            if (newCellNo1 < newCellNo4){
                                                cellNumberModificationTemp3 [5] = newCellNo1;
                                                cellNumberModificationTemp3 [7] = newCellNo4;
                                            }
                                            else{
                                                
                                                cellNumberModificationTemp3 [5] = newCellNo4;
                                                cellNumberModificationTemp3 [7] = newCellNo1;
                                            }
                                        }
                                        else if (newCellNo4 < newCellNo1 && newCellNo4 < newCellNo3){
                                            cellNumberModificationTemp3 [3] = newCellNo4;
                                            
                                            if (newCellNo1 < newCellNo3){
                                                cellNumberModificationTemp3 [5] = newCellNo1;
                                                cellNumberModificationTemp3 [7] = newCellNo3;
                                            }
                                            else{
                                                
                                                cellNumberModificationTemp3 [5] = newCellNo3;
                                                cellNumberModificationTemp3 [7] = newCellNo1;
                                            }
                                        }
                                    }
                                    else if (newCellNo3 < newCellNo1 && newCellNo3 < newCellNo2 && newCellNo3 < newCellNo4){
                                        cellNumberModificationTemp3 [1] = newCellNo3;
                                        
                                        if (newCellNo1 < newCellNo2 && newCellNo1 < newCellNo4){
                                            cellNumberModificationTemp3 [3] = newCellNo1;
                                            
                                            if (newCellNo1 < newCellNo4){
                                                cellNumberModificationTemp3 [5] = newCellNo1;
                                                cellNumberModificationTemp3 [7] = newCellNo4;
                                            }
                                            else{
                                                
                                                cellNumberModificationTemp3 [5] = newCellNo4;
                                                cellNumberModificationTemp3 [7] = newCellNo1;
                                            }
                                        }
                                        else if (newCellNo2 < newCellNo1 && newCellNo2 < newCellNo4){
                                            cellNumberModificationTemp3 [3] = newCellNo2;
                                            
                                            if (newCellNo1 < newCellNo4){
                                                cellNumberModificationTemp3 [5] = newCellNo1;
                                                cellNumberModificationTemp3 [7] = newCellNo4;
                                            }
                                            else{
                                                
                                                cellNumberModificationTemp3 [5] = newCellNo4;
                                                cellNumberModificationTemp3 [7] = newCellNo1;
                                            }
                                        }
                                        else if (newCellNo4 < newCellNo1 && newCellNo4 < newCellNo2){
                                            cellNumberModificationTemp3 [3] = newCellNo4;
                                            
                                            if (newCellNo1 < newCellNo2){
                                                cellNumberModificationTemp3 [5] = newCellNo1;
                                                cellNumberModificationTemp3 [7] = newCellNo2;
                                            }
                                            else{
                                                
                                                cellNumberModificationTemp3 [5] = newCellNo2;
                                                cellNumberModificationTemp3 [7] = newCellNo1;
                                            }
                                        }
                                    }
                                    else if (newCellNo4 < newCellNo1 && newCellNo4 < newCellNo2 && newCellNo4 < newCellNo3){
                                        cellNumberModificationTemp3 [1] = newCellNo4;
                                        
                                        if (newCellNo1 < newCellNo2 && newCellNo1 < newCellNo3){
                                            cellNumberModificationTemp3 [3] = newCellNo1;
                                            
                                            if (newCellNo1 < newCellNo3){
                                                cellNumberModificationTemp3 [5] = newCellNo1;
                                                cellNumberModificationTemp3 [7] = newCellNo3;
                                            }
                                            else{
                                                
                                                cellNumberModificationTemp3 [5] = newCellNo3;
                                                cellNumberModificationTemp3 [7] = newCellNo1;
                                            }
                                        }
                                        else if (newCellNo2 < newCellNo1 && newCellNo2 < newCellNo3){
                                            cellNumberModificationTemp3 [3] = newCellNo2;
                                            
                                            if (newCellNo1 < newCellNo3){
                                                cellNumberModificationTemp3 [5] = newCellNo1;
                                                cellNumberModificationTemp3 [7] = newCellNo3;
                                            }
                                            else{
                                                
                                                cellNumberModificationTemp3 [5] = newCellNo3;
                                                cellNumberModificationTemp3 [7] = newCellNo1;
                                            }
                                        }
                                        else if (newCellNo3 < newCellNo1 && newCellNo3 < newCellNo2){
                                            cellNumberModificationTemp3 [3] = newCellNo3;
                                            
                                            if (newCellNo1 < newCellNo2){
                                                cellNumberModificationTemp3 [5] = newCellNo1;
                                                cellNumberModificationTemp3 [7] = newCellNo2;
                                            }
                                            else{
                                                
                                                cellNumberModificationTemp3 [5] = newCellNo2;
                                                cellNumberModificationTemp3 [7] = newCellNo1;
                                            }
                                        }
                                    }
                                }
                                
                                if (numberOfCells >= 2){
                                    cellNumberModificationRef [cellNumberModificationRefCount] = lingNoForFuse1, cellNumberModificationRefCount++;
                                    cellNumberModificationRef [cellNumberModificationRefCount] = cellNumberModificationTemp3 [0], cellNumberModificationRefCount++;
                                    cellNumberModificationRef [cellNumberModificationRefCount] = lingNoForFuse1, cellNumberModificationRefCount++;
                                    cellNumberModificationRef [cellNumberModificationRefCount] = cellNumberModificationTemp3 [1], cellNumberModificationRefCount++;
                                    
                                    cellNumberModificationRef [cellNumberModificationRefCount] = lingNoForFuse1, cellNumberModificationRefCount++;
                                    cellNumberModificationRef [cellNumberModificationRefCount] = cellNumberModificationTemp3 [2], cellNumberModificationRefCount++;
                                    cellNumberModificationRef [cellNumberModificationRefCount] = lingNoForFuse1, cellNumberModificationRefCount++;
                                    cellNumberModificationRef [cellNumberModificationRefCount] = cellNumberModificationTemp3 [3], cellNumberModificationRefCount++;
                                }
                                
                                if (numberOfCells >= 3){
                                    cellNumberModificationRef [cellNumberModificationRefCount] = lingNoForFuse1, cellNumberModificationRefCount++;
                                    cellNumberModificationRef [cellNumberModificationRefCount] = cellNumberModificationTemp3 [4], cellNumberModificationRefCount++;
                                    cellNumberModificationRef [cellNumberModificationRefCount] = lingNoForFuse1, cellNumberModificationRefCount++;
                                    cellNumberModificationRef [cellNumberModificationRefCount] = cellNumberModificationTemp3 [5], cellNumberModificationRefCount++;
                                }
                                
                                if (numberOfCells == 4){
                                    cellNumberModificationRef [cellNumberModificationRefCount] = lingNoForFuse1, cellNumberModificationRefCount++;
                                    cellNumberModificationRef [cellNumberModificationRefCount] = cellNumberModificationTemp3 [6], cellNumberModificationRefCount++;
                                    cellNumberModificationRef [cellNumberModificationRefCount] = lingNoForFuse1, cellNumberModificationRefCount++;
                                    cellNumberModificationRef [cellNumberModificationRefCount] = cellNumberModificationTemp3 [7], cellNumberModificationRefCount++;
                                }
                                
                                cellNumberModificationTemp [positionFlag*2+1] = 1;
                            }
                            else cellNumberModificationTemp [positionFlag*2+1] = 1;
                            
                            positionFlag = -1;
                            
                            for (int counter1 = 0; counter1 < cellNumberModificationTempCount/2; counter1++){
                                if (cellNumberModificationTemp [counter1*2+1] == 0){
                                    positionFlag = counter1;
                                    nextParentCellNo = cellNumberModificationTemp [counter1*2];
                                    break;
                                }
                            }
                            
                            for (int counter1 = 0; counter1 < cellNumberModificationRefCount/4; counter1++){
                                if (cellNumberModificationRef [counter1*4+1] == nextParentCellNo){
                                    nextParentCellRevNo = cellNumberModificationRef [counter1*4+3];
                                    break;
                                }
                            }
                            
                            //for (int counterA = 0; counterA < cellNumberModificationRefCount/4; counterA++){
                            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<cellNumberModificationRef [counterA*4+counterB];
                            //    cout<<" cellNumberModificationRef "<<counterA<<endl;
                            //}
                            
                            if (positionFlag == -1){
                                terminationFlag = 0;
                            }
                            
                        } while (terminationFlag == 1);
                        
                        delete [] largeCellNumberList2;
                        delete [] largeCellNumberList3;
                        
                        //for (int counterA = 0; counterA < cellNumberModificationRefCount/4; counterA++){
                        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<cellNumberModificationRef [counterA*4+counterB];
                        //    cout<<" cellNumberModificationRef "<<counterA<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < lineageExtractCount/9; counterA++){
                        //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayLineageExtract [counterA*9+counterB];
                        //    cout<<" arrayLineageExtract "<<counterA<<endl;
                        //}
                        
                        int changeFlag = 0;
                        
                        for (unsigned long counter1 = 0; counter1 < lineageExtractCount/9; counter1++){
                            changeFlag = 0;
                            
                            for (int counter2 = 0; counter2 < cellNumberModificationRefCount/4; counter2++){
                                if (arrayLineageExtract [counter1*9+6] == cellNumberModificationRef [counter2*4] && arrayLineageExtract [counter1*9+5] == cellNumberModificationRef [counter2*4+1]){
                                    arrayLineageExtract [counter1*9+5] = cellNumberModificationRef [counter2*4+3];
                                    
                                    if (arrayLineageExtract [counter1*9+3] == 31 || arrayLineageExtract [counter1*9+3] == 41 || arrayLineageExtract [counter1*9+3] == 51 || arrayLineageExtract [counter1*9+3] == 91 || arrayLineageExtract [counter1*9+3] == 92){
                                        
                                        for (int counter3 = 0; counter3 < cellNumberModificationRefCount/4; counter3++){
                                            if (arrayLineageExtract [counter1*9+4] == cellNumberModificationRef [counter3*4+1]){
                                                arrayLineageExtract [counter1*9+4] = cellNumberModificationRef [counter3*4+3];
                                                break;
                                            }
                                        }
                                    }
                                    
                                    changeFlag = 1;
                                    break;
                                }
                                
                                if (arrayLineageExtract [counter1*9+6] != arrayLineageExtract [counter1*9+7] && arrayLineageExtract [counter1*9+7] == cellNumberModificationRef [counter2*4] && arrayLineageExtract [counter1*9+4] == cellNumberModificationRef [counter2*4+1]){
                                    arrayLineageExtract [counter1*9+4] = cellNumberModificationRef [counter2*4+3];
                                    
                                    break;
                                }
                            }
                            
                            if (changeFlag == 0){
                                for (int counter2 = 0; counter2 < cellNumberModificationRefCount/4; counter2++){
                                    if (arrayLineageExtract [counter1*9+6] == cellNumberModificationRef [counter2*4] && arrayLineageExtract [counter1*9+4] == cellNumberModificationRef [counter2*4+1] && (arrayLineageExtract [counter1*9+3] == 31 || arrayLineageExtract [counter1*9+3] == 41 || arrayLineageExtract [counter1*9+3] == 51 || arrayLineageExtract [counter1*9+3] == 91 || arrayLineageExtract [counter1*9+3] == 92)){
                                        arrayLineageExtract [counter1*9+4] = cellNumberModificationRef [counter2*4+3];
                                        break;
                                    }
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < lineageExtractCount/9; counterA++){
                        //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayLineageExtract [counterA*9+counterB];
                        //    cout<<" arrayLineageExtract "<<counterA<<endl;
                        //}
                        
                        int *cellDataList = new int [lineageExtractCount/9+10];
                        int cellEntryCountTemp = 0;
                        
                        for (unsigned long counter1 = 0; counter1 < lineageExtractCount/9; counter1++){
                            if (lingNoForFuse1 == arrayLineageExtract [counter1*9+6] && (arrayLineageExtract [counter1*9+3] == 1 || arrayLineageExtract [counter1*9+3] == 31 || arrayLineageExtract [counter1*9+3] == 41 || arrayLineageExtract [counter1*9+3] == 51)){
                                cellDataList [cellEntryCountTemp] = arrayLineageExtract [counter1*9+5], cellEntryCountTemp++;
                                cellDataList [cellEntryCountTemp] = arrayLineageExtract [counter1*9+2], cellEntryCountTemp++;
                                cellDataList [cellEntryCountTemp] = 0, cellEntryCountTemp++;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < cellEntryCountTemp/3; counterA++){
                        //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<cellDataList [counterA*3+counterB];
                        //    cout<<" cellDataList "<<counterA<<endl;
                        //}
                        
                        int reviseCellNo = 1;
                        int smallestTimePoint = 0;
                        int smallestValue = 0;
                        
                        do{
                            
                            terminationFlag = 1;
                            smallestTimePoint = -1;
                            smallestValue = 100000;
                            
                            for (int counter2 = 0; counter2 < cellEntryCountTemp/3; counter2++){
                                if (smallestValue > cellDataList [counter2*3+1] && cellDataList [counter2*3+2] == 0){
                                    smallestValue = cellDataList [counter2*3+1];
                                    smallestTimePoint = counter2;
                                }
                            }
                            
                            if (smallestTimePoint != -1){
                                cellDataList [smallestTimePoint*3+2] = reviseCellNo;
                                reviseCellNo++;
                            }
                            else terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                        
                        //for (int counterA = 0; counterA < cellEntryCountTemp/3; counterA++){
                        //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<cellDataList [counterA*3+counterB];
                        //    cout<<" cellDataList "<<counterA<<endl;
                        //}
                        
                        for (unsigned long counter1 = 0; counter1 < lineageExtractCount/9; counter1++){
                            if (lingNoForFuse1 == arrayLineageExtract [counter1*9+6]){
                                for (int counter2 = 0; counter2 < cellEntryCountTemp/3; counter2++){
                                    if (arrayLineageExtract [counter1*9+5] == cellDataList [counter2*3]){
                                        arrayLineageExtract [counter1*9+8] = cellDataList [counter2*3+2];
                                    }
                                }
                            }
                        }
                        
                        delete [] cellDataList;
                        
                        //for (int counterA = 0; counterA < ifValueExtractCount/13; counterA++){
                        //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<ifValueExtract [counterA*13+counterB];
                        //    cout<<" ifValueExtract "<<counterA<<endl;
                        //}
                        
                        for (int counter1 = 0; counter1 < ifValueExtractCount/22; counter1++){
                            for (int counter2 = 0; counter2 < cellNumberModificationRefCount/4; counter2++){
                                if (ifValueExtract [counter1*22+1] == cellNumberModificationRef [counter2*4] && ifValueExtract [counter1*22] == cellNumberModificationRef [counter2*4+1]){
                                    ifValueExtract [counter1*22+1] = cellNumberModificationRef [counter2*4+2];
                                    ifValueExtract [counter1*22] = cellNumberModificationRef [counter2*4+3];
                                    break;
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < areaExtractCount/5; counterA++){
                        //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<areaExtract [counterA*5+counterB];
                        //    cout<<" areaExtract "<<counterA<<endl;
                        //}
                        
                        for (int counter1 = 0; counter1 < areaExtractCount/5; counter1++){
                            for (int counter2 = 0; counter2 < cellNumberModificationRefCount/4; counter2++){
                                if (areaExtract [counter1*5] == cellNumberModificationRef [counter2*4] && areaExtract [counter1*5+1] == cellNumberModificationRef [counter2*4+1]){
                                    areaExtract [counter1*5+1] = cellNumberModificationRef [counter2*4+3];
                                    break;
                                }
                            }
                        }
                        
                        delete [] cellNumberModificationRef;
                        delete [] cellNumberModificationTemp;
                        delete [] cellNumberModificationTemp2;
                        delete [] cellNumberModificationTemp3;
                        
                        //----Lineage link data get----
                        int extractCount = 0;
                        
                        int *lineageSelect = new int [lineageLinkListLength+5];
                        
                        lineageSelect [extractCount] = arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength];
                        extractCount++;
                        
                        for (int counter2 = 1; counter2 < lineageLinkListLength; counter2++){
                            if (arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter2] != 0){
                                lineageSelect [extractCount] = arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter2];
                                extractCount++;
                            }
                        }
                        
                        if (holdReviseLineageStatus == 0){
                            holdReviseLineageStatus = 1;
                            holdReviseLineageCount = 0;
                            holdReviseLineageLimit = lineageExtractCount+5000;
                            holdReviseLineage = new int [holdReviseLineageLimit];
                        }
                        
                        //----Hold Lineage data clear----
                        int lineageNoFind = 0;
                        
                        if (holdReviseLineageCount != 0){
                            for (int counter1 = 0; counter1 < extractCount; counter1++){
                                lineageNoFind = lineageSelect [counter1];
                                
                                for (unsigned long counter2 = 0; counter2 < holdReviseLineageCount/9; counter2++){
                                    if (holdReviseLineage [counter2*9+6] == lineageNoFind){
                                        holdReviseLineage [counter2*9+6] = 0;
                                    }
                                }
                            }
                            
                            int lineageHoldCount = 0;
                            
                            for (unsigned long counter2 = 0; counter2 < holdReviseLineageCount/9; counter2++){
                                if (holdReviseLineage [counter2*9+6] != 0){
                                    holdReviseLineage [lineageHoldCount] = holdReviseLineage [counter2*9], lineageHoldCount++;
                                    holdReviseLineage [lineageHoldCount] = holdReviseLineage [counter2*9+1], lineageHoldCount++;
                                    holdReviseLineage [lineageHoldCount] = holdReviseLineage [counter2*9+2], lineageHoldCount++;
                                    holdReviseLineage [lineageHoldCount] = holdReviseLineage [counter2*9+3], lineageHoldCount++;
                                    holdReviseLineage [lineageHoldCount] = holdReviseLineage [counter2*9+4], lineageHoldCount++;
                                    holdReviseLineage [lineageHoldCount] = holdReviseLineage [counter2*9+5], lineageHoldCount++;
                                    holdReviseLineage [lineageHoldCount] = holdReviseLineage [counter2*9+6], lineageHoldCount++;
                                    holdReviseLineage [lineageHoldCount] = holdReviseLineage [counter2*9+7], lineageHoldCount++;
                                    holdReviseLineage [lineageHoldCount] = holdReviseLineage [counter2*9+8], lineageHoldCount++;
                                }
                            }
                            
                            holdReviseLineageCount = (unsigned long)lineageHoldCount;
                        }
                        
                        //for (int counterA = 0; counterA < holdReviseLineageCount/9; counterA++){
                        //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<holdReviseLineage [counterA*9+counterB];
                        //    cout<<" holdReviseLineage "<<counterA<<endl;
                        //}
                        
                        for (unsigned long counter1 = 0; counter1 < lineageExtractCount/9; counter1++){
                            if (holdReviseLineageCount+10 > holdReviseLineageLimit){
                                int *arrayUpDate = new int [holdReviseLineageCount+10];
                                
                                for (unsigned long counter3 = 0; counter3 < holdReviseLineageCount; counter3++) arrayUpDate [counter3] = holdReviseLineage [counter3];
                                
                                delete [] holdReviseLineage;
                                holdReviseLineageLimit = holdReviseLineageCount+5000;
                                holdReviseLineage = new int [holdReviseLineageLimit];
                                
                                for (unsigned long counter3 = 0; counter3 < holdReviseLineageCount; counter3++) holdReviseLineage [counter3] = arrayUpDate [counter3];
                                delete [] arrayUpDate;
                            }
                            
                            holdReviseLineage [holdReviseLineageCount] = arrayLineageExtract [counter1*9], holdReviseLineageCount++;
                            holdReviseLineage [holdReviseLineageCount] = arrayLineageExtract [counter1*9+1], holdReviseLineageCount++;
                            holdReviseLineage [holdReviseLineageCount] = arrayLineageExtract [counter1*9+2], holdReviseLineageCount++;
                            holdReviseLineage [holdReviseLineageCount] = arrayLineageExtract [counter1*9+3], holdReviseLineageCount++;
                            holdReviseLineage [holdReviseLineageCount] = arrayLineageExtract [counter1*9+4], holdReviseLineageCount++;
                            holdReviseLineage [holdReviseLineageCount] = arrayLineageExtract [counter1*9+5], holdReviseLineageCount++;
                            holdReviseLineage [holdReviseLineageCount] = arrayLineageExtract [counter1*9+6], holdReviseLineageCount++;
                            holdReviseLineage [holdReviseLineageCount] = arrayLineageExtract [counter1*9+7], holdReviseLineageCount++;
                            holdReviseLineage [holdReviseLineageCount] = arrayLineageExtract [counter1*9+8], holdReviseLineageCount++;
                        }
                        
                        //for (int counterA = 0; counterA < holdReviseLineageCount/9; counterA++){
                        //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<holdReviseLineage [counterA*9+counterB];
                        //    cout<<" holdReviseLineage "<<counterA<<endl;
                        //}
                        
                        if (holdReviseIfDataStatus == 0){
                            holdReviseIfDataStatus = 1;
                            holdReviseIfDataCount = 0;
                            holdReviseIfDataLimit = ifValueExtractCount+1000;
                            holdReviseIfData = new int [holdReviseIfDataLimit];
                        }
                        
                        if (holdReviseIfDataCount != 0){
                            //----Hold IF data clear----
                            for (int counter1 = 0; counter1 < extractCount; counter1++){
                                lineageNoFind = lineageSelect [counter1];
                                
                                for (int counter2 = 0; counter2 < holdReviseIfDataCount/22; counter2++){
                                    if (holdReviseIfData [counter2*22+1] == lineageNoFind){
                                        holdReviseIfData [counter2*22+1] = 0;
                                    }
                                }
                            }
                            
                            int lineageHoldCount = 0;
                            
                            for (int counter2 = 0; counter2 < holdReviseIfDataCount/22; counter2++){
                                if (holdReviseIfData [counter2*22+1] != 0){
                                    holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22], lineageHoldCount++;
                                    holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+1], lineageHoldCount++;
                                    holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+2], lineageHoldCount++;
                                    holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+3], lineageHoldCount++;
                                    holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+4], lineageHoldCount++;
                                    holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+5], lineageHoldCount++;
                                    holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+6], lineageHoldCount++;
                                    holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+7], lineageHoldCount++;
                                    holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+8], lineageHoldCount++;
                                    holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+9], lineageHoldCount++;
                                    holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+10], lineageHoldCount++;
                                    holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+11], lineageHoldCount++;
                                    holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+12], lineageHoldCount++;
                                    holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+13], lineageHoldCount++;
                                    holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+14], lineageHoldCount++;
                                    holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+15], lineageHoldCount++;
                                    holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+16], lineageHoldCount++;
                                    holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+17], lineageHoldCount++;
                                    holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+18], lineageHoldCount++;
                                    holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+19], lineageHoldCount++;
                                    holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+20], lineageHoldCount++;
                                    holdReviseIfData [lineageHoldCount] = holdReviseIfData [counter2*22+21], lineageHoldCount++;
                                }
                            }
                            
                            holdReviseIfDataCount = lineageHoldCount;
                        }
                        
                        for (int counter1 = 0; counter1 < ifValueExtractCount/22; counter1++){
                            if (holdReviseIfDataCount+50 > holdReviseIfDataLimit){
                                int *arrayUpDate = new int [holdReviseIfDataCount+10];
                                
                                for (int counter3 = 0; counter3 < holdReviseIfDataCount; counter3++) arrayUpDate [counter3] = holdReviseIfData [counter3];
                                
                                delete [] holdReviseIfData;
                                holdReviseIfDataLimit = holdReviseIfDataCount+5000;
                                holdReviseIfData = new int [holdReviseIfDataLimit];
                                
                                for (int counter3 = 0; counter3 < holdReviseIfDataCount; counter3++) holdReviseIfData [counter3] = arrayUpDate [counter3];
                                delete [] arrayUpDate;
                            }
                            
                            holdReviseIfData [holdReviseIfDataCount] = ifValueExtract [counter1*22], holdReviseIfDataCount++;
                            holdReviseIfData [holdReviseIfDataCount] = ifValueExtract [counter1*22+1], holdReviseIfDataCount++;
                            holdReviseIfData [holdReviseIfDataCount] = ifValueExtract [counter1*22+2], holdReviseIfDataCount++;
                            holdReviseIfData [holdReviseIfDataCount] = ifValueExtract [counter1*22+3], holdReviseIfDataCount++;
                            holdReviseIfData [holdReviseIfDataCount] = ifValueExtract [counter1*22+4], holdReviseIfDataCount++;
                            holdReviseIfData [holdReviseIfDataCount] = ifValueExtract [counter1*22+5], holdReviseIfDataCount++;
                            holdReviseIfData [holdReviseIfDataCount] = ifValueExtract [counter1*22+6], holdReviseIfDataCount++;
                            holdReviseIfData [holdReviseIfDataCount] = ifValueExtract [counter1*22+7], holdReviseIfDataCount++;
                            holdReviseIfData [holdReviseIfDataCount] = ifValueExtract [counter1*22+8], holdReviseIfDataCount++;
                            holdReviseIfData [holdReviseIfDataCount] = ifValueExtract [counter1*22+9], holdReviseIfDataCount++;
                            holdReviseIfData [holdReviseIfDataCount] = ifValueExtract [counter1*22+10], holdReviseIfDataCount++;
                            holdReviseIfData [holdReviseIfDataCount] = ifValueExtract [counter1*22+11], holdReviseIfDataCount++;
                            holdReviseIfData [holdReviseIfDataCount] = ifValueExtract [counter1*22+12], holdReviseIfDataCount++;
                            holdReviseIfData [holdReviseIfDataCount] = ifValueExtract [counter1*22+13], holdReviseIfDataCount++;
                            holdReviseIfData [holdReviseIfDataCount] = ifValueExtract [counter1*22+14], holdReviseIfDataCount++;
                            holdReviseIfData [holdReviseIfDataCount] = ifValueExtract [counter1*22+15], holdReviseIfDataCount++;
                            holdReviseIfData [holdReviseIfDataCount] = ifValueExtract [counter1*22+16], holdReviseIfDataCount++;
                            holdReviseIfData [holdReviseIfDataCount] = ifValueExtract [counter1*22+17], holdReviseIfDataCount++;
                            holdReviseIfData [holdReviseIfDataCount] = ifValueExtract [counter1*22+18], holdReviseIfDataCount++;
                            holdReviseIfData [holdReviseIfDataCount] = ifValueExtract [counter1*22+19], holdReviseIfDataCount++;
                            holdReviseIfData [holdReviseIfDataCount] = ifValueExtract [counter1*22+20], holdReviseIfDataCount++;
                            holdReviseIfData [holdReviseIfDataCount] = ifValueExtract [counter1*22+21], holdReviseIfDataCount++;
                        }
                        
                        //for (int counterA = 0; counterA < holdReviseIfDataCount/13; counterA++){
                        //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<holdReviseIfData [counterA*13+counterB];
                        //    cout<<" holdReviseIfData "<<counterA<<endl;
                        //}
                        
                        if (holdReviseAreaDataStatus == 0){
                            holdReviseAreaDataStatus = 1;
                            holdReviseAreaDataCount = 0;
                            holdReviseAreaDataLimit = areaExtractCount+5000;
                            holdReviseAreaData = new int [holdReviseAreaDataLimit];
                        }
                        
                        //----Area data clear----
                        if (holdReviseAreaDataCount != 0){
                            for (int counter1 = 0; counter1 < extractCount; counter1++){
                                lineageNoFind = lineageSelect [counter1];
                                
                                for (int counter2 = 0; counter2 < holdReviseAreaDataCount/5; counter2++){
                                    if (holdReviseAreaData [counter2*5] == lineageNoFind){
                                        holdReviseAreaData [counter2*5] = 0;
                                    }
                                }
                            }
                            
                            int lineageHoldCount = 0;
                            
                            for (int counter2 = 0; counter2 < holdReviseAreaDataCount/5; counter2++){
                                if (holdReviseAreaData [counter2*5] != 0){
                                    holdReviseAreaData [lineageHoldCount] = holdReviseAreaData [counter2*5], lineageHoldCount++;
                                    holdReviseAreaData [lineageHoldCount] = holdReviseAreaData [counter2*5+1], lineageHoldCount++;
                                    holdReviseAreaData [lineageHoldCount] = holdReviseAreaData [counter2*5+2], lineageHoldCount++;
                                    holdReviseAreaData [lineageHoldCount] = holdReviseAreaData [counter2*5+3], lineageHoldCount++;
                                    holdReviseAreaData [lineageHoldCount] = holdReviseAreaData [counter2*5+4], lineageHoldCount++;
                                }
                            }
                            
                            holdReviseAreaDataCount = lineageHoldCount;
                        }
                        
                        for (int counter1 = 0; counter1 < areaExtractCount/5; counter1++){
                            if (holdReviseAreaDataCount+20 > holdReviseAreaDataLimit){
                                int *arrayUpDate = new int [holdReviseAreaDataCount+10];
                                
                                for (int counter3 = 0; counter3 < holdReviseAreaDataCount; counter3++) arrayUpDate [counter3] = holdReviseAreaData [counter3];
                                
                                delete [] holdReviseAreaData;
                                holdReviseAreaDataLimit = holdReviseAreaDataCount+5000;
                                holdReviseAreaData = new int [holdReviseAreaDataLimit];
                                
                                for (int counter3 = 0; counter3 < holdReviseAreaDataCount; counter3++) holdReviseAreaData [counter3] = arrayUpDate [counter3];
                                delete [] arrayUpDate;
                            }
                            
                            holdReviseAreaData [holdReviseAreaDataCount] = areaExtract [counter1*5], holdReviseAreaDataCount++;
                            holdReviseAreaData [holdReviseAreaDataCount] = areaExtract [counter1*5+1], holdReviseAreaDataCount++;
                            holdReviseAreaData [holdReviseAreaDataCount] = areaExtract [counter1*5+2], holdReviseAreaDataCount++;
                            holdReviseAreaData [holdReviseAreaDataCount] = areaExtract [counter1*5+3], holdReviseAreaDataCount++;
                            holdReviseAreaData [holdReviseAreaDataCount] = areaExtract [counter1*5+4], holdReviseAreaDataCount++;
                        }
                        
                        //for (int counterA = 0; counterA < holdReviseAreaDataCount/5; counterA++){
                        //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<< holdReviseAreaData [counterA*5+counterB];
                        //    cout<<"  holdReviseAreaData "<<counterA<<endl;
                        //}
                        
                        fusionSetFlag = 0;
                        lingNoForFuse1 = -1;
                        cellNoForFuse1 = -1;
                        cellNoCurrent1 = -1;
                        lingNoForFuse2 = -1;
                        cellNoForFuse2 = -1;
                        cellNoCurrent2 = -1;
                        fusionSetCount = 0;
                        lineageModification = 1;
                        clickFlag = 1;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Parent Cell Number Mismatch"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Cells Not Selected"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else if (fusionSetFlag == 1){ //----Cell select click----
            clickFlag = 1;
        }
        
        if (exportFlag1 == 2){
            exportFlag1 = 0;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
            
            if (exportTiming == 0) clickFlag = 1;
        }
        
        if (clickFlag == 1) [self setNeedsDisplay:YES];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)keyDown:(NSEvent *)event{
    int keyCode = [event keyCode];
    int proceedFlag = 0;
    
    if (upLoadingProgress == 0){
        //----Lineage Reverse----
        if (keyCode == 123){
            if (initialArraySet == 1){
                for (int counter1 = lineageDisplayPosition-1; counter1 > 0; counter1--){
                    if (arrayLineageLinkList [counter1*lineageLinkListLength] > 0){
                        lineageDisplayPosition = counter1;
                        proceedFlag = 1;
                        break;
                    }
                }
                
                int extractCount = 0;
                
                int *lineageSelect = new int [lineageLinkListLength+5];
                
                lineageSelect [extractCount] = arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength];
                extractCount++;
                
                for (int counter2 = 1; counter2 < lineageLinkListLength; counter2++){
                    if (arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter2] != 0){
                        lineageSelect [extractCount] = arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter2];
                        extractCount++;
                    }
                }
                
                int lineageNoFind = 0;
                int matchFind = 0;
                
                for (int counter1 = 0; counter1 < extractCount; counter1++){
                    lineageNoFind = lineageSelect [counter1];
                    
                    for (unsigned long counter2 = 0; counter2 < holdReviseLineageCount/9; counter2++){
                        if (holdReviseLineage [counter2*9+6] == lineageNoFind){
                            matchFind = 1;
                        }
                    }
                }
                
                if (matchFind == 1){
                    lineageExtractCount = 0;
                    
                    for (int counter1 = 0; counter1 < extractCount; counter1++){
                        lineageNoFind = lineageSelect [counter1];
                        
                        for (unsigned long counter2 = 0; counter2 < holdReviseLineageCount/9; counter2++){
                            if (holdReviseLineage [counter2*9+6] == lineageNoFind){
                                if (lineageExtractCount+10 > lineageExtractLimit){
                                    int *arrayUpDate = new int [lineageExtractCount+10];
                                    
                                    for (unsigned long counter3 = 0; counter3 < lineageExtractCount; counter3++) arrayUpDate [counter3] = arrayLineageExtract [counter3];
                                    
                                    delete [] arrayLineageExtract;
                                    lineageExtractLimit = lineageExtractCount+(unsigned long)holdReviseLineageCount+5000;
                                    arrayLineageExtract = new int [lineageExtractLimit];
                                    
                                    for (unsigned long counter3 = 0; counter3 < lineageExtractCount; counter3++) arrayLineageExtract [counter3] = arrayUpDate [counter3];
                                    delete [] arrayUpDate;
                                }
                                
                                arrayLineageExtract [lineageExtractCount] = holdReviseLineage [counter2*9], lineageExtractCount++;
                                arrayLineageExtract [lineageExtractCount] = holdReviseLineage [counter2*9+1], lineageExtractCount++;
                                arrayLineageExtract [lineageExtractCount] = holdReviseLineage [counter2*9+2], lineageExtractCount++;
                                arrayLineageExtract [lineageExtractCount] = holdReviseLineage [counter2*9+3], lineageExtractCount++;
                                arrayLineageExtract [lineageExtractCount] = holdReviseLineage [counter2*9+4], lineageExtractCount++;
                                arrayLineageExtract [lineageExtractCount] = holdReviseLineage [counter2*9+5], lineageExtractCount++;
                                arrayLineageExtract [lineageExtractCount] = holdReviseLineage [counter2*9+6], lineageExtractCount++;
                                arrayLineageExtract [lineageExtractCount] = holdReviseLineage [counter2*9+7], lineageExtractCount++;
                                arrayLineageExtract [lineageExtractCount] = holdReviseLineage [counter2*9+8], lineageExtractCount++;
                            }
                        }
                    }
                    
                    ifValueExtractCount = 0;
                    
                    for (int counter1 = 0; counter1 < extractCount; counter1++){
                        lineageNoFind = lineageSelect [counter1];
                        
                        for (int counter2 = 0; counter2 < holdReviseIfDataCount/22; counter2++){
                            if (holdReviseIfData [counter2*22+1] == lineageNoFind){
                                if (ifValueExtractCount+50 > ifValueExtractLimit){
                                    int *arrayUpDate = new int [ifValueExtractCount+20];
                                    
                                    for (int counter3 = 0; counter3 < ifValueExtractCount; counter3++) arrayUpDate [counter3] = ifValueExtract [counter3];
                                    
                                    delete [] ifValueExtract;
                                    ifValueExtractLimit = ifValueExtractCount+5000;
                                    ifValueExtract = new int [ifValueExtractLimit];
                                    
                                    for (int counter3 = 0; counter3 < ifValueExtractCount; counter3++) ifValueExtract [counter3] = arrayUpDate [counter3];
                                    delete [] arrayUpDate;
                                }
                                
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+1], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+2], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+3], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+4], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+5], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+6], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+7], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+8], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+9], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+10], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+11], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+12], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+13], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+14], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+15], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+16], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+17], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+18], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+19], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+20], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+21], ifValueExtractCount++;
                            }
                        }
                    }
                    
                    areaExtractCount = 0;
                    
                    for (int counter1 = 0; counter1 < extractCount; counter1++){
                        lineageNoFind = lineageSelect [counter1];
                        
                        for (int counter2 = 0; counter2 < holdReviseAreaDataCount/5; counter2++){
                            if (holdReviseAreaData [counter2*5] == lineageNoFind){
                                if (areaExtractCount+10 > areaExtractLimit){
                                    int *arrayUpDate = new int [areaExtractCount+10];
                                    
                                    for (int counter3 = 0; counter3 < areaExtractCount; counter3++) arrayUpDate [counter3] = areaExtract [counter3];
                                    
                                    delete [] areaExtract;
                                    areaExtractLimit = areaExtractCount+5000;
                                    areaExtract = new int [areaExtractLimit];
                                    
                                    for (int counter3 = 0; counter3 < areaExtractCount; counter3++) areaExtract [counter3] = arrayUpDate [counter3];
                                    delete [] arrayUpDate;
                                }
                                
                                areaExtract [areaExtractCount] = holdReviseAreaData [counter2*5], areaExtractCount++;
                                areaExtract [areaExtractCount] = holdReviseAreaData [counter2*5+1], areaExtractCount++;
                                areaExtract [areaExtractCount] = holdReviseAreaData [counter2*5+2], areaExtractCount++;
                                areaExtract [areaExtractCount] = holdReviseAreaData [counter2*5+3], areaExtractCount++;
                                areaExtract [areaExtractCount] = holdReviseAreaData [counter2*5+4], areaExtractCount++;
                            }
                        }
                    }
                }
                else{
                    
                    lineageExtractCount = 0;
                    
                    for (int counter1 = 0; counter1 < extractCount; counter1++){
                        lineageNoFind = lineageSelect [counter1];
                        
                        for (unsigned long counter2 = 0; counter2 < arrayLineageDataEntryHold [tableCurrentRowHold]/9; counter2++){
                            if (arrayLineageData [tableCurrentRowHold][counter2*9+6] == lineageNoFind){
                                if (lineageExtractCount+10 > lineageExtractLimit){
                                    int *arrayUpDate = new int [lineageExtractCount+10];
                                    
                                    for (unsigned long counter3 = 0; counter3 < lineageExtractCount; counter3++) arrayUpDate [counter3] = arrayLineageExtract [counter3];
                                    
                                    delete [] arrayLineageExtract;
                                    lineageExtractLimit = lineageExtractCount+arrayLineageDataEntryHold [tableCurrentRowHold]+5000;
                                    arrayLineageExtract = new int [lineageExtractLimit];
                                    
                                    for (unsigned long counter3 = 0; counter3 < lineageExtractCount; counter3++) arrayLineageExtract [counter3] = arrayUpDate [counter3];
                                    delete [] arrayUpDate;
                                }
                                
                                arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9], lineageExtractCount++;
                                arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+1], lineageExtractCount++;
                                arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+2], lineageExtractCount++;
                                arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+3], lineageExtractCount++;
                                arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+4], lineageExtractCount++;
                                arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+5], lineageExtractCount++;
                                arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+6], lineageExtractCount++;
                                arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+7], lineageExtractCount++;
                                arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+8], lineageExtractCount++;
                            }
                        }
                    }
                    
                    //========Load IF data========
                    int ifEntryCount = arrayIFDataEntryHold [tableCurrentRowHold];
                    
                    ifValueExtractCount = 0;
                    
                    for (int counter1 = 0; counter1 < extractCount; counter1++){
                        lineageNoFind = lineageSelect [counter1];
                        
                        for (int counter2 = 0; counter2 < ifEntryCount/22; counter2++){
                            if (arrayIFData [tableCurrentRowHold][counter2*22+1] == lineageNoFind){
                                if (ifValueExtractCount+50 > ifValueExtractLimit){
                                    int *arrayUpDate = new int [ifValueExtractCount+50];
                                    
                                    for (int counter3 = 0; counter3 < ifValueExtractCount; counter3++) arrayUpDate [counter3] = ifValueExtract [counter3];
                                    
                                    delete [] ifValueExtract;
                                    ifValueExtractLimit = ifValueExtractCount+5000;
                                    ifValueExtract = new int [ifValueExtractLimit];
                                    
                                    for (int counter3 = 0; counter3 < ifValueExtractCount; counter3++) ifValueExtract [counter3] = arrayUpDate [counter3];
                                    delete [] arrayUpDate;
                                }
                                
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+1], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+2], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+3], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+4], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+5], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+6], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+7], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+8], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+9], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+10], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+11], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+12], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+13], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+14], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+15], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+16], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+17], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+18], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+19], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+20], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+21], ifValueExtractCount++;
                            }
                        }
                    }
                    
                    //**********arrayAreaData**********
                    int areaEntryCount = arrayAreaDataHold [tableCurrentRowHold];
                    
                    areaExtractCount = 0;
                    
                    for (int counter1 = 0; counter1 < extractCount; counter1++){
                        lineageNoFind = lineageSelect [counter1];
                        
                        for (int counter2 = 0; counter2 < areaEntryCount/5; counter2++){
                            if (arrayAreaData [tableCurrentRowHold][counter2*5] == lineageNoFind){
                                if (areaExtractCount+10 > areaExtractLimit){
                                    int *arrayUpDate = new int [areaExtractCount+10];
                                    
                                    for (int counter3 = 0; counter3 < areaExtractCount; counter3++) arrayUpDate [counter3] = areaExtract [counter3];
                                    
                                    delete [] areaExtract;
                                    areaExtractLimit = areaExtractCount+5000;
                                    areaExtract = new int [areaExtractLimit];
                                    
                                    for (int counter3 = 0; counter3 < areaExtractCount; counter3++) areaExtract [counter3] = arrayUpDate [counter3];
                                    delete [] arrayUpDate;
                                }
                                
                                areaExtract [areaExtractCount] = arrayAreaData [tableCurrentRowHold][counter2*5], areaExtractCount++;
                                areaExtract [areaExtractCount] = arrayAreaData [tableCurrentRowHold][counter2*5+1], areaExtractCount++;
                                areaExtract [areaExtractCount] = arrayAreaData [tableCurrentRowHold][counter2*5+2], areaExtractCount++;
                                areaExtract [areaExtractCount] = arrayAreaData [tableCurrentRowHold][counter2*5+3], areaExtractCount++;
                                areaExtract [areaExtractCount] = arrayAreaData [tableCurrentRowHold][counter2*5+4], areaExtractCount++;
                            }
                        }
                    }
                }
                
                delete [] lineageSelect;
            }
        }
        
        //----Lineage Forward----
        if (keyCode == 124){
            if (initialArraySet == 1){
                for (int counter1 = lineageDisplayPosition+1; counter1 <= maxLingNo; counter1++){
                    if (arrayLineageLinkList [counter1*lineageLinkListLength] > 0){
                        lineageDisplayPosition = counter1;
                        proceedFlag = 1;
                        break;
                    }
                }
                
                int extractCount = 0;
                
                int *lineageSelect = new int [lineageLinkListLength+5];
                
                lineageSelect [extractCount] = arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength];
                extractCount++;
                
                for (int counter2 = 1; counter2 < lineageLinkListLength; counter2++){
                    if (arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter2] != 0){
                        lineageSelect [extractCount] = arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter2];
                        extractCount++;
                    }
                }
                
                int lineageNoFind = 0;
                int matchFind = 0;
                
                for (int counter1 = 0; counter1 < extractCount; counter1++){
                    lineageNoFind = lineageSelect [counter1];
                    
                    for (unsigned long counter2 = 0; counter2 < holdReviseLineageCount/9; counter2++){
                        if (holdReviseLineage [counter2*9+6] == lineageNoFind){
                            matchFind = 1;
                        }
                    }
                }
                
                if (matchFind == 1){
                    lineageExtractCount = 0;
                    
                    for (int counter1 = 0; counter1 < extractCount; counter1++){
                        lineageNoFind = lineageSelect [counter1];
                        
                        for (unsigned long counter2 = 0; counter2 < holdReviseLineageCount/9; counter2++){
                            if (holdReviseLineage [counter2*9+6] == lineageNoFind){
                                if (lineageExtractCount+10 > lineageExtractLimit){
                                    int *arrayUpDate = new int [lineageExtractCount+10];
                                    
                                    for (unsigned long counter3 = 0; counter3 < lineageExtractCount; counter3++) arrayUpDate [counter3] = arrayLineageExtract [counter3];
                                    
                                    delete [] arrayLineageExtract;
                                    lineageExtractLimit = lineageExtractCount+(unsigned long)holdReviseLineageCount+5000;
                                    arrayLineageExtract = new int [lineageExtractLimit];
                                    
                                    for (unsigned long counter3 = 0; counter3 < lineageExtractCount; counter3++) arrayLineageExtract [counter3] = arrayUpDate [counter3];
                                    delete [] arrayUpDate;
                                }
                                
                                arrayLineageExtract [lineageExtractCount] = holdReviseLineage [counter2*9], lineageExtractCount++;
                                arrayLineageExtract [lineageExtractCount] = holdReviseLineage [counter2*9+1], lineageExtractCount++;
                                arrayLineageExtract [lineageExtractCount] = holdReviseLineage [counter2*9+2], lineageExtractCount++;
                                arrayLineageExtract [lineageExtractCount] = holdReviseLineage [counter2*9+3], lineageExtractCount++;
                                arrayLineageExtract [lineageExtractCount] = holdReviseLineage [counter2*9+4], lineageExtractCount++;
                                arrayLineageExtract [lineageExtractCount] = holdReviseLineage [counter2*9+5], lineageExtractCount++;
                                arrayLineageExtract [lineageExtractCount] = holdReviseLineage [counter2*9+6], lineageExtractCount++;
                                arrayLineageExtract [lineageExtractCount] = holdReviseLineage [counter2*9+7], lineageExtractCount++;
                                arrayLineageExtract [lineageExtractCount] = holdReviseLineage [counter2*9+8], lineageExtractCount++;
                            }
                        }
                    }
                    
                    ifValueExtractCount = 0;
                    
                    for (int counter1 = 0; counter1 < extractCount; counter1++){
                        lineageNoFind = lineageSelect [counter1];
                        
                        for (int counter2 = 0; counter2 < holdReviseIfDataCount/22; counter2++){
                            if (holdReviseIfData [counter2*22+1] == lineageNoFind){
                                if (ifValueExtractCount+50 > ifValueExtractLimit){
                                    int *arrayUpDate = new int [ifValueExtractCount+20];
                                    
                                    for (int counter3 = 0; counter3 < ifValueExtractCount; counter3++) arrayUpDate [counter3] = ifValueExtract [counter3];
                                    
                                    delete [] ifValueExtract;
                                    ifValueExtractLimit = ifValueExtractCount+5000;
                                    ifValueExtract = new int [ifValueExtractLimit];
                                    
                                    for (int counter3 = 0; counter3 < ifValueExtractCount; counter3++) ifValueExtract [counter3] = arrayUpDate [counter3];
                                    delete [] arrayUpDate;
                                }
                                
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+1], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+2], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+3], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+4], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+5], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+6], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+7], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+8], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+9], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+10], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+11], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+12], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+13], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+14], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+15], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+16], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+17], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+18], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+19], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+20], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+21], ifValueExtractCount++;
                            }
                        }
                    }
                    
                    areaExtractCount = 0;
                    
                    for (int counter1 = 0; counter1 < extractCount; counter1++){
                        lineageNoFind = lineageSelect [counter1];
                        
                        for (int counter2 = 0; counter2 < holdReviseAreaDataCount/5; counter2++){
                            if (holdReviseAreaData [counter2*5] == lineageNoFind){
                                if (areaExtractCount+10 > areaExtractLimit){
                                    int *arrayUpDate = new int [areaExtractCount+10];
                                    
                                    for (int counter3 = 0; counter3 < areaExtractCount; counter3++) arrayUpDate [counter3] = areaExtract [counter3];
                                    
                                    delete [] areaExtract;
                                    areaExtractLimit = areaExtractCount+5000;
                                    areaExtract = new int [areaExtractLimit];
                                    
                                    for (int counter3 = 0; counter3 < areaExtractCount; counter3++) areaExtract [counter3] = arrayUpDate [counter3];
                                    delete [] arrayUpDate;
                                }
                                
                                areaExtract [areaExtractCount] = holdReviseAreaData [counter2*5], areaExtractCount++;
                                areaExtract [areaExtractCount] = holdReviseAreaData [counter2*5+1], areaExtractCount++;
                                areaExtract [areaExtractCount] = holdReviseAreaData [counter2*5+2], areaExtractCount++;
                                areaExtract [areaExtractCount] = holdReviseAreaData [counter2*5+3], areaExtractCount++;
                                areaExtract [areaExtractCount] = holdReviseAreaData [counter2*5+4], areaExtractCount++;
                            }
                        }
                    }
                }
                else{
                    
                    lineageExtractCount = 0;
                    
                    for (int counter1 = 0; counter1 < extractCount; counter1++){
                        lineageNoFind = lineageSelect [counter1];
                        
                        for (unsigned long counter2 = 0; counter2 < arrayLineageDataEntryHold [tableCurrentRowHold]/9; counter2++){
                            if (arrayLineageData [tableCurrentRowHold][counter2*9+6] == lineageNoFind){
                                if (lineageExtractCount+10 > lineageExtractLimit){
                                    int *arrayUpDate = new int [lineageExtractCount+10];
                                    
                                    for (unsigned long counter3 = 0; counter3 < lineageExtractCount; counter3++) arrayUpDate [counter3] = arrayLineageExtract [counter3];
                                    
                                    delete [] arrayLineageExtract;
                                    lineageExtractLimit = lineageExtractCount+arrayLineageDataEntryHold [tableCurrentRowHold]+5000;
                                    arrayLineageExtract = new int [lineageExtractLimit];
                                    
                                    for (unsigned long counter3 = 0; counter3 < lineageExtractCount; counter3++) arrayLineageExtract [counter3] = arrayUpDate [counter3];
                                    delete [] arrayUpDate;
                                }
                                
                                arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9], lineageExtractCount++;
                                arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+1], lineageExtractCount++;
                                arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+2], lineageExtractCount++;
                                arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+3], lineageExtractCount++;
                                arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+4], lineageExtractCount++;
                                arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+5], lineageExtractCount++;
                                arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+6], lineageExtractCount++;
                                arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+7], lineageExtractCount++;
                                arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+8], lineageExtractCount++;
                            }
                        }
                    }
                    
                    //========Load IF data========
                    int ifEntryCount = arrayIFDataEntryHold [tableCurrentRowHold];
                    
                    ifValueExtractCount = 0;
                    
                    for (int counter1 = 0; counter1 < extractCount; counter1++){
                        lineageNoFind = lineageSelect [counter1];
                        
                        for (int counter2 = 0; counter2 < ifEntryCount/22; counter2++){
                            if (arrayIFData [tableCurrentRowHold][counter2*22+1] == lineageNoFind){
                                if (ifValueExtractCount+50 > ifValueExtractLimit){
                                    int *arrayUpDate = new int [ifValueExtractCount+50];
                                    
                                    for (int counter3 = 0; counter3 < ifValueExtractCount; counter3++) arrayUpDate [counter3] = ifValueExtract [counter3];
                                    
                                    delete [] ifValueExtract;
                                    ifValueExtractLimit = ifValueExtractCount+5000;
                                    ifValueExtract = new int [ifValueExtractLimit];
                                    
                                    for (int counter3 = 0; counter3 < ifValueExtractCount; counter3++) ifValueExtract [counter3] = arrayUpDate [counter3];
                                    delete [] arrayUpDate;
                                }
                                
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+1], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+2], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+3], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+4], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+5], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+6], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+7], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+8], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+9], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+10], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+11], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+12], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+13], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+14], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+15], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+16], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+17], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+18], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+19], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+20], ifValueExtractCount++;
                                ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+21], ifValueExtractCount++;
                            }
                        }
                    }
                    
                    //**********arrayAreaData**********
                    int areaEntryCount = arrayAreaDataHold [tableCurrentRowHold];
                    
                    areaExtractCount = 0;
                    
                    for (int counter1 = 0; counter1 < extractCount; counter1++){
                        lineageNoFind = lineageSelect [counter1];
                        
                        for (int counter2 = 0; counter2 < areaEntryCount/5; counter2++){
                            if (arrayAreaData [tableCurrentRowHold][counter2*5] == lineageNoFind){
                                if (areaExtractCount+10 > areaExtractLimit){
                                    int *arrayUpDate = new int [areaExtractCount+10];
                                    
                                    for (int counter3 = 0; counter3 < areaExtractCount; counter3++) arrayUpDate [counter3] = areaExtract [counter3];
                                    
                                    delete [] areaExtract;
                                    areaExtractLimit = areaExtractCount+5000;
                                    areaExtract = new int [areaExtractLimit];
                                    
                                    for (int counter3 = 0; counter3 < areaExtractCount; counter3++) areaExtract [counter3] = arrayUpDate [counter3];
                                    delete [] arrayUpDate;
                                }
                                
                                areaExtract [areaExtractCount] = arrayAreaData [tableCurrentRowHold][counter2*5], areaExtractCount++;
                                areaExtract [areaExtractCount] = arrayAreaData [tableCurrentRowHold][counter2*5+1], areaExtractCount++;
                                areaExtract [areaExtractCount] = arrayAreaData [tableCurrentRowHold][counter2*5+2], areaExtractCount++;
                                areaExtract [areaExtractCount] = arrayAreaData [tableCurrentRowHold][counter2*5+3], areaExtractCount++;
                                areaExtract [areaExtractCount] = arrayAreaData [tableCurrentRowHold][counter2*5+4], areaExtractCount++;
                            }
                        }
                    }
                }
                
                delete [] lineageSelect;
            }
        }
        
        //----IF Forward----
        if (keyCode == 126){
            if (initialArraySet == 1){
                for (int counter1 = 0; counter1 < ifDataExtractCount/7; counter1++){
                    if (ifDataExtract [counter1*7] > ifCurrentTime){
                        ifCurrentTime = ifDataExtract [counter1*7];
                        proceedFlag = 1;
                        break;
                    }
                }
                
                for (int counter1 = 0; counter1 < ifTimeExtractCount/2; counter1++){
                    if (ifTimeExtract [counter1*2] == ifCurrentTime){
                        includeExcludeFlag = ifTimeExtract [counter1*2+1];
                        break;
                    }
                }
                
                //for (int counterA = 0; counterA < ifDataExtractCount/4; counterA++){
                //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<ifDataExtract [counterA*4+counterB];
                //    cout<<" ifDataExtract "<<counterA<<endl;
                //}
            }
        }
        
        //----IF Reverse----
        if (keyCode == 125){
            for (int counter1 = ifDataExtractCount/7-1; counter1 > 0; counter1--){
                if (ifDataExtract [counter1*7] < ifCurrentTime){
                    ifCurrentTime = ifDataExtract [counter1*7];
                    proceedFlag = 1;
                    break;
                }
            }
            
            for (int counter1 = 0; counter1 < ifTimeExtractCount/2; counter1++){
                if (ifTimeExtract [counter1*2] == ifCurrentTime){
                    includeExcludeFlag = ifTimeExtract [counter1*2+1];
                    break;
                }
            }
        }
        
        if (proceedFlag == 1) [self setNeedsDisplay:YES];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

//----First Responder----
-(BOOL)acceptsFirstResponder{
    return YES;
}

- (void)drawRect:(NSRect)rect{
    if (exportFlag1 == 0){
        [[NSColor whiteColor] set];
        
        NSBezierPath *path;
        path = [NSBezierPath bezierPathWithRect: NSMakeRect(0, 0, 920, 360)];
        [path fill];
        
        [[NSColor blackColor] set];
        
        [NSBezierPath setDefaultLineWidth:2];
        
        path = [NSBezierPath bezierPathWithRect: NSMakeRect(25, 40, 850, 280)];
        [path stroke];
        
        if (initialArraySet == 1){
            //----Horizontal Scale----
            int horizontalTime = arrayTableDetail [tableCurrentRowHold][3];
            string timeInterval = arrayLineageDataType [tableCurrentRowHold][5];
            string timeString = "Time point (x"+timeInterval+" min)";
            NSString *timeNSstring = @(timeString.c_str());
            
            NSFont *font = [NSFont fontWithName:@"Times New Roman" size:12];
            NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
            NSAttributedString *attrStrS = [[NSAttributedString alloc] initWithString:timeNSstring attributes:attributes];
            CGFloat size2 = [attrStrS size].width;
            
            NSPoint pointA;
            NSAttributedString *attrStrA;
            NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
            
            [attributesA setObject:[NSFont boldSystemFontOfSize:12] forKey:NSFontAttributeName];
            [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            
            attrStrA = [[NSAttributedString alloc] initWithString:timeNSstring attributes:attributesA];
            pointA.x = 425-size2/(double)2;
            pointA.y = 6;
            [attrStrA drawAtPoint:pointA];
            
            double lengthDivision = horizontalTime/(double)5;
            int lengthDivisionInt = 0;
            
            if (lengthDivision <= 25) lengthDivisionInt = 25;
            else if (lengthDivision > 25 && lengthDivision <= 50) lengthDivisionInt = 50;
            else if (lengthDivision > 50 && lengthDivision <= 100) lengthDivisionInt = 100;
            else if (lengthDivision > 100 && lengthDivision <= 150) lengthDivisionInt = 100;
            else if (lengthDivision > 150 && lengthDivision <= 200) lengthDivisionInt = 200;
            else if (lengthDivision > 200 && lengthDivision <= 250) lengthDivisionInt = 200;
            else if (lengthDivision > 250 && lengthDivision <= 300) lengthDivisionInt = 300;
            else if (lengthDivision > 300 && lengthDivision <= 350) lengthDivisionInt = 300;
            else if (lengthDivision > 350 && lengthDivision <= 400) lengthDivisionInt = 300;
            else if (lengthDivision > 400 && lengthDivision <= 450) lengthDivisionInt = 400;
            else if (lengthDivision > 450 && lengthDivision <= 550) lengthDivisionInt = 500;
            else if (lengthDivision > 550 && lengthDivision <= 650) lengthDivisionInt = 600;
            else if (lengthDivision > 650 && lengthDivision <= 750) lengthDivisionInt = 700;
            else if (lengthDivision > 750 && lengthDivision <= 850) lengthDivisionInt = 800;
            else if (lengthDivision > 850 && lengthDivision <= 950) lengthDivisionInt = 900;
            else if (lengthDivision > 950 && lengthDivision <= 1050) lengthDivisionInt = 1000;
            else if (lengthDivision > 1050 && lengthDivision <= 1150) lengthDivisionInt = 1100;
            else if (lengthDivision > 1150 && lengthDivision <= 1250) lengthDivisionInt = 1200;
            else if (lengthDivision > 1250 && lengthDivision <= 1350) lengthDivisionInt = 1300;
            else if (lengthDivision > 1350 && lengthDivision <= 1450) lengthDivisionInt = 1400;
            else if (lengthDivision > 1450 && lengthDivision <= 1550) lengthDivisionInt = 1500;
            
            double lengthPix = ((750-40)/(double)horizontalTime)*lengthDivisionInt;
            int numberOfDivision = (int)((750-40)/(double)lengthPix)+1;
            
            NSPoint positionAA;
            NSPoint positionBB;
            
            int sift = 0;
            
            for (int counter1 = 0; counter1 < numberOfDivision; counter1++){
                positionAA.x = 40+lengthPix*counter1;
                positionAA.y = 40;
                positionBB.x = 40+lengthPix*counter1;
                positionBB.y = 50;
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                
                NSString *timeNSstring2 = @(to_string(counter1*lengthDivisionInt).c_str());
                NSDictionary *attributes2 = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                NSAttributedString *attrStrS2 = [[NSAttributedString alloc] initWithString:timeNSstring2 attributes:attributes2];
                size2 = [attrStrS2 size].width;
                
                if (counter1*lengthDivision == 0) sift = 1;
                else if (counter1*lengthDivision < 1000) sift = 2;
                
                NSPoint pointA2;
                NSAttributedString *attrStrA2;
                NSMutableDictionary *attributesA2 = [NSMutableDictionary dictionary];
                
                [attributesA2 setObject:[NSFont boldSystemFontOfSize:12] forKey:NSFontAttributeName];
                [attributesA2 setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                
                attrStrA2 = [[NSAttributedString alloc] initWithString:timeNSstring2 attributes:attributesA];
                pointA2.x = (40+lengthPix*counter1)-size2/(double)2-sift;
                pointA2.y = 25;
                [attrStrA2 drawAtPoint:pointA2];
            }
            
            //----Lineage no----
            double *cellExtractedInfo = new double [lineageExtractCount+50];
            int cellExtractedInfoCount = 0;
            
            double *cellNoList = new double [lineageExtractCount/9*4+50];
            int cellNoListCount = 0;
            
            for (unsigned long counter1 = 0; counter1 < lineageExtractCount/9*3+50; counter1++) cellNoList [counter1] = 0;
            
            for (unsigned long counter1 = 0; counter1 < lineageExtractCount/9; counter1++){
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageExtract [counter1*9], cellExtractedInfoCount++;
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageExtract [counter1*9+1], cellExtractedInfoCount++;
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageExtract [counter1*9+2], cellExtractedInfoCount++;
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageExtract [counter1*9+3], cellExtractedInfoCount++;
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageExtract [counter1*9+4], cellExtractedInfoCount++;
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageExtract [counter1*9+5], cellExtractedInfoCount++;
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageExtract [counter1*9+6], cellExtractedInfoCount++;
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageExtract [counter1*9+7], cellExtractedInfoCount++;
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageExtract [counter1*9+8], cellExtractedInfoCount++;
                
                if (arrayLineageExtract [counter1*9+3] == 1 || arrayLineageExtract [counter1*9+3] == 31 || arrayLineageExtract [counter1*9+3] == 41 || arrayLineageExtract [counter1*9+3] == 51){
                    cellNoList [cellNoListCount] = arrayLineageExtract [counter1*9+5], cellNoListCount++;
                    cellNoList [cellNoListCount] = arrayLineageExtract [counter1*9+4], cellNoListCount++;
                    cellNoList [cellNoListCount] = 0, cellNoListCount++;
                    cellNoList [cellNoListCount] = arrayLineageExtract [counter1*9+6], cellNoListCount++;
                }
            }
            
            //for (int counterA = 0; counterA < lineageExtractCount/9; counterA++){
            //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayLineageExtract [counterA*9+counterB];
            //    cout<<" arrayLineageExtract "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < cellExtractedInfoCount/9; counterA++){
            //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<cellExtractedInfo [counterA*9+counterB];
            //    cout<<" cellExtractedInfo "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < cellNoListCount/4; counterA++){
            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<to_string(cellNoList [counterA*4+counterB]);
            //    cout<<" cellNoList "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < ifValueExtractCount/13; counterA++){
            //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<ifValueExtract [counterA*13+counterB];
            //    cout<<" ifValueExtract "<<counterA<<endl;
            //}
            
            string extensionNoExtract;
            string extensionNoExtract2;
            string extensionNoExtractB;
            int extensionValueSource = 0;
            
            double extensionValue = 0;
            double parentInfo = 0;
            
            for (int counter1 = 0; counter1 < cellNoListCount/4; counter1++){
                if (cellNoList [counter1*4] <= 299999999 && cellNoList [counter1*4] >= -299999999){
                    cellNoList [counter1*4+2] = cellNoList [counter1*4]*1000000;
                    cellNoList [counter1*4+1] = cellNoList [counter1*4+1]*1000000;
                }
                else if (cellNoList [counter1*4] <= 499999999 && cellNoList [counter1*4] >= 300000000 && cellNoList [counter1*4+1] <= 299999999 && cellNoList [counter1*4+1] >= -299999999){
                    extensionNoExtract = to_string(cellNoList [counter1*4]);
                    
                    if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                    
                    extensionNoExtract = extensionNoExtract.substr(6, 3);
                    extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                    extensionNoExtractB = to_string(extensionValueSource)+"000";
                    extensionNoExtract2 = to_string(cellNoList [counter1*4+1]);
                    
                    if ((int)extensionNoExtract2.find(".") != -1) extensionNoExtract2 = extensionNoExtract2.substr(0, extensionNoExtract2.find("."));
                    
                    extensionNoExtract2 = extensionNoExtract2+"000000";
                    extensionValue = atof(extensionNoExtract2.c_str())+atof(extensionNoExtractB.c_str());
                    
                    cellNoList [counter1*4+2] = extensionValue;
                    cellNoList [counter1*4+1] = cellNoList [counter1*4+1]*1000000;
                }
                else if (cellNoList [counter1*4] >= -499999999 && cellNoList [counter1*4] <= -300000000 && cellNoList [counter1*4+1] <= 299999999 && cellNoList [counter1*4+1] >= -299999999){
                    extensionNoExtract = to_string(cellNoList [counter1*4]);
                    
                    if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                    
                    extensionNoExtract = extensionNoExtract.substr(7, 3);
                    extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                    extensionNoExtractB = to_string(extensionValueSource)+"000";
                    extensionNoExtract2 = to_string(cellNoList [counter1*4+1]);
                    
                    if ((int)extensionNoExtract2.find(".") != -1) extensionNoExtract2 = extensionNoExtract2.substr(0, extensionNoExtract2.find("."));
                    
                    extensionNoExtract2 = extensionNoExtract2+"000000";
                    extensionValue = atof(extensionNoExtract2.c_str())+atof(extensionNoExtractB.c_str());
                    
                    cellNoList [counter1*4+2] = extensionValue;
                    cellNoList [counter1*4+1] = cellNoList [counter1*4+1]*1000000;
                }
            }
            
            for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                if (cellNoList [counter2*4] <= 499999999 && cellNoList [counter2*4] >= 300000000 && cellNoList [counter2*4+1] <= 499999999 && cellNoList [counter2*4+1] >= 300000000){
                    extensionNoExtract = to_string(cellNoList [counter2*4]);
                    
                    if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                    
                    extensionNoExtract = extensionNoExtract.substr(6, 3);
                    parentInfo = 0;
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter3*4] == cellNoList [counter2*4+1]){
                            parentInfo = cellNoList [counter3*4+1];
                            break;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter2*4+1] == cellNoList [counter3*4] && cellNoList [counter3*4+1] > 999999999 && cellNoList [counter2*4+3] == cellNoList [counter3*4+3]){
                            extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                            extensionNoExtractB = to_string(extensionValueSource)+"000";
                            
                            extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                            cellNoList [counter2*4+2] = extensionValue;
                            cellNoList [counter2*4+1] = cellNoList [counter3*4+2];
                            break;
                        }
                    }
                }
                else if (cellNoList [counter2*4] >= -499999999 && cellNoList [counter2*4] <= -300000000 && cellNoList [counter2*4+1] >= -499999999 && cellNoList [counter2*4+1] <= -300000000){
                    extensionNoExtract = to_string(cellNoList [counter2*4]);
                    
                    if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                    
                    extensionNoExtract = extensionNoExtract.substr(7, 3);
                    parentInfo = 0;
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter3*4] == cellNoList [counter2*4+1]){
                            parentInfo = cellNoList [counter3*4+1];
                            break;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter2*4+1] == cellNoList [counter3*4] && cellNoList [counter3*4+1] < -999999999 && cellNoList [counter2*4+3] == cellNoList [counter3*4+3]){
                            extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                            extensionNoExtractB = to_string(extensionValueSource)+"000";
                            extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                            cellNoList [counter2*4+2] = extensionValue;
                            cellNoList [counter2*4+1] = cellNoList [counter3*4+2];
                            break;
                        }
                    }
                }
            }
            
            for (int counter1 = 0; counter1 < cellNoListCount/4; counter1++){
                if (cellNoList [counter1*4] <= 699999999 && cellNoList [counter1*4] >= 500000000 && cellNoList [counter1*4+1] <= 499999999 && cellNoList [counter1*4+1] >= 300000000){
                    extensionNoExtract = to_string(cellNoList [counter1*4]);
                    
                    if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                    
                    extensionNoExtract = extensionNoExtract.substr(6, 3);
                    parentInfo = 0;
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter3*4] == cellNoList [counter1*4+1]){
                            parentInfo = cellNoList [counter3*4+1];
                            break;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter1*4+1] == cellNoList [counter3*4] && cellNoList [counter3*4+1] > 999999999 && cellNoList [counter1*4+3] == cellNoList [counter3*4+3]){
                            extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                            extensionNoExtractB = to_string(extensionValueSource);
                            extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                            cellNoList [counter1*4+2] = extensionValue;
                            cellNoList [counter1*4+1] = cellNoList [counter3*4+2];
                            break;
                        }
                    }
                }
                else if (cellNoList [counter1*4] >= -699999999 && cellNoList [counter1*4] <= -500000000 && cellNoList [counter1*4+1] >= -499999999 && cellNoList [counter1*4+1] <= -300000000){
                    extensionNoExtract = to_string(cellNoList [counter1*4]);
                    
                    if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                    
                    extensionNoExtract = extensionNoExtract.substr(7, 3);
                    parentInfo = 0;
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter3*4] == cellNoList [counter1*4+1]){
                            parentInfo = cellNoList [counter3*4+1];
                            break;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter1*4+1] == cellNoList [counter3*4] && cellNoList [counter3*4+1] < -999999999 && cellNoList [counter1*4+3] == cellNoList [counter3*4+3]){
                            extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                            extensionNoExtractB = to_string(extensionValueSource);
                            extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                            cellNoList [counter1*4+2] = extensionValue;
                            cellNoList [counter1*4+1] = cellNoList [counter3*4+2];
                            break;
                        }
                    }
                }
            }
            
            for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                if (cellNoList [counter2*4] <= 699999999 && cellNoList [counter2*4] >= 500000000 && cellNoList [counter2*4+1] <= 699999999 && cellNoList [counter2*4+1] >= 500000000){
                    extensionNoExtract = to_string(cellNoList [counter2*4]);
                    
                    if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                    
                    extensionNoExtract = extensionNoExtract.substr(6, 3);
                    parentInfo = 0;
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter3*4] == cellNoList [counter2*4+1]){
                            parentInfo = cellNoList [counter3*4+1];
                            break;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter2*4+1] == cellNoList [counter3*4] && cellNoList [counter3*4+1] > 999999999 && cellNoList [counter2*4+3] == cellNoList [counter3*4+3]){
                            extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                            extensionNoExtractB = to_string(extensionValueSource);
                            extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                            cellNoList [counter2*4+2] = extensionValue;
                            cellNoList [counter2*4+1] = cellNoList [counter3*4+2];
                            break;
                        }
                    }
                }
                else if (cellNoList [counter2*4] >= -699999999 && cellNoList [counter2*4] <= -500000000 && cellNoList [counter2*4+1] >= -699999999 && cellNoList [counter2*4+1] <= -500000000){
                    extensionNoExtract = to_string(cellNoList [counter2*4]);
                    
                    if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                    
                    extensionNoExtract = extensionNoExtract.substr(7, 3);
                    parentInfo = 0;
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter3*4] == cellNoList [counter2*4+1]){
                            parentInfo = cellNoList [counter3*4+1];
                            break;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter2*4+1] == cellNoList [counter3*4] && cellNoList [counter3*4+1] < -999999999 && cellNoList [counter2*4+3] == cellNoList [counter3*4+3]){
                            extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                            extensionNoExtractB = to_string(extensionValueSource);
                            extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                            cellNoList [counter2*4+2] = extensionValue;
                            cellNoList [counter2*4+1] = cellNoList [counter3*4+2];
                            break;
                        }
                    }
                }
            }
            
            int findBoth = 0;
            double cellNoEntry1 = 0;
            double cellNoEntry2 = 0;
            double cellNoSummary = 0;
            double lingNoSummary = 0;
            
            for (int counter1 = 0; counter1 < cellExtractedInfoCount/9; counter1++){
                if (cellNoSummary != cellExtractedInfo [counter1*9+5] || lingNoSummary != cellExtractedInfo [counter1*9+6]){
                    cellNoSummary = cellExtractedInfo [counter1*9+5];
                    lingNoSummary = cellExtractedInfo [counter1*9+6];
                    
                    findBoth = 0;
                    cellNoEntry1 = 0;
                    cellNoEntry2 = 0;
                    
                    for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                        if (cellExtractedInfo [counter1*9+5] == cellNoList [counter2*4] && cellExtractedInfo [counter1*9+6] == cellNoList [counter2*4+3]){
                            cellNoEntry1 = cellNoList [counter2*4+2];
                            findBoth++;
                        }
                        
                        if (cellExtractedInfo [counter1*9+4] == cellNoList [counter2*4] && cellExtractedInfo [counter1*9+6] == cellNoList [counter2*4+3]){
                            cellNoEntry2 = cellNoList [counter2*4+2];
                            findBoth++;
                        }
                        
                        if (findBoth == 2){
                            break;
                        }
                    }
                    
                    cellExtractedInfo [counter1*9+5] = cellNoEntry1;
                    cellExtractedInfo [counter1*9+4] = cellNoEntry2;
                }
                else cellExtractedInfo [counter1*9+5] = cellNoEntry1;
                
                if (cellExtractedInfo [counter1*9+3] == 91 || cellExtractedInfo [counter1*9+3] == 92){
                    for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                        if (cellExtractedInfo [counter1*9+4] == cellNoList [counter2*4]){
                            cellExtractedInfo [counter1*9+4] = cellNoList [counter2*4+2];
                            break;
                        }
                    }
                }
            }
            
            //for (int counterA = 0; counterA < cellExtractedInfoCount/9; counterA++){
            //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<cellExtractedInfo [counterA*9+counterB];
            //    cout<<" cellExtractedInfo "<<counterA<<endl;
            //}
            
            double *cellExtractedInfoSummary = new double [cellExtractedInfoCount+50];
            int cellExtractedInfoSummaryCount = 0;
            
            cellNoSummary = 0;
            lingNoSummary = 0;
            
            for (int counter1 = 0; counter1 < cellExtractedInfoCount/9; counter1++){
                if (cellExtractedInfo [counter1*9+3] != 2){
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+1], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+2], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+3], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+4], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+5], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+6], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+7], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+8], cellExtractedInfoSummaryCount++;
                }
                
                if (cellNoSummary != cellExtractedInfo [counter1*9+5] || lingNoSummary != cellExtractedInfo [counter1*9+6]){
                    cellNoSummary = cellExtractedInfo [counter1*9+5];
                    lingNoSummary = cellExtractedInfo [counter1*9+6];
                    
                    if (counter1 != 0 && cellExtractedInfo [(counter1-1)*9+3] == 2){
                        cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [(counter1-1)*9], cellExtractedInfoSummaryCount++;
                        cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [(counter1-1)*9+1], cellExtractedInfoSummaryCount++;
                        cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [(counter1-1)*9+2], cellExtractedInfoSummaryCount++;
                        cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [(counter1-1)*9+3], cellExtractedInfoSummaryCount++;
                        cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [(counter1-1)*9+4], cellExtractedInfoSummaryCount++;
                        cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [(counter1-1)*9+5], cellExtractedInfoSummaryCount++;
                        cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [(counter1-1)*9+6], cellExtractedInfoSummaryCount++;
                        cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [(counter1-1)*9+7], cellExtractedInfoSummaryCount++;
                        cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [(counter1-1)*9+8], cellExtractedInfoSummaryCount++;
                    }
                }
                
                if (counter1 == cellExtractedInfoCount/9-1 && cellExtractedInfoCount/9-1 != 0){
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+1], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+2], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+3], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+4], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+5], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+6], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+7], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+8], cellExtractedInfoSummaryCount++;
                }
            }
            
            int lineageFuseNo = 0;
            
            for (int counter1 = 0; counter1 < lineageLinkListLength; counter1++){
                if (arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1] != 0){
                    lineageFuseNo++;
                }
            }
            
            if (lineageFuseNo <= 3){
                string lineageNo = to_string(arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength]);
                
                for (int counter1 = 1; counter1 < lineageLinkListLength; counter1++){
                    if (arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1] != 0){
                        lineageNo = lineageNo+", "+to_string(arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1]);
                    }
                }
                
                lineageNo = "Lineage: "+lineageNo;
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(lineageNo.c_str()) attributes:attributesA];
                pointA.x = 30;
                pointA.y = 330;
                [attrStrA drawAtPoint:pointA];
            }
            else if (lineageFuseNo > 3 && lineageFuseNo <= 6){
                string lineageNo = "Lineage:";
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(lineageNo.c_str()) attributes:attributesA];
                pointA.x = 30;
                pointA.y = 330;
                [attrStrA drawAtPoint:pointA];
                
                lineageNo = to_string(arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength]);
                
                for (int counter1 = 1; counter1 < 3; counter1++){
                    if (arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1] != 0){
                        lineageNo = lineageNo+", "+to_string(arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1]);
                    }
                }
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(lineageNo.c_str()) attributes:attributesA];
                pointA.x = 85;
                pointA.y = 337;
                [attrStrA drawAtPoint:pointA];
                
                lineageNo = to_string(arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+3]);
                
                for (int counter1 = 4; counter1 < lineageLinkListLength; counter1++){
                    if (arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1] != 0){
                        lineageNo = lineageNo+", "+to_string(arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1]);
                    }
                }
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(lineageNo.c_str()) attributes:attributesA];
                pointA.x = 85;
                pointA.y = 323;
                [attrStrA drawAtPoint:pointA];
            }
            else if (lineageFuseNo > 6){
                string lineageNo = "";
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(lineageNo.c_str()) attributes:attributesA];
                pointA.x = 30;
                pointA.y = 330;
                [attrStrA drawAtPoint:pointA];
                
                lineageNo = to_string(arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength]);
                
                for (int counter1 = 1; counter1 < 3; counter1++){
                    if (arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1] != 0){
                        lineageNo = lineageNo+", "+to_string(arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1]);
                    }
                }
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(lineageNo.c_str()) attributes:attributesA];
                pointA.x = 85;
                pointA.y = 337;
                [attrStrA drawAtPoint:pointA];
                
                lineageNo = to_string(arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+3]);
                
                for (int counter1 = 4; counter1 < 6; counter1++){
                    if (arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1] != 0){
                        lineageNo = lineageNo+", "+to_string(arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1]);
                    }
                }
                
                lineageNo = lineageNo+"+";
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(lineageNo.c_str()) attributes:attributesA];
                pointA.x = 85;
                pointA.y = 323;
                [attrStrA drawAtPoint:pointA];
            }
            
            //----Doubling time Calculation----
            int shortestDoublingTime = 1000000;
            int longestDoublingTime = 0;
            int meanDoublingTime = 0;
            int numberOfDoubling = 0;
            int timeTemp = 0;
            
            for (int counter1 = 0; counter1 < cellExtractedInfoSummaryCount/9; counter1++){
                if (cellExtractedInfoSummary [counter1*9+3] == 31 || cellExtractedInfoSummary [counter1*9+3] == 41 || cellExtractedInfoSummary [counter1*9+3] == 51){
                    timeTemp = (int)(cellExtractedInfoSummary [counter1*9+2]);
                    
                    for (int counter2 = 0; counter2 < cellExtractedInfoSummaryCount/9; counter2++){
                        if (cellExtractedInfoSummary [counter2*9+5] == cellExtractedInfoSummary [counter1*9+5] && cellExtractedInfoSummary [counter2*9+6] == cellExtractedInfoSummary [counter1*9+6] && (cellExtractedInfoSummary [counter2*9+3] == 32 || cellExtractedInfoSummary [counter2*9+3] == 42 || cellExtractedInfoSummary [counter2*9+3] == 52)){
                            if (cellExtractedInfoSummary[counter2*9+2]-timeTemp < shortestDoublingTime) shortestDoublingTime = (int)(cellExtractedInfoSummary [counter2*9+2]-timeTemp);
                            if (cellExtractedInfoSummary [counter2*9+2]-timeTemp > longestDoublingTime) longestDoublingTime = (int)(cellExtractedInfoSummary [counter2*9+2]-timeTemp);
                            meanDoublingTime = meanDoublingTime+(int)(cellExtractedInfoSummary [counter2*9+2]-timeTemp);
                            
                            numberOfDoubling++;
                            break;
                        }
                    }
                }
            }
            
            double shortestDoublingTimeDouble = 0;
            double longestDoublingTimeDouble = 0;
            double meanDoublingTimeDouble = 0;
            
            if (shortestDoublingTime == 1000000) shortestDoublingTime = 0;
            
            if (meanDoublingTime != 0) meanDoublingTimeDouble = meanDoublingTime/(double)numberOfDoubling;
            
            shortestDoublingTimeDouble = shortestDoublingTime*atoi(timeInterval.c_str())/(double)60;
            shortestDoublingTime = (int)(shortestDoublingTimeDouble*100);
            shortestDoublingTimeDouble = shortestDoublingTime/(double)100;
            
            longestDoublingTimeDouble = longestDoublingTime*atoi(timeInterval.c_str())/(double)60;
            longestDoublingTime = (int)(longestDoublingTimeDouble*100);
            longestDoublingTimeDouble = longestDoublingTime/(double)100;
            
            meanDoublingTimeDouble = meanDoublingTimeDouble*atoi(timeInterval.c_str())/(double)60;
            meanDoublingTime = (int)(meanDoublingTimeDouble*100);
            meanDoublingTimeDouble = meanDoublingTime/(double)100;
            
            stringstream extension1;
            extension1 << shortestDoublingTimeDouble;
            string shortestString = extension1.str();
            
            stringstream extension2;
            extension2 << longestDoublingTimeDouble;
            string longestString = extension2.str();
            
            stringstream extension3;
            extension3 << meanDoublingTimeDouble;
            string meanString = extension3.str();
            
            string doubling = "Doub. M: "+meanString;
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(doubling.c_str()) attributes:attributesA];
            pointA.x = 200;
            pointA.y = 323;
            [attrStrA drawAtPoint:pointA];
            
            if (longestString == "0") doubling = "Doub. T : 0";
            else doubling = "Doub. T : "+shortestString+"-"+longestString;
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(doubling.c_str()) attributes:attributesA];
            pointA.x = 200;
            pointA.y = 337;
            [attrStrA drawAtPoint:pointA];
            
            //----Live IF Data set----
            string liveString;
            
            if (liveCurrentCHNo == 0) liveString = "Live: N";
            else if (liveCurrentCHNo == 1) liveString = "Live: 1";
            else if (liveCurrentCHNo == 2) liveString = "Live: 2";
            else if (liveCurrentCHNo == 3) liveString = "Live: 3";
            else if (liveCurrentCHNo == 4) liveString = "Live: 4";
            else if (liveCurrentCHNo == 5) liveString = "Live: 5";
            else if (liveCurrentCHNo == 6) liveString = "Live: 6";
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(liveString.c_str()) attributes:attributesA];
            pointA.x = 360;
            pointA.y = 330;
            [attrStrA drawAtPoint:pointA];
            
            [[NSColor darkGrayColor] set];
            [NSBezierPath setDefaultLineWidth:2];
            
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(410, 330, 13, 13)];
            [path fill];
            
            if (ifDataExtract [1] == 0) [[NSColor grayColor] set];
            else if (ifDataExtract [1] == 1) [[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1] set];
            else if (ifDataExtract [1] == 2) [[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1] set];
            else if (ifDataExtract [1] == 3) [[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1] set];
            else if (ifDataExtract [1] == 4) [[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1] set];
            else if (ifDataExtract [1] == 5) [[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1] set];
            else if (ifDataExtract [1] == 6) [[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1] set];
            else if (ifDataExtract [1] == 7) [[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1] set];
            else if (ifDataExtract [1] == 8) [[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1] set];
            else if (ifDataExtract [1] == 9) [[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1] set];
            
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(424, 330, 13, 13)];
            [path fill];
            
            if (ifDataExtract [2] == 0) [[NSColor grayColor] set];
            else if (ifDataExtract [2] == 1) [[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1] set];
            else if (ifDataExtract [2] == 2) [[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1] set];
            else if (ifDataExtract [2] == 3) [[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1] set];
            else if (ifDataExtract [2] == 4) [[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1] set];
            else if (ifDataExtract [2] == 5) [[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1] set];
            else if (ifDataExtract [2] == 6) [[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1] set];
            else if (ifDataExtract [2] == 7) [[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1] set];
            else if (ifDataExtract [2] == 8) [[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1] set];
            else if (ifDataExtract [2] == 9) [[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1] set];
            
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(438, 330, 13, 13)];
            [path fill];
            
            if (ifDataExtract [3] == 0) [[NSColor grayColor] set];
            else if (ifDataExtract [3] == 1) [[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1] set];
            else if (ifDataExtract [3] == 2) [[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1] set];
            else if (ifDataExtract [3] == 3) [[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1] set];
            else if (ifDataExtract [3] == 4) [[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1] set];
            else if (ifDataExtract [3] == 5) [[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1] set];
            else if (ifDataExtract [3] == 6) [[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1] set];
            else if (ifDataExtract [3] == 7) [[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1] set];
            else if (ifDataExtract [3] == 8) [[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1] set];
            else if (ifDataExtract [3] == 9) [[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1] set];
            
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(452, 330, 13, 13)];
            [path fill];
            
            if (ifDataExtract [4] == 0) [[NSColor grayColor] set];
            else if (ifDataExtract [4] == 1) [[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1] set];
            else if (ifDataExtract [4] == 2) [[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1] set];
            else if (ifDataExtract [4] == 3) [[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1] set];
            else if (ifDataExtract [4] == 4) [[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1] set];
            else if (ifDataExtract [4] == 5) [[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1] set];
            else if (ifDataExtract [4] == 6) [[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1] set];
            else if (ifDataExtract [4] == 7) [[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1] set];
            else if (ifDataExtract [4] == 8) [[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1] set];
            else if (ifDataExtract [4] == 9) [[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1] set];
            
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(466, 330, 13, 13)];
            [path fill];
            
            if (ifDataExtract [5] == 0) [[NSColor grayColor] set];
            else if (ifDataExtract [5] == 1) [[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1] set];
            else if (ifDataExtract [5] == 2) [[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1] set];
            else if (ifDataExtract [5] == 3) [[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1] set];
            else if (ifDataExtract [5] == 4) [[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1] set];
            else if (ifDataExtract [5] == 5) [[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1] set];
            else if (ifDataExtract [5] == 6) [[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1] set];
            else if (ifDataExtract [5] == 7) [[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1] set];
            else if (ifDataExtract [5] == 8) [[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1] set];
            else if (ifDataExtract [5] == 9) [[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1] set];
            
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(480, 330, 13, 13)];
            [path fill];
            
            if (ifDataExtract [6] == 0) [[NSColor grayColor] set];
            else if (ifDataExtract [6] == 1) [[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1] set];
            else if (ifDataExtract [6] == 2) [[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1] set];
            else if (ifDataExtract [6] == 3) [[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1] set];
            else if (ifDataExtract [6] == 4) [[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1] set];
            else if (ifDataExtract [6] == 5) [[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1] set];
            else if (ifDataExtract [6] == 6) [[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1] set];
            else if (ifDataExtract [6] == 7) [[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1] set];
            else if (ifDataExtract [6] == 8) [[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1] set];
            else if (ifDataExtract [6] == 9) [[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1] set];
            
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(494, 330, 13, 13)];
            [path fill];
            
            //for (int counterA = 0; counterA < ifDataExtractCount/7; counterA++){
            //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<ifDataExtract [counterA*7+counterB];
            //    cout<<" ifDataExtract "<<counterA<<endl;
            //}
            
            //----IF data entry----
            string ifString;
            
            if (ifDataExtractCount > 7 && ifCurrentTime == 0){
                ifCurrentTime = ifDataExtract [7];
                ifCurrentCHNo = 1;
            }
            
            if (ifDataExtractCount > 7 && ifCurrentTime != 0){
                if (ifCurrentCHNo == 1){
                    if (to_string(ifCurrentTime).length() == 1) ifString = "IF T000"+to_string(ifCurrentTime)+": 1";
                    else if (to_string(ifCurrentTime).length() == 2) ifString = "IF T00"+to_string(ifCurrentTime)+": 1";
                    else if (to_string(ifCurrentTime).length() == 3) ifString = "IF T0"+to_string(ifCurrentTime)+": 1";
                    else if (to_string(ifCurrentTime).length() == 4) ifString = "IF T"+to_string(ifCurrentTime)+": 1";
                }
                else if (ifCurrentCHNo == 2){
                    if (to_string(ifCurrentTime).length() == 1) ifString = "IF T000"+to_string(ifCurrentTime)+": 2";
                    else if (to_string(ifCurrentTime).length() == 2) ifString = "IF T00"+to_string(ifCurrentTime)+": 2";
                    else if (to_string(ifCurrentTime).length() == 3) ifString = "IF T0"+to_string(ifCurrentTime)+": 2";
                    else if (to_string(ifCurrentTime).length() == 4) ifString = "IF T"+to_string(ifCurrentTime)+": 2";
                }
                else if (ifCurrentCHNo == 3){
                    if (to_string(ifCurrentTime).length() == 1) ifString = "IF T000"+to_string(ifCurrentTime)+": 3";
                    else if (to_string(ifCurrentTime).length() == 2) ifString = "IF T00"+to_string(ifCurrentTime)+": 3";
                    else if (to_string(ifCurrentTime).length() == 3) ifString = "IF T0"+to_string(ifCurrentTime)+": 3";
                    else if (to_string(ifCurrentTime).length() == 4) ifString = "IF T"+to_string(ifCurrentTime)+": 3";
                }
                else if (ifCurrentCHNo == 4){
                    if (to_string(ifCurrentTime).length() == 1) ifString = "IF T000"+to_string(ifCurrentTime)+": 4";
                    else if (to_string(ifCurrentTime).length() == 2) ifString = "IF T00"+to_string(ifCurrentTime)+": 4";
                    else if (to_string(ifCurrentTime).length() == 3) ifString = "IF T0"+to_string(ifCurrentTime)+": 4";
                    else if (to_string(ifCurrentTime).length() == 4) ifString = "IF T"+to_string(ifCurrentTime)+": 4";
                }
                else if (ifCurrentCHNo == 5){
                    if (to_string(ifCurrentTime).length() == 1) ifString = "IF T000"+to_string(ifCurrentTime)+": 5";
                    else if (to_string(ifCurrentTime).length() == 2) ifString = "IF T00"+to_string(ifCurrentTime)+": 5";
                    else if (to_string(ifCurrentTime).length() == 3) ifString = "IF T0"+to_string(ifCurrentTime)+": 5";
                    else if (to_string(ifCurrentTime).length() == 4) ifString = "IF T"+to_string(ifCurrentTime)+": 5";
                }
                else if (ifCurrentCHNo == 6){
                    if (to_string(ifCurrentTime).length() == 1) ifString = "IF T000"+to_string(ifCurrentTime)+": 6";
                    else if (to_string(ifCurrentTime).length() == 2) ifString = "IF T00"+to_string(ifCurrentTime)+": 6";
                    else if (to_string(ifCurrentTime).length() == 3) ifString = "IF T0"+to_string(ifCurrentTime)+": 6";
                    else if (to_string(ifCurrentTime).length() == 4) ifString = "IF T"+to_string(ifCurrentTime)+": 6";
                }
            }
            else ifString = "IF T0000: N";
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(ifString.c_str()) attributes:attributesA];
            pointA.x = 515;
            pointA.y = 330;
            [attrStrA drawAtPoint:pointA];
            
            int entryPosition = 0;
            
            for (int counter2 = 1; counter2 < ifDataExtractCount/7; counter2++){
                if (ifDataExtract [counter2*7] == ifCurrentTime){
                    entryPosition = counter2;
                    break;
                }
            }
            
            if (entryPosition != 0){
                if (ifDataExtract [entryPosition*7+1] == 0) [[NSColor grayColor] set];
                else if (ifDataExtract [entryPosition*7+1] == 1) [[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+1] == 2) [[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+1] == 3) [[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+1] == 4) [[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+1] == 5) [[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+1] == 6) [[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+1] == 7) [[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+1] == 8) [[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+1] == 9) [[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1] set];
            }
            else [[NSColor grayColor] set];
            
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(592, 330, 13, 13)];
            [path fill];
            
            if (entryPosition != 0){
                if (ifDataExtract [entryPosition*7+2] == 0) [[NSColor grayColor] set];
                else if (ifDataExtract [entryPosition*7+2] == 1) [[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+2] == 2) [[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+2] == 3) [[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+2] == 4) [[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+2] == 5) [[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+2] == 6) [[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+2] == 7) [[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+2] == 8) [[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+2] == 9) [[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1] set];
            }
            else [[NSColor grayColor] set];
            
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(606, 330, 13, 13)];
            [path fill];
            
            if (entryPosition != 0){
                if (ifDataExtract [entryPosition*7+3] == 0) [[NSColor grayColor] set];
                else if (ifDataExtract [entryPosition*7+3] == 1) [[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+3] == 2) [[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+3] == 3) [[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+3] == 4) [[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+3] == 5) [[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+3] == 6) [[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+3] == 7) [[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+3] == 8) [[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+3] == 9) [[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1] set];
            }
            else [[NSColor grayColor] set];
            
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(620, 330, 13, 13)];
            [path fill];
            
            if (entryPosition != 0){
                if (ifDataExtract [entryPosition*7+4] == 0) [[NSColor grayColor] set];
                else if (ifDataExtract [entryPosition*7+4] == 1) [[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+4] == 2) [[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+4] == 3) [[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+4] == 4) [[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+4] == 5) [[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+4] == 6) [[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+4] == 7) [[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+4] == 8) [[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+4] == 9) [[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1] set];
            }
            else [[NSColor grayColor] set];
            
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(634, 330, 13, 13)];
            [path fill];
            
            if (entryPosition != 0){
                if (ifDataExtract [entryPosition*7+5] == 0) [[NSColor grayColor] set];
                else if (ifDataExtract [entryPosition*7+5] == 1) [[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+5] == 2) [[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+5] == 3) [[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+5] == 4) [[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+5] == 5) [[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+5] == 6) [[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+5] == 7) [[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+5] == 8) [[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+5] == 9) [[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1] set];
            }
            else [[NSColor grayColor] set];
            
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(648, 330, 13, 13)];
            [path fill];
            
            if (entryPosition != 0){
                if (ifDataExtract [entryPosition*7+6] == 0) [[NSColor grayColor] set];
                else if (ifDataExtract [entryPosition*7+6] == 1) [[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+6] == 2) [[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+6] == 3) [[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+6] == 4) [[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+6] == 5) [[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+6] == 6) [[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+6] == 7) [[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+6] == 8) [[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1] set];
                else if (ifDataExtract [entryPosition*7+6] == 9) [[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1] set];
            }
            else [[NSColor grayColor] set];
            
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(662, 330, 13, 13)];
            [path fill];
            
            //----Include----
            [NSBezierPath setDefaultLineWidth:1];
            
            [[NSColor blueColor] set];
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(684, 330, 35, 14)];
            [path stroke];
            
            ifString = "Inc.";
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(ifString.c_str()) attributes:attributesA];
            pointA.x = 691;
            pointA.y = 330;
            [attrStrA drawAtPoint:pointA];
            
            //----Exclude----
            [[NSColor grayColor] set];
            
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(723, 330, 35, 14)];
            [path stroke];
            
            ifString = "Exc.";
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(ifString.c_str()) attributes:attributesA];
            pointA.x = 729;
            pointA.y = 330;
            [attrStrA drawAtPoint:pointA];
            
            //----Fusion Select and Flip----
            [[NSColor orangeColor] set];
            [NSBezierPath setDefaultLineWidth:1];
            
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(765, 330, 20, 14)];
            [path stroke];
            
            ifString = "S";
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(ifString.c_str()) attributes:attributesA];
            pointA.x = 771;
            pointA.y = 330;
            [attrStrA drawAtPoint:pointA];
            
            [[NSColor orangeColor] set];
            [NSBezierPath setDefaultLineWidth:1];
            
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(788, 330, 20, 14)];
            [path stroke];
            
            ifString = "C";
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(ifString.c_str()) attributes:attributesA];
            pointA.x = 794;
            pointA.y = 330;
            [attrStrA drawAtPoint:pointA];
            
            [[NSColor orangeColor] set];
            [NSBezierPath setDefaultLineWidth:1];
            
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(811, 330, 20, 14)];
            [path stroke];
            
            ifString = "F";
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(ifString.c_str()) attributes:attributesA];
            pointA.x = 817;
            pointA.y = 330;
            [attrStrA drawAtPoint:pointA];
            
            [[NSColor orangeColor] set];
            [NSBezierPath setDefaultLineWidth:1];
            
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(833, 330, 20, 14)];
            [path stroke];
            
            ifString = "R";
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(ifString.c_str()) attributes:attributesA];
            pointA.x = 839;
            pointA.y = 330;
            [attrStrA drawAtPoint:pointA];
            
            [[NSColor magentaColor] set];
            [NSBezierPath setDefaultLineWidth:1];
            
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(880, 330, 20, 14)];
            [path stroke];
            
            if (averageTotalFlag == 0) ifString = "A";
            else if (averageTotalFlag == 1) ifString = "T";
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(ifString.c_str()) attributes:attributesA];
            pointA.x = 886;
            pointA.y = 330;
            [attrStrA drawAtPoint:pointA];
            
            [[NSColor blueColor] set];
            [NSBezierPath setDefaultLineWidth:1];
            
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(880, 240, 20, 14)];
            [path stroke];
            
            if (blueLineFlag == 0) ifString = "B";
            else if (blueLineFlag == 1) ifString = "N";
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(ifString.c_str()) attributes:attributesA];
            pointA.x = 886;
            pointA.y = 240;
            [attrStrA drawAtPoint:pointA];
            
            [[NSColor blueColor] set];
            [NSBezierPath setDefaultLineWidth:1];
            
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(880, 220, 20, 14)];
            [path stroke];
            
            if (lineWidthFlag == 0) ifString = "L1";
            else if (lineWidthFlag == 1) ifString = "L2";
            else if (lineWidthFlag == 2) ifString = "L3";
            else if (lineWidthFlag == 3) ifString = "L4";
            else if (lineWidthFlag == 4) ifString = "L5";
            else if (lineWidthFlag == 5) ifString = "L6";
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(ifString.c_str()) attributes:attributesA];
            pointA.x = 883;
            pointA.y = 220;
            [attrStrA drawAtPoint:pointA];
            
            [[NSColor blueColor] set];
            [NSBezierPath setDefaultLineWidth:1];
            
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(880, 200, 20, 14)];
            [path stroke];
            
            if (cellNumberFlag == 0) ifString = "C1";
            else if (cellNumberFlag == 1) ifString = "C0";
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(ifString.c_str()) attributes:attributesA];
            pointA.x = 882;
            pointA.y = 200;
            [attrStrA drawAtPoint:pointA];
            
            [[NSColor blueColor] set];
            [NSBezierPath setDefaultLineWidth:1];
            
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(880, 180, 20, 14)];
            [path stroke];
            
            if (endNumberFlag == 0) ifString = "E1";
            else if (endNumberFlag == 1) ifString = "E0";
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(ifString.c_str()) attributes:attributesA];
            pointA.x = 883;
            pointA.y = 180;
            [attrStrA drawAtPoint:pointA];
            
            [[NSColor blueColor] set];
            [NSBezierPath setDefaultLineWidth:1];
            
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(880, 160, 20, 14)];
            [path stroke];
            
            if (markSizeFlag == 0) ifString = "M1";
            else if (markSizeFlag == 1) ifString = "M2";
            else if (markSizeFlag == 2) ifString = "M0";
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(ifString.c_str()) attributes:attributesA];
            pointA.x = 881;
            pointA.y = 160;
            [attrStrA drawAtPoint:pointA];
            
            //for (int counterA = 0; counterA < ifTimeExtractCount/2; counterA++){
            //    for (int counterB = 0; counterB < 2; counterB++) cout<<" "<<ifTimeExtract [counterA*2+counterB];
            //    cout<<" iifTimeExtract "<<counterA<<endl;
            //}
            
            //----IF Time point----
            [attributesA setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            
            string ifTimePoint1;
            
            if (to_string(ifCurrentTime).length() == 1) ifTimePoint1 = "000"+to_string(ifCurrentTime);
            else if (to_string(ifCurrentTime).length() == 2) ifTimePoint1 = "00"+to_string(ifCurrentTime);
            else if (to_string(ifCurrentTime).length() == 3) ifTimePoint1 = "0"+to_string(ifCurrentTime);
            else if (to_string(ifCurrentTime).length() == 4) ifTimePoint1 = to_string(ifCurrentTime);
            
            if (includeExcludeFlag == 0) [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            else [attributesA setObject:[NSColor grayColor] forKey: NSForegroundColorAttributeName];
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(ifTimePoint1.c_str()) attributes:attributesA];
            pointA.x = 825;
            pointA.y = 305;
            [attrStrA drawAtPoint:pointA];
            
            //----IF Time point Range----
            if (ifDataExtractCount > 14){
                int timeStart = ifDataExtract [7];
                int timeEnd = 0;
                
                for (int counter2 = 1; counter2 < ifDataExtractCount/7; counter2++){
                    timeEnd = ifDataExtract [counter2*7];
                }
                
                if (to_string(timeStart).length() == 1) ifTimePoint1 = "000"+to_string(timeStart);
                else if (to_string(timeStart).length() == 2) ifTimePoint1 = "00"+to_string(timeStart);
                else if (to_string(timeStart).length() == 3) ifTimePoint1 = "0"+to_string(timeStart);
                else if (to_string(timeStart).length() == 4) ifTimePoint1 = to_string(timeStart);
                
                string ifTimePoint2;
                
                if (to_string(timeEnd).length() == 1) ifTimePoint2 = "000"+to_string(timeEnd);
                else if (to_string(timeEnd).length() == 2) ifTimePoint2 = "00"+to_string(timeEnd);
                else if (to_string(timeEnd).length() == 3) ifTimePoint2 = "0"+to_string(timeEnd);
                else if (to_string(timeEnd).length() == 4) ifTimePoint2 = to_string(timeEnd);
                
                ifTimePoint1 = "IF: "+ifTimePoint1+"-"+ifTimePoint2;
                
                [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(ifTimePoint1.c_str()) attributes:attributesA];
                pointA.x = 700;
                pointA.y = 305;
                [attrStrA drawAtPoint:pointA];
            }
            
            if (includeExcludeModification == 1 || lineageModification == 1){
                [attributesA setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
                
                attrStrA = [[NSAttributedString alloc] initWithString:@"Time/Lineage: Modified" attributes:attributesA];
                pointA.x = 30;
                pointA.y = 305;
                [attrStrA drawAtPoint:pointA];
            }
            
            if (fusionSetFlag == 1){
                [attributesA setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
                
                attrStrA = [[NSAttributedString alloc] initWithString:@"Select Ling/Cell" attributes:attributesA];
                pointA.x = 200;
                pointA.y = 305;
                [attrStrA drawAtPoint:pointA];
            }
            
            //----Lineage display Horizontal set----
            [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            
            int numberOfCellEntry = 0;
            int numberOfEventCount = 0;
            
            for (int counter1 = 0; counter1 < cellExtractedInfoSummaryCount/9; counter1++){
                if (cellExtractedInfoSummary [counter1*9+3] == 1 || cellExtractedInfoSummary [counter1*9+3] == 31 || cellExtractedInfoSummary [counter1*9+3] == 41 || cellExtractedInfoSummary [counter1*9+3] == 51){
                    numberOfCellEntry++;
                    numberOfEventCount++;
                }
                
                if (cellExtractedInfoSummary [counter1*9+3] == 32 || cellExtractedInfoSummary [counter1*9+3] == 42 || cellExtractedInfoSummary [counter1*9+3] == 52 || cellExtractedInfoSummary [counter1*9+3] == 91 || cellExtractedInfoSummary [counter1*9+3] == 6 || cellExtractedInfoSummary [counter1*9+3] == 92 || cellExtractedInfoSummary [counter1*9+3] == 8 || cellExtractedInfoSummary [counter1*9+3] == 10 || cellExtractedInfoSummary[counter1*9+3] == 11 || cellExtractedInfoSummary [counter1*9+3] == 7){
                    numberOfEventCount++;
                }
            }
            
            double *horizontalList = new double [numberOfCellEntry*7+50];
            int horizontalListCount = 0;
            double *eventList = new double [numberOfEventCount*5+50];
            int eventListCount = 0;
            int largestTimePoint = 0;
            int findFlag = 0;
            
            for (int counter1 = 0; counter1 < cellExtractedInfoSummaryCount/9; counter1++){
                if (cellExtractedInfoSummary [counter1*9+3] == 1 || cellExtractedInfoSummary [counter1*9+3] == 31 || cellExtractedInfoSummary [counter1*9+3] == 41 || cellExtractedInfoSummary [counter1*9+3] == 51){
                    horizontalList [horizontalListCount] = cellExtractedInfoSummary [counter1*9+5], horizontalListCount++;
                    horizontalList [horizontalListCount] = cellExtractedInfoSummary [counter1*9+6], horizontalListCount++;
                    horizontalList [horizontalListCount] = cellExtractedInfoSummary [counter1*9+8], horizontalListCount++;
                    horizontalList [horizontalListCount] = cellExtractedInfoSummary [counter1*9+2], horizontalListCount++;
                    
                    largestTimePoint = 0;
                    findFlag = 0;
                    
                    for (int counter2 = counter1; counter2 < cellExtractedInfoSummaryCount/9; counter2++){
                        if ((cellExtractedInfoSummary [counter2*9+3] == 32 || cellExtractedInfoSummary [counter2*9+3] == 42 || cellExtractedInfoSummary [counter2*9+3] == 52 || cellExtractedInfoSummary [counter2*9+3] == 91 || cellExtractedInfoSummary [counter2*9+3] == 6 || cellExtractedInfoSummary [counter2*9+3] == 92 || cellExtractedInfoSummary [counter2*9+3] == 8 || cellExtractedInfoSummary [counter2*9+3] == 10 || cellExtractedInfoSummary [counter2*9+3] == 11 || cellExtractedInfoSummary [counter2*9+3] == 7) && cellExtractedInfoSummary [counter2*9+5] == cellExtractedInfoSummary [counter1*9+5] && cellExtractedInfoSummary [counter2*9+6] == cellExtractedInfoSummary [counter1*9+6]){
                            
                            eventList [eventListCount] = cellExtractedInfoSummary [counter2*9+5], eventListCount++;
                            eventList [eventListCount] = cellExtractedInfoSummary [counter2*9+6], eventListCount++;
                            eventList [eventListCount] = cellExtractedInfoSummary [counter2*9+2], eventListCount++;
                            eventList [eventListCount] = cellExtractedInfoSummary [counter2*9+3], eventListCount++;
                            eventList [eventListCount] = 0, eventListCount++;
                            
                            if (cellExtractedInfoSummary [counter2*9+3] == 32 || cellExtractedInfoSummary [counter2*9+3] == 42 || cellExtractedInfoSummary [counter2*9+3] == 52 || cellExtractedInfoSummary [counter2*9+3] == 91 || cellExtractedInfoSummary [counter2*9+3] == 8 || cellExtractedInfoSummary [counter2*9+3] == 7){
                                break;
                            }
                        }
                    }
                    
                    for (int counter2 = 0; counter2 < cellExtractedInfoSummaryCount/9; counter2++){
                        if ((cellExtractedInfoSummary [counter2*9+3] == 32 || cellExtractedInfoSummary [counter2*9+3] == 42 || cellExtractedInfoSummary [counter2*9+3] == 52 || cellExtractedInfoSummary [counter2*9+3] == 91) && cellExtractedInfoSummary [counter2*9+5] == cellExtractedInfoSummary [counter1*9+5] && cellExtractedInfoSummary [counter2*9+6] == cellExtractedInfoSummary [counter1*9+6]){
                            horizontalList [horizontalListCount] = cellExtractedInfoSummary [counter2*9+2], horizontalListCount++;
                            horizontalList [horizontalListCount] = cellExtractedInfoSummary [counter2*9+3], horizontalListCount++;
                            findFlag = 1;
                            break;
                        }
                        else{
                            
                            if (cellExtractedInfoSummary [counter2*9+5] == cellExtractedInfoSummary [counter1*9+5] && cellExtractedInfoSummary [counter2*9+6] == cellExtractedInfoSummary [counter1*9+6]){
                                if (cellExtractedInfoSummary [counter2*9+2] > largestTimePoint) largestTimePoint = (int)(cellExtractedInfoSummary [counter2*9+2]);
                            }
                        }
                    }
                    
                    if (findFlag == 0){
                        horizontalList [horizontalListCount] = largestTimePoint, horizontalListCount++;
                        horizontalList [horizontalListCount] = 2, horizontalListCount++;
                    }
                    
                    if (cellExtractedInfoSummary [counter1*9+3] == 1) horizontalList [horizontalListCount] = 1, horizontalListCount++;
                    else horizontalList [horizontalListCount] = 0, horizontalListCount++;
                }
            }
            
            //for (int counterA = 0; counterA < horizontalListCount/7; counterA++){
            //    cout<<to_string(horizontalList [counterA*7])<<" "<<horizontalList [counterA*7+1]<<" "<<horizontalList [counterA*7+2]<<" "<<horizontalList [counterA*7+3]<<" "<<horizontalList [counterA*7+4]<<" horizontalList"<<endl;
            //}
            
            //for (int counterA = 0; counterA < eventListCount/5; counterA++){
            //    cout<<counterA<<" "<<to_string(eventList [counterA*5])<<" "<<eventList [counterA*5+1]<<" "<< eventList [counterA*5+2]<<" "<<eventList [counterA*5+3]<<" "<<eventList [counterA*5+4]<<"   eventList"<<endl;
            //}
            
            int terminationFlag = 0;
            int lineageSelect = 0;
            int cellSelectPosition = 0;
            double cellSelect = 0;
            
            double *horizontalList2 = new double [numberOfCellEntry*7+50];
            int horizontalListCount2 = 0;
            double *eventList2 = new double [numberOfEventCount*6+50];
            
            int eventListCount2 = 0;
            
            for (int counter1 = 0; counter1 < numberOfEventCount*6+50; counter1++) eventList2 [counter1] = 0;
            
            int entryOrder = 0;
            
            do{
                
                terminationFlag = 1;
                lineageSelect = 100000;
                
                for (int counter1 = 0; counter1 < horizontalListCount/7; counter1++){
                    if (horizontalList [counter1*7+1] != -1){
                        lineageSelect = (int)(horizontalList [counter1*7+1]);
                        break;
                    }
                }
                
                if (lineageSelect == 100000) terminationFlag = 0;
                else{
                    
                    cellSelect = 999999999999999;
                    cellSelectPosition = 0;
                    
                    for (int counter1 = 0; counter1 < horizontalListCount/7; counter1++){
                        if (horizontalList [counter1*7] != -1 && horizontalList [counter1*7+1] == lineageSelect && horizontalList [counter1*7] < cellSelect){
                            cellSelect = horizontalList [counter1*7];
                            cellSelectPosition = counter1;
                        }
                    }
                    
                    if (cellSelect != 999999999999999){
                        horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7], horizontalListCount2++; //----Cell no---
                        horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+1], horizontalListCount2++; //----Ling no----
                        horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+2], horizontalListCount2++; //----Rev cell no----
                        horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+3], horizontalListCount2++; //----Time start----
                        horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+4], horizontalListCount2++; //----Time end----
                        horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+5], horizontalListCount2++; //----Event last----
                        horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+6], horizontalListCount2++; //----Event I----
                        
                        for (int counter1 = 0; counter1 < eventListCount/5; counter1++){
                            if (eventList [counter1*5] == horizontalList [cellSelectPosition*7] && eventList [counter1*5+1] == horizontalList [cellSelectPosition*7+1]){
                                eventList2 [eventListCount2] = eventList [counter1*5], eventListCount2++; //----Cell no----
                                eventList2 [eventListCount2] = eventList [counter1*5+1], eventListCount2++; //----Ling no----
                                eventList2 [eventListCount2] = eventList [counter1*5+2], eventListCount2++; //----Time----
                                eventList2 [eventListCount2] = eventList [counter1*5+3], eventListCount2++; //----Event----
                                eventList2 [eventListCount2] = entryOrder, eventListCount2++; //----Entry order----
                            }
                        }
                        
                        horizontalList [cellSelectPosition*7] = -1;
                        horizontalList [cellSelectPosition*7+1] = -1;
                        
                        entryOrder++;
                    }
                }
                
            } while (terminationFlag == 1);
            
            //for (int counterA = 0; counterA < eventListCount2/5; counterA++){
            //    cout<<eventList2 [counterA*5]<<" "<<eventList2 [counterA*5+1]<<" "<< eventList2 [counterA*5+2]<<" "<<eventList2 [counterA*5+3]<<" "<<eventList2 [counterA*5+4]<<"   eventList2"<<endl;
            //}
            
            //for (int counterA = 0; counterA < horizontalListCount2/7; counterA++){
            //    cout<<to_string(horizontalList2 [counterA*7])<<" "<<to_string(horizontalList2 [counterA*7+1])<<" "<<horizontalList2 [counterA*7+2]<<" "<<horizontalList2 [counterA*7+3]<<" "<<horizontalList2 [counterA*7+4]<<" horizontalList2"<<endl;
            //}
            
            //----Lineage display Vertical set----
            double *verticalList = new double [numberOfEventCount*9+50];
            int verticalListCount = 0;
            
            double parentCellNo = 0;
            double cellNoLow = 0;
            double cellNoHigh = 0;
            int cellNoLowPosition = 0;
            int cellNoHighPosition = 0;
            int matchFindFlag = 0;
            
            for (int counter1 = 0; counter1 < cellExtractedInfoSummaryCount/9; counter1++){
                if (cellExtractedInfoSummary [counter1*9+3] == 91){
                    matchFindFlag = 0;
                    
                    for (int counter2 = 0; counter2 < verticalListCount/9; counter2++){
                        if ((verticalList [counter2*9] == cellExtractedInfoSummary [counter1*9+5] && verticalList [counter2*9+1] == cellExtractedInfoSummary [counter1*9+6] && verticalList [counter2*9+2] == cellExtractedInfoSummary [counter1*9+2]) || (verticalList [counter2*9+3] == cellExtractedInfoSummary [counter1*9+5] && verticalList [counter2*9+4] == cellExtractedInfoSummary [counter1*9+6] && verticalList [counter2*9+5] == cellExtractedInfoSummary [counter1*9+2])){
                            matchFindFlag = 1;
                        }
                    }
                    
                    if (matchFindFlag == 0){
                        for (int counter2 = 0; counter2 < cellExtractedInfoSummaryCount/9; counter2++){
                            if (cellExtractedInfoSummary [counter2*9+3] == 92 && cellExtractedInfoSummary [counter1*9+4] == cellExtractedInfoSummary [counter2*9+5] && cellExtractedInfoSummary [counter1*9+7] == cellExtractedInfoSummary [counter2*9+6] && cellExtractedInfoSummary [counter2*9+2] == cellExtractedInfoSummary [counter1*9+2]){
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+5], verticalListCount++;
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+6], verticalListCount++;
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+2], verticalListCount++;
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+5], verticalListCount++;
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+6], verticalListCount++;
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+2], verticalListCount++;
                                verticalList [verticalListCount] = 0, verticalListCount++;
                                verticalList [verticalListCount] = 0, verticalListCount++;
                                verticalList [verticalListCount] = 91, verticalListCount++;
                                
                                break;
                            }
                        }
                    }
                }
                else if (cellExtractedInfoSummary [counter1*9+3] == 92){
                    matchFindFlag = 0;
                    
                    for (int counter2 = 0; counter2 < verticalListCount/9; counter2++){
                        if ((verticalList [counter2*9] == cellExtractedInfoSummary [counter1*9+5] && verticalList [counter2*9+1] == cellExtractedInfoSummary [counter1*9+6] && verticalList [counter2*9+2] == cellExtractedInfoSummary [counter1*9+2]) || (verticalList [counter2*9+3] == cellExtractedInfoSummary [counter1*9+5] && verticalList [counter2*9+4] == cellExtractedInfoSummary [counter1*9+6] && verticalList [counter2*9+5] == cellExtractedInfoSummary [counter1*9+2])){
                            matchFindFlag = 1;
                        }
                    }
                    
                    if (matchFindFlag == 0){
                        for (int counter2 = 0; counter2 < cellExtractedInfoSummaryCount/9; counter2++){
                            if (cellExtractedInfoSummary [counter2*9+3] == 91 && cellExtractedInfoSummary [counter1*9+4] == cellExtractedInfoSummary [counter2*9+5] && cellExtractedInfoSummary [counter1*9+7] == cellExtractedInfoSummary [counter2*9+6] && cellExtractedInfoSummary [counter2*9+2] == cellExtractedInfoSummary [counter1*9+2]){
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+5], verticalListCount++;
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+6], verticalListCount++;
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+2], verticalListCount++;
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+5], verticalListCount++;
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+6], verticalListCount++;
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+2], verticalListCount++;
                                verticalList [verticalListCount] = 0, verticalListCount++;
                                verticalList [verticalListCount] = 0, verticalListCount++;
                                verticalList [verticalListCount] = 91, verticalListCount++;
                                
                                break;
                            }
                        }
                    }
                }
                else if (cellExtractedInfoSummary [counter1*9+3] == 31){
                    parentCellNo = cellExtractedInfoSummary [counter1*9+4];
                    matchFindFlag = 0;
                    
                    for (int counter2 = 0; counter2 < verticalListCount/9; counter2++){
                        if ((verticalList [counter2*9] == cellExtractedInfoSummary [counter1*9+5] && verticalList [counter2*9+1] == cellExtractedInfoSummary [counter1*9+6] && verticalList [counter2*9+2] == cellExtractedInfoSummary [counter1*9+2]) || (verticalList [counter2*9+3] == cellExtractedInfoSummary [counter1*9+5] && verticalList [counter2*9+4] == cellExtractedInfoSummary [counter1*9+6] && verticalList [counter2*9+5] == cellExtractedInfoSummary [counter1*9+2])){
                            matchFindFlag = 1;
                        }
                    }
                    
                    if (matchFindFlag == 0){
                        for (int counter2 = 0; counter2 < cellExtractedInfoSummaryCount/9; counter2++){
                            if (cellExtractedInfoSummary [counter2*9+3] == 31 && cellExtractedInfoSummary [counter1*9+6] == cellExtractedInfoSummary [counter2*9+6] && cellExtractedInfoSummary [counter2*9+4] == parentCellNo && cellExtractedInfoSummary [counter2*9+5] != cellExtractedInfoSummary [counter1*9+5] && cellExtractedInfoSummary [counter2*9+2] == cellExtractedInfoSummary [counter1*9+2]){
                                
                                if (cellExtractedInfoSummary [counter2*9+5] > cellExtractedInfoSummary [counter1*9+5]){
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+5], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+6], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+2], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+5], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+6], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+2], verticalListCount++;
                                    verticalList [verticalListCount] = 0, verticalListCount++;
                                    verticalList [verticalListCount] = 0, verticalListCount++;
                                    verticalList [verticalListCount] = 31, verticalListCount++;
                                }
                                else{
                                    
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+5], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+6], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+2], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+5], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+6], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+2], verticalListCount++;
                                    verticalList [verticalListCount] = 0, verticalListCount++;
                                    verticalList [verticalListCount] = 0, verticalListCount++;
                                    verticalList [verticalListCount] = 31, verticalListCount++;
                                }
                                
                                break;
                            }
                        }
                    }
                }
                else if (cellExtractedInfoSummary [counter1*9+3] == 41){
                    parentCellNo = cellExtractedInfoSummary [counter1*9+4];
                    cellNoLow = cellExtractedInfoSummary [counter1*9+5];
                    cellNoHigh = cellExtractedInfoSummary [counter1*9+5];
                    cellNoLowPosition = counter1;
                    cellNoHighPosition = counter1;
                    
                    matchFindFlag = 0;
                    
                    for (int counter2 = 0; counter2 < verticalListCount/9; counter2++){
                        if ((verticalList [counter2*9] == cellExtractedInfoSummary [counter1*9+5] && verticalList [counter2*9+1] == cellExtractedInfoSummary [counter1*9+6] && verticalList [counter2*9+2] == cellExtractedInfoSummary [counter1*9+2]) || (verticalList [counter2*9+3] == cellExtractedInfoSummary [counter1*9+5] && verticalList [counter2*9+4] == cellExtractedInfoSummary [counter1*9+6] && verticalList [counter2*9+5] == cellExtractedInfoSummary [counter1*9+2])){
                            matchFindFlag = 1;
                        }
                    }
                    
                    if (matchFindFlag == 0){
                        for (int counter2 = 0; counter2 < cellExtractedInfoSummaryCount/9; counter2++){
                            if (cellExtractedInfoSummary [counter2*9+3] == 41 && cellExtractedInfoSummary [counter1*9+6] == cellExtractedInfoSummary [counter2*9+6] && cellExtractedInfoSummary [counter2*9+4] == parentCellNo && cellExtractedInfoSummary [counter2*9+5] != cellExtractedInfoSummary [counter1*9+5]){
                                if (cellExtractedInfoSummary [counter2*9+5] > cellNoHigh){
                                    cellNoHigh = cellExtractedInfoSummary [counter2*9+5];
                                    cellNoHighPosition = counter2;
                                }
                                
                                if (cellExtractedInfoSummary [counter2*9+5] < cellNoLow){
                                    cellNoHigh = cellExtractedInfoSummary [counter2*9+5];
                                    cellNoLowPosition = counter2;
                                }
                            }
                        }
                        
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoLowPosition*9+5], verticalListCount++;
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoLowPosition*9+6], verticalListCount++;
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoLowPosition*9+2], verticalListCount++;
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoHighPosition*9+5], verticalListCount++;
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoHighPosition*9+6], verticalListCount++;
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoHighPosition*9+2], verticalListCount++;
                        verticalList [verticalListCount] = 0, verticalListCount++;
                        verticalList [verticalListCount] = 0, verticalListCount++;
                        verticalList [verticalListCount] = 41, verticalListCount++;
                    }
                }
                else if (cellExtractedInfoSummary [counter1*9+3] == 51){
                    parentCellNo = cellExtractedInfoSummary [counter1*9+4];
                    cellNoLow = cellExtractedInfoSummary [counter1*9+5];
                    cellNoHigh = cellExtractedInfoSummary [counter1*9+5];
                    cellNoLowPosition = counter1;
                    cellNoHighPosition = counter1;
                    
                    matchFindFlag = 0;
                    
                    for (int counter2 = 0; counter2 < verticalListCount/9; counter2++){
                        if ((verticalList [counter2*9] == cellExtractedInfoSummary [counter1*9+5] && verticalList [counter2*9+1] == cellExtractedInfoSummary [counter1*9+6] && verticalList [counter2*9+2] == cellExtractedInfoSummary [counter1*9+2]) || (verticalList [counter2*9+3] == cellExtractedInfoSummary [counter1*9+5] && verticalList [counter2*9+4] == cellExtractedInfoSummary [counter1*9+6] && verticalList [counter2*9+5] == cellExtractedInfoSummary [counter1*9+2])){
                            matchFindFlag = 1;
                        }
                    }
                    
                    if (matchFindFlag == 0){
                        for (int counter2 = 0; counter2 < cellExtractedInfoSummaryCount/9; counter2++){
                            if (cellExtractedInfoSummary [counter2*9+3] == 51 && cellExtractedInfoSummary [counter1*9+6] == cellExtractedInfoSummary [counter2*9+6] && cellExtractedInfoSummary [counter2*9+4] == parentCellNo && cellExtractedInfoSummary [counter2*9+5] != cellExtractedInfoSummary [counter1*9+5]){
                                
                                if (cellExtractedInfoSummary [counter2*9+5] > cellNoHigh){
                                    cellNoHigh = cellExtractedInfoSummary [counter2*9+5];
                                    cellNoHighPosition = counter2;
                                }
                                
                                if (cellExtractedInfoSummary [counter2*9+5] < cellNoLow){
                                    cellNoLow = cellExtractedInfoSummary [counter2*9+5];
                                    cellNoLowPosition = counter2;
                                }
                            }
                        }
                        
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoLowPosition*9+5], verticalListCount++; //----Cell no 1----
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoLowPosition*9+6], verticalListCount++; //----Ling no 1----
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoLowPosition*9+2], verticalListCount++; //----Time 1----
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoHighPosition*9+5], verticalListCount++; //----Cell no 2----
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoHighPosition*9+6], verticalListCount++; //----Ling no 2----
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoHighPosition*9+2], verticalListCount++; //----Time 2----
                        verticalList [verticalListCount] = 0, verticalListCount++; //----Cell order 1----
                        verticalList [verticalListCount] = 0, verticalListCount++; //----Cell order 2----
                        verticalList [verticalListCount] = 51, verticalListCount++; //----Event----
                    }
                }
            }
            
            //for (int counterA = 0; counterA < verticalListCount/9; counterA++){
            //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<< to_string(verticalList [counterA*9+counterB]);
            //    cout<<" verticalList "<<counterA<<endl;
            //}
            
            for (int counter1 = 0; counter1 < verticalListCount/9; counter1++){
                for (int counter2 = 0; counter2 < horizontalListCount2/7; counter2++){
                    if (horizontalList2 [counter2*7] == verticalList [counter1*9] && horizontalList2 [counter2*7+1] == verticalList [counter1*9+1]){
                        verticalList [counter1*9+6] = counter2;
                        break;
                    }
                }
                
                for (int counter2 = 0; counter2 < horizontalListCount2/7; counter2++){
                    if (horizontalList2 [counter2*7] == verticalList [counter1*9+3] && horizontalList2 [counter2*7+1] == verticalList [counter1*9+4]){
                        verticalList [counter1*9+7] = counter2;
                        break;
                    }
                }
            }
            
            //for (int counterA = 0; counterA < verticalListCount/9; counterA++){
            //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<< to_string(verticalList [counterA*9+counterB]);
            //    cout<<" verticalList "<<counterA<<endl;
            //}
            
            double increment = (295-52)/(double)(numberOfCellEntry+1);
            double horizontalIncrement = (750-40)/(double)horizontalTime;
            
            [[NSColor blackColor] set];
            [NSBezierPath setDefaultLineWidth:1];
            
            [attributesA setObject:[NSFont boldSystemFontOfSize:9] forKey:NSFontAttributeName];
            
            //for (int counterA = 0; counterA < eventListCount2/5; counterA++){
            //    cout<<eventList2 [counterA*5]<<" "<<eventList2 [counterA*5+1]<<" "<< eventList2 [counterA*5+2]<<" "<<eventList2 [counterA*5+3]<<" "<<eventList2 [counterA*5+4]<<"   eventList2"<<endl;
            //}
            
            //----Live vertical line----
            int roundNoGet = 0;
            int ifDataEntryGet = arrayIFTimeLineDataEntryHold [tableCurrentRowHold];
            int positionShiftA = 0;
            
            int *liveTimeList = new int [ifDataEntryGet/9+1];
            int liveTimeListCount = 0;
            
            //for (int counterA = 0; counterA < arrayIFTimeLineDataEntryHold [tableCurrentRowHold]/9; counterA++){
            //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayIFTimeLineData [tableCurrentRowHold][counterA*9+counterB];
            //    cout<<" arrayIFTimeLineData "<<counterA<<endl;
            //}
            
            for (int counter1 = 0; counter1 < ifDataEntryGet/9; counter1++){
                if (arrayIFTimeLineData [tableCurrentRowHold][counter1*9+1] == -1){
                    liveTimeList [liveTimeListCount] = arrayIFTimeLineData [tableCurrentRowHold][counter1*9], liveTimeListCount++;
                    
                    if (blueLineFlag == 0){
                        [[NSColor blueColor] set];
                        
                        positionAA.x = 40+arrayIFTimeLineData [tableCurrentRowHold][counter1*9]*horizontalIncrement;
                        positionAA.y = 40;
                        positionBB.x = 40+arrayIFTimeLineData [tableCurrentRowHold][counter1*9]*horizontalIncrement;
                        positionBB.y = 295;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        if (to_string(arrayIFTimeLineData [tableCurrentRowHold][counter1*9]).length() == 1) positionShiftA = 2;
                        else if (to_string(arrayIFTimeLineData [tableCurrentRowHold][counter1*9]).length() == 2) positionShiftA = 4;
                        else if (to_string(arrayIFTimeLineData [tableCurrentRowHold][counter1*9]).length() == 3) positionShiftA = 6;
                        else if (to_string(arrayIFTimeLineData [tableCurrentRowHold][counter1*9]).length() == 4) positionShiftA = 8;
                        
                        attrStrA = [[NSAttributedString alloc] initWithString:@(to_string(arrayIFTimeLineData [tableCurrentRowHold][counter1*9]).c_str()) attributes:attributesA];
                        pointA.x = 40+arrayIFTimeLineData [tableCurrentRowHold][counter1*9]*horizontalIncrement-positionShiftA;
                        pointA.y = 296;
                        [attrStrA drawAtPoint:pointA];
                    }
                }
                
                if (arrayIFTimeLineData [tableCurrentRowHold][counter1*9] == ifCurrentTime) roundNoGet = arrayIFTimeLineData [tableCurrentRowHold][counter1*9+1];
            }
            
            if (ifDataExtractCount > 7){
                [[NSColor blackColor] set];
                
                positionAA.x = 40+(ifDataExtract [7]-1)*horizontalIncrement;
                positionAA.y = 40;
                positionBB.x = 40+(ifDataExtract [7]-1)*horizontalIncrement;
                positionBB.y = 295;
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                
                if (to_string(ifDataExtract [7]-1).length() == 1) positionShiftA = 2;
                else if (to_string(ifDataExtract [7]-1).length() == 2) positionShiftA = 5;
                else if (to_string(ifDataExtract [7]-1).length() == 3) positionShiftA = 8;
                else if (to_string(ifDataExtract [7]-1).length() == 4) positionShiftA = 11;
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(to_string(ifDataExtract [7]-1).c_str()) attributes:attributesA];
                pointA.x = 40+(ifDataExtract [7]-1)*horizontalIncrement-positionShiftA;
                pointA.y = 296;
                [attrStrA drawAtPoint:pointA];
            }
            
            //----Lineage Display Vertical----
            if (lineWidthFlag == 0) [NSBezierPath setDefaultLineWidth:2];
            else if (lineWidthFlag == 1) [NSBezierPath setDefaultLineWidth:1];
            else if (lineWidthFlag == 2) [NSBezierPath setDefaultLineWidth:0.5];
            else if (lineWidthFlag == 3) [NSBezierPath setDefaultLineWidth:5];
            else if (lineWidthFlag == 4) [NSBezierPath setDefaultLineWidth:4];
            else if (lineWidthFlag == 5) [NSBezierPath setDefaultLineWidth:3];
            
            for (int counter1 = 0; counter1 < verticalListCount/9; counter1++){
                if (verticalList [counter1*9+8] == 91) [[NSColor orangeColor] set];
                else if (verticalList [counter1*9+8] == 31) [[NSColor blackColor] set];
                else if (verticalList [counter1*9+8] == 41) [[NSColor redColor] set];
                else if (verticalList [counter1*9+8] == 51) [[NSColor redColor] set];
                
                positionAA.x = 40+verticalList [counter1*9+2]*horizontalIncrement;
                positionAA.y = 52+increment+verticalList [counter1*9+6]*increment;
                positionBB.x = 40+verticalList [counter1*9+5]*horizontalIncrement;
                positionBB.y = 52+increment+verticalList [counter1*9+7]*increment;
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
            }
            
            [attributesA setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            [[NSColor blackColor] set];
            
            ifString = to_string(roundNoGet);
            
            if (ifString.length() == 1) ifTimePoint1 = "R0"+ifString;
            else if (ifString.length() == 2) ifTimePoint1 = "R"+ifString;
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(ifTimePoint1.c_str()) attributes:attributesA];
            pointA.x = 798;
            pointA.y = 305;
            [attrStrA drawAtPoint:pointA];
            
            [attributesA setObject:[NSFont boldSystemFontOfSize:9] forKey:NSFontAttributeName];
            
            //----Lineage Display Horizontal----
            int findMainLength = arrayTableMainHold [tableCurrentRowHold];
            
            //----Color data range get----
            int rangeLiveAverageLow = 0;
            int rangeLiveAverageHigh = 0;
            int rangeLiveTotalLow = 0;
            int rangeLiveTotalHigh = 0;
            
            if (liveCurrentCHNo != 0){
                string liveName = "";
                
                if (liveCurrentCHNo == 1) liveName = arrayTableMain [tableCurrentRowHold][6];
                else if (liveCurrentCHNo == 2) liveName = arrayTableMain [tableCurrentRowHold][7];
                else if (liveCurrentCHNo == 3) liveName = arrayTableMain [tableCurrentRowHold][8];
                else if (liveCurrentCHNo == 4) liveName = arrayTableMain [tableCurrentRowHold][9];
                else if (liveCurrentCHNo == 5) liveName = arrayTableMain [tableCurrentRowHold][10];
                else if (liveCurrentCHNo == 6) liveName = arrayTableMain [tableCurrentRowHold][11];
                
                for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryCount; counter1++){
                    if (atoi(arrayLineageFluorescentDataType [counter1][0].c_str()) == tableCurrentRowHold+1 && arrayLineageFluorescentDataType [counter1][1] == "Live" && arrayLineageFluorescentDataType [counter1][2] == liveName){
                        rangeLiveTotalLow = atoi(arrayLineageFluorescentDataType [counter1][6].c_str());
                        rangeLiveTotalHigh = atoi(arrayLineageFluorescentDataType [counter1][7].c_str());
                        rangeLiveAverageLow = atoi(arrayLineageFluorescentDataType [counter1][4].c_str());
                        rangeLiveAverageHigh = atoi(arrayLineageFluorescentDataType [counter1][5].c_str());
                        break;
                    }
                }
            }
            
            //for (int counterA = 0; counterA < liveTimeListCount; counterA++){
            //    cout<<counterA<<" "<<liveTimeList [counterA] <<" liveTimeList"<<endl;
            //}
            
            int endType = 0;
            int startType = 0;
            int liveColorStart = 0;
            int liveColorEnd = 0;
            int liveValueGet = 0;
            int rangeNo = 0;
            int rangeNoHold = 0;
            int timeHold = 0;
            int timeHold2 = 0;
            int differenceInt = 0;
            int cellNoOriginal = 0;
            
            double rangeDivision = 0;
            double difference = 0;
            double difference2 = 0;
            double markerSizeSet = 0;
            
            string liveName = "";
            string cellNumberString;
            
            NSBezierPath *pathCircle;
            
            double *rangeList = new double [horizontalTime*3+30];
            int rangeListCount = 0;
            
            if (markSizeFlag == 0) markerSizeSet = 12;
            else if (markSizeFlag == 1) markerSizeSet = 6;
            else if (markSizeFlag == 2) markerSizeSet = 0;
            
            string horizontalString;
            
            for (int counter1 = 0; counter1 < horizontalListCount2/7; counter1++){
                [[NSColor blackColor] set];
                
                cellNoOriginal = 0;
                
                for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                    if (horizontalList2 [counter1*7] == cellNoList [counter2*4+2]){
                        cellNoOriginal = (int)(cellNoList [counter2*4]);
                        break;
                    }
                }
                
                if (horizontalList2 [counter1*7+5] == 32 || horizontalList2 [counter1*7+3] == 42 || horizontalList2 [counter1*7+3] == 52) endType = 1;
                else endType = 0;
                
                if (horizontalList2 [counter1*7+6] == 1) startType = 1;
                else startType = 0;
                
                //cout<<counter1<<" "<<horizontalList2 [counter1*7]<<" "<<horizontalList2 [counter1*7+1]<<" TimeStartEnd"<<endl;
                
                //----Color data drawing----
                if (liveCurrentCHNo == 0){
                    if (fusionSetCount == 1){
                        if (xPointDownDisplay >= 40+horizontalList2 [counter1*7+3]*horizontalIncrement && xPointDownDisplay <= 40+horizontalList2 [counter1*7+4]*horizontalIncrement && yPointDownDisplay >= 52+increment+counter1*increment-4 && yPointDownDisplay <= 52+increment+counter1*increment+4){
                            
                            [[NSColor redColor] set];
                            
                            fusionSetCount = 2;
                            lingNoForFuse1 = (int)(horizontalList2 [counter1*7+1]);
                            
                            cellNoForFuse1 = cellNoOriginal;
                            cellNoCurrent1 = horizontalList2 [counter1*7];
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                    }
                    else if (fusionSetCount == 2 && (lingNoForFuse1 != horizontalList2 [counter1*7+1] || cellNoForFuse1 != horizontalList2 [counter1*7])){
                        if (xPointDownDisplay >= 40+horizontalList2 [counter1*7+3]*horizontalIncrement && xPointDownDisplay <= 40+horizontalList2 [counter1*7+4]*horizontalIncrement && yPointDownDisplay >= 52+increment+counter1*increment-4 && yPointDownDisplay <= 52+increment+counter1*increment+4){
                            [[NSColor blueColor] set];
                            
                            fusionSetCount = 3;
                            lingNoForFuse2 = (int)(horizontalList2 [counter1*7+1]);
                            
                            cellNoForFuse2 = cellNoOriginal;
                            cellNoCurrent2 = horizontalList2 [counter1*7];
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                    }
                    
                    if (fusionSetCount >= 2 && lingNoForFuse1 == horizontalList2 [counter1*7+1] && cellNoCurrent1 == horizontalList2 [counter1*7] && (lingNoForFuse2 != horizontalList2 [counter1*7+1] || cellNoCurrent2 != horizontalList2 [counter1*7])){
                        [[NSColor redColor] set];
                    }
                    
                    if (fusionSetCount >= 2 && lingNoForFuse2 == horizontalList2 [counter1*7+1] && cellNoCurrent2 == horizontalList2 [counter1*7] && (lingNoForFuse1 != horizontalList2 [counter1*7+1] || cellNoCurrent1 != horizontalList2 [counter1*7])){
                        [[NSColor blueColor] set];
                    }
                    
                    positionAA.x = 40+horizontalList2 [counter1*7+3]*horizontalIncrement;
                    positionAA.y = 52+increment+counter1*increment;
                    
                    if (endType == 1) positionBB.x = 40+(horizontalList2 [counter1*7+4]+1)*horizontalIncrement;
                    else positionBB.x = 40+horizontalList2 [counter1*7+4]*horizontalIncrement;
                    
                    positionBB.y = 52+increment+counter1*increment;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                }
                else{
                    
                    liveColorStart = -1;
                    liveColorEnd = -1;
                    
                    for (int counter2 = 0; counter2 < liveTimeListCount; counter2++){
                        if (liveColorStart == -1 && liveTimeList [counter2] >= horizontalList2 [counter1*7+3]) liveColorStart = counter2;
                        if (liveTimeList [counter2] <= horizontalList2 [counter1*7+4]) liveColorEnd = counter2;
                    }
                    
                    if (liveColorStart != -1 && liveColorStart == liveColorEnd){
                        liveValueGet = 0;
                        
                        for (int counter2 = 0; counter2 < ifValueExtractCount/22; counter2++){
                            if (cellNoOriginal == ifValueExtract [counter2*22] && (int)(horizontalList2 [counter1*7+1]) == ifValueExtract [counter2*22+1] && liveTimeList [liveColorStart] == ifValueExtract [counter2*22+2]){
                                
                                if (liveCurrentCHNo == 1){
                                    if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter2*22+5];
                                    else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter2*22+5]*ifValueExtract [counter2*22+6];
                                }
                                else if (liveCurrentCHNo == 2){
                                    if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter2*22+8];
                                    else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter2*22+8]*ifValueExtract [counter2*22+9];
                                }
                                else if (liveCurrentCHNo == 3){
                                    if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter2*22+11];
                                    else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter2*22+11]*ifValueExtract [counter2*22+12];
                                }
                                else if (liveCurrentCHNo == 4){
                                    if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter2*22+14];
                                    else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter2*22+14]*ifValueExtract [counter2*22+15];
                                }
                                else if (liveCurrentCHNo == 5){
                                    if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter2*22+17];
                                    else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter2*22+17]*ifValueExtract [counter2*22+18];
                                }
                                else if (liveCurrentCHNo == 6){
                                    if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter2*22+20];
                                    else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter2*22+20]*ifValueExtract [counter2*22+21];
                                }
                                
                                break;
                            }
                        }
                        
                        if (averageTotalFlag == 0){
                            rangeDivision = (rangeLiveAverageHigh-rangeLiveAverageLow)/(double)25;
                            
                            if (liveValueGet < rangeLiveAverageLow+rangeDivision) rangeNo = 1;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*2) rangeNo = 2;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*3) rangeNo = 3;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*4) rangeNo = 4;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*5) rangeNo = 5;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*6) rangeNo = 6;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*7) rangeNo = 7;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*8) rangeNo = 8;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*9) rangeNo = 9;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*10) rangeNo = 10;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*11) rangeNo = 11;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*12) rangeNo = 12;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*13) rangeNo = 13;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*14) rangeNo = 14;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*15) rangeNo = 15;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*16) rangeNo = 16;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*17) rangeNo = 17;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*18) rangeNo = 18;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*19) rangeNo = 19;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*20) rangeNo = 20;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*21) rangeNo = 21;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*22) rangeNo = 22;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*23) rangeNo = 23;
                            else rangeNo = 24;
                            
                            [[NSColor colorWithCalibratedRed:arrayColorRange [(rangeNo-1)*3] green:arrayColorRange [(rangeNo-1)*3+1] blue:arrayColorRange [(rangeNo-1)*3+2] alpha:1] set];
                            
                            positionAA.x = 40+horizontalList2 [counter1*7+3]*horizontalIncrement;
                            positionAA.y = 52+increment+counter1*increment;
                            
                            if (endType == 1) positionBB.x = 40+(horizontalList2 [counter1*7+4]+1)*horizontalIncrement;
                            else positionBB.x = 40+horizontalList2 [counter1*7+4]*horizontalIncrement;
                            
                            positionBB.y = 52+increment+counter1*increment;
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                        else{
                            
                            rangeDivision = (rangeLiveTotalHigh-rangeLiveTotalLow)/(double)25;
                            
                            if (liveValueGet < rangeLiveTotalLow+rangeDivision) rangeNo = 1;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*2) rangeNo = 2;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*3) rangeNo = 3;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*4) rangeNo = 4;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*5) rangeNo = 5;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*6) rangeNo = 6;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*7) rangeNo = 7;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*8) rangeNo = 8;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*9) rangeNo = 9;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*10) rangeNo = 10;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*11) rangeNo = 11;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*12) rangeNo = 12;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*13) rangeNo = 13;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*14) rangeNo = 14;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*15) rangeNo = 15;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*16) rangeNo = 16;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*17) rangeNo = 17;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*18) rangeNo = 18;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*19) rangeNo = 19;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*20) rangeNo = 20;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*21) rangeNo = 21;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*22) rangeNo = 22;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*23) rangeNo = 23;
                            else rangeNo = 24;
                            
                            [[NSColor colorWithCalibratedRed:arrayColorRange [(rangeNo-1)*3] green:arrayColorRange [(rangeNo-1)*3+1] blue:arrayColorRange [(rangeNo-1)*3+2] alpha:1] set];
                            
                            positionAA.x = 40+horizontalList2 [counter1*7+3]*horizontalIncrement;
                            positionAA.y = 52+increment+counter1*increment;
                            
                            if (endType == 1) positionBB.x = 40+(horizontalList2 [counter1*7+4]+1)*horizontalIncrement;
                            else positionBB.x = 40+horizontalList2 [counter1*7+4]*horizontalIncrement;
                            
                            positionBB.y = 52+increment+counter1*increment;
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                    } //----One live data/cell----
                    else if (liveColorStart != -1 && liveColorStart < liveColorEnd){ //----More than one live data/cell----
                        rangeListCount = 0;
                        
                        for (int counter2 = liveColorStart; counter2 <= liveColorEnd; counter2++){
                            liveValueGet = 0;
                            
                            for (int counter3 = 0; counter3 < ifValueExtractCount/22; counter3++){
                                if (cellNoOriginal == ifValueExtract [counter3*22] && (int)(horizontalList2 [counter1*7+1]) == ifValueExtract [counter3*22+1] && liveTimeList [counter2] == ifValueExtract [counter3*22+2]){
                                    if (liveCurrentCHNo == 1){
                                        if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter3*22+5];
                                        else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter3*22+5]*ifValueExtract [counter3*22+6];
                                    }
                                    else if (liveCurrentCHNo == 2){
                                        if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter3*22+8];
                                        else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter3*22+8]*ifValueExtract [counter3*22+9];
                                    }
                                    else if (liveCurrentCHNo == 3){
                                        if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter3*22+11];
                                        else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter3*22+11]*ifValueExtract [counter3*22+12];
                                    }
                                    else if (liveCurrentCHNo == 4){
                                        if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter3*22+14];
                                        else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter3*22+14]*ifValueExtract [counter3*22+15];
                                    }
                                    else if (liveCurrentCHNo == 5){
                                        if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter3*22+17];
                                        else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter3*22+17]*ifValueExtract [counter3*22+18];
                                    }
                                    else if (liveCurrentCHNo == 6){
                                        if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter3*22+20];
                                        else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter3*22+20]*ifValueExtract [counter3*22+21];
                                    }
                                    
                                    break;
                                }
                            }
                            
                            if (averageTotalFlag == 0){
                                rangeDivision = (rangeLiveAverageHigh-rangeLiveAverageLow)/(double)25;
                                
                                if (liveValueGet < rangeLiveAverageLow+rangeDivision) rangeNo = 1;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*2) rangeNo = 2;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*3) rangeNo = 3;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*4) rangeNo = 4;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*5) rangeNo = 5;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*6) rangeNo = 6;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*7) rangeNo = 7;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*8) rangeNo = 8;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*9) rangeNo = 9;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*10) rangeNo = 10;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*11) rangeNo = 11;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*12) rangeNo = 12;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*13) rangeNo = 13;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*14) rangeNo = 14;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*15) rangeNo = 15;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*16) rangeNo = 16;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*17) rangeNo = 17;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*18) rangeNo = 18;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*19) rangeNo = 19;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*20) rangeNo = 20;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*21) rangeNo = 21;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*22) rangeNo = 22;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*23) rangeNo = 23;
                                else rangeNo = 23;
                            }
                            else{
                                
                                rangeDivision = (rangeLiveTotalHigh-rangeLiveTotalLow)/(double)25;
                                
                                if (liveValueGet < rangeLiveTotalLow+rangeDivision) rangeNo = 1;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*2) rangeNo = 2;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*3) rangeNo = 3;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*4) rangeNo = 4;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*5) rangeNo = 5;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*6) rangeNo = 6;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*7) rangeNo = 7;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*8) rangeNo = 8;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*9) rangeNo = 9;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*10) rangeNo = 10;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*11) rangeNo = 11;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*12) rangeNo = 12;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*13) rangeNo = 13;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*14) rangeNo = 14;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*15) rangeNo = 15;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*16) rangeNo = 16;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*17) rangeNo = 17;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*18) rangeNo = 18;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*19) rangeNo = 19;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*20) rangeNo = 20;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*21) rangeNo = 21;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*22) rangeNo = 22;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*23) rangeNo = 23;
                                else rangeNo = 23;
                            }
                            
                            if (counter2 == liveColorStart){
                                rangeList [rangeListCount] = horizontalList2 [counter1*7+3], rangeListCount++;
                                rangeList [rangeListCount] = liveTimeList [counter2], rangeListCount++;
                                rangeList [rangeListCount] = rangeNo, rangeListCount++;
                                
                                rangeNoHold = rangeNo;
                                timeHold = liveTimeList [counter2];
                            }
                            else if (counter2 == liveColorEnd){
                                difference = (rangeNo-rangeNoHold)/(double)(liveTimeList [counter2]-timeHold);
                                
                                if (liveTimeList [counter2]-timeHold < 5){
                                    rangeList [rangeListCount] = horizontalList2 [counter1*7+3], rangeListCount++;
                                    rangeList [rangeListCount] = liveTimeList [counter2], rangeListCount++;
                                    rangeList [rangeListCount] = rangeNo, rangeListCount++;
                                }
                                else{
                                    
                                    difference2 = difference;
                                    timeHold2 = timeHold;
                                    
                                    for (int counter3 = timeHold+1; counter3 <= liveTimeList [counter2]; counter3++){
                                        if (counter3 == liveTimeList [counter2]){
                                            rangeList [rangeListCount] = timeHold2, rangeListCount++;
                                            rangeList [rangeListCount] = counter3, rangeListCount++;
                                            rangeList [rangeListCount] = rangeNo, rangeListCount++;
                                        }
                                        else if (difference2 >= 1){
                                            differenceInt = (int)difference2;
                                            
                                            rangeList [rangeListCount] = timeHold2, rangeListCount++;
                                            rangeList [rangeListCount] = counter3, rangeListCount++;
                                            rangeList [rangeListCount] = rangeNoHold+differenceInt, rangeListCount++;
                                            
                                            difference2 = difference;
                                            rangeNoHold = rangeNoHold+differenceInt;
                                            timeHold2 = counter3;
                                        }
                                        else difference2 = difference2+difference;
                                    }
                                }
                                
                                rangeList [rangeListCount] = liveTimeList [counter2], rangeListCount++;
                                
                                if (endType == 1) rangeList [rangeListCount] = horizontalList2 [counter1*7+4]+1, rangeListCount++;
                                else rangeList [rangeListCount] = horizontalList2 [counter1*7+4], rangeListCount++;
                                
                                rangeList [rangeListCount] = rangeNo, rangeListCount++;
                            }
                            else{
                                
                                difference = (rangeNo-rangeNoHold)/(double)(liveTimeList [counter2]-timeHold);
                                
                                if (liveTimeList [counter2]-timeHold < 5){
                                    rangeList [rangeListCount] = horizontalList2 [counter1*7+3], rangeListCount++;
                                    rangeList [rangeListCount] = liveTimeList [counter2], rangeListCount++;
                                    rangeList [rangeListCount] = rangeNo, rangeListCount++;
                                }
                                else{
                                    
                                    difference2 = difference;
                                    timeHold2 = timeHold;
                                    
                                    for (int counter3 = timeHold+1; counter3 <= liveTimeList [counter2]; counter3++){
                                        if (counter3 == liveTimeList [counter2]){
                                            rangeList [rangeListCount] = timeHold2, rangeListCount++;
                                            rangeList [rangeListCount] = counter3, rangeListCount++;
                                            rangeList [rangeListCount] = rangeNo, rangeListCount++;
                                        }
                                        else if (difference2 >= 1){
                                            differenceInt = (int)difference2;
                                            
                                            rangeList [rangeListCount] = timeHold2, rangeListCount++;
                                            rangeList [rangeListCount] = counter3, rangeListCount++;
                                            rangeList [rangeListCount] = rangeNoHold+differenceInt, rangeListCount++;
                                            
                                            difference2 = difference;
                                            rangeNoHold = rangeNoHold+differenceInt;
                                            timeHold2 = counter3;
                                        }
                                        else difference2 = difference2+difference;
                                    }
                                }
                                
                                rangeNoHold = rangeNo;
                                timeHold = liveTimeList [counter2];
                            }
                        }
                        
                        for (int counter2 = 0; counter2 < rangeListCount/3; counter2++){
                            [[NSColor colorWithCalibratedRed:arrayColorRange [(int)(rangeList [counter2*3+2])*3] green:arrayColorRange [(int)(rangeList [counter2*3+2])*3+1] blue:arrayColorRange [(int)(rangeList [counter2*3+2])*3+2] alpha:1] set];
                            
                            positionAA.x = 40+rangeList [counter2*3]*horizontalIncrement;
                            positionAA.y = 52+increment+counter1*increment;
                            positionBB.x = 40+rangeList [counter2*3+1]*horizontalIncrement;
                            positionBB.y = 52+increment+counter1*increment;
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                    }
                    else{
                        
                        positionAA.x = 40+horizontalList2 [counter1*7+3]*horizontalIncrement;
                        positionAA.y = 52+increment+counter1*increment;
                        
                        if (endType == 1) positionBB.x = 40+(horizontalList2 [counter1*7+4]+1)*horizontalIncrement;
                        else positionBB.x = 40+horizontalList2 [counter1*7+4]*horizontalIncrement;
                        
                        positionBB.y = 52+increment+counter1*increment;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    }
                }
                
                for (int counter2 = 0; counter2 < eventListCount2/5; counter2++){
                    if (eventList2 [counter2*5+4] == counter1){
                        if (eventList2 [counter2*5+3] == 91 || eventList2 [counter2*5+3] == 92){
                            [[NSColor orangeColor] set];
                            pathCircle = [NSBezierPath bezierPathWithOvalInRect:NSMakeRect(40+eventList2 [counter2*5+2]*horizontalIncrement-6, 48+increment+counter1*increment, markerSizeSet, markerSizeSet)];
                            
                            [pathCircle fill];
                        }
                        else if (eventList2 [counter2*5+3] == 6){
                            [[NSColor cyanColor] set];
                            pathCircle = [NSBezierPath bezierPathWithOvalInRect:NSMakeRect(40+eventList2 [counter2*5+2]*horizontalIncrement-6, 48+increment+counter1*increment, markerSizeSet, markerSizeSet)];
                            [pathCircle fill];
                        }
                        else if (eventList2 [counter2*5+3] == 7){
                            [[NSColor magentaColor] set];
                            path = [NSBezierPath bezierPathWithRect: NSMakeRect(40+eventList2 [counter2*5+2]*horizontalIncrement-6, 48+increment+counter1*increment, markerSizeSet, markerSizeSet)];
                            [path fill];
                        }
                        else if (eventList2 [counter2*5+3] == 8){
                            [[NSColor grayColor] set];
                            path = [NSBezierPath bezierPathWithRect: NSMakeRect(40+eventList2 [counter2*5+2]*horizontalIncrement-6, 48+increment+counter1*increment, markerSizeSet, markerSizeSet)];
                            [path fill];
                        }
                        else if (eventList2 [counter2*5+3] == 10){
                            [[NSColor redColor] set];
                            path = [NSBezierPath bezierPathWithRect: NSMakeRect(40+eventList2 [counter2*5+2]*horizontalIncrement-6, 48+increment+counter1*increment, markerSizeSet, markerSizeSet)];
                            [path stroke];
                        }
                        else if (eventList2 [counter2*5+3] == 11){
                            [[NSColor blueColor] set];
                            path = [NSBezierPath bezierPathWithRect: NSMakeRect(40+eventList2 [counter2*5+2]*horizontalIncrement-6, 48+increment+counter1*increment, markerSizeSet, markerSizeSet)];
                            [path fill];
                        }
                    }
                }
                
                if (startType == 0){
                    if (to_string(horizontalList2 [counter1*7+3]).length() == 1) positionShiftA = 7;
                    else if (to_string(horizontalList2 [counter1*7+3]).length() == 2) positionShiftA = 14;
                    else if (to_string(horizontalList2 [counter1*7+3]).length() == 3) positionShiftA = 21;
                    else if (to_string(horizontalList2 [counter1*7+3]).length() == 4) positionShiftA = 28;
                    
                    if ((int)to_string(horizontalList2 [counter1*7+3]).find (".") != -1) horizontalString = to_string(horizontalList2 [counter1*7+3]).substr(0, to_string(horizontalList2 [counter1*7+3]).find ("."));
                    else horizontalString = to_string(horizontalList2 [counter1*7+3]);
                    
                    attrStrA = [[NSAttributedString alloc] initWithString:@(horizontalString.c_str()) attributes:attributesA];
                    pointA.x = 40+horizontalList2 [counter1*7+3]*horizontalIncrement-positionShiftA;
                    pointA.y = 47+increment+counter1*increment;
                    [attrStrA drawAtPoint:pointA];
                }
                else{
                    
                    [attributesA setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
                    
                    if (to_string(horizontalList2 [counter1*7+1]).length() == 1) positionShiftA = 7;
                    else if (to_string(horizontalList2 [counter1*7+1]).length() == 2) positionShiftA = 11;
                    else if (to_string(horizontalList2 [counter1*7+1]).length() == 3) positionShiftA = 17;
                    else if (to_string(horizontalList2 [counter1*7+1]).length() == 4) positionShiftA = 24;
                    
                    if ((int)to_string(horizontalList2 [counter1*7+1]).find (".") != -1) horizontalString = to_string(horizontalList2 [counter1*7+1]).substr(0, to_string(horizontalList2 [counter1*7+1]).find ("."));
                    else horizontalString = to_string(horizontalList2 [counter1*7+1]);
                    
                    attrStrA = [[NSAttributedString alloc] initWithString:@(horizontalString.c_str()) attributes:attributesA];
                    pointA.x = 40+horizontalList2 [counter1*7+3]*horizontalIncrement-positionShiftA;
                    pointA.y = 47+increment+counter1*increment;
                    [attrStrA drawAtPoint:pointA];
                }
                
                [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                
                if (endType == 1){
                    if (to_string(horizontalList2 [counter1*7+4]+1).length() == 1) positionShiftA = 1;
                    else if (to_string(horizontalList2 [counter1*7+4]+1).length() == 2) positionShiftA = 2;
                    else if (to_string(horizontalList2 [counter1*7+4]+1).length() == 3) positionShiftA = 3;
                    else if (to_string(horizontalList2 [counter1*7+4]+1).length() == 4) positionShiftA = 4;
                    
                    if ((int)to_string(horizontalList2 [counter1*7+4]).find (".") != -1) horizontalString = to_string(horizontalList2 [counter1*7+4]).substr(0, to_string(horizontalList2 [counter1*7+4]).find ("."));
                    else horizontalString = to_string(horizontalList2 [counter1*7+4]);
                    
                    if (endNumberFlag == 0){
                        attrStrA = [[NSAttributedString alloc] initWithString:@(horizontalString.c_str()) attributes:attributesA];
                        pointA.x = 40+(horizontalList2 [counter1*7+4]+1)*horizontalIncrement+positionShiftA;
                        pointA.y = 47+increment+counter1*increment;
                        [attrStrA drawAtPoint:pointA];
                    }
                }
                else{
                    
                    if (to_string(horizontalList2 [counter1*7+4]).length() == 1) positionShiftA = 1;
                    else if (to_string(horizontalList2 [counter1*7+4]).length() == 2) positionShiftA = 2;
                    else if (to_string(horizontalList2 [counter1*7+4]).length() == 3) positionShiftA = 3;
                    else if (to_string(horizontalList2 [counter1*7+4]).length() == 4) positionShiftA = 4;
                    
                    if ((int)to_string(horizontalList2 [counter1*7+4]).find (".") != -1) horizontalString = to_string(horizontalList2 [counter1*7+4]).substr(0, to_string(horizontalList2 [counter1*7+4]).find ("."));
                    else horizontalString = to_string(horizontalList2 [counter1*7+4]);
                    
                    if (endNumberFlag == 0){
                        attrStrA = [[NSAttributedString alloc] initWithString:@(horizontalString.c_str()) attributes:attributesA];
                        pointA.x = 40+horizontalList2 [counter1*7+4]*horizontalIncrement+positionShiftA;
                        pointA.y = 47+increment+counter1*increment;
                        [attrStrA drawAtPoint:pointA];
                    }
                }
                
                if ((int)to_string(horizontalList2 [counter1*7+2]).find (".") != -1) horizontalString = to_string(horizontalList2 [counter1*7+2]).substr(0, to_string(horizontalList2 [counter1*7+2]).find ("."));
                else horizontalString = to_string(horizontalList2 [counter1*7+2]);
                
                cellNumberString = "C"+horizontalString;
                
                if (cellNumberFlag == 0){
                    attrStrA = [[NSAttributedString alloc] initWithString:@(cellNumberString.c_str()) attributes:attributesA];
                    pointA.x = 40+((horizontalList2 [counter1*7+4]+horizontalList2 [counter1*7+3])/(double)2)*horizontalIncrement-5;
                    pointA.y = 53+increment+counter1*increment;
                    [attrStrA drawAtPoint:pointA];
                }
            }
            
            //for (int counterA = 0; counterA < lineageFluorescentDataTypeEntryCount; counterA++){
            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageFluorescentDataType [counterA][counterB];
            //    cout<<" arrayLineageFluorescentDataType "<<counterA+1<<endl;
            //}
            
            //for (int counterA = 0; counterA < 1; counterA++){
            //    for (int counterB = 0; counterB < findMainLength; counterB++) cout<<" "<< arrayTableMain [tableCurrentRowHold][counterA+counterB];
            //    cout<<"  arrayTableMain "<<counterA<<endl;
            //}
            
            string ifName = "";
            
            for (int counter1 = 13; counter1 < findMainLength; counter1 = counter1+8){
                if (atoi(arrayTableMain [tableCurrentRowHold][counter1].c_str()) == roundNoGet){
                    ifName = arrayTableMain [tableCurrentRowHold][counter1+ifCurrentCHNo+1];
                    break;
                }
            }
            
            //1 TR StemD2 StemD2 TR16-HeLa1 nil nil nil nil nil nil nil 1 01 3 DAPI GFP RFP nil nil nil  tableMainTempCount 0
            
            string roundExtract;
            int rangeAverageLow = 0;
            int rangeAverageHigh = 0;
            int rangeTotalLow = 0;
            int rangeTotalHigh = 0;
            
            for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryCount; counter1++){
                roundExtract = arrayLineageFluorescentDataType [counter1][1];
                roundExtract = roundExtract.substr(1);
                
                if (atoi(arrayLineageFluorescentDataType [counter1][0].c_str()) == tableCurrentRowHold+1 && atoi(roundExtract.c_str()) == roundNoGet && arrayLineageFluorescentDataType [counter1][2] == ifName){
                    rangeTotalLow = atoi(arrayLineageFluorescentDataType [counter1][6].c_str());
                    rangeTotalHigh = atoi(arrayLineageFluorescentDataType [counter1][7].c_str());
                    rangeAverageLow = atoi(arrayLineageFluorescentDataType [counter1][4].c_str());
                    rangeAverageHigh = atoi(arrayLineageFluorescentDataType [counter1][5].c_str());
                    break;
                }
            }
            
            double *fluorescentEntry = new double [numberOfCellEntry*5+50];
            int fluorescentEntryCount = 0;
            
            for (int counter1 = 0; counter1 < horizontalListCount2/7; counter1++){
                if (horizontalList2 [counter1*7+3] <= ifCurrentTime && horizontalList2 [counter1*7+4] >= ifCurrentTime){
                    fluorescentEntry [fluorescentEntryCount] = horizontalList2 [counter1*7], fluorescentEntryCount++; //----Cell no----
                    fluorescentEntry [fluorescentEntryCount] = horizontalList2 [counter1*7+1], fluorescentEntryCount++; //----Ling no----
                    fluorescentEntry [fluorescentEntryCount] = 0, fluorescentEntryCount++; //----AV----
                    fluorescentEntry [fluorescentEntryCount] = 0, fluorescentEntryCount++; //----Total----
                    fluorescentEntry [fluorescentEntryCount] = counter1, fluorescentEntryCount++; //----Cell order----
                }
            }
            
            //for (int counterA = 0; counterA < horizontalListCount2/7; counterA++){
            //    cout<<horizontalList2 [counterA*7]<<" "<<horizontalList2 [counterA*7+1]<<" "<<horizontalList2 [counterA*7+2]<<" "<<horizontalList2 [counterA*7+3]<<" "<<horizontalList2 [counterA*7+4]<<" "<<horizontalList2 [counterA*7+5]<<" "<<horizontalList2 [counterA*7+6]<<"  horizontalList2"<<endl;
            //}
            
            //for (int counterA = 0; counterA < fluorescentEntryCount/5; counterA++){
            //    cout<<fluorescentEntry [counterA*5]<<" "<<fluorescentEntry [counterA*5+1]<<" "<< fluorescentEntry [counterA*5+2]<<" "<<fluorescentEntry [counterA*5+3]<<" "<<fluorescentEntry [counterA*5+4]<<"   fluorescentEntry"<<endl;
            //}
            
            //for (int counterA = 0; counterA < arrayIFDataEntryHold [tableCurrentRowHold]/22; counterA++){
            //    for (int counterB = 0; counterB < 22; counterB++) cout<<" "<<arrayIFData [tableCurrentRowHold][counterA*22+counterB];
            //    cout<<" arrayIFData "<<counterA<<endl;
            //}
            
            for (int counter1 = 0; counter1 < fluorescentEntryCount/5; counter1++){
                cellNoOriginal = 0;
                
                for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                    if (fluorescentEntry [counter1*5] == cellNoList [counter2*4+2]){
                        cellNoOriginal = (int)(cellNoList [counter2*4]);
                        break;
                    }
                }
                
                for (int counter2 = 0; counter2 < ifValueExtractCount/22; counter2++){
                    if (cellNoOriginal == ifValueExtract [counter2*22] && (int)(fluorescentEntry [counter1*5+1]) == ifValueExtract [counter2*22+1] && ifCurrentTime == ifValueExtract [counter2*22+2]){
                        
                        if (ifCurrentCHNo == 1){
                            fluorescentEntry [counter1*5+2] = ifValueExtract [counter2*22+5];
                            fluorescentEntry [counter1*5+3] = ifValueExtract [counter2*22+5]*ifValueExtract [counter2*22+6];
                        }
                        else if (ifCurrentCHNo == 2){
                            fluorescentEntry [counter1*5+2] = ifValueExtract [counter2*22+8];
                            fluorescentEntry [counter1*5+3] = ifValueExtract [counter2*22+8]*ifValueExtract [counter2*22+9];
                        }
                        else if (ifCurrentCHNo == 3){
                            fluorescentEntry [counter1*5+2] = ifValueExtract [counter2*22+11];
                            fluorescentEntry [counter1*5+3] = ifValueExtract [counter2*22+11]*ifValueExtract [counter2*22+12];
                        }
                        else if (ifCurrentCHNo == 4){
                            fluorescentEntry [counter1*5+2] = ifValueExtract [counter2*22+14];
                            fluorescentEntry [counter1*5+3] = ifValueExtract [counter2*22+14]*ifValueExtract [counter2*22+15];
                        }
                        else if (ifCurrentCHNo == 5){
                            fluorescentEntry [counter1*5+2] = ifValueExtract [counter2*22+17];
                            fluorescentEntry [counter1*5+3] = ifValueExtract [counter2*22+17]*ifValueExtract [counter2*22+18];
                        }
                        else if (ifCurrentCHNo == 6){
                            fluorescentEntry [counter1*5+2] = ifValueExtract [counter2*22+20];
                            fluorescentEntry [counter1*5+3] = ifValueExtract [counter2*22+20]*ifValueExtract [counter2*22+21];
                        }
                        
                        break;
                    }
                }
            }
            
            //for (int counterA = 0; counterA < fluorescentEntryCount/5; counterA++){
            //    cout<<fluorescentEntry [counterA*5]<<" "<<fluorescentEntry [counterA*5+1]<<" "<< fluorescentEntry [counterA*5+2]<<" "<<fluorescentEntry [counterA*5+3]<<" "<<fluorescentEntry [counterA*5+4]<<"   fluorescentEntry"<<endl;
            //}
            
            if (averageTotalFlag == 0){
                double rangeDivisionAverage = (rangeAverageHigh-rangeAverageLow)/(double)25;
                
                for (int counter1 = 0; counter1 < fluorescentEntryCount/5; counter1++){
                    if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage) rangeNo = 1;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*2) rangeNo = 2;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*3) rangeNo = 3;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*4) rangeNo = 4;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*5) rangeNo = 5;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*6) rangeNo = 6;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*7) rangeNo = 7;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*8) rangeNo = 8;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*9) rangeNo = 9;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*10) rangeNo = 10;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*11) rangeNo = 11;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*12) rangeNo = 12;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*13) rangeNo = 13;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*14) rangeNo = 14;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*15) rangeNo = 15;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*16) rangeNo = 16;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*17) rangeNo = 17;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*18) rangeNo = 18;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*19) rangeNo = 19;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*20) rangeNo = 20;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*21) rangeNo = 21;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*22) rangeNo = 22;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*23) rangeNo = 23;
                    else rangeNo = 24;
                    
                    [[NSColor colorWithCalibratedRed:arrayColorRange [(rangeNo-1)*3] green:arrayColorRange [(rangeNo-1)*3+1] blue:arrayColorRange [(rangeNo-1)*3+2] alpha:1] set];
                    
                    positionAA.x = 835;
                    positionAA.y = 52+increment+fluorescentEntry [counter1*5+4]*increment;
                    positionBB.x = 845;
                    positionBB.y = 52+increment+fluorescentEntry [counter1*5+4]*increment;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                }
            }
            else{
                
                double rangeDivisionTotal = (rangeTotalHigh-rangeTotalLow)/(double)25;
                
                for (int counter1 = 0; counter1 < fluorescentEntryCount/5; counter1++){
                    if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal) rangeNo = 1;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*2) rangeNo = 2;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*3) rangeNo = 3;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*4) rangeNo = 4;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*5) rangeNo = 5;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*6) rangeNo = 6;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*7) rangeNo = 7;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*8) rangeNo = 8;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*9) rangeNo = 9;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*10) rangeNo = 10;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*11) rangeNo = 11;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*12) rangeNo = 12;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*13) rangeNo = 13;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*14) rangeNo = 14;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*15) rangeNo = 15;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*16) rangeNo = 16;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*17) rangeNo = 17;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*18) rangeNo = 18;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*19) rangeNo = 19;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*20) rangeNo = 20;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*21) rangeNo = 21;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*22) rangeNo = 22;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*23) rangeNo = 23;
                    else rangeNo = 24;
                    
                    [[NSColor colorWithCalibratedRed:arrayColorRange [(rangeNo-1)*3] green:arrayColorRange [(rangeNo-1)*3+1] blue:arrayColorRange [(rangeNo-1)*3+2] alpha:1] set];
                    
                    positionAA.x = 835;
                    positionAA.y = 52+increment+fluorescentEntry [counter1*5+4]*increment;
                    positionBB.x = 845;
                    positionBB.y = 52+increment+fluorescentEntry [counter1*5+4]*increment;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                }
            }
            
            delete [] horizontalList;
            delete [] horizontalList2;
            delete [] eventList;
            delete [] eventList2;
            delete [] verticalList;
            delete [] liveTimeList;
            delete [] rangeList;
            delete [] fluorescentEntry;
            delete [] cellExtractedInfo;
            delete [] cellNoList;
            delete [] cellExtractedInfoSummary;
        }
    }
    else{
        
        int magFactor = 4;
        
        NSBitmapImageRep *bitmapReps;
        bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:920*magFactor pixelsHigh:360*magFactor bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:920*magFactor*4 bitsPerPixel:32];
        
        [NSGraphicsContext saveGraphicsState];
        [NSGraphicsContext setCurrentContext:[NSGraphicsContext graphicsContextWithBitmapImageRep:bitmapReps]];
        
        [[NSColor whiteColor] set];
        
        NSBezierPath *path;
        path = [NSBezierPath bezierPathWithRect: NSMakeRect(0, 0, 920*magFactor, 360*magFactor)];
        [path fill];
        
        [[NSColor blackColor] set];
        
        [NSBezierPath setDefaultLineWidth:2];
        
        path = [NSBezierPath bezierPathWithRect: NSMakeRect(25*magFactor, 40*magFactor, 850*magFactor, 280*magFactor)];
        [path stroke];
        
        if (initialArraySet == 1){
            //----Horizontal Scale----
            int horizontalTime = arrayTableDetail [tableCurrentRowHold][3];
            string timeInterval = arrayLineageDataType [tableCurrentRowHold][5];
            string timeString = "Time point (x"+timeInterval+" min)";
            NSString *timeNSstring = @(timeString.c_str());
            
            NSFont *font = [NSFont fontWithName:@"Times New Roman" size:12*magFactor];
            NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
            NSAttributedString *attrStrS = [[NSAttributedString alloc] initWithString:timeNSstring attributes:attributes];
            CGFloat size2 = [attrStrS size].width;
            
            NSPoint pointA;
            NSAttributedString *attrStrA;
            NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
            
            [attributesA setObject:[NSFont boldSystemFontOfSize:12*magFactor] forKey:NSFontAttributeName];
            [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            
            attrStrA = [[NSAttributedString alloc] initWithString:timeNSstring attributes:attributesA];
            pointA.x = 425*magFactor-size2/(double)2;
            pointA.y = 6*magFactor;
            [attrStrA drawAtPoint:pointA];
            
            double lengthDivision = horizontalTime/(double)5;
            int lengthDivisionInt = 0;
            
            if (lengthDivision <= 25) lengthDivisionInt = 25;
            else if (lengthDivision > 25 && lengthDivision <= 50) lengthDivisionInt = 50;
            else if (lengthDivision > 50 && lengthDivision <= 100) lengthDivisionInt = 100;
            else if (lengthDivision > 100 && lengthDivision <= 150) lengthDivisionInt = 100;
            else if (lengthDivision > 150 && lengthDivision <= 200) lengthDivisionInt = 200;
            else if (lengthDivision > 200 && lengthDivision <= 250) lengthDivisionInt = 200;
            else if (lengthDivision > 250 && lengthDivision <= 300) lengthDivisionInt = 300;
            else if (lengthDivision > 300 && lengthDivision <= 350) lengthDivisionInt = 300;
            else if (lengthDivision > 350 && lengthDivision <= 400) lengthDivisionInt = 300;
            else if (lengthDivision > 400 && lengthDivision <= 450) lengthDivisionInt = 400;
            else if (lengthDivision > 450 && lengthDivision <= 550) lengthDivisionInt = 500;
            else if (lengthDivision > 550 && lengthDivision <= 650) lengthDivisionInt = 600;
            else if (lengthDivision > 650 && lengthDivision <= 750) lengthDivisionInt = 700;
            else if (lengthDivision > 750 && lengthDivision <= 850) lengthDivisionInt = 800;
            else if (lengthDivision > 850 && lengthDivision <= 950) lengthDivisionInt = 900;
            else if (lengthDivision > 950 && lengthDivision <= 1050) lengthDivisionInt = 1000;
            else if (lengthDivision > 1050 && lengthDivision <= 1150) lengthDivisionInt = 1100;
            else if (lengthDivision > 1150 && lengthDivision <= 1250) lengthDivisionInt = 1200;
            else if (lengthDivision > 1250 && lengthDivision <= 1350) lengthDivisionInt = 1300;
            else if (lengthDivision > 1350 && lengthDivision <= 1450) lengthDivisionInt = 1400;
            else if (lengthDivision > 1450 && lengthDivision <= 1550) lengthDivisionInt = 1500;
            
            double lengthPix = ((750-40)/(double)horizontalTime)*lengthDivisionInt;
            int numberOfDivision = (int)((750-40)/(double)lengthPix)+1;
            
            NSPoint positionAA;
            NSPoint positionBB;
            
            int sift = 0;
            
            for (int counter1 = 0; counter1 < numberOfDivision; counter1++){
                positionAA.x = 40*magFactor+lengthPix*counter1*magFactor;
                positionAA.y = 40*magFactor;
                positionBB.x = 40*magFactor+lengthPix*counter1*magFactor;
                positionBB.y = 50*magFactor;
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                
                NSString *timeNSstring2 = @(to_string(counter1*lengthDivisionInt).c_str());
                NSDictionary *attributes2 = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                NSAttributedString *attrStrS2 = [[NSAttributedString alloc] initWithString:timeNSstring2 attributes:attributes2];
                size2 = [attrStrS2 size].width;
                
                if (counter1*lengthDivision == 0) sift = 1;
                else if (counter1*lengthDivision < 1000) sift = 2;
                
                NSPoint pointA2;
                NSAttributedString *attrStrA2;
                NSMutableDictionary *attributesA2 = [NSMutableDictionary dictionary];
                
                [attributesA2 setObject:[NSFont boldSystemFontOfSize:12*magFactor] forKey:NSFontAttributeName];
                [attributesA2 setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                
                attrStrA2 = [[NSAttributedString alloc] initWithString:timeNSstring2 attributes:attributesA];
                pointA2.x = (40+lengthPix*counter1)*magFactor-size2/(double)2-sift*magFactor;
                pointA2.y = 25*magFactor;
                [attrStrA2 drawAtPoint:pointA2];
            }
            
            //----Lineage no----
            double *cellExtractedInfo = new double [lineageExtractCount+50];
            int cellExtractedInfoCount = 0;
            
            double *cellNoList = new double [lineageExtractCount/9*4+50];
            int cellNoListCount = 0;
            
            for (unsigned long counter1 = 0; counter1 < lineageExtractCount/9*3+50; counter1++) cellNoList [counter1] = 0;
            
            for (unsigned long counter1 = 0; counter1 < lineageExtractCount/9; counter1++){
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageExtract [counter1*9], cellExtractedInfoCount++;
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageExtract [counter1*9+1], cellExtractedInfoCount++;
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageExtract [counter1*9+2], cellExtractedInfoCount++;
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageExtract [counter1*9+3], cellExtractedInfoCount++;
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageExtract [counter1*9+4], cellExtractedInfoCount++;
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageExtract [counter1*9+5], cellExtractedInfoCount++;
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageExtract [counter1*9+6], cellExtractedInfoCount++;
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageExtract [counter1*9+7], cellExtractedInfoCount++;
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageExtract [counter1*9+8], cellExtractedInfoCount++;
                
                if (arrayLineageExtract [counter1*9+3] == 1 || arrayLineageExtract [counter1*9+3] == 31 || arrayLineageExtract [counter1*9+3] == 41 || arrayLineageExtract [counter1*9+3] == 51){
                    cellNoList [cellNoListCount] = arrayLineageExtract [counter1*9+5], cellNoListCount++;
                    cellNoList [cellNoListCount] = arrayLineageExtract [counter1*9+4], cellNoListCount++;
                    cellNoList [cellNoListCount] = 0, cellNoListCount++;
                    cellNoList [cellNoListCount] = arrayLineageExtract [counter1*9+6], cellNoListCount++;
                }
            }
            
            //for (int counterA = 0; counterA < lineageExtractCount/9; counterA++){
            //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayLineageExtract [counterA*9+counterB];
            //    cout<<" arrayLineageExtract "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < cellExtractedInfoCount/9; counterA++){
            //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<to_string(cellExtractedInfo [counterA*9+counterB]);
            //    cout<<" cellExtractedInfo "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < cellNoListCount/4; counterA++){
            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<to_string(cellNoList [counterA*4+counterB]);
            //    cout<<" cellNoList "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < ifValueExtractCount/13; counterA++){
            //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<ifValueExtract [counterA*13+counterB];
            //    cout<<" ifValueExtract "<<counterA<<endl;
            //}
            
            string extensionNoExtract;
            string extensionNoExtract2;
            string extensionNoExtractB;
            int extensionValueSource = 0;
            
            double extensionValue = 0;
            double parentInfo = 0;
            
            for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                if (cellNoList [counter2*4] <= 299999999 && cellNoList [counter2*4] >= -299999999){
                    cellNoList [counter2*4+2] = cellNoList [counter2*4]*1000000;
                    cellNoList [counter2*4+1] = cellNoList [counter2*4+1]*1000000;
                }
                else if (cellNoList [counter2*4] <= 499999999 && cellNoList [counter2*4] >= 300000000 && cellNoList [counter2*4+1] <= 299999999 && cellNoList [counter2*4+1] >= -299999999){
                    extensionNoExtract = to_string(cellNoList [counter2*4]);
                    
                    if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                    
                    extensionNoExtract = extensionNoExtract.substr(6, 3);
                    extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                    extensionNoExtractB = to_string(extensionValueSource)+"000";
                    extensionNoExtract2 = to_string(cellNoList [counter2*4+1]);
                    
                    if ((int)extensionNoExtract2.find(".") != -1) extensionNoExtract2 = extensionNoExtract2.substr(0, extensionNoExtract2.find("."));
                    
                    extensionNoExtract2 = extensionNoExtract2+"000000";
                    extensionValue = atof(extensionNoExtract2.c_str())+atof(extensionNoExtractB.c_str());
                    
                    cellNoList [counter2*4+2] = extensionValue;
                    cellNoList [counter2*4+1] = cellNoList [counter2*4+1]*1000000;
                }
                else if (cellNoList [counter2*4] >= -499999999 && cellNoList [counter2*4] <= -300000000 && cellNoList [counter2*4+1] <= 299999999 && cellNoList [counter2*4+1] >= -299999999){
                    extensionNoExtract = to_string(cellNoList [counter2*4]);
                    
                    if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                    
                    extensionNoExtract = extensionNoExtract.substr(7, 3);
                    extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                    extensionNoExtractB = to_string(extensionValueSource)+"000";
                    
                    extensionNoExtract2 = to_string(cellNoList [counter2*4+1]);
                    
                    if ((int)extensionNoExtract2.find(".") != -1) extensionNoExtract2 = extensionNoExtract2.substr(0, extensionNoExtract2.find("."));
                    
                    extensionNoExtract2 = extensionNoExtract2+"000000";
                    extensionValue = atof(extensionNoExtract2.c_str())+atof(extensionNoExtractB.c_str());
                    
                    cellNoList [counter2*4+2] = extensionValue;
                    cellNoList [counter2*4+1] = cellNoList [counter2*4+1]*1000000;
                }
            }
            
            for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                if (cellNoList [counter2*4] <= 499999999 && cellNoList [counter2*4] >= 300000000 && cellNoList [counter2*4+1] <= 499999999 && cellNoList [counter2*4+1] >= 300000000){
                    extensionNoExtract = to_string(cellNoList [counter2*4]);
                    
                    if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                    
                    extensionNoExtract = extensionNoExtract.substr(6, 3);
                    parentInfo = 0;
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter3*4] == cellNoList [counter2*4+1]){
                            parentInfo = cellNoList [counter3*4+1];
                            break;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter2*4+1] == cellNoList [counter3*4] && cellNoList [counter3*4+1] > 999999999 && cellNoList [counter2*4+3] == cellNoList [counter3*4+3]){
                            extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                            extensionNoExtractB = to_string(extensionValueSource)+"000";
                            extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                            cellNoList [counter2*4+2] = extensionValue;
                            cellNoList [counter2*4+1] = cellNoList [counter3*4+2];
                            break;
                        }
                    }
                }
                else if (cellNoList [counter2*4] >= -499999999 && cellNoList [counter2*4] <= -300000000 && cellNoList [counter2*4+1] >= -499999999 && cellNoList [counter2*4+1] <= -300000000){
                    extensionNoExtract = to_string(cellNoList [counter2*4]);
                    
                    if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                    
                    extensionNoExtract = extensionNoExtract.substr(7, 3);
                    parentInfo = 0;
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter3*4] == cellNoList [counter2*4+1]){
                            parentInfo = cellNoList [counter3*4+1];
                            break;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter2*4+1] == cellNoList [counter3*4] && cellNoList [counter3*4+1] < -999999999 && cellNoList [counter2*4+3] == cellNoList [counter3*4+3]){
                            extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                            extensionNoExtractB = to_string(extensionValueSource)+"000";
                            extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                            cellNoList [counter2*4+2] = extensionValue;
                            cellNoList [counter2*4+1] = cellNoList [counter3*4+2];
                            break;
                        }
                    }
                }
            }
            
            for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                if (cellNoList [counter2*4] <= 699999999 && cellNoList [counter2*4] >= 500000000 && cellNoList [counter2*4+1] <= 499999999 && cellNoList [counter2*4+1] >= 300000000){
                    extensionNoExtract = to_string(cellNoList [counter2*4]);
                    
                    if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                    
                    extensionNoExtract = extensionNoExtract.substr(6, 3);
                    parentInfo = 0;
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter3*4] == cellNoList [counter2*4+1]){
                            parentInfo = cellNoList [counter3*4+1];
                            break;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter2*4+1] == cellNoList [counter3*4] && cellNoList [counter3*4+1] > 999999999 && cellNoList [counter2*4+3] == cellNoList [counter3*4+3]){
                            extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                            extensionNoExtractB = to_string(extensionValueSource);
                            extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                            cellNoList [counter2*4+2] = extensionValue;
                            cellNoList [counter2*4+1] = cellNoList [counter3*4+2];
                            break;
                        }
                    }
                }
                else if (cellNoList [counter2*4] >= -699999999 && cellNoList [counter2*4] <= -500000000 && cellNoList [counter2*4+1] >= -499999999 && cellNoList [counter2*4+1] <= -300000000){
                    extensionNoExtract = to_string(cellNoList [counter2*4]);
                    
                    if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                    
                    extensionNoExtract = extensionNoExtract.substr(7, 3);
                    parentInfo = 0;
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter3*4] == cellNoList [counter2*4+1]){
                            parentInfo = cellNoList [counter3*4+1];
                            break;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter2*4+1] == cellNoList [counter3*4] && cellNoList [counter3*4+1] < -999999999 && cellNoList [counter2*4+3] == cellNoList [counter3*4+3]){
                            extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                            extensionNoExtractB = to_string(extensionValueSource);
                            extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                            cellNoList [counter2*4+2] = extensionValue;
                            cellNoList [counter2*4+1] = cellNoList [counter3*4+2];
                            break;
                        }
                    }
                }
            }
            
            for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                if (cellNoList [counter2*4] <= 699999999 && cellNoList [counter2*4] >= 500000000 && cellNoList [counter2*4+1] <= 699999999 && cellNoList [counter2*4+1] >= 500000000){
                    extensionNoExtract = to_string(cellNoList [counter2*4]);
                    
                    if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                    
                    extensionNoExtract = extensionNoExtract.substr(6, 3);
                    parentInfo = 0;
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter3*4] == cellNoList [counter2*4+1]){
                            parentInfo = cellNoList [counter3*4+1];
                            break;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter2*4+1] == cellNoList [counter3*4] && cellNoList [counter3*4+1] > 999999999 && cellNoList [counter2*4+3] == cellNoList [counter3*4+3]){
                            extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                            extensionNoExtractB = to_string(extensionValueSource);
                            extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                            cellNoList [counter2*4+2] = extensionValue;
                            cellNoList [counter2*4+1] = cellNoList [counter3*4+2];
                            break;
                        }
                    }
                }
                else if (cellNoList [counter2*4] >= -699999999 && cellNoList [counter2*4] <= -500000000 && cellNoList [counter2*4+1] >= -699999999 && cellNoList [counter2*4+1] <= -500000000){
                    extensionNoExtract = to_string(cellNoList [counter2*4]);
                    
                    if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                    
                    extensionNoExtract = extensionNoExtract.substr(7, 3);
                    parentInfo = 0;
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter3*4] == cellNoList [counter2*4+1]){
                            parentInfo = cellNoList [counter3*4+1];
                            break;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                        if (cellNoList [counter2*4+1] == cellNoList [counter3*4] && cellNoList [counter3*4+1] < -999999999 && cellNoList [counter2*4+3] == cellNoList [counter3*4+3]){
                            extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                            extensionNoExtractB = to_string(extensionValueSource);
                            extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                            cellNoList [counter2*4+2] = extensionValue;
                            cellNoList [counter2*4+1] = cellNoList [counter3*4+2];
                            break;
                        }
                    }
                }
            }
            
            //for (int counterA = 0; counterA < cellNoListCount/4; counterA++){
            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<to_string(cellNoList [counterA*4+counterB]);
            //    cout<<" cellNoList "<<counterA<<endl;
            //}
            
            int findBoth = 0;
            double cellNoSummary = 0;
            double lingNoSummary = 0;
            double cellNoEntry1 = 0;
            double cellNoEntry2 = 0;
            
            for (int counter1 = 0; counter1 < cellExtractedInfoCount/9; counter1++){
                if (cellNoSummary != cellExtractedInfo [counter1*9+5] || lingNoSummary != cellExtractedInfo [counter1*9+6]){
                    cellNoSummary = cellExtractedInfo [counter1*9+5];
                    lingNoSummary = cellExtractedInfo [counter1*9+6];
                    
                    findBoth = 0;
                    cellNoEntry1 = 0;
                    cellNoEntry2 = 0;
                    
                    for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                        if (cellExtractedInfo [counter1*9+5] == cellNoList [counter2*4] && cellExtractedInfo [counter1*9+6] == cellNoList [counter2*4+3]){
                            cellNoEntry1 = cellNoList [counter2*4+2];
                            findBoth++;
                        }
                        
                        if (cellExtractedInfo [counter1*9+4] == cellNoList [counter2*4] && cellExtractedInfo [counter1*9+6] == cellNoList [counter2*4+3]){
                            cellNoEntry2 = cellNoList [counter2*4+2];
                            findBoth++;
                        }
                        
                        if (findBoth == 2){
                            break;
                        }
                    }
                    
                    cellExtractedInfo [counter1*9+5] = cellNoEntry1;
                    cellExtractedInfo [counter1*9+4] = cellNoEntry2;
                }
                else cellExtractedInfo [counter1*9+5] = cellNoEntry1;
                
                if (cellExtractedInfo [counter1*9+3] == 91 || cellExtractedInfo [counter1*9+3] == 92){
                    for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                        if (cellExtractedInfo [counter1*9+4] == cellNoList [counter2*4]){
                            cellExtractedInfo [counter1*9+4] = cellNoList [counter2*4+2];
                            break;
                        }
                    }
                }
            }
            
            double *cellExtractedInfoSummary = new double [cellExtractedInfoCount+50];
            int cellExtractedInfoSummaryCount = 0;
            
            cellNoSummary = 0;
            lingNoSummary = 0;
            
            for (int counter1 = 0; counter1 < cellExtractedInfoCount/9; counter1++){
                if (cellExtractedInfo [counter1*9+3] != 2){
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+1], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+2], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+3], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+4], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+5], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+6], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+7], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+8], cellExtractedInfoSummaryCount++;
                }
                
                if (cellNoSummary != cellExtractedInfo [counter1*9+5] || lingNoSummary != cellExtractedInfo [counter1*9+6]){
                    cellNoSummary = cellExtractedInfo [counter1*9+5];
                    lingNoSummary = cellExtractedInfo [counter1*9+6];
                    
                    if (counter1 != 0 && cellExtractedInfo [(counter1-1)*9+3] == 2){
                        cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [(counter1-1)*9], cellExtractedInfoSummaryCount++;
                        cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [(counter1-1)*9+1], cellExtractedInfoSummaryCount++;
                        cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [(counter1-1)*9+2], cellExtractedInfoSummaryCount++;
                        cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [(counter1-1)*9+3], cellExtractedInfoSummaryCount++;
                        cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [(counter1-1)*9+4], cellExtractedInfoSummaryCount++;
                        cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [(counter1-1)*9+5], cellExtractedInfoSummaryCount++;
                        cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [(counter1-1)*9+6], cellExtractedInfoSummaryCount++;
                        cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [(counter1-1)*9+7], cellExtractedInfoSummaryCount++;
                        cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [(counter1-1)*9+8], cellExtractedInfoSummaryCount++;
                    }
                }
                
                if (counter1 == cellExtractedInfoCount/9-1 && cellExtractedInfoCount/9-1 != 0){
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+1], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+2], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+3], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+4], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+5], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+6], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+7], cellExtractedInfoSummaryCount++;
                    cellExtractedInfoSummary [cellExtractedInfoSummaryCount] = cellExtractedInfo [counter1*9+8], cellExtractedInfoSummaryCount++;
                }
            }
            
            //for (int counterA = 0; counterA < cellExtractedInfoSummaryCount/9; counterA++){
            //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<to_string(cellExtractedInfoSummary[counterA*9+counterB]);
            //    cout<<" cellExtractedInfoSummary "<<counterA<<endl;
            //}
            
            int lineageFuseNo = 0;
            
            for (int counter1 = 0; counter1 < lineageLinkListLength; counter1++){
                if (arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1] != 0){
                    lineageFuseNo++;
                }
            }
            
            if (lineageFuseNo <= 3){
                string lineageNo = to_string(arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength]);
                
                for (int counter1 = 1; counter1 < lineageLinkListLength; counter1++){
                    if (arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1] != 0){
                        lineageNo = lineageNo+", "+to_string(arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1]);
                    }
                }
                
                lineageNo = "Lineage: "+lineageNo;
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(lineageNo.c_str()) attributes:attributesA];
                pointA.x = 30*magFactor;
                pointA.y = 330*magFactor;
                [attrStrA drawAtPoint:pointA];
            }
            else if (lineageFuseNo > 3 && lineageFuseNo <= 6){
                string lineageNo = "Lineage:";
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(lineageNo.c_str()) attributes:attributesA];
                pointA.x = 30*magFactor;
                pointA.y = 330*magFactor;
                [attrStrA drawAtPoint:pointA];
                
                lineageNo = to_string(arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength]);
                
                for (int counter1 = 1; counter1 < 3; counter1++){
                    if (arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1] != 0){
                        lineageNo = lineageNo+", "+to_string(arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1]);
                    }
                }
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(lineageNo.c_str()) attributes:attributesA];
                pointA.x = 85*magFactor;
                pointA.y = 337*magFactor;
                [attrStrA drawAtPoint:pointA];
                
                lineageNo = to_string(arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+3]);
                
                for (int counter1 = 4; counter1 < lineageLinkListLength; counter1++){
                    if (arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1] != 0){
                        lineageNo = lineageNo+", "+to_string(arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1]);
                    }
                }
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(lineageNo.c_str()) attributes:attributesA];
                pointA.x = 85*magFactor;
                pointA.y = 323*magFactor;
                [attrStrA drawAtPoint:pointA];
            }
            else if (lineageFuseNo > 6){
                string lineageNo = "";
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(lineageNo.c_str()) attributes:attributesA];
                pointA.x = 30*magFactor;
                pointA.y = 330*magFactor;
                [attrStrA drawAtPoint:pointA];
                
                lineageNo = to_string(arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength]);
                
                for (int counter1 = 1; counter1 < 3; counter1++){
                    if (arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1] != 0){
                        lineageNo = lineageNo+", "+to_string(arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1]);
                    }
                }
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(lineageNo.c_str()) attributes:attributesA];
                pointA.x = 85*magFactor;
                pointA.y = 337*magFactor;
                [attrStrA drawAtPoint:pointA];
                
                lineageNo = to_string(arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+3]);
                
                for (int counter1 = 4; counter1 < 6; counter1++){
                    if (arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1] != 0){
                        lineageNo = lineageNo+", "+to_string(arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter1]);
                    }
                }
                
                lineageNo = lineageNo+"+";
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(lineageNo.c_str()) attributes:attributesA];
                pointA.x = 85*magFactor;
                pointA.y = 323*magFactor;
                [attrStrA drawAtPoint:pointA];
            }
            
            //----Doubling time Calculation----
            int shortestDoublingTime = 1000000;
            int longestDoublingTime = 0;
            int meanDoublingTime = 0;
            int numberOfDoubling = 0;
            int timeTemp = 0;
            
            for (int counter1 = 0; counter1 < cellExtractedInfoSummaryCount/9; counter1++){
                if (cellExtractedInfoSummary [counter1*9+3] == 31 || cellExtractedInfoSummary [counter1*9+3] == 41 || cellExtractedInfoSummary [counter1*9+3] == 51){
                    timeTemp = (int)(cellExtractedInfoSummary [counter1*9+2]);
                    
                    for (int counter2 = 0; counter2 < cellExtractedInfoSummaryCount/9; counter2++){
                        if (cellExtractedInfoSummary [counter2*9+5] == cellExtractedInfoSummary [counter1*9+5] && cellExtractedInfoSummary [counter2*9+6] == cellExtractedInfoSummary [counter1*9+6] && (cellExtractedInfoSummary [counter2*9+3] == 32 || cellExtractedInfoSummary [counter2*9+3] == 42 || cellExtractedInfoSummary [counter2*9+3] == 52)){
                            if (cellExtractedInfoSummary [counter2*9+2]-timeTemp < shortestDoublingTime) shortestDoublingTime = (int)(cellExtractedInfoSummary [counter2*9+2]-timeTemp);
                            if (cellExtractedInfoSummary [counter2*9+2]-timeTemp > longestDoublingTime) longestDoublingTime = (int)(cellExtractedInfoSummary [counter2*9+2]-timeTemp);
                            meanDoublingTime = meanDoublingTime+(int)(cellExtractedInfoSummary [counter2*9+2]-timeTemp);
                            
                            numberOfDoubling++;
                            break;
                        }
                    }
                }
            }
            
            double shortestDoublingTimeDouble = 0;
            double longestDoublingTimeDouble = 0;
            double meanDoublingTimeDouble = 0;
            
            if (shortestDoublingTime == 1000000) shortestDoublingTime = 0;
            
            if (meanDoublingTime != 0) meanDoublingTimeDouble = meanDoublingTime/(double)numberOfDoubling;
            
            shortestDoublingTimeDouble = shortestDoublingTime*atoi(timeInterval.c_str())/(double)60;
            shortestDoublingTime = (int)(shortestDoublingTimeDouble*100);
            shortestDoublingTimeDouble = shortestDoublingTime/(double)100;
            
            longestDoublingTimeDouble = longestDoublingTime*atoi(timeInterval.c_str())/(double)60;
            longestDoublingTime = (int)(longestDoublingTimeDouble*100);
            longestDoublingTimeDouble = longestDoublingTime/(double)100;
            
            meanDoublingTimeDouble = meanDoublingTimeDouble*atoi(timeInterval.c_str())/(double)60;
            meanDoublingTime = (int)(meanDoublingTimeDouble*100);
            meanDoublingTimeDouble = meanDoublingTime/(double)100;
            
            stringstream extension1;
            extension1 << shortestDoublingTimeDouble;
            string shortestString = extension1.str();
            
            stringstream extension2;
            extension2 << longestDoublingTimeDouble;
            string longestString = extension2.str();
            
            stringstream extension3;
            extension3 << meanDoublingTimeDouble;
            string meanString = extension3.str();
            
            string doubling = "Doub. M: "+meanString;
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(doubling.c_str()) attributes:attributesA];
            pointA.x = 200*magFactor;
            pointA.y = 323*magFactor;
            [attrStrA drawAtPoint:pointA];
            
            if (longestString == "0") doubling = "Doub. T : 0";
            else doubling = "Doub. T : "+shortestString+"-"+longestString;
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(doubling.c_str()) attributes:attributesA];
            pointA.x = 200*magFactor;
            pointA.y = 337*magFactor;
            [attrStrA drawAtPoint:pointA];
            
            //----Lineage display Horizontal set----
            [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            
            int numberOfCellEntry = 0;
            int numberOfEventCount = 0;
            
            for (int counter1 = 0; counter1 < cellExtractedInfoSummaryCount/9; counter1++){
                if (cellExtractedInfoSummary [counter1*9+3] == 1 || cellExtractedInfoSummary [counter1*9+3] == 31 || cellExtractedInfoSummary [counter1*9+3] == 41 || cellExtractedInfoSummary [counter1*9+3] == 51){
                    numberOfCellEntry++;
                    numberOfEventCount++;
                }
                
                if (cellExtractedInfoSummary [counter1*9+3] == 32 || cellExtractedInfoSummary [counter1*9+3] == 42 || cellExtractedInfoSummary [counter1*9+3] == 52 || cellExtractedInfoSummary [counter1*9+3] == 91 || cellExtractedInfoSummary [counter1*9+3] == 6 || cellExtractedInfoSummary [counter1*9+3] == 92 || cellExtractedInfoSummary [counter1*9+3] == 8 || cellExtractedInfoSummary [counter1*9+3] == 10 || cellExtractedInfoSummary[counter1*9+3] == 11 || cellExtractedInfoSummary [counter1*9+3] == 7){
                    numberOfEventCount++;
                }
            }
            
            double *horizontalList = new double [numberOfCellEntry*7+50];
            int horizontalListCount = 0;
            double *eventList = new double [numberOfEventCount*5+50];
            int eventListCount = 0;
            int largestTimePoint = 0;
            int findFlag = 0;
            
            for (int counter1 = 0; counter1 < cellExtractedInfoSummaryCount/9; counter1++){
                if (cellExtractedInfoSummary [counter1*9+3] == 1 || cellExtractedInfoSummary [counter1*9+3] == 31 || cellExtractedInfoSummary [counter1*9+3] == 41 || cellExtractedInfoSummary [counter1*9+3] == 51){
                    horizontalList [horizontalListCount] = cellExtractedInfoSummary [counter1*9+5], horizontalListCount++;
                    horizontalList [horizontalListCount] = cellExtractedInfoSummary [counter1*9+6], horizontalListCount++;
                    horizontalList [horizontalListCount] = cellExtractedInfoSummary [counter1*9+8], horizontalListCount++;
                    horizontalList [horizontalListCount] = cellExtractedInfoSummary [counter1*9+2], horizontalListCount++;
                    
                    largestTimePoint = 0;
                    findFlag = 0;
                    
                    for (int counter2 = counter1; counter2 < cellExtractedInfoSummaryCount/9; counter2++){
                        if ((cellExtractedInfoSummary [counter2*9+3] == 32 || cellExtractedInfoSummary [counter2*9+3] == 42 || cellExtractedInfoSummary [counter2*9+3] == 52 || cellExtractedInfoSummary [counter2*9+3] == 91 || cellExtractedInfoSummary [counter2*9+3] == 6 || cellExtractedInfoSummary [counter2*9+3] == 92 || cellExtractedInfoSummary [counter2*9+3] == 8 || cellExtractedInfoSummary [counter2*9+3] == 10 || cellExtractedInfoSummary [counter2*9+3] == 11 || cellExtractedInfoSummary [counter2*9+3] == 7) && cellExtractedInfoSummary [counter2*9+5] == cellExtractedInfoSummary [counter1*9+5] && cellExtractedInfoSummary [counter2*9+6] == cellExtractedInfoSummary [counter1*9+6]){
                            eventList [eventListCount] = cellExtractedInfoSummary [counter2*9+5], eventListCount++;
                            eventList [eventListCount] = cellExtractedInfoSummary [counter2*9+6], eventListCount++;
                            eventList [eventListCount] = cellExtractedInfoSummary [counter2*9+2], eventListCount++;
                            eventList [eventListCount] = cellExtractedInfoSummary [counter2*9+3], eventListCount++;
                            eventList [eventListCount] = 0, eventListCount++;
                        }
                    }
                    
                    for (int counter2 = 0; counter2 < cellExtractedInfoSummaryCount/9; counter2++){
                        if ((cellExtractedInfoSummary [counter2*9+3] == 32 || cellExtractedInfoSummary [counter2*9+3] == 42 || cellExtractedInfoSummary [counter2*9+3] == 52 || cellExtractedInfoSummary [counter2*9+3] == 91) && cellExtractedInfoSummary [counter2*9+5] == cellExtractedInfoSummary [counter1*9+5] && cellExtractedInfoSummary [counter2*9+6] == cellExtractedInfoSummary [counter1*9+6]){
                            horizontalList [horizontalListCount] = cellExtractedInfoSummary [counter2*9+2], horizontalListCount++;
                            horizontalList [horizontalListCount] = cellExtractedInfoSummary [counter2*9+3], horizontalListCount++;
                            findFlag = 1;
                            break;
                        }
                        else{
                            
                            if (cellExtractedInfoSummary [counter2*9+5] == cellExtractedInfoSummary [counter1*9+5] && cellExtractedInfoSummary [counter2*9+6] == cellExtractedInfoSummary [counter1*9+6]){
                                if (cellExtractedInfoSummary [counter2*9+2] > largestTimePoint) largestTimePoint = (int)(cellExtractedInfoSummary [counter2*9+2]);
                            }
                        }
                    }
                    
                    if (findFlag == 0){
                        horizontalList [horizontalListCount] = largestTimePoint, horizontalListCount++;
                        horizontalList [horizontalListCount] = 2, horizontalListCount++;
                    }
                    
                    if (cellExtractedInfoSummary [counter1*9+3] == 1) horizontalList [horizontalListCount] = 1, horizontalListCount++;
                    else horizontalList [horizontalListCount] = 0, horizontalListCount++;
                }
            }
            
            //for (int counterA = 0; counterA < horizontalListCount/7; counterA++){
            //    cout<<to_string(horizontalList [counterA*7])<<" "<<horizontalList [counterA*7+1]<<" "<<horizontalList [counterA*7+2]<<" "<<horizontalList [counterA*7+3]<<" "<<horizontalList [counterA*7+4]<<" horizontalList"<<endl;
            //}
            
            //for (int counterA = 0; counterA < eventListCount/5; counterA++){
            //    cout<<counterA<<" "<<to_string(eventList [counterA*5])<<" "<<eventList [counterA*5+1]<<" "<< eventList [counterA*5+2]<<" "<<eventList [counterA*5+3]<<" "<<eventList [counterA*5+4]<<"   eventList"<<endl;
            //}
            
            int terminationFlag = 0;
            int lineageSelect = 0;
            int cellSelectPosition = 0;
            double cellSelect = 0;
            
            double *horizontalList2 = new double [numberOfCellEntry*7+50];
            int horizontalListCount2 = 0;
            double *eventList2 = new double [numberOfEventCount*6+50];
            
            int eventListCount2 = 0;
            
            for (int counter1 = 0; counter1 < numberOfEventCount*6+50; counter1++) eventList2 [counter1] = 0;
            
            int entryOrder = 0;
            
            do{
                
                terminationFlag = 1;
                lineageSelect = 100000;
                
                for (int counter1 = 0; counter1 < horizontalListCount/7; counter1++){
                    if (horizontalList [counter1*7+1] != -1){
                        lineageSelect = (int)(horizontalList [counter1*7+1]);
                        break;
                    }
                }
                
                if (lineageSelect == 100000) terminationFlag = 0;
                else{
                    
                    cellSelect = 999999999999999;
                    cellSelectPosition = 0;
                    
                    for (int counter1 = 0; counter1 < horizontalListCount/7; counter1++){
                        if (horizontalList [counter1*7] != -1 && horizontalList [counter1*7+1] == lineageSelect && horizontalList [counter1*7] < cellSelect){
                            cellSelect = horizontalList [counter1*7];
                            cellSelectPosition = counter1;
                        }
                    }
                    
                    if (cellSelect != 999999999999999){
                        horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7], horizontalListCount2++; //----Cell no---
                        horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+1], horizontalListCount2++; //----Ling no----
                        horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+2], horizontalListCount2++; //----Rev cell no----
                        horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+3], horizontalListCount2++; //----Time start----
                        horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+4], horizontalListCount2++; //----Time end----
                        horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+5], horizontalListCount2++; //----Event last----
                        horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+6], horizontalListCount2++; //----Event I----
                        
                        for (int counter1 = 0; counter1 < eventListCount/5; counter1++){
                            if (eventList [counter1*5] == horizontalList [cellSelectPosition*7] && eventList [counter1*5+1] == horizontalList [cellSelectPosition*7+1]){
                                eventList2 [eventListCount2] = eventList [counter1*5], eventListCount2++; //----Cell no----
                                eventList2 [eventListCount2] = eventList [counter1*5+1], eventListCount2++; //----Ling no----
                                eventList2 [eventListCount2] = eventList [counter1*5+2], eventListCount2++; //----Time----
                                eventList2 [eventListCount2] = eventList [counter1*5+3], eventListCount2++; //----Event----
                                eventList2 [eventListCount2] = entryOrder, eventListCount2++; //----Entry order----
                                break;
                            }
                        }
                        
                        horizontalList [cellSelectPosition*7] = -1;
                        horizontalList [cellSelectPosition*7+1] = -1;
                        
                        entryOrder++;
                    }
                }
                
            } while (terminationFlag == 1);
            
            //for (int counterA = 0; counterA < horizontalListCount2/7; counterA++){
            //    cout<<to_string(horizontalList2 [counterA*7])<<" "<<to_string(horizontalList2 [counterA*7+1])<<" "<<horizontalList2 [counterA*7+2]<<" "<<horizontalList2 [counterA*7+3]<<" "<<horizontalList2 [counterA*7+4]<<" horizontalList2"<<endl;
            //}
            
            //----Lineage display Vertical set----
            double *verticalList = new double [numberOfEventCount*9+50];
            int verticalListCount = 0;
            
            double parentCellNo = 0;
            double cellNoLow = 0;
            double cellNoHigh = 0;
            int cellNoLowPosition = 0;
            int cellNoHighPosition = 0;
            int matchFindFlag = 0;
            
            for (int counter1 = 0; counter1 < cellExtractedInfoSummaryCount/9; counter1++){
                if (cellExtractedInfoSummary [counter1*9+3] == 91){
                    matchFindFlag = 0;
                    
                    for (int counter2 = 0; counter2 < verticalListCount/9; counter2++){
                        if ((verticalList [counter2*9] == cellExtractedInfoSummary [counter1*9+5] && verticalList [counter2*9+1] == cellExtractedInfoSummary [counter1*9+6] && verticalList [counter2*9+2] == cellExtractedInfoSummary [counter1*9+2]) || (verticalList [counter2*9+3] == cellExtractedInfoSummary [counter1*9+5] && verticalList [counter2*9+4] == cellExtractedInfoSummary [counter1*9+6] && verticalList [counter2*9+5] == cellExtractedInfoSummary [counter1*9+2])){
                            matchFindFlag = 1;
                        }
                    }
                    
                    if (matchFindFlag == 0){
                        for (int counter2 = 0; counter2 < cellExtractedInfoSummaryCount/9; counter2++){
                            if (cellExtractedInfoSummary [counter2*9+3] == 92 && cellExtractedInfoSummary [counter1*9+4] == cellExtractedInfoSummary [counter2*9+5] && cellExtractedInfoSummary [counter1*9+7] == cellExtractedInfoSummary [counter2*9+6] && cellExtractedInfoSummary [counter2*9+2] == cellExtractedInfoSummary [counter1*9+2]){
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+5], verticalListCount++;
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+6], verticalListCount++;
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+2], verticalListCount++;
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+5], verticalListCount++;
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+6], verticalListCount++;
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+2], verticalListCount++;
                                verticalList [verticalListCount] = 0, verticalListCount++;
                                verticalList [verticalListCount] = 0, verticalListCount++;
                                verticalList [verticalListCount] = 91, verticalListCount++;
                                
                                break;
                            }
                        }
                    }
                }
                else if (cellExtractedInfoSummary [counter1*9+3] == 92){
                    matchFindFlag = 0;
                    
                    for (int counter2 = 0; counter2 < verticalListCount/9; counter2++){
                        if ((verticalList [counter2*9] == cellExtractedInfoSummary [counter1*9+5] && verticalList [counter2*9+1] == cellExtractedInfoSummary [counter1*9+6] && verticalList [counter2*9+2] == cellExtractedInfoSummary [counter1*9+2]) || (verticalList [counter2*9+3] == cellExtractedInfoSummary [counter1*9+5] && verticalList [counter2*9+4] == cellExtractedInfoSummary [counter1*9+6] && verticalList [counter2*9+5] == cellExtractedInfoSummary [counter1*9+2])){
                            matchFindFlag = 1;
                        }
                    }
                    
                    if (matchFindFlag == 0){
                        for (int counter2 = 0; counter2 < cellExtractedInfoSummaryCount/9; counter2++){
                            if (cellExtractedInfoSummary [counter2*9+3] == 91 && cellExtractedInfoSummary [counter1*9+4] == cellExtractedInfoSummary [counter2*9+5] && cellExtractedInfoSummary [counter1*9+7] == cellExtractedInfoSummary [counter2*9+6] && cellExtractedInfoSummary [counter2*9+2] == cellExtractedInfoSummary [counter1*9+2]){
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+5], verticalListCount++;
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+6], verticalListCount++;
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+2], verticalListCount++;
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+5], verticalListCount++;
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+6], verticalListCount++;
                                verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+2], verticalListCount++;
                                verticalList [verticalListCount] = 0, verticalListCount++;
                                verticalList [verticalListCount] = 0, verticalListCount++;
                                verticalList [verticalListCount] = 91, verticalListCount++;
                                
                                break;
                            }
                        }
                    }
                }
                else if (cellExtractedInfoSummary [counter1*9+3] == 31){
                    parentCellNo = cellExtractedInfoSummary [counter1*9+4];
                    matchFindFlag = 0;
                    
                    for (int counter2 = 0; counter2 < verticalListCount/9; counter2++){
                        if ((verticalList [counter2*9] == cellExtractedInfoSummary [counter1*9+5] && verticalList [counter2*9+1] == cellExtractedInfoSummary [counter1*9+6] && verticalList [counter2*9+2] == cellExtractedInfoSummary [counter1*9+2]) || (verticalList [counter2*9+3] == cellExtractedInfoSummary [counter1*9+5] && verticalList [counter2*9+4] == cellExtractedInfoSummary [counter1*9+6] && verticalList [counter2*9+5] == cellExtractedInfoSummary [counter1*9+2])){
                            matchFindFlag = 1;
                        }
                    }
                    
                    if (matchFindFlag == 0){
                        for (int counter2 = 0; counter2 < cellExtractedInfoSummaryCount/9; counter2++){
                            if (cellExtractedInfoSummary [counter2*9+3] == 31 && cellExtractedInfoSummary [counter1*9+6] == cellExtractedInfoSummary [counter2*9+6] && cellExtractedInfoSummary [counter2*9+4] == parentCellNo && cellExtractedInfoSummary [counter2*9+5] != cellExtractedInfoSummary [counter1*9+5] && cellExtractedInfoSummary [counter2*9+2] == cellExtractedInfoSummary [counter1*9+2]){
                                
                                if (cellExtractedInfoSummary [counter2*9+5] > cellExtractedInfoSummary [counter1*9+5]){
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+5], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+6], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+2], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+5], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+6], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+2], verticalListCount++;
                                    verticalList [verticalListCount] = 0, verticalListCount++;
                                    verticalList [verticalListCount] = 0, verticalListCount++;
                                    verticalList [verticalListCount] = 31, verticalListCount++;
                                }
                                else{
                                    
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+5], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+6], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter2*9+2], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+5], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+6], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfoSummary [counter1*9+2], verticalListCount++;
                                    verticalList [verticalListCount] = 0, verticalListCount++;
                                    verticalList [verticalListCount] = 0, verticalListCount++;
                                    verticalList [verticalListCount] = 31, verticalListCount++;
                                }
                                
                                break;
                            }
                        }
                    }
                }
                else if (cellExtractedInfoSummary [counter1*9+3] == 41){
                    parentCellNo = cellExtractedInfoSummary [counter1*9+4];
                    cellNoLow = cellExtractedInfoSummary [counter1*9+5];
                    cellNoHigh = cellExtractedInfoSummary [counter1*9+5];
                    cellNoLowPosition = counter1;
                    cellNoHighPosition = counter1;
                    
                    matchFindFlag = 0;
                    
                    for (int counter2 = 0; counter2 < verticalListCount/9; counter2++){
                        if ((verticalList [counter2*9] == cellExtractedInfoSummary [counter1*9+5] && verticalList [counter2*9+1] == cellExtractedInfoSummary [counter1*9+6] && verticalList [counter2*9+2] == cellExtractedInfoSummary [counter1*9+2]) || (verticalList [counter2*9+3] == cellExtractedInfoSummary [counter1*9+5] && verticalList [counter2*9+4] == cellExtractedInfoSummary [counter1*9+6] && verticalList [counter2*9+5] == cellExtractedInfoSummary [counter1*9+2])){
                            matchFindFlag = 1;
                        }
                    }
                    
                    if (matchFindFlag == 0){
                        for (int counter2 = 0; counter2 < cellExtractedInfoSummaryCount/9; counter2++){
                            if (cellExtractedInfoSummary [counter2*9+3] == 41 && cellExtractedInfoSummary [counter1*9+6] == cellExtractedInfoSummary [counter2*9+6] && cellExtractedInfoSummary [counter2*9+4] == parentCellNo && cellExtractedInfoSummary [counter2*9+5] != cellExtractedInfoSummary [counter1*9+5]){
                                if (cellExtractedInfoSummary [counter2*9+5] > cellNoHigh){
                                    cellNoHigh = cellExtractedInfoSummary [counter2*9+5];
                                    cellNoHighPosition = counter2;
                                }
                                
                                if (cellExtractedInfoSummary [counter2*9+5] < cellNoLow){
                                    cellNoHigh = cellExtractedInfoSummary [counter2*9+5];
                                    cellNoLowPosition = counter2;
                                }
                            }
                        }
                        
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoLowPosition*9+5], verticalListCount++;
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoLowPosition*9+6], verticalListCount++;
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoLowPosition*9+2], verticalListCount++;
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoHighPosition*9+5], verticalListCount++;
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoHighPosition*9+6], verticalListCount++;
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoHighPosition*9+2], verticalListCount++;
                        verticalList [verticalListCount] = 0, verticalListCount++;
                        verticalList [verticalListCount] = 0, verticalListCount++;
                        verticalList [verticalListCount] = 41, verticalListCount++;
                    }
                }
                else if (cellExtractedInfoSummary [counter1*9+3] == 51){
                    parentCellNo = cellExtractedInfoSummary [counter1*9+4];
                    cellNoLow = cellExtractedInfoSummary [counter1*9+5];
                    cellNoHigh = cellExtractedInfoSummary [counter1*9+5];
                    cellNoLowPosition = counter1;
                    cellNoHighPosition = counter1;
                    
                    matchFindFlag = 0;
                    
                    for (int counter2 = 0; counter2 < verticalListCount/9; counter2++){
                        if ((verticalList [counter2*9] == cellExtractedInfoSummary [counter1*9+5] && verticalList [counter2*9+1] == cellExtractedInfoSummary [counter1*9+6] && verticalList [counter2*9+2] == cellExtractedInfoSummary [counter1*9+2]) || (verticalList [counter2*9+3] == cellExtractedInfoSummary [counter1*9+5] && verticalList [counter2*9+4] == cellExtractedInfoSummary [counter1*9+6] && verticalList [counter2*9+5] == cellExtractedInfoSummary [counter1*9+2])){
                            matchFindFlag = 1;
                        }
                    }
                    
                    if (matchFindFlag == 0){
                        for (int counter2 = 0; counter2 < cellExtractedInfoSummaryCount/9; counter2++){
                            if (cellExtractedInfoSummary [counter2*9+3] == 51 && cellExtractedInfoSummary [counter1*9+6] == cellExtractedInfoSummary [counter2*9+6] && cellExtractedInfoSummary [counter2*9+4] == parentCellNo && cellExtractedInfoSummary [counter2*9+5] != cellExtractedInfoSummary [counter1*9+5]){
                                
                                if (cellExtractedInfoSummary [counter2*9+5] > cellNoHigh){
                                    cellNoHigh = cellExtractedInfoSummary [counter2*9+5];
                                    cellNoHighPosition = counter2;
                                }
                                
                                if (cellExtractedInfoSummary [counter2*9+5] < cellNoLow){
                                    cellNoLow = cellExtractedInfoSummary [counter2*9+5];
                                    cellNoLowPosition = counter2;
                                }
                            }
                        }
                        
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoLowPosition*9+5], verticalListCount++; //----Cell no 1----
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoLowPosition*9+6], verticalListCount++; //----Ling no 1----
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoLowPosition*9+2], verticalListCount++; //----Time 1----
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoHighPosition*9+5], verticalListCount++; //----Cell no 2----
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoHighPosition*9+6], verticalListCount++; //----Ling no 2----
                        verticalList [verticalListCount] = cellExtractedInfoSummary [cellNoHighPosition*9+2], verticalListCount++; //----Time 2----
                        verticalList [verticalListCount] = 0, verticalListCount++; //----Cell order 1----
                        verticalList [verticalListCount] = 0, verticalListCount++; //----Cell order 2----
                        verticalList [verticalListCount] = 51, verticalListCount++; //----Event----
                    }
                }
            }
            
            //for (int counterA = 0; counterA < verticalListCount/9; counterA++){
            //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<< to_string(verticalList [counterA*9+counterB]);
            //    cout<<" verticalList "<<counterA<<endl;
            //}
            
            for (int counter1 = 0; counter1 < verticalListCount/9; counter1++){
                for (int counter2 = 0; counter2 < horizontalListCount2/7; counter2++){
                    if (horizontalList2 [counter2*7] == verticalList [counter1*9] && horizontalList2 [counter2*7+1] == verticalList [counter1*9+1]){
                        verticalList [counter1*9+6] = counter2;
                        break;
                    }
                }
                
                for (int counter2 = 0; counter2 < horizontalListCount2/7; counter2++){
                    if (horizontalList2 [counter2*7] == verticalList [counter1*9+3] && horizontalList2 [counter2*7+1] == verticalList [counter1*9+4]){
                        verticalList [counter1*9+7] = counter2;
                        break;
                    }
                }
            }
            
            //for (int counterA = 0; counterA < verticalListCount/9; counterA++){
            //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<< to_string(verticalList [counterA*9+counterB]);
            //    cout<<" verticalList "<<counterA<<endl;
            //}
            
            double increment = (295-52)/(double)(numberOfCellEntry+1);
            double horizontalIncrement = (750-40)/(double)horizontalTime;
            
            [attributesA setObject:[NSFont boldSystemFontOfSize:9*magFactor] forKey:NSFontAttributeName];
            
            //for (int counterA = 0; counterA < eventListCount2/5; counterA++){
            //    cout<<eventList2 [counterA*5]<<" "<<eventList2 [counterA*5+1]<<" "<< eventList2 [counterA*5+2]<<" "<<eventList2 [counterA*5+3]<<" "<<eventList2 [counterA*5+4]<<"   eventList2"<<endl;
            //}
            
            //----Live vertical line----
            int roundNoGet = 0;
            int ifDataEntryGet = arrayIFTimeLineDataEntryHold [tableCurrentRowHold];
            int positionShiftA = 0;
            
            int *liveTimeList = new int [ifDataEntryGet/9+1];
            int liveTimeListCount = 0;
            
            //for (int counterA = 0; counterA < arrayIFTimeLineDataEntryHold [tableCurrentRowHold]/6; counterA++){
            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayIFTimeLineData [tableCurrentRowHold][counterA*6+counterB];
            //    cout<<" arrayIFTimeLineData "<<counterA<<endl;
            //}
            
            for (int counter1 = 0; counter1 < ifDataEntryGet/9; counter1++){
                if (arrayIFTimeLineData [tableCurrentRowHold][counter1*9+1] == -1){
                    liveTimeList [liveTimeListCount] = arrayIFTimeLineData [tableCurrentRowHold][counter1*9], liveTimeListCount++;
                    
                    if (blueLineFlag == 0){
                        [[NSColor blueColor] set];
                        
                        positionAA.x = 40*magFactor+arrayIFTimeLineData [tableCurrentRowHold][counter1*9]*horizontalIncrement*magFactor;
                        positionAA.y = 40*magFactor;
                        positionBB.x = 40*magFactor+arrayIFTimeLineData [tableCurrentRowHold][counter1*9]*horizontalIncrement*magFactor;
                        positionBB.y = 295*magFactor;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        if (to_string(arrayIFTimeLineData [tableCurrentRowHold][counter1*9]).length() == 1) positionShiftA = 2;
                        else if (to_string(arrayIFTimeLineData [tableCurrentRowHold][counter1*9]).length() == 2) positionShiftA = 4;
                        else if (to_string(arrayIFTimeLineData [tableCurrentRowHold][counter1*9]).length() == 3) positionShiftA = 6;
                        else if (to_string(arrayIFTimeLineData [tableCurrentRowHold][counter1*9]).length() == 4) positionShiftA = 8;
                        
                        attrStrA = [[NSAttributedString alloc] initWithString:@(to_string(arrayIFTimeLineData [tableCurrentRowHold][counter1*9]).c_str()) attributes:attributesA];
                        pointA.x = 40*magFactor+arrayIFTimeLineData [tableCurrentRowHold][counter1*9]*horizontalIncrement*magFactor-positionShiftA*magFactor;
                        pointA.y = 296*magFactor;
                        [attrStrA drawAtPoint:pointA];
                    }
                }
                
                if (arrayIFTimeLineData [tableCurrentRowHold][counter1*9] == ifCurrentTime) roundNoGet = arrayIFTimeLineData [tableCurrentRowHold][counter1*9+1];
            }
            
            if (ifDataExtractCount > 7){
                [[NSColor blackColor] set];
                
                positionAA.x = 40*magFactor+(ifDataExtract [7]-1)*horizontalIncrement*magFactor;
                positionAA.y = 40*magFactor;
                positionBB.x = 40*magFactor+(ifDataExtract [7]-1)*horizontalIncrement*magFactor;
                positionBB.y = 295*magFactor;
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                
                if (to_string(ifDataExtract [7]-1).length() == 1) positionShiftA = 2;
                else if (to_string(ifDataExtract [7]-1).length() == 2) positionShiftA = 5;
                else if (to_string(ifDataExtract [7]-1).length() == 3) positionShiftA = 8;
                else if (to_string(ifDataExtract [7]-1).length() == 4) positionShiftA = 11;
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(to_string(ifDataExtract [7]-1).c_str()) attributes:attributesA];
                pointA.x = 40*magFactor+(ifDataExtract [7]-1)*horizontalIncrement*magFactor-positionShiftA*magFactor;
                pointA.y = 296*magFactor;
                [attrStrA drawAtPoint:pointA];
            }
            
            //----Lineage Display Vertical----
            string ifTimePoint1;
            
            if (lineWidthFlag == 0) [NSBezierPath setDefaultLineWidth:2*magFactor];
            else if (lineWidthFlag == 1) [NSBezierPath setDefaultLineWidth:1*magFactor];
            else if (lineWidthFlag == 2) [NSBezierPath setDefaultLineWidth:0.5*magFactor];
            else if (lineWidthFlag == 3) [NSBezierPath setDefaultLineWidth:5*magFactor];
            else if (lineWidthFlag == 4) [NSBezierPath setDefaultLineWidth:4*magFactor];
            else if (lineWidthFlag == 5) [NSBezierPath setDefaultLineWidth:3*magFactor];
            
            for (int counter1 = 0; counter1 < verticalListCount/9; counter1++){
                if (verticalList [counter1*9+8] == 91) [[NSColor orangeColor] set];
                else if (verticalList [counter1*9+8] == 31) [[NSColor blackColor] set];
                else if (verticalList [counter1*9+8] == 41) [[NSColor redColor] set];
                else if (verticalList [counter1*9+8] == 51) [[NSColor redColor] set];
                
                positionAA.x = 40*magFactor+verticalList [counter1*9+2]*horizontalIncrement*magFactor;
                positionAA.y = 52*magFactor+increment*magFactor+verticalList [counter1*9+6]*increment*magFactor;
                positionBB.x = 40*magFactor+verticalList [counter1*9+5]*horizontalIncrement*magFactor;
                positionBB.y = 52*magFactor+increment*magFactor+verticalList [counter1*9+7]*increment*magFactor;
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
            }
            
            [attributesA setObject:[NSFont boldSystemFontOfSize:9*magFactor] forKey:NSFontAttributeName];
            
            //----Lineage Display Horizontal----
            int findMainLength = arrayTableMainHold [tableCurrentRowHold];
            
            //----Color data range get----
            int rangeLiveAverageLow = 0;
            int rangeLiveAverageHigh = 0;
            int rangeLiveTotalLow = 0;
            int rangeLiveTotalHigh = 0;
            
            if (liveCurrentCHNo != 0){
                string liveName = "";
                
                if (liveCurrentCHNo == 1) liveName = arrayTableMain [tableCurrentRowHold][6];
                else if (liveCurrentCHNo == 2) liveName = arrayTableMain [tableCurrentRowHold][7];
                else if (liveCurrentCHNo == 3) liveName = arrayTableMain [tableCurrentRowHold][8];
                else if (liveCurrentCHNo == 4) liveName = arrayTableMain [tableCurrentRowHold][9];
                else if (liveCurrentCHNo == 5) liveName = arrayTableMain [tableCurrentRowHold][10];
                else if (liveCurrentCHNo == 6) liveName = arrayTableMain [tableCurrentRowHold][11];
                
                for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryCount; counter1++){
                    if (atoi(arrayLineageFluorescentDataType [counter1][0].c_str()) == tableCurrentRowHold+1 && arrayLineageFluorescentDataType [counter1][1] == "Live" && arrayLineageFluorescentDataType [counter1][2] == liveName){
                        rangeLiveTotalLow = atoi(arrayLineageFluorescentDataType [counter1][6].c_str());
                        rangeLiveTotalHigh = atoi(arrayLineageFluorescentDataType [counter1][7].c_str());
                        rangeLiveAverageLow = atoi(arrayLineageFluorescentDataType [counter1][4].c_str());
                        rangeLiveAverageHigh = atoi(arrayLineageFluorescentDataType [counter1][5].c_str());
                        break;
                    }
                }
            }
            
            //for (int counterA = 0; counterA < liveTimeListCount; counterA++){
            //    cout<<counterA<<" "<<liveTimeList [counterA] <<" liveTimeList"<<endl;
            //}
            
            int endType = 0;
            int startType = 0;
            int liveColorStart = 0;
            int liveColorEnd = 0;
            int liveValueGet = 0;
            int rangeNo = 0;
            int rangeNoHold = 0;
            int timeHold = 0;
            int timeHold2 = 0;
            int differenceInt = 0;
            int cellNoOriginal = 0;
            
            double rangeDivision = 0;
            double difference = 0;
            double difference2 = 0;
            double markerSizeSet = 0;
            
            string liveName = "";
            string cellNumberString;
            
            NSBezierPath *pathCircle;
            
            double *rangeList = new double [horizontalTime*3+30];
            int rangeListCount = 0;
            
            if (markSizeFlag == 0) markerSizeSet = 12;
            else if (markSizeFlag == 1) markerSizeSet = 6;
            else if (markSizeFlag == 2) markerSizeSet = 0;
            
            string horizontalString;
            
            for (int counter1 = 0; counter1 < horizontalListCount2/7; counter1++){
                [[NSColor blackColor] set];
                
                cellNoOriginal = 0;
                
                for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                    if (horizontalList2 [counter1*7] == cellNoList [counter2*4+2]){
                        cellNoOriginal = (int)(cellNoList [counter2*4]);
                        break;
                    }
                }
                
                if (horizontalList2 [counter1*7+5] == 32 || horizontalList2 [counter1*7+3] == 42 || horizontalList2 [counter1*7+3] == 52) endType = 1;
                else endType = 0;
                
                if (horizontalList2 [counter1*7+6] == 1) startType = 1;
                else startType = 0;
                
                //cout<<counter1<<" "<<horizontalList2 [counter1*7]<<" "<<horizontalList2 [counter1*7+1]<<" TimeStartEnd"<<endl;
                
                //----Color data drawing----
                if (liveCurrentCHNo == 0){
                    if (fusionSetCount == 1){
                        if (xPointDownDisplay >= 40+horizontalList2 [counter1*7+3]*horizontalIncrement && xPointDownDisplay <= 40+horizontalList2 [counter1*7+4]*horizontalIncrement && yPointDownDisplay >= 52+increment+counter1*increment-4 && yPointDownDisplay <= 52+increment+counter1*increment+4){
                            
                            [[NSColor redColor] set];
                            
                            fusionSetCount = 2;
                            lingNoForFuse1 = (int)(horizontalList2 [counter1*7+1]);
                            
                            cellNoForFuse1 = cellNoOriginal;
                            cellNoCurrent1 = horizontalList2 [counter1*7];
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                    }
                    else if (fusionSetCount == 2 && (lingNoForFuse1 != horizontalList2 [counter1*7+1] || cellNoForFuse1 != horizontalList2 [counter1*7])){
                        if (xPointDownDisplay >= 40+horizontalList2 [counter1*7+3]*horizontalIncrement && xPointDownDisplay <= 40+horizontalList2 [counter1*7+4]*horizontalIncrement && yPointDownDisplay >= 52+increment+counter1*increment-4 && yPointDownDisplay <= 52+increment+counter1*increment+4){
                            [[NSColor blueColor] set];
                            
                            fusionSetCount = 3;
                            lingNoForFuse2 = (int)(horizontalList2 [counter1*7+1]);
                            
                            cellNoForFuse2 = cellNoOriginal;
                            cellNoCurrent2 = horizontalList2 [counter1*7];
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                    }
                    
                    if (fusionSetCount >= 2 && lingNoForFuse1 == horizontalList2 [counter1*7+1] && cellNoCurrent1 == horizontalList2 [counter1*7] && (lingNoForFuse2 != horizontalList2 [counter1*7+1] || cellNoCurrent2 != horizontalList2 [counter1*7])){
                        [[NSColor redColor] set];
                    }
                    
                    if (fusionSetCount >= 2 && lingNoForFuse2 == horizontalList2 [counter1*7+1] && cellNoCurrent2 == horizontalList2 [counter1*7] && (lingNoForFuse1 != horizontalList2 [counter1*7+1] || cellNoCurrent1 != horizontalList2 [counter1*7])){
                        [[NSColor blueColor] set];
                    }
                    
                    positionAA.x = 40*magFactor+horizontalList2 [counter1*7+3]*horizontalIncrement*magFactor;
                    positionAA.y = 52*magFactor+increment*magFactor+counter1*increment*magFactor;
                    
                    if (endType == 1) positionBB.x = 40*magFactor+(horizontalList2 [counter1*7+4]+1)*horizontalIncrement*magFactor;
                    else positionBB.x = 40*magFactor+horizontalList2 [counter1*7+4]*horizontalIncrement*magFactor;
                    
                    positionBB.y = 52*magFactor+increment*magFactor+counter1*increment*magFactor;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                }
                else{
                    
                    liveColorStart = -1;
                    liveColorEnd = -1;
                    
                    for (int counter2 = 0; counter2 < liveTimeListCount; counter2++){
                        if (liveColorStart == -1 && liveTimeList [counter2] >= horizontalList2 [counter1*7+3]) liveColorStart = counter2;
                        if (liveTimeList [counter2] <= horizontalList2 [counter1*7+4]) liveColorEnd = counter2;
                    }
                    
                    if (liveColorStart != -1 && liveColorStart == liveColorEnd){
                        liveValueGet = 0;
                        
                        for (int counter2 = 0; counter2 < ifValueExtractCount/22; counter2++){
                            if (cellNoOriginal == ifValueExtract [counter2*22] && (int)(horizontalList2 [counter1*7+1]) == ifValueExtract [counter2*22+1] && liveTimeList [liveColorStart] == ifValueExtract [counter2*22+2]){
                                
                                if (liveCurrentCHNo == 1){
                                    if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter2*22+5];
                                    else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter2*22+5]*ifValueExtract [counter2*22+6];
                                }
                                else if (liveCurrentCHNo == 2){
                                    if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter2*22+8];
                                    else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter2*22+8]*ifValueExtract [counter2*22+9];
                                }
                                else if (liveCurrentCHNo == 3){
                                    if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter2*22+11];
                                    else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter2*22+11]*ifValueExtract [counter2*22+12];
                                }
                                else if (liveCurrentCHNo == 4){
                                    if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter2*22+14];
                                    else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter2*22+14]*ifValueExtract [counter2*22+15];
                                }
                                else if (liveCurrentCHNo == 5){
                                    if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter2*22+17];
                                    else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter2*22+17]*ifValueExtract [counter2*22+18];
                                }
                                else if (liveCurrentCHNo == 6){
                                    if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter2*22+20];
                                    else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter2*22+20]*ifValueExtract [counter2*22+21];
                                }
                                
                                break;
                            }
                        }
                        
                        if (averageTotalFlag == 0){
                            rangeDivision = (rangeLiveAverageHigh-rangeLiveAverageLow)/(double)25;
                            
                            if (liveValueGet < rangeLiveAverageLow+rangeDivision) rangeNo = 1;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*2) rangeNo = 2;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*3) rangeNo = 3;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*4) rangeNo = 4;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*5) rangeNo = 5;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*6) rangeNo = 6;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*7) rangeNo = 7;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*8) rangeNo = 8;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*9) rangeNo = 9;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*10) rangeNo = 10;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*11) rangeNo = 11;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*12) rangeNo = 12;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*13) rangeNo = 13;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*14) rangeNo = 14;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*15) rangeNo = 15;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*16) rangeNo = 16;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*17) rangeNo = 17;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*18) rangeNo = 18;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*19) rangeNo = 19;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*20) rangeNo = 20;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*21) rangeNo = 21;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*22) rangeNo = 22;
                            else if (liveValueGet < rangeLiveAverageLow+rangeDivision*23) rangeNo = 23;
                            else rangeNo = 24;
                            
                            [[NSColor colorWithCalibratedRed:arrayColorRange [(rangeNo-1)*3] green:arrayColorRange [(rangeNo-1)*3+1] blue:arrayColorRange [(rangeNo-1)*3+2] alpha:1] set];
                            
                            positionAA.x = 40*magFactor+horizontalList2 [counter1*7+3]*horizontalIncrement*magFactor;
                            positionAA.y = 52*magFactor+increment*magFactor+counter1*increment*magFactor;
                            
                            if (endType == 1) positionBB.x = 40*magFactor+(horizontalList2 [counter1*7+4]+1)*horizontalIncrement*magFactor;
                            else positionBB.x = 40*magFactor+horizontalList2 [counter1*7+4]*horizontalIncrement*magFactor;
                            
                            positionBB.y = 52*magFactor+increment*magFactor+counter1*increment*magFactor;
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                        else{
                            
                            rangeDivision = (rangeLiveTotalHigh-rangeLiveTotalLow)/(double)25;
                            
                            if (liveValueGet < rangeLiveTotalLow+rangeDivision) rangeNo = 1;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*2) rangeNo = 2;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*3) rangeNo = 3;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*4) rangeNo = 4;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*5) rangeNo = 5;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*6) rangeNo = 6;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*7) rangeNo = 7;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*8) rangeNo = 8;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*9) rangeNo = 9;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*10) rangeNo = 10;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*11) rangeNo = 11;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*12) rangeNo = 12;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*13) rangeNo = 13;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*14) rangeNo = 14;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*15) rangeNo = 15;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*16) rangeNo = 16;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*17) rangeNo = 17;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*18) rangeNo = 18;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*19) rangeNo = 19;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*20) rangeNo = 20;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*21) rangeNo = 21;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*22) rangeNo = 22;
                            else if (liveValueGet < rangeLiveTotalLow+rangeDivision*23) rangeNo = 23;
                            else rangeNo = 24;
                            
                            [[NSColor colorWithCalibratedRed:arrayColorRange [(rangeNo-1)*3] green:arrayColorRange [(rangeNo-1)*3+1] blue:arrayColorRange [(rangeNo-1)*3+2] alpha:1] set];
                            
                            positionAA.x = 40*magFactor+horizontalList2 [counter1*7+3]*horizontalIncrement*magFactor;
                            positionAA.y = 52*magFactor+increment*magFactor+counter1*increment*magFactor;
                            
                            if (endType == 1) positionBB.x = 40*magFactor+(horizontalList2 [counter1*7+4]+1)*horizontalIncrement*magFactor;
                            else positionBB.x = 40*magFactor+horizontalList2 [counter1*7+4]*horizontalIncrement*magFactor;
                            
                            positionBB.y = 52*magFactor+increment*magFactor+counter1*increment*magFactor;
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                    } //----One live data/cell----
                    else if (liveColorStart != -1 && liveColorStart < liveColorEnd){ //----More than one live data/cell----
                        rangeListCount = 0;
                        
                        for (int counter2 = liveColorStart; counter2 <= liveColorEnd; counter2++){
                            liveValueGet = 0;
                            
                            for (int counter3 = 0; counter3 < ifValueExtractCount/22; counter3++){
                                if (cellNoOriginal == ifValueExtract [counter3*22] && (int)(horizontalList2 [counter1*7+1]) == ifValueExtract [counter3*22+1] && liveTimeList [counter2] == ifValueExtract [counter3*22+2]){
                                    if (liveCurrentCHNo == 1){
                                        if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter3*22+5];
                                        else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter3*22+5]*ifValueExtract [counter3*22+6];
                                    }
                                    else if (liveCurrentCHNo == 2){
                                        if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter3*22+8];
                                        else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter3*22+8]*ifValueExtract [counter3*22+9];
                                    }
                                    else if (liveCurrentCHNo == 3){
                                        if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter3*22+11];
                                        else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter3*22+11]*ifValueExtract [counter3*22+12];
                                    }
                                    else if (liveCurrentCHNo == 4){
                                        if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter3*22+14];
                                        else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter3*22+14]*ifValueExtract [counter3*22+15];
                                    }
                                    else if (liveCurrentCHNo == 5){
                                        if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter3*22+17];
                                        else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter3*22+17]*ifValueExtract [counter3*22+18];
                                    }
                                    else if (liveCurrentCHNo == 6){
                                        if (averageTotalFlag == 0) liveValueGet = ifValueExtract [counter3*22+20];
                                        else if (averageTotalFlag == 1) liveValueGet = ifValueExtract [counter3*22+20]*ifValueExtract [counter3*22+21];
                                    }
                                    
                                    break;
                                }
                            }
                            
                            if (averageTotalFlag == 0){
                                rangeDivision = (rangeLiveAverageHigh-rangeLiveAverageLow)/(double)25;
                                
                                if (liveValueGet < rangeLiveAverageLow+rangeDivision) rangeNo = 1;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*2) rangeNo = 2;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*3) rangeNo = 3;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*4) rangeNo = 4;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*5) rangeNo = 5;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*6) rangeNo = 6;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*7) rangeNo = 7;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*8) rangeNo = 8;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*9) rangeNo = 9;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*10) rangeNo = 10;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*11) rangeNo = 11;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*12) rangeNo = 12;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*13) rangeNo = 13;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*14) rangeNo = 14;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*15) rangeNo = 15;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*16) rangeNo = 16;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*17) rangeNo = 17;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*18) rangeNo = 18;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*19) rangeNo = 19;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*20) rangeNo = 20;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*21) rangeNo = 21;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*22) rangeNo = 22;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*23) rangeNo = 23;
                                else rangeNo = 23;
                            }
                            else{
                                
                                rangeDivision = (rangeLiveTotalHigh-rangeLiveTotalLow)/(double)25;
                                
                                if (liveValueGet < rangeLiveTotalLow+rangeDivision) rangeNo = 1;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*2) rangeNo = 2;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*3) rangeNo = 3;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*4) rangeNo = 4;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*5) rangeNo = 5;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*6) rangeNo = 6;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*7) rangeNo = 7;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*8) rangeNo = 8;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*9) rangeNo = 9;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*10) rangeNo = 10;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*11) rangeNo = 11;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*12) rangeNo = 12;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*13) rangeNo = 13;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*14) rangeNo = 14;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*15) rangeNo = 15;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*16) rangeNo = 16;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*17) rangeNo = 17;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*18) rangeNo = 18;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*19) rangeNo = 19;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*20) rangeNo = 20;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*21) rangeNo = 21;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*22) rangeNo = 22;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*23) rangeNo = 23;
                                else rangeNo = 23;
                            }
                            
                            if (counter2 == liveColorStart){
                                rangeList [rangeListCount] = horizontalList2 [counter1*7+3], rangeListCount++;
                                rangeList [rangeListCount] = liveTimeList [counter2], rangeListCount++;
                                rangeList [rangeListCount] = rangeNo, rangeListCount++;
                                
                                rangeNoHold = rangeNo;
                                timeHold = liveTimeList [counter2];
                            }
                            else if (counter2 == liveColorEnd){
                                difference = (rangeNo-rangeNoHold)/(double)(liveTimeList [counter2]-timeHold);
                                
                                if (liveTimeList [counter2]-timeHold < 5){
                                    rangeList [rangeListCount] = horizontalList2 [counter1*7+3], rangeListCount++;
                                    rangeList [rangeListCount] = liveTimeList [counter2], rangeListCount++;
                                    rangeList [rangeListCount] = rangeNo, rangeListCount++;
                                }
                                else{
                                    
                                    difference2 = difference;
                                    timeHold2 = timeHold;
                                    
                                    for (int counter3 = timeHold+1; counter3 <= liveTimeList [counter2]; counter3++){
                                        if (counter3 == liveTimeList [counter2]){
                                            rangeList [rangeListCount] = timeHold2, rangeListCount++;
                                            rangeList [rangeListCount] = counter3, rangeListCount++;
                                            rangeList [rangeListCount] = rangeNo, rangeListCount++;
                                        }
                                        else if (difference2 >= 1){
                                            differenceInt = (int)difference2;
                                            
                                            rangeList [rangeListCount] = timeHold2, rangeListCount++;
                                            rangeList [rangeListCount] = counter3, rangeListCount++;
                                            rangeList [rangeListCount] = rangeNoHold+differenceInt, rangeListCount++;
                                            
                                            difference2 = difference;
                                            rangeNoHold = rangeNoHold+differenceInt;
                                            timeHold2 = counter3;
                                        }
                                        else difference2 = difference2+difference;
                                    }
                                }
                                
                                rangeList [rangeListCount] = liveTimeList [counter2], rangeListCount++;
                                
                                if (endType == 1) rangeList [rangeListCount] = horizontalList2 [counter1*7+4]+1, rangeListCount++;
                                else rangeList [rangeListCount] = horizontalList2 [counter1*7+4], rangeListCount++;
                                
                                rangeList [rangeListCount] = rangeNo, rangeListCount++;
                            }
                            else{
                                
                                difference = (rangeNo-rangeNoHold)/(double)(liveTimeList [counter2]-timeHold);
                                
                                if (liveTimeList [counter2]-timeHold < 5){
                                    rangeList [rangeListCount] = horizontalList2 [counter1*7+3], rangeListCount++;
                                    rangeList [rangeListCount] = liveTimeList [counter2], rangeListCount++;
                                    rangeList [rangeListCount] = rangeNo, rangeListCount++;
                                }
                                else{
                                    
                                    difference2 = difference;
                                    timeHold2 = timeHold;
                                    
                                    for (int counter3 = timeHold+1; counter3 <= liveTimeList [counter2]; counter3++){
                                        if (counter3 == liveTimeList [counter2]){
                                            rangeList [rangeListCount] = timeHold2, rangeListCount++;
                                            rangeList [rangeListCount] = counter3, rangeListCount++;
                                            rangeList [rangeListCount] = rangeNo, rangeListCount++;
                                        }
                                        else if (difference2 >= 1){
                                            differenceInt = (int)difference2;
                                            
                                            rangeList [rangeListCount] = timeHold2, rangeListCount++;
                                            rangeList [rangeListCount] = counter3, rangeListCount++;
                                            rangeList [rangeListCount] = rangeNoHold+differenceInt, rangeListCount++;
                                            
                                            difference2 = difference;
                                            rangeNoHold = rangeNoHold+differenceInt;
                                            timeHold2 = counter3;
                                        }
                                        else difference2 = difference2+difference;
                                    }
                                }
                                
                                rangeNoHold = rangeNo;
                                timeHold = liveTimeList [counter2];
                            }
                        }
                        
                        for (int counter2 = 0; counter2 < rangeListCount/3; counter2++){
                            [[NSColor colorWithCalibratedRed:arrayColorRange [(int)(rangeList [counter2*3+2])*3] green:arrayColorRange [(int)(rangeList [counter2*3+2])*3+1] blue:arrayColorRange [(int)(rangeList [counter2*3+2])*3+2] alpha:1] set];
                            
                            positionAA.x = 40*magFactor+rangeList [counter2*3]*horizontalIncrement*magFactor;
                            positionAA.y = 52*magFactor+increment*magFactor+counter1*increment*magFactor;
                            positionBB.x = 40*magFactor+rangeList [counter2*3+1]*horizontalIncrement*magFactor;
                            positionBB.y = 52*magFactor+increment*magFactor+counter1*increment*magFactor;
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                    }
                    else{
                        
                        positionAA.x = 40*magFactor+horizontalList2 [counter1*7+3]*horizontalIncrement*magFactor;
                        positionAA.y = 52*magFactor+increment*magFactor+counter1*increment*magFactor;
                        
                        if (endType == 1) positionBB.x = 40*magFactor+(horizontalList2 [counter1*7+4]+1)*horizontalIncrement*magFactor;
                        else positionBB.x = 40*magFactor+horizontalList2 [counter1*7+4]*horizontalIncrement*magFactor;
                        
                        positionBB.y = 52*magFactor+increment*magFactor+counter1*increment*magFactor;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    }
                }
                
                for (int counter2 = 0; counter2 < eventListCount2/5; counter2++){
                    if (eventList2 [counter2*5+4] == counter1){
                        if (eventList2 [counter2*5+3] == 91 || eventList2 [counter2*5+3] == 92){
                            [[NSColor orangeColor] set];
                            pathCircle = [NSBezierPath bezierPathWithOvalInRect:NSMakeRect(40*magFactor+eventList2 [counter2*5+2]*horizontalIncrement*magFactor-6*magFactor, 48*magFactor+increment*magFactor+counter1*increment*magFactor, markerSizeSet*magFactor, markerSizeSet*magFactor)];
                            
                            [pathCircle fill];
                        }
                        else if (eventList2 [counter2*5+3] == 6){
                            [[NSColor cyanColor] set];
                            pathCircle = [NSBezierPath bezierPathWithOvalInRect:NSMakeRect(40*magFactor+eventList2 [counter2*5+2]*horizontalIncrement*magFactor-6*magFactor, 48*magFactor+increment*magFactor+counter1*increment*magFactor, markerSizeSet*magFactor, markerSizeSet*magFactor)];
                            [pathCircle fill];
                        }
                        else if (eventList2 [counter2*5+3] == 7){
                            [[NSColor magentaColor] set];
                            path = [NSBezierPath bezierPathWithRect: NSMakeRect(40*magFactor+eventList2 [counter2*5+2]*horizontalIncrement*magFactor-6*magFactor, 48*magFactor+increment*magFactor+counter1*increment*magFactor, markerSizeSet*magFactor, markerSizeSet*magFactor)];
                            [path fill];
                        }
                        else if (eventList2 [counter2*5+3] == 8){
                            [[NSColor grayColor] set];
                            path = [NSBezierPath bezierPathWithRect: NSMakeRect(40*magFactor+eventList2 [counter2*5+2]*horizontalIncrement*magFactor-6*magFactor, 48*magFactor+increment*magFactor+counter1*increment*magFactor, markerSizeSet*magFactor, markerSizeSet*magFactor)];
                            [path fill];
                        }
                        else if (eventList2 [counter2*5+3] == 10){
                            [[NSColor redColor] set];
                            path = [NSBezierPath bezierPathWithRect: NSMakeRect(40*magFactor+eventList2 [counter2*5+2]*horizontalIncrement*magFactor-6*magFactor, 48*magFactor+increment*magFactor+counter1*increment*magFactor, markerSizeSet*magFactor, markerSizeSet*magFactor)];
                            [path stroke];
                        }
                        else if (eventList2 [counter2*5+3] == 11){
                            [[NSColor blueColor] set];
                            path = [NSBezierPath bezierPathWithRect: NSMakeRect(40*magFactor+eventList2 [counter2*5+2]*horizontalIncrement*magFactor-6*magFactor, 48*magFactor+increment*magFactor+counter1*increment*magFactor, markerSizeSet*magFactor, markerSizeSet*magFactor)];
                            [path fill];
                        }
                    }
                }
                
                if (startType == 0){
                    if (to_string(horizontalList2 [counter1*7+3]).length() == 1) positionShiftA = 7;
                    else if (to_string(horizontalList2 [counter1*7+3]).length() == 2) positionShiftA = 14;
                    else if (to_string(horizontalList2 [counter1*7+3]).length() == 3) positionShiftA = 21;
                    else if (to_string(horizontalList2 [counter1*7+3]).length() == 4) positionShiftA = 28;
                    
                    if ((int)to_string(horizontalList2 [counter1*7+3]).find (".") != -1) horizontalString = to_string(horizontalList2 [counter1*7+3]).substr(0, to_string(horizontalList2 [counter1*7+3]).find ("."));
                    else horizontalString = to_string(horizontalList2 [counter1*7+3]);
                    
                    attrStrA = [[NSAttributedString alloc] initWithString:@(horizontalString.c_str()) attributes:attributesA];
                    pointA.x = 40*magFactor+horizontalList2 [counter1*7+3]*horizontalIncrement*magFactor-positionShiftA*magFactor;
                    pointA.y = 47*magFactor+increment*magFactor+counter1*increment*magFactor;
                    [attrStrA drawAtPoint:pointA];
                }
                else{
                    
                    [attributesA setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
                    
                    if (to_string(horizontalList2 [counter1*7+1]).length() == 1) positionShiftA = 7;
                    else if (to_string(horizontalList2 [counter1*7+1]).length() == 2) positionShiftA = 11;
                    else if (to_string(horizontalList2 [counter1*7+1]).length() == 3) positionShiftA = 17;
                    else if (to_string(horizontalList2 [counter1*7+1]).length() == 4) positionShiftA = 24;
                    
                    if ((int)to_string(horizontalList2 [counter1*7+1]).find (".") != -1) horizontalString = to_string(horizontalList2 [counter1*7+1]).substr(0, to_string(horizontalList2 [counter1*7+1]).find ("."));
                    else horizontalString = to_string(horizontalList2 [counter1*7+1]);
                    
                    attrStrA = [[NSAttributedString alloc] initWithString:@(horizontalString.c_str()) attributes:attributesA];
                    pointA.x = 40*magFactor+horizontalList2 [counter1*7+3]*horizontalIncrement*magFactor-positionShiftA*magFactor;
                    pointA.y = 47*magFactor+increment*magFactor+counter1*increment*magFactor;
                    [attrStrA drawAtPoint:pointA];
                }
                
                [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                
                if (endType == 1){
                    if (to_string(horizontalList2 [counter1*7+4]+1).length() == 1) positionShiftA = 1;
                    else if (to_string(horizontalList2 [counter1*7+4]+1).length() == 2) positionShiftA = 2;
                    else if (to_string(horizontalList2 [counter1*7+4]+1).length() == 3) positionShiftA = 3;
                    else if (to_string(horizontalList2 [counter1*7+4]+1).length() == 4) positionShiftA = 4;
                    
                    if ((int)to_string(horizontalList2 [counter1*7+4]).find (".") != -1) horizontalString = to_string(horizontalList2 [counter1*7+4]).substr(0, to_string(horizontalList2 [counter1*7+4]).find ("."));
                    else horizontalString = to_string(horizontalList2 [counter1*7+4]);
                    
                    if (endNumberFlag == 0){
                        attrStrA = [[NSAttributedString alloc] initWithString:@(horizontalString.c_str()) attributes:attributesA];
                        pointA.x = 40*magFactor+(horizontalList2 [counter1*7+4]+1)*horizontalIncrement*magFactor+positionShiftA*magFactor;
                        pointA.y = 47*magFactor+increment*magFactor+counter1*increment*magFactor;
                        [attrStrA drawAtPoint:pointA];
                    }
                }
                else{
                    
                    if (to_string(horizontalList2 [counter1*7+4]).length() == 1) positionShiftA = 1;
                    else if (to_string(horizontalList2 [counter1*7+4]).length() == 2) positionShiftA = 2;
                    else if (to_string(horizontalList2 [counter1*7+4]).length() == 3) positionShiftA = 3;
                    else if (to_string(horizontalList2 [counter1*7+4]).length() == 4) positionShiftA = 4;
                    
                    if ((int)to_string(horizontalList2 [counter1*7+4]).find (".") != -1) horizontalString = to_string(horizontalList2 [counter1*7+4]).substr(0, to_string(horizontalList2 [counter1*7+4]).find ("."));
                    else horizontalString = to_string(horizontalList2 [counter1*7+4]);
                    
                    if (endNumberFlag == 0){
                        attrStrA = [[NSAttributedString alloc] initWithString:@(horizontalString.c_str()) attributes:attributesA];
                        pointA.x = 40*magFactor+horizontalList2 [counter1*7+4]*horizontalIncrement*magFactor+positionShiftA*magFactor;
                        pointA.y = 47*magFactor+increment*magFactor+counter1*increment*magFactor;
                        [attrStrA drawAtPoint:pointA];
                    }
                }
                
                if ((int)to_string(horizontalList2 [counter1*7+2]).find (".") != -1) horizontalString = to_string(horizontalList2 [counter1*7+2]).substr(0, to_string(horizontalList2 [counter1*7+2]).find ("."));
                else horizontalString = to_string(horizontalList2 [counter1*7+2]);
                
                cellNumberString = "C"+horizontalString;
                
                if (cellNumberFlag == 0){
                    attrStrA = [[NSAttributedString alloc] initWithString:@(cellNumberString.c_str()) attributes:attributesA];
                    pointA.x = 40*magFactor+((horizontalList2 [counter1*7+4]+horizontalList2 [counter1*7+3])/(double)2)*horizontalIncrement*magFactor-5*magFactor;
                    pointA.y = 53*magFactor+increment*magFactor+counter1*increment*magFactor;
                    [attrStrA drawAtPoint:pointA];
                }
            }
            
            //for (int counterA = 0; counterA < lineageFluorescentDataTypeEntryCount; counterA++){
            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageFluorescentDataType [counterA][counterB];
            //    cout<<" arrayLineageFluorescentDataType "<<counterA+1<<endl;
            //}
            
            //for (int counterA = 0; counterA < 1; counterA++){
            //    for (int counterB = 0; counterB < findMainLength; counterB++) cout<<" "<< arrayTableMain [tableCurrentRowHold][counterA+counterB];
            //    cout<<"  arrayTableMain "<<counterA<<endl;
            //}
            
            string ifName = "";
            
            for (int counter1 = 13; counter1 < findMainLength; counter1 = counter1+8){
                if (atoi(arrayTableMain [tableCurrentRowHold][counter1].c_str()) == roundNoGet){
                    ifName = arrayTableMain [tableCurrentRowHold][counter1+ifCurrentCHNo+1];
                    break;
                }
            }
            
            string roundExtract;
            int rangeAverageLow = 0;
            int rangeAverageHigh = 0;
            int rangeTotalLow = 0;
            int rangeTotalHigh = 0;
            
            for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryCount; counter1++){
                roundExtract = arrayLineageFluorescentDataType [counter1][1];
                roundExtract = roundExtract.substr(1);
                
                if (atoi(arrayLineageFluorescentDataType [counter1][0].c_str()) == tableCurrentRowHold+1 && atoi(roundExtract.c_str()) == roundNoGet && arrayLineageFluorescentDataType [counter1][2] == ifName){
                    rangeTotalLow = atoi(arrayLineageFluorescentDataType [counter1][6].c_str());
                    rangeTotalHigh = atoi(arrayLineageFluorescentDataType [counter1][7].c_str());
                    rangeAverageLow = atoi(arrayLineageFluorescentDataType [counter1][4].c_str());
                    rangeAverageHigh = atoi(arrayLineageFluorescentDataType [counter1][5].c_str());
                    break;
                }
            }
            
            //cout<<rangeAverageLow<<" "<<rangeAverageHigh<<" "<<rangeTotalLow<<" "<<rangeTotalHigh<<" "<<roundNoGet<<" "<<tableCurrentRowHold+1<<" Range"<<endl;
            
            double *fluorescentEntry = new double [numberOfCellEntry*5+50];
            int fluorescentEntryCount = 0;
            
            for (int counter1 = 0; counter1 < horizontalListCount2/7; counter1++){
                if (horizontalList2 [counter1*7+3] <= ifCurrentTime && horizontalList2 [counter1*7+4] >= ifCurrentTime){
                    fluorescentEntry [fluorescentEntryCount] = horizontalList2 [counter1*7], fluorescentEntryCount++; //----Cell no----
                    fluorescentEntry [fluorescentEntryCount] = horizontalList2 [counter1*7+1], fluorescentEntryCount++; //----Ling no----
                    fluorescentEntry [fluorescentEntryCount] = 0, fluorescentEntryCount++; //----AV----
                    fluorescentEntry [fluorescentEntryCount] = 0, fluorescentEntryCount++; //----Total----
                    fluorescentEntry [fluorescentEntryCount] = counter1, fluorescentEntryCount++; //----Cell order----
                }
            }
            
            //for (int counterA = 0; counterA < horizontalListCount2/7; counterA++){
            //    cout<<horizontalList2 [counterA*7]<<" "<<horizontalList2 [counterA*7+1]<<" "<<horizontalList2 [counterA*7+2]<<" "<<horizontalList2 [counterA*7+3]<<" "<<horizontalList2 [counterA*7+4]<<" "<<horizontalList2 [counterA*7+5]<<" "<<horizontalList2 [counterA*7+6]<<"  horizontalList2"<<endl;
            //}
            
            //for (int counterA = 0; counterA < fluorescentEntryCount/5; counterA++){
            //    cout<<fluorescentEntry [counterA*5]<<" "<<fluorescentEntry [counterA*5+1]<<" "<< fluorescentEntry [counterA*5+2]<<" "<<fluorescentEntry [counterA*5+3]<<" "<<fluorescentEntry [counterA*5+4]<<"   fluorescentEntry"<<endl;
            //}
            
            //for (int counterA = 0; counterA < ifEntryCount/13; counterA++){
            //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<arrayIFData [tableCurrentRowHold][counterA*13+counterB];
            //    cout<<" arrayIFData "<<counterA<<endl;
            //}
            
            for (int counter1 = 0; counter1 < fluorescentEntryCount/5; counter1++){
                cellNoOriginal = 0;
                
                for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                    if (fluorescentEntry [counter1*5] == cellNoList [counter2*4+2]){
                        cellNoOriginal = (int)(cellNoList [counter2*4]);
                        break;
                    }
                }
                
                for (int counter2 = 0; counter2 < ifValueExtractCount/22; counter2++){
                    if (cellNoOriginal == ifValueExtract [counter2*22] && (int)(fluorescentEntry [counter1*5+1]) == ifValueExtract [counter2*22+1] && ifCurrentTime == ifValueExtract [counter2*22+2]){
                        
                        if (ifCurrentCHNo == 1){
                            fluorescentEntry [counter1*5+2] = ifValueExtract [counter2*22+5];
                            fluorescentEntry [counter1*5+3] = ifValueExtract [counter2*22+5]*ifValueExtract [counter2*22+6];
                        }
                        else if (ifCurrentCHNo == 2){
                            fluorescentEntry [counter1*5+2] = ifValueExtract [counter2*22+8];
                            fluorescentEntry [counter1*5+3] = ifValueExtract [counter2*22+8]*ifValueExtract [counter2*22+9];
                        }
                        else if (ifCurrentCHNo == 3){
                            fluorescentEntry [counter1*5+2] = ifValueExtract [counter2*22+11];
                            fluorescentEntry [counter1*5+3] = ifValueExtract [counter2*22+11]*ifValueExtract [counter2*22+12];
                        }
                        else if (ifCurrentCHNo == 4){
                            fluorescentEntry [counter1*5+2] = ifValueExtract [counter2*22+14];
                            fluorescentEntry [counter1*5+3] = ifValueExtract [counter2*22+14]*ifValueExtract [counter2*22+15];
                        }
                        else if (ifCurrentCHNo == 5){
                            fluorescentEntry [counter1*5+2] = ifValueExtract [counter2*22+17];
                            fluorescentEntry [counter1*5+3] = ifValueExtract [counter2*22+17]*ifValueExtract [counter2*22+18];
                        }
                        else if (ifCurrentCHNo == 6){
                            fluorescentEntry [counter1*5+2] = ifValueExtract [counter2*22+20];
                            fluorescentEntry [counter1*5+3] = ifValueExtract [counter2*22+20]*ifValueExtract [counter2*22+21];
                        }
                        
                        break;
                    }
                }
            }
            
            //for (int counterA = 0; counterA < fluorescentEntryCount/5; counterA++){
            //    cout<<fluorescentEntry [counterA*5]<<" "<<fluorescentEntry [counterA*5+1]<<" "<< fluorescentEntry [counterA*5+2]<<" "<<fluorescentEntry [counterA*5+3]<<" "<<fluorescentEntry [counterA*5+4]<<"   fluorescentEntry"<<endl;
            //}
            
            if (averageTotalFlag == 0){
                double rangeDivisionAverage = (rangeAverageHigh-rangeAverageLow)/(double)25;
                
                for (int counter1 = 0; counter1 < fluorescentEntryCount/5; counter1++){
                    if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage) rangeNo = 1;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*2) rangeNo = 2;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*3) rangeNo = 3;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*4) rangeNo = 4;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*5) rangeNo = 5;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*6) rangeNo = 6;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*7) rangeNo = 7;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*8) rangeNo = 8;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*9) rangeNo = 9;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*10) rangeNo = 10;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*11) rangeNo = 11;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*12) rangeNo = 12;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*13) rangeNo = 13;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*14) rangeNo = 14;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*15) rangeNo = 15;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*16) rangeNo = 16;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*17) rangeNo = 17;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*18) rangeNo = 18;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*19) rangeNo = 19;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*20) rangeNo = 20;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*21) rangeNo = 21;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*22) rangeNo = 22;
                    else if (fluorescentEntry [counter1*5+2] < rangeAverageLow+rangeDivisionAverage*23) rangeNo = 23;
                    else rangeNo = 24;
                    
                    [[NSColor colorWithCalibratedRed:arrayColorRange [(rangeNo-1)*3] green:arrayColorRange [(rangeNo-1)*3+1] blue:arrayColorRange [(rangeNo-1)*3+2] alpha:1] set];
                    
                    positionAA.x = 835*magFactor;
                    positionAA.y = 52*magFactor+increment*magFactor+fluorescentEntry [counter1*5+4]*increment*magFactor;
                    positionBB.x = 845*magFactor;
                    positionBB.y = 52*magFactor+increment*magFactor+fluorescentEntry [counter1*5+4]*increment*magFactor;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                }
            }
            else{
                
                double rangeDivisionTotal = (rangeTotalHigh-rangeTotalLow)/(double)25;
                
                for (int counter1 = 0; counter1 < fluorescentEntryCount/5; counter1++){
                    if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal) rangeNo = 1;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*2) rangeNo = 2;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*3) rangeNo = 3;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*4) rangeNo = 4;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*5) rangeNo = 5;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*6) rangeNo = 6;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*7) rangeNo = 7;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*8) rangeNo = 8;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*9) rangeNo = 9;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*10) rangeNo = 10;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*11) rangeNo = 11;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*12) rangeNo = 12;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*13) rangeNo = 13;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*14) rangeNo = 14;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*15) rangeNo = 15;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*16) rangeNo = 16;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*17) rangeNo = 17;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*18) rangeNo = 18;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*19) rangeNo = 19;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*20) rangeNo = 20;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*21) rangeNo = 21;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*22) rangeNo = 22;
                    else if (fluorescentEntry [counter1*5+3] < rangeTotalLow+rangeDivisionTotal*23) rangeNo = 23;
                    else rangeNo = 24;
                    
                    [[NSColor colorWithCalibratedRed:arrayColorRange [(rangeNo-1)*3] green:arrayColorRange [(rangeNo-1)*3+1] blue:arrayColorRange [(rangeNo-1)*3+2] alpha:1] set];
                    
                    positionAA.x = 835*magFactor;
                    positionAA.y = 52*magFactor+increment*magFactor+fluorescentEntry [counter1*5+4]*increment*magFactor;
                    positionBB.x = 845*magFactor;
                    positionBB.y = 52*magFactor+increment*magFactor+fluorescentEntry [counter1*5+4]*increment*magFactor;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                }
            }
            
            delete [] horizontalList;
            delete [] horizontalList2;
            delete [] eventList;
            delete [] eventList2;
            delete [] verticalList;
            delete [] liveTimeList;
            delete [] rangeList;
            delete [] fluorescentEntry;
            delete [] cellExtractedInfo;
            delete [] cellNoList;
            delete [] cellExtractedInfoSummary;
        }
        
        [NSGraphicsContext restoreGraphicsState];
        
        NSData *imageExportData;
        imageExportData = [bitmapReps TIFFRepresentation];
        
        [imageExportData writeToFile:@(exportResultPath.c_str()) atomically:YES];
        
        if (exportTiming != 112) exportFlag1 = 2;
        else if (exportTiming == 112) exportTiming = 113;
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToMainLineage object:nil];
}

@end
