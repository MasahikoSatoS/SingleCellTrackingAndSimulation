//
//  CellGrowthCurveAddition.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 12/14/16.
//
//

#ifndef CELLGROWTHCURVEADDITION_H
#define CELLGROWTHCURVEADDITION_H
#import "Controller.h" 
#endif

@interface CellGrowthCurveAddition : NSObject{
    IBOutlet NSTextField *verticalLow;
    IBOutlet NSTextField *verticalHigh;
    IBOutlet NSTextField *horizontalLow;
    IBOutlet NSTextField *horizontalHigh;
}

-(id)init;
-(void)dealloc;

@end
