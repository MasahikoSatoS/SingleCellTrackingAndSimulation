//
//  SearchController.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 11/9/16.
//
//

#import "SearchController.h"

NSString *notificationToSearchController = @"notificationExecuteSearchController";

@implementation SearchController

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToSearchController object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    searchWindowController = [[NSWindowController alloc] initWithWindowNibName:@"Search"];
    [searchWindowController showWindow:self];
}

- (void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [searchWindow frame];
    CGFloat windowHeight = windowSize.size.height;
    
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    lingSearchPosition = 1;
    logicStatus1 = 0;
    logicStatus2 = 0;
    logicStatus3 = 0;
    
    searchStatus1 = "nil";
    searchStatus2 = "nil";
    searchStatus3 = "nil";
    searchStatus4 = "nil";
    
    [eventSL1 setStringValue:@"nil"];
    [eventSL2 setStringValue:@"nil"];
    [eventSL3 setStringValue:@"nil"];
    [eventSL4 setStringValue:@"nil"];
    [logicSL1 setStringValue:@"nil"];
    [logicSL2 setStringValue:@"nil"];
    [logicSL3 setStringValue:@"nil"];
    
    if (windowHeight != 0) [searchWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
}

-(IBAction)closeWindow:(id)sender{
    [searchWindow orderOut:self];
    searchWindowOperation = 2;
    searchTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
}

-(void)reDisplayWindow{
    if (searchWindowOperation == 3){
        [searchWindow makeKeyAndOrderFront:self];
        searchWindowOperation = 1;
        [searchTimer invalidate];
    }
}

-(IBAction)logicSet1:(id)sender{
    if (logicStatus1 == 0){
        logicStatus1 = 1;
        [logicSL1 setStringValue:@"AND"];
    }
    else if (logicStatus1 == 1){
        logicStatus1 = 2;
        [logicSL1 setStringValue:@"OR"];
    }
    else if (logicStatus1 == 2){
        logicStatus1 = 3;
        [logicSL1 setStringValue:@"NOT"];
    }
    else if (logicStatus1 == 3){
        logicStatus1 = 0;
        [logicSL1 setStringValue:@"nil"];
        
        logicStatus2 = 0;
        [logicSL2 setStringValue:@"nil"];
        
        logicStatus3 = 0;
        [logicSL3 setStringValue:@"nil"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)logicSet2:(id)sender{
    if (logicStatus1 != 0){
        if (logicStatus2 == 0){
            logicStatus2 = 1;
            [logicSL2 setStringValue:@"AND"];
        }
        else if (logicStatus2 == 1){
            logicStatus2 = 2;
            [logicSL2 setStringValue:@"OR"];
        }
        else if (logicStatus2 == 2){
            logicStatus2 = 3;
            [logicSL2 setStringValue:@"NOT"];
        }
        else if (logicStatus2 == 3){
            logicStatus2 = 0;
            [logicSL2 setStringValue:@"nil"];
            
            logicStatus3 = 0;
            [logicSL3 setStringValue:@"nil"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)logicSet3:(id)sender{
    if (logicStatus1 != 0 && logicStatus2 != 0){
        if (logicStatus3 == 0){
            logicStatus3 = 1;
            [logicSL3 setStringValue:@"AND"];
        }
        else if (logicStatus3 == 1){
            logicStatus3 = 2;
            [logicSL3 setStringValue:@"OR"];
        }
        else if (logicStatus3 == 2){
            logicStatus3 = 3;
            [logicSL3 setStringValue:@"NOT"];
        }
        else if (logicStatus3 == 3){
            logicStatus3 = 0;
            [logicSL3 setStringValue:@"nil"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)clear1:(id)sender{
    if (searchStatus1 != "nil"){
        searchStatus1 = "nil";
        [eventSL1 setStringValue:@"nil"];
        
        lingSearchPosition = 1;
        
        if (searchStatus2 != "nil"){
            searchStatus1 = searchStatus2;
            searchStatus2 = "nil";
            [eventSL1 setStringValue:@(searchStatus1.c_str())];
            [eventSL2 setStringValue:@"nil"];
            
            lingSearchPosition = 2;
        }
        
        if (searchStatus3 != "nil"){
            searchStatus2 = searchStatus3;
            searchStatus3 = "nil";
            [eventSL2 setStringValue:@(searchStatus2.c_str())];
            [eventSL3 setStringValue:@"nil"];
            
            lingSearchPosition = 3;
        }
        
        if (searchStatus4 != "nil"){
            searchStatus3 = searchStatus4;
            searchStatus4 = "nil";
            [eventSL3 setStringValue:@(searchStatus3.c_str())];
            [eventSL4 setStringValue:@"nil"];
            
            lingSearchPosition = 4;
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)clear2:(id)sender{
    if (searchStatus2 != "nil"){
        searchStatus2 = "nil";
        [eventSL2 setStringValue:@"nil"];
        
        lingSearchPosition = 2;
        
        if (searchStatus3 != "nil"){
            searchStatus2 = searchStatus3;
            searchStatus3 = "nil";
            [eventSL2 setStringValue:@(searchStatus2.c_str())];
            [eventSL3 setStringValue:@"nil"];
            
            lingSearchPosition = 3;
        }
        
        if (searchStatus4 != "nil"){
            searchStatus3 = searchStatus4;
            searchStatus4 = "nil";
            [eventSL3 setStringValue:@(searchStatus3.c_str())];
            [eventSL4 setStringValue:@"nil"];
            
            lingSearchPosition = 4;
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)clear3:(id)sender{
    if (searchStatus3 != "nil"){
        searchStatus3 = "nil";
        [eventSL3 setStringValue:@"nil"];
        
        lingSearchPosition = 3;
        
        if (searchStatus4 != "nil"){
            searchStatus3 = searchStatus4;
            searchStatus4 = "nil";
            [eventSL3 setStringValue:@(searchStatus3.c_str())];
            [eventSL4 setStringValue:@"nil"];
            
            lingSearchPosition = 4;
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)clear4:(id)sender{
    if (searchStatus4 != "nil"){
        searchStatus4 = "nil";
        [eventSL4 setStringValue:@"nil"];
        
        lingSearchPosition = 4;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)setClear:(id)sender{
    lingSearchPosition = 1;
    logicStatus1 = 0;
    logicStatus2 = 0;
    logicStatus3 = 0;
    
    searchStatus1 = "nil";
    searchStatus2 = "nil";
    searchStatus3 = "nil";
    searchStatus4 = "nil";
    
    [eventSL1 setStringValue:@"nil"];
    [eventSL2 setStringValue:@"nil"];
    [eventSL3 setStringValue:@"nil"];
    [eventSL4 setStringValue:@"nil"];
    [logicSL1 setStringValue:@"nil"];
    [logicSL2 setStringValue:@"nil"];
    [logicSL3 setStringValue:@"nil"];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)search:(id)sender{
    if (upLoadingProgress == 0){
        if (searchStatus1 != "nil" && searchStatus2 != "nil"){
            if (logicStatus1 == 0){
                searchStatus2 = "nil";
                [eventSL2 setStringValue:@"nil"];
                searchStatus3 = "nil";
                [eventSL3 setStringValue:@"nil"];
                searchStatus4 = "nil";
                [eventSL4 setStringValue:@"nil"];
            }
        }
        
        if (searchStatus1 != "nil" && searchStatus2 != "nil" && searchStatus3 != "nil"){
            if (logicStatus2 == 0){
                searchStatus3 = "nil";
                [eventSL3 setStringValue:@"nil"];
                searchStatus4 = "nil";
                [eventSL4 setStringValue:@"nil"];
            }
        }
        
        if (searchStatus1 != "nil" && searchStatus2 != "nil" && searchStatus3 != "nil" && searchStatus4 != "nil"){
            if (logicStatus3 == 0){
                searchStatus4 = "nil";
                [eventSL4 setStringValue:@"nil"];
            }
        }
        
        int searchType1 = -1;
        
        if (searchStatus1 == "IN") searchType1 = 0;
        else if (searchStatus1 == "BD") searchType1 = 1;
        else if (searchStatus1 == "TD") searchType1 = 2;
        else if (searchStatus1 == "HD") searchType1 = 3;
        else if (searchStatus1 == "OF") searchType1 = 4;
        else if (searchStatus1 == "CD") searchType1 = 5;
        else if (searchStatus1 == "CF") searchType1 = 6;
        else if (searchStatus1 == "IP") searchType1 = 7;
        else if (searchStatus1 == "FM") searchType1 = 8;
        else if (searchStatus1 == "MI") searchType1 = 9;
        
        int searchType2 = -1;
        
        if (searchStatus2 == "IN") searchType2 = 0;
        else if (searchStatus2 == "BD") searchType2 = 1;
        else if (searchStatus2 == "TD") searchType2 = 2;
        else if (searchStatus2 == "HD") searchType2 = 3;
        else if (searchStatus2 == "OF") searchType2 = 4;
        else if (searchStatus2 == "CD") searchType2 = 5;
        else if (searchStatus2 == "CF") searchType2 = 6;
        else if (searchStatus2 == "IP") searchType2 = 7;
        else if (searchStatus2 == "FM") searchType2 = 8;
        else if (searchStatus2 == "MI") searchType2 = 9;
        
        int searchType3 = -1;
        
        if (searchStatus3 == "IN") searchType3 = 0;
        else if (searchStatus3 == "BD") searchType3 = 1;
        else if (searchStatus3 == "TD") searchType3 = 2;
        else if (searchStatus3 == "HD") searchType3 = 3;
        else if (searchStatus3 == "OF") searchType3 = 4;
        else if (searchStatus3 == "CD") searchType3 = 5;
        else if (searchStatus3 == "CF") searchType3 = 6;
        else if (searchStatus3 == "IP") searchType3 = 7;
        else if (searchStatus3 == "FM") searchType3 = 8;
        else if (searchStatus3 == "MI") searchType3 = 9;
        
        int searchType4 = -1;
        
        if (searchStatus4 == "IN") searchType4 = 0;
        else if (searchStatus4 == "BD") searchType4 = 1;
        else if (searchStatus4 == "TD") searchType4 = 2;
        else if (searchStatus4 == "HD") searchType4 = 3;
        else if (searchStatus4 == "OF") searchType4 = 4;
        else if (searchStatus4 == "CD") searchType4 = 5;
        else if (searchStatus4 == "CF") searchType4 = 6;
        else if (searchStatus4 == "IP") searchType4 = 7;
        else if (searchStatus4 == "FM") searchType4 = 8;
        else if (searchStatus4 == "MI") searchType4 = 9;
        
        if (searchStatus1 != "nil" && searchType1 != -1 && searchType2 != -1){
            unsigned long lineageEntryNo = 0;
            int lastLineageNo = 0;
            int lineageNoTemp = 0;
            
            searchResultsHoldCount = 0;
            
            for (int counter1 = 0; counter1 < lineageDataEntryCount; counter1++){
                if (arraySelectedLing [counter1] == 1){
                    lineageEntryNo = arrayLineageDataEntryHold [counter1];
                    lastLineageNo = arrayTableDetail [counter1][1];
                    
                    for (unsigned long counter2 = 0; counter2 < lineageEntryNo/9; counter2++){
                        if (arrayLineageData [counter1][counter2*9+6] > lastLineageNo) lastLineageNo = arrayLineageData [counter1][counter2*9+6];
                    }
                    
                    int *arrayLineageList = new int [lastLineageNo*5+50];
                    int *arrayLineageListTemp = new int [lastLineageNo*12+50];
                    
                    for (int counter2 = 0; counter2 <= lastLineageNo; counter2++){
                        arrayLineageList [counter2*5] = 0;
                        arrayLineageList [counter2*5+1] = 0;
                        arrayLineageList [counter2*5+2] = 0;
                        arrayLineageList [counter2*5+3] = 0;
                        arrayLineageList [counter2*5+4] = 0;
                        arrayLineageListTemp [counter2*12] = 0;
                        arrayLineageListTemp [counter2*12+1] = 0;
                        arrayLineageListTemp [counter2*12+2] = 0;
                        arrayLineageListTemp [counter2*12+3] = 0;
                        arrayLineageListTemp [counter2*12+4] = 0;
                        arrayLineageListTemp [counter2*12+5] = 0;
                        arrayLineageListTemp [counter2*12+6] = 0;
                        arrayLineageListTemp [counter2*12+7] = 0;
                        arrayLineageListTemp [counter2*12+8] = 0;
                        arrayLineageListTemp [counter2*12+9] = 0;
                        arrayLineageListTemp [counter2*12+10] = 0;
                        arrayLineageListTemp [counter2*12+11] = 0;
                    }
                    
                    for (unsigned long counter2 = 0; counter2 < lineageEntryNo/9; counter2++){
                        lineageNoTemp = arrayLineageData [counter1][counter2*9+6];
                        
                        if (arrayLineageData [counter1][counter2*9+3] == 1) arrayLineageListTemp [lineageNoTemp*12] = 1;
                        if (arrayLineageData [counter1][counter2*9+3] == 31) arrayLineageListTemp [lineageNoTemp*12+1] = 1;
                        if (arrayLineageData [counter1][counter2*9+3] == 41) arrayLineageListTemp [lineageNoTemp*12+2] = 1;
                        if (arrayLineageData [counter1][counter2*9+3] == 51) arrayLineageListTemp [lineageNoTemp*12+3] = 1;
                        if (arrayLineageData [counter1][counter2*9+3] == 8) arrayLineageListTemp [lineageNoTemp*12+4] = 1;
                        if (arrayLineageData [counter1][counter2*9+3] == 7) arrayLineageListTemp [lineageNoTemp*12+5] = 1;
                        if (arrayLineageData [counter1][counter2*9+3] == 91 || arrayLineageData [counter1][counter2*9+3] == 92) arrayLineageListTemp [lineageNoTemp*12+6] = 1;
                        if (arrayLineageData [counter1][counter2*9+3] == 11) arrayLineageListTemp [lineageNoTemp*12+7] = 1;
                        if (arrayLineageData [counter1][counter2*9+3] == 10) arrayLineageListTemp [lineageNoTemp*12+8] = 1;
                        if (arrayLineageData [counter1][counter2*9+3] == 6) arrayLineageListTemp [lineageNoTemp*12+9] = 1;
                        
                        arrayLineageListTemp [lineageNoTemp*12+11] = 1;
                    }
                    
                    for (int counter2 = 0; counter2 <= lastLineageNo; counter2++){
                        if (arrayLineageListTemp [counter2*12+11] == 1){
                            arrayLineageList [counter2*5] = 1;
                            arrayLineageList [counter2*5+1] = 0;
                            arrayLineageList [counter2*5+2] = -1;
                            
                            if (arrayLineageListTemp [counter2*12+10] == 1) arrayLineageList [counter2*5+3] = 1;
                            else arrayLineageList [counter2*5+3] = 0;
                            
                            arrayLineageList [counter2*5+4] = 0;
                        }
                    }
                    
                    //for (int counterA = 1; counterA < lastLineageNo; counterA++){
                    //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayLineageList [counterA*5+counterB];
                    //    cout<<" arrayLineageList "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 1; counterA < lastLineageNo; counterA++){
                    //    for (int counterB = 0; counterB < 12; counterB++) cout<<" "<<arrayLineageListTemp [counterA*12+counterB];
                    //    cout<<" arrayLineageListTemp "<<counterA<<endl;
                    // }
                    
                    if (searchType1 != -1){
                        for (int counter2 = 1; counter2 <= lastLineageNo; counter2++){
                            if (arrayLineageList [counter2*5] != 0 && arrayLineageListTemp [counter2*12+searchType1] != 0) arrayLineageList [counter2*5] = 2;
                        }
                    }
                    
                    //for (int counterA = 1; counterA < lastLineageNo; counterA++){
                    //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayLineageList [counterA*5+counterB];
                    //    cout<<" arrayLineageList "<<counterA<<endl;
                    //}
                    
                    if (searchType2 != -1){
                        if (logicStatus1 == 1){
                            for (int counter2 = 1; counter2 <= lastLineageNo; counter2++){
                                if (arrayLineageList [counter2*5] == 2 && arrayLineageListTemp [counter2*12+searchType2] == 0){
                                    arrayLineageList [counter2*5] = 1;
                                }
                            }
                        }
                        else if (logicStatus1 == 2){
                            for (int counter2 = 1; counter2 <= lastLineageNo; counter2++){
                                if (arrayLineageList [counter2*5] != 0 && arrayLineageListTemp [counter2*12+searchType2] != 0){
                                    arrayLineageList [counter2*5] = 2;
                                }
                            }
                        }
                        else if (logicStatus1 == 3){
                            for (int counter2 = 1; counter2 <= lastLineageNo; counter2++){
                                if (arrayLineageList [counter2*5] == 2 && arrayLineageListTemp [counter2*12+searchType2] != 0){
                                    arrayLineageList [counter2*5] = 1;
                                }
                            }
                        }
                    }
                    
                    if (searchType3 != -1){
                        if (logicStatus2 == 1){
                            for (int counter2 = 1; counter2 <= lastLineageNo; counter2++){
                                if (arrayLineageList [counter2*5] == 2 && arrayLineageListTemp [counter2*12+searchType3] == 0){
                                    arrayLineageList [counter2*5] = 1;
                                }
                            }
                        }
                        else if (logicStatus2 == 2){
                            for (int counter2 = 1; counter2 <= lastLineageNo; counter2++){
                                if (arrayLineageList [counter2*5] != 0 && arrayLineageListTemp [counter2*12+searchType3] != 0){
                                    arrayLineageList [counter2*5] = 2;
                                }
                            }
                        }
                        else if (logicStatus2 == 3){
                            for (int counter2 = 1; counter2 <= lastLineageNo; counter2++){
                                if (arrayLineageList [counter2*5] == 2 && arrayLineageListTemp [counter2*12+searchType3] != 0){
                                    arrayLineageList [counter2*5] = 1;
                                }
                            }
                        }
                    }
                    
                    if (searchType4 != -1){
                        if (logicStatus3 == 1){
                            for (int counter2 = 1; counter2 <= lastLineageNo; counter2++){
                                if (arrayLineageList [counter2*5] == 2 && arrayLineageListTemp [counter2*12+searchType4] == 0){
                                    arrayLineageList [counter2*5] = 1;
                                }
                            }
                        }
                        else if (logicStatus3 == 2){
                            for (int counter2 = 1; counter2 <= lastLineageNo; counter2++){
                                if (arrayLineageList [counter2*5] != 0 && arrayLineageListTemp [counter2*12+searchType4] != 0){
                                    arrayLineageList [counter2*5] = 2;
                                }
                            }
                        }
                        else if (logicStatus3 == 3){
                            for (int counter2 = 1; counter2 <= lastLineageNo; counter2++){
                                if (arrayLineageList [counter2*5] == 2 && arrayLineageListTemp [counter2*12+searchType4] != 0){
                                    arrayLineageList [counter2*5] = 1;
                                }
                            }
                        }
                    }
                    
                    for (int counter2 = 1; counter2 <= lastLineageNo; counter2++){
                        if (arrayLineageList [counter2*5] == 2) arrayLineageList [counter2*5] = 1;
                        else if (arrayLineageList [counter2*5] == 1) arrayLineageList [counter2*5] = 0;
                    }
                    
                    string cellLineageString;
                    
                    for (int counter2 = 1; counter2 <= lastLineageNo; counter2++){
                        if (arrayLineageList [counter2*5] == 1 && arrayLineageList [counter2*5+3] == 0){
                            if (searchResultsHoldCount+10 > searchResultsHoldLimit){
                                string *arrayUpDate = new string [searchResultsHoldCount+10];
                                
                                for (int counter3 = 0; counter3 < searchResultsHoldCount; counter3++) arrayUpDate [counter3] = arraySearchResultsHold [counter3];
                                
                                delete [] arraySearchResultsHold;
                                searchResultsHoldLimit = searchResultsHoldCount+600;
                                arraySearchResultsHold = new string [searchResultsHoldLimit];
                                
                                for (int counter3 = 0; counter3 < searchResultsHoldCount; counter3++) arraySearchResultsHold [counter3] = arrayUpDate [counter3];
                                delete [] arrayUpDate;
                            }
                            
                            arraySearchResultsHold [searchResultsHoldCount] = arrayTableMain [counter1][0], searchResultsHoldCount++;
                            arraySearchResultsHold [searchResultsHoldCount] = arrayTableMain [counter1][1], searchResultsHoldCount++;
                            arraySearchResultsHold [searchResultsHoldCount] = arrayTableMain [counter1][2], searchResultsHoldCount++;
                            arraySearchResultsHold [searchResultsHoldCount] = arrayTableMain [counter1][3], searchResultsHoldCount++;
                            arraySearchResultsHold [searchResultsHoldCount] = arrayTableMain [counter1][4], searchResultsHoldCount++;
                            
                            cellLineageString = to_string(counter2);
                            
                            if (cellLineageString.length() == 1) cellLineageString = "L0000"+cellLineageString;
                            else if (cellLineageString.length() == 2) cellLineageString = "L000"+cellLineageString;
                            else if (cellLineageString.length() == 3) cellLineageString = "L00"+cellLineageString;
                            else if (cellLineageString.length() == 4) cellLineageString = "L0"+cellLineageString;
                            else if (cellLineageString.length() == 5) cellLineageString = "L"+cellLineageString;
                            
                            arraySearchResultsHold [searchResultsHoldCount] = cellLineageString, searchResultsHoldCount++;
                        }
                    }
                    
                    delete [] arrayLineageListTemp;
                    delete [] arrayLineageList;
                }
            }
            
            if (searchResultsHoldCount > displayForSearchLimit){
                delete [] arrayDisplayForSearch;
                arrayDisplayForSearch = new string [searchResultsHoldCount+500];
                displayForSearchCount = 0;
                displayForSearchLimit = searchResultsHoldCount+500;
            }
            else displayForSearchCount = 0;
            
            int saveFindFlag1 = 0;
            int saveFindFlag2 = 0;
            int saveFindFlag3 = 0;
            int saveFindFlag4 = 0;
            
            for (int counter1 = 0; counter1 < searchResultsHoldCount/6; counter1++){
                saveFindFlag1 = 0;
                saveFindFlag2 = 0;
                saveFindFlag3 = 0;
                saveFindFlag4 = 0;
                
                if (typeSearchName != "nil" && arraySearchResultsHold [counter1*6+1] != typeSearchName) saveFindFlag1 = 1;
                if (seriesSearchName != "nil" && arraySearchResultsHold [counter1*6+2] != seriesSearchName) saveFindFlag2 = 1;
                if (analysisSearchName != "nil" && arraySearchResultsHold [counter1*6+3] != analysisSearchName) saveFindFlag3 = 1;
                if (treatSearchName != "nil" && arraySearchResultsHold [counter1*6+4] != treatSearchName) saveFindFlag4 = 1;
                
                if (saveFindFlag1 != 1 && saveFindFlag2 != 1 && saveFindFlag3 != 1 && saveFindFlag4 != 1){
                    arrayDisplayForSearch [displayForSearchCount] = arraySearchResultsHold [counter1*6+1], displayForSearchCount++;
                    arrayDisplayForSearch [displayForSearchCount] = arraySearchResultsHold [counter1*6+2], displayForSearchCount++;
                    arrayDisplayForSearch [displayForSearchCount] = arraySearchResultsHold [counter1*6+3], displayForSearchCount++;
                    arrayDisplayForSearch [displayForSearchCount] = arraySearchResultsHold [counter1*6+4], displayForSearchCount++;
                    arrayDisplayForSearch [displayForSearchCount] = arraySearchResultsHold [counter1*6+5], displayForSearchCount++;
                }
            }
            
            //for (int counterA = 0; counterA < displayForSearchCount/5; counterA++){
            //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayDisplayForSearch [counterA*5+counterB];
            //    cout<<" arrayDisplayForSearch "<<counterA<<endl;
            //}
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSearchOperationTable object:self];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Search Condition Not Set"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)setIN:(id)sender{
    if (lingSearchPosition == 1){
        [eventSL1 setStringValue:@"IN"];
        searchStatus1 = "IN";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 2){
        [eventSL2 setStringValue:@"IN"];
        searchStatus2 = "IN";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 3){
        [eventSL3 setStringValue:@"IN"];
        searchStatus3 = "IN";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 4){
        [eventSL4 setStringValue:@"IN"];
        searchStatus4 = "IN";
        lingSearchPosition++;
    }
}

-(IBAction)setDD:(id)sender{
    if (lingSearchPosition == 1){
        [eventSL1 setStringValue:@"BD"];
        searchStatus1 = "BD";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 2){
        [eventSL2 setStringValue:@"BD"];
        searchStatus2 = "BD";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 3){
        [eventSL3 setStringValue:@"BD"];
        searchStatus3 = "BD";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 4){
        [eventSL4 setStringValue:@"BD"];
        searchStatus4 = "BD";
        lingSearchPosition++;
    }
}

-(IBAction)setTD:(id)sender{
    if (lingSearchPosition == 1){
        [eventSL1 setStringValue:@"TD"];
        searchStatus1 = "TD";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 2){
        [eventSL2 setStringValue:@"TD"];
        searchStatus2 = "TD";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 3){
        [eventSL3 setStringValue:@"TD"];
        searchStatus3 = "TD";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 4){
        [eventSL4 setStringValue:@"TD"];
        searchStatus4 = "TD";
        lingSearchPosition++;
    }
}

-(IBAction)setHD:(id)sender{
    if (lingSearchPosition == 1){
        [eventSL1 setStringValue:@"HD"];
        searchStatus1 = "HD";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 2){
        [eventSL2 setStringValue:@"HD"];
        searchStatus2 = "HD";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 3){
        [eventSL3 setStringValue:@"HD"];
        searchStatus3 = "HD";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 4){
        [eventSL4 setStringValue:@"HD"];
        searchStatus4 = "HD";
        lingSearchPosition++;
    }
}

-(IBAction)setOF:(id)sender{
    if (lingSearchPosition == 1){
        [eventSL1 setStringValue:@"OF"];
        searchStatus1 = "OF";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 2){
        [eventSL2 setStringValue:@"OF"];
        searchStatus2 = "OF";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 3){
        [eventSL3 setStringValue:@"OF"];
        searchStatus3 = "OF";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 4){
        [eventSL4 setStringValue:@"OF"];
        searchStatus4 = "OF";
        lingSearchPosition++;
    }
}

-(IBAction)setCD:(id)sender{
    if (lingSearchPosition == 1){
        [eventSL1 setStringValue:@"CD"];
        searchStatus1 = "CD";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 2){
        [eventSL2 setStringValue:@"CD"];
        searchStatus2 = "CD";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 3){
        [eventSL3 setStringValue:@"CD"];
        searchStatus3 = "CD";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 4){
        [eventSL4 setStringValue:@"CD"];
        searchStatus4 = "CD";
        lingSearchPosition++;
    }
}

-(IBAction)setIP:(id)sender{
    if (lingSearchPosition == 1){
        [eventSL1 setStringValue:@"IP"];
        searchStatus1 = "IP";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 2){
        [eventSL2 setStringValue:@"IP"];
        searchStatus2 = "IP";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 3){
        [eventSL3 setStringValue:@"IP"];
        searchStatus3 = "IP";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 4){
        [eventSL4 setStringValue:@"IP"];
        searchStatus4 = "IP";
        lingSearchPosition++;
    }
}

-(IBAction)setMI:(id)sender{
    if (lingSearchPosition == 1){
        [eventSL1 setStringValue:@"MI"];
        searchStatus1 = "MI";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 2){
        [eventSL2 setStringValue:@"MI"];
        searchStatus2 = "MI";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 3){
        [eventSL3 setStringValue:@"MI"];
        searchStatus3 = "MI";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 4){
        [eventSL4 setStringValue:@"MI"];
        searchStatus4 = "MI";
        lingSearchPosition++;
    }
}

-(IBAction)setCF:(id)sender{
    if (lingSearchPosition == 1){
        [eventSL1 setStringValue:@"CF"];
        searchStatus1 = "CF";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 2){
        [eventSL2 setStringValue:@"CF"];
        searchStatus2 = "CF";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 3){
        [eventSL3 setStringValue:@"CF"];
        searchStatus3 = "CF";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 4){
        [eventSL4 setStringValue:@"CF"];
        searchStatus4 = "CF";
        lingSearchPosition++;
    }
}

-(IBAction)setFM:(id)sender{
    if (lingSearchPosition == 1){
        [eventSL1 setStringValue:@"FM"];
        searchStatus1 = "FM";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 2){
        [eventSL2 setStringValue:@"FM"];
        searchStatus2 = "FM";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 3){
        [eventSL3 setStringValue:@"FM"];
        searchStatus3 = "FM";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 4){
        [eventSL4 setStringValue:@"FM"];
        searchStatus4 = "FM";
        lingSearchPosition++;
    }
}

-(IBAction)setType:(id)sender{
    if (displayForSearchCount != 0){
        typeSearchName = arrayDisplayForSearch [searchOperationTableCurrentRow*5];
        
        int saveFindFlag1 = 0;
        int saveFindFlag2 = 0;
        int saveFindFlag3 = 0;
        int saveFindFlag4 = 0;
        
        displayForSearchCount = 0;
        
        for (int counter1 = 0; counter1 < searchResultsHoldCount/6; counter1++){
            saveFindFlag1 = 0;
            saveFindFlag2 = 0;
            saveFindFlag3 = 0;
            saveFindFlag4 = 0;
            
            if (typeSearchName != "nil" && arraySearchResultsHold [counter1*6+1] != typeSearchName) saveFindFlag1 = 1;
            if (seriesSearchName != "nil" && arraySearchResultsHold [counter1*6+2] != seriesSearchName) saveFindFlag2 = 1;
            if (analysisSearchName != "nil" && arraySearchResultsHold [counter1*6+3] != analysisSearchName) saveFindFlag3 = 1;
            if (treatSearchName != "nil" && arraySearchResultsHold [counter1*6+4] != treatSearchName) saveFindFlag4 = 1;
            
            if (saveFindFlag1 != 1 && saveFindFlag2 != 1 && saveFindFlag3 != 1 && saveFindFlag4 != 1){
                arrayDisplayForSearch [displayForSearchCount] = arraySearchResultsHold [counter1*6+1], displayForSearchCount++;
                arrayDisplayForSearch [displayForSearchCount] = arraySearchResultsHold [counter1*6+2], displayForSearchCount++;
                arrayDisplayForSearch [displayForSearchCount] = arraySearchResultsHold [counter1*6+3], displayForSearchCount++;
                arrayDisplayForSearch [displayForSearchCount] = arraySearchResultsHold [counter1*6+4], displayForSearchCount++;
                arrayDisplayForSearch [displayForSearchCount] = arraySearchResultsHold [counter1*6+5], displayForSearchCount++;
            }
        }
        
        [typeSL setStringValue:@(typeSearchName.c_str())];
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSearchOperationTable object:self];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)setSeries:(id)sender{
    if (displayForSearchCount != 0){
        seriesSearchName = arrayDisplayForSearch [searchOperationTableCurrentRow*5+1];
        
        int saveFindFlag1 = 0;
        int saveFindFlag2 = 0;
        int saveFindFlag3 = 0;
        int saveFindFlag4 = 0;
        
        displayForSearchCount = 0;
        
        for (int counter1 = 0; counter1 < searchResultsHoldCount/6; counter1++){
            saveFindFlag1 = 0;
            saveFindFlag2 = 0;
            saveFindFlag3 = 0;
            saveFindFlag4 = 0;
            
            if (typeSearchName != "nil" && arraySearchResultsHold [counter1*6+1] != typeSearchName) saveFindFlag1 = 1;
            if (seriesSearchName != "nil" && arraySearchResultsHold [counter1*6+2] != seriesSearchName) saveFindFlag2 = 1;
            if (analysisSearchName != "nil" && arraySearchResultsHold [counter1*6+3] != analysisSearchName) saveFindFlag3 = 1;
            if (treatSearchName != "nil" && arraySearchResultsHold [counter1*6+4] != treatSearchName) saveFindFlag4 = 1;
            
            if (saveFindFlag1 != 1 && saveFindFlag2 != 1 && saveFindFlag3 != 1 && saveFindFlag4 != 1){
                arrayDisplayForSearch [displayForSearchCount] = arraySearchResultsHold [counter1*6+1], displayForSearchCount++;
                arrayDisplayForSearch [displayForSearchCount] = arraySearchResultsHold [counter1*6+2], displayForSearchCount++;
                arrayDisplayForSearch [displayForSearchCount] = arraySearchResultsHold [counter1*6+3], displayForSearchCount++;
                arrayDisplayForSearch [displayForSearchCount] = arraySearchResultsHold [counter1*6+4], displayForSearchCount++;
                arrayDisplayForSearch [displayForSearchCount] = arraySearchResultsHold [counter1*6+5], displayForSearchCount++;
            }
        }
        
        [seriesSL setStringValue:@(seriesSearchName.c_str())];
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSearchOperationTable object:self];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)setAnalysis:(id)sender{
    if (displayForSearchCount != 0){
        analysisSearchName = arrayDisplayForSearch [searchOperationTableCurrentRow*5+2];
        
        int saveFindFlag1 = 0;
        int saveFindFlag2 = 0;
        int saveFindFlag3 = 0;
        int saveFindFlag4 = 0;
        
        displayForSearchCount = 0;
        
        for (int counter1 = 0; counter1 < searchResultsHoldCount/6; counter1++){
            saveFindFlag1 = 0;
            saveFindFlag2 = 0;
            saveFindFlag3 = 0;
            saveFindFlag4 = 0;
            
            if (typeSearchName != "nil" && arraySearchResultsHold [counter1*6+1] != typeSearchName) saveFindFlag1 = 1;
            if (seriesSearchName != "nil" && arraySearchResultsHold [counter1*6+2] != seriesSearchName) saveFindFlag2 = 1;
            if (analysisSearchName != "nil" && arraySearchResultsHold [counter1*6+3] != analysisSearchName) saveFindFlag3 = 1;
            if (treatSearchName != "nil" && arraySearchResultsHold [counter1*6+4] != treatSearchName) saveFindFlag4 = 1;
            
            if (saveFindFlag1 != 1 && saveFindFlag2 != 1 && saveFindFlag3 != 1 && saveFindFlag4 != 1){
                arrayDisplayForSearch [displayForSearchCount] = arraySearchResultsHold [counter1*6+1], displayForSearchCount++;
                arrayDisplayForSearch [displayForSearchCount] = arraySearchResultsHold [counter1*6+2], displayForSearchCount++;
                arrayDisplayForSearch [displayForSearchCount] = arraySearchResultsHold [counter1*6+3], displayForSearchCount++;
                arrayDisplayForSearch [displayForSearchCount] = arraySearchResultsHold [counter1*6+4], displayForSearchCount++;
                arrayDisplayForSearch [displayForSearchCount] = arraySearchResultsHold [counter1*6+5], displayForSearchCount++;
            }
        }
        
        [analysisSL setStringValue:@(analysisSearchName.c_str())];
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSearchOperationTable object:self];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)setTreat:(id)sender{
    if (displayForSearchCount != 0){
        treatSearchName = arrayDisplayForSearch [searchOperationTableCurrentRow*5+3];
        
        int saveFindFlag1 = 0;
        int saveFindFlag2 = 0;
        int saveFindFlag3 = 0;
        int saveFindFlag4 = 0;
        
        displayForSearchCount = 0;
        
        for (int counter1 = 0; counter1 < searchResultsHoldCount/6; counter1++){
            saveFindFlag1 = 0;
            saveFindFlag2 = 0;
            saveFindFlag3 = 0;
            saveFindFlag4 = 0;
            
            if (typeSearchName != "nil" && arraySearchResultsHold [counter1*6+1] != typeSearchName) saveFindFlag1 = 1;
            if (seriesSearchName != "nil" && arraySearchResultsHold [counter1*6+2] != seriesSearchName) saveFindFlag2 = 1;
            if (analysisSearchName != "nil" && arraySearchResultsHold [counter1*6+3] != analysisSearchName) saveFindFlag3 = 1;
            if (treatSearchName != "nil" && arraySearchResultsHold [counter1*6+4] != treatSearchName) saveFindFlag4 = 1;
            
            if (saveFindFlag1 != 1 && saveFindFlag2 != 1 && saveFindFlag3 != 1 && saveFindFlag4 != 1){
                arrayDisplayForSearch [displayForSearchCount] = arraySearchResultsHold [counter1*6+1], displayForSearchCount++;
                arrayDisplayForSearch [displayForSearchCount] = arraySearchResultsHold [counter1*6+2], displayForSearchCount++;
                arrayDisplayForSearch [displayForSearchCount] = arraySearchResultsHold [counter1*6+3], displayForSearchCount++;
                arrayDisplayForSearch [displayForSearchCount] = arraySearchResultsHold [counter1*6+4], displayForSearchCount++;
                arrayDisplayForSearch [displayForSearchCount] = arraySearchResultsHold [counter1*6+5], displayForSearchCount++;
            }
        }
        
        [treatSL setStringValue:@(treatSearchName.c_str())];
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSearchOperationTable object:self];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)clearSetting:(id)sender{
    if (displayForSearchCount != 0){
        typeSearchName = "nil";
        seriesSearchName = "nil";
        analysisSearchName = "nil";
        treatSearchName = "nil";
        
        int saveFindFlag1 = 0;
        int saveFindFlag2 = 0;
        int saveFindFlag3 = 0;
        int saveFindFlag4 = 0;
        
        displayForSearchCount = 0;
        
        for (int counter1 = 0; counter1 < searchResultsHoldCount/6; counter1++){
            saveFindFlag1 = 0;
            saveFindFlag2 = 0;
            saveFindFlag3 = 0;
            saveFindFlag4 = 0;
            
            if (typeSearchName != "nil" && arraySearchResultsHold [counter1*6+1] != typeSearchName) saveFindFlag1 = 1;
            if (seriesSearchName != "nil" && arraySearchResultsHold [counter1*6+2] != seriesSearchName) saveFindFlag2 = 1;
            if (analysisSearchName != "nil" && arraySearchResultsHold [counter1*6+3] != analysisSearchName) saveFindFlag3 = 1;
            if (treatSearchName != "nil" && arraySearchResultsHold [counter1*6+4] != treatSearchName) saveFindFlag4 = 1;
            
            if (saveFindFlag1 != 1 && saveFindFlag2 != 1 && saveFindFlag3 != 1 && saveFindFlag4 != 1){
                arrayDisplayForSearch [displayForSearchCount] = arraySearchResultsHold [counter1*6+1], displayForSearchCount++;
                arrayDisplayForSearch [displayForSearchCount] = arraySearchResultsHold [counter1*6+2], displayForSearchCount++;
                arrayDisplayForSearch [displayForSearchCount] = arraySearchResultsHold [counter1*6+3], displayForSearchCount++;
                arrayDisplayForSearch [displayForSearchCount] = arraySearchResultsHold [counter1*6+4], displayForSearchCount++;
                arrayDisplayForSearch [displayForSearchCount] = arraySearchResultsHold [counter1*6+5], displayForSearchCount++;
            }
        }
        
        [typeSL setStringValue:@"nil"];
        [analysisSL setStringValue:@"nil"];
        [seriesSL setStringValue:@"nil"];
        [treatSL setStringValue:@"nil"];
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSearchOperationTable object:self];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)searchSave:(id)sender{
    if (searchResultsHoldCount != 0){
        int *saveRoundList = new int[lineageDataEntryCount+10];
        
        for (int counter1 = 0; counter1 < lineageDataEntryCount+10; counter1++){
            saveRoundList [counter1] = 0;
        }
        
        for (int counter1 = 0; counter1 < searchResultsHoldCount/6; counter1++){
            saveRoundList [atoi(arraySearchResultsHold [counter1*6].c_str())-1]++;
        }
        
        //for (int counterA = 0; counterA < lineageDataEntryCount; counterA++){
        //    cout<<saveRoundList [counterA]<<" saveRoundList"<<endl;
        //}
        
        DIR *dir;
        struct dirent *dent;
        
        string imageDisplayPath;
        string entry;
        int maxSearchNo = 0;
        
        for (int counter1 = 0; counter1 < lineageDataEntryCount; counter1++){
            if (saveRoundList [counter1] != 0){
                imageDisplayPath = analysisDataFolderPath+"/"+arrayTableMain [counter1][2]+"_AnalysisResults"+"/"+arrayTableMain [counter1][3]+"_IDResults";
                
                dir = opendir(imageDisplayPath.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            if ((int)entry.find("SE") != -1){
                                if (atoi(entry.substr(2, entry.find("-")-2).c_str()) > maxSearchNo) maxSearchNo = atoi(entry.substr(2, entry.find("-")-2).c_str());
                            }
                        }
                    }
                    
                    closedir(dir);
                }
            }
        }
        
        maxSearchNo++;
        
        int *lineageNoList = new int [searchResultsHoldCount+10];
        int lineageNoListCount = 0;
        unsigned long lineageExtractTempCount = 0;
        unsigned long lineageExtractTempLimit = 0;
        int ifExtractTempCount = 0;
        int ifExtractTempLimit = 0;
        int findFlag = 0;
        int noOfLing = 0;
        int noOfCellStart = 0;
        int noOfCellEnd = 0;
        int noOfTotalCells = 0;
        int noOfDD = 0;
        int noOfTD = 0;
        int noOfHD = 0;
        int noOfMI = 0;
        int noOfFU = 0;
        int noOfCD = 0;
        int maxLineageNo = 0;
        int areaExtractTempCount = 0;
        int areaExtractTempLimit = 0;
        int lineageLinkListLengthTemp = 0;
        int lingNoTemp = 0;
        
        double foldTemp = 0;
        
        string savePath;
        string treatNameExtract;
        
        ofstream oin;
        
        for (int counter1 = 0; counter1 < lineageDataEntryCount; counter1++){
            if (saveRoundList [counter1] != 0){
                if (lineageDataEntryCount-1 < 101){
                    treatNameExtract = arrayTableMain [counter1][4].substr(arrayTableMain [counter1][4].find("-")+1, arrayTableMain [counter1][4].find("_Results")-arrayTableMain [counter1][4].find("-")-1);
                    imageDisplayPath = analysisDataFolderPath+"/"+arrayTableMain [counter1][2]+"_AnalysisResults"+"/"+arrayTableMain [counter1][3]+"_IDResults/"+"SE"+to_string(maxSearchNo)+"-"+treatNameExtract+"_Results";
                    
                    mkdir(imageDisplayPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                    
                    lineageNoListCount = 0;
                    
                    for (int counter2 = 0; counter2 < searchResultsHoldCount/6; counter2++){
                        if (arraySearchResultsHold [counter2*6] == to_string(counter1+1)){
                            lineageNoList [lineageNoListCount] = atoi(arraySearchResultsHold [counter2*6+5].substr(1).c_str()), lineageNoListCount++;
                        }
                    }
                    
                    int *lineageExtractTemp = new int [arrayLineageDataEntryHold [counter1]+500];
                    lineageExtractTempCount = 0;
                    lineageExtractTempLimit = arrayLineageDataEntryHold [counter1]+500;
                    
                    for (unsigned long counter2 = 0; counter2 < arrayLineageDataEntryHold [counter1]/9; counter2++){
                        findFlag = 0;
                        
                        for (int counter3 = 0; counter3 < lineageNoListCount; counter3++){
                            if (arrayLineageData [counter1][counter2*9+6] == lineageNoList [counter3]){
                                findFlag = 1;
                                break;
                            }
                        }
                        
                        if (findFlag == 1){
                            if (lineageExtractTempCount+10 > lineageExtractTempLimit){
                                int *arrayUpDate = new int [lineageExtractTempCount+10];
                                
                                for (unsigned long counter3 = 0; counter3 < lineageExtractTempCount; counter3++) arrayUpDate [counter3] = lineageExtractTemp [counter3];
                                
                                delete [] lineageExtractTemp;
                                lineageExtractTempLimit = lineageExtractTempCount+5000;
                                lineageExtractTemp = new int [lineageExtractTempLimit];
                                
                                for (unsigned long counter3 = 0; counter3 < lineageExtractTempCount; counter3++) lineageExtractTemp [counter3] = arrayUpDate [counter3];
                                delete [] arrayUpDate;
                            }
                            
                            lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [counter1][counter2*9], lineageExtractTempCount++;
                            lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [counter1][counter2*9+1], lineageExtractTempCount++;
                            lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [counter1][counter2*9+2], lineageExtractTempCount++;
                            lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [counter1][counter2*9+3], lineageExtractTempCount++;
                            lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [counter1][counter2*9+4], lineageExtractTempCount++;
                            lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [counter1][counter2*9+5], lineageExtractTempCount++;
                            lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [counter1][counter2*9+6], lineageExtractTempCount++;
                            
                            if (arrayLineageData [counter1][counter2*9+7] != 0 && arrayLineageData [counter1][counter2*9+7] != arrayLineageData [counter1][counter2*9+6]){
                                lineageExtractTemp [lineageExtractTempCount] = 0, lineageExtractTempCount++;
                            }
                            else lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [counter1][counter2*9+7], lineageExtractTempCount++;
                            
                            lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [counter1][counter2*9+8], lineageExtractTempCount++;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < lineageExtractTempCount/9; counterA++){
                    //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<lineageExtractTemp [counterA*9+counterB];
                    //    cout<<" lineageExtractTemp"<<counterA<<endl;
                    //}
                    
                    //----IF data: Array set----
                    int *ifExtractTemp = new int [arrayIFDataEntryHold [counter1]+500];
                    ifExtractTempCount = 0;
                    ifExtractTempLimit = arrayIFDataEntryHold [counter1]+500;
                    
                    for (int counter2 = 0; counter2 < arrayIFDataEntryHold [counter1]/22; counter2++){
                        findFlag = 0;
                        
                        for (int counter3 = 0; counter3 < lineageNoListCount; counter3++){
                            if (arrayIFData [counter1][counter2*22+1] == lineageNoList [counter3]){
                                findFlag = 1;
                                break;
                            }
                        }
                        
                        if (findFlag == 1){
                            if (ifExtractTempCount+50 > ifExtractTempLimit){
                                int *arrayUpDate = new int [ifExtractTempCount+10];
                                
                                for (int counter3 = 0; counter3 < ifExtractTempCount; counter3++) arrayUpDate [counter3] = ifExtractTemp [counter3];
                                
                                delete [] ifExtractTemp;
                                ifExtractTempLimit = ifExtractTempCount+5000;
                                ifExtractTemp = new int [ifExtractTempLimit];
                                
                                for (int counter3 = 0; counter3 < ifExtractTempCount; counter3++) ifExtractTemp [counter3] = arrayUpDate [counter3];
                                delete [] arrayUpDate;
                            }
                            
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter2*22], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter2*22+1], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter2*22+2], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter2*22+3], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter2*22+4], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter2*22+5], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter2*22+6], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter2*22+7], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter2*22+8], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter2*22+9], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter2*22+10], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter2*22+11], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter2*22+12], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter2*22+13], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter2*22+14], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter2*22+15], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter2*22+16], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter2*22+17], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter2*22+18], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter2*22+19], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter2*22+20], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter2*22+21], ifExtractTempCount++;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < ifExtractTempCount/13; counterA++){
                    //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<ifExtractTemp [counterA*13+counterB];
                    //    cout<<" ifExtractTemp "<<counterA<<endl;
                    //}
                    
                    //----Detail table data: Array set----
                    int *arrayTableDetailTemp = new int [20];
                    
                    noOfLing = 0;
                    noOfCellStart = 0;
                    noOfCellEnd = 0;
                    noOfTotalCells = 0;
                    noOfDD = 0;
                    noOfTD = 0;
                    noOfHD = 0;
                    noOfMI = 0;
                    noOfFU = 0;
                    noOfCD = 0;
                    
                    maxLineageNo = 0;
                    
                    for (unsigned long counter2 = 0; counter2 < lineageExtractTempCount/9; counter2++){
                        if (lineageExtractTemp [counter2*9+2] == arrayTableDetail[counter1][2] && (lineageExtractTemp [counter2*9+5] == 0 || lineageExtractTemp [counter2*9+5] == -1)){
                            noOfLing++;
                        }
                        
                        if (maxLineageNo < lineageExtractTemp [counter2*9+6]) maxLineageNo = lineageExtractTemp [counter2*9+6]; //==
                        
                        if (lineageExtractTemp [counter2*9+2] == arrayTableDetail[counter1][2] && lineageExtractTemp [counter2*9+5] == 0){
                            noOfCellStart++;
                        }
                        
                        if ((lineageExtractTemp [counter2*9+3] == 1 || lineageExtractTemp [counter2*9+3] == 31 || lineageExtractTemp [counter2*9+3] == 41 || lineageExtractTemp [counter2*9+3] == 51)){
                            noOfTotalCells++;
                        }
                        
                        if (lineageExtractTemp [counter2*9+2] == arrayTableDetail[counter1][3]) noOfCellEnd++;
                        if (lineageExtractTemp [counter2*9+3] == 32) noOfDD++;
                        if (lineageExtractTemp [counter2*9+3] == 42) noOfTD++;
                        if (lineageExtractTemp [counter2*9+3] == 52) noOfHD++;
                        if (lineageExtractTemp [counter2*9+3] == 6) noOfMI++;
                        if (lineageExtractTemp [counter2*9+3] == 91) noOfFU++;
                        if (lineageExtractTemp [counter2*9+3] == 7) noOfCD++;
                    }
                    
                    arrayTableDetailTemp [0] = lineageDataEntryCount+1;
                    arrayTableDetailTemp [1] = noOfLing;
                    arrayTableDetailTemp [2] = arrayTableDetail[counter1][2];
                    arrayTableDetailTemp [3] = arrayTableDetail[counter1][3];
                    arrayTableDetailTemp [4] = arrayTableDetail[counter1][4];
                    arrayTableDetailTemp [5] = arrayTableDetail[counter1][5];
                    arrayTableDetailTemp [6] = noOfCellStart;
                    arrayTableDetailTemp [7] = noOfCellEnd;
                    
                    if (noOfCellStart != 0){
                        foldTemp = noOfCellEnd/(double)noOfCellStart;
                        foldTemp = foldTemp*10+1;
                    }
                    else foldTemp = 1;
                    
                    arrayTableDetailTemp [8] = (int)foldTemp;
                    arrayTableDetailTemp [9] = noOfTotalCells;
                    arrayTableDetailTemp [10] = noOfDD;
                    arrayTableDetailTemp [11] = noOfTD;
                    arrayTableDetailTemp [12] = noOfHD;
                    arrayTableDetailTemp [13] = noOfDD+noOfTD+noOfHD;
                    arrayTableDetailTemp [14] = noOfMI;
                    arrayTableDetailTemp [15] = noOfFU;
                    arrayTableDetailTemp [16] = noOfCD;
                    
                    //for (int counterA = 0; counterA < 1; counterA++){
                    //    for (int counterB = 0; counterB < 17; counterB++) cout<<" "<<arrayTableDetailTemp [counterA*17+counterB];
                    //    cout<<" arrayTableDetailTemp "<<counterA<<endl;
                    //}
                    
                    //----AreaData: Array set----
                    int *areaExtractTemp = new int [arrayAreaDataHold [counter1]+500];
                    areaExtractTempCount = 0;
                    areaExtractTempLimit = arrayAreaDataHold [counter1]+500;
                    
                    for (int counter2 = 0; counter2 < arrayAreaDataHold [counter1]/5; counter2++){
                        findFlag = 0;
                        
                        for (int counter3 = 0; counter3 < lineageNoListCount; counter3++){
                            if (arrayAreaData [counter1][counter2*5] == lineageNoList [counter3]){
                                findFlag = 1;
                                break;
                            }
                        }
                        
                        if (findFlag == 1){
                            if (areaExtractTempCount+10 > areaExtractTempLimit){
                                int *arrayUpDate = new int [areaExtractTempCount+10];
                                
                                for (int counter3 = 0; counter3 < areaExtractTempCount; counter3++) arrayUpDate [counter3] = areaExtractTemp [counter3];
                                
                                delete [] areaExtractTemp;
                                areaExtractTempLimit = areaExtractTempCount+5000;
                                areaExtractTemp = new int [areaExtractTempLimit];
                                
                                for (int counter3 = 0; counter3 < areaExtractTempCount; counter3++) areaExtractTemp [counter3] = arrayUpDate [counter3];
                                delete [] arrayUpDate;
                            }
                            
                            areaExtractTemp [areaExtractTempCount] = arrayAreaData [counter1][counter2*5], areaExtractTempCount++;
                            areaExtractTemp [areaExtractTempCount] = arrayAreaData [counter1][counter2*5+1], areaExtractTempCount++;
                            areaExtractTemp [areaExtractTempCount] = arrayAreaData [counter1][counter2*5+2], areaExtractTempCount++;
                            areaExtractTemp [areaExtractTempCount] = arrayAreaData [counter1][counter2*5+3], areaExtractTempCount++;
                            areaExtractTemp [areaExtractTempCount] = arrayAreaData [counter1][counter2*5+4], areaExtractTempCount++;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < areaExtractTempCount/5; counterA++){
                    //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<areaExtractTemp [counterA*5+counterB];
                    //    cout<<" areaExtractTemp "<<counterA<<endl;
                    //}
                    
                    //----Link Data----
                    lineageLinkListLengthTemp = 4;
                    int *arrayLineageLinkTemp = new int [(maxLineageNo+1)*lineageLinkListLengthTemp+11];
                    
                    for (int counter2 = 0; counter2 < (maxLineageNo+1)*lineageLinkListLengthTemp+11; counter2++) arrayLineageLinkTemp [counter2] = 0;
                    
                    for (unsigned long counter2 = 0; counter2 < lineageExtractTempCount/9; counter2++){
                        if (lineageExtractTemp [counter2*9+3] == 31 || lineageExtractTemp [counter2*9+3] == 41 || lineageExtractTemp [counter2*9+3] == 51 || lineageExtractTemp [counter2*9+3] == 1){
                            lingNoTemp = lineageExtractTemp [counter2*9+6];
                            arrayLineageLinkTemp [lingNoTemp*lineageLinkListLengthTemp] = lingNoTemp;
                        }
                    }
                    
                    //----Lineage Data type: Array Set----
                    for (int counter2 = 0; counter2 < 7; counter2++){
                        arrayLineageDataType [lineageDataEntryCount][counter2] = arrayLineageDataType [counter1][counter2];
                    }
                    
                    arrayLineageDataType [lineageDataEntryCount][0] = to_string(lineageDataEntryCount+1);
                    arrayLineageDataType [lineageDataEntryCount][1] = "SE"+to_string(maxSearchNo);
                    
                    //for (int counterA = 0; counterA <= lineageDataEntryCount; counterA++){
                    //    cout<<" "<<arrayLineageDataType [counterA][0]<<" "<<arrayLineageDataType [counterA][1]<<" "<<arrayLineageDataType [counterA][2]<<" "<<arrayLineageDataType [counterA][3]<<" "<<arrayLineageDataType [counterA][4]<<" "<<arrayLineageDataType [counterA][5]<<" "<<arrayLineageDataType [counterA][6]<<" "<<arrayLineageDataType [counterA][7]<<" LingType" <<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < lineageFluorescentDataTypeEntryCount; counterA++){
                    //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageFluorescentDataType [counterA][counterB];
                    //    cout<<" arrayLineageFluorescentDataType "<<counterA+1<<endl;
                    //}
                    
                    //----LineageFluorescentDataType: Array Set----
                    int fluorescentDataEntryCount = lineageFluorescentDataTypeEntryCount;
                    
                    for (int counter2 = 0; counter2 < fluorescentDataEntryCount; counter2++){
                        if (lineageFluorescentDataTypeEntryCount+9 > lineageFluorescentDataTypeEntryLimit) [self lineageFluorescentDataTypeUpDate];
                        
                        if (atoi(arrayLineageFluorescentDataType [counter2][0].c_str()) == counter1+1){
                            arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][0] = to_string(lineageDataEntryCount+1);
                            arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][1] = arrayLineageFluorescentDataType [counter2][1];
                            arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][2] = arrayLineageFluorescentDataType [counter2][2];
                            arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][3] = arrayLineageFluorescentDataType [counter2][3];
                            arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][4] = arrayLineageFluorescentDataType [counter2][4];
                            arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][5] = arrayLineageFluorescentDataType [counter2][5];
                            arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][6] = arrayLineageFluorescentDataType [counter2][6];
                            arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][7] = arrayLineageFluorescentDataType [counter2][7];
                            
                            lineageFluorescentDataTypeEntryCount++;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < lineageFluorescentDataTypeEntryCount; counterA++){
                    //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageFluorescentDataType [counterA][counterB];
                    //    cout<<" arrayLineageFluorescentDataType "<<counterA+1<<endl;
                    //}
                    
                    //----Data save----
                    savePath = imageDisplayPath+"/"+"*LineageDataAddition.dat";
                    
                    oin.open(savePath.c_str(), ios::out);
                    oin<<to_string(lineageDataEntryCount+1)<<endl;
                    oin<<"SE"+to_string(maxSearchNo)<<endl;
                    oin<<arrayLineageDataType [lineageDataEntryCount][2]<<endl;
                    oin<<arrayLineageDataType [lineageDataEntryCount][3]<<endl;
                    oin<<arrayLineageDataType [lineageDataEntryCount][4]<<endl;
                    oin<<arrayLineageDataType [lineageDataEntryCount][5]<<endl;
                    oin<<arrayLineageDataType [lineageDataEntryCount][6]<<endl;
                    
                    for (int counter2 = 0; counter2 < lineageFluorescentDataTypeEntryCount; counter2++){
                        if (atoi(arrayLineageFluorescentDataType [counter2][0].c_str()) == lineageDataEntryCount+1){
                            oin<<arrayLineageFluorescentDataType [counter2][0]<<endl;
                            oin<<arrayLineageFluorescentDataType [counter2][1]<<endl;
                            oin<<arrayLineageFluorescentDataType [counter2][2]<<endl;
                            oin<<arrayLineageFluorescentDataType [counter2][3]<<endl;
                            oin<<arrayLineageFluorescentDataType [counter2][4]<<endl;
                            oin<<arrayLineageFluorescentDataType [counter2][5]<<endl;
                            oin<<arrayLineageFluorescentDataType [counter2][6]<<endl;
                            oin<<arrayLineageFluorescentDataType [counter2][7]<<endl;
                        }
                    }
                    
                    oin.close();
                    
                    delete [] arrayLineageData [lineageDataEntryCount];
                    delete [] arrayIFData [lineageDataEntryCount];
                    delete [] arrayIFTimeLineData [lineageDataEntryCount];
                    delete [] arrayTableMain [lineageDataEntryCount];
                    delete [] arrayIfTimeStatus [lineageDataEntryCount];
                    delete [] arrayAreaData [lineageDataEntryCount];
                    delete [] arrayLineageLink [lineageDataEntryCount];
                    
                    arrayLineageData [lineageDataEntryCount] = new int [lineageExtractTempCount+10];
                    arrayIFData [lineageDataEntryCount] = new int [ifExtractTempCount+10];
                    arrayIFTimeLineData [lineageDataEntryCount] = new int [arrayIFTimeLineDataEntryHold [counter1]+10];
                    arrayTableMain [lineageDataEntryCount] = new string [arrayTableMainHold [counter1]+10];
                    arrayIfTimeStatus [lineageDataEntryCount] = new int [arrayIfTimeStatusHold [counter1]+10];
                    arrayAreaData [lineageDataEntryCount] = new int [areaExtractTempCount+10];
                    arrayLineageLink [lineageDataEntryCount] = new int [(maxLineageNo+1)*lineageLinkListLengthTemp+lineageLinkListLengthTemp+10];
                    
                    lineageDataEntryCount++;
                    
                    for (unsigned long counter2 = 0; counter2 < lineageExtractTempCount; counter2++) arrayLineageData [lineageDataEntryCount-1][counter2] = lineageExtractTemp [counter2];
                    
                    arrayLineageDataEntryHold [lineageDataEntryCount-1] = (unsigned long)lineageExtractTempCount;
                    
                    //for (int counterA = 0; counterA < arrayLineageDataEntryHold [lineageDataEntryCount-1]/9; counterA++){
                    //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayLineageData [lineageDataEntryCount-1][counterA*9+counterB];
                    //    cout<<" arrayLineageData "<<counterA<<endl;
                    //}
                    
                    for (int counter2 = 0; counter2 < ifExtractTempCount; counter2++) arrayIFData [lineageDataEntryCount-1][counter2] = ifExtractTemp [counter2];
                    
                    arrayIFDataEntryHold [lineageDataEntryCount-1] = ifExtractTempCount;
                    
                    //for (int counterA = 0; counterA < arrayIFDataEntryHold [lineageDataEntryCount-1]/13; counterA++){
                    //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<arrayIFData [lineageDataEntryCount-1][counterA*13+counterB];
                    //    cout<<" arrayIFData "<<counterA<<endl;
                    //}
                    
                    for (int counter2 = 0; counter2 < arrayIFTimeLineDataEntryHold [counter1]; counter2++){
                        arrayIFTimeLineData [lineageDataEntryCount-1][counter2] = arrayIFTimeLineData [counter1][counter2];
                    }
                    
                    arrayIFTimeLineDataEntryHold [lineageDataEntryCount-1] = arrayIFTimeLineDataEntryHold [counter1];
                    
                    for (int counter2 = 0; counter2 < arrayTableMainHold [counter1]; counter2++) arrayTableMain [lineageDataEntryCount-1][counter2] = arrayTableMain [counter1][counter2];
                    
                    arrayTableMain [lineageDataEntryCount-1][0] = to_string(lineageDataEntryCount);
                    arrayTableMain [lineageDataEntryCount-1][1] = "SE";
                    arrayTableMain [lineageDataEntryCount-1][4] = "SE"+to_string(maxSearchNo)+"-"+treatNameExtract;
                    
                    arrayTableMainHold [lineageDataEntryCount-1] = arrayTableMainHold [counter1];
                    
                    for (int counter2 = 0; counter2 < 17; counter2++) arrayTableDetail [lineageDataEntryCount-1][counter2] = arrayTableDetailTemp [counter2];
                    
                    for (int counter2 = 0; counter2 < arrayIfTimeStatusHold [counter1]; counter2++) arrayIfTimeStatus [lineageDataEntryCount-1][counter2] = ifTimeExtract [counter2];
                    
                    arrayIfTimeStatusHold [lineageDataEntryCount-1] = arrayIfTimeStatusHold [counter1];
                    
                    for (int counter2 = 0; counter2 < areaExtractTempCount; counter2++) arrayAreaData [lineageDataEntryCount-1][counter2] = areaExtractTemp [counter2];
                    
                    arrayAreaDataHold [lineageDataEntryCount-1] = areaExtractTempCount;
                    
                    //**********arrayLinkData**********
                    for (int counter2 = 0; counter2 < (maxLineageNo+1)*lineageLinkListLengthTemp; counter2++){
                        arrayLineageLink [lineageDataEntryCount-1][counter2] = arrayLineageLinkTemp [counter2];
                    }
                    
                    arrayLineageLink [lineageDataEntryCount-1][0] = lineageLinkListLengthTemp;
                    
                    lineageLinkHold [lineageDataEntryCount-1] = (maxLineageNo+1)*lineageLinkListLengthTemp;
                    
                    savePath = imageDisplayPath+"/"+"LineageDataAnalysis";
                    
                    char *writingArray = new char [lineageExtractTempCount/9*28+100];
                    
                    long indexCount = 0;
                    int readBit [4];
                    int dataTemp;
                    
                    for (unsigned long counter2 = 0; counter2 < lineageExtractTempCount/9; counter2++){
                        if (lineageExtractTemp [counter2*9] < 0){
                            writingArray [indexCount] = 1, indexCount++;
                            dataTemp = lineageExtractTemp [counter2*9]*-1;
                        }
                        else{
                            
                            writingArray [indexCount] = 0, indexCount++;
                            dataTemp = lineageExtractTemp [counter2*9];
                        }
                        
                        readBit [0] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [1] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        
                        if (lineageExtractTemp [counter2*9+1] < 0){
                            writingArray [indexCount] = 1, indexCount++;
                            dataTemp = lineageExtractTemp [counter2*9+1]*-1;
                        }
                        else{
                            
                            writingArray [indexCount] = 0, indexCount++;
                            dataTemp = lineageExtractTemp [counter2*9+1];
                        }
                        
                        readBit [0] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [1] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        
                        dataTemp = lineageExtractTemp [counter2*9+2];
                        readBit [0] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [1] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        
                        writingArray [indexCount] = (char)lineageExtractTemp [counter2*9+3], indexCount++;
                        
                        if (lineageExtractTemp [counter2*9+4] < 0){
                            writingArray [indexCount] = 1, indexCount++;
                            dataTemp = lineageExtractTemp [counter2*9+4]*-1;
                        }
                        else{
                            
                            writingArray [indexCount] = 0, indexCount++;
                            dataTemp = lineageExtractTemp [counter2*9+4];
                        }
                        
                        readBit [0] = dataTemp/16777216;
                        dataTemp = dataTemp%16777216;
                        readBit [1] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [2] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [3] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        writingArray [indexCount] = (char)readBit [3], indexCount++;
                        
                        if (lineageExtractTemp [counter2*9+5] < 0){
                            writingArray [indexCount] = 1, indexCount++;
                            dataTemp = lineageExtractTemp [counter2*9+5]*-1;
                        }
                        else{
                            
                            writingArray [indexCount] = 0, indexCount++;
                            dataTemp = lineageExtractTemp [counter2*9+5];
                        }
                        
                        readBit [0] = dataTemp/16777216;
                        dataTemp = dataTemp%16777216;
                        readBit [1] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [2] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [3] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        writingArray [indexCount] = (char)readBit [3], indexCount++;
                        
                        dataTemp = lineageExtractTemp [counter2*9+6];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = lineageExtractTemp [counter2*9+7];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = lineageExtractTemp [counter2*9+8];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                    }
                    
                    for (int counter2 = 0; counter2 < 28; counter2++) writingArray [indexCount] = 0, indexCount++;
                    
                    ofstream outfile (savePath.c_str(), ofstream::binary);
                    outfile.write ((char*)writingArray, indexCount);
                    outfile.close();
                    
                    delete [] writingArray;
                    
                    savePath = imageDisplayPath+"/"+"LineageDataAnalysisEntry";
                    
                    oin.open(savePath.c_str(), ios::out | ios::binary);
                    oin<<lineageExtractTempCount<<endl;
                    oin.close();
                    
                    savePath = imageDisplayPath+"/"+"IFData";
                    
                    writingArray = new char [ifExtractTempCount/22*60+60];
                    
                    indexCount = 0;
                    
                    for (int counter2 = 0; counter2 < ifExtractTempCount/22; counter2++){
                        if (ifExtractTemp [counter2*22] < 0){
                            writingArray [indexCount] = 1, indexCount++;
                            dataTemp = ifExtractTemp [counter2*22]*-1;
                        }
                        else{
                            
                            writingArray [indexCount] = 0, indexCount++;
                            dataTemp = ifExtractTemp [counter2*22];
                        }
                        
                        readBit [0] = dataTemp/16777216;
                        dataTemp = dataTemp%16777216;
                        readBit [1] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [2] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [3] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        writingArray [indexCount] = (char)readBit [3], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+1];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+2];
                        readBit [0] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [1] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        
                        writingArray [indexCount] = (char)ifExtractTemp [counter2*22+3], indexCount++;
                        
                        writingArray [indexCount] = (char)ifExtractTemp [counter2*22+4], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+5];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+6];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        writingArray [indexCount] = (char)ifExtractTemp [counter2*22+7], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+8];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+9];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        writingArray [indexCount] = (char)ifExtractTemp [counter2*22+10], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+11];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+12];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        writingArray [indexCount] = (char)ifExtractTemp [counter2*22+13], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+14];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+15];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        writingArray [indexCount] = (char)ifExtractTemp [counter2*22+16], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+17];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+18];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        writingArray [indexCount] = (char)ifExtractTemp [counter2*22+19], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+20];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+21];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                    }
                    
                    for (int counter2 = 0; counter2 < 33; counter2++) writingArray [indexCount] = 0, indexCount++;
                    
                    ofstream outfile2 (savePath.c_str(), ofstream::binary);
                    outfile2.write ((char*) writingArray, indexCount);
                    outfile2.close();
                    
                    delete [] writingArray;
                    
                    savePath = imageDisplayPath+"/"+"IFDataEntry";
                    
                    oin.open(savePath.c_str(), ios::out | ios::binary);
                    oin<<ifExtractTempCount<<endl;
                    oin.close();
                    
                    savePath = imageDisplayPath+"/"+"IFTimeLine";
                    
                    oin.open(savePath.c_str(), ios::out | ios::binary);
                    
                    for (int counter2 = 0; counter2 < arrayIFTimeLineDataEntryHold [lineageDataEntryCount-1]; counter2++){
                        oin<<arrayIFTimeLineData [lineageDataEntryCount-1][counter2]<<endl;
                    }
                    
                    oin.close();
                    
                    savePath = imageDisplayPath+"/"+"IFTimeLineEntry";
                    
                    oin.open(savePath.c_str(), ios::out | ios::binary);
                    oin<<arrayIFTimeLineDataEntryHold [lineageDataEntryCount-1]<<endl;
                    oin.close();
                    
                    savePath = imageDisplayPath+"/"+"MainTable";
                    
                    oin.open(savePath.c_str(), ios::out | ios::binary);
                    
                    for (int counter2 = 0; counter2 < arrayTableMainHold [lineageDataEntryCount-1]; counter2++){
                        oin<<arrayTableMain [lineageDataEntryCount-1][counter2]<<endl;
                    }
                    
                    oin.close();
                    
                    savePath = imageDisplayPath+"/"+"MainTableEntry";
                    
                    oin.open(savePath.c_str(), ios::out | ios::binary);
                    oin<<arrayTableMainHold [lineageDataEntryCount-1]<<endl;
                    oin.close();
                    
                    savePath = imageDisplayPath+"/"+"DetailTable";
                    
                    oin.open(savePath.c_str(), ios::out | ios::binary);
                    
                    for (int counter2 = 0; counter2 < 17; counter2++){
                        oin<<arrayTableDetail [lineageDataEntryCount-1][counter2]<<endl;
                    }
                    
                    oin.close();
                    
                    savePath = imageDisplayPath+"/IFDataStatus";
                    
                    oin.open(savePath.c_str(), ios::out | ios::binary);
                    
                    for (int counter2 = 0; counter2 < ifTimeExtractCount; counter2++){
                        oin<<arrayIfTimeStatus [counter1][counter2]<<endl;
                    }
                    
                    oin.close();
                    
                    savePath = imageDisplayPath+"/IFDataStatusEntry";
                    
                    oin.open(savePath.c_str(), ios::out | ios::binary);
                    oin<<arrayIfTimeStatusHold [counter1]<<endl;
                    oin.close();
                    
                    savePath = imageDisplayPath+"/"+"AreaData";
                    
                    oin.open(savePath.c_str(), ios::out | ios::binary);
                    
                    for (int counter2 = 0; counter2 < arrayAreaDataHold [lineageDataEntryCount-1]; counter2++){
                        oin<<arrayAreaData [lineageDataEntryCount-1][counter2]<<endl;
                    }
                    
                    oin.close();
                    
                    savePath = imageDisplayPath+"/AreaDataEntry";
                    
                    oin.open(savePath.c_str(), ios::out | ios::binary);
                    oin<<arrayAreaDataHold [lineageDataEntryCount-1]<<endl;
                    oin.close();
                    
                    savePath = imageDisplayPath+"/"+"LinkData";
                    
                    oin.open(savePath.c_str(), ios::out | ios::binary);
                    
                    for (int counter2 = 0; counter2 < lineageLinkHold [lineageDataEntryCount-1]; counter2++){
                        oin<<arrayLineageLink [lineageDataEntryCount-1][counter2]<<endl;
                    }
                    
                    oin.close();
                    
                    savePath = imageDisplayPath+"/LinkDataEntry";
                    
                    oin.open(savePath.c_str(), ios::out | ios::binary);
                    oin<<lineageLinkHold [lineageDataEntryCount-1] <<endl;
                    oin.close();
                    
                    delete [] lineageExtractTemp;
                    delete [] ifExtractTemp;
                    delete [] areaExtractTemp;
                    delete [] arrayLineageLinkTemp;
                    delete [] arrayTableDetailTemp;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Entry Limit Exceeded: 100"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                    
                    break;
                }
            }
        }
        
        delete [] saveRoundList;
        delete [] lineageNoList;
        
        upLoadingFlag = 1;
        
        if (lineageOpen == 1 && lineageWindowOperation != 2) lineageListCall = 1;
        if (growthCurveOpen == 1 && growthCurveWindowOperation != 2) growthCurveCall = 1;
        if (cellDivisionOpen == 1 && cellDivisionWindowOperation != 2) cellDivisionCall = 1; //========ADD POINT
        if (doublingTimeOpen == 1 && doublingTimeWindowOperation != 2) doublingTimeCall = 1;
        if (trimOpen == 1 && trimWindowOperation != 2) trimCall = 1;
        if (lineageSelectOpen == 1 && lineageSelectWindowOperation != 2) lineageSelectCall = 1;
        if (simulationOpen == 1 && simulationOperation != 2) simulationCall = 1;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(void)lineageFluorescentDataTypeUpDate{
    string **arrayLineageFluorescentDataTypeTemp = new string *[lineageFluorescentDataTypeEntryLimit];
    
    for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryLimit; counter1++){
        arrayLineageFluorescentDataTypeTemp [counter1] = new string [9];
    }
    
    int lineageFluorescentDataTypeEntryLimitTemp = lineageFluorescentDataTypeEntryLimit;
    int lineageFluorescentEntryCount = 0;
    
    for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryCount; counter1++){
        for (int counter2 = 0; counter2 < 8; counter2++){
            arrayLineageFluorescentDataTypeTemp [lineageFluorescentEntryCount][counter2] = arrayLineageFluorescentDataType [counter1][counter2];
        }
        
        lineageFluorescentEntryCount++;
    }
    
    for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryLimit; counter1++){
        delete [] arrayLineageFluorescentDataType [counter1];
    }
    
    delete [] arrayLineageFluorescentDataType;
    
    arrayLineageFluorescentDataType = new string *[lineageFluorescentDataTypeEntryLimit+320];
    
    for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryLimit+320; counter1++){
        arrayLineageFluorescentDataType [counter1] = new string [9];
    }
    
    lineageFluorescentDataTypeEntryLimit = lineageFluorescentDataTypeEntryLimit+320;
    lineageFluorescentDataTypeEntryCount = 0;
    
    for (int counter1 = 0; counter1 < lineageFluorescentEntryCount; counter1++){
        for (int counter2 = 0; counter2 < 8; counter2++){
            arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][counter2] = arrayLineageFluorescentDataTypeTemp [counter1][counter2];
        }
        
        lineageFluorescentDataTypeEntryCount++;
    }
    
    for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryLimitTemp; counter1++){
        delete [] arrayLineageFluorescentDataTypeTemp [counter1];
    }
    
    delete [] arrayLineageFluorescentDataTypeTemp;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToSearchController object:nil];
}

@end
