//
//  LineageSelectController.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2017-06-08.
//
//

#import "LineageSelectController.h"

NSString *notificationToLineageSelectController = @"notificationExecuteLineageSelectController";

@implementation LineageSelectController

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToLineageSelectController object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    lineageSelectWindowController = [[NSWindowController alloc] initWithWindowNibName:@"LineageSelect"];
    [lineageSelectWindowController showWindow:self];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLineageSelectTable object:self];
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLineageSelectTable2 object:self];
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLineageSelectTable3 object:self];
}

- (void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [lineageSelectWindow frame];
    CGFloat windowHeight = windowSize.size.height;
    
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [lineageSelectWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    [fusionMoveDisplay setStringValue:@"Together"];
}

-(IBAction)createNonSelected:(id)sender{
    if (lineageSelectLineageHoldCount != 0){
        int nonSelectedFind = 0;
        
        for (int counter1 = 0; counter1 < lineageSelectLineageHoldCount/2; counter1++){
            if (arrayLineageSelectLineageHold [counter1*2+1] == 1) nonSelectedFind++;
        }
        
        if (nonSelectedFind != 0){
            DIR *dir;
            struct dirent *dent;
            
            string imageDisplayPath;
            string entry;
            int maxSearchNo = 0;
            
            for (int counter1 = 0; counter1 < lineageDataEntryCount; counter1++){
                imageDisplayPath = analysisDataFolderPath+"/"+arrayTableMain [counter1][2]+"_AnalysisResults"+"/"+arrayTableMain [counter1][3]+"_IDResults";
                
                dir = opendir(imageDisplayPath.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            if ((int)entry.find("NS") != -1){
                                if (atoi(entry.substr(2, entry.find("-")-2).c_str()) > maxSearchNo) maxSearchNo = atoi(entry.substr(2, entry.find("-")-2).c_str());
                            }
                        }
                    }
                    
                    closedir(dir);
                }
            }
            
            maxSearchNo++;
            
            int findFlag = 0;
            int maxLineageNo = 0;
            
            string savePath;
            
            ofstream oin;
            
            if (lineageDataEntryCount-1 < 101){
                string treatNameExtract = arrayTableMain [lineageSelectOperationTableCurrentRow][4].substr(arrayTableMain [lineageSelectOperationTableCurrentRow][4].find("-")+1, arrayTableMain [lineageSelectOperationTableCurrentRow][4].find("_Results")-arrayTableMain [lineageSelectOperationTableCurrentRow][4].find("-")-1);
                
                imageDisplayPath = analysisDataFolderPath+"/"+arrayTableMain [lineageSelectOperationTableCurrentRow][2]+"_AnalysisResults"+"/"+arrayTableMain [lineageSelectOperationTableCurrentRow][3]+"_IDResults/"+"NS"+to_string(maxSearchNo)+"-"+treatNameExtract+"_Results";
                
                mkdir(imageDisplayPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                int *lineageNoList = new int [lineageSelectLineageHoldCount+10];
                int lineageNoListCount = 0;
                
                for (int counter2 = 0; counter2 < lineageSelectLineageHoldCount/2; counter2++){
                    if (arrayLineageSelectLineageHold [counter2*2+1] == 1){
                        lineageNoList [lineageNoListCount] = arrayLineageSelectLineageHold [counter2*2], lineageNoListCount++;
                    }
                }
                
                int *lineageExtractTemp = new int [arrayLineageDataEntryHold [lineageSelectOperationTableCurrentRow]+500];
                unsigned long lineageExtractTempCount = 0;
                unsigned long lineageExtractTempLimit = arrayLineageDataEntryHold [lineageSelectOperationTableCurrentRow]+500;
                
                for (unsigned long counter2 = 0; counter2 < arrayLineageDataEntryHold [lineageSelectOperationTableCurrentRow]/9; counter2++){
                    findFlag = 0;
                    
                    for (int counter3 = 0; counter3 < lineageNoListCount; counter3++){
                        if (arrayLineageData [lineageSelectOperationTableCurrentRow][counter2*9+6] == lineageNoList [counter3]){
                            findFlag = 1;
                            break;
                        }
                    }
                    
                    if (findFlag == 1){
                        if (lineageExtractTempCount+10 > lineageExtractTempLimit){
                            int *arrayUpDate = new int [lineageExtractTempCount+10];
                            
                            for (unsigned long counter3 = 0; counter3 < lineageExtractTempCount; counter3++) arrayUpDate [counter3] = lineageExtractTemp [counter3];
                            
                            delete [] lineageExtractTemp;
                            lineageExtractTempLimit = lineageExtractTempCount+5000;
                            lineageExtractTemp = new int [lineageExtractTempLimit];
                            
                            for (unsigned long counter3 = 0; counter3 < lineageExtractTempCount; counter3++) lineageExtractTemp [counter3] = arrayUpDate [counter3];
                            delete [] arrayUpDate;
                        }
                        
                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [lineageSelectOperationTableCurrentRow][counter2*9], lineageExtractTempCount++;
                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [lineageSelectOperationTableCurrentRow][counter2*9+1], lineageExtractTempCount++;
                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [lineageSelectOperationTableCurrentRow][counter2*9+2], lineageExtractTempCount++;
                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [lineageSelectOperationTableCurrentRow][counter2*9+3], lineageExtractTempCount++;
                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [lineageSelectOperationTableCurrentRow][counter2*9+4], lineageExtractTempCount++;
                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [lineageSelectOperationTableCurrentRow][counter2*9+5], lineageExtractTempCount++;
                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [lineageSelectOperationTableCurrentRow][counter2*9+6], lineageExtractTempCount++;
                        
                        if (fusionMoveStatus == 1 && arrayLineageData [lineageSelectOperationTableCurrentRow][counter2*9+7] != 0 && arrayLineageData [lineageSelectOperationTableCurrentRow][counter2*9+7] != arrayLineageData [lineageSelectOperationTableCurrentRow][counter2*9+6]){
                            lineageExtractTemp [lineageExtractTempCount] = 0, lineageExtractTempCount++;
                        }
                        else lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [lineageSelectOperationTableCurrentRow][counter2*9+7], lineageExtractTempCount++;
                        
                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [lineageSelectOperationTableCurrentRow][counter2*9+8], lineageExtractTempCount++;
                    }
                }
                
                //for (int counterA = 0; counterA < lineageExtractTempCount/9; counterA++){
                //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<lineageExtractTemp [counterA*9+counterB];
                //    cout<<" lineageExtractTemp"<<counterA<<endl;
                //}
                
                //----IF data: Array set----
                int *ifExtractTemp = new int [arrayIFDataEntryHold [lineageSelectOperationTableCurrentRow]+500];
                int ifExtractTempCount = 0;
                int ifExtractTempLimit = arrayIFDataEntryHold [lineageSelectOperationTableCurrentRow]+500;
                
                for (int counter2 = 0; counter2 < arrayIFDataEntryHold [lineageSelectOperationTableCurrentRow]/22; counter2++){
                    findFlag = 0;
                    
                    for (int counter3 = 0; counter3 < lineageNoListCount; counter3++){
                        if (arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+1] == lineageNoList [counter3]){
                            findFlag = 1;
                            break;
                        }
                    }
                    
                    if (findFlag == 1){
                        if (ifExtractTempCount+50 > ifExtractTempLimit){
                            int *arrayUpDate = new int [ifExtractTempCount+10];
                            
                            for (int counter3 = 0; counter3 < ifExtractTempCount; counter3++) arrayUpDate [counter3] = ifExtractTemp [counter3];
                            
                            delete [] ifExtractTemp;
                            ifExtractTempLimit = ifExtractTempCount+5000;
                            ifExtractTemp = new int [ifExtractTempLimit];
                            
                            for (int counter3 = 0; counter3 < ifExtractTempCount; counter3++) ifExtractTemp [counter3] = arrayUpDate [counter3];
                            delete [] arrayUpDate;
                        }
                        
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+1], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+2], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+3], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+4], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+5], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+6], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+7], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+8], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+9], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+10], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+11], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+12], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+13], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+14], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+15], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+16], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+17], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+18], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+19], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+20], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+21], ifExtractTempCount++;
                    }
                }
                
                //for (int counterA = 0; counterA < ifExtractTempCount/13; counterA++){
                //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<ifExtractTemp [counterA*13+counterB];
                //    cout<<" ifExtractTemp "<<counterA<<endl;
                //}
                
                //----Detail table data: Array set----
                int *arrayTableDetailTemp = new int [20];
                
                int noOfLing = 0;
                int noOfCellStart = 0;
                int noOfCellEnd = 0;
                int noOfTotalCells = 0;
                int noOfDD = 0;
                int noOfTD = 0;
                int noOfHD = 0;
                int noOfMI = 0;
                int noOfFU = 0;
                int noOfCD = 0;
                
                maxLineageNo = 0;
                
                for (unsigned long counter2 = 0; counter2 < lineageExtractTempCount/9; counter2++){
                    if (lineageExtractTemp [counter2*9+2] == arrayTableDetail[lineageSelectOperationTableCurrentRow][2] && (lineageExtractTemp [counter2*9+5] == 0 || lineageExtractTemp [counter2*9+5] == -1)){
                        noOfLing++;
                    }
                    
                    if (maxLineageNo < lineageExtractTemp [counter2*9+6]) maxLineageNo = lineageExtractTemp [counter2*9+6]; //==
                    
                    if (lineageExtractTemp [counter2*9+2] == arrayTableDetail[lineageSelectOperationTableCurrentRow][2] && lineageExtractTemp [counter2*9+5] == 0){
                        noOfCellStart++;
                    }
                    
                    if ((lineageExtractTemp [counter2*9+3] == 1 || lineageExtractTemp [counter2*9+3] == 31 || lineageExtractTemp [counter2*9+3] == 41 || lineageExtractTemp [counter2*9+3] == 51)){
                        noOfTotalCells++;
                    }
                    
                    if (lineageExtractTemp [counter2*9+2] == arrayTableDetail[lineageSelectOperationTableCurrentRow][3]) noOfCellEnd++;
                    if (lineageExtractTemp [counter2*9+3] == 32) noOfDD++;
                    if (lineageExtractTemp [counter2*9+3] == 42) noOfTD++;
                    if (lineageExtractTemp [counter2*9+3] == 52) noOfHD++;
                    if (lineageExtractTemp [counter2*9+3] == 6) noOfMI++;
                    if (lineageExtractTemp [counter2*9+3] == 91) noOfFU++;
                    if (lineageExtractTemp [counter2*9+3] == 7) noOfCD++;
                }
                
                arrayTableDetailTemp [0] = lineageDataEntryCount+1;
                arrayTableDetailTemp [1] = noOfLing;
                arrayTableDetailTemp [2] = arrayTableDetail[lineageSelectOperationTableCurrentRow][2];
                arrayTableDetailTemp [3] = arrayTableDetail[lineageSelectOperationTableCurrentRow][3];
                arrayTableDetailTemp [4] = arrayTableDetail[lineageSelectOperationTableCurrentRow][4];
                arrayTableDetailTemp [5] = arrayTableDetail[lineageSelectOperationTableCurrentRow][5];
                arrayTableDetailTemp [6] = noOfCellStart;
                arrayTableDetailTemp [7] = noOfCellEnd;
                
                double foldTemp = 0;
                
                if (noOfCellStart != 0){
                    foldTemp = noOfCellEnd/(double)noOfCellStart;
                    foldTemp = foldTemp*10+1;
                }
                else foldTemp = 1;
                
                arrayTableDetailTemp [8] = (int)foldTemp;
                arrayTableDetailTemp [9] = noOfTotalCells;
                arrayTableDetailTemp [10] = noOfDD;
                arrayTableDetailTemp [11] = noOfTD;
                arrayTableDetailTemp [12] = noOfHD;
                arrayTableDetailTemp [13] = noOfDD+noOfTD+noOfHD;
                arrayTableDetailTemp [14] = noOfMI;
                arrayTableDetailTemp [15] = noOfFU;
                arrayTableDetailTemp [16] = noOfCD;
                
                //for (int counterA = 0; counterA < 1; counterA++){
                //    for (int counterB = 0; counterB < 17; counterB++) cout<<" "<<arrayTableDetailTemp [counterA*17+counterB];
                //    cout<<" arrayTableDetailTemp "<<counterA<<endl;
                //}
                
                //----AreaData: Array set----
                int *areaExtractTemp = new int [arrayAreaDataHold [lineageSelectOperationTableCurrentRow]+500];
                int areaExtractTempCount = 0;
                int areaExtractTempLimit = arrayAreaDataHold [lineageSelectOperationTableCurrentRow]+500;
                
                for (int counter2 = 0; counter2 < arrayAreaDataHold [lineageSelectOperationTableCurrentRow]/5; counter2++){
                    findFlag = 0;
                    
                    for (int counter3 = 0; counter3 < lineageNoListCount; counter3++){
                        if (arrayAreaData [lineageSelectOperationTableCurrentRow][counter2*5] == lineageNoList [counter3]){
                            findFlag = 1;
                            break;
                        }
                    }
                    
                    if (findFlag == 1){
                        if (areaExtractTempCount+10 > areaExtractTempLimit){
                            int *arrayUpDate = new int [areaExtractTempCount+10];
                            
                            for (int counter3 = 0; counter3 < areaExtractTempCount; counter3++) arrayUpDate [counter3] = areaExtractTemp [counter3];
                            
                            delete [] areaExtractTemp;
                            areaExtractTempLimit = areaExtractTempCount+5000;
                            areaExtractTemp = new int [areaExtractTempLimit];
                            
                            for (int counter3 = 0; counter3 < areaExtractTempCount; counter3++) areaExtractTemp [counter3] = arrayUpDate [counter3];
                            delete [] arrayUpDate;
                        }
                        
                        areaExtractTemp [areaExtractTempCount] = arrayAreaData [lineageSelectOperationTableCurrentRow][counter2*5], areaExtractTempCount++;
                        areaExtractTemp [areaExtractTempCount] = arrayAreaData [lineageSelectOperationTableCurrentRow][counter2*5+1], areaExtractTempCount++;
                        areaExtractTemp [areaExtractTempCount] = arrayAreaData [lineageSelectOperationTableCurrentRow][counter2*5+2], areaExtractTempCount++;
                        areaExtractTemp [areaExtractTempCount] = arrayAreaData [lineageSelectOperationTableCurrentRow][counter2*5+3], areaExtractTempCount++;
                        areaExtractTemp [areaExtractTempCount] = arrayAreaData [lineageSelectOperationTableCurrentRow][counter2*5+4], areaExtractTempCount++;
                    }
                }
                
                //for (int counterA = 0; counterA < areaExtractTempCount/5; counterA++){
                //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<areaExtractTemp [counterA*5+counterB];
                //    cout<<" areaExtractTemp "<<counterA<<endl;
                //}
                
                //----Link Data----
                int lingNoTemp = 0;
                int matchFind = 0;
                int freeSpotFind = 0;
                int previousLengthHold = 0;
                int readingCount = 0;
                int terminationFlag = 0;
                int lengthExpansionFlag = 0;
                int entryNo = 0;
                int expansionNo = 0;
                
                int lineageLinkListLengthTemp = 4;
                int *arrayLineageLinkTemp = new int [(maxLineageNo+1)*lineageLinkListLengthTemp+11];
                int lineageLinkListTempLimit = (maxLineageNo+1)*lineageLinkListLengthTemp+11;
                
                for (int counter1 = 0; counter1 < (maxLineageNo+1)*lineageLinkListLengthTemp+11; counter1++) arrayLineageLinkTemp [counter1] = 0;
                
                for (unsigned long counter1 = 0; counter1 < lineageExtractTempCount/9; counter1++){
                    if (lineageExtractTemp [counter1*9+3] == 31 || lineageExtractTemp [counter1*9+3] == 41 || lineageExtractTemp [counter1*9+3] == 51 || lineageExtractTemp [counter1*9+3] == 1){
                        lingNoTemp = lineageExtractTemp [counter1*9+6];
                        arrayLineageLinkTemp [lingNoTemp*lineageLinkListLengthTemp] = lingNoTemp;
                    }
                }
                
                for (unsigned long counter1 = 0; counter1 < lineageExtractTempCount/9; counter1++){
                    lingNoTemp = lineageExtractTemp [counter1*9+6];
                    
                    if (lineageExtractTemp [counter1*9+7] != 0 && lineageExtractTemp [counter1*9+7] != lingNoTemp){
                        matchFind = 0;
                        freeSpotFind = 0;
                        
                        for (int counter2 = 1; counter2 < lineageLinkListLengthTemp; counter2++){
                            if (arrayLineageLinkTemp [lingNoTemp*lineageLinkListLengthTemp+counter2] == lineageExtractTemp [counter1*9+7]){
                                matchFind = 1;
                            }
                            
                            if (arrayLineageLinkTemp [lingNoTemp*lineageLinkListLengthTemp+counter2] == 0 && freeSpotFind == 0){
                                freeSpotFind = counter2;
                            }
                        }
                        
                        if (matchFind == 0){
                            if (freeSpotFind == 0){
                                previousLengthHold = lineageLinkListLengthTemp;
                                int *arrayUpDate = new int [lineageLinkListTempLimit+11];
                                
                                for (int counter2 = 0; counter2 < (maxLineageNo+1)*lineageLinkListLengthTemp; counter2++) arrayUpDate [counter2] = arrayLineageLinkTemp [counter2];
                                
                                delete [] arrayLineageLinkTemp;
                                lineageLinkListLengthTemp = lineageLinkListLengthTemp+2;
                                arrayLineageLinkTemp = new int [(maxLineageNo+1)*lineageLinkListLengthTemp+11];
                                lineageLinkListTempLimit = (maxLineageNo+1)*lineageLinkListLengthTemp+11;
                                
                                readingCount = 0;
                                
                                for (int counter2 = 0; counter2 <= maxLineageNo; counter2++){
                                    for (int counter3 = 0; counter3 < previousLengthHold; counter3++){
                                        arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+counter3] = arrayUpDate [readingCount], readingCount++;
                                    }
                                    
                                    arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+previousLengthHold] = 0;
                                    arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+previousLengthHold+1] = 0;
                                }
                                
                                delete [] arrayUpDate;
                                
                                freeSpotFind = previousLengthHold;
                            }
                            
                            arrayLineageLinkTemp [lingNoTemp*lineageLinkListLengthTemp] = lingNoTemp;
                            arrayLineageLinkTemp [lingNoTemp*lineageLinkListLengthTemp+freeSpotFind] = lineageExtractTemp [counter1*9+7];
                        }
                    }
                }
                
                //for (int counterA = 0; counterA <= maxLingNo; counterA++){
                //    for (int counterB = 0; counterB < lineageLinkListLength; counterB++) cout<<" "<<arrayLineageLinkList [counterA*lineageLinkListLength+counterB];
                //    cout<<" arrayLineageLinkList "<<counterA<<endl;
                //}
                
                for (int counter1 = 1; counter1 <= maxLineageNo; counter1++){
                    if (arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp] > 0 && arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp+1] != 0){
                        freeSpotFind = -1;
                        
                        for (int counter2 = 1; counter2 < lineageLinkListLengthTemp; counter2++){
                            if (arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp+counter2] == 0){
                                freeSpotFind = counter2;
                                break;
                            }
                        }
                        
                        if (freeSpotFind == -1) freeSpotFind = 4;
                        
                        do{
                            
                            terminationFlag = 1;
                            
                            for (int counter2 = 1; counter2 < lineageLinkListLengthTemp; counter2++){
                                if (arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp+counter2] != 0){
                                    lengthExpansionFlag = 0;
                                    
                                    for (int counter3 = 1; counter3 <= maxLineageNo; counter3++){
                                        if (arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp] == arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp+counter2]){
                                            entryNo = 0;
                                            
                                            for (int counter4 = 1; counter4 < lineageLinkListLengthTemp; counter4++){
                                                findFlag = 0;
                                                
                                                for (int counter5 = 1; counter5 < lineageLinkListLengthTemp; counter5++){
                                                    if (arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp+counter4] != 0 && (arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp+counter4] == arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp+counter5] || arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp+counter4] == counter1)){
                                                        findFlag = 1;
                                                    }
                                                    else if (arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp+counter4] == 0) findFlag = 1;
                                                }
                                                
                                                if (findFlag == 0) entryNo++;
                                            }
                                            
                                            if (entryNo != 0){
                                                if (freeSpotFind == lineageLinkListLengthTemp || freeSpotFind+entryNo > lineageLinkListLengthTemp){
                                                    previousLengthHold = lineageLinkListLengthTemp;
                                                    int *arrayUpDate = new int [lineageLinkListTempLimit+11];
                                                    
                                                    for (int counter4 = 0; counter4 < (maxLineageNo+1)*lineageLinkListLengthTemp; counter4++) arrayUpDate [counter4] = arrayLineageLinkTemp [counter4];
                                                    
                                                    if ((freeSpotFind+entryNo)%2 != 0) expansionNo = freeSpotFind+entryNo+1;
                                                    else expansionNo = freeSpotFind+entryNo;
                                                    
                                                    delete [] arrayLineageLinkTemp;
                                                    lineageLinkListLengthTemp = expansionNo+2;
                                                    arrayLineageLinkTemp = new int [(maxLineageNo+1)*lineageLinkListLengthTemp+lineageLinkListLengthTemp+1];
                                                    lineageLinkListTempLimit = (maxLineageNo+1)*lineageLinkListLengthTemp+lineageLinkListLengthTemp+1;
                                                    
                                                    expansionNo = lineageLinkListLengthTemp-previousLengthHold;
                                                    
                                                    readingCount = 0;
                                                    
                                                    for (int counter4 = 0; counter4 <= maxLineageNo; counter4++){
                                                        for (int counter5 = 0; counter5 < previousLengthHold; counter5++){
                                                            arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+counter5] = arrayUpDate [readingCount], readingCount++;
                                                        }
                                                        
                                                        for (int counter5 = 0; counter5 < expansionNo; counter5++){
                                                            arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+previousLengthHold+counter5] = 0;
                                                        }
                                                    }
                                                    
                                                    delete [] arrayUpDate;
                                                    
                                                    lengthExpansionFlag = 1;
                                                    
                                                    break;
                                                }
                                                else{
                                                    
                                                    for (int counter4 = 1; counter4 < lineageLinkListLengthTemp; counter4++){
                                                        findFlag = 0;
                                                        
                                                        for (int counter5 = 1; counter5 < lineageLinkListLengthTemp; counter5++){
                                                            if (arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp+counter4] != 0 && (arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp+counter4] == arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp+counter5] || arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp+counter4] == counter1)){
                                                                findFlag = 1;
                                                            }
                                                            else if (arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp+counter4] == 0) findFlag = 1;
                                                        }
                                                        
                                                        if (findFlag != 1){
                                                            arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp+freeSpotFind] = arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp+counter4];
                                                            
                                                            freeSpotFind++;
                                                        }
                                                    }
                                                    
                                                    arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp] = -1;
                                                    break;
                                                }
                                            }
                                            else arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp] = -1;
                                        }
                                    }
                                    
                                    if (lengthExpansionFlag == 1){
                                        break;
                                    }
                                }
                                
                                if (counter2 == lineageLinkListLengthTemp-1) terminationFlag = 0;
                            }
                            
                        } while (terminationFlag == 1);
                    }
                }
                
                //for (int counterA = 0; counterA <= maxLineageNo; counterA++){
                //    for (int counterB = 0; counterB < lineageLinkListLengthTemp; counterB++) cout<<" "<<arrayLineageLinkTemp [counterA*lineageLinkListLengthTemp+counterB];
                //    cout<<" arrayLineageLinkTemp "<<counterA<<endl;
                //}
                
                int *numberOfEntryList = new int [lineageLinkListLengthTemp+1];
                int *numberOfEntryList2 = new int [lineageLinkListLengthTemp+1];
                int numberOfFusionEntry = 0;
                int smallestEntry2 = 0;
                int remainingFlag = 0;
                int smallestEntry = 0;
                int smallestEntryPosition = 0;
                
                for (int counter1 = 1; counter1 <= maxLineageNo; counter1++){
                    if (arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp] > 0 && arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp+1] != 0){
                        numberOfFusionEntry = 0;
                        
                        for (int counter2 = 0; counter2 < lineageLinkListLengthTemp; counter2++){
                            if (arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp+counter2] != 0){
                                numberOfFusionEntry++;
                            }
                        }
                        
                        if (numberOfFusionEntry > 1){
                            for (int counter2 = 0; counter2 < lineageLinkListLengthTemp; counter2++){
                                if (arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp+counter2] != 0){
                                    numberOfEntryList [counter2] = arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp+counter2];
                                }
                                else numberOfEntryList [counter2] = 0;
                                
                                numberOfEntryList2 [counter2] = 0;
                            }
                            
                            smallestEntry2 = 1;
                            
                            do{
                                
                                terminationFlag = 1;
                                remainingFlag = 0;
                                smallestEntry = 100000;
                                smallestEntryPosition = 0;
                                
                                for (int counter2 = 1; counter2 < lineageLinkListLengthTemp; counter2++){
                                    if (numberOfEntryList [counter2] != 0 && numberOfEntryList [counter2] < smallestEntry){
                                        smallestEntry = numberOfEntryList [counter2];
                                        smallestEntryPosition = counter2;
                                        remainingFlag = 1;
                                    }
                                }
                                
                                if (remainingFlag == 0) terminationFlag = 0;
                                else{
                                    
                                    numberOfEntryList2 [smallestEntry2] = numberOfEntryList [smallestEntryPosition], smallestEntry2++;
                                    numberOfEntryList [smallestEntryPosition] = 0;
                                }
                                
                            } while (terminationFlag == 1);
                            
                            for (int counter2 = 1; counter2 < lineageLinkListLengthTemp; counter2++){
                                arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp+counter2] = numberOfEntryList2 [counter2];
                            }
                        }
                    }
                }
                
                delete [] numberOfEntryList;
                delete [] numberOfEntryList2;
                
                //----Lineage Data type: Array Set----
                for (int counter2 = 0; counter2 < 7; counter2++){
                    arrayLineageDataType [lineageDataEntryCount][counter2] = arrayLineageDataType [lineageSelectOperationTableCurrentRow][counter2];
                }
                
                arrayLineageDataType [lineageDataEntryCount][0] = to_string(lineageDataEntryCount+1);
                arrayLineageDataType [lineageDataEntryCount][1] = "NS"+to_string(maxSearchNo);
                
                //for (int counterA = 0; counterA <= lineageDataEntryCount; counterA++){
                //    cout<<" "<<arrayLineageDataType [counterA][0]<<" "<<arrayLineageDataType [counterA][1]<<" "<<arrayLineageDataType [counterA][2]<<" "<<arrayLineageDataType [counterA][3]<<" "<<arrayLineageDataType [counterA][4]<<" "<<arrayLineageDataType [counterA][5]<<" "<<arrayLineageDataType [counterA][6]<<" "<<arrayLineageDataType [counterA][7]<<" LineageType "<<endl;
                //}
                
                //for (int counterA = 0; counterA < lineageFluorescentDataTypeEntryCount; counterA++){
                //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageFluorescentDataType [counterA][counterB];
                //    cout<<" arrayLineageFluorescentDataType "<<counterA+1<<endl;
                //}
                
                //----LineageFluorescentDataType: Array Set----
                int fluorescentDataEntryCount = lineageFluorescentDataTypeEntryCount;
                
                for (int counter2 = 0; counter2 < fluorescentDataEntryCount; counter2++){
                    if (lineageFluorescentDataTypeEntryCount+9 > lineageFluorescentDataTypeEntryLimit) [self lineageFluorescentDataTypeUpDate];
                    
                    if (atoi(arrayLineageFluorescentDataType [counter2][0].c_str()) == lineageSelectOperationTableCurrentRow+1){
                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][0] = to_string(lineageDataEntryCount+1);
                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][1] = arrayLineageFluorescentDataType [counter2][1];
                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][2] = arrayLineageFluorescentDataType [counter2][2];
                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][3] = arrayLineageFluorescentDataType [counter2][3];
                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][4] = arrayLineageFluorescentDataType [counter2][4];
                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][5] = arrayLineageFluorescentDataType [counter2][5];
                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][6] = arrayLineageFluorescentDataType [counter2][6];
                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][7] = arrayLineageFluorescentDataType [counter2][7];
                        
                        lineageFluorescentDataTypeEntryCount++;
                    }
                }
                
                //for (int counterA = 0; counterA < lineageFluorescentDataTypeEntryCount; counterA++){
                //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageFluorescentDataType [counterA][counterB];
                //    cout<<" arrayLineageFluorescentDataType "<<counterA+1<<endl;
                //}
                
                //----Data save----
                savePath = imageDisplayPath+"/"+"*LineageDataAddition.dat";
                
                oin.open(savePath.c_str(), ios::out);
                oin<<to_string(lineageDataEntryCount+1)<<endl;
                oin<<"NS"+to_string(maxSearchNo)<<endl;
                oin<<arrayLineageDataType [lineageDataEntryCount][2]<<endl;
                oin<<arrayLineageDataType [lineageDataEntryCount][3]<<endl;
                oin<<arrayLineageDataType [lineageDataEntryCount][4]<<endl;
                oin<<arrayLineageDataType [lineageDataEntryCount][5]<<endl;
                oin<<arrayLineageDataType [lineageDataEntryCount][6]<<endl;
                
                for (int counter2 = 0; counter2 < lineageFluorescentDataTypeEntryCount; counter2++){
                    if (atoi(arrayLineageFluorescentDataType [counter2][0].c_str()) == lineageDataEntryCount+1){
                        oin<<arrayLineageFluorescentDataType [counter2][0]<<endl;
                        oin<<arrayLineageFluorescentDataType [counter2][1]<<endl;
                        oin<<arrayLineageFluorescentDataType [counter2][2]<<endl;
                        oin<<arrayLineageFluorescentDataType [counter2][3]<<endl;
                        oin<<arrayLineageFluorescentDataType [counter2][4]<<endl;
                        oin<<arrayLineageFluorescentDataType [counter2][5]<<endl;
                        oin<<arrayLineageFluorescentDataType [counter2][6]<<endl;
                        oin<<arrayLineageFluorescentDataType [counter2][7]<<endl;
                    }
                }
                
                oin.close();
                
                if (lineageDataEntryCount < 101){
                    delete [] arrayLineageData [lineageDataEntryCount];
                    delete [] arrayIFData [lineageDataEntryCount];
                    delete [] arrayIFTimeLineData [lineageDataEntryCount];
                    delete [] arrayTableMain [lineageDataEntryCount];
                    delete [] arrayIfTimeStatus [lineageDataEntryCount];
                    delete [] arrayAreaData [lineageDataEntryCount];
                    delete [] arrayLineageLink [lineageDataEntryCount];
                    
                    arrayLineageData [lineageDataEntryCount] = new int [lineageExtractTempCount+10];
                    arrayIFData [lineageDataEntryCount] = new int [ifExtractTempCount+10];
                    arrayIFTimeLineData [lineageDataEntryCount] = new int [arrayIFTimeLineDataEntryHold [lineageSelectOperationTableCurrentRow]+10];
                    arrayTableMain [lineageDataEntryCount] = new string [arrayTableMainHold [lineageSelectOperationTableCurrentRow]+10];
                    arrayIfTimeStatus [lineageDataEntryCount] = new int [arrayIfTimeStatusHold [lineageSelectOperationTableCurrentRow]+10];
                    arrayAreaData [lineageDataEntryCount] = new int [areaExtractTempCount+10];
                    arrayLineageLink [lineageDataEntryCount] = new int [(maxLineageNo+1)*lineageLinkListLengthTemp+lineageLinkListLengthTemp+10];
                    
                    lineageDataEntryCount++;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Entry Limit Exceeded: 100"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                
                if (lineageDataEntryCount-1 < 101){
                    for (unsigned long counter2 = 0; counter2 < lineageExtractTempCount; counter2++) arrayLineageData [lineageDataEntryCount-1][counter2] = lineageExtractTemp [counter2];
                    
                    arrayLineageDataEntryHold [lineageDataEntryCount-1] = (unsigned long)lineageExtractTempCount;
                    
                    //for (int counterA = 0; counterA < arrayLineageDataEntryHold [lineageDataEntryCount-1]/9; counterA++){
                    //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayLineageData [lineageDataEntryCount-1][counterA*9+counterB];
                    //    cout<<" arrayLineageData "<<counterA<<endl;
                    //}
                    
                    for (int counter2 = 0; counter2 < ifExtractTempCount; counter2++) arrayIFData [lineageDataEntryCount-1][counter2] = ifExtractTemp [counter2];
                    
                    arrayIFDataEntryHold [lineageDataEntryCount-1] = ifExtractTempCount;
                    
                    //for (int counterA = 0; counterA < arrayIFDataEntryHold [lineageDataEntryCount-1]/13; counterA++){
                    //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<arrayIFData [lineageDataEntryCount-1][counterA*13+counterB];
                    //    cout<<" arrayIFData "<<counterA<<endl;
                    //}
                    
                    for (int counter2 = 0; counter2 < arrayIFTimeLineDataEntryHold [lineageSelectOperationTableCurrentRow]; counter2++){
                        arrayIFTimeLineData [lineageDataEntryCount-1][counter2] = arrayIFTimeLineData [lineageSelectOperationTableCurrentRow][counter2];
                    }
                    
                    arrayIFTimeLineDataEntryHold [lineageDataEntryCount-1] = arrayIFTimeLineDataEntryHold [lineageSelectOperationTableCurrentRow];
                    
                    for (int counter2 = 0; counter2 < arrayTableMainHold [lineageSelectOperationTableCurrentRow]; counter2++) arrayTableMain [lineageDataEntryCount-1][counter2] = arrayTableMain [lineageSelectOperationTableCurrentRow][counter2];
                    
                    arrayTableMain [lineageDataEntryCount-1][0] = to_string(lineageDataEntryCount);
                    arrayTableMain [lineageDataEntryCount-1][1] = "NS";
                    arrayTableMain [lineageDataEntryCount-1][4] = "NS"+to_string(maxSearchNo)+"-"+treatNameExtract;
                    
                    arrayTableMainHold [lineageDataEntryCount-1] = arrayTableMainHold [lineageSelectOperationTableCurrentRow];
                    
                    for (int counter2 = 0; counter2 < 17; counter2++) arrayTableDetail [lineageDataEntryCount-1][counter2] = arrayTableDetailTemp [counter2];
                    
                    for (int counter2 = 0; counter2 < arrayIfTimeStatusHold [lineageSelectOperationTableCurrentRow]; counter2++) arrayIfTimeStatus [lineageDataEntryCount-1][counter2] = ifTimeExtract [counter2];
                    
                    arrayIfTimeStatusHold [lineageDataEntryCount-1] = arrayIfTimeStatusHold [lineageSelectOperationTableCurrentRow];
                    
                    for (int counter2 = 0; counter2 < areaExtractTempCount; counter2++) arrayAreaData [lineageDataEntryCount-1][counter2] = areaExtractTemp [counter2];
                    
                    arrayAreaDataHold [lineageDataEntryCount-1] = areaExtractTempCount;
                    
                    //**********arrayLinkData**********
                    for (int counter2 = 0; counter2 < (maxLineageNo+1)*lineageLinkListLengthTemp; counter2++){
                        arrayLineageLink [lineageDataEntryCount-1][counter2] = arrayLineageLinkTemp [counter2];
                    }
                    
                    arrayLineageLink [lineageDataEntryCount-1][0] = lineageLinkListLengthTemp;
                    
                    lineageLinkHold [lineageDataEntryCount-1] = (maxLineageNo+1)*lineageLinkListLengthTemp;
                    
                    savePath = imageDisplayPath+"/"+"LineageDataAnalysis";
                    
                    char *writingArray = new char [lineageExtractTempCount/9*28+100];
                    
                    long indexCount = 0;
                    int readBit [4];
                    int dataTemp;
                    
                    for (unsigned long counter2 = 0; counter2 < lineageExtractTempCount/9; counter2++){
                        if (lineageExtractTemp [counter2*9] < 0){
                            writingArray [indexCount] = 1, indexCount++;
                            dataTemp = lineageExtractTemp [counter2*9]*-1;
                        }
                        else{
                            
                            writingArray [indexCount] = 0, indexCount++;
                            dataTemp = lineageExtractTemp [counter2*9];
                        }
                        
                        readBit [0] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [1] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        
                        if (lineageExtractTemp [counter2*9+1] < 0){
                            writingArray [indexCount] = 1, indexCount++;
                            dataTemp = lineageExtractTemp [counter2*9+1]*-1;
                        }
                        else{
                            
                            writingArray [indexCount] = 0, indexCount++;
                            dataTemp = lineageExtractTemp [counter2*9+1];
                        }
                        
                        readBit [0] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [1] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        
                        dataTemp = lineageExtractTemp [counter2*9+2];
                        readBit [0] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [1] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        
                        writingArray [indexCount] = (char)lineageExtractTemp [counter2*9+3], indexCount++;
                        
                        if (lineageExtractTemp [counter2*9+4] < 0){
                            writingArray [indexCount] = 1, indexCount++;
                            dataTemp = lineageExtractTemp [counter2*9+4]*-1;
                        }
                        else{
                            
                            writingArray [indexCount] = 0, indexCount++;
                            dataTemp = lineageExtractTemp [counter2*9+4];
                        }
                        
                        readBit [0] = dataTemp/16777216;
                        dataTemp = dataTemp%16777216;
                        readBit [1] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [2] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [3] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        writingArray [indexCount] = (char)readBit [3], indexCount++;
                        
                        if (lineageExtractTemp [counter2*9+5] < 0){
                            writingArray [indexCount] = 1, indexCount++;
                            dataTemp = lineageExtractTemp [counter2*9+5]*-1;
                        }
                        else{
                            
                            writingArray [indexCount] = 0, indexCount++;
                            dataTemp = lineageExtractTemp [counter2*9+5];
                        }
                        
                        readBit [0] = dataTemp/16777216;
                        dataTemp = dataTemp%16777216;
                        readBit [1] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [2] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [3] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        writingArray [indexCount] = (char)readBit [3], indexCount++;
                        
                        dataTemp = lineageExtractTemp [counter2*9+6];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = lineageExtractTemp [counter2*9+7];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = lineageExtractTemp [counter2*9+8];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                    }
                    
                    for (int counter2 = 0; counter2 < 28; counter2++) writingArray [indexCount] = 0, indexCount++;
                    
                    ofstream outfile (savePath.c_str(), ofstream::binary);
                    outfile.write ((char*) writingArray, indexCount);
                    outfile.close();
                    
                    delete [] writingArray;
                    
                    savePath = imageDisplayPath+"/"+"LineageDataAnalysisEntry";
                    
                    oin.open(savePath.c_str(), ios::out | ios::binary);
                    oin<<lineageExtractTempCount<<endl;
                    oin.close();
                    
                    savePath = imageDisplayPath+"/"+"IFData";
                    
                    writingArray = new char [ifExtractTempCount/22*60+60];
                    
                    indexCount = 0;
                    
                    for (int counter2 = 0; counter2 < ifExtractTempCount/22; counter2++){
                        if (ifExtractTemp [counter2*22] < 0){
                            writingArray [indexCount] = 1, indexCount++;
                            dataTemp = ifExtractTemp [counter2*22]*-1;
                        }
                        else{
                            
                            writingArray [indexCount] = 0, indexCount++;
                            dataTemp = ifExtractTemp [counter2*22];
                        }
                        
                        readBit [0] = dataTemp/16777216;
                        dataTemp = dataTemp%16777216;
                        readBit [1] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [2] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [3] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        writingArray [indexCount] = (char)readBit [3], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+1];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+2];
                        readBit [0] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [1] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        
                        writingArray [indexCount] = (char)ifExtractTemp [counter2*22+3], indexCount++;
                        
                        writingArray [indexCount] = (char)ifExtractTemp [counter2*22+4], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+5];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+6];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        writingArray [indexCount] = (char)ifExtractTemp [counter2*22+7], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+8];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+9];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        writingArray [indexCount] = (char)ifExtractTemp [counter2*22+10], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+11];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+12];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        writingArray [indexCount] = (char)ifExtractTemp [counter2*22+13], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+14];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+15];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        writingArray [indexCount] = (char)ifExtractTemp [counter2*22+16], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+17];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+18];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        writingArray [indexCount] = (char)ifExtractTemp [counter2*22+19], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+20];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+21];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                    }
                    
                    for (int counter2 = 0; counter2 < 33; counter2++) writingArray [indexCount] = 0, indexCount++;
                    
                    ofstream outfile2 (savePath.c_str(), ofstream::binary);
                    outfile2.write ((char*) writingArray, indexCount);
                    outfile2.close();
                    
                    delete [] writingArray;
                    
                    savePath = imageDisplayPath+"/"+"IFDataEntry";
                    
                    oin.open(savePath.c_str(), ios::out | ios::binary);
                    oin<<ifExtractTempCount<<endl;
                    oin.close();
                    
                    savePath = imageDisplayPath+"/"+"IFTimeLine";
                    
                    oin.open(savePath.c_str(), ios::out | ios::binary);
                    
                    for (int counter2 = 0; counter2 < arrayIFTimeLineDataEntryHold [lineageDataEntryCount-1]; counter2++){
                        oin<<arrayIFTimeLineData [lineageDataEntryCount-1][counter2]<<endl;
                    }
                    
                    oin.close();
                    
                    savePath = imageDisplayPath+"/"+"IFTimeLineEntry";
                    
                    oin.open(savePath.c_str(), ios::out | ios::binary);
                    oin<<arrayIFTimeLineDataEntryHold [lineageDataEntryCount-1]<<endl;
                    oin.close();
                    
                    savePath = imageDisplayPath+"/"+"MainTable";
                    
                    oin.open(savePath.c_str(), ios::out | ios::binary);
                    
                    for (int counter2 = 0; counter2 < arrayTableMainHold [lineageDataEntryCount-1]; counter2++){
                        oin<<arrayTableMain [lineageDataEntryCount-1][counter2]<<endl;
                    }
                    
                    oin.close();
                    
                    savePath = imageDisplayPath+"/"+"MainTableEntry";
                    
                    oin.open(savePath.c_str(), ios::out | ios::binary);
                    oin<<arrayTableMainHold [lineageDataEntryCount-1]<<endl;
                    oin.close();
                    
                    savePath = imageDisplayPath+"/"+"DetailTable";
                    
                    oin.open(savePath.c_str(), ios::out | ios::binary);
                    
                    for (int counter2 = 0; counter2 < 17; counter2++){
                        oin<<arrayTableDetail [lineageDataEntryCount-1][counter2]<<endl;
                    }
                    
                    oin.close();
                    
                    savePath = imageDisplayPath+"/IFDataStatus";
                    
                    oin.open(savePath.c_str(), ios::out | ios::binary);
                    
                    for (int counter2 = 0; counter2 < ifTimeExtractCount; counter2++){
                        oin<<arrayIfTimeStatus [lineageSelectOperationTableCurrentRow][counter2]<<endl;
                    }
                    
                    oin.close();
                    
                    savePath = imageDisplayPath+"/IFDataStatusEntry";
                    
                    oin.open(savePath.c_str(), ios::out | ios::binary);
                    oin<<arrayIfTimeStatusHold [lineageSelectOperationTableCurrentRow]<<endl;
                    oin.close();
                    
                    savePath = imageDisplayPath+"/"+"AreaData";
                    
                    oin.open(savePath.c_str(), ios::out | ios::binary);
                    
                    for (int counter2 = 0; counter2 < arrayAreaDataHold [lineageDataEntryCount-1]; counter2++){
                        oin<<arrayAreaData [lineageDataEntryCount-1][counter2]<<endl;
                    }
                    
                    oin.close();
                    
                    savePath = imageDisplayPath+"/AreaDataEntry";
                    
                    oin.open(savePath.c_str(), ios::out | ios::binary);
                    oin<<arrayAreaDataHold [lineageDataEntryCount-1]<<endl;
                    oin.close();
                    
                    savePath = imageDisplayPath+"/"+"LinkData";
                    
                    oin.open(savePath.c_str(), ios::out | ios::binary);
                    
                    for (int counter2 = 0; counter2 < lineageLinkHold [lineageDataEntryCount-1]; counter2++){
                        oin<<arrayLineageLink [lineageDataEntryCount-1][counter2]<<endl;
                    }
                    
                    oin.close();
                    
                    savePath = imageDisplayPath+"/LinkDataEntry";
                    
                    oin.open(savePath.c_str(), ios::out | ios::binary);
                    oin<<lineageLinkHold [lineageDataEntryCount-1] <<endl;
                    oin.close();
                }
                
                delete [] lineageExtractTemp;
                delete [] ifExtractTemp;
                delete [] areaExtractTemp;
                delete [] arrayLineageLinkTemp;
                delete [] arrayTableDetailTemp;
                delete [] lineageNoList;
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Entry Limit Exceeded: 100"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
            
            upLoadingFlag = 1;
            
            if (lineageOpen == 1 && lineageWindowOperation != 2) lineageListCall = 1;
            if (growthCurveOpen == 1 && growthCurveWindowOperation != 2) growthCurveCall = 1;
            if (cellDivisionOpen == 1 && cellDivisionWindowOperation != 2) cellDivisionCall = 1; //========ADD POINT
            if (doublingTimeOpen == 1 && doublingTimeWindowOperation != 2) doublingTimeCall = 1;
            if (trimOpen == 1 && trimWindowOperation != 2) trimCall = 1;
            if (lineageSelectOpen == 1 && lineageSelectWindowOperation != 2) lineageSelectCall = 1;
            if (simulationOpen == 1 && simulationOperation != 2) simulationCall = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Non-Selected Lineage Found"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Lineage Data"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)createSelected:(id)sender{
    if (lineageSelectLineageHoldCount != 0){
        int nonSelectedFind = 0;
        
        for (int counter1 = 0; counter1 < lineageSelectLineageHoldCount/2; counter1++){
            if (arrayLineageSelectLineageHold [counter1*2+1] == 2) nonSelectedFind++;
        }
        
        if (nonSelectedFind != 0){
            DIR *dir;
            struct dirent *dent;
            
            string imageDisplayPath;
            string entry;
            int maxSearchNo = 0;
            
            for (int counter1 = 0; counter1 < lineageDataEntryCount; counter1++){
                imageDisplayPath = analysisDataFolderPath+"/"+arrayTableMain [counter1][2]+"_AnalysisResults"+"/"+arrayTableMain [counter1][3]+"_IDResults";
                
                dir = opendir(imageDisplayPath.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            if ((int)entry.find("SL") != -1){
                                if (atoi(entry.substr(2, entry.find("-")-2).c_str()) > maxSearchNo) maxSearchNo = atoi(entry.substr(2, entry.find("-")-2).c_str());
                            }
                        }
                    }
                    
                    closedir(dir);
                }
            }
            
            maxSearchNo++;
            
            int findFlag = 0;
            int maxLineageNo = 0;
            
            string savePath;
            
            ofstream oin;
            
            if (lineageDataEntryCount-1 < 101){
                string treatNameExtract = arrayTableMain [lineageSelectOperationTableCurrentRow][4].substr(arrayTableMain [lineageSelectOperationTableCurrentRow][4].find("-")+1, arrayTableMain [lineageSelectOperationTableCurrentRow][4].find("_Results")-arrayTableMain [lineageSelectOperationTableCurrentRow][4].find("-")-1);
                
                imageDisplayPath = analysisDataFolderPath+"/"+arrayTableMain [lineageSelectOperationTableCurrentRow][2]+"_AnalysisResults"+"/"+arrayTableMain [lineageSelectOperationTableCurrentRow][3]+"_IDResults/"+"SL"+to_string(maxSearchNo)+"-"+treatNameExtract+"_Results";
                
                mkdir(imageDisplayPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                int *lineageNoList = new int [lineageSelectLineageHoldCount+10];
                int lineageNoListCount = 0;
                
                for (int counter2 = 0; counter2 < lineageSelectLineageHoldCount/2; counter2++){
                    if (arrayLineageSelectLineageHold [counter2*2+1] == 2){
                        lineageNoList [lineageNoListCount] = arrayLineageSelectLineageHold [counter2*2], lineageNoListCount++;
                    }
                }
                
                int *lineageExtractTemp = new int [arrayLineageDataEntryHold [lineageSelectOperationTableCurrentRow]+500];
                unsigned long lineageExtractTempCount = 0;
                unsigned long lineageExtractTempLimit = arrayLineageDataEntryHold [lineageSelectOperationTableCurrentRow]+500;
                
                for (unsigned long counter2 = 0; counter2 < arrayLineageDataEntryHold [lineageSelectOperationTableCurrentRow]/9; counter2++){
                    findFlag = 0;
                    
                    for (int counter3 = 0; counter3 < lineageNoListCount; counter3++){
                        if (arrayLineageData [lineageSelectOperationTableCurrentRow][counter2*9+6] == lineageNoList [counter3]){
                            findFlag = 1;
                            break;
                        }
                    }
                    
                    if (findFlag == 1){
                        if (lineageExtractTempCount+10 > lineageExtractTempLimit){
                            int *arrayUpDate = new int [lineageExtractTempCount+10];
                            
                            for (unsigned long counter3 = 0; counter3 < lineageExtractTempCount; counter3++) arrayUpDate [counter3] = lineageExtractTemp [counter3];
                            
                            delete [] lineageExtractTemp;
                            lineageExtractTempLimit = lineageExtractTempCount+5000;
                            lineageExtractTemp = new int [lineageExtractTempLimit];
                            
                            for (unsigned long counter3 = 0; counter3 < lineageExtractTempCount; counter3++) lineageExtractTemp [counter3] = arrayUpDate [counter3];
                            delete [] arrayUpDate;
                        }
                        
                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [lineageSelectOperationTableCurrentRow][counter2*9], lineageExtractTempCount++;
                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [lineageSelectOperationTableCurrentRow][counter2*9+1], lineageExtractTempCount++;
                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [lineageSelectOperationTableCurrentRow][counter2*9+2], lineageExtractTempCount++;
                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [lineageSelectOperationTableCurrentRow][counter2*9+3], lineageExtractTempCount++;
                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [lineageSelectOperationTableCurrentRow][counter2*9+4], lineageExtractTempCount++;
                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [lineageSelectOperationTableCurrentRow][counter2*9+5], lineageExtractTempCount++;
                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [lineageSelectOperationTableCurrentRow][counter2*9+6], lineageExtractTempCount++;
                        
                        if (fusionMoveStatus == 1 && arrayLineageData [lineageSelectOperationTableCurrentRow][counter2*9+7] != 0 && arrayLineageData [lineageSelectOperationTableCurrentRow][counter2*9+7] != arrayLineageData [lineageSelectOperationTableCurrentRow][counter2*9+6]){
                            lineageExtractTemp [lineageExtractTempCount] = 0, lineageExtractTempCount++;
                        }
                        else lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [lineageSelectOperationTableCurrentRow][counter2*9+7], lineageExtractTempCount++;
                        
                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [lineageSelectOperationTableCurrentRow][counter2*9+8], lineageExtractTempCount++;
                    }
                }
                
                //for (int counterA = 0; counterA < lineageExtractTempCount/9; counterA++){
                //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<lineageExtractTemp [counterA*9+counterB];
                //    cout<<" lineageExtractTemp"<<counterA<<endl;
                //}
                
                //----IF data: Array set----
                int *ifExtractTemp = new int [arrayIFDataEntryHold [lineageSelectOperationTableCurrentRow]+500];
                int ifExtractTempCount = 0;
                int ifExtractTempLimit = arrayIFDataEntryHold [lineageSelectOperationTableCurrentRow]+500;
                
                for (int counter2 = 0; counter2 < arrayIFDataEntryHold [lineageSelectOperationTableCurrentRow]/22; counter2++){
                    findFlag = 0;
                    
                    for (int counter3 = 0; counter3 < lineageNoListCount; counter3++){
                        if (arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+1] == lineageNoList [counter3]){
                            findFlag = 1;
                            break;
                        }
                    }
                    
                    if (findFlag == 1){
                        if (ifExtractTempCount+50 > ifExtractTempLimit){
                            int *arrayUpDate = new int [ifExtractTempCount+10];
                            
                            for (int counter3 = 0; counter3 < ifExtractTempCount; counter3++) arrayUpDate [counter3] = ifExtractTemp [counter3];
                            
                            delete [] ifExtractTemp;
                            ifExtractTempLimit = ifExtractTempCount+5000;
                            ifExtractTemp = new int [ifExtractTempLimit];
                            
                            for (int counter3 = 0; counter3 < ifExtractTempCount; counter3++) ifExtractTemp [counter3] = arrayUpDate [counter3];
                            delete [] arrayUpDate;
                        }
                        
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+1], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+2], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+3], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+4], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+5], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+6], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+7], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+8], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+9], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+10], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+11], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+12], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+13], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+14], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+15], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+16], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+17], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+18], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+19], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+20], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [lineageSelectOperationTableCurrentRow][counter2*22+21], ifExtractTempCount++;
                    }
                }
                
                //for (int counterA = 0; counterA < ifExtractTempCount/13; counterA++){
                //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<ifExtractTemp [counterA*13+counterB];
                //    cout<<" ifExtractTemp "<<counterA<<endl;
                //}
                
                //----Detail table data: Array set----
                int *arrayTableDetailTemp = new int [20];
                
                int noOfLing = 0;
                int noOfCellStart = 0;
                int noOfCellEnd = 0;
                int noOfTotalCells = 0;
                int noOfDD = 0;
                int noOfTD = 0;
                int noOfHD = 0;
                int noOfMI = 0;
                int noOfFU = 0;
                int noOfCD = 0;
                
                maxLineageNo = 0;
                
                for (unsigned long counter2 = 0; counter2 < lineageExtractTempCount/9; counter2++){
                    if (lineageExtractTemp [counter2*9+2] == arrayTableDetail[lineageSelectOperationTableCurrentRow][2] && (lineageExtractTemp [counter2*9+5] == 0 || lineageExtractTemp [counter2*9+5] == -1)){
                        noOfLing++;
                    }
                    
                    if (maxLineageNo < lineageExtractTemp [counter2*9+6]) maxLineageNo = lineageExtractTemp [counter2*9+6]; //==
                    
                    if (lineageExtractTemp [counter2*9+2] == arrayTableDetail[lineageSelectOperationTableCurrentRow][2] && lineageExtractTemp [counter2*9+5] == 0){
                        noOfCellStart++;
                    }
                    
                    if ((lineageExtractTemp [counter2*9+3] == 1 || lineageExtractTemp [counter2*9+3] == 31 || lineageExtractTemp [counter2*9+3] == 41 || lineageExtractTemp [counter2*9+3] == 51)){
                        noOfTotalCells++;
                    }
                    
                    if (lineageExtractTemp [counter2*9+2] == arrayTableDetail[lineageSelectOperationTableCurrentRow][3]) noOfCellEnd++;
                    if (lineageExtractTemp [counter2*9+3] == 32) noOfDD++;
                    if (lineageExtractTemp [counter2*9+3] == 42) noOfTD++;
                    if (lineageExtractTemp [counter2*9+3] == 52) noOfHD++;
                    if (lineageExtractTemp [counter2*9+3] == 6) noOfMI++;
                    if (lineageExtractTemp [counter2*9+3] == 91) noOfFU++;
                    if (lineageExtractTemp [counter2*9+3] == 7) noOfCD++;
                }
                
                arrayTableDetailTemp [0] = lineageDataEntryCount+1;
                arrayTableDetailTemp [1] = noOfLing;
                arrayTableDetailTemp [2] = arrayTableDetail[lineageSelectOperationTableCurrentRow][2];
                arrayTableDetailTemp [3] = arrayTableDetail[lineageSelectOperationTableCurrentRow][3];
                arrayTableDetailTemp [4] = arrayTableDetail[lineageSelectOperationTableCurrentRow][4];
                arrayTableDetailTemp [5] = arrayTableDetail[lineageSelectOperationTableCurrentRow][5];
                arrayTableDetailTemp [6] = noOfCellStart;
                arrayTableDetailTemp [7] = noOfCellEnd;
                
                double foldTemp = 0;
                
                if (noOfCellStart != 0){
                    foldTemp = noOfCellEnd/(double)noOfCellStart;
                    foldTemp = foldTemp*10+1;
                }
                else foldTemp = 1;
                
                arrayTableDetailTemp [8] = (int)foldTemp;
                arrayTableDetailTemp [9] = noOfTotalCells;
                arrayTableDetailTemp [10] = noOfDD;
                arrayTableDetailTemp [11] = noOfTD;
                arrayTableDetailTemp [12] = noOfHD;
                arrayTableDetailTemp [13] = noOfDD+noOfTD+noOfHD;
                arrayTableDetailTemp [14] = noOfMI;
                arrayTableDetailTemp [15] = noOfFU;
                arrayTableDetailTemp [16] = noOfCD;
                
                //for (int counterA = 0; counterA < 1; counterA++){
                //    for (int counterB = 0; counterB < 17; counterB++) cout<<" "<<arrayTableDetailTemp [counterA*17+counterB];
                //    cout<<" arrayTableDetailTemp "<<counterA<<endl;
                //}
                
                //----AreaData: Array set----
                int *areaExtractTemp = new int [arrayAreaDataHold [lineageSelectOperationTableCurrentRow]+500];
                int areaExtractTempCount = 0;
                int areaExtractTempLimit = arrayAreaDataHold [lineageSelectOperationTableCurrentRow]+500;
                
                for (int counter2 = 0; counter2 < arrayAreaDataHold [lineageSelectOperationTableCurrentRow]/5; counter2++){
                    findFlag = 0;
                    
                    for (int counter3 = 0; counter3 < lineageNoListCount; counter3++){
                        if (arrayAreaData [lineageSelectOperationTableCurrentRow][counter2*5] == lineageNoList [counter3]){
                            findFlag = 1;
                            break;
                        }
                    }
                    
                    if (findFlag == 1){
                        if (areaExtractTempCount+10 > areaExtractTempLimit){
                            int *arrayUpDate = new int [areaExtractTempCount+10];
                            
                            for (int counter3 = 0; counter3 < areaExtractTempCount; counter3++) arrayUpDate [counter3] = areaExtractTemp [counter3];
                            
                            delete [] areaExtractTemp;
                            areaExtractTempLimit = areaExtractTempCount+5000;
                            areaExtractTemp = new int [areaExtractTempLimit];
                            
                            for (int counter3 = 0; counter3 < areaExtractTempCount; counter3++) areaExtractTemp [counter3] = arrayUpDate [counter3];
                            delete [] arrayUpDate;
                        }
                        
                        areaExtractTemp [areaExtractTempCount] = arrayAreaData [lineageSelectOperationTableCurrentRow][counter2*5], areaExtractTempCount++;
                        areaExtractTemp [areaExtractTempCount] = arrayAreaData [lineageSelectOperationTableCurrentRow][counter2*5+1], areaExtractTempCount++;
                        areaExtractTemp [areaExtractTempCount] = arrayAreaData [lineageSelectOperationTableCurrentRow][counter2*5+2], areaExtractTempCount++;
                        areaExtractTemp [areaExtractTempCount] = arrayAreaData [lineageSelectOperationTableCurrentRow][counter2*5+3], areaExtractTempCount++;
                        areaExtractTemp [areaExtractTempCount] = arrayAreaData [lineageSelectOperationTableCurrentRow][counter2*5+4], areaExtractTempCount++;
                    }
                }
                
                //for (int counterA = 0; counterA < areaExtractTempCount/5; counterA++){
                //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<areaExtractTemp [counterA*5+counterB];
                //    cout<<" areaExtractTemp "<<counterA<<endl;
                //}
                
                //----Link Data----
                int lingNoTemp = 0;
                int matchFind = 0;
                int freeSpotFind = 0;
                int previousLengthHold = 0;
                int readingCount = 0;
                int terminationFlag = 0;
                int lengthExpansionFlag = 0;
                int entryNo = 0;
                int expansionNo = 0;
                
                int lineageLinkListLengthTemp = 4;
                int *arrayLineageLinkTemp = new int [(maxLineageNo+1)*lineageLinkListLengthTemp+11];
                int lineageLinkListTempLimit = (maxLineageNo+1)*lineageLinkListLengthTemp+11;
                
                for (int counter1 = 0; counter1 < (maxLineageNo+1)*lineageLinkListLengthTemp+11; counter1++) arrayLineageLinkTemp [counter1] = 0;
                
                for (unsigned long counter1 = 0; counter1 < lineageExtractTempCount/9; counter1++){
                    if (lineageExtractTemp [counter1*9+3] == 31 || lineageExtractTemp [counter1*9+3] == 41 || lineageExtractTemp [counter1*9+3] == 51 || lineageExtractTemp [counter1*9+3] == 1){
                        lingNoTemp = lineageExtractTemp [counter1*9+6];
                        arrayLineageLinkTemp [lingNoTemp*lineageLinkListLengthTemp] = lingNoTemp;
                    }
                }
                
                for (unsigned long counter1 = 0; counter1 < lineageExtractTempCount/9; counter1++){
                    lingNoTemp = lineageExtractTemp [counter1*9+6];
                    
                    if (lineageExtractTemp [counter1*9+7] != 0 && lineageExtractTemp [counter1*9+7] != lingNoTemp){
                        matchFind = 0;
                        freeSpotFind = 0;
                        
                        for (int counter2 = 1; counter2 < lineageLinkListLengthTemp; counter2++){
                            if (arrayLineageLinkTemp [lingNoTemp*lineageLinkListLengthTemp+counter2] == lineageExtractTemp [counter1*9+7]){
                                matchFind = 1;
                            }
                            
                            if (arrayLineageLinkTemp [lingNoTemp*lineageLinkListLengthTemp+counter2] == 0 && freeSpotFind == 0){
                                freeSpotFind = counter2;
                            }
                        }
                        
                        if (matchFind == 0){
                            if (freeSpotFind == 0){
                                previousLengthHold = lineageLinkListLengthTemp;
                                int *arrayUpDate = new int [lineageLinkListTempLimit+11];
                                
                                for (int counter2 = 0; counter2 < (maxLineageNo+1)*lineageLinkListLengthTemp; counter2++) arrayUpDate [counter2] = arrayLineageLinkTemp [counter2];
                                
                                delete [] arrayLineageLinkTemp;
                                lineageLinkListLengthTemp = lineageLinkListLengthTemp+2;
                                arrayLineageLinkTemp = new int [(maxLineageNo+1)*lineageLinkListLengthTemp+11];
                                lineageLinkListTempLimit = (maxLineageNo+1)*lineageLinkListLengthTemp+11;
                                
                                readingCount = 0;
                                
                                for (int counter2 = 0; counter2 <= maxLineageNo; counter2++){
                                    for (int counter3 = 0; counter3 < previousLengthHold; counter3++){
                                        arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+counter3] = arrayUpDate [readingCount], readingCount++;
                                    }
                                    
                                    arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+previousLengthHold] = 0;
                                    arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+previousLengthHold+1] = 0;
                                }
                                
                                delete [] arrayUpDate;
                                
                                freeSpotFind = previousLengthHold;
                            }
                            
                            arrayLineageLinkTemp [lingNoTemp*lineageLinkListLengthTemp] = lingNoTemp;
                            arrayLineageLinkTemp [lingNoTemp*lineageLinkListLengthTemp+freeSpotFind] = lineageExtractTemp [counter1*9+7];
                        }
                    }
                }
                
                //for (int counterA = 0; counterA <= maxLingNo; counterA++){
                //    for (int counterB = 0; counterB < lineageLinkListLength; counterB++) cout<<" "<<arrayLineageLinkList [counterA*lineageLinkListLength+counterB];
                //    cout<<" arrayLineageLinkList "<<counterA<<endl;
                //}
                
                for (int counter1 = 1; counter1 <= maxLineageNo; counter1++){
                    if (arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp] > 0 && arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp+1] != 0){
                        freeSpotFind = -1;
                        
                        for (int counter2 = 1; counter2 < lineageLinkListLengthTemp; counter2++){
                            if (arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp+counter2] == 0){
                                freeSpotFind = counter2;
                                break;
                            }
                        }
                        
                        if (freeSpotFind == -1) freeSpotFind = 4;
                        
                        do{
                            
                            terminationFlag = 1;
                            
                            for (int counter2 = 1; counter2 < lineageLinkListLengthTemp; counter2++){
                                if (arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp+counter2] != 0){
                                    lengthExpansionFlag = 0;
                                    
                                    for (int counter3 = 1; counter3 <= maxLineageNo; counter3++){
                                        if (arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp] == arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp+counter2]){
                                            entryNo = 0;
                                            
                                            for (int counter4 = 1; counter4 < lineageLinkListLengthTemp; counter4++){
                                                findFlag = 0;
                                                
                                                for (int counter5 = 1; counter5 < lineageLinkListLengthTemp; counter5++){
                                                    if (arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp+counter4] != 0 && (arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp+counter4] == arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp+counter5] || arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp+counter4] == counter1)){
                                                        findFlag = 1;
                                                    }
                                                    else if (arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp+counter4] == 0) findFlag = 1;
                                                }
                                                
                                                if (findFlag == 0) entryNo++;
                                            }
                                            
                                            if (entryNo != 0){
                                                if (freeSpotFind == lineageLinkListLengthTemp || freeSpotFind+entryNo > lineageLinkListLengthTemp){
                                                    previousLengthHold = lineageLinkListLengthTemp;
                                                    int *arrayUpDate = new int [lineageLinkListTempLimit+11];
                                                    
                                                    for (int counter4 = 0; counter4 < (maxLineageNo+1)*lineageLinkListLengthTemp; counter4++) arrayUpDate [counter4] = arrayLineageLinkTemp [counter4];
                                                    
                                                    if ((freeSpotFind+entryNo)%2 != 0) expansionNo = freeSpotFind+entryNo+1;
                                                    else expansionNo = freeSpotFind+entryNo;
                                                    
                                                    delete [] arrayLineageLinkTemp;
                                                    lineageLinkListLengthTemp = expansionNo+2;
                                                    arrayLineageLinkTemp = new int [(maxLineageNo+1)*lineageLinkListLengthTemp+lineageLinkListLengthTemp+1];
                                                    lineageLinkListTempLimit = (maxLineageNo+1)*lineageLinkListLengthTemp+lineageLinkListLengthTemp+1;
                                                    
                                                    expansionNo = lineageLinkListLengthTemp-previousLengthHold;
                                                    
                                                    readingCount = 0;
                                                    
                                                    for (int counter4 = 0; counter4 <= maxLineageNo; counter4++){
                                                        for (int counter5 = 0; counter5 < previousLengthHold; counter5++){
                                                            arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+counter5] = arrayUpDate [readingCount], readingCount++;
                                                        }
                                                        
                                                        for (int counter5 = 0; counter5 < expansionNo; counter5++){
                                                            arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+previousLengthHold+counter5] = 0;
                                                        }
                                                    }
                                                    
                                                    delete [] arrayUpDate;
                                                    
                                                    lengthExpansionFlag = 1;
                                                    
                                                    break;
                                                }
                                                else{
                                                    
                                                    for (int counter4 = 1; counter4 < lineageLinkListLengthTemp; counter4++){
                                                        findFlag = 0;
                                                        
                                                        for (int counter5 = 1; counter5 < lineageLinkListLengthTemp; counter5++){
                                                            if (arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp+counter4] != 0 && (arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp+counter4] == arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp+counter5] || arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp+counter4] == counter1)){
                                                                findFlag = 1;
                                                            }
                                                            else if (arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp+counter4] == 0) findFlag = 1;
                                                        }
                                                        
                                                        if (findFlag != 1){
                                                            arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp+freeSpotFind] = arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp+counter4];
                                                            
                                                            freeSpotFind++;
                                                        }
                                                    }
                                                    
                                                    arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp] = -1;
                                                    break;
                                                }
                                            }
                                            else arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp] = -1;
                                        }
                                    }
                                    
                                    if (lengthExpansionFlag == 1){
                                        break;
                                    }
                                }
                                
                                if (counter2 == lineageLinkListLengthTemp-1) terminationFlag = 0;
                            }
                            
                        } while (terminationFlag == 1);
                    }
                }
                
                //for (int counterA = 0; counterA <= maxLineageNo; counterA++){
                //    for (int counterB = 0; counterB < lineageLinkListLengthTemp; counterB++) cout<<" "<<arrayLineageLinkTemp [counterA*lineageLinkListLengthTemp+counterB];
                //    cout<<" arrayLineageLinkTemp "<<counterA<<endl;
                //}
                
                int *numberOfEntryList = new int [lineageLinkListLengthTemp+1];
                int *numberOfEntryList2 = new int [lineageLinkListLengthTemp+1];
                int numberOfFusionEntry = 0;
                int smallestEntry2 = 0;
                int remainingFlag = 0;
                int smallestEntry = 0;
                int smallestEntryPosition = 0;
                
                for (int counter1 = 1; counter1 <= maxLineageNo; counter1++){
                    if (arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp] > 0 && arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp+1] != 0){
                        numberOfFusionEntry = 0;
                        
                        for (int counter2 = 0; counter2 < lineageLinkListLengthTemp; counter2++){
                            if (arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp+counter2] != 0){
                                numberOfFusionEntry++;
                            }
                        }
                        
                        if (numberOfFusionEntry > 1){
                            for (int counter2 = 0; counter2 < lineageLinkListLengthTemp; counter2++){
                                if (arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp+counter2] != 0){
                                    numberOfEntryList [counter2] = arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp+counter2];
                                }
                                else numberOfEntryList [counter2] = 0;
                                
                                numberOfEntryList2 [counter2] = 0;
                            }
                            
                            smallestEntry2 = 1;
                            
                            do{
                                
                                terminationFlag = 1;
                                remainingFlag = 0;
                                smallestEntry = 100000;
                                smallestEntryPosition = 0;
                                
                                for (int counter2 = 1; counter2 < lineageLinkListLengthTemp; counter2++){
                                    if (numberOfEntryList [counter2] != 0 && numberOfEntryList [counter2] < smallestEntry){
                                        smallestEntry = numberOfEntryList [counter2];
                                        smallestEntryPosition = counter2;
                                        remainingFlag = 1;
                                    }
                                }
                                
                                if (remainingFlag == 0) terminationFlag = 0;
                                else{
                                    
                                    numberOfEntryList2 [smallestEntry2] = numberOfEntryList [smallestEntryPosition], smallestEntry2++;
                                    numberOfEntryList [smallestEntryPosition] = 0;
                                }
                                
                            } while (terminationFlag == 1);
                            
                            for (int counter2 = 1; counter2 < lineageLinkListLengthTemp; counter2++){
                                arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp+counter2] = numberOfEntryList2 [counter2];
                            }
                        }
                    }
                }
                
                delete [] numberOfEntryList;
                delete [] numberOfEntryList2;
                
                //----Lineage Data type: Array Set----
                for (int counter2 = 0; counter2 < 7; counter2++){
                    arrayLineageDataType [lineageDataEntryCount][counter2] = arrayLineageDataType [lineageSelectOperationTableCurrentRow][counter2];
                }
                
                arrayLineageDataType [lineageDataEntryCount][0] = to_string(lineageDataEntryCount+1);
                arrayLineageDataType [lineageDataEntryCount][1] = "SL"+to_string(maxSearchNo);
                
                //for (int counterA = 0; counterA <= lineageDataEntryCount; counterA++){
                //    cout<<" "<<arrayLineageDataType [counterA][0]<<" "<<arrayLineageDataType [counterA][1]<<" "<<arrayLineageDataType [counterA][2]<<" "<<arrayLineageDataType [counterA][3]<<" "<<arrayLineageDataType [counterA][4]<<" "<<arrayLineageDataType [counterA][5]<<" "<<arrayLineageDataType [counterA][6]<<" "<<arrayLineageDataType [counterA][7]<<" LineageType "<<endl;
                //}
                
                //for (int counterA = 0; counterA < lineageFluorescentDataTypeEntryCount; counterA++){
                //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageFluorescentDataType [counterA][counterB];
                //    cout<<" arrayLineageFluorescentDataType "<<counterA+1<<endl;
                //}
                
                //----LineageFluorescentDataType: Array Set----
                int fluorescentDataEntryCount = lineageFluorescentDataTypeEntryCount;
                
                for (int counter2 = 0; counter2 < fluorescentDataEntryCount; counter2++){
                    if (lineageFluorescentDataTypeEntryCount+9 > lineageFluorescentDataTypeEntryLimit) [self lineageFluorescentDataTypeUpDate];
                    
                    if (atoi(arrayLineageFluorescentDataType [counter2][0].c_str()) == lineageSelectOperationTableCurrentRow+1){
                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][0] = to_string(lineageDataEntryCount+1);
                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][1] = arrayLineageFluorescentDataType [counter2][1];
                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][2] = arrayLineageFluorescentDataType [counter2][2];
                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][3] = arrayLineageFluorescentDataType [counter2][3];
                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][4] = arrayLineageFluorescentDataType [counter2][4];
                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][5] = arrayLineageFluorescentDataType [counter2][5];
                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][6] = arrayLineageFluorescentDataType [counter2][6];
                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][7] = arrayLineageFluorescentDataType [counter2][7];
                        
                        lineageFluorescentDataTypeEntryCount++;
                    }
                }
                
                //for (int counterA = 0; counterA < lineageFluorescentDataTypeEntryCount; counterA++){
                //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageFluorescentDataType [counterA][counterB];
                //    cout<<" arrayLineageFluorescentDataType "<<counterA+1<<endl;
                //}
                
                //----Data save----
                savePath = imageDisplayPath+"/"+"*LineageDataAddition.dat";
                
                oin.open(savePath.c_str(), ios::out);
                oin<<to_string(lineageDataEntryCount+1)<<endl;
                oin<<"SL"+to_string(maxSearchNo)<<endl;
                oin<<arrayLineageDataType [lineageDataEntryCount][2]<<endl;
                oin<<arrayLineageDataType [lineageDataEntryCount][3]<<endl;
                oin<<arrayLineageDataType [lineageDataEntryCount][4]<<endl;
                oin<<arrayLineageDataType [lineageDataEntryCount][5]<<endl;
                oin<<arrayLineageDataType [lineageDataEntryCount][6]<<endl;
                
                for (int counter2 = 0; counter2 < lineageFluorescentDataTypeEntryCount; counter2++){
                    if (atoi(arrayLineageFluorescentDataType [counter2][0].c_str()) == lineageDataEntryCount+1){
                        oin<<arrayLineageFluorescentDataType [counter2][0]<<endl;
                        oin<<arrayLineageFluorescentDataType [counter2][1]<<endl;
                        oin<<arrayLineageFluorescentDataType [counter2][2]<<endl;
                        oin<<arrayLineageFluorescentDataType [counter2][3]<<endl;
                        oin<<arrayLineageFluorescentDataType [counter2][4]<<endl;
                        oin<<arrayLineageFluorescentDataType [counter2][5]<<endl;
                        oin<<arrayLineageFluorescentDataType [counter2][6]<<endl;
                        oin<<arrayLineageFluorescentDataType [counter2][7]<<endl;
                    }
                }
                
                oin.close();
                
                if (lineageDataEntryCount < 101){
                    delete [] arrayLineageData [lineageDataEntryCount];
                    delete [] arrayIFData [lineageDataEntryCount];
                    delete [] arrayIFTimeLineData [lineageDataEntryCount];
                    delete [] arrayTableMain [lineageDataEntryCount];
                    delete [] arrayIfTimeStatus [lineageDataEntryCount];
                    delete [] arrayAreaData [lineageDataEntryCount];
                    delete [] arrayLineageLink [lineageDataEntryCount];
                    
                    arrayLineageData [lineageDataEntryCount] = new int [lineageExtractTempCount+10];
                    arrayIFData [lineageDataEntryCount] = new int [ifExtractTempCount+10];
                    arrayIFTimeLineData [lineageDataEntryCount] = new int [arrayIFTimeLineDataEntryHold [lineageSelectOperationTableCurrentRow]+10];
                    arrayTableMain [lineageDataEntryCount] = new string [arrayTableMainHold [lineageSelectOperationTableCurrentRow]+10];
                    arrayIfTimeStatus [lineageDataEntryCount] = new int [arrayIfTimeStatusHold [lineageSelectOperationTableCurrentRow]+10];
                    arrayAreaData [lineageDataEntryCount] = new int [areaExtractTempCount+10];
                    arrayLineageLink [lineageDataEntryCount] = new int [(maxLineageNo+1)*lineageLinkListLengthTemp+lineageLinkListLengthTemp+10];
                    
                    lineageDataEntryCount++;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Entry Limit Exceeded: 100"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                
                if (lineageDataEntryCount-1 < 101){
                    for (unsigned long counter2 = 0; counter2 < lineageExtractTempCount; counter2++) arrayLineageData [lineageDataEntryCount-1][counter2] = lineageExtractTemp [counter2];
                    
                    arrayLineageDataEntryHold [lineageDataEntryCount-1] = (unsigned long)lineageExtractTempCount;
                    
                    //for (int counterA = 0; counterA < arrayLineageDataEntryHold [lineageDataEntryCount-1]/9; counterA++){
                    //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayLineageData [lineageDataEntryCount-1][counterA*9+counterB];
                    //    cout<<" arrayLineageData "<<counterA<<endl;
                    //}
                    
                    for (int counter2 = 0; counter2 < ifExtractTempCount; counter2++) arrayIFData [lineageDataEntryCount-1][counter2] = ifExtractTemp [counter2];
                    
                    arrayIFDataEntryHold [lineageDataEntryCount-1] = ifExtractTempCount;
                    
                    //for (int counterA = 0; counterA < arrayIFDataEntryHold [lineageDataEntryCount-1]/13; counterA++){
                    //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<arrayIFData [lineageDataEntryCount-1][counterA*13+counterB];
                    //    cout<<" arrayIFData "<<counterA<<endl;
                    //}
                    
                    for (int counter2 = 0; counter2 < arrayIFTimeLineDataEntryHold [lineageSelectOperationTableCurrentRow]; counter2++){
                        arrayIFTimeLineData [lineageDataEntryCount-1][counter2] = arrayIFTimeLineData [lineageSelectOperationTableCurrentRow][counter2];
                    }
                    
                    arrayIFTimeLineDataEntryHold [lineageDataEntryCount-1] = arrayIFTimeLineDataEntryHold [lineageSelectOperationTableCurrentRow];
                    
                    for (int counter2 = 0; counter2 < arrayTableMainHold [lineageSelectOperationTableCurrentRow]; counter2++) arrayTableMain [lineageDataEntryCount-1][counter2] = arrayTableMain [lineageSelectOperationTableCurrentRow][counter2];
                    
                    arrayTableMain [lineageDataEntryCount-1][0] = to_string(lineageDataEntryCount);
                    arrayTableMain [lineageDataEntryCount-1][1] = "SL";
                    arrayTableMain [lineageDataEntryCount-1][4] = "SL"+to_string(maxSearchNo)+"-"+treatNameExtract;
                    
                    arrayTableMainHold [lineageDataEntryCount-1] = arrayTableMainHold [lineageSelectOperationTableCurrentRow];
                    
                    for (int counter2 = 0; counter2 < 17; counter2++) arrayTableDetail [lineageDataEntryCount-1][counter2] = arrayTableDetailTemp [counter2];
                    
                    for (int counter2 = 0; counter2 < arrayIfTimeStatusHold [lineageSelectOperationTableCurrentRow]; counter2++) arrayIfTimeStatus [lineageDataEntryCount-1][counter2] = ifTimeExtract [counter2];
                    
                    arrayIfTimeStatusHold [lineageDataEntryCount-1] = arrayIfTimeStatusHold [lineageSelectOperationTableCurrentRow];
                    
                    for (int counter2 = 0; counter2 < areaExtractTempCount; counter2++) arrayAreaData [lineageDataEntryCount-1][counter2] = areaExtractTemp [counter2];
                    
                    arrayAreaDataHold [lineageDataEntryCount-1] = areaExtractTempCount;
                    
                    //**********arrayLinkData**********
                    for (int counter2 = 0; counter2 < (maxLineageNo+1)*lineageLinkListLengthTemp; counter2++){
                        arrayLineageLink [lineageDataEntryCount-1][counter2] = arrayLineageLinkTemp [counter2];
                    }
                    
                    arrayLineageLink [lineageDataEntryCount-1][0] = lineageLinkListLengthTemp;
                    
                    lineageLinkHold [lineageDataEntryCount-1] = (maxLineageNo+1)*lineageLinkListLengthTemp;
                    
                    savePath = imageDisplayPath+"/"+"LineageDataAnalysis";
                    
                    char *writingArray = new char [lineageExtractTempCount/9*28+100];
                    
                    long indexCount = 0;
                    int readBit [4];
                    int dataTemp;
                    
                    for (unsigned long counter2 = 0; counter2 < lineageExtractTempCount/9; counter2++){
                        if (lineageExtractTemp [counter2*9] < 0){
                            writingArray [indexCount] = 1, indexCount++;
                            dataTemp = lineageExtractTemp [counter2*9]*-1;
                        }
                        else{
                            
                            writingArray [indexCount] = 0, indexCount++;
                            dataTemp = lineageExtractTemp [counter2*9];
                        }
                        
                        readBit [0] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [1] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        
                        if (lineageExtractTemp [counter2*9+1] < 0){
                            writingArray [indexCount] = 1, indexCount++;
                            dataTemp = lineageExtractTemp [counter2*9+1]*-1;
                        }
                        else{
                            
                            writingArray [indexCount] = 0, indexCount++;
                            dataTemp = lineageExtractTemp [counter2*9+1];
                        }
                        
                        readBit [0] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [1] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        
                        dataTemp = lineageExtractTemp [counter2*9+2];
                        readBit [0] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [1] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        
                        writingArray [indexCount] = (char)lineageExtractTemp [counter2*9+3], indexCount++;
                        
                        if (lineageExtractTemp [counter2*9+4] < 0){
                            writingArray [indexCount] = 1, indexCount++;
                            dataTemp = lineageExtractTemp [counter2*9+4]*-1;
                        }
                        else{
                            
                            writingArray [indexCount] = 0, indexCount++;
                            dataTemp = lineageExtractTemp [counter2*9+4];
                        }
                        
                        readBit [0] = dataTemp/16777216;
                        dataTemp = dataTemp%16777216;
                        readBit [1] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [2] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [3] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        writingArray [indexCount] = (char)readBit [3], indexCount++;
                        
                        if (lineageExtractTemp [counter2*9+5] < 0){
                            writingArray [indexCount] = 1, indexCount++;
                            dataTemp = lineageExtractTemp [counter2*9+5]*-1;
                        }
                        else{
                            
                            writingArray [indexCount] = 0, indexCount++;
                            dataTemp = lineageExtractTemp [counter2*9+5];
                        }
                        
                        readBit [0] = dataTemp/16777216;
                        dataTemp = dataTemp%16777216;
                        readBit [1] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [2] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [3] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        writingArray [indexCount] = (char)readBit [3], indexCount++;
                        
                        dataTemp = lineageExtractTemp [counter2*9+6];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = lineageExtractTemp [counter2*9+7];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = lineageExtractTemp [counter2*9+8];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                    }
                    
                    for (int counter2 = 0; counter2 < 28; counter2++) writingArray [indexCount] = 0, indexCount++;
                    
                    ofstream outfile (savePath.c_str(), ofstream::binary);
                    outfile.write ((char*) writingArray, indexCount);
                    outfile.close();
                    
                    delete [] writingArray;
                    
                    savePath = imageDisplayPath+"/"+"LineageDataAnalysisEntry";
                    
                    oin.open(savePath.c_str(), ios::out | ios::binary);
                    oin<<lineageExtractTempCount<<endl;
                    oin.close();
                    
                    savePath = imageDisplayPath+"/"+"IFData";
                    
                    writingArray = new char [ifExtractTempCount/22*60+60];
                    
                    indexCount = 0;
                    
                    for (int counter2 = 0; counter2 < ifExtractTempCount/22; counter2++){
                        if (ifExtractTemp [counter2*22] < 0){
                            writingArray [indexCount] = 1, indexCount++;
                            dataTemp = ifExtractTemp [counter2*22]*-1;
                        }
                        else{
                            
                            writingArray [indexCount] = 0, indexCount++;
                            dataTemp = ifExtractTemp [counter2*22];
                        }
                        
                        readBit [0] = dataTemp/16777216;
                        dataTemp = dataTemp%16777216;
                        readBit [1] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [2] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [3] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        writingArray [indexCount] = (char)readBit [3], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+1];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+2];
                        readBit [0] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [1] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        
                        writingArray [indexCount] = (char)ifExtractTemp [counter2*22+3], indexCount++;
                        
                        writingArray [indexCount] = (char)ifExtractTemp [counter2*22+4], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+5];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+6];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        writingArray [indexCount] = (char)ifExtractTemp [counter2*22+7], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+8];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+9];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        writingArray [indexCount] = (char)ifExtractTemp [counter2*22+10], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+11];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+12];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        writingArray [indexCount] = (char)ifExtractTemp [counter2*22+13], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+14];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+15];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        writingArray [indexCount] = (char)ifExtractTemp [counter2*22+16], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+17];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+18];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        writingArray [indexCount] = (char)ifExtractTemp [counter2*22+19], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+20];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = ifExtractTemp [counter2*22+21];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                    }
                    
                    for (int counter2 = 0; counter2 < 33; counter2++) writingArray [indexCount] = 0, indexCount++;
                    
                    ofstream outfile2 (savePath.c_str(), ofstream::binary);
                    outfile2.write ((char*) writingArray, indexCount);
                    outfile2.close();
                    
                    delete [] writingArray;
                    
                    savePath = imageDisplayPath+"/"+"IFDataEntry";
                    
                    oin.open(savePath.c_str(), ios::out | ios::binary);
                    oin<<ifExtractTempCount<<endl;
                    oin.close();
                    
                    savePath = imageDisplayPath+"/"+"IFTimeLine";
                    
                    oin.open(savePath.c_str(), ios::out | ios::binary);
                    
                    for (int counter2 = 0; counter2 < arrayIFTimeLineDataEntryHold [lineageDataEntryCount-1]; counter2++){
                        oin<<arrayIFTimeLineData [lineageDataEntryCount-1][counter2]<<endl;
                    }
                    
                    oin.close();
                    
                    savePath = imageDisplayPath+"/"+"IFTimeLineEntry";
                    
                    oin.open(savePath.c_str(), ios::out | ios::binary);
                    oin<<arrayIFTimeLineDataEntryHold [lineageDataEntryCount-1]<<endl;
                    oin.close();
                    
                    savePath = imageDisplayPath+"/"+"MainTable";
                    
                    oin.open(savePath.c_str(), ios::out | ios::binary);
                    
                    for (int counter2 = 0; counter2 < arrayTableMainHold [lineageDataEntryCount-1]; counter2++){
                        oin<<arrayTableMain [lineageDataEntryCount-1][counter2]<<endl;
                    }
                    
                    oin.close();
                    
                    savePath = imageDisplayPath+"/"+"MainTableEntry";
                    
                    oin.open(savePath.c_str(), ios::out | ios::binary);
                    oin<<arrayTableMainHold [lineageDataEntryCount-1]<<endl;
                    oin.close();
                    
                    savePath = imageDisplayPath+"/"+"DetailTable";
                    
                    oin.open(savePath.c_str(), ios::out | ios::binary);
                    
                    for (int counter2 = 0; counter2 < 17; counter2++){
                        oin<<arrayTableDetail [lineageDataEntryCount-1][counter2]<<endl;
                    }
                    
                    oin.close();
                    
                    savePath = imageDisplayPath+"/IFDataStatus";
                    
                    oin.open(savePath.c_str(), ios::out | ios::binary);
                    
                    for (int counter2 = 0; counter2 < ifTimeExtractCount; counter2++){
                        oin<<arrayIfTimeStatus [lineageSelectOperationTableCurrentRow][counter2]<<endl;
                    }
                    
                    oin.close();
                    
                    savePath = imageDisplayPath+"/IFDataStatusEntry";
                    
                    oin.open(savePath.c_str(), ios::out | ios::binary);
                    oin<<arrayIfTimeStatusHold [lineageSelectOperationTableCurrentRow]<<endl;
                    oin.close();
                    
                    savePath = imageDisplayPath+"/"+"AreaData";
                    
                    oin.open(savePath.c_str(), ios::out | ios::binary);
                    
                    for (int counter2 = 0; counter2 < arrayAreaDataHold [lineageDataEntryCount-1]; counter2++){
                        oin<<arrayAreaData [lineageDataEntryCount-1][counter2]<<endl;
                    }
                    
                    oin.close();
                    
                    savePath = imageDisplayPath+"/AreaDataEntry";
                    
                    oin.open(savePath.c_str(), ios::out | ios::binary);
                    oin<<arrayAreaDataHold [lineageDataEntryCount-1]<<endl;
                    oin.close();
                    
                    savePath = imageDisplayPath+"/"+"LinkData";
                    
                    oin.open(savePath.c_str(), ios::out | ios::binary);
                    
                    for (int counter2 = 0; counter2 < lineageLinkHold [lineageDataEntryCount-1]; counter2++){
                        oin<<arrayLineageLink [lineageDataEntryCount-1][counter2]<<endl;
                    }
                    
                    oin.close();
                    
                    savePath = imageDisplayPath+"/LinkDataEntry";
                    
                    oin.open(savePath.c_str(), ios::out | ios::binary);
                    oin<<lineageLinkHold [lineageDataEntryCount-1] <<endl;
                    oin.close();
                }
                
                delete [] lineageExtractTemp;
                delete [] ifExtractTemp;
                delete [] areaExtractTemp;
                delete [] arrayLineageLinkTemp;
                delete [] arrayTableDetailTemp;
                delete [] lineageNoList;
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Entry Limit Exceeded: 100"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
            
            upLoadingFlag = 1;
            
            if (lineageOpen == 1 && lineageWindowOperation != 2) lineageListCall = 1;
            if (growthCurveOpen == 1 && growthCurveWindowOperation != 2) growthCurveCall = 1;
            if (cellDivisionOpen == 1 && cellDivisionWindowOperation != 2) cellDivisionCall = 1; //========ADD POINT
            if (doublingTimeOpen == 1 && doublingTimeWindowOperation != 2) doublingTimeCall = 1;
            if (trimOpen == 1 && trimWindowOperation != 2) trimCall = 1;
            if (lineageSelectOpen == 1 && lineageSelectWindowOperation != 2) lineageSelectCall = 1;
            if (simulationOpen == 1 && simulationOperation != 2) simulationCall = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Non-Selected Lineage Found"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Lineage Data"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)fusionMove:(id)sender{
    NSAlert *alert = [[NSAlert alloc] init];
    
    [alert addButtonWithTitle:@"OK"];
    [alert addButtonWithTitle:@"Cancel"];
    [alert setMessageText:@"Lineage List Will Be Cleared"];
    [alert setAlertStyle:NSAlertStyleWarning];
    
    if ([alert runModal] == NSAlertFirstButtonReturn){
        
        if (fusionMoveStatus == 0){
            fusionMoveStatus = 1;
            lineageSelectLineageHoldCount = 0;
            [fusionMoveDisplay setStringValue:@"Individual"];
        }
        else{
            
            fusionMoveStatus = 0;
            lineageSelectLineageHoldCount = 0;
            [fusionMoveDisplay setStringValue:@"Togther"];
        }
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLineageSelectTable2 object:self];
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLineageSelectTable3 object:self];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)resetSelect:(id)sender{
    if (lineageSelectLineageHoldCount != 0){
        for (int counter1 = 0; counter1 < lineageSelectLineageHoldCount/2; counter1++){
            if (arrayLineageSelectLineageHold [counter1*2+1] == 2) arrayLineageSelectLineageHold [counter1*2+1] = 1;
        }
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLineageSelectTable2 object:self];
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLineageSelectTable3 object:self];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Lineage Data"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)randomSelect:(id)sender{
    if (lineageSelectLineageHoldCount != 0){
        int noOfPickInt = [noOfPickDisplay intValue];
        
        if (noOfPickInt > 10 && noOfPickInt < (lineageSelectLineageHoldCount/2)-10){
            int random = 0;
            int terminationFlag = 0;
            int entryNo = 0;
            int entryNoIncrementCheck = 0;
            int lineageEntryCheck = 0;
            unsigned long lineageEntrySize = 0;
            int lineageEntryNo = 0;
            int lineageSelectedNo = 0;
            int lineageLinkListLengthNonSel = 0;
            int fuseLingListCount = 0;
            int breakFlag = 0;
            int entryCheckFlag = 0;
            
            do{
                
                terminationFlag = 1;
                random = rand() % lineageSelectLineageHoldCount/2+1;
                
                if (fusionMoveStatus == 1){
                    if (arrayLineageSelectLineageHold [random*2+1] == 1){
                        arrayLineageSelectLineageHold [random*2+1] = 2;
                        entryNo++;
                        entryNoIncrementCheck = 0;
                        lineageEntryCheck++;
                    }
                    else entryNoIncrementCheck++;
                }
                else{
                    
                    lineageEntrySize = arrayLineageDataEntryHold [lineageSelectOperationTableCurrentRow];
                    lineageEntryNo = 0;
                    
                    for (unsigned long counter3 = 0; counter3 < lineageEntrySize/9; counter3++){
                        if (arrayLineageData [lineageSelectOperationTableCurrentRow][counter3*9+6] > lineageEntryNo){
                            lineageEntryNo = arrayLineageData [lineageSelectOperationTableCurrentRow][counter3*9+6];
                        }
                    }
                    
                    lineageSelectedNo = random;
                    lineageLinkListLengthNonSel = arrayLineageLink [lineageSelectOperationTableCurrentRow][0];
                    
                    int *fuseLingList = new int [lineageLinkListLengthNonSel+1];
                    fuseLingListCount = 0;
                    
                    breakFlag = 0;
                    
                    for (int counter1 = 1; counter1 <= lineageEntryNo; counter1++){
                        if (arrayLineageLink [lineageSelectOperationTableCurrentRow][counter1*lineageLinkListLength] != -1){
                            for (int counter2 = 0; counter2 < lineageLinkListLengthNonSel; counter2++){
                                if (arrayLineageLink [lineageSelectOperationTableCurrentRow][counter1*lineageLinkListLength+counter2] == lineageSelectedNo){
                                    for (int counter3 = 0; counter3 < lineageLinkListLengthNonSel; counter3++){
                                        if (arrayLineageLink [lineageSelectOperationTableCurrentRow][counter1*lineageLinkListLength+counter3] != 0){
                                            fuseLingList [fuseLingListCount] = arrayLineageLink [lineageSelectOperationTableCurrentRow][counter1*lineageLinkListLength+counter3], fuseLingListCount++;
                                        }
                                    }
                                    
                                    breakFlag = 1;
                                    break;
                                }
                            }
                            
                            if (breakFlag == 1){
                                break;
                            }
                        }
                    }
                    
                    entryCheckFlag = 0;
                    
                    for (int counter1 = 0; counter1 < fuseLingListCount; counter1++){
                        if (arrayLineageSelectLineageHold [(fuseLingList [counter1]-1)*2+1] == 1){
                            arrayLineageSelectLineageHold [(fuseLingList [counter1]-1)*2+1] = 2;
                            entryCheckFlag = 1;
                            lineageEntryCheck++;
                        }
                    }
                    
                    if (entryCheckFlag == 1){
                        entryNo++;
                        entryNoIncrementCheck = 0;
                    }
                    else entryNoIncrementCheck++;
                    
                    delete [] fuseLingList;
                }
                
                if (noOfPickInt == entryNo || lineageSelectLineageHoldCount/2 == lineageEntryCheck || entryNoIncrementCheck == 10){
                    terminationFlag = 0;
                }
                
            } while (terminationFlag == 1);
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLineageSelectTable2 object:self];
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLineageSelectTable3 object:self];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Number Must Be >= 10 And <= -10 Of Total Number Of Ling"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Lineage Data"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)reDisplayWindow{
    if (lineageSelectWindowOperation == 3){
        [lineageSelectWindow makeKeyAndOrderFront:self];
        lineageSelectWindowOperation = 1;
        [lineageSelectTimer invalidate];
    }
}

-(IBAction)closeWindow:(id)sender{
    [lineageSelectWindow orderOut:self];
    lineageSelectWindowOperation = 2;
    
    lineageSelectTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
}

-(void)lineageFluorescentDataTypeUpDate{
    string **arrayLineageFluorescentDataTypeTemp = new string *[lineageFluorescentDataTypeEntryLimit];
    
    for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryLimit; counter1++){
        arrayLineageFluorescentDataTypeTemp [counter1] = new string [9];
    }
    
    int lineageFluorescentDataTypeEntryLimitTemp = lineageFluorescentDataTypeEntryLimit;
    int lineageFluorescentEntryCount = 0;
    
    for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryCount; counter1++){
        for (int counter2 = 0; counter2 < 8; counter2++){
            arrayLineageFluorescentDataTypeTemp [lineageFluorescentEntryCount][counter2] = arrayLineageFluorescentDataType [counter1][counter2];
        }
        
        lineageFluorescentEntryCount++;
    }
    
    for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryLimit; counter1++){
        delete [] arrayLineageFluorescentDataType [counter1];
    }
    
    delete [] arrayLineageFluorescentDataType;
    
    arrayLineageFluorescentDataType = new string *[lineageFluorescentDataTypeEntryLimit+320];
    
    for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryLimit+320; counter1++){
        arrayLineageFluorescentDataType [counter1] = new string [9];
    }
    
    lineageFluorescentDataTypeEntryLimit = lineageFluorescentDataTypeEntryLimit+320;
    lineageFluorescentDataTypeEntryCount = 0;
    
    for (int counter1 = 0; counter1 < lineageFluorescentEntryCount; counter1++){
        for (int counter2 = 0; counter2 < 8; counter2++){
            arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][counter2] = arrayLineageFluorescentDataTypeTemp [counter1][counter2];
        }
        
        lineageFluorescentDataTypeEntryCount++;
    }
    
    for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryLimitTemp; counter1++){
        delete [] arrayLineageFluorescentDataTypeTemp [counter1];
    }
    
    delete [] arrayLineageFluorescentDataTypeTemp;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToLineageSelectController object:nil];
}

@end
