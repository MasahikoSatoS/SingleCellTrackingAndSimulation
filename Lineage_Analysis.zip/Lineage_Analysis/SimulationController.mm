//
//  SimulationController.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2020-10-29.
//

#import "SimulationController.h"

NSString *notificationToSimulationController = @"notificationExecuteSimController";

@implementation SimulationController

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToSimulationController object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    mainWindowSimController = [[NSWindowController alloc] initWithWindowNibName:@"Simulation"];
    [mainWindowSimController showWindow:nil];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSimulationDisplay object:nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSimulationTable object:nil];
}

-(void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [mainWindowSimWindow frame];
    CGFloat windowHeight = windowSize.size.height;
    
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [mainWindowSimWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    [formulaA1Display setDelegate:self];
    [formulaA2Display setDelegate:self];
    [formulaA3Display setDelegate:self];
    [formulaA4Display setDelegate:self];
    [formulaB1Display setDelegate:self];
    [formulaB2Display setDelegate:self];
    [formulaB3Display setDelegate:self];
    [formulaB4Display setDelegate:self];
    [cycleFitDisplay setDelegate:self];
    [fitRangeBEndDisplay setDelegate:self];
    [fitTimeStartDisplay setDelegate:self];
    [fitModeDisplay setDelegate:self];
    
    [growthTimeBDDisplay setDelegate:self];
    [growthTimeTDDisplay setDelegate:self];
    [growthTimeCFDisplay setDelegate:self];
    [growthBDDisplay setDelegate:self];
    [growthTDDisplay setDelegate:self];
    [growthBDCDDisplay setDelegate:self];
    [growthNOCDDisplay setDelegate:self];
    [growthBDCFDisplay setDelegate:self];
    [growthBDCFBDDisplay setDelegate:self];
    [growthBDCFTDDisplay setDelegate:self];
    [growthBDCFCDDisplay setDelegate:self];
    [growthTDCFDisplay setDelegate:self];
    [growthTDCFBDDisplay setDelegate:self];
    [growthTDCFTDDisplay setDelegate:self];
    [growthTDCFCDDisplay setDelegate:self];
    [growthTDBDDisplay setDelegate:self];
    [growthTDTDDisplay setDelegate:self];
    [growthTDCDDisplay setDelegate:self];
    [growthMulTDTDDisplay setDelegate:self];
    [growthSupTDBDDisplay setDelegate:self];
    [growthNoDivDisplay setDelegate:self];
    [growthRecoveryDisplay setDelegate:self];
    
    [growthPrgTimeBDDisplay setDelegate:self];
    [growthPrgTimeTDDisplay setDelegate:self];
    [growthPrgTimeCFDisplay setDelegate:self];
    [growthPrgBDDisplay setDelegate:self];
    [growthPrgTDDisplay setDelegate:self];
    [growthPrgBDCDDisplay setDelegate:self];
    [growthPrgNOCDDisplay setDelegate:self];
    [growthPrgBDCFDisplay setDelegate:self];
    [growthPrgBDCFBDDisplay setDelegate:self];
    [growthPrgBDCFTDDisplay setDelegate:self];
    [growthPrgBDCFCDDisplay setDelegate:self];
    [growthPrgTDCFDisplay setDelegate:self];
    [growthPrgTDCFBDDisplay setDelegate:self];
    [growthPrgTDCFTDDisplay setDelegate:self];
    [growthPrgTDCFCDDisplay setDelegate:self];
    [growthPrgTDBDDisplay setDelegate:self];
    [growthPrgTDTDDisplay setDelegate:self];
    [growthPrgTDCDDisplay setDelegate:self];
    [growthPrgMulTDTDDisplay setDelegate:self];
    [growthPrgSupTDBDDisplay setDelegate:self];
    [growthPrgNoDivDisplay setDelegate:self];
    [growthPrgRecoveryDisplay setDelegate:self];
    
    [growthMidTimeBDDisplay setDelegate:self];
    [growthMidTimeTDDisplay setDelegate:self];
    [growthMidTimeCFDisplay setDelegate:self];
    [growthMidBDDisplay setDelegate:self];
    [growthMidTDDisplay setDelegate:self];
    [growthMidBDCDDisplay setDelegate:self];
    [growthMidNOCDDisplay setDelegate:self];
    [growthMidBDCFDisplay setDelegate:self];
    [growthMidBDCFBDDisplay setDelegate:self];
    [growthMidBDCFTDDisplay setDelegate:self];
    [growthMidBDCFCDDisplay setDelegate:self];
    [growthMidTDCFDisplay setDelegate:self];
    [growthMidTDCFBDDisplay setDelegate:self];
    [growthMidTDCFTDDisplay setDelegate:self];
    [growthMidTDCFCDDisplay setDelegate:self];
    [growthMidTDBDDisplay setDelegate:self];
    [growthMidTDTDDisplay setDelegate:self];
    [growthMidTDCDDisplay setDelegate:self];
    [growthMidMulTDTDDisplay setDelegate:self];
    [growthMidSupTDBDDisplay setDelegate:self];
    [growthMidNoDivDisplay setDelegate:self];
    [growthMidRecoveryDisplay setDelegate:self];
    
    [growthAddTimeBDDisplay setDelegate:self];
    [growthAddTimeTDDisplay setDelegate:self];
    [growthAddTimeCFDisplay setDelegate:self];
    [growthAddBDDisplay setDelegate:self];
    [growthAddTDDisplay setDelegate:self];
    [growthAddBDCDDisplay setDelegate:self];
    [growthAddNOCDDisplay setDelegate:self];
    [growthAddBDCFDisplay setDelegate:self];
    [growthAddBDCFBDDisplay setDelegate:self];
    [growthAddBDCFTDDisplay setDelegate:self];
    [growthAddBDCFCDDisplay setDelegate:self];
    [growthAddTDCFDisplay setDelegate:self];
    [growthAddTDCFBDDisplay setDelegate:self];
    [growthAddTDCFTDDisplay setDelegate:self];
    [growthAddTDCFCDDisplay setDelegate:self];
    [growthAddTDBDDisplay setDelegate:self];
    [growthAddTDTDDisplay setDelegate:self];
    [growthAddTDCDDisplay setDelegate:self];
    [growthAddMulTDTDDisplay setDelegate:self];
    [growthAddSupTDBDDisplay setDelegate:self];
    [growthAddNoDivDisplay setDelegate:self];
    [growthAddRecoveryDisplay setDelegate:self];
    
    [growthCycleDisplay setDelegate:self];
    [growthTimeStartDisplay setDelegate:self];
    [growthInitNoDisplay setDelegate:self];
    [growthTimeEndDisplay setDelegate:self];
    [growthMidTimeStartDisplay setDelegate:self];
    
    [movieDistanceDisplay setDelegate:self];
    [movieDistanceDisplay2 setDelegate:self];
    [movieDistanceDisplay3 setDelegate:self];
    [movieDistanceTimeDisplay2 setDelegate:self];
    [movieDistanceTimeDisplay3 setDelegate:self];
    [circleSizeDisplay setDelegate:self];
    [circleSizeMinDisplay setDelegate:self];
    [videoImageSizeDisplay setDelegate:self];
    
    [doseBaseDisplay setDelegate:self];
    [doseMiddleDisplay setDelegate:self];
    [doseTargetDisplay setDelegate:self];
    [endVariationDisplay setDelegate:self];
    [selectLingNoDisplay setDelegate:self];
    [colorToneDisplay setDelegate:self];
    
    [fluorescentBiasDisplay setDelegate:self];
    [fluorescentDropDisplay setDelegate:self];
    
    if (simulationOperation != 0){
        [[colorButton cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [9] green:arrayColorRange2 [10] blue:arrayColorRange2 [11] alpha:1]];
        
        colorNoSimHold = 3;
        
        [[colorButtonVideo1 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [9] green:arrayColorRange2 [10] blue:arrayColorRange2 [11] alpha:1]];
        [[colorButtonVideo2 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [9] green:arrayColorRange2 [10] blue:arrayColorRange2 [11] alpha:1]];
        [[colorButtonVideo3 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [9] green:arrayColorRange2 [10] blue:arrayColorRange2 [11] alpha:1]];
        [[colorButtonVideo4 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [9] green:arrayColorRange2 [10] blue:arrayColorRange2 [11] alpha:1]];
        [[colorButtonVideo5 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [9] green:arrayColorRange2 [10] blue:arrayColorRange2 [11] alpha:1]];
        [[colorButtonVideo6 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [9] green:arrayColorRange2 [10] blue:arrayColorRange2 [11] alpha:1]];
        [[colorButtonVideo7 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [9] green:arrayColorRange2 [10] blue:arrayColorRange2 [11] alpha:1]];
        [[colorButtonVideo8 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [9] green:arrayColorRange2 [10] blue:arrayColorRange2 [11] alpha:1]];
        [[colorButtonVideo9 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [9] green:arrayColorRange2 [10] blue:arrayColorRange2 [11] alpha:1]];
        [[colorButtonVideo10 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [9] green:arrayColorRange2 [10] blue:arrayColorRange2 [11] alpha:1]];
        [[colorButtonVideo11 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [9] green:arrayColorRange2 [10] blue:arrayColorRange2 [11] alpha:1]];
        
        [[colorButtonGraph1 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [9] green:arrayColorRange2 [10] blue:arrayColorRange2 [11] alpha:1]];
        [[colorButtonGraph2 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [9] green:arrayColorRange2 [10] blue:arrayColorRange2 [11] alpha:1]];
        [[colorButtonGraph3 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [9] green:arrayColorRange2 [10] blue:arrayColorRange2 [11] alpha:1]];
        [[colorButtonGraph4 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [9] green:arrayColorRange2 [10] blue:arrayColorRange2 [11] alpha:1]];
        [[colorButtonGraph5 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [9] green:arrayColorRange2 [10] blue:arrayColorRange2 [11] alpha:1]];
        [[colorButtonGraph6 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [9] green:arrayColorRange2 [10] blue:arrayColorRange2 [11] alpha:1]];
        [[colorButtonGraph7 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [9] green:arrayColorRange2 [10] blue:arrayColorRange2 [11] alpha:1]];
        [[colorButtonGraph8 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [9] green:arrayColorRange2 [10] blue:arrayColorRange2 [11] alpha:1]];
        [[colorButtonGraph9 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [9] green:arrayColorRange2 [10] blue:arrayColorRange2 [11] alpha:1]];
        [[colorButtonGraph10 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [9] green:arrayColorRange2 [10] blue:arrayColorRange2 [11] alpha:1]];
        [[colorButtonGraph11 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [9] green:arrayColorRange2 [10] blue:arrayColorRange2 [11] alpha:1]];
    }
    
    [movieDistanceDisplay setStringValue:@"1"];
    [circleSizeDisplay setStringValue:@"20"];
    [circleSizeMinDisplay setStringValue:@"20"];
    [movieDistanceDisplay2 setStringValue:@"0"];
    [movieDistanceDisplay3 setStringValue:@"0"];
    [movieDistanceTimeDisplay2 setStringValue:@"0"];
    [movieDistanceTimeDisplay3 setStringValue:@"0"];
    [endVariationDisplay setStringValue:@"30"];
    
    simControllerTimer2 = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(displayData) userInfo:nil repeats:YES];
}

-(void)displayData{
    if (backSaveOn == 1){
        [backSave startAnimation:self];
        
        if (backSave){
            backSaveOn = 2;
        }
    }
    else if (backSaveOn == 3){
        [backSave stopAnimation:self];
        
        if (backSave){
            [terminateDisplay setTextColor:[NSColor blackColor]];
            [terminateDisplay setStringValue:@"Terminate"];
            terminateSimFlag = 0;
            backSaveOn = 0;
        }
    }
    
    if (backSaveOn2 == 1){
        [backSave2 startAnimation:self];
        
        if (backSave2){
            backSaveOn2 = 2;
        }
    }
    else if (backSaveOn2 == 3){
        [backSave2 stopAnimation:self];
        
        if (backSave2){
            backSaveOn2 = 0;
        }
    }
    
    if (processingStatusCall == 1){
        NSString *message = @(processingStatus.c_str());
        
        [processStatusDisplay setStringValue:message];
        
        NSString *message2 = [processStatusDisplay stringValue];
        
        if (message2 != nil){
            string messageString2 = [message2 UTF8String];
            
            if (processingStatus == messageString2) processingStatusCall = 0;
        }
    }
    
    if (processingStatusCall2 == 1){
        NSString *message = @(processingStatus2.c_str());
        
        [processStatusDisplay2 setStringValue:message];
        
        NSString *message2 = [processStatusDisplay2 stringValue];
        
        if (message2 != nil){
            string messageString2 = [message2 UTF8String];
            
            if (processingStatus2 == messageString2) processingStatusCall2 = 0;
        }
    }
    
    if (processingStatusCall3 == 1){
        NSString *message = @(processingStatus3.c_str());
        
        [processStatusDisplay3 setStringValue:message];
        
        NSString *message2 = [processStatusDisplay3 stringValue];
        
        if (message2 != nil){
            string messageString2 = [message2 UTF8String];
            
            if (processingStatus3 == messageString2) processingStatusCall3 = 0;
        }
    }
    
    if (processingStatusCall4 == 1){
        NSString *message = @(processingStatus4.c_str());
        
        [processStatusDisplay4 setStringValue:message];
        
        NSString *message2 = [processStatusDisplay4 stringValue];
        
        if (message2 != nil){
            string messageString2 = [message2 UTF8String];
            
            if (processingStatus4 == messageString2) processingStatusCall4 = 0;
        }
    }
    
    if (simulationCall == 3){
        simulationCall = 0;
        
        string displayData1 = arraySimListHold [simOperationTableCurrentRow*2];
        string displayData2 = arraySimListHold [simOperationTableCurrentRow*2+1];
        
        [currentNameDisplay setStringValue:@(displayData1.c_str())];
        [currentTreatDisplay setStringValue:@(displayData2.c_str())];
    }
    
    if (lingSetDisplayCall == 1){
        NSString *message = @(messageLingSim.c_str());
        NSString *message2 = @(messageLingSim2.c_str());
        NSString *message3 = @(messageLingSim3.c_str());
        NSString *message4 = @(messageLingSim4.c_str());
        NSString *message5 = @(messageLingSim5.c_str());
        NSString *message6 = @(messageLingSim6.c_str());
        NSString *message7 = @(messageLingSim7.c_str());
        NSString *message8 = @(messageLingSim8.c_str());
        
        [lingNoDisplay setStringValue:message];
        [lingNoDisplay2 setStringValue:message2];
        [lingNoDisplay3 setStringValue:message3];
        [lingNoDisplay4 setStringValue:message4];
        [lingNoDisplay5 setStringValue:message5];
        [lingNoDisplay6 setStringValue:message6];
        [lingNoDisplay7 setStringValue:message7];
        [lingNoDisplay8 setStringValue:message8];
        
        NSString *message2A = [lingNoDisplay stringValue];
        
        if (message2A != nil){
            string messageString2 = [message2A UTF8String];
            
            if (messageLingSim == messageString2) lingSetDisplayCall = 0;
        }
    }
}

-(IBAction)terminateSim:(id)sender{
    if (backSaveOn != 0 && terminateSimFlag == 0){
        terminateSimFlag = 1;
        
        [terminateDisplay setTextColor:[NSColor redColor]];
        [terminateDisplay setStringValue:@"Terminate"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        [terminateDisplay setTextColor:[NSColor blackColor]];
        [terminateDisplay setStringValue:@"Terminate"];
        terminateSimFlag = 0;
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Sim Not Running"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)controlTextDidChange:(NSNotification *)aNotification{
    if ([[aNotification name] isEqualToString:@"NSControlTextDidChangeNotification"]){
        
        //----Fit lines----
        if ([aNotification object] == formulaA1Display){
            if ([formulaA1Display doubleValue] >= 0 && [formulaA1Display doubleValue] <= 10000){
                fitA1Hold = [formulaA1Display doubleValue];
            }
            else{
                
                fitA1Hold = 0;
                [formulaA1Display setIntegerValue:0];
            }
        }
        
        if ([aNotification object] == formulaA2Display){
            if ([formulaA2Display doubleValue] >= 0 && [formulaA2Display doubleValue] <= 10000){
                fitA2Hold = [formulaA2Display doubleValue];
            }
            else{
                
                fitA2Hold = 0;
                [formulaA2Display setIntegerValue:0];
            }
        }
        
        if ([aNotification object] == formulaA3Display){
            if ([formulaA3Display doubleValue] >= 0 && [formulaA3Display doubleValue] <= 10000){
                fitA3Hold = [formulaA3Display doubleValue];
            }
            else{
                
                fitA3Hold = 0;
                [formulaA3Display setIntegerValue:0];
            }
        }
        
        if ([aNotification object] == formulaA4Display){
            if ([formulaA4Display doubleValue] >= 0 && [formulaA4Display doubleValue] <= 10000){
                fitA4Hold = [formulaA4Display doubleValue];
            }
            else{
                
                fitA4Hold = 0;
                [formulaA3Display setIntegerValue:0];
            }
        }
        
        if ([aNotification object] == formulaB1Display){
            if ([formulaB1Display doubleValue] >= 0 && [formulaB1Display doubleValue] <= 43){
                fitB1Hold = [formulaB1Display doubleValue];
            }
            else{
                
                fitB1Hold = 0;
                [formulaB1Display setIntegerValue:0];
            }
        }
        
        if ([aNotification object] == formulaB2Display){
            if ([formulaB2Display doubleValue] >= 0 && [formulaB2Display doubleValue] <= 43){
                fitB2Hold = [formulaB2Display doubleValue];
            }
            else{
                
                fitB2Hold = 0;
                [formulaB2Display setIntegerValue:0];
            }
        }
        
        if ([aNotification object] == formulaB3Display){
            if ([formulaB3Display doubleValue] >= 0 && [formulaB3Display doubleValue] <= 43){
                fitB3Hold = [formulaB3Display doubleValue];
            }
            else{
                
                fitB3Hold = 0;
                [formulaB3Display setIntegerValue:0];
            }
        }
        
        if ([aNotification object] == formulaB4Display){
            if ([formulaB4Display doubleValue] >= 0 && [formulaB4Display doubleValue] <= 43){
                fitB4Hold = [formulaB4Display doubleValue];
            }
            else{
                
                fitB4Hold = 0;
                [formulaB4Display setIntegerValue:0];
            }
        }
        
        if ([aNotification object] == cycleFitDisplay){
            fitCycleHold = [cycleFitDisplay intValue];
            
            if (fitCycleHold < 0 || fitCycleHold > 100000){
                fitCycleHold = 0;
                [fitTimeStartDisplay setIntegerValue:0];
            }
        }
        
        if ([aNotification object] == fitRangeBEndDisplay){
            if ([fitRangeBEndDisplay doubleValue] >= 0 && [fitRangeBEndDisplay doubleValue] <= 43){
                fitRangeBEndHold = [fitRangeBEndDisplay doubleValue];
            }
            else{
                
                fitRangeBEndHold = 0;
                [fitRangeBEndDisplay doubleValue];
            }
        }
        
        if ([aNotification object] == fitTimeStartDisplay){
            fitTimeStartHold = [fitTimeStartDisplay intValue];
            
            if (fitTimeStartHold < 0){
                fitTimeStartHold = 0;
                [fitTimeStartDisplay setIntegerValue:0];
            }
        }
        
        if (simulationProgress == 0){
            //----Growth----
            if ([aNotification object] == growthTimeBDDisplay){
                simProcessDataBaseHold [0] = [growthTimeBDDisplay doubleValue];
                
                if (simProcessDataBaseHold [0] < 0 || simProcessDataBaseHold [0] > 500){
                    simProcessDataBaseHold [0] = 1;
                    [growthTimeBDDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthTimeTDDisplay){
                simProcessDataBaseHold [1] = [growthTimeTDDisplay doubleValue];
                
                if (simProcessDataBaseHold [1] < 0 || simProcessDataBaseHold [1] > 10){
                    simProcessDataBaseHold [1] = 1;
                    [growthTimeTDDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthTimeCFDisplay){
                simProcessDataBaseHold [2] = [growthTimeCFDisplay doubleValue];
                
                if (simProcessDataBaseHold [2] < 0 || simProcessDataBaseHold [2] > 10){
                    simProcessDataBaseHold [2] = 1;
                    [growthTimeCFDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthBDDisplay){
                simProcessDataBaseHold [3] = [growthBDDisplay doubleValue];
                simProcessDataBaseHold [3] = (simProcessDataBaseHold [3]/(double)100)*simProcessDataBaseHold [23];
                
                if (simProcessDataBaseHold [3] < 0){
                    simProcessDataBaseHold [3] = 0;
                    [growthBDDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthTDDisplay){
                simProcessDataBaseHold [4] = [growthTDDisplay doubleValue];
                simProcessDataBaseHold [4] = (simProcessDataBaseHold [4]/(double)100)*simProcessDataBaseHold [23];
                
                if (simProcessDataBaseHold [4] < 0){
                    simProcessDataBaseHold [4] = 0;
                    [growthTDDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthBDCDDisplay){
                simProcessDataBaseHold [5] = [growthBDCDDisplay doubleValue];
                
                if (simProcessDataBaseHold [5] < 0 || simProcessDataBaseHold [5] > 10){
                    simProcessDataBaseHold [5] = 1;
                    [growthBDCDDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthNOCDDisplay){
                simProcessDataBaseHold [6] = [growthNOCDDisplay doubleValue];
                
                if (simProcessDataBaseHold [6] < 0 || simProcessDataBaseHold [6] > 10){
                    simProcessDataBaseHold [6] = 1;
                    [growthNOCDDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthBDCFDisplay){
                simProcessDataBaseHold [7] = [growthBDCFDisplay doubleValue];
                
                if (simProcessDataBaseHold [7] < 0 || simProcessDataBaseHold [7] > 10){
                    simProcessDataBaseHold [7] = 1;
                    [growthBDCFDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthBDCFBDDisplay){
                simProcessDataBaseHold [8] = [growthBDCFBDDisplay doubleValue];
                simProcessDataBaseHold [8] = (simProcessDataBaseHold [8]/(double)100)*simProcessDataBaseHold [23];
                
                if (simProcessDataBaseHold [8] < 0){
                    simProcessDataBaseHold [8] = 0;
                    [growthBDCFBDDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthBDCFTDDisplay){
                simProcessDataBaseHold [9] = [growthBDCFTDDisplay doubleValue];
                simProcessDataBaseHold [9] = (simProcessDataBaseHold [9]/(double)100)*simProcessDataBaseHold [23];
                
                if (simProcessDataBaseHold [9] < 0){
                    simProcessDataBaseHold [9] = 0;
                    [growthBDCFTDDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthBDCFCDDisplay){
                simProcessDataBaseHold [10] = [growthBDCFCDDisplay doubleValue];
                
                if (simProcessDataBaseHold [10] < 0 || simProcessDataBaseHold [10] > 10){
                    simProcessDataBaseHold [10] = 1;
                    [growthBDCFDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthTDCFDisplay){
                simProcessDataBaseHold [11] = [growthTDCFDisplay doubleValue];
                
                if (simProcessDataBaseHold [11] < 0 || simProcessDataBaseHold [11] > 10){
                    simProcessDataBaseHold [11] = 1;
                    [growthTDCFDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthTDCFBDDisplay){
                simProcessDataBaseHold [12] = [growthTDCFBDDisplay doubleValue];
                simProcessDataBaseHold [12] = (simProcessDataBaseHold [12]/(double)100)*simProcessDataBaseHold [23];
                
                if (simProcessDataBaseHold [12] < 0){
                    simProcessDataBaseHold [12] = 0;
                    [growthTDCFBDDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthTDCFTDDisplay){
                simProcessDataBaseHold [13] = [growthTDCFTDDisplay doubleValue];
                simProcessDataBaseHold [13] = (simProcessDataBaseHold [13]/(double)100)*simProcessDataBaseHold [23];
                
                if (simProcessDataBaseHold [13] < 0){
                    simProcessDataBaseHold [13] = 0;
                    [growthTDCFTDDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthTDCFCDDisplay){
                simProcessDataBaseHold [14] = [growthTDCFCDDisplay doubleValue];
                
                if (simProcessDataBaseHold [14] < 0 || simProcessDataBaseHold [14] > 10){
                    simProcessDataBaseHold [14] = 1;
                    [growthTDCFCDDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthTDBDDisplay){
                simProcessDataBaseHold [15] = [growthTDBDDisplay doubleValue];
                simProcessDataBaseHold [15] = (simProcessDataBaseHold [15]/(double)100)*simProcessDataBaseHold [23];
                
                if (simProcessDataBaseHold [15] < 0){
                    simProcessDataBaseHold [15] = 0;
                    [growthTDBDDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthTDTDDisplay){
                simProcessDataBaseHold [16] = [growthTDTDDisplay doubleValue];
                simProcessDataBaseHold [16] = (simProcessDataBaseHold [16]/(double)100)*simProcessDataBaseHold [23];
                
                if (simProcessDataBaseHold [16] < 0){
                    simProcessDataBaseHold [16] = 0;
                    [growthTDTDDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthTDCDDisplay){
                simProcessDataBaseHold [17] = [growthTDCDDisplay doubleValue];
                
                if (simProcessDataBaseHold [17] < 0 || simProcessDataBaseHold [17] > 10){
                    simProcessDataBaseHold [17] = 1;
                    [growthTDCDDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthMulTDTDDisplay){
                simProcessDataBaseHold [18] = [growthMulTDTDDisplay doubleValue];
                
                if (simProcessDataBaseHold [18] < 2 || simProcessDataBaseHold [18] > 3){
                    simProcessDataBaseHold [18] = 2;
                    [growthTDCDDisplay setIntegerValue:2];
                }
            }
            
            if ([aNotification object] == growthSupTDBDDisplay){
                simProcessDataBaseHold [19] = [growthSupTDBDDisplay doubleValue];
                
                if (simProcessDataBaseHold [19] < 1 || simProcessDataBaseHold [19] > 3){
                    simProcessDataBaseHold [19] = 1;
                    [growthSupTDBDDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthNoDivDisplay){
                simProcessDataBaseHold [20] = [growthNoDivDisplay doubleValue];
                simProcessDataBaseHold [20] = (simProcessDataBaseHold [20]/(double)100)*simProcessDataBaseHold [24];
                
                if (simProcessDataBaseHold [20] < 0){
                    simProcessDataBaseHold [20] = 0;
                    [growthNoDivDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthRecoveryDisplay){
                simProcessDataBaseHold [21] = [growthRecoveryDisplay doubleValue];
                simProcessDataBaseHold [21] = (simProcessDataBaseHold [21]/(double)100)*simProcessDataBaseHold [24];
                
                if (simProcessDataBaseHold [21] < 0){
                    simProcessDataBaseHold [21] = 0;
                    [growthRecoveryDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == fluorescentBiasDisplay){
                simProcessDataBaseHold [28] = [fluorescentBiasDisplay doubleValue];
                
                if (simProcessDataBaseHold [28] < 0 || simProcessDataBaseHold [28] > 10){
                    simProcessDataBaseHold [28] = 1;
                    [fluorescentBiasDisplay setIntegerValue:1];
                }
            }
            
            //----Growth Progressive----
            if ([aNotification object] == growthPrgTimeBDDisplay){
                simProcessDataProgHold [0] = [growthPrgTimeBDDisplay doubleValue];
                
                if (simProcessDataProgHold [0] < 0 || simProcessDataProgHold [0] > 10){
                    simProcessDataProgHold [0] = 1;
                    [growthPrgTimeBDDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthPrgTimeTDDisplay){
                simProcessDataProgHold [1] = [growthPrgTimeTDDisplay doubleValue];
                
                if (simProcessDataProgHold [1] < 0 || simProcessDataProgHold [1] > 10){
                    simProcessDataProgHold [1] = 1;
                    [growthPrgTimeTDDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthPrgTimeCFDisplay){
                simProcessDataProgHold [2] = [growthPrgTimeCFDisplay doubleValue];
                
                if (simProcessDataProgHold [2] < 0 || simProcessDataProgHold [2] > 10){
                    simProcessDataProgHold [2] = 1;
                    [growthPrgTimeCFDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthPrgBDDisplay){
                simProcessDataProgHold [3] = [growthPrgBDDisplay doubleValue];
                simProcessDataProgHold [3] = (simProcessDataProgHold [3]/(double)100)*simProcessDataProgHold [23];
                
                if (simProcessDataProgHold [3] < 0){
                    simProcessDataProgHold [3] = 0;
                    [growthPrgBDDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthPrgTDDisplay){
                simProcessDataProgHold [4] = [growthPrgTDDisplay doubleValue];
                simProcessDataProgHold [4] = (simProcessDataProgHold [4]/(double)100)*simProcessDataProgHold [23];
                
                if (simProcessDataProgHold [4] < 0){
                    simProcessDataProgHold [4] = 0;
                    [growthPrgTDDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthPrgBDCDDisplay){
                simProcessDataProgHold [5] = [growthPrgBDCDDisplay doubleValue];
                
                if (simProcessDataProgHold [5] < 0 || simProcessDataProgHold [5] > 10){
                    simProcessDataProgHold [5] = 1;
                    [growthPrgBDCDDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthPrgNOCDDisplay){
                simProcessDataProgHold [6] = [growthPrgNOCDDisplay doubleValue];
                
                if (simProcessDataProgHold [6] < 0 || simProcessDataProgHold [6] > 10){
                    simProcessDataProgHold [6] = 1;
                    [growthPrgNOCDDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthPrgBDCFDisplay){
                simProcessDataProgHold [7] = [growthPrgBDCFDisplay doubleValue];
                
                if (simProcessDataProgHold [7] < 0 || simProcessDataProgHold [7] > 10){
                    simProcessDataProgHold [7] = 1;
                    [growthPrgBDCFDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthPrgBDCFBDDisplay){
                simProcessDataProgHold [8] = [growthPrgBDCFBDDisplay doubleValue];
                simProcessDataProgHold [8] = (simProcessDataProgHold [8]/(double)100)*simProcessDataProgHold [23];
                
                if (simProcessDataProgHold [8] < 0){
                    simProcessDataProgHold [8] = 0;
                    [growthPrgBDCFBDDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthPrgBDCFTDDisplay){
                simProcessDataProgHold [9] = [growthPrgBDCFTDDisplay doubleValue];
                simProcessDataProgHold [9] = (simProcessDataProgHold [9]/(double)100)*simProcessDataProgHold [23];
                
                if (simProcessDataProgHold [9] < 0){
                    simProcessDataProgHold [9] = 0;
                    [growthPrgBDCFTDDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthPrgBDCFCDDisplay){
                simProcessDataProgHold [10] = [growthPrgBDCFCDDisplay doubleValue];
                
                if (simProcessDataProgHold [10] < 0 || simProcessDataProgHold [10] > 10){
                    simProcessDataProgHold [10] = 1;
                    [growthPrgBDCFDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthPrgTDCFDisplay){
                simProcessDataProgHold [11] = [growthPrgTDCFDisplay doubleValue];
                
                if (simProcessDataProgHold [11] < 0 || simProcessDataProgHold [11] > 10){
                    simProcessDataProgHold [11] = 1;
                    [growthPrgTDCFDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthPrgTDCFBDDisplay){
                simProcessDataProgHold [12] = [growthPrgTDCFBDDisplay doubleValue];
                simProcessDataProgHold [12] = (simProcessDataProgHold [12]/(double)100)*simProcessDataProgHold [23];
                
                if (simProcessDataProgHold [12] < 0){
                    simProcessDataProgHold [12] = 0;
                    [growthPrgTDCFBDDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthPrgTDCFTDDisplay){
                simProcessDataProgHold [13] = [growthPrgTDCFTDDisplay doubleValue];
                simProcessDataProgHold [13] = (simProcessDataProgHold [13]/(double)100)*simProcessDataProgHold [23];
                
                if (simProcessDataProgHold [13] < 0){
                    simProcessDataProgHold [13] = 0;
                    [growthPrgTDCFTDDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthPrgTDCFCDDisplay){
                simProcessDataProgHold [14] = [growthPrgTDCFCDDisplay doubleValue];
                
                if (simProcessDataProgHold [14] < 0 || simProcessDataProgHold [14] > 10){
                    simProcessDataProgHold [14] = 1;
                    [growthPrgTDCFCDDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthPrgTDBDDisplay){
                simProcessDataProgHold [15] = [growthPrgTDBDDisplay doubleValue];
                simProcessDataProgHold [15] = (simProcessDataProgHold [15]/(double)100)*simProcessDataProgHold [23];
                
                if (simProcessDataProgHold [15] < 0){
                    simProcessDataProgHold [15] = 0;
                    [growthPrgTDBDDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthPrgTDTDDisplay){
                simProcessDataProgHold [16] = [growthPrgTDTDDisplay doubleValue];
                simProcessDataProgHold [16] = (simProcessDataProgHold [16]/(double)100)*simProcessDataProgHold [23];
                
                if (simProcessDataProgHold [16] < 0){
                    simProcessDataProgHold [16] = 0;
                    [growthPrgTDTDDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthPrgTDCDDisplay){
                simProcessDataProgHold [17] = [growthPrgTDCDDisplay doubleValue];
                
                if (simProcessDataProgHold [17] < 0 || simProcessDataProgHold [17] > 10){
                    simProcessDataProgHold [17] = 1;
                    [growthPrgTDCDDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthPrgMulTDTDDisplay){
                simProcessDataProgHold [18] = [growthPrgMulTDTDDisplay doubleValue];
                
                if (simProcessDataProgHold [18] < 2 || simProcessDataProgHold [18] > 3){
                    simProcessDataProgHold [18] = 2;
                    [growthPrgTDCDDisplay setIntegerValue:2];
                }
            }
            
            if ([aNotification object] == growthPrgSupTDBDDisplay){
                simProcessDataProgHold [19] = [growthPrgSupTDBDDisplay doubleValue];
                
                if (simProcessDataProgHold [19] < 1 || simProcessDataProgHold [19] > 3){
                    simProcessDataProgHold [19] = 1;
                    [growthPrgSupTDBDDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthPrgNoDivDisplay){
                simProcessDataProgHold [20] = [growthPrgNoDivDisplay doubleValue];
                simProcessDataProgHold [20] = (simProcessDataProgHold [20]/(double)100)*simProcessDataProgHold [24];
                
                if (simProcessDataProgHold [20] < 0){
                    simProcessDataProgHold [20] = 0;
                    [growthPrgNoDivDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthPrgRecoveryDisplay){
                simProcessDataProgHold [21] = [growthPrgRecoveryDisplay doubleValue];
                simProcessDataProgHold [21] = (simProcessDataProgHold [21]/(double)100)*simProcessDataProgHold [24];
                
                if (simProcessDataProgHold [21] < 0){
                    simProcessDataProgHold [21] = 0;
                    [growthPrgRecoveryDisplay setIntegerValue:0];
                }
            }
            
            //----Growth Mid----
            if ([aNotification object] == growthMidTimeBDDisplay){
                simProcessDataMiddleHold  [0] = [growthMidTimeBDDisplay doubleValue];
                
                if (simProcessDataMiddleHold [0] < 0 || simProcessDataMiddleHold [0] > 10){
                    simProcessDataMiddleHold [0] = 1;
                    [growthMidTimeBDDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthMidTimeTDDisplay){
                simProcessDataMiddleHold [1] = [growthMidTimeTDDisplay doubleValue];
                
                if (simProcessDataMiddleHold [1] < 0 || simProcessDataMiddleHold [1] > 10){
                    simProcessDataMiddleHold [1] = 1;
                    [growthMidTimeTDDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthMidTimeCFDisplay){
                simProcessDataMiddleHold [2] = [growthMidTimeCFDisplay doubleValue];
                
                if (simProcessDataMiddleHold [2] < 0 || simProcessDataMiddleHold [2] > 10){
                    simProcessDataMiddleHold [2] = 1;
                    [growthMidTimeCFDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthMidBDDisplay){
                simProcessDataMiddleHold [3] = [growthMidBDDisplay doubleValue];
                simProcessDataMiddleHold [3] = (simProcessDataMiddleHold [3]/(double)100)*simProcessDataMiddleHold [23];
                
                if (simProcessDataMiddleHold [3] < 0){
                    simProcessDataMiddleHold [3] = 0;
                    [growthMidBDDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthMidTDDisplay){
                simProcessDataMiddleHold [4] = [growthMidTDDisplay doubleValue];
                simProcessDataMiddleHold [4] = (simProcessDataMiddleHold [4]/(double)100)*simProcessDataMiddleHold [23];
                
                if (simProcessDataMiddleHold [4] < 0){
                    simProcessDataMiddleHold [4] = 0;
                    [growthMidTDDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthMidBDCDDisplay){
                simProcessDataMiddleHold [5] = [growthMidBDCDDisplay doubleValue];
                
                if (simProcessDataMiddleHold [5] < 0 || simProcessDataMiddleHold [5] > 10){
                    simProcessDataMiddleHold [5] = 1;
                    [growthMidBDCDDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthMidNOCDDisplay){
                simProcessDataMiddleHold [6] = [growthMidNOCDDisplay doubleValue];
                
                if (simProcessDataMiddleHold [6] < 0 || simProcessDataMiddleHold [6] > 10){
                    simProcessDataMiddleHold [6] = 1;
                    [growthMidNOCDDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthMidBDCFDisplay){
                simProcessDataMiddleHold [7] = [growthMidBDCFDisplay doubleValue];
                
                if (simProcessDataMiddleHold [7] < 0 || simProcessDataMiddleHold [7] > 10){
                    simProcessDataMiddleHold [7] = 1;
                    [growthMidBDCFDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthMidBDCFBDDisplay){
                simProcessDataMiddleHold [8] = [growthMidBDCFBDDisplay doubleValue];
                simProcessDataMiddleHold [8] = (simProcessDataMiddleHold [8]/(double)100)*simProcessDataMiddleHold [23];
                
                if (simProcessDataMiddleHold [8] < 0){
                    simProcessDataMiddleHold [8] = 0;
                    [growthMidBDCFBDDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthMidBDCFTDDisplay){
                simProcessDataMiddleHold [9] = [growthMidBDCFTDDisplay doubleValue];
                simProcessDataMiddleHold [9] = (simProcessDataMiddleHold [9]/(double)100)*simProcessDataMiddleHold [23];
                
                if (simProcessDataMiddleHold [9] < 0){
                    simProcessDataMiddleHold [9] = 0;
                    [growthMidBDCFTDDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthMidBDCFCDDisplay){
                simProcessDataMiddleHold [10] = [growthMidBDCFCDDisplay doubleValue];
                
                if (simProcessDataMiddleHold [10] < 0 || simProcessDataMiddleHold [10] > 10){
                    simProcessDataMiddleHold [10] = 1;
                    [growthMidBDCFDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthMidTDCFDisplay){
                simProcessDataMiddleHold [11] = [growthMidTDCFDisplay doubleValue];
                
                if (simProcessDataMiddleHold [11] < 0 || simProcessDataMiddleHold [11] > 10){
                    simProcessDataMiddleHold [11] = 1;
                    [growthMidTDCFDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthMidTDCFBDDisplay){
                simProcessDataMiddleHold [12] = [growthMidTDCFBDDisplay doubleValue];
                simProcessDataMiddleHold [12] = (simProcessDataMiddleHold [12]/(double)100)*simProcessDataMiddleHold [23];
                
                if (simProcessDataMiddleHold [12] < 0){
                    simProcessDataMiddleHold [12] = 0;
                    [growthMidTDCFBDDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthMidTDCFTDDisplay){
                simProcessDataMiddleHold [13] = [growthMidTDCFTDDisplay doubleValue];
                
                if (simProcessDataMiddleHold [13] > 100){
                    simProcessDataMiddleHold [13] = 100;
                    [growthMidTDCFTDDisplay setIntegerValue:100];
                }
                else if (simProcessDataMiddleHold [13] < 0){
                    simProcessDataMiddleHold [13] = 0;
                    [growthMidTDCFTDDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthMidTDCFCDDisplay){
                simProcessDataMiddleHold [14] = [growthMidTDCFCDDisplay doubleValue];
                
                if (simProcessDataMiddleHold [14] < 0 || simProcessDataMiddleHold [14] > 10){
                    simProcessDataMiddleHold [14] = 1;
                    [growthMidTDCFCDDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthMidTDBDDisplay){
                simProcessDataMiddleHold [15] = [growthMidTDBDDisplay doubleValue];
                simProcessDataMiddleHold [15] = (simProcessDataMiddleHold [15]/(double)100)*simProcessDataMiddleHold [23];
                
                if (simProcessDataMiddleHold [15] < 0){
                    simProcessDataMiddleHold [15] = 0;
                    [growthMidTDBDDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthMidTDTDDisplay){
                simProcessDataMiddleHold [16] = [growthMidTDTDDisplay doubleValue];
                simProcessDataMiddleHold [16] = (simProcessDataMiddleHold [16]/(double)100)*simProcessDataMiddleHold [23];
                
                if (simProcessDataMiddleHold [16] < 0){
                    simProcessDataMiddleHold [16] = 0;
                    [growthMidTDTDDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthMidTDCDDisplay){
                simProcessDataMiddleHold [17] = [growthMidTDCDDisplay doubleValue];
                
                if (simProcessDataMiddleHold [17] < 0 || simProcessDataMiddleHold [17] > 10){
                    simProcessDataMiddleHold [17] = 1;
                    [growthMidTDCDDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthMidMulTDTDDisplay){
                simProcessDataMiddleHold [18] = [growthMidMulTDTDDisplay doubleValue];
                
                if (simProcessDataMiddleHold [18] < 2 || simProcessDataMiddleHold [18] > 3){
                    simProcessDataMiddleHold [18] = 2;
                    [growthMidTDCDDisplay setIntegerValue:2];
                }
            }
            
            if ([aNotification object] == growthMidSupTDBDDisplay){
                simProcessDataMiddleHold [19] = [growthMidSupTDBDDisplay doubleValue];
                
                if (simProcessDataMiddleHold [19] < 1 || simProcessDataMiddleHold [19] > 3){
                    simProcessDataMiddleHold [19] = 1;
                    [growthMidSupTDBDDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthMidNoDivDisplay){
                simProcessDataMiddleHold [20] = [growthMidNoDivDisplay doubleValue];
                simProcessDataMiddleHold [20] = (simProcessDataMiddleHold [20]/(double)100)*simProcessDataMiddleHold [24];
                
                if (simProcessDataMiddleHold [20] < 0){
                    simProcessDataMiddleHold [20] = 0;
                    [growthMidNoDivDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthMidRecoveryDisplay){
                simProcessDataMiddleHold [21] = [growthMidRecoveryDisplay doubleValue];
                simProcessDataMiddleHold [21] = (simProcessDataMiddleHold [21]/(double)100)*simProcessDataMiddleHold [24];
                
                if (simProcessDataMiddleHold [21] < 0){
                    simProcessDataMiddleHold [21] = 0;
                    [growthMidRecoveryDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthCycleDisplay){
                growthCycleHold = [growthCycleDisplay intValue];
                
                if (growthCycleHold < 0 || growthCycleHold > 100000){
                    growthCycleHold = 0;
                    [growthCycleDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthInitNoDisplay){
                growthInitHold = [growthInitNoDisplay intValue];
                
                if (growthInitHold  < 0 || growthInitHold > 100000){
                    growthInitHold = 0;
                    [growthInitNoDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthTimeStartDisplay){
                growthProgTimeStartHold = [growthTimeStartDisplay intValue];
                
                if (growthProgTimeStartHold < 0){
                    growthProgTimeStartHold = 0;
                    [growthTimeStartDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthTimeEndDisplay){
                growthProgTimeEndHold = [growthTimeEndDisplay intValue];
                
                if (growthProgTimeEndHold < 0){
                    growthProgTimeEndHold = 0;
                    [growthTimeEndDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthMidTimeStartDisplay){
                growthMidTimeStartHold = [growthMidTimeStartDisplay intValue];
                
                if (growthMidTimeStartHold < 0){
                    growthMidTimeStartHold = 0;
                    [growthMidTimeStartDisplay setIntegerValue:0];
                }
            }
            
            //----Growth Add----
            if ([aNotification object] == growthAddTimeBDDisplay){
                simProcessDataAddHold [0] = [growthAddTimeBDDisplay doubleValue];
                
                if (simProcessDataAddHold [0] < 0 || simProcessDataAddHold [0] > 10){
                    simProcessDataAddHold [0] = 1;
                    [growthAddTimeBDDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthAddTimeTDDisplay){
                simProcessDataAddHold [1] = [growthAddTimeTDDisplay doubleValue];
                
                if (simProcessDataAddHold [1] < 0 || simProcessDataAddHold [1] > 10){
                    simProcessDataAddHold [1] = 1;
                    [growthAddTimeTDDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthAddTimeCFDisplay){
                simProcessDataAddHold [2] = [growthAddTimeCFDisplay doubleValue];
                
                if (simProcessDataAddHold [2] < 0 || simProcessDataAddHold [2] > 10){
                    simProcessDataAddHold [2] = 1;
                    [growthAddTimeCFDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthAddBDDisplay){
                simProcessDataAddHold [3] = [growthAddBDDisplay doubleValue];
                simProcessDataAddHold [3] = (simProcessDataAddHold [3]/(double)100)*simProcessDataAddHold [23];
                
                if (simProcessDataAddHold [3] < 0){
                    simProcessDataAddHold [3] = 0;
                    [growthAddBDDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthAddTDDisplay){
                simProcessDataAddHold [4] = [growthAddTDDisplay doubleValue];
                simProcessDataAddHold [4] = (simProcessDataAddHold [4]/(double)100)*simProcessDataAddHold [23];
                
                if (simProcessDataAddHold [4] < 0){
                    simProcessDataAddHold [4] = 0;
                    [growthAddTDDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthAddBDCDDisplay){
                simProcessDataAddHold [5] = [growthAddBDCDDisplay doubleValue];
                
                if (simProcessDataAddHold [5] < 0 || simProcessDataAddHold [5] > 10){
                    simProcessDataAddHold [5] = 1;
                    [growthAddBDCDDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthAddNOCDDisplay){
                simProcessDataAddHold [6] = [growthAddNOCDDisplay doubleValue];
                
                if (simProcessDataAddHold [6] < 0 || simProcessDataAddHold [6] > 10){
                    simProcessDataAddHold [6] = 1;
                    [growthAddNOCDDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthAddBDCFDisplay){
                simProcessDataAddHold [7] = [growthAddBDCFDisplay doubleValue];
                
                if (simProcessDataAddHold [7] < 0 || simProcessDataAddHold [7] > 10){
                    simProcessDataAddHold [7] = 1;
                    [growthAddBDCFDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthAddBDCFBDDisplay){
                simProcessDataAddHold [8] = [growthAddBDCFBDDisplay doubleValue];
                simProcessDataAddHold [8] = (simProcessDataAddHold [8]/(double)100)*simProcessDataAddHold [23];
                
                if (simProcessDataAddHold [8] < 0){
                    simProcessDataAddHold [8] = 0;
                    [growthAddBDCFBDDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthAddBDCFTDDisplay){
                simProcessDataAddHold [9] = [growthAddBDCFTDDisplay doubleValue];
                simProcessDataAddHold [9] = (simProcessDataAddHold [9]/(double)100)*simProcessDataAddHold [23];
                
                if (simProcessDataAddHold [9] < 0){
                    simProcessDataAddHold [9] = 0;
                    [growthAddBDCFTDDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthAddBDCFCDDisplay){
                simProcessDataAddHold [10] = [growthAddBDCFCDDisplay doubleValue];
                
                if (simProcessDataAddHold [10] < 0 || simProcessDataAddHold [10] > 10){
                    simProcessDataAddHold [10] = 1;
                    [growthAddBDCFDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthAddTDCFDisplay){
                simProcessDataAddHold [11] = [growthAddTDCFDisplay doubleValue];
                
                if (simProcessDataAddHold [11] < 0 || simProcessDataAddHold [11] > 10){
                    simProcessDataAddHold [11] = 1;
                    [growthAddTDCFDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthAddTDCFBDDisplay){
                simProcessDataAddHold [12] = [growthAddTDCFBDDisplay doubleValue];
                simProcessDataAddHold [12] = (simProcessDataAddHold [12]/(double)100)*simProcessDataAddHold [23];
                
                if (simProcessDataAddHold [12] < 0){
                    simProcessDataAddHold [12] = 0;
                    [growthAddTDCFBDDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthAddTDCFTDDisplay){
                simProcessDataAddHold [13] = [growthAddTDCFTDDisplay doubleValue];
                simProcessDataAddHold [13] = (simProcessDataAddHold [13]/(double)100)*simProcessDataAddHold [23];
                
                if (simProcessDataAddHold [13] < 0){
                    simProcessDataAddHold [13] = 0;
                    [growthAddTDCFTDDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthAddTDCFCDDisplay){
                simProcessDataAddHold [14] = [growthAddTDCFCDDisplay doubleValue];
                
                if (simProcessDataAddHold [14] < 0 || simProcessDataAddHold [14] > 10){
                    simProcessDataAddHold [14] = 1;
                    [growthAddTDCFCDDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthAddTDBDDisplay){
                simProcessDataAddHold [15] = [growthAddTDBDDisplay doubleValue];
                simProcessDataAddHold [15] = (simProcessDataAddHold [15]/(double)100)*simProcessDataAddHold [23];
                
                if (simProcessDataAddHold [15] < 0){
                    simProcessDataAddHold [15] = 0;
                    [growthAddTDBDDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthAddTDTDDisplay){
                simProcessDataAddHold [16] = [growthAddTDTDDisplay doubleValue];
                simProcessDataAddHold [16] = (simProcessDataAddHold [16]/(double)100)*simProcessDataAddHold [23];
                
                if (simProcessDataAddHold [16] < 0){
                    simProcessDataAddHold [16] = 0;
                    [growthAddTDTDDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthAddTDCDDisplay){
                simProcessDataAddHold [17] = [growthAddTDCDDisplay doubleValue];
                
                if (simProcessDataAddHold [17] < 0 || simProcessDataAddHold [17] > 10){
                    simProcessDataAddHold [17] = 1;
                    [growthAddTDCDDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthAddMulTDTDDisplay){
                simProcessDataAddHold [18] = [growthAddMulTDTDDisplay doubleValue];
                
                if (simProcessDataAddHold [18] < 2 || simProcessDataAddHold [18] > 3){
                    simProcessDataAddHold [18] = 2;
                    [growthAddTDCDDisplay setIntegerValue:2];
                }
            }
            
            if ([aNotification object] == growthAddSupTDBDDisplay){
                simProcessDataAddHold [19] = [growthAddSupTDBDDisplay doubleValue];
                
                if (simProcessDataAddHold [19] < 1 || simProcessDataAddHold [19] > 3){
                    simProcessDataAddHold [19] = 1;
                    [growthAddSupTDBDDisplay setIntegerValue:1];
                }
            }
            
            if ([aNotification object] == growthAddNoDivDisplay){
                simProcessDataAddHold [20] = [growthAddNoDivDisplay doubleValue];
                simProcessDataAddHold [20] = (simProcessDataAddHold [20]/(double)100)*simProcessDataAddHold [24];
                
                if (simProcessDataAddHold [20] < 0){
                    simProcessDataAddHold [20] = 0;
                    [growthAddNoDivDisplay setIntegerValue:0];
                }
            }
            
            if ([aNotification object] == growthAddRecoveryDisplay){
                simProcessDataAddHold [21] = [growthAddRecoveryDisplay doubleValue];
                simProcessDataAddHold [21] = (simProcessDataAddHold [21]/(double)100)*simProcessDataAddHold [24];
                
                if (simProcessDataAddHold [21] < 0){
                    simProcessDataAddHold [21] = 0;
                    [growthAddRecoveryDisplay setIntegerValue:0];
                }
            }
            
            //----Video parameters----
            if (timingSimCount == 0){
                if ([aNotification object] == movieDistanceDisplay){
                    movieDistanceHold = [movieDistanceDisplay intValue];
                    
                    if (movieDistanceHold < 0){
                        movieDistanceHold = 0;
                        [movieDistanceDisplay setIntegerValue:0];
                    }
                }
                
                if ([aNotification object] == movieDistanceDisplay2){
                    movieDistanceHold2 = [movieDistanceDisplay2 intValue];
                    
                    if (movieDistanceHold2 < 0){
                        movieDistanceHold2 = 0;
                        [movieDistanceDisplay2 setIntegerValue:0];
                    }
                }
                
                if ([aNotification object] == movieDistanceDisplay3){
                    movieDistanceHold3 = [movieDistanceDisplay3 intValue];
                    
                    if (movieDistanceHold3 < 0){
                        movieDistanceHold3 = 0;
                        [movieDistanceDisplay3 setIntegerValue:0];
                    }
                }
                
                if ([aNotification object] == movieDistanceTimeDisplay2){
                    movieDistanceTime2 = [movieDistanceTimeDisplay2 intValue];
                    
                    if (movieDistanceTime2 < 0){
                        movieDistanceTime2 = 0;
                        [movieDistanceTimeDisplay2 setIntegerValue:0];
                    }
                }
                
                if ([aNotification object] == movieDistanceTimeDisplay3){
                    movieDistanceTime3 = [movieDistanceTimeDisplay3 intValue];
                    
                    if (movieDistanceTime3 < 0){
                        movieDistanceTime3 = 0;
                        [movieDistanceTimeDisplay3 setIntegerValue:0];
                    }
                }
                
                if ([aNotification object] == circleSizeDisplay){
                    circleSizeHold = [circleSizeDisplay intValue];
                    
                    if (circleSizeHold < 0){
                        circleSizeHold = 0;
                        [circleSizeDisplay setIntegerValue:0];
                    }
                }
                
                if ([aNotification object] == circleSizeMinDisplay){
                    circleMinHold = [circleSizeMinDisplay intValue];
                    
                    if (circleMinHold < 0){
                        circleMinHold = 0;
                        [circleSizeMinDisplay setIntegerValue:0];
                    }
                }
                
                if ([aNotification object] == circleSizeMinDisplay){
                    circleMinHold = [circleSizeMinDisplay intValue];
                    
                    if (circleMinHold < 0){
                        circleMinHold = 0;
                        [circleSizeMinDisplay setIntegerValue:0];
                    }
                }
                
                if ([aNotification object] == videoImageSizeDisplay){
                    videoImageSizeHold = [videoImageSizeDisplay intValue];
                    
                    if (videoImageSizeHold < 0){
                        videoImageSizeHold = 0;
                        [videoImageSizeDisplay setIntegerValue:0];
                    }
                }
                
                if ([aNotification object] == colorToneDisplay){
                    colorToneChangeTimeHold = [colorToneDisplay intValue];
                    
                    if (colorToneChangeTimeHold < 0){
                        colorToneChangeTimeHold = 0;
                        [colorToneDisplay setIntegerValue:0];
                    }
                }
            }
            
            //----Dose simulation----
            if (simulationProgress == 0){
                if ([aNotification object] == doseBaseDisplay){
                    doseBaseHold = [doseBaseDisplay doubleValue];
                    
                    if (doseBaseHold < 0){
                        doseBaseHold = 0;
                        [doseBaseDisplay setIntegerValue:1];
                    }
                }
                
                if ([aNotification object] == doseMiddleDisplay){
                    doseMiddleHold = [doseMiddleDisplay doubleValue];
                    
                    if (doseMiddleHold < 0){
                        doseMiddleHold = 0;
                        [doseMiddleDisplay setIntegerValue:1];
                    }
                }
                
                if ([aNotification object] == doseTargetDisplay){
                    doseTargetHold = [doseTargetDisplay doubleValue];
                    
                    if (doseTargetHold < 0){
                        doseTargetHold = 0;
                        [doseTargetDisplay setIntegerValue:1];
                    }
                }
                
                if ([aNotification object] == endVariationDisplay){
                    endVariationHold = [endVariationDisplay doubleValue];
                    
                    if (endVariationHold < 0){
                        endVariationHold = 0;
                        [endVariationDisplay setIntegerValue:1];
                    }
                }
                
                if ([aNotification object] == selectLingNoDisplay){
                    selectLingNoHold = [selectLingNoDisplay intValue];
                    
                    if (selectLingNoHold < 0){
                        selectLingNoHold = 0;
                        [selectLingNoDisplay setIntegerValue:0];
                    }
                }
                
                if ([aNotification object] == fluorescentDropDisplay){
                    fluorescentDropHold = [fluorescentDropDisplay intValue];
                    
                    if (fluorescentDropHold < 0){
                        fluorescentDropHold = 0;
                        [fluorescentDropDisplay setIntegerValue:0];
                    }
                }
            }
        }
    }
}

-(IBAction)clearSet:(id)sender{
    if (simulationProgress == 0){
        for (int counter1 = 0; counter1 < 100; counter1++){
            simProcessDataBaseHold [counter1] = 0;
            simProcessDataMiddleHold [counter1] = 0;
            simProcessDataProgHold [counter1] = 0;
            simProcessDataAddHold [counter1] = 0;
        }
        
        [growthTimeBDDisplay setStringValue:@""];
        [growthTimeTDDisplay setStringValue:@""];
        [growthTimeCFDisplay setStringValue:@""];
        [growthBDDisplay setStringValue:@""];
        [growthTDDisplay setStringValue:@""];
        [growthBDCDDisplay setStringValue:@""];
        [growthNOCDDisplay setStringValue:@""];
        [growthBDCFDisplay setStringValue:@""];
        [growthBDCFBDDisplay setStringValue:@""];
        [growthBDCFTDDisplay setStringValue:@""];
        [growthBDCFCDDisplay setStringValue:@""];
        [growthTDCFDisplay setStringValue:@""];
        [growthTDCFBDDisplay setStringValue:@""];
        [growthTDCFTDDisplay setStringValue:@""];
        [growthTDCFCDDisplay setStringValue:@""];
        [growthTDBDDisplay setStringValue:@""];
        [growthTDTDDisplay setStringValue:@""];
        [growthTDCDDisplay setStringValue:@""];
        [growthMulTDTDDisplay setStringValue:@""];
        [growthSupTDBDDisplay setStringValue:@""];
        [growthNoDivDisplay setStringValue:@""];
        [growthRecoveryDisplay setStringValue:@""];
        
        [growthPrgTimeBDDisplay setStringValue:@""];
        [growthPrgTimeTDDisplay setStringValue:@""];
        [growthPrgTimeCFDisplay setStringValue:@""];
        [growthPrgBDDisplay setStringValue:@""];
        [growthPrgTDDisplay setStringValue:@""];
        [growthPrgBDCDDisplay setStringValue:@""];
        [growthPrgNOCDDisplay setStringValue:@""];
        [growthPrgBDCFDisplay setStringValue:@""];
        [growthPrgBDCFBDDisplay setStringValue:@""];
        [growthPrgBDCFTDDisplay setStringValue:@""];
        [growthPrgBDCFCDDisplay setStringValue:@""];
        [growthPrgTDCFDisplay setStringValue:@""];
        [growthPrgTDCFBDDisplay setStringValue:@""];
        [growthPrgTDCFTDDisplay setStringValue:@""];
        [growthPrgTDCFCDDisplay setStringValue:@""];
        [growthPrgTDBDDisplay setStringValue:@""];
        [growthPrgTDTDDisplay setStringValue:@""];
        [growthPrgTDCDDisplay setStringValue:@""];
        [growthPrgMulTDTDDisplay setStringValue:@""];
        [growthPrgSupTDBDDisplay setStringValue:@""];
        [growthPrgNoDivDisplay setStringValue:@""];
        [growthPrgRecoveryDisplay setStringValue:@""];
        
        [growthMidTimeBDDisplay setStringValue:@""];
        [growthMidTimeTDDisplay setStringValue:@""];
        [growthMidTimeCFDisplay setStringValue:@""];
        [growthMidBDDisplay setStringValue:@""];
        [growthMidTDDisplay setStringValue:@""];
        [growthMidBDCDDisplay setStringValue:@""];
        [growthMidNOCDDisplay setStringValue:@""];
        [growthMidBDCFDisplay setStringValue:@""];
        [growthMidBDCFBDDisplay setStringValue:@""];
        [growthMidBDCFTDDisplay setStringValue:@""];
        [growthMidBDCFCDDisplay setStringValue:@""];
        [growthMidTDCFDisplay setStringValue:@""];
        [growthMidTDCFBDDisplay setStringValue:@""];
        [growthMidTDCFTDDisplay setStringValue:@""];
        [growthMidTDCFCDDisplay setStringValue:@""];
        [growthMidTDBDDisplay setStringValue:@""];
        [growthMidTDTDDisplay setStringValue:@""];
        [growthMidTDCDDisplay setStringValue:@""];
        [growthMidMulTDTDDisplay setStringValue:@""];
        [growthMidSupTDBDDisplay setStringValue:@""];
        [growthMidNoDivDisplay setStringValue:@""];
        [growthMidRecoveryDisplay setStringValue:@""];
        
        [growthAddTimeBDDisplay setStringValue:@""];
        [growthAddTimeTDDisplay setStringValue:@""];
        [growthAddTimeCFDisplay setStringValue:@""];
        [growthAddBDDisplay setStringValue:@""];
        [growthAddTDDisplay setStringValue:@""];
        [growthAddBDCDDisplay setStringValue:@""];
        [growthAddNOCDDisplay setStringValue:@""];
        [growthAddBDCFDisplay setStringValue:@""];
        [growthAddBDCFBDDisplay setStringValue:@""];
        [growthAddBDCFTDDisplay setStringValue:@""];
        [growthAddBDCFCDDisplay setStringValue:@""];
        [growthAddTDCFDisplay setStringValue:@""];
        [growthAddTDCFBDDisplay setStringValue:@""];
        [growthAddTDCFTDDisplay setStringValue:@""];
        [growthAddTDCFCDDisplay setStringValue:@""];
        [growthAddTDBDDisplay setStringValue:@""];
        [growthAddTDTDDisplay setStringValue:@""];
        [growthAddTDCDDisplay setStringValue:@""];
        [growthAddMulTDTDDisplay setStringValue:@""];
        [growthAddSupTDBDDisplay setStringValue:@""];
        [growthAddNoDivDisplay setStringValue:@""];
        [growthAddRecoveryDisplay setStringValue:@""];
        
        [growthTreatDisplay setStringValue:@"Treat 1"];
        [growthPrgTreatDisplay setStringValue:@"Treat 3"];
        [growthMidTreatDisplay setStringValue:@"Treat 2"];
        [growthAddTreatDisplay setStringValue:@"Treat 4"];
        
        [fluorescentBiasDisplay setStringValue:@""];
        [fluorescentDropDisplay setStringValue:@""];
        [fluorescentProgDisplay setStringValue:@"nil"];
        [fluorescentMidDisplay setStringValue:@"nil"];
        [fluorescentAddDisplay setStringValue:@"nil"];
        
        messageStringSim = "nil";
        messageStringSim2 = "nil";
        messageStringSim3 = "nil";
        messageStringSim4 = "nil";
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Sim Running"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)clearSetA:(id)sender{
    if (simulationProgress == 0){
        for (int counter1 = 0; counter1 < 100; counter1++) simProcessDataBaseHold [counter1] = 0;
        
        [growthTimeBDDisplay setStringValue:@""];
        [growthTimeTDDisplay setStringValue:@""];
        [growthTimeCFDisplay setStringValue:@""];
        [growthBDDisplay setStringValue:@""];
        [growthTDDisplay setStringValue:@""];
        [growthBDCDDisplay setStringValue:@""];
        [growthNOCDDisplay setStringValue:@""];
        [growthBDCFDisplay setStringValue:@""];
        [growthBDCFBDDisplay setStringValue:@""];
        [growthBDCFTDDisplay setStringValue:@""];
        [growthBDCFCDDisplay setStringValue:@""];
        [growthTDCFDisplay setStringValue:@""];
        [growthTDCFBDDisplay setStringValue:@""];
        [growthTDCFTDDisplay setStringValue:@""];
        [growthTDCFCDDisplay setStringValue:@""];
        [growthTDBDDisplay setStringValue:@""];
        [growthTDTDDisplay setStringValue:@""];
        [growthTDCDDisplay setStringValue:@""];
        [growthMulTDTDDisplay setStringValue:@""];
        [growthSupTDBDDisplay setStringValue:@""];
        [growthNoDivDisplay setStringValue:@""];
        [growthRecoveryDisplay setStringValue:@""];
        [fluorescentBiasDisplay setStringValue:@""];
        
        [growthTreatDisplay setStringValue:@"Treat 1"];
        
        messageStringSim = "nil";
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Sim Running"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)clearSetC:(id)sender{
    if (simulationProgress == 0){
        for (int counter1 = 0; counter1 < 100; counter1++) simProcessDataProgHold [counter1] = 0;
        
        [growthPrgTimeBDDisplay setStringValue:@""];
        [growthPrgTimeTDDisplay setStringValue:@""];
        [growthPrgTimeCFDisplay setStringValue:@""];
        [growthPrgBDDisplay setStringValue:@""];
        [growthPrgTDDisplay setStringValue:@""];
        [growthPrgBDCDDisplay setStringValue:@""];
        [growthPrgNOCDDisplay setStringValue:@""];
        [growthPrgBDCFDisplay setStringValue:@""];
        [growthPrgBDCFBDDisplay setStringValue:@""];
        [growthPrgBDCFTDDisplay setStringValue:@""];
        [growthPrgBDCFCDDisplay setStringValue:@""];
        [growthPrgTDCFDisplay setStringValue:@""];
        [growthPrgTDCFBDDisplay setStringValue:@""];
        [growthPrgTDCFTDDisplay setStringValue:@""];
        [growthPrgTDCFCDDisplay setStringValue:@""];
        [growthPrgTDBDDisplay setStringValue:@""];
        [growthPrgTDTDDisplay setStringValue:@""];
        [growthPrgTDCDDisplay setStringValue:@""];
        [growthPrgMulTDTDDisplay setStringValue:@""];
        [growthPrgSupTDBDDisplay setStringValue:@""];
        [growthPrgNoDivDisplay setStringValue:@""];
        [growthPrgRecoveryDisplay setStringValue:@""];
        
        [growthPrgTreatDisplay setStringValue:@"Treat 3"];
        
        messageStringSim3 = "nil";
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Sim Running"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)clearSetB:(id)sender{
    if (simulationProgress == 0){
        for (int counter1 = 0; counter1 < 100; counter1++) simProcessDataMiddleHold [counter1] = 0;
        
        [growthMidTimeBDDisplay setStringValue:@""];
        [growthMidTimeTDDisplay setStringValue:@""];
        [growthMidTimeCFDisplay setStringValue:@""];
        [growthMidBDDisplay setStringValue:@""];
        [growthMidTDDisplay setStringValue:@""];
        [growthMidBDCDDisplay setStringValue:@""];
        [growthMidNOCDDisplay setStringValue:@""];
        [growthMidBDCFDisplay setStringValue:@""];
        [growthMidBDCFBDDisplay setStringValue:@""];
        [growthMidBDCFTDDisplay setStringValue:@""];
        [growthMidBDCFCDDisplay setStringValue:@""];
        [growthMidTDCFDisplay setStringValue:@""];
        [growthMidTDCFBDDisplay setStringValue:@""];
        [growthMidTDCFTDDisplay setStringValue:@""];
        [growthMidTDCFCDDisplay setStringValue:@""];
        [growthMidTDBDDisplay setStringValue:@""];
        [growthMidTDTDDisplay setStringValue:@""];
        [growthMidTDCDDisplay setStringValue:@""];
        [growthMidMulTDTDDisplay setStringValue:@""];
        [growthMidSupTDBDDisplay setStringValue:@""];
        [growthMidNoDivDisplay setStringValue:@""];
        [growthMidRecoveryDisplay setStringValue:@""];
        
        [growthMidTreatDisplay setStringValue:@"Treat 2"];
        
        messageStringSim2 = "nil";
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];}
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Sim Running"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)clearSetD:(id)sender{
    if (simulationProgress == 0){
        for (int counter1 = 0; counter1 < 100; counter1++) simProcessDataAddHold [counter1] = 0;
        
        [growthAddTimeBDDisplay setStringValue:@""];
        [growthAddTimeTDDisplay setStringValue:@""];
        [growthAddTimeCFDisplay setStringValue:@""];
        [growthAddBDDisplay setStringValue:@""];
        [growthAddTDDisplay setStringValue:@""];
        [growthAddBDCDDisplay setStringValue:@""];
        [growthAddNOCDDisplay setStringValue:@""];
        [growthAddBDCFDisplay setStringValue:@""];
        [growthAddBDCFBDDisplay setStringValue:@""];
        [growthAddBDCFTDDisplay setStringValue:@""];
        [growthAddBDCFCDDisplay setStringValue:@""];
        [growthAddTDCFDisplay setStringValue:@""];
        [growthAddTDCFBDDisplay setStringValue:@""];
        [growthAddTDCFTDDisplay setStringValue:@""];
        [growthAddTDCFCDDisplay setStringValue:@""];
        [growthAddTDBDDisplay setStringValue:@""];
        [growthAddTDTDDisplay setStringValue:@""];
        [growthAddTDCDDisplay setStringValue:@""];
        [growthAddMulTDTDDisplay setStringValue:@""];
        [growthAddSupTDBDDisplay setStringValue:@""];
        [growthAddNoDivDisplay setStringValue:@""];
        [growthAddRecoveryDisplay setStringValue:@""];
        
        [growthAddTreatDisplay setStringValue:@"Treat 4"];
        
        messageStringSim4 = "nil";
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Sim Running"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)fitModeSet:(id)sender{
    if (fitModeStatusHold == 0){
        fitModeStatusHold = 1;
        [fitModeDisplay setStringValue:@"Growth+Prog"];
    }
    else if (fitModeStatusHold == 1){
        fitModeStatusHold = 0;
        [fitModeDisplay setStringValue:@"Growth"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)limitSimSet:(id)sender{
    if (limitSimType == 0){
        limitSimType = 1;
        [limitSimDisplay setStringValue:@"X2"];
    }
    else if (limitSimType == 1){
        limitSimType = 2;
        [limitSimDisplay setStringValue:@"X10"];
    }
    else if (limitSimType == 2){
        limitSimType = 3;
        [limitSimDisplay setStringValue:@"X100"];
    }
    else if (limitSimType == 3){
        limitSimType = 0;
        [limitSimDisplay setStringValue:@"None"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)fitPerformSet:(id)sender{
    if (fitCycleHold != 0){
        int valueCheck = 0;
        
        if (fitA1Hold >= 1 && fitB1Hold <= 43){
            valueCheck = 1;
            
            if (fitA2Hold >= 1 && fitB2Hold <= 43){
                valueCheck = 2;
                
                if (fitA3Hold >= 1 && fitB3Hold <= 43){
                    valueCheck = 3;
                    
                    if (fitA4Hold >= 1 && fitB4Hold <= 43){
                        valueCheck = 4;
                    }
                }
            }
        }
        
        if (valueCheck != 0){
            if (fitModeStatusHold == 0){
                if (fitDataHoldStatus == 1){
                    delete [] arrayFitDataHold;
                }
                
                arrayFitDataHold = new double [fitCycleHold*4+100];
                fitDataHoldCount = fitCycleHold*4+4;
                
                for (int counter1 = 0; counter1 < fitCycleHold*4+100; counter1++) arrayFitDataHold [counter1] = 0;
                
                arrayFitDataHold [0] = -1;
                
                if (valueCheck == 2 || valueCheck == 3 || valueCheck == 4) arrayFitDataHold [1] = -1;
                if (valueCheck == 3 || valueCheck == 4) arrayFitDataHold [2] = -1;
                if (valueCheck == 4) arrayFitDataHold [3] = -1;
                
                for (int counter1 = 1; counter1 <= fitCycleHold; counter1++){
                    if (fitB1Hold*(counter1) < 43.6){
                        if (fitA1Hold*exp(fitB1Hold*(counter1+1)) < 9223372036854775807){
                            if (limitSimType == 0){
                                arrayFitDataHold [counter1*4] = fitA1Hold*exp(fitB1Hold*(counter1));
                            }
                            else if (limitSimType == 1){
                                if (fitA1Hold*exp(fitB1Hold*(counter1)) <= fitA1Hold*2){
                                    arrayFitDataHold [counter1*4] = fitA1Hold*exp(fitB1Hold*(counter1));
                                }
                                else arrayFitDataHold [counter1*4] = -2;
                            }
                            else if (limitSimType == 2){
                                if (fitA1Hold*exp(fitB1Hold*(counter1)) <= fitA1Hold*10){
                                    arrayFitDataHold [counter1*4] = fitA1Hold*exp(fitB1Hold*(counter1));
                                }
                                else arrayFitDataHold [counter1*4] = -2;
                            }
                            else if (limitSimType == 3){
                                if (fitA1Hold*exp(fitB1Hold*(counter1)) <= fitA1Hold*100){
                                    arrayFitDataHold [counter1*4] = fitA1Hold*exp(fitB1Hold*(counter1));
                                }
                                else arrayFitDataHold [counter1*4] = -2;
                            }
                        }
                    }
                    
                    if (valueCheck == 2 || valueCheck == 3 || valueCheck == 4){
                        if (fitB2Hold*(counter1) < 43.6){
                            if (fitA2Hold*exp(fitB2Hold*(counter1+1)) < 9223372036854775807){
                                if (limitSimType == 0){
                                    arrayFitDataHold [counter1*4+1] = fitA2Hold*exp(fitB2Hold*(counter1));
                                }
                                else if (limitSimType == 1){
                                    if (fitA2Hold*exp(fitB2Hold*(counter1)) <= fitA2Hold*2){
                                        arrayFitDataHold [counter1*4+1] = fitA2Hold*exp(fitB2Hold*(counter1));
                                    }
                                    else arrayFitDataHold [counter1*4+1] = -2;
                                }
                                else if (limitSimType == 2){
                                    if (fitA2Hold*exp(fitB2Hold*(counter1)) <= fitA2Hold*10){
                                        arrayFitDataHold [counter1*4+1] = fitA2Hold*exp(fitB2Hold*(counter1));
                                    }
                                    else arrayFitDataHold [counter1*4+1] = -2;
                                }
                                else if (limitSimType == 3){
                                    if (fitA2Hold*exp(fitB2Hold*(counter1)) <= fitA2Hold*100){
                                        arrayFitDataHold [counter1*4+1] = fitA2Hold*exp(fitB2Hold*(counter1));
                                    }
                                    else arrayFitDataHold [counter1*4+1] = -2;
                                }
                            }
                        }
                    }
                    
                    if (valueCheck == 3 || valueCheck == 4){
                        if (fitB3Hold*(counter1) < 43.6){
                            if (fitA3Hold*exp(fitB3Hold*(counter1+1)) < 9223372036854775807){
                                if (limitSimType == 0){
                                    arrayFitDataHold [counter1*4+2] = fitA3Hold*exp(fitB3Hold*(counter1));
                                }
                                else if (limitSimType == 1){
                                    if (fitA3Hold*exp(fitB3Hold*(counter1)) <= fitA3Hold*2){
                                        arrayFitDataHold [counter1*4+2] = fitA3Hold*exp(fitB3Hold*(counter1));
                                    }
                                    else arrayFitDataHold [counter1*4+2] = -2;
                                }
                                else if (limitSimType == 2){
                                    if (fitA3Hold*exp(fitB3Hold*(counter1)) <= fitA3Hold*10){
                                        arrayFitDataHold [counter1*4+2] = fitA3Hold*exp(fitB3Hold*(counter1));
                                    }
                                    else arrayFitDataHold [counter1*4+2] = -2;
                                }
                                else if (limitSimType == 3){
                                    if (fitA3Hold*exp(fitB3Hold*(counter1)) <= fitA3Hold*100){
                                        arrayFitDataHold [counter1*4+2] = fitA3Hold*exp(fitB3Hold*(counter1));
                                    }
                                    else arrayFitDataHold [counter1*4+2] = -2;
                                }
                            }
                        }
                    }
                    
                    if (valueCheck == 4){
                        if (fitB4Hold*(counter1) < 43.6){
                            if (fitA4Hold*exp(fitB4Hold*(counter1+1)) < 9223372036854775807){
                                if (limitSimType == 0){
                                    arrayFitDataHold [counter1*4+3] = fitA4Hold*exp(fitB4Hold*(counter1));
                                }
                                else if (limitSimType == 1){
                                    if (fitA4Hold*exp(fitB4Hold*(counter1)) <= fitA4Hold*2){
                                        arrayFitDataHold [counter1*4+3] = fitA4Hold*exp(fitB4Hold*(counter1));
                                    }
                                    else arrayFitDataHold [counter1*4+3] = -2;
                                }
                                else if (limitSimType == 2){
                                    if (fitA4Hold*exp(fitB4Hold*(counter1)) <= fitA4Hold*10){
                                        arrayFitDataHold [counter1*4+3] = fitA4Hold*exp(fitB4Hold*(counter1));
                                    }
                                    else arrayFitDataHold [counter1*4+3] = -2;
                                }
                                else if (limitSimType == 3){
                                    if (fitA4Hold*exp(fitB4Hold*(counter1)) <= fitA4Hold*100){
                                        arrayFitDataHold [counter1*4+3] = fitA4Hold*exp(fitB4Hold*(counter1));
                                    }
                                    else arrayFitDataHold [counter1*4+3] = -2;
                                }
                            }
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < fitCycleHold; counterA++){
                //    cout<<counterA<<" "<<arrayFitDataHold [counterA*4]<<" "<<arrayFitDataHold [counterA*4+1]<<" "<<arrayFitDataHold [counterA*4+2]<<" "<<arrayFitDataHold [counterA*4+3]<<" arrayFitDataHold"<<endl;
                //}
                
                processSimType = 1;
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSimulationDisplay object:nil];
            }
            else if (fitModeStatusHold == 1){
                int modeCheck = 0;
                
                if (fitRangeBEndHold > 43 && fitModeStatusHold == 1){
                    modeCheck = 1;
                }
                
                if ((fitTimeStartHold > fitCycleHold || fitCycleHold-fitTimeStartHold < 10) && fitModeStatusHold == 1){
                    modeCheck = 1;
                }
                
                if (modeCheck == 0){
                    if (fitDataHoldStatus == 1){
                        delete [] arrayFitDataHold;
                    }
                    
                    arrayFitDataHold = new double [fitCycleHold*4+100];
                    fitDataHoldCount = fitCycleHold*4+4;
                    
                    for (int counter1 = 0; counter1 < fitCycleHold*4+100; counter1++) arrayFitDataHold [counter1] = 0;
                    
                    arrayFitDataHold [0] = -1;
                    
                    if (valueCheck == 2 || valueCheck == 3 || valueCheck == 4) arrayFitDataHold [1] = -1;
                    if (valueCheck == 3 || valueCheck == 4) arrayFitDataHold [2] = -1;
                    if (valueCheck == 4) arrayFitDataHold [3] = -1;
                    
                    double increment = 0;
                    int timeLapsFromStart = 0;
                    
                    for (int counter1 = 1; counter1 <= fitCycleHold; counter1++){
                        if (counter1 > fitTimeStartHold) timeLapsFromStart++;
                        
                        if (fitB1Hold*(counter1) < 43.6){
                            if (fitA1Hold*exp(fitB1Hold*(counter1+1)) < 9223372036854775807){
                                if (counter1 < fitTimeStartHold){
                                    if (limitSimType == 0){
                                        arrayFitDataHold [counter1*4] = fitA1Hold*exp(fitB1Hold*(counter1));
                                    }
                                    else if (limitSimType == 1){
                                        if (fitA1Hold*exp(fitB1Hold*(counter1)) <= fitA1Hold*2){
                                            arrayFitDataHold [counter1*4] = fitA1Hold*exp(fitB1Hold*(counter1));
                                        }
                                        else arrayFitDataHold [counter1*4] = -2;
                                    }
                                    else if (limitSimType == 2){
                                        if (fitA1Hold*exp(fitB1Hold*(counter1)) <= fitA1Hold*10){
                                            arrayFitDataHold [counter1*4] = fitA1Hold*exp(fitB1Hold*(counter1));
                                        }
                                        else arrayFitDataHold [counter1*4] = -2;
                                    }
                                    else if (limitSimType == 3){
                                        if (fitA1Hold*exp(fitB1Hold*(counter1)) <= fitA1Hold*100){
                                            arrayFitDataHold [counter1*4] = fitA1Hold*exp(fitB1Hold*(counter1));
                                        }
                                        else arrayFitDataHold [counter1*4] = -2;
                                    }
                                }
                                else{
                                    
                                    increment = (fitRangeBEndHold-fitB1Hold)/(double(fitCycleHold-fitTimeStartHold-1));
                                    
                                    if (limitSimType == 0){
                                        arrayFitDataHold [counter1*4] = fitA1Hold*exp((fitB1Hold+increment*timeLapsFromStart)*(counter1));
                                    }
                                    else if (limitSimType == 1){
                                        if (fitA1Hold*exp((fitB1Hold+increment*timeLapsFromStart)*(counter1)) <= fitA1Hold*2){
                                            arrayFitDataHold [counter1*4] = fitA1Hold*exp((fitB1Hold+increment*timeLapsFromStart)*(counter1));
                                        }
                                        else arrayFitDataHold [counter1*4] = -2;
                                    }
                                    else if (limitSimType == 2){
                                        if (fitA1Hold*exp((fitB1Hold+increment*timeLapsFromStart)*(counter1)) <= fitA1Hold*10){
                                            arrayFitDataHold [counter1*4] = fitA1Hold*exp((fitB1Hold+increment*timeLapsFromStart)*(counter1));
                                        }
                                        else arrayFitDataHold [counter1*4] = -2;
                                    }
                                    else if (limitSimType == 3){
                                        if (fitA1Hold*exp((fitB1Hold+increment*timeLapsFromStart)*(counter1)) <= fitA1Hold*100){
                                            arrayFitDataHold [counter1*4] = fitA1Hold*exp((fitB1Hold+increment*timeLapsFromStart)*(counter1));
                                        }
                                        else arrayFitDataHold [counter1*4] = -2;
                                    }
                                }
                            }
                        }
                        
                        if (valueCheck == 2 || valueCheck == 3 || valueCheck == 4){
                            if (fitB2Hold*(counter1) < 43.6){
                                if (fitA2Hold*exp(fitB2Hold*(counter1+1)) < 9223372036854775807){
                                    if (limitSimType == 0){
                                        arrayFitDataHold [counter1*4+1] = fitA2Hold*exp(fitB2Hold*(counter1));
                                    }
                                    else if (limitSimType == 1){
                                        if (fitA2Hold*exp(fitB2Hold*(counter1)) <= fitA2Hold*2){
                                            arrayFitDataHold [counter1*4+1] = fitA2Hold*exp(fitB2Hold*(counter1));
                                        }
                                        else arrayFitDataHold [counter1*4+1] = -2;
                                    }
                                    else if (limitSimType == 2){
                                        if (fitA2Hold*exp(fitB2Hold*(counter1)) <= fitA2Hold*10){
                                            arrayFitDataHold [counter1*4+1] = fitA2Hold*exp(fitB2Hold*(counter1));
                                        }
                                        else arrayFitDataHold [counter1*4+1] = -2;
                                    }
                                    else if (limitSimType == 3){
                                        if (fitA2Hold*exp(fitB2Hold*(counter1)) <= fitA2Hold*100){
                                            arrayFitDataHold [counter1*4+1] = fitA2Hold*exp(fitB2Hold*(counter1));
                                        }
                                        else arrayFitDataHold [counter1*4+1] = -2;
                                    }
                                }
                            }
                        }
                        
                        if (valueCheck == 3 || valueCheck == 4){
                            if (fitB3Hold*(counter1) < 43.6){
                                if (fitA3Hold*exp(fitB3Hold*(counter1+1)) < 9223372036854775807){
                                    if (limitSimType == 0){
                                        arrayFitDataHold [counter1*4+2] = fitA3Hold*exp(fitB3Hold*(counter1));
                                    }
                                    else if (limitSimType == 1){
                                        if (fitA3Hold*exp(fitB3Hold*(counter1)) <= fitA3Hold*2){
                                            arrayFitDataHold [counter1*4+2] = fitA3Hold*exp(fitB3Hold*(counter1));
                                        }
                                        else arrayFitDataHold [counter1*4+2] = -2;
                                    }
                                    else if (limitSimType == 2){
                                        if (fitA3Hold*exp(fitB3Hold*(counter1)) <= fitA3Hold*10){
                                            arrayFitDataHold [counter1*4+2] = fitA3Hold*exp(fitB3Hold*(counter1));
                                        }
                                        else arrayFitDataHold [counter1*4+2] = -2;
                                    }
                                    else if (limitSimType == 3){
                                        if (fitA3Hold*exp(fitB3Hold*(counter1)) <= fitA3Hold*100){
                                            arrayFitDataHold [counter1*4+2] = fitA3Hold*exp(fitB3Hold*(counter1));
                                        }
                                        else arrayFitDataHold [counter1*4+2] = -2;
                                    }
                                }
                            }
                        }
                        
                        if (valueCheck == 4){
                            if (fitB4Hold*(counter1) < 43.6){
                                if (fitA4Hold*exp(fitB4Hold*(counter1+1)) < 9223372036854775807){
                                    if (limitSimType == 0){
                                        arrayFitDataHold [counter1*4+3] = fitA4Hold*exp(fitB4Hold*(counter1));
                                    }
                                    else if (limitSimType == 1){
                                        if (fitA4Hold*exp(fitB4Hold*(counter1)) <= fitA4Hold*2){
                                            arrayFitDataHold [counter1*4+3] = fitA4Hold*exp(fitB4Hold*(counter1));
                                        }
                                        else arrayFitDataHold [counter1*4+3] = -2;
                                    }
                                    else if (limitSimType == 2){
                                        if (fitA4Hold*exp(fitB4Hold*(counter1)) <= fitA4Hold*10){
                                            arrayFitDataHold [counter1*4+3] = fitA4Hold*exp(fitB4Hold*(counter1));
                                        }
                                        else arrayFitDataHold [counter1*4+3] = -2;
                                    }
                                    else if (limitSimType == 3){
                                        if (fitA4Hold*exp(fitB4Hold*(counter1)) <= fitA4Hold*100){
                                            arrayFitDataHold [counter1*4+3] = fitA4Hold*exp(fitB4Hold*(counter1));
                                        }
                                        else arrayFitDataHold [counter1*4+3] = -2;
                                    }
                                }
                            }
                        }
                    }
                    
                    processSimType = 1;
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSimulationDisplay object:nil];
                    
                    //for (int counterA = 0; counterA < fitCycleHold; counterA++){
                    //    cout<<counterA<<" "<<arrayFitDataHold [counterA*4]<<" "<<arrayFitDataHold [counterA*4+1]<<" "<<arrayFitDataHold [counterA*4+2]<<" "<<arrayFitDataHold [counterA*4+3]<<" arrayFitDataHold"<<endl;
                    //}
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Check b End/Time"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Check a And b"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Check Cycle"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)exportSimdata:(id)sender{
    if (fitCycleHold != 0){
        int valueCheck = 0;
        
        if (fitA1Hold >= 1 && fitB1Hold <= 43){
            valueCheck = 1;
            
            if (fitA2Hold >= 1 && fitB2Hold <= 43){
                valueCheck = 2;
                
                if (fitA3Hold >= 1 && fitB3Hold <= 43){
                    valueCheck = 3;
                    
                    if (fitA4Hold >= 1 && fitB4Hold <= 43){
                        valueCheck = 4;
                    }
                }
            }
        }
        
        if (valueCheck != 0){
            string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
            mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Simulation";
            mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            DIR *dir;
            struct dirent *dent;
            
            string entry;
            string extractString;
            int maxEntryNo = 0;
            
            dir = opendir(resultSavePath2.c_str());
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        extractString = entry.substr(entry.find("FE")+2, entry.find(".txt")-entry.find("FE")-2);
                        
                        if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                    }
                }
                
                closedir(dir);
            }
            
            maxEntryNo++;
            
            string path = resultSavePath2+"/Line_Fitting-FE"+to_string(maxEntryNo)+".txt";
            
            ofstream oin;
            oin.open(path.c_str(), ios::out | ios::binary);
            
            int *arrayAscIIintData = new int [100], ascIIintDataCount = 0;
            
            ascIIconversion = [[ASCIIconversion alloc] init];
            
            double *arrayFitDataHoldTemp = new double [fitCycleHold*4+100];
            
            for (int counter1 = 0; counter1 < fitCycleHold*4+100; counter1++) arrayFitDataHoldTemp [counter1] = 0;
            
            if (fitModeStatusHold == 0){
                for (int counter1 = 1; counter1 <= fitCycleHold; counter1++){
                    if (fitB1Hold*(counter1) < 43.6){
                        if (fitA1Hold*exp(fitB1Hold*(counter1+1)) < 9223372036854775807){
                            if (limitSimType == 0){
                                arrayFitDataHoldTemp [counter1*4] = fitA1Hold*exp(fitB1Hold*(counter1));
                            }
                            else if (limitSimType == 1){
                                if (fitA1Hold*exp(fitB1Hold*(counter1)) <= fitA1Hold*2){
                                    arrayFitDataHoldTemp [counter1*4] = fitA1Hold*exp(fitB1Hold*(counter1));
                                }
                                else arrayFitDataHoldTemp [counter1*4] = -2;
                            }
                            else if (limitSimType == 2){
                                if (fitA1Hold*exp(fitB1Hold*(counter1)) <= fitA1Hold*10){
                                    arrayFitDataHoldTemp [counter1*4] = fitA1Hold*exp(fitB1Hold*(counter1));
                                }
                                else arrayFitDataHoldTemp [counter1*4] = -2;
                            }
                            else if (limitSimType == 3){
                                if (fitA1Hold*exp(fitB1Hold*(counter1)) <= fitA1Hold*100){
                                    arrayFitDataHoldTemp [counter1*4] = fitA1Hold*exp(fitB1Hold*(counter1));
                                }
                                else arrayFitDataHoldTemp [counter1*4] = -2;
                            }
                        }
                    }
                    
                    if (valueCheck == 2 || valueCheck == 3 || valueCheck == 4){
                        if (fitB2Hold*(counter1) < 43.6){
                            if (fitA2Hold*exp(fitB2Hold*(counter1+1)) < 9223372036854775807){
                                if (limitSimType == 0){
                                    arrayFitDataHoldTemp [counter1*4+1] = fitA2Hold*exp(fitB2Hold*(counter1));
                                }
                                else if (limitSimType == 1){
                                    if (fitA2Hold*exp(fitB2Hold*(counter1)) <= fitA2Hold*2){
                                        arrayFitDataHoldTemp [counter1*4+1] = fitA2Hold*exp(fitB2Hold*(counter1));
                                    }
                                    else arrayFitDataHoldTemp [counter1*4+1] = -2;
                                }
                                else if (limitSimType == 2){
                                    if (fitA2Hold*exp(fitB2Hold*(counter1)) <= fitA2Hold*10){
                                        arrayFitDataHoldTemp [counter1*4+1] = fitA2Hold*exp(fitB2Hold*(counter1));
                                    }
                                    else arrayFitDataHoldTemp [counter1*4+1] = -2;
                                }
                                else if (limitSimType == 3){
                                    if (fitA2Hold*exp(fitB2Hold*(counter1)) <= fitA2Hold*100){
                                        arrayFitDataHoldTemp [counter1*4+1] = fitA2Hold*exp(fitB2Hold*(counter1));
                                    }
                                    else arrayFitDataHoldTemp [counter1*4+1] = -2;
                                }
                            }
                        }
                    }
                    
                    if (valueCheck == 3 || valueCheck == 4){
                        if (fitB3Hold*(counter1) < 43.6){
                            if (fitA3Hold*exp(fitB3Hold*(counter1+1)) < 9223372036854775807){
                                if (limitSimType == 0){
                                    arrayFitDataHoldTemp [counter1*4+2] = fitA3Hold*exp(fitB3Hold*(counter1));
                                }
                                else if (limitSimType == 1){
                                    if (fitA3Hold*exp(fitB3Hold*(counter1)) <= fitA3Hold*2){
                                        arrayFitDataHoldTemp [counter1*4+2] = fitA3Hold*exp(fitB3Hold*(counter1));
                                    }
                                    else arrayFitDataHoldTemp [counter1*4+2] = -2;
                                }
                                else if (limitSimType == 2){
                                    if (fitA3Hold*exp(fitB3Hold*(counter1)) <= fitA3Hold*10){
                                        arrayFitDataHoldTemp [counter1*4+2] = fitA3Hold*exp(fitB3Hold*(counter1));
                                    }
                                    else arrayFitDataHoldTemp [counter1*4+2] = -2;
                                }
                                else if (limitSimType == 3){
                                    if (fitA3Hold*exp(fitB3Hold*(counter1)) <= fitA3Hold*100){
                                        arrayFitDataHoldTemp [counter1*4+2] = fitA3Hold*exp(fitB3Hold*(counter1));
                                    }
                                    else arrayFitDataHoldTemp [counter1*4+2] = -2;
                                }
                            }
                        }
                    }
                    
                    if (valueCheck == 4){
                        if (fitB4Hold*(counter1) < 43.6){
                            if (fitA4Hold*exp(fitB4Hold*(counter1+1)) < 9223372036854775807){
                                if (limitSimType == 0){
                                    arrayFitDataHoldTemp [counter1*4+3] = fitA4Hold*exp(fitB4Hold*(counter1));
                                }
                                else if (limitSimType == 1){
                                    if (fitA4Hold*exp(fitB4Hold*(counter1)) <= fitA4Hold*2){
                                        arrayFitDataHoldTemp [counter1*4+3] = fitA4Hold*exp(fitB4Hold*(counter1));
                                    }
                                    else arrayFitDataHoldTemp [counter1*4+3] = -2;
                                }
                                else if (limitSimType == 2){
                                    if (fitA4Hold*exp(fitB4Hold*(counter1)) <= fitA4Hold*10){
                                        arrayFitDataHoldTemp [counter1*4+3] = fitA4Hold*exp(fitB4Hold*(counter1));
                                    }
                                    else arrayFitDataHoldTemp [counter1*4+3] = -2;
                                }
                                else if (limitSimType == 3){
                                    if (fitA4Hold*exp(fitB4Hold*(counter1)) <= fitA4Hold*100){
                                        arrayFitDataHoldTemp [counter1*4+3] = fitA4Hold*exp(fitB4Hold*(counter1));
                                    }
                                    else arrayFitDataHoldTemp [counter1*4+3] = -2;
                                }
                            }
                        }
                    }
                }
            }
            else if (fitModeStatusHold == 1){
                int modeCheck = 0;
                
                if (fitRangeBEndHold > 43 && fitModeStatusHold == 1){
                    modeCheck = 1;
                }
                
                if ((fitTimeStartHold > fitCycleHold || fitCycleHold-fitTimeStartHold < 10) && fitModeStatusHold == 1){
                    modeCheck = 1;
                }
                
                if (modeCheck == 0){
                    double increment = 0;
                    int timeLapsFromStart = 0;
                    
                    for (int counter1 = 1; counter1 <= fitCycleHold; counter1++){
                        if (counter1 > fitTimeStartHold) timeLapsFromStart++;
                        
                        if (fitB1Hold*(counter1) < 43.6){
                            if (fitA1Hold*exp(fitB1Hold*(counter1+1)) < 9223372036854775807){
                                if (counter1 < fitTimeStartHold){
                                    if (limitSimType == 0){
                                        arrayFitDataHoldTemp [counter1*4] = fitA1Hold*exp(fitB1Hold*(counter1));
                                    }
                                    else if (limitSimType == 1){
                                        if (fitA1Hold*exp(fitB1Hold*(counter1)) <= fitA1Hold*2){
                                            arrayFitDataHoldTemp [counter1*4] = fitA1Hold*exp(fitB1Hold*(counter1));
                                        }
                                        else arrayFitDataHoldTemp [counter1*4] = -2;
                                    }
                                    else if (limitSimType == 2){
                                        if (fitA1Hold*exp(fitB1Hold*(counter1)) <= fitA1Hold*10){
                                            arrayFitDataHoldTemp [counter1*4] = fitA1Hold*exp(fitB1Hold*(counter1));
                                        }
                                        else arrayFitDataHoldTemp [counter1*4] = -2;
                                    }
                                    else if (limitSimType == 3){
                                        if (fitA1Hold*exp(fitB1Hold*(counter1)) <= fitA1Hold*100){
                                            arrayFitDataHoldTemp [counter1*4] = fitA1Hold*exp(fitB1Hold*(counter1));
                                        }
                                        else arrayFitDataHoldTemp [counter1*4] = -2;
                                    }
                                }
                                else{
                                    
                                    increment = (fitRangeBEndHold-fitB1Hold)/(double(fitCycleHold-fitTimeStartHold-1));
                                    
                                    if (limitSimType == 0){
                                        arrayFitDataHoldTemp [counter1*4] = fitA1Hold*exp((fitB1Hold+increment*timeLapsFromStart)*(counter1));
                                    }
                                    else if (limitSimType == 1){
                                        if (fitA1Hold*exp((fitB1Hold+increment*timeLapsFromStart)*(counter1)) <= fitA1Hold*2){
                                            arrayFitDataHoldTemp [counter1*4] = fitA1Hold*exp((fitB1Hold+increment*timeLapsFromStart)*(counter1));
                                        }
                                        else arrayFitDataHoldTemp [counter1*4] = -2;
                                    }
                                    else if (limitSimType == 2){
                                        if (fitA1Hold*exp((fitB1Hold+increment*timeLapsFromStart)*(counter1)) <= fitA1Hold*10){
                                            arrayFitDataHoldTemp [counter1*4] = fitA1Hold*exp((fitB1Hold+increment*timeLapsFromStart)*(counter1));
                                        }
                                        else arrayFitDataHoldTemp [counter1*4] = -2;
                                    }
                                    else if (limitSimType == 3){
                                        if (fitA1Hold*exp((fitB1Hold+increment*timeLapsFromStart)*(counter1)) <= fitA1Hold*100){
                                            arrayFitDataHoldTemp [counter1*4] = fitA1Hold*exp((fitB1Hold+increment*timeLapsFromStart)*(counter1));
                                        }
                                        else arrayFitDataHoldTemp [counter1*4] = -2;
                                    }
                                }
                            }
                        }
                        
                        if (valueCheck == 2 || valueCheck == 3 || valueCheck == 4){
                            if (fitB2Hold*(counter1) < 43.6){
                                if (fitA2Hold*exp(fitB2Hold*(counter1+1)) < 9223372036854775807){
                                    if (limitSimType == 0){
                                        arrayFitDataHoldTemp [counter1*4+1] = fitA2Hold*exp(fitB2Hold*(counter1));
                                    }
                                    else if (limitSimType == 1){
                                        if (fitA2Hold*exp(fitB2Hold*(counter1)) <= fitA2Hold*2){
                                            arrayFitDataHoldTemp [counter1*4+1] = fitA2Hold*exp(fitB2Hold*(counter1));
                                        }
                                        else arrayFitDataHoldTemp [counter1*4+1] = -2;
                                    }
                                    else if (limitSimType == 2){
                                        if (fitA2Hold*exp(fitB2Hold*(counter1)) <= fitA2Hold*10){
                                            arrayFitDataHoldTemp [counter1*4+1] = fitA2Hold*exp(fitB2Hold*(counter1));
                                        }
                                        else arrayFitDataHoldTemp [counter1*4+1] = -2;
                                    }
                                    else if (limitSimType == 3){
                                        if (fitA2Hold*exp(fitB2Hold*(counter1)) <= fitA2Hold*100){
                                            arrayFitDataHoldTemp [counter1*4+1] = fitA2Hold*exp(fitB2Hold*(counter1));
                                        }
                                        else arrayFitDataHoldTemp [counter1*4+1] = -2;
                                    }
                                }
                            }
                        }
                        
                        if (valueCheck == 3 || valueCheck == 4){
                            if (fitB3Hold*(counter1) < 43.6){
                                if (fitA3Hold*exp(fitB3Hold*(counter1+1)) < 9223372036854775807){
                                    if (limitSimType == 0){
                                        arrayFitDataHoldTemp [counter1*4+2] = fitA3Hold*exp(fitB3Hold*(counter1));
                                    }
                                    else if (limitSimType == 1){
                                        if (fitA3Hold*exp(fitB3Hold*(counter1)) <= fitA3Hold*2){
                                            arrayFitDataHoldTemp [counter1*4+2] = fitA3Hold*exp(fitB3Hold*(counter1));
                                        }
                                        else arrayFitDataHoldTemp [counter1*4+2] = -2;
                                    }
                                    else if (limitSimType == 2){
                                        if (fitA3Hold*exp(fitB3Hold*(counter1)) <= fitA3Hold*10){
                                            arrayFitDataHoldTemp [counter1*4+2] = fitA3Hold*exp(fitB3Hold*(counter1));
                                        }
                                        else arrayFitDataHoldTemp [counter1*4+2] = -2;
                                    }
                                    else if (limitSimType == 3){
                                        if (fitA3Hold*exp(fitB3Hold*(counter1)) <= fitA3Hold*100){
                                            arrayFitDataHoldTemp [counter1*4+2] = fitA3Hold*exp(fitB3Hold*(counter1));
                                        }
                                        else arrayFitDataHoldTemp [counter1*4+2] = -2;
                                    }
                                }
                            }
                        }
                        
                        if (valueCheck == 4){
                            if (fitB4Hold*(counter1) < 43.6){
                                if (fitA4Hold*exp(fitB4Hold*(counter1+1)) < 9223372036854775807){
                                    if (limitSimType == 0){
                                        arrayFitDataHoldTemp [counter1*4+3] = fitA4Hold*exp(fitB4Hold*(counter1));
                                    }
                                    else if (limitSimType == 1){
                                        if (fitA4Hold*exp(fitB4Hold*(counter1)) <= fitA4Hold*2){
                                            arrayFitDataHoldTemp [counter1*4+3] = fitA4Hold*exp(fitB4Hold*(counter1));
                                        }
                                        else arrayFitDataHoldTemp [counter1*4+3] = -2;
                                    }
                                    else if (limitSimType == 2){
                                        if (fitA4Hold*exp(fitB4Hold*(counter1)) <= fitA4Hold*10){
                                            arrayFitDataHoldTemp [counter1*4+3] = fitA4Hold*exp(fitB4Hold*(counter1));
                                        }
                                        else arrayFitDataHoldTemp [counter1*4+3] = -2;
                                    }
                                    else if (limitSimType == 3){
                                        if (fitA4Hold*exp(fitB4Hold*(counter1)) <= fitA4Hold*100){
                                            arrayFitDataHoldTemp [counter1*4+3] = fitA4Hold*exp(fitB4Hold*(counter1));
                                        }
                                        else arrayFitDataHoldTemp [counter1*4+3] = -2;
                                    }
                                }
                            }
                        }
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Check b End/Time"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            
            ascIIstring = "Fitting parameters";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            oin.put(13);
            oin.put(10);
            
            ascIIstring = "Equitation 1";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string (fitA1Hold);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string (fitB1Hold);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            oin.put(13);
            oin.put(10);
            
            ascIIstring = "Equitation 2";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string (fitA2Hold);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string (fitB2Hold);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            oin.put(13);
            oin.put(10);
            
            ascIIstring = "Equitation 3";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string (fitA3Hold);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string (fitB3Hold);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            oin.put(13);
            oin.put(10);
            
            ascIIstring = "Equitation 4";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string (fitA4Hold);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string (fitB4Hold);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            oin.put(13);
            oin.put(10);
            
            ascIIstring = "Cycle";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string (fitCycleHold);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            oin.put(13);
            oin.put(10);
            
            ascIIstring = "Progressive";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string (fitRangeBEndHold);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            oin.put(13);
            oin.put(10);
            
            ascIIstring = "Start Time";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string (fitTimeStartHold);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            oin.put(13);
            oin.put(10);
            
            oin.put(13);
            oin.put(10);
            
            ascIIstring = "Equitation 1";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = "Equitation 2";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = "Equitation 3";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = "Equitation 4";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            oin.put(13);
            oin.put(10);
            
            for (int counter3 = 0; counter3 < fitCycleHold; counter3++){
                if (arrayFitDataHoldTemp [counter3*4] != -2){
                    ascIIstring = to_string(arrayFitDataHoldTemp [counter3*4]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                }
                
                oin.put(9);
                
                if (arrayFitDataHoldTemp [counter3*4+1] != -2){
                    ascIIstring = to_string(arrayFitDataHoldTemp [counter3*4+1]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                }
                
                oin.put(9);
                
                if (arrayFitDataHoldTemp [counter3*4+2] != -2){
                    ascIIstring = to_string(arrayFitDataHoldTemp [counter3*4+2]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                }
                
                oin.put(9);
                
                if (arrayFitDataHoldTemp [counter3*4+3] != -2){
                    ascIIstring = to_string(arrayFitDataHoldTemp [counter3*4+3]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                }
                
                oin.put(9);
                
                oin.put(13);
                oin.put(10);
            }
            
            oin.close();
            
            delete [] arrayAscIIintData;
            delete [] arrayFitDataHoldTemp;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Check a And b"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Check Cycle"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)colorBDSet:(id)sender{
    simColorDataHold [0] = colorNoSimHold;
    [[colorButtonVideo1 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorTDSet:(id)sender{
    simColorDataHold [2] = colorNoSimHold;
    [[colorButtonVideo2 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorBDCFSet:(id)sender{
    simColorDataHold [4] = colorNoSimHold;
    [[colorButtonVideo3 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorBDCFBDSet:(id)sender{
    simColorDataHold [6] = colorNoSimHold;
    [[colorButtonVideo4 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorBDCFTDSet:(id)sender{
    simColorDataHold [8] = colorNoSimHold;
    [[colorButtonVideo5 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorTDCFSet:(id)sender{
    simColorDataHold [10] = colorNoSimHold;
    [[colorButtonVideo6 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorTDCFBDSet:(id)sender{
    simColorDataHold [12] = colorNoSimHold;
    [[colorButtonVideo7 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorTDCFTDSet:(id)sender{
    simColorDataHold [14] = colorNoSimHold;
    [[colorButtonVideo8 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorTDBDSet:(id)sender{
    simColorDataHold [16] = colorNoSimHold;
    [[colorButtonVideo9 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorTDTDSet:(id)sender{
    simColorDataHold [18] = colorNoSimHold;
    [[colorButtonVideo10 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)colorNonDivSet:(id)sender{
    simColorDataHold [20] = colorNoSimHold;
    [[colorButtonVideo11 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)drawBDSet:(id)sender{
    simColorDataHold [1] = colorNoSimHold;
    [[colorButtonGraph1 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)drawTDSet:(id)sender{
    simColorDataHold [3] = colorNoSimHold;
    [[colorButtonGraph2 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)drawBDCFSet:(id)sender{
    simColorDataHold [5] = colorNoSimHold;
    [[colorButtonGraph3 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)drawBDCFBDSet:(id)sender{
    simColorDataHold [7] = colorNoSimHold;
    [[colorButtonGraph4 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)drawBDCFTDSet:(id)sender{
    simColorDataHold [9] = colorNoSimHold;
    [[colorButtonGraph5 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)drawTDCFSet:(id)sender{
    simColorDataHold [11] = colorNoSimHold;
    [[colorButtonGraph6 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)drawTDCFBDSet:(id)sender{
    simColorDataHold [13] = colorNoSimHold;
    [[colorButtonGraph7 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)drawTDCFTDSet:(id)sender{
    simColorDataHold [15] = colorNoSimHold;
    [[colorButtonGraph8 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)drawTDBDSet:(id)sender{
    simColorDataHold [17] = colorNoSimHold;
    [[colorButtonGraph9 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)drawTDTDSet:(id)sender{
    simColorDataHold [19] = colorNoSimHold;
    [[colorButtonGraph10 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)drawNonDivSet:(id)sender{
    simColorDataHold [21] = colorNoSimHold;
    [[colorButtonGraph11 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)color1Set:(id)sender{
    [[colorButton cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [0] green:arrayColorRange2 [1] blue:arrayColorRange2 [2] alpha:1]];
    colorNoSimHold = 0;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)color2Set:(id)sender{
    [[colorButton cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [3] green:arrayColorRange2 [4] blue:arrayColorRange2 [5] alpha:1]];
    colorNoSimHold = 1;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)color3Set:(id)sender{
    [[colorButton cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [6] green:arrayColorRange2 [7] blue:arrayColorRange2 [8] alpha:1]];
    colorNoSimHold = 2;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)color4Set:(id)sender{
    [[colorButton cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [9] green:arrayColorRange2 [10] blue:arrayColorRange2 [11] alpha:1]];
    colorNoSimHold = 3;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)color5Set:(id)sender{
    [[colorButton cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [12] green:arrayColorRange2 [13] blue:arrayColorRange2 [14] alpha:1]];
    colorNoSimHold = 4;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)color6Set:(id)sender{
    [[colorButton cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [15] green:arrayColorRange2 [16] blue:arrayColorRange2 [17] alpha:1]];
    colorNoSimHold = 5;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)color7Set:(id)sender{
    [[colorButton cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [18] green:arrayColorRange2 [19] blue:arrayColorRange2 [20] alpha:1]];
    colorNoSimHold = 6;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)color8Set:(id)sender{
    [[colorButton cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [21] green:arrayColorRange2 [22] blue:arrayColorRange2 [23] alpha:1]];
    colorNoSimHold = 7;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)color9Set:(id)sender{
    [[colorButton cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [24] green:arrayColorRange2 [25] blue:arrayColorRange2 [26] alpha:1]];
    colorNoSimHold = 8;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)color10Set:(id)sender{
    [[colorButton cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [27] green:arrayColorRange2 [28] blue:arrayColorRange2 [29] alpha:1]];
    colorNoSimHold = 9;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)color11Set:(id)sender{
    [[colorButton cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [30] green:arrayColorRange2 [31] blue:arrayColorRange2 [32] alpha:1]];
    colorNoSimHold = 10;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)color12Set:(id)sender{
    [[colorButton cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [33] green:arrayColorRange2 [34] blue:arrayColorRange2 [35] alpha:1]];
    colorNoSimHold = 11;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)color13Set:(id)sender{
    [[colorButton cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [36] green:arrayColorRange2 [37] blue:arrayColorRange2 [38] alpha:1]];
    colorNoSimHold = 12;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)color14Set:(id)sender{
    [[colorButton cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [39] green:arrayColorRange2 [40] blue:arrayColorRange2 [41] alpha:1]];
    colorNoSimHold = 13;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)color15Set:(id)sender{
    [[colorButton cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [42] green:arrayColorRange2 [43] blue:arrayColorRange2 [44] alpha:1]];
    colorNoSimHold = 14;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)color16Set:(id)sender{
    [[colorButton cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [45] green:arrayColorRange2 [46] blue:arrayColorRange2 [47] alpha:1]];
    colorNoSimHold = 15;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)growthInitModeSet:(id)sender{
    if (simStartModeHold == 0){
        simStartModeHold = 1;
        [startDisplay setStringValue:@"Synchro."];
    }
    else if (simStartModeHold == 1){
        simStartModeHold = 0;
        [startDisplay setStringValue:@"Random"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)recoveryPercentSet:(id)sender{
    if (simulationProgress == 0){
        if (recoveryCalculationPercentHold == 20){
            recoveryCalculationPercentHold = 30;
            [recoveryPercDisplay setIntegerValue:30];
        }
        else if (recoveryCalculationPercentHold == 30){
            recoveryCalculationPercentHold = 10;
            [recoveryPercDisplay setIntegerValue:10];
        }
        else if (recoveryCalculationPercentHold == 10){
            recoveryCalculationPercentHold = 20;
            [recoveryPercDisplay setIntegerValue:20];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Sim Running"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)dataExportSet:(id)sender{
    if (performDataStatus == 1){
        string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
        mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Simulation";
        mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        DIR *dir;
        struct dirent *dent;
        
        string entry;
        string extractString;
        int maxEntryNo = 0;
        
        dir = opendir(resultSavePath2.c_str());
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                    extractString = entry.substr(entry.find("SL")+2, entry.find(".txt")-entry.find("SL")-2);
                    
                    if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                }
            }
            
            closedir(dir);
        }
        
        maxEntryNo++;
        
        string path = resultSavePath2+"/Simulation-SL"+to_string(maxEntryNo)+".txt";
        
        ofstream oin;
        oin.open(path.c_str(), ios::out | ios::binary);
        
        int *arrayAscIIintData = new int [100], ascIIintDataCount = 0;
        
        ascIIconversion = [[ASCIIconversion alloc] init];
        
        if (simGraphModeHold == 0){
            ascIIstring = "Growth simulation";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            oin.put(13);
            oin.put(10);
            
            ascIIstring = "Total and No of Progeny produced by a type of event";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            oin.put(13);
            oin.put(10);
            
            oin.put(13);
            oin.put(10);
            
            ascIIstring = "Time";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = "Total";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = "BD";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = "TD";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = "BD-CF";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = "BD-CF-BD";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = "BD-CF-TD";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = "TD-CF";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = "TD-CF-BD";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = "TD-CF-TD";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = "TD-BD";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = "TD-TD";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = "Non Div";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            oin.put(13);
            oin.put(10);
            
            oin.put(13);
            oin.put(10);
            
            //for (int counterA = 0; counterA < timeEnd; counterA++){
            //    for (int counterB = 0; counterB < 12; counterB++) cout<<" "<<cellGrowthCount [counterA*12+counterB];
            //    cout<<" cellGrowthCount "<<counterA<<endl;
            //}
            
            for (int counter3 = 1; counter3 <= cellGrowthCountTimeEnd; counter3++){
                ascIIstring = to_string(counter3);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                
                oin.put(9);
                
                ascIIstring = to_string(cellGrowthCount [counter3*12]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                
                oin.put(9);
                
                ascIIstring = to_string(cellGrowthCount [counter3*12+1]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                
                oin.put(9);
                
                ascIIstring = to_string(cellGrowthCount [counter3*12+2]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                
                oin.put(9);
                
                ascIIstring = to_string(cellGrowthCount [counter3*12+3]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                
                oin.put(9);
                
                ascIIstring = to_string(cellGrowthCount [counter3*12+4]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                
                oin.put(9);
                
                ascIIstring = to_string(cellGrowthCount [counter3*12+5]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                
                oin.put(9);
                
                ascIIstring = to_string(cellGrowthCount [counter3*12+6]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                
                oin.put(9);
                
                ascIIstring = to_string(cellGrowthCount [counter3*12+7]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                
                oin.put(9);
                
                ascIIstring = to_string(cellGrowthCount [counter3*12+8]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                
                oin.put(9);
                
                ascIIstring = to_string(cellGrowthCount [counter3*12+9]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                
                oin.put(9);
                
                ascIIstring = to_string(cellGrowthCount [counter3*12+10]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                
                oin.put(9);
                
                ascIIstring = to_string(cellGrowthCount [counter3*12+11]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                
                oin.put(9);
                
                oin.put(13);
                oin.put(10);
            }
        }
        else{
            
            int lineagePositionNo = simOperationTableCurrentRow;
            
            int *cellNoList = new int [cellGrowthCountTimeEnd*2+10];
            
            for (int counter2 = 0; counter2 < cellGrowthCountTimeEnd*2+10; counter2++) cellNoList [counter2] = 0;
            
            int findFlag = 0;
            
            for (unsigned long counter2 = 0; counter2 < arrayLineageDataEntryHold [lineagePositionNo]/9; counter2++){
                findFlag = 0;
                
                for (int counter3 = 0; counter3 < cellNoListForSelectLingCount; counter3++){
                    if (cellNoListForSelectLing [counter3] == arrayLineageData [lineagePositionNo][counter2*9+6]){
                        findFlag = 1;
                        break;
                    }
                }
                
                if (findFlag == 1){
                    cellNoList [arrayLineageData [lineagePositionNo][counter2*9+2]*2+1]++;
                }
                else{
                    
                    cellNoList [arrayLineageData [lineagePositionNo][counter2*9+2]*2]++;
                }
            }
            
            ascIIstring = "Growth simulation";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            oin.put(13);
            oin.put(10);
            
            ascIIstring = "Growth of selected lineages";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            oin.put(13);
            oin.put(10);
            
            oin.put(13);
            oin.put(10);
            
            ascIIstring = "Time";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = "Base cell lineages";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = "Selected cell lineages";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(13);
            oin.put(10);
            
            oin.put(13);
            oin.put(10);
            
            for (int counter2 = 1; counter2 <= cellGrowthCountTimeEnd; counter2++){
                ascIIstring = to_string(counter2);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                
                oin.put(9);
                
                ascIIstring = to_string(cellNoList [counter2*2]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                
                oin.put(9);
                
                ascIIstring = to_string(cellNoList [counter2*2+1]);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                
                oin.put(9);
                
                oin.put(13);
                oin.put(10);
            }
            
            delete [] cellNoList;
        }
        
        oin.close();
        
        delete [] arrayAscIIintData;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Perform Reload To Set Export Data"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)parameterExportSet:(id)sender{
    string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
    mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
    
    string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Simulation";
    mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
    
    DIR *dir;
    struct dirent *dent;
    
    string entry;
    string extractString;
    int maxEntryNo = 0;
    
    dir = opendir(resultSavePath2.c_str());
    
    if (dir != NULL){
        while ((dent = readdir(dir))){
            entry = dent -> d_name;
            
            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                extractString = entry.substr(entry.find("SP")+2, entry.find(".txt")-entry.find("SP")-2);
                
                if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
            }
        }
        
        closedir(dir);
    }
    
    maxEntryNo++;
    
    string path = resultSavePath2+"/Simulation_Parameters-SP"+to_string(maxEntryNo)+".txt";
    
    ofstream oin;
    oin.open(path.c_str(), ios::out | ios::binary);
    
    int *arrayAscIIintData = new int [100], ascIIintDataCount = 0;
    
    ascIIconversion = [[ASCIIconversion alloc] init];
    
    ascIIstring = messageStringSim;
    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
    
    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
    
    oin.put(9);
    
    ascIIstring = messageStringSim2;
    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
    
    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
    
    oin.put(9);
    
    ascIIstring = messageStringSim3;
    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
    
    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
    
    oin.put(9);
    
    ascIIstring = messageStringSim4;
    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
    
    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
    
    oin.put(9);
    
    oin.put(13);
    oin.put(10);
    
    ascIIstring = "Simulation Time";
    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
    
    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
    
    oin.put(9);
    
    ascIIstring = "Mid start";
    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
    
    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
    
    oin.put(9);
    
    ascIIstring = "Prog Start";
    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
    
    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
    
    oin.put(9);
    
    ascIIstring = "Prog End";
    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
    
    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
    
    oin.put(9);
    
    oin.put(13);
    oin.put(10);
    
    ascIIstring = to_string(growthCycleHold);
    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
    
    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
    
    oin.put(9);
    
    ascIIstring = to_string(growthMidTimeStartHold);
    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
    
    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
    
    oin.put(9);
    
    ascIIstring = to_string(growthProgTimeStartHold);
    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
    
    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
    
    oin.put(9);
    
    ascIIstring = to_string(growthProgTimeEndHold);
    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
    
    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
    
    oin.put(9);
    
    oin.put(13);
    oin.put(10);
    oin.put(13);
    oin.put(10);
    
    ascIIstring = "Category";
    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
    
    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
    
    oin.put(9);
    
    ascIIstring = "Base";
    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
    
    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
    
    oin.put(9);
    
    ascIIstring = "Mid";
    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
    
    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
    
    oin.put(9);
    
    ascIIstring = "Prog";
    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
    
    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
    
    oin.put(9);
    
    oin.put(13);
    oin.put(10);
    
    for (int counter3 = 0; counter3 < 29; counter3++){
        if (counter3 == 0){
            ascIIstring = "Doub Time BD-Bias";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
        }
        else if (counter3 == 1){
            ascIIstring = "Doub Time TD-Bias";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
        }
        else if (counter3 == 2){
            ascIIstring = "Doub Time CF-Bias";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
        }
        else if (counter3 == 3){
            ascIIstring = "BD-Number of event";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
        }
        else if (counter3 == 4){
            ascIIstring = "TD-Number of event";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
        }
        else if (counter3 == 5){
            ascIIstring = "BD-CD-Bias";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
        }
        else if (counter3 == 6){
            ascIIstring = "nonDiv CD";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
        }
        else if (counter3 == 7){
            ascIIstring = "BD-CF-Bias";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
        }
        else if (counter3 == 8){
            ascIIstring = "BD-CF-CD-Number of event";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
        }
        else if (counter3 == 9){
            ascIIstring = "BD-CF-TD-Number of event";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
        }
        else if (counter3 == 10){
            ascIIstring = "BD-CF-CD-Bias";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
        }
        else if (counter3 == 11){
            ascIIstring = "TD-CD-Bias";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
        }
        else if (counter3 == 12){
            ascIIstring = "TD-CF-BD-Number of event";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
        }
        else if (counter3 == 13){
            ascIIstring = "TD-CF-TD-Number of event";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
        }
        else if (counter3 == 14){
            ascIIstring = "TD-CF-CD-Bias";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
        }
        else if (counter3 == 15){
            ascIIstring = "TD-BD-Number of event";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
        }
        else if (counter3 == 16){
            ascIIstring = "TD-TD-Number of event";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
        }
        else if (counter3 == 17){
            ascIIstring = "TD-CD-Bias";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
        }
        else if (counter3 == 18){
            ascIIstring = "MultiTD-TD limit-Cycle";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
        }
        else if (counter3 == 19){
            ascIIstring = "TD-BD sup-Cycle";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
        }
        else if (counter3 == 20){
            ascIIstring = "Non-Div-Number of Ling";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
        }
        else if (counter3 == 21){
            ascIIstring = "Recovery";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
        }
        else if (counter3 == 22){
            ascIIstring = "Recovery Percent";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
        }
        else if (counter3 == 23){
            ascIIstring = "Total no of Div";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
        }
        else if (counter3 == 24){
            ascIIstring = "Number of Ling";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
        }
        else if (counter3 == 25){
            ascIIstring = "End-Time point";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
        }
        else if (counter3 == 26){
            ascIIstring = "BD Rand";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
        }
        else if (counter3 == 27){
            ascIIstring = "CD Rand";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
        }
        else if (counter3 == 28){
            ascIIstring = "Fluorescent IF";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
        }
        
        if (counter3 != 28){
            ascIIstring = to_string(simProcessDataMiddleHold [counter3]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string(simProcessDataProgHold [counter3]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string(simProcessDataAddHold [counter3]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
        }
        else if (counter3 == 28){
            ascIIstring = to_string(simProcessDataBaseHold [counter3]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = "nil";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = "nil";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = "nil";
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
        }
        
        oin.put(13);
        oin.put(10);
    }
    
    oin.close();
    
    delete [] arrayAscIIintData;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)distanceRedSet:(id)sender{
    if (timingSimCount == 0){
        if (movieDistanceRedStatus == 0){
            movieDistanceRedStatus = 1;
            [movieDistanceRedDisplay setStringValue:@"On"];
        }
        else if (movieDistanceRedStatus == 1){
            movieDistanceRedStatus = 0;
            [movieDistanceRedDisplay setStringValue:@"Off"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Video Making On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)circleSizeRedSet:(id)sender{
    if (timingSimCount == 0){
        if (circleSizeRedStatus == 0){
            circleSizeRedStatus = 1;
            [circleReductionDisplay setStringValue:@"On"];
        }
        else if (circleSizeRedStatus == 1){
            circleSizeRedStatus = 0;
            [circleReductionDisplay setStringValue:@"Off"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Video Making On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)colorModeSet:(id)sender{
    if (timingSimCount == 0){
        if (videoColorStatus == 0){
            videoColorStatus = 1;
            [colorOptionDisplay setStringValue:@"Ling."];
        }
        else if (videoColorStatus == 1){
            videoColorStatus = 2;
            [colorOptionDisplay setStringValue:@"Sel Ling"];
        }
        else if (videoColorStatus == 2){
            videoColorStatus = 0;
            [colorOptionDisplay setStringValue:@"Events"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Video Making On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)doseModeSet:(id)sender{
    if (simulationProgress == 0){
        if (doseSimStatusHold == 0){
            doseSimStatusHold = 1;
            [doseModeDisplay setStringValue:@"Dose simulation"];
        }
        else if (doseSimStatusHold == 1){
            doseSimStatusHold = 2;
            [doseModeDisplay setStringValue:@"Mix cul. simulation"];
        }
        else if (doseSimStatusHold == 2){
            doseSimStatusHold = 0;
            [doseModeDisplay setStringValue:@"Standard simulation"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Sim Running"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)lingNoDataExport:(id)sender{
    if (simulationProgress == 0 && lingNoAssignSimCount != 0){
        string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
        mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Simulation";
        mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        DIR *dir;
        struct dirent *dent;
        
        string entry;
        string extractString;
        int maxEntryNo = 0;
        
        dir = opendir(resultSavePath2.c_str());
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                    extractString = entry.substr(entry.find("LA")+2, entry.find(".txt")-entry.find("LA")-2);
                    
                    if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                }
            }
            
            closedir(dir);
        }
        
        maxEntryNo++;
        
        string path = resultSavePath2+"/Simulation-LA"+to_string(maxEntryNo)+".txt";
        
        ofstream oin;
        oin.open(path.c_str(), ios::out | ios::binary);
        
        int *arrayAscIIintData = new int [100], ascIIintDataCount = 0;
        
        ascIIconversion = [[ASCIIconversion alloc] init];
        
        ascIIstring = "Lineage no";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
        
        oin.put(9);
        
        oin.put(13);
        oin.put(10);
        
        oin.put(13);
        oin.put(10);
        
        for (int counter3 = 0; counter3 < lingNoAssignSimCount; counter3++){
            ascIIstring = to_string(counter3);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string(lingNoAssignSim [counter3]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            oin.put(13);
            oin.put(10);
        }
        
        oin.close();
        
        delete [] arrayAscIIintData;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Sim Running/No Ling Data"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)targetDataExport:(id)sender{
    if (simulationProgress == 0){
        if (doseBaseHold >= 0 && doseMiddleHold >= 0 && doseTargetHold > doseBaseHold && doseBaseHold < doseMiddleHold && doseTargetHold < doseMiddleHold && (simProcessDataBaseHold [3] != 0 || simProcessDataBaseHold [4] != 0 || simProcessDataBaseHold [5] != 0 || simProcessDataBaseHold [6] != 0) && (simProcessDataMiddleHold [3] != 0 || simProcessDataMiddleHold [4] != 0 || simProcessDataMiddleHold [5] != 0 || simProcessDataMiddleHold [6] != 0)){
            NSOpenPanel *openDlg = [NSOpenPanel openPanel];
            [openDlg setCanChooseFiles:NO];
            [openDlg setCanChooseDirectories:YES];
            
            if ([openDlg runModal] == NSModalResponseOK){
                NSArray *files = [openDlg URLs];
                NSString *fileName = [[files objectAtIndex:0] absoluteString];
                
                string directoryPathImport = [fileName UTF8String];
                
                int findString1 = (int)directoryPathImport.find("/Users/");
                if (findString1 == -1) findString1 = (int)directoryPathImport.find("/Volumes/");
                
                unsigned long directoryLength = directoryPathImport.length();
                directoryPathImport = directoryPathImport.substr((unsigned long)findString1, directoryLength-(unsigned long)findString1-1);
                string extractedID;
                string extractedID2;
                
                int terminationFlag = 0;
                
                do{
                    
                    terminationFlag = 1;
                    
                    findString1 = (int)directoryPathImport.find("%20");
                    if (findString1 != -1){
                        extractedID2 = directoryPathImport.substr(0, (unsigned long)findString1);
                        directoryPathImport = directoryPathImport.substr((unsigned long)findString1+3);
                        directoryPathImport = extractedID2+" "+directoryPathImport;
                    }
                    else terminationFlag = 0;
                    
                } while (terminationFlag == 1);
                
                directoryPathImport = directoryPathImport+"/SimData";
                
                mkdir(directoryPathImport.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                DIR *dir;
                struct dirent *dent;
                
                string entry;
                string extractString;
                int maxEntryNo = 0;
                
                string doseString = "Dose-"+to_string(doseTargetHold)+"-Mix-"+to_string(doseBaseHold)+"-and-"+to_string(doseMiddleHold);
                
                dir = opendir(directoryPathImport.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find(doseString) != -1){
                            extractString = entry.substr(entry.find("Sim-")+4);
                            
                            if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                        }
                    }
                    
                    closedir(dir);
                }
                
                maxEntryNo++;
                
                string pathName2 = directoryPathImport+"/"+doseString+"_Sim-"+to_string(maxEntryNo)+".txt";
                
                int timeMax = (int)simProcessDataBaseHold [25];
                double duration = 0;
                double targetAdjust = 0;
                
                if (doseMiddleHold-doseBaseHold > 0){
                    duration = doseMiddleHold-doseBaseHold;
                    targetAdjust = doseTargetHold-doseBaseHold;
                }
                else{
                    
                    duration = doseBaseHold-doseMiddleHold;
                    targetAdjust = (doseTargetHold-doseBaseHold)*-1;
                }
                
                ofstream oin;
                
                oin.open(pathName2.c_str(), ios::out | ios::binary);
                
                oin<<"Dose data array"<<endl;
                oin<<1<<endl;
                oin<<1<<endl;
                oin<<1<<endl;
                oin<<simProcessDataBaseHold [3]+((simProcessDataMiddleHold [3]-simProcessDataBaseHold [3])/(double)duration)*(double)targetAdjust<<endl;
                oin<<simProcessDataBaseHold [4]+((simProcessDataMiddleHold [4]-simProcessDataBaseHold [4])/(double)duration)*(double)targetAdjust<<endl;
                oin<<1<<endl;
                oin<<1<<endl;
                oin<<1<<endl;
                oin<<simProcessDataBaseHold [8]+((simProcessDataMiddleHold [8]-simProcessDataBaseHold [8])/(double)duration)*(double)targetAdjust<<endl;
                oin<<simProcessDataBaseHold [9]+((simProcessDataMiddleHold [9]-simProcessDataBaseHold [9])/(double)duration)*(double)targetAdjust<<endl;
                oin<<1<<endl;
                oin<<1<<endl;
                oin<<simProcessDataBaseHold [12]+((simProcessDataMiddleHold [12]-simProcessDataBaseHold [12])/(double)duration)*(double)targetAdjust<<endl;
                oin<<simProcessDataBaseHold [13]+((simProcessDataMiddleHold [13]-simProcessDataBaseHold [13])/(double)duration)*(double)targetAdjust<<endl;
                oin<<1<<endl;
                oin<<simProcessDataBaseHold [15]+((simProcessDataMiddleHold [15]-simProcessDataBaseHold [15])/(double)duration)*(double)targetAdjust<<endl;
                oin<<simProcessDataBaseHold [16]+((simProcessDataMiddleHold [16]-simProcessDataBaseHold [16])/(double)duration)*(double)targetAdjust<<endl;
                oin<<1<<endl;
                oin<<2<<endl;
                oin<<3<<endl;
                oin<<round(simProcessDataBaseHold [20]+((simProcessDataMiddleHold [20]-simProcessDataBaseHold [20])/(double)duration)*(double)targetAdjust)<<endl;
                oin<<simProcessDataBaseHold [21]+(((simProcessDataMiddleHold [21]-simProcessDataBaseHold [21])/(double)duration)*(double)targetAdjust)<<endl;
                oin<<simProcessDataBaseHold [22]<<endl;
                oin<<round(simProcessDataBaseHold [23]+(((simProcessDataMiddleHold [23]-simProcessDataBaseHold [23])/(double)duration)*(double)targetAdjust))<<endl;
                
                oin<<round(simProcessDataBaseHold [24]+(((simProcessDataMiddleHold [24]-simProcessDataBaseHold [24])/(double)duration)*(double)targetAdjust))<<endl;
                oin<<simProcessDataBaseHold [25]<<endl;
                oin<<simProcessDataBaseHold [26]+((simProcessDataMiddleHold [26]-simProcessDataBaseHold [26])/(double)duration)*(double)targetAdjust<<endl;
                oin<<simProcessDataBaseHold [27]+((simProcessDataMiddleHold [27]-simProcessDataBaseHold [27])/(double)duration)*(double)targetAdjust<<endl;
                
                oin<<"A1"<<endl;
                
                for (int counter1 = 0; counter1 < timeMax; counter1++){
                    oin<<simulationDistributionData [counter1*11]+(int)(round(((simulationDistributionMidData [counter1*11]-simulationDistributionData [counter1*11])/(double)duration)*(double)targetAdjust))<<endl;
                }
                
                oin<<"End"<<endl;
                
                oin<<"A2"<<endl;
                
                for (int counter1 = 0; counter1 < timeMax; counter1++){
                    oin<<simulationDistributionData [counter1*11+1]+(int)(round(((simulationDistributionMidData [counter1*11+1]-simulationDistributionData [counter1*11+1])/(double)duration)*(double)targetAdjust))<<endl;
                }
                
                oin<<"End"<<endl;
                
                oin<<"A3"<<endl;
                
                for (int counter1 = 0; counter1 < timeMax; counter1++){
                    oin<<simulationDistributionData [counter1*11+2]+(int)(round(((simulationDistributionMidData [counter1*11+2]-simulationDistributionData [counter1*11+2])/(double)duration)*(double)targetAdjust))<<endl;
                }
                
                oin<<"End"<<endl;
                
                oin<<"A4"<<endl;
                
                for (int counter1 = 0; counter1 < timeMax; counter1++){
                    oin<<simulationDistributionData [counter1*11+3]+(int)(round(((simulationDistributionMidData [counter1*11+3]-simulationDistributionData [counter1*11+3])/(double)duration)*(double)targetAdjust))<<endl;
                }
                
                oin<<"End"<<endl;
                
                oin<<"A5"<<endl;
                
                for (int counter1 = 0; counter1 < timeMax; counter1++){
                    oin<<simulationDistributionData [counter1*11+4]+(int)(round(((simulationDistributionMidData [counter1*11+4]-simulationDistributionData [counter1*11+4])/(double)duration)*(double)targetAdjust))<<endl;
                }
                
                oin<<"End"<<endl;
                
                oin<<"A6"<<endl;
                
                for (int counter1 = 0; counter1 < timeMax; counter1++){
                    oin<<simulationDistributionData [counter1*11+5]+(int)(round(((simulationDistributionMidData [counter1*11+5]-simulationDistributionData [counter1*11+5])/(double)duration)*(double)targetAdjust))<<endl;
                }
                
                oin<<"End"<<endl;
                
                oin<<"A7"<<endl;
                
                for (int counter1 = 0; counter1 < timeMax; counter1++){
                    oin<<simulationDistributionData [counter1*11+6]+(int)(round(((simulationDistributionMidData [counter1*11+6]-simulationDistributionData [counter1*11+6])/(double)duration)*(double)targetAdjust))<<endl;
                }
                
                oin<<"End"<<endl;
                
                oin<<"A8"<<endl;
                
                for (int counter1 = 0; counter1 < timeMax; counter1++){
                    oin<<simulationDistributionData [counter1*11+7]+(int)(round(((simulationDistributionMidData [counter1*11+7]-simulationDistributionData [counter1*11+7])/(double)duration)*(double)targetAdjust))<<endl;
                }
                
                oin<<"End"<<endl;
                
                oin<<"A9"<<endl;
                
                for (int counter1 = 0; counter1 < timeMax; counter1++){
                    oin<<simulationDistributionData [counter1*11+8]+(int)(round(((simulationDistributionMidData [counter1*11+8]-simulationDistributionData [counter1*11+8])/(double)duration)*(double)targetAdjust))<<endl;
                }
                
                oin<<"End"<<endl;
                
                oin<<"A10"<<endl;
                
                for (int counter1 = 0; counter1 < timeMax; counter1++){
                    oin<<simulationDistributionData [counter1*11+9]+(int)(round(((simulationDistributionMidData [counter1*11+9]-simulationDistributionData [counter1*11+9])/(double)duration)*(double)targetAdjust))<<endl;
                }
                
                oin<<"End"<<endl;
                
                oin<<"A11"<<endl;
                
                for (int counter1 = 0; counter1 < timeMax; counter1++){
                    oin<<simulationDistributionData [counter1*11+10]+(int)(round(((simulationDistributionMidData [counter1*11+10]-simulationDistributionData [counter1*11+10])/(double)duration)*(double)targetAdjust))<<endl;
                }
                
                oin.close();
            }
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Data Not Set"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Sim Running"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)databaseLoadOption:(id)sender{
    if (simulationProgress == 0){
        if (databaseLoadOptionHold == 0){
            databaseLoadOptionHold = 1;
            [dataBaseOptionDisplay setStringValue:@"File"];
        }
        else if (databaseLoadOptionHold == 1){
            databaseLoadOptionHold = 0;
            [dataBaseOptionDisplay setStringValue:@"Table"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Sim Running"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)graphColorOption:(id)sender{
    if (simulationProgress == 0){
        if (simGraphModeHold == 0){
            simGraphModeHold = 1;
            [graphColorTypeDisplay setStringValue:@"Sel Ling"];
        }
        else if (simGraphModeHold == 1){
            simGraphModeHold = 0;
            [graphColorTypeDisplay setStringValue:@"Events"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Sim Running"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)titleFontSet:(id)sender{
    if (titleFontExport == 1){
        titleFontExport = 2;
        [titleFontDisplay setStringValue:@"18 F"];
    }
    else if (titleFontExport == 2){
        titleFontExport = 3;
        [titleFontDisplay setStringValue:@"24 F"];
    }
    else if (titleFontExport== 3){
        titleFontExport = 4;
        [titleFontDisplay setStringValue:@"30 F"];
    }
    else if (titleFontExport == 4){
        titleFontExport = 5;
        [titleFontDisplay setStringValue:@"40 F"];
    }
    else if (titleFontExport == 5){
        titleFontExport = 6;
        [titleFontDisplay setStringValue:@"50 F"];
    }
    else if (titleFontExport == 6){
        titleFontExport = 7;
        [titleFontDisplay setStringValue:@"60 F"];
    }
    else if (titleFontExport == 7){
        titleFontExport = 8;
        [titleFontDisplay setStringValue:@"80 F"];
    }
    else if (titleFontExport == 8){
        titleFontExport = 9;
        [titleFontDisplay setStringValue:@"0 F"];
    }
    else if (titleFontExport == 9){
        titleFontExport = 10;
        [titleFontDisplay setStringValue:@"6 F"];
    }
    else if (titleFontExport == 10){
        titleFontExport = 11;
        [titleFontDisplay setStringValue:@"8 F"];
    }
    else if (titleFontExport == 11){
        titleFontExport = 1;
        [titleFontDisplay setStringValue:@"12 F"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)imageSizeOption:(id)sender{
    if (simulationProgress == 0){
        if (videoImageSizeOptionHold == 0){
            videoImageSizeOptionHold = 1;
            [videoImageSizeOptionDisplay setStringValue:@"Manual"];
        }
        else if (videoImageSizeOptionHold == 1){
            videoImageSizeOptionHold = 0;
            [videoImageSizeOptionDisplay setStringValue:@"Auto"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Sim Running"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)mixedLingNoGet:(id)sender{
    if (simulationProgress == 0){
        int mixedCellCount = 0;
        
        for (unsigned long counter2 = 0; counter2 < arrayLineageDataEntryHold [simOperationTableCurrentRow]/9; counter2++){
            if (arrayLineageData [simOperationTableCurrentRow][counter2*9] == 20 && arrayLineageData [simOperationTableCurrentRow][counter2*9+1] == 20 && arrayLineageData [simOperationTableCurrentRow][counter2*9+3] == 1) mixedCellCount++;
        }
        
        if (mixedCellCount != 0){
            if (lingNoAssignSimStatus == 1) delete [] lingNoAssignSim;
            lingNoAssignSim = new int [mixedCellCount+10];
            lingNoAssignSimCount = 0;
            lingNoAssignSimStatus = 1;
            
            for (unsigned long counter2 = 0; counter2 < arrayLineageDataEntryHold [simOperationTableCurrentRow]/9; counter2++){
                if (arrayLineageData [simOperationTableCurrentRow][counter2*9] == 20 && arrayLineageData [simOperationTableCurrentRow][counter2*9+1] == 20 && arrayLineageData [simOperationTableCurrentRow][counter2*9+3] == 1) lingNoAssignSim [lingNoAssignSimCount] = arrayLineageData [simOperationTableCurrentRow][counter2*9+6], lingNoAssignSimCount++;
            }
            
            messageLingSim = "1: nil";
            messageLingSim2 = "2: nil";
            messageLingSim3 = "3: nil";
            messageLingSim4 = "4: nil";
            messageLingSim5 = "5: nil";
            messageLingSim6 = "6: nil";
            messageLingSim7 = "7: nil";
            messageLingSim8 = "8: nil";
            
            if (lingNoAssignSimCount >= 1) messageLingSim = "1: L"+to_string(lingNoAssignSim [0]);
            if (lingNoAssignSimCount >= 2) messageLingSim2 = "2: L"+to_string(lingNoAssignSim [1]);
            if (lingNoAssignSimCount >= 3) messageLingSim3 = "3: L"+to_string(lingNoAssignSim [2]);
            if (lingNoAssignSimCount >= 4) messageLingSim4 = "4: L"+to_string(lingNoAssignSim [3]);
            if (lingNoAssignSimCount >= 5) messageLingSim5 = "5: L"+to_string(lingNoAssignSim [4]);
            if (lingNoAssignSimCount >= 6) messageLingSim6 = "6: L"+to_string(lingNoAssignSim [5]);
            if (lingNoAssignSimCount >= 7) messageLingSim7 = "7: L"+to_string(lingNoAssignSim [6]);
            if (lingNoAssignSimCount >= 8) messageLingSim8 = "8: L"+to_string(lingNoAssignSim [7]);
            
            lingSetDisplayCall = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Mixed Cells Found"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Sim Running"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)colorToneChangeSet:(id)sender{
    if (simulationProgress == 0){
        if (colorToneChangeOptionHold == 0){
            colorToneChangeOptionHold = 1;
            [colorToneOptionDisplay setStringValue:@"+20"];
        }
        else if (colorToneChangeOptionHold == 1){
            colorToneChangeOptionHold = 2;
            [colorToneOptionDisplay setStringValue:@"+40"];
        }
        else if (colorToneChangeOptionHold == 2){
            colorToneChangeOptionHold = 3;
            [colorToneOptionDisplay setStringValue:@"-20"];
        }
        else if (colorToneChangeOptionHold == 3){
            colorToneChangeOptionHold = 4;
            [colorToneOptionDisplay setStringValue:@"-40"];
        }
        else if (colorToneChangeOptionHold == 4){
            colorToneChangeOptionHold = 0;
            [colorToneOptionDisplay setStringValue:@"Off"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Sim Running"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)fluorescentSimulationSet:(id)sender{
    if (simulationProgress == 0){
        if (fluorescentSimSetNo == 0){
            fluorescentSimSetNo = 1;
            [fluorescentOptionDisplay setStringValue:@"L1"];
        }
        else if (fluorescentSimSetNo == 1){
            fluorescentSimSetNo = 2;
            [fluorescentOptionDisplay setStringValue:@"L2"];
        }
        else if (fluorescentSimSetNo == 2){
            fluorescentSimSetNo = 3;
            [fluorescentOptionDisplay setStringValue:@"L3"];
        }
        else if (fluorescentSimSetNo == 3){
            fluorescentSimSetNo = 4;
            [fluorescentOptionDisplay setStringValue:@"L4"];
        }
        else if (fluorescentSimSetNo == 4){
            fluorescentSimSetNo = 5;
            [fluorescentOptionDisplay setStringValue:@"L5"];
        }
        else if (fluorescentSimSetNo == 5){
            fluorescentSimSetNo = 6;
            [fluorescentOptionDisplay setStringValue:@"L6"];
        }
        else if (fluorescentSimSetNo == 6){
            fluorescentSimSetNo = 7;
            [fluorescentOptionDisplay setStringValue:@"I7"];
        }
        else if (fluorescentSimSetNo == 7){
            fluorescentSimSetNo = 8;
            [fluorescentOptionDisplay setStringValue:@"I8"];
        }
        else if (fluorescentSimSetNo == 8){
            fluorescentSimSetNo = 9;
            [fluorescentOptionDisplay setStringValue:@"I9"];
        }
        else if (fluorescentSimSetNo == 9){
            fluorescentSimSetNo = 10;
            [fluorescentOptionDisplay setStringValue:@"I10"];
        }
        else if (fluorescentSimSetNo == 10){
            fluorescentSimSetNo = 11;
            [fluorescentOptionDisplay setStringValue:@"I11"];
        }
        else if (fluorescentSimSetNo == 11){
            fluorescentSimSetNo = 12;
            [fluorescentOptionDisplay setStringValue:@"I12"];
        }
        else if (fluorescentSimSetNo == 12){
            fluorescentSimSetNo = 0;
            [fluorescentOptionDisplay setStringValue:@"Off"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Sim Running"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)reDisplayWindow{
    if (simulationOperation == 3){
        [mainWindowSimWindow makeKeyAndOrderFront:nil];
        simulationOperation = 1;
        [simControllerTimer invalidate];
    }
}

-(IBAction)closeWindow:(id)sender{
    [mainWindowSimWindow orderOut:nil];
    simulationOperation = 2;
    simControllerTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToSimulationController object:nil];
}

@end
