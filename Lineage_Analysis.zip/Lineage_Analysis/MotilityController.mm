//
//  MotilityController.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2018-03-06.
//
//

#import "MotilityController.h"

NSString *notificationToMotilityController = @"notificationExecuteMotilityController";

@implementation MotilityController

-(id)init{
    self = [super init];
    
    if (self != nil){
        selectCutLevelHold = 0;
        selectCutLevelStatus = 0;
        selectTypeStatus = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToMotilityController object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    mainWindowMotilityController = [[NSWindowController alloc] initWithWindowNibName:@"Motility"];
    [mainWindowMotilityController showWindow:nil];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMotilityDisplay object:nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMotilityTable object:nil];
}

-(void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [motilityWindow frame];
    CGFloat windowHeight = windowSize.size.height;
    
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [motilityWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    [displayScaleDisplay setDelegate:self];
    [verticalStartDisplay setDelegate:self];
    [horizontalStartDisplay setDelegate:self];
    [timeStartDisplay setDelegate:self];
    [timeEndDisplay setDelegate:self];
    [fixSizeDisplay setDelegate:self];
    [cutLevelDisplay setDelegate:self];
    [shiftXDisplay setDelegate:self];
    [shiftYDisplay setDelegate:self];
    [markerMidValueDisplay setDelegate:self];
    
    [timeStartDisplay setIntegerValue:1];
    [timeEndDisplay setIntegerValue:1000];
    
    if (motilityOperation == 1){
        [stepperMotilityDisplay setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [0] green:arrayColorRange [1] blue:arrayColorRange [2] alpha:1]];
        [stepperMotilityDisplay setStringValue:@"Color select"];
    }
}

-(void)controlTextDidChange:(NSNotification *)aNotification{
    if ([[aNotification name] isEqualToString:@"NSControlTextDidChangeNotification"]){
        if ([aNotification object] == displayScaleDisplay){
            if (motilityAnalysisPerformHold >= 1){
                if ([displayScaleDisplay intValue] >= 0 && [displayScaleDisplay intValue] <= motilityDisplayScaleMaxHold+5000 && fixSizeHold == 0){
                    motilityDisplayScaleMaxHold = [displayScaleDisplay intValue];
                    [displayMaxDisplay setIntegerValue:motilityDisplayScaleMaxHold];
                }
                else [displayScaleDisplay setIntegerValue:motilityDisplayScaleMaxHold];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Perform Analysis"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        
        if ([aNotification object] == verticalStartDisplay){
            if (motilityAnalysisPerformHold >= 1){
                if ([verticalStartDisplay intValue] >= 0 && [verticalStartDisplay intValue] <= atoi(arrayMotilityResultsHold [motilityOperationTableCurrentRow*10+6].c_str())+motilityDisplayScaleMaxHold){
                    motilityVerticalStartHold = [verticalStartDisplay intValue];
                }
                else if ([verticalStartDisplay intValue] > atoi(arrayMotilityResultsHold [motilityOperationTableCurrentRow*10+6].c_str())+motilityDisplayScaleMaxHold) [verticalStartDisplay setIntegerValue:motilityVerticalStartHold];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Perform Analysis"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        
        if ([aNotification object] == horizontalStartDisplay){
            if (motilityAnalysisPerformHold >= 1){
                if ([horizontalStartDisplay intValue] >= 0 && [horizontalStartDisplay intValue] <= atoi(arrayMotilityResultsHold [motilityOperationTableCurrentRow*10+4].c_str())+motilityDisplayScaleMaxHold){
                    motilityHorizontalStartHold = [horizontalStartDisplay intValue];
                }
                else if ([horizontalStartDisplay intValue] > atoi(arrayMotilityResultsHold [motilityOperationTableCurrentRow*10+4].c_str())+motilityDisplayScaleMaxHold) [horizontalStartDisplay setIntegerValue:motilityHorizontalStartHold];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Perform Analysis"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        
        if ([aNotification object] == timeStartDisplay){
            if ([timeStartDisplay intValue] >= 1 && [timeStartDisplay intValue] <= 10000){
                motilityTimeStartHold = [timeStartDisplay intValue];
            }
            else{
                
                motilityTimeStartHold = 1;
                [timeEndDisplay setIntegerValue:1];
            }
        }
        
        if ([aNotification object] == timeEndDisplay){
            if ([timeEndDisplay intValue] >= 1 && [timeEndDisplay intValue] <= 10000){
                motilityTimeEndHold = [timeEndDisplay intValue];
            }
            else{
                
                motilityTimeEndHold = 1000;
                [timeEndDisplay setIntegerValue:1000];
            }
        }
        
        if ([aNotification object] == fixSizeDisplay){
            if ([fixSizeDisplay intValue] >= 1){
                fixSizeHold = [fixSizeDisplay intValue];
            }
            else{
                
                [fixSizeDisplay setIntegerValue:fixSizeHold];
            }
        }
        
        if ([aNotification object] == cutLevelDisplay){
            if ([cutLevelDisplay intValue] >= 1){
                selectCutLevelHold = [cutLevelDisplay intValue];
            }
            else{
                
                selectCutLevelHold = 1;
                [cutLevelDisplay setIntegerValue:1];
            }
        }
        
        if ([aNotification object] == shiftXDisplay){
            if ([shiftXDisplay doubleValue] > -10000 && [shiftXDisplay doubleValue] < 10000){
                shiftX = [shiftXDisplay doubleValue];
            }
            else{
                
                shiftX = 0;
                [shiftXDisplay setIntegerValue:0];
            }
        }
        
        if ([aNotification object] == shiftYDisplay){
            if ([shiftYDisplay doubleValue] > -10000 && [shiftYDisplay doubleValue] < 10000){
                shiftY = [shiftYDisplay doubleValue];
            }
            else{
                
                shiftY = 0;
                [shiftYDisplay setIntegerValue:0];
            }
        }
        
        if ([aNotification object] == markerMidValueDisplay){
            if ([markerMidValueDisplay intValue] > 0){
                markerMidValueHold = [markerMidValueDisplay intValue];
            }
            else{
                
                markerMidValueHold = 0;
                [markerMidValueDisplay setIntegerValue:0];
            }
        }
    }
}

-(IBAction)stepperActionColor:(id)sender{
    if ([stepperMotilityColor intValue] >= 0 && [stepperMotilityColor intValue] <= 105){
        motilityColorHold = [stepperMotilityColor intValue];
        [stepperMotilityDisplay setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [motilityColorHold] green:arrayColorRange [motilityColorHold+1] blue:arrayColorRange [motilityColorHold+2] alpha:1]];
        [stepperMotilityDisplay setStringValue:@"Color select"];
    }
}

-(IBAction)stepperActionMarkerStartColor:(id)sender{
    if ([stepperMarkerStartColor intValue] >= 0 && [stepperMarkerStartColor intValue] <= 105){
        markerStartColorHold = [stepperMarkerStartColor intValue];
        [stepperMarkerStartDisplay setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [markerStartColorHold] green:arrayColorRange [markerStartColorHold+1] blue:arrayColorRange [markerStartColorHold+2] alpha:1]];
        [stepperMarkerStartDisplay setStringValue:@"Start"];
    }
}

-(IBAction)stepperActionMarkerEndColor:(id)sender{
    if ([stepperMarkerEndColor intValue] >= 0 && [stepperMarkerEndColor intValue] <= 105){
        markerEndColorHold = [stepperMarkerEndColor intValue];
        [stepperMarkerEndDisplay setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [markerEndColorHold] green:arrayColorRange [markerEndColorHold+1] blue:arrayColorRange [markerEndColorHold+2] alpha:1]];
        [stepperMarkerEndDisplay setStringValue:@"End"];
    }
}

-(IBAction)stepperActionMarkerMidColor:(id)sender{
    if ([stepperMarkerMidColor intValue] >= 0 && [stepperMarkerMidColor intValue] <= 105){
        markerMidColorHold = [stepperMarkerMidColor intValue];
        [stepperMarkerMidDisplay setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [markerMidColorHold] green:arrayColorRange [markerMidColorHold+1] blue:arrayColorRange [markerMidColorHold+2] alpha:1]];
        [stepperMarkerMidDisplay setStringValue:@"Mid"];
    }
}

-(IBAction)lineColorSelect:(id)sender{
    if (motilityColorStatusHold == 0){
        motilityColorStatusHold = 1;
        [lineColorDisplay setStringValue:@"Ling"];
    }
    else if (motilityColorStatusHold == 1){
        motilityColorStatusHold = 2;
        [lineColorDisplay setStringValue:@"Cell"];
    }
    else{
        
        motilityColorStatusHold = 0;
        [lineColorDisplay setStringValue:@"Single"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)tableCategorySelect:(id)sender{
    if (motilityTableCategoryHold == 0){
        motilityTableCategoryHold = 1;
        displayOptionStatus = 0;
        [displayStatusDisplay setStringValue:@"Original"];
        [tableModeDisplay setStringValue:@"Lineage average"];
    }
    else if (motilityTableCategoryHold == 1){
        motilityTableCategoryHold = 2;
        displayOptionStatus = 0;
        [displayStatusDisplay setStringValue:@"Original"];
        [tableModeDisplay setStringValue:@"Cell average"];
    }
    else if (motilityTableCategoryHold == 2){
        motilityTableCategoryHold = 3;
        [tableModeDisplay setStringValue:@"Treatment total"];
    }
    else if (motilityTableCategoryHold == 3){
        motilityTableCategoryHold = 4;
        displayOptionStatus = 0;
        [displayStatusDisplay setStringValue:@"Original"];
        [tableModeDisplay setStringValue:@"Lineage total"];
    }
    else if (motilityTableCategoryHold == 4){
        motilityTableCategoryHold = 5;
        displayOptionStatus = 0;
        [displayStatusDisplay setStringValue:@"Original"];
        [tableModeDisplay setStringValue:@"Cell total"];
    }
    else{
        
        motilityTableCategoryHold = 0;
        [tableModeDisplay setStringValue:@"Treatment Average"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)fixSizeSet:(id)sender{
    if (fixSizeHold == 0){
        fixSizeHold = 1;
        [fixSizeDisplay setStringValue:@"On"];
    }
    else if (fixSizeHold == 1){
        fixSizeHold = 0;
        [fixSizeDisplay setStringValue:@"Off"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)analysisStart:(id)sender{
    if (lineageDataEntryCount != 0){
        if (motilityTimeEndHold > 1 || motilityTimeStartHold < motilityTimeEndHold){
            motilityResultsHoldCount = 0;
            
            int timeStart = 0;
            int timeEnd = 0;
            int motilityBasicInfoCount = 0;
            int motilityDistanceCount = 0;
            int cellLineageTempCount = 0;
            int xPositionMotility = 0;
            int yPositionMotility = 0;
            int lingNoHoldMotility = 0;
            int cellNoHoldMotility = 0;
            int dataSetStart = 0;
            int maxLineageNo = 0;
            int cellDataSortCount = 0;
            int lineageDataSortCount = 0;
            int cellNoExtractCount = 0;
            int cellNoExtractCount2 = 0;
            int cellNoFind = 0;
            int terminationFlag = 0;
            int smallestCellNo = 0;
            int smallestCellPosition = 0;
            int treatDataEntry = 0;
            int percentEventIntCount = 0;
            int lineageNoForDisplay = 0;
            int lineageNoCheck = 0;
            int cellNoDisplay = 0;
            int treatXMin = 0;
            int treatXMan = 0;
            int treatYMin = 0;
            int treatYMan = 0;
            int cellSize = 0;
            int lineageSize = 0;
            int timePoint = 0;
            int lineageNoTemp = 0;
            int cellNoTemp = -1;
            int eventType = 0;
            unsigned long typeMarkFound = 0;
            unsigned long currentPosition = 0;
            int lineageNoTempHold = 0;
            int xPositionDiff = 0;
            int yPositionDiff = 0;
            int firstFind = 0;
            int adjustXMin = 0;
            int adjustYMin = 0;
            
            double treatDataTotal = 0;
            double treatAverage = 0;
            double treatSDTotal = 0;
            double treatSD = 0;
            double percentEventCount = 0;
            
            string displayData1;
            string percentString;
            
            for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
                if (arraySelectedLing [counter2] == 1){
                    timeStart = motilityTimeStartHold;
                    timeEnd = motilityTimeEndHold;
                    
                    if (timeEnd > arrayTableDetail [counter2][3]) timeEnd = arrayTableDetail [counter2][3];
                    
                    int *arrayMotilityBasicInfo = new int [(arrayLineageDataEntryHold [counter2]/9)*6+100];
                    int *arrayCellLineageTemp = new int [(arrayLineageDataEntryHold [counter2]/9)*9+100];
                    double *arrayMotilityDistance = new double [arrayLineageDataEntryHold [counter2]/9+100];
                    
                    for (unsigned long counter3 = 0; counter3 < (arrayLineageDataEntryHold [counter2]/9)*6+100; counter3++){
                        arrayMotilityBasicInfo [counter3] = 0;
                    }
                    
                    for (unsigned long counter3 = 0; counter3 < (arrayLineageDataEntryHold [counter2]/9)*9+100; counter3++){
                        arrayCellLineageTemp [counter3] = 0;
                    }
                    
                    for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [counter2]/9+100; counter3++){
                        arrayMotilityDistance [counter3] = 0;
                    }
                    
                    if (activationStatus == 1){
                        timePoint = 0;
                        lineageNoTemp = 0;
                        cellNoTemp = -1;
                        eventType = 0;
                        typeMarkFound = 0;
                        currentPosition = 0;
                        cellLineageTempCount = 0;
                        
                        for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [counter2]/9; counter3++){
                            if ((arrayLineageData [counter2][counter3*9+5] != cellNoTemp || arrayLineageData [counter2][counter3*9+6] != lineageNoTemp) && timePoint == 0){
                                timePoint = arrayLineageData [counter2][counter3*9+2];
                                lineageNoTemp = arrayLineageData [counter2][counter3*9+6];
                                cellNoTemp = arrayLineageData [counter2][counter3*9+5];
                                eventType = arrayLineageData [counter2][counter3*9+3];
                                currentPosition = counter3;
                            }
                            else if ((arrayLineageData [counter2][counter3*9+5] != cellNoTemp || arrayLineageData [counter2][counter3*9+6] != lineageNoTemp) && timePoint != 0){
                                if (typeMarkFound != 0 && counter3-2 != typeMarkFound){
                                    for (unsigned long counter4 = typeMarkFound; counter4 <= counter3-1; counter4++){
                                        arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9], cellLineageTempCount++;
                                        arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+1], cellLineageTempCount++;
                                        arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+2], cellLineageTempCount++;
                                        arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+3], cellLineageTempCount++;
                                        arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+4], cellLineageTempCount++;
                                        arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+5], cellLineageTempCount++;
                                        arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+6], cellLineageTempCount++;
                                        arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+7], cellLineageTempCount++;
                                        arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+8], cellLineageTempCount++;
                                    }
                                }
                                else{
                                    
                                    for (unsigned long counter4 = currentPosition; counter4 < counter3; counter4++){
                                        arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9], cellLineageTempCount++;
                                        arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+1], cellLineageTempCount++;
                                        arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+2], cellLineageTempCount++;
                                        arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+3], cellLineageTempCount++;
                                        arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+4], cellLineageTempCount++;
                                        arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+5], cellLineageTempCount++;
                                        arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+6], cellLineageTempCount++;
                                        arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+7], cellLineageTempCount++;
                                        arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+8], cellLineageTempCount++;
                                    }
                                }
                                
                                typeMarkFound = 0;
                                
                                timePoint = arrayLineageData [counter2][counter3*9+2];
                                lineageNoTemp = arrayLineageData [counter2][counter3*9+6];
                                cellNoTemp = arrayLineageData [counter2][counter3*9+5];
                                eventType = arrayLineageData [counter2][counter3*9+3];
                                currentPosition = counter3;
                            }
                            else if (arrayLineageData [counter2][counter3*9+3] == 10 && eventType == 1){
                                typeMarkFound = counter3;
                            }
                            else if (counter3 == arrayLineageDataEntryHold [counter2]/9-1 && timePoint != 0){
                                if (typeMarkFound != 0 && counter3-2 != typeMarkFound){
                                    for (unsigned long counter4 = typeMarkFound; counter4 <= counter3-1; counter4++){
                                        arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9], cellLineageTempCount++;
                                        arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+1], cellLineageTempCount++;
                                        arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+2], cellLineageTempCount++;
                                        arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+3], cellLineageTempCount++;
                                        arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+4], cellLineageTempCount++;
                                        arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+5], cellLineageTempCount++;
                                        arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+6], cellLineageTempCount++;
                                        arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+7], cellLineageTempCount++;
                                        arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+8], cellLineageTempCount++;
                                    }
                                }
                                else{
                                    
                                    for (unsigned long counter4 = currentPosition; counter4 < counter3; counter4++){
                                        arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9], cellLineageTempCount++;
                                        arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+1], cellLineageTempCount++;
                                        arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+2], cellLineageTempCount++;
                                        arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+3], cellLineageTempCount++;
                                        arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+4], cellLineageTempCount++;
                                        arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+5], cellLineageTempCount++;
                                        arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+6], cellLineageTempCount++;
                                        arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+7], cellLineageTempCount++;
                                        arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+8], cellLineageTempCount++;
                                    }
                                }
                                
                                typeMarkFound = 0;
                            }
                        }
                        
                        motilityBasicInfoCount = 0;
                        motilityDistanceCount = 0;
                        maxLineageNo = 0;
                        dataSetStart = 0;
                        
                        for (int counter3 = 0; counter3 < cellLineageTempCount/9; counter3++){
                            if (maxLineageNo < arrayCellLineageTemp [counter3*9+6]) maxLineageNo = arrayCellLineageTemp [counter3*9+6];
                            
                            if (arrayCellLineageTemp [counter3*9+2] >= timeStart && arrayCellLineageTemp [counter3*9+2] < timeEnd && dataSetStart == 0){
                                xPositionMotility = arrayCellLineageTemp [counter3*9];
                                yPositionMotility = arrayCellLineageTemp [counter3*9+1];
                                
                                lingNoHoldMotility = arrayCellLineageTemp [counter3*9+6];
                                cellNoHoldMotility = arrayCellLineageTemp [counter3*9+5];
                                
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+6], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+5], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+1], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+3], motilityBasicInfoCount++;
                                arrayMotilityDistance [motilityDistanceCount] = 999999999, motilityDistanceCount++;
                                
                                dataSetStart = 1;
                            }
                            else if (arrayCellLineageTemp [counter3*9+2] > timeStart && arrayCellLineageTemp [counter3*9+2] < timeEnd && lingNoHoldMotility == arrayCellLineageTemp [counter3*9+6] && cellNoHoldMotility == arrayCellLineageTemp [counter3*9+5] && dataSetStart == 1){
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+6], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+5], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+1], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+3], motilityBasicInfoCount++;
                                
                                arrayMotilityDistance [motilityDistanceCount] = sqrt((xPositionMotility-arrayCellLineageTemp [counter3*9])*(xPositionMotility-arrayCellLineageTemp [counter3*9])+(yPositionMotility-arrayCellLineageTemp [counter3*9+1])*(yPositionMotility-arrayCellLineageTemp [counter3*9+1])), motilityDistanceCount++;
                                
                                xPositionMotility = arrayCellLineageTemp [counter3*9];
                                yPositionMotility = arrayCellLineageTemp [counter3*9+1];
                            }
                            else if (arrayCellLineageTemp [counter3*9+2] == timeEnd && lingNoHoldMotility == arrayCellLineageTemp [counter3*9+6] && cellNoHoldMotility == arrayCellLineageTemp [counter3*9+5] && dataSetStart == 1){
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+6], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+5], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+1], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+3], motilityBasicInfoCount++;
                                
                                arrayMotilityDistance [motilityDistanceCount] = sqrt((xPositionMotility-arrayCellLineageTemp [counter3*9])*(xPositionMotility-arrayCellLineageTemp [counter3*9])+(yPositionMotility-arrayCellLineageTemp [counter3*9+1])*(yPositionMotility-arrayCellLineageTemp [counter3*9+1])), motilityDistanceCount++;
                                
                                dataSetStart = 0;
                            }
                            else if (arrayCellLineageTemp [counter3*9+2] >= timeStart && arrayCellLineageTemp [counter3*9+2] < timeEnd && (lingNoHoldMotility != arrayCellLineageTemp [counter3*9+6] || cellNoHoldMotility != arrayCellLineageTemp [counter3*9+5]) && dataSetStart == 1){
                                xPositionMotility = arrayCellLineageTemp [counter3*9];
                                yPositionMotility = arrayCellLineageTemp [counter3*9+1];
                                
                                lingNoHoldMotility = arrayCellLineageTemp [counter3*9+6];
                                cellNoHoldMotility = arrayCellLineageTemp [counter3*9+5];
                                
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+6], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+5], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+1], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+3], motilityBasicInfoCount++;
                                arrayMotilityDistance [motilityDistanceCount] = 999999999, motilityDistanceCount++;
                            }
                        }
                    }
                    else{
                        
                        motilityBasicInfoCount = 0;
                        motilityDistanceCount = 0;
                        maxLineageNo = 0;
                        dataSetStart = 0;
                        
                        for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [counter2]/9; counter3++){
                            if (maxLineageNo < arrayLineageData [counter2][counter3*9+6]) maxLineageNo = arrayLineageData [counter2][counter3*9+6];
                            
                            if (arrayLineageData [counter2][counter3*9+2] >= timeStart && arrayLineageData [counter2][counter3*9+2] < timeEnd && dataSetStart == 0){
                                xPositionMotility = arrayLineageData [counter2][counter3*9];
                                yPositionMotility = arrayLineageData [counter2][counter3*9+1];
                                
                                lingNoHoldMotility = arrayLineageData [counter2][counter3*9+6];
                                cellNoHoldMotility = arrayLineageData [counter2][counter3*9+5];
                                
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9+6], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9+5], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9+1], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9+3], motilityBasicInfoCount++;
                                arrayMotilityDistance [motilityDistanceCount] = 999999999, motilityDistanceCount++;
                                
                                dataSetStart = 1;
                            }
                            else if (arrayLineageData [counter2][counter3*9+2] > timeStart && arrayLineageData [counter2][counter3*9+2] < timeEnd && lingNoHoldMotility == arrayLineageData [counter2][counter3*9+6] && cellNoHoldMotility == arrayLineageData [counter2][counter3*9+5] && dataSetStart == 1){
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9+6], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9+5], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9+1], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9+3], motilityBasicInfoCount++;
                                
                                arrayMotilityDistance [motilityDistanceCount] = sqrt((xPositionMotility-arrayLineageData [counter2][counter3*9])*(xPositionMotility-arrayLineageData [counter2][counter3*9])+(yPositionMotility-arrayLineageData [counter2][counter3*9+1])*(yPositionMotility-arrayLineageData [counter2][counter3*9+1])), motilityDistanceCount++;
                                
                                xPositionMotility = arrayLineageData [counter2][counter3*9];
                                yPositionMotility = arrayLineageData [counter2][counter3*9+1];
                            }
                            else if (arrayLineageData [counter2][counter3*9+2] == timeEnd && lingNoHoldMotility == arrayLineageData [counter2][counter3*9+6] && cellNoHoldMotility == arrayLineageData [counter2][counter3*9+5] && dataSetStart == 1){
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9+6], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9+5], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9+1], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9+3], motilityBasicInfoCount++;
                                
                                arrayMotilityDistance [motilityDistanceCount] = sqrt((xPositionMotility-arrayLineageData [counter2][counter3*9])*(xPositionMotility-arrayLineageData [counter2][counter3*9])+(yPositionMotility-arrayLineageData [counter2][counter3*9+1])*(yPositionMotility-arrayLineageData [counter2][counter3*9+1])), motilityDistanceCount++;
                                
                                dataSetStart = 0;
                            }
                            else if (arrayLineageData [counter2][counter3*9+2] >= timeStart && arrayLineageData [counter2][counter3*9+2] < timeEnd && (lingNoHoldMotility != arrayLineageData [counter2][counter3*9+6] || cellNoHoldMotility != arrayLineageData [counter2][counter3*9+5]) && dataSetStart == 1){
                                xPositionMotility = arrayLineageData [counter2][counter3*9];
                                yPositionMotility = arrayLineageData [counter2][counter3*9+1];
                                
                                lingNoHoldMotility = arrayLineageData [counter2][counter3*9+6];
                                cellNoHoldMotility = arrayLineageData [counter2][counter3*9+5];
                                
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9+6], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9+5], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9+1], motilityBasicInfoCount++;
                                arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9+3], motilityBasicInfoCount++;
                                arrayMotilityDistance [motilityDistanceCount] = 999999999, motilityDistanceCount++;
                            }
                        }
                    }
                    
                    delete [] arrayCellLineageTemp;
                    
                    //for (int counterA = 0; counterA < motilityBasicInfoCount/5; counterA++){
                    //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<< arrayMotilityBasicInfo [counterA*5+counterB];
                    //    cout<<"  arrayMotilityBasicInfo "<<counterA<<endl;
                    //}
                    
                    if (displayOptionStatus == 1 && (motilityTableCategoryHold == 0 || motilityTableCategoryHold == 3)){
                        int *motilityTemp = new int [motilityBasicInfoCount+50];
                        
                        for (int counter3 = 0; counter3 < motilityBasicInfoCount; counter3++) motilityTemp [counter3] = arrayMotilityBasicInfo [counter3];
                        
                        lineageNoTempHold = 0;
                        xPositionDiff = 0;
                        yPositionDiff = 0;
                        firstFind = 0;
                        
                        for (int counter3 = 0; counter3 < motilityBasicInfoCount/5; counter3++){
                            if (lineageNoTempHold != motilityTemp [counter3*4] && firstFind == 0){
                                lineageNoTempHold = motilityTemp [counter3*4];
                                xPositionDiff = motilityTemp [counter3*4+2];
                                yPositionDiff = motilityTemp [counter3*4+3];
                                
                                motilityTemp [counter3*4+2] = 0;
                                motilityTemp [counter3*4+3] = 0;
                                
                                firstFind = 1;
                            }
                            else if (lineageNoTempHold == motilityTemp [counter3*4] && firstFind == 1){
                                motilityTemp [counter3*4+2] = motilityTemp [counter3*4+2]-xPositionDiff;
                                motilityTemp [counter3*4+3] = motilityTemp [counter3*4+3]-yPositionDiff;
                                
                            }
                            else if (lineageNoTempHold != motilityTemp [counter3*4] && firstFind == 1){
                                lineageNoTempHold = motilityTemp [counter3*4];
                                xPositionDiff = motilityTemp [counter3*4+2];
                                yPositionDiff = motilityTemp [counter3*4+3];
                                
                                motilityTemp [counter3*4+2] = 0;
                                motilityTemp [counter3*4+3] = 0;
                            }
                        }
                        
                        adjustXMin = 0;
                        adjustYMin = 0;
                        
                        for (int counter3 = 0; counter3 < motilityBasicInfoCount/5; counter3++){
                            if (adjustXMin > motilityTemp [counter3*4+2]) adjustXMin = motilityTemp [counter3*4+2];
                            if (adjustYMin > motilityTemp [counter3*4+3]) adjustYMin = motilityTemp [counter3*4+3];
                        }
                        
                        int adjustFinal = 0;
                        
                        if (adjustXMin < adjustYMin) adjustFinal = adjustXMin;
                        else adjustFinal = adjustYMin;
                        
                        if (adjustFinal < 0){
                            for (int counter3 = 0; counter3 < motilityBasicInfoCount/5; counter3++){
                                arrayMotilityBasicInfo [counter3*5+2] = motilityTemp [counter3*4+2]-adjustFinal+10;
                                arrayMotilityBasicInfo [counter3*5+3] = motilityTemp [counter3*4+3]-adjustFinal+10;
                            }
                        }
                        
                        delete [] motilityTemp;
                        
                        //for (int counterA = 0; counterA < motilityBasicInfoCount/4; counterA++){
                        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<< arrayMotilityBasicInfo [counterA*4+counterB];
                        //    cout<<"  arrayMotilityBasicInfo "<<counterA<<endl;
                        //}
                    }
                    
                    //for (int counterA = 0; counterA < motilityBasicInfoCount/5; counterA++){
                    //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<< arrayMotilityBasicInfo [counterA*5+counterB];
                    //    cout<<"  arrayMotilityBasicInfo "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < motilityDistanceCount; counterA++){
                    //    cout<<counterA<<" "<<arrayMotilityDistance [counterA] <<" arrayMotilityDistance"<<endl;
                    //}
                    
                    double *cellDataSort = new double [(motilityBasicInfoCount/5)*11+100];
                    cellDataSortCount = 0;
                    
                    double *lineageDataSort = new double [maxLineageNo*10+100];
                    lineageDataSortCount = 0;
                    
                    int *cellNoExtract = new int [arrayTableDetail [counter2][9]+10];
                    int *cellNoExtract2 = new int [arrayTableDetail [counter2][9]+10];
                    
                    for (int counter3 = 1; counter3 <= maxLineageNo; counter3++){
                        cellNoExtractCount = 0;
                        
                        for (int counter4 = 0; counter4 < motilityBasicInfoCount/5; counter4++){
                            if (counter3 == arrayMotilityBasicInfo [counter4*5]){
                                cellNoFind = 0;
                                
                                for (int counter5 = 0; counter5 < cellNoExtractCount; counter5++){
                                    if (cellNoExtract [counter5] == arrayMotilityBasicInfo [counter4*5+1]){
                                        cellNoFind = 1;
                                        break;
                                    }
                                }
                                
                                if (cellNoFind == 0){
                                    cellNoExtract [cellNoExtractCount] = arrayMotilityBasicInfo [counter4*5+1], cellNoExtractCount++;
                                }
                            }
                        }
                        
                        if (cellNoExtractCount != 0){
                            cellNoExtractCount2 = 0;
                            
                            do{
                                
                                terminationFlag = 1;
                                smallestCellNo = 999999999;
                                smallestCellPosition = 0;
                                
                                for (int counter4 = 0; counter4 < cellNoExtractCount; counter4++){
                                    if (cellNoExtract [counter4] < smallestCellNo && cellNoExtract [counter4] != -2){
                                        smallestCellNo = cellNoExtract [counter4];
                                        smallestCellPosition = counter4;
                                    }
                                }
                                
                                if (smallestCellNo != 999999999){
                                    cellNoExtract2 [cellNoExtractCount2] = cellNoExtract [smallestCellPosition], cellNoExtractCount2++;
                                    cellNoExtract [smallestCellPosition] = -2;
                                }
                                else terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                            
                            for (int counter4 = 0; counter4 < cellNoExtractCount2; counter4++){
                                cellDataSort [cellDataSortCount] = counter3, cellDataSortCount++; //----Ling no
                                cellDataSort [cellDataSortCount] = cellNoExtract2 [counter4], cellDataSortCount++; //----Cell no
                                cellDataSort [cellDataSortCount] = 0, cellDataSortCount++; //----Count
                                cellDataSort [cellDataSortCount] = 0, cellDataSortCount++; //----Total
                                cellDataSort [cellDataSortCount] = 0, cellDataSortCount++; //----AV
                                cellDataSort [cellDataSortCount] = 0, cellDataSortCount++; //----SD total
                                cellDataSort [cellDataSortCount] = 0, cellDataSortCount++; //----SD
                                cellDataSort [cellDataSortCount] = 999999999, cellDataSortCount++; //----x Min
                                cellDataSort [cellDataSortCount] = 0, cellDataSortCount++; //----x Max
                                cellDataSort [cellDataSortCount] = 999999999, cellDataSortCount++; //----y Min
                                cellDataSort [cellDataSortCount] = 0, cellDataSortCount++; //----y Max
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < cellDataSortCount/11; counterA++){
                    //    for (int counterB = 0; counterB < 11; counterB++) cout<<" "<< to_string(cellDataSort [counterA*11+counterB]);
                    //    cout<<"  cellDataSort "<<counterA<<endl;
                    //}
                    
                    for (int counter3 = 0; counter3 < motilityBasicInfoCount/5; counter3++){
                        for (int counter4 = 0; counter4 < cellDataSortCount/11; counter4++){
                            if (arrayMotilityDistance [counter3] != 999999999 && cellDataSort [counter4*11] == arrayMotilityBasicInfo [counter3*5] && cellDataSort [counter4*11+1] == arrayMotilityBasicInfo [counter3*5+1]){
                                cellDataSort [counter4*11+2]++;
                                cellDataSort [counter4*11+3] = cellDataSort [counter4*11+3]+arrayMotilityDistance [counter3];
                                break;
                            }
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < motilityBasicInfoCount/5; counter3++){
                        for (int counter4 = 0; counter4 < cellDataSortCount/11; counter4++){
                            if (cellDataSort [counter4*11] == arrayMotilityBasicInfo [counter3*5] && cellDataSort [counter4*11+1] == arrayMotilityBasicInfo [counter3*5+1]){
                                if (cellDataSort [counter4*11+7] > arrayMotilityBasicInfo [counter3*5+2]) cellDataSort [counter4*11+7] = arrayMotilityBasicInfo [counter3*5+2];
                                if (cellDataSort [counter4*11+8] < arrayMotilityBasicInfo [counter3*5+2]) cellDataSort [counter4*11+8] = arrayMotilityBasicInfo [counter3*5+2];
                                if (cellDataSort [counter4*11+9] > arrayMotilityBasicInfo [counter3*5+3]) cellDataSort [counter4*11+9] = arrayMotilityBasicInfo [counter3*5+3];
                                if (cellDataSort [counter4*11+10] < arrayMotilityBasicInfo [counter3*5+3]) cellDataSort [counter4*11+10] = arrayMotilityBasicInfo [counter3*5+3];
                                break;
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < cellDataSortCount/11; counterA++){
                    //    for (int counterB = 0; counterB < 11; counterB++) cout<<" "<< to_string(cellDataSort [counterA*11+counterB]);
                    //    cout<<"  cellDataSort "<<counterA<<endl;
                    //}
                    
                    for (int counter3 = 0; counter3 < cellDataSortCount/11; counter3++){
                        cellNoFind = 0;
                        
                        for (int counter4 = 0; counter4 < lineageDataSortCount/10; counter4++){
                            if (cellDataSort [counter3*11] == lineageDataSort [counter4*10]){
                                cellNoFind = 1;
                                break;
                            }
                        }
                        
                        if (cellNoFind == 0){
                            
                            lineageDataSort [lineageDataSortCount] = cellDataSort [counter3*11], lineageDataSortCount++;
                            lineageDataSort [lineageDataSortCount] = 0, lineageDataSortCount++;
                            lineageDataSort [lineageDataSortCount] = 0, lineageDataSortCount++;
                            lineageDataSort [lineageDataSortCount] = 0, lineageDataSortCount++;
                            lineageDataSort [lineageDataSortCount] = 0, lineageDataSortCount++;
                            lineageDataSort [lineageDataSortCount] = 0, lineageDataSortCount++;
                            lineageDataSort [lineageDataSortCount] = 999999999, lineageDataSortCount++;
                            lineageDataSort [lineageDataSortCount] = 0, lineageDataSortCount++;
                            lineageDataSort [lineageDataSortCount] = 999999999, lineageDataSortCount++;
                            lineageDataSort [lineageDataSortCount] = 0, lineageDataSortCount++;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < lineageDataSortCount/10; counterA++){
                    //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<< to_string(lineageDataSort [counterA*10+counterB]);
                    //    cout<<"  lineageDataSort "<<counterA<<endl;
                    //}
                    
                    treatDataTotal = 0;
                    treatDataEntry = 0;
                    treatXMin = 99999999;
                    treatXMan = 0;
                    treatYMin = 99999999;
                    treatYMan = 0;
                    
                    for (int counter3 = 0; counter3 < motilityBasicInfoCount/5; counter3++){
                        for (int counter4 = 0; counter4 < lineageDataSortCount/10; counter4++){
                            if (arrayMotilityDistance [counter3] != 999999999 && lineageDataSort [counter4*10] == arrayMotilityBasicInfo [counter3*5]){
                                lineageDataSort [counter4*10+1]++;
                                lineageDataSort [counter4*10+2] = lineageDataSort [counter4*10+2]+arrayMotilityDistance [counter3];
                                break;
                            }
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < motilityBasicInfoCount/5; counter3++){
                        for (int counter4 = 0; counter4 < lineageDataSortCount/10; counter4++){
                            if (lineageDataSort [counter4*10] == arrayMotilityBasicInfo [counter3*5]){
                                if (lineageDataSort [counter4*10+6] > arrayMotilityBasicInfo [counter3*5+2]) lineageDataSort [counter4*10+6] = arrayMotilityBasicInfo [counter3*5+2];
                                if (lineageDataSort [counter4*10+7] < arrayMotilityBasicInfo [counter3*5+2]) lineageDataSort [counter4*10+7] = arrayMotilityBasicInfo [counter3*5+2];
                                if (lineageDataSort [counter4*10+8] > arrayMotilityBasicInfo [counter3*5+3]) lineageDataSort [counter4*10+8] = arrayMotilityBasicInfo [counter3*5+3];
                                if (lineageDataSort [counter4*10+9] < arrayMotilityBasicInfo [counter3*5+3]) lineageDataSort [counter4*10+9] = arrayMotilityBasicInfo [counter3*5+3];
                                break;
                            }
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < motilityBasicInfoCount/5; counter3++){
                        if (arrayMotilityDistance [counter3] != 999999999){
                            treatDataEntry++;
                            treatDataTotal = treatDataTotal+arrayMotilityDistance [counter3];
                            
                            if (treatXMin > arrayMotilityBasicInfo [counter3*5+2]) treatXMin = arrayMotilityBasicInfo [counter3*5+2];
                            if (treatXMan < arrayMotilityBasicInfo [counter3*5+2]) treatXMan = arrayMotilityBasicInfo [counter3*5+2];
                            if (treatYMin > arrayMotilityBasicInfo [counter3*5+3]) treatYMin = arrayMotilityBasicInfo [counter3*5+3];
                            if (treatYMan < arrayMotilityBasicInfo [counter3*5+3]) treatYMan = arrayMotilityBasicInfo [counter3*5+3];
                        }
                    }
                    
                    //for (int counterA = 0; counterA < lineageDataSortCount/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<< to_string(lineageDataSort [counterA*6+counterB]);
                    //    cout<<"  lineageDataSort "<<counterA<<endl;
                    //}
                    
                    //----Cell SD----
                    for (int counter4 = 0; counter4 < cellDataSortCount/11; counter4++){
                        if (cellDataSort [counter4*11+2] != 0){
                            cellDataSort [counter4*11+4] = cellDataSort [counter4*11+3]/(double)cellDataSort [counter4*11+2];
                        }
                        else cellDataSort [counter4*11+4] = 0;
                    }
                    
                    //for (int counterA = 0; counterA < cellDataSortCount/7; counterA++){
                    //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<< to_string(cellDataSort [counterA*7+counterB]);
                    //    cout<<"  cellDataSort "<<counterA<<endl;
                    //}
                    
                    for (int counter3 = 0; counter3 < motilityBasicInfoCount/5; counter3++){
                        for (int counter4 = 0; counter4 < cellDataSortCount/11; counter4++){
                            if (arrayMotilityDistance [counter3] != 999999999 && cellDataSort [counter4*11] == arrayMotilityBasicInfo [counter3*5] && cellDataSort [counter4*11+1] == arrayMotilityBasicInfo [counter3*5+1]){
                                cellDataSort [counter4*11+5] = cellDataSort [counter4*11+5]+(cellDataSort [counter4*11+4]-arrayMotilityDistance [counter3])*(cellDataSort [counter4*11+4]-arrayMotilityDistance [counter3]);
                                break;
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < cellDataSortCount/7; counterA++){
                    //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<< to_string(cellDataSort [counterA*7+counterB]);
                    //    cout<<"  cellDataSort "<<counterA<<endl;
                    //}
                    
                    for (int counter4 = 0; counter4 < cellDataSortCount/11; counter4++){
                        if (cellDataSort [counter4*11+2] != 0){
                            cellDataSort [counter4*11+6] = sqrt(cellDataSort [counter4*11+5]/(double)cellDataSort [counter4*11+2]);
                        }
                        else cellDataSort [counter4*11+6] = 0;
                    }
                    
                    //for (int counterA = 0; counterA < cellDataSortCount/11; counterA++){
                    //    for (int counterB = 0; counterB < 11; counterB++) cout<<" "<< to_string(cellDataSort [counterA*11+counterB]);
                    //    cout<<"  cellDataSort "<<counterA<<endl;
                    //}
                    
                    //----Ling SD----
                    for (int counter4 = 0; counter4 < lineageDataSortCount/10; counter4++){
                        if (lineageDataSort [counter4*10+1] != 0){
                            lineageDataSort [counter4*10+3] = lineageDataSort [counter4*10+2]/(double)lineageDataSort [counter4*10+1];
                        }
                        else lineageDataSort [counter4*10+1] = 0;
                    }
                    
                    //for (int counterA = 0; counterA < lineageDataSortCount/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<< to_string(lineageDataSort [counterA*6+counterB]);
                    //    cout<<"  lineageDataSort "<<counterA<<endl;
                    //}
                    
                    for (int counter3 = 0; counter3 < motilityBasicInfoCount/5; counter3++){
                        for (int counter4 = 0; counter4 < lineageDataSortCount/10; counter4++){
                            if (arrayMotilityDistance [counter3] != 999999999 && lineageDataSort [counter4*10] == arrayMotilityBasicInfo [counter3*5]){
                                lineageDataSort [counter4*10+4] = lineageDataSort [counter4*6+4]+(lineageDataSort [counter4*10+3]-arrayMotilityDistance [counter3])*(lineageDataSort [counter4*10+3]-arrayMotilityDistance [counter3]);
                                break;
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < lineageDataSortCount/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<< to_string(lineageDataSort [counterA*6+counterB]);
                    //    cout<<"  lineageDataSort "<<counterA<<endl;
                    //}
                    
                    for (int counter4 = 0; counter4 < lineageDataSortCount/10; counter4++){
                        if (lineageDataSort [counter4*10+1] != 0){
                            lineageDataSort [counter4*10+5] = sqrt(lineageDataSort [counter4*10+4]/(double)lineageDataSort [counter4*10+1]);
                        }
                        else lineageDataSort [counter4*10+5] = 0;
                    }
                    
                    //for (int counterA = 0; counterA < lineageDataSortCount/10; counterA++){
                    //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<< to_string(lineageDataSort [counterA*10+counterB]);
                    //    cout<<"  lineageDataSort "<<counterA<<endl;
                    //}
                    
                    //----Treat SD----
                    if (treatDataEntry != 0){
                        treatAverage = treatDataTotal/(double)treatDataEntry;
                    }
                    else treatAverage = 0;
                    
                    treatSDTotal = 0;
                    
                    for (int counter3 = 0; counter3 < motilityBasicInfoCount/5; counter3++){
                        if (arrayMotilityDistance [counter3] != 999999999){
                            treatSDTotal = treatSDTotal+(treatAverage-arrayMotilityDistance [counter3])*(treatAverage-arrayMotilityDistance [counter3]);
                        }
                    }
                    
                    if (treatDataEntry != 0){
                        treatSD = sqrt(treatSDTotal/(double)treatDataEntry);
                    }
                    else treatSD = 0;
                    
                    //----Data set----
                    if (motilityTableCategoryHold == 0){
                        if (motilityResultsHoldCount+20 > motilityResultsHoldLimit){
                            string *arrayUpDate = new string [motilityResultsHoldCount+10];
                            
                            for (int counter4 = 0; counter4 < motilityResultsHoldCount; counter4++) arrayUpDate [counter4] = arrayMotilityResultsHold [counter4];
                            
                            delete [] arrayMotilityResultsHold;
                            arrayMotilityResultsHold = new string [motilityResultsHoldLimit+350*10+500];
                            motilityResultsHoldLimit = motilityResultsHoldLimit+350*10+500;
                            
                            for (int counter4 = 0; counter4 < motilityResultsHoldCount; counter4++) arrayMotilityResultsHold [counter4] = arrayUpDate [counter4];
                            delete [] arrayUpDate;
                        }
                        
                        arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(counter2), motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(treatXMin), motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(treatXMan), motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(treatYMin), motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(treatYMan), motilityResultsHoldCount++;
                        
                        arrayMotilityResultsHold [motilityResultsHoldCount] = arrayTableMain [counter2][4], motilityResultsHoldCount++;
                        
                        percentEventIntCount = (int)(treatAverage*1000);
                        percentEventCount = percentEventIntCount/(double)1000;
                        
                        stringstream extension1;
                        extension1 << percentEventCount;
                        percentString = extension1.str();
                        
                        arrayMotilityResultsHold [motilityResultsHoldCount] = percentString, motilityResultsHoldCount++;
                        
                        percentEventIntCount = (int)(treatSD*1000);
                        percentEventCount = percentEventIntCount/(double)1000;
                        
                        stringstream extension2;
                        extension2 << percentEventCount;
                        percentString = extension2.str();
                        
                        arrayMotilityResultsHold [motilityResultsHoldCount] = percentString, motilityResultsHoldCount++;
                    }
                    else if (motilityTableCategoryHold == 1){
                        if (motilityResultsHoldCount+20 > motilityResultsHoldLimit){
                            string *arrayUpDate = new string [motilityResultsHoldCount+10];
                            
                            for (int counter4 = 0; counter4 < motilityResultsHoldCount; counter4++) arrayUpDate [counter4] = arrayMotilityResultsHold [counter4];
                            
                            delete [] arrayMotilityResultsHold;
                            arrayMotilityResultsHold = new string [motilityResultsHoldLimit+350*10+500];
                            motilityResultsHoldLimit = motilityResultsHoldLimit+350*10+500;
                            
                            for (int counter4 = 0; counter4 < motilityResultsHoldCount; counter4++) arrayMotilityResultsHold [counter4] = arrayUpDate [counter4];
                            delete [] arrayUpDate;
                        }
                        
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = arrayTableMain [counter2][4], motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = " ", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = " ", motilityResultsHoldCount++;
                        
                        for (int counter4 = 0; counter4 < lineageDataSortCount/10; counter4++){
                            if (motilityResultsHoldCount+20 > motilityResultsHoldLimit){
                                string *arrayUpDate = new string [motilityResultsHoldCount+10];
                                
                                for (int counter5 = 0; counter5 < motilityResultsHoldCount; counter5++) arrayUpDate [counter5] = arrayMotilityResultsHold [counter5];
                                
                                delete [] arrayMotilityResultsHold;
                                arrayMotilityResultsHold = new string [motilityResultsHoldLimit+350*10+500];
                                motilityResultsHoldLimit = motilityResultsHoldLimit+350*10+500;
                                
                                for (int counter5 = 0; counter5 < motilityResultsHoldCount; counter5++) arrayMotilityResultsHold [counter5] = arrayUpDate [counter5];
                                delete [] arrayUpDate;
                            }
                            
                            lineageNoForDisplay = (int)lineageDataSort [counter4*10];
                            
                            displayData1 = to_string(lineageNoForDisplay);
                            
                            if (displayData1.length() == 1) displayData1 = "L0000"+displayData1;
                            else if (displayData1.length() == 2) displayData1 = "L000"+displayData1;
                            else if (displayData1.length() == 3) displayData1 = "L00"+displayData1;
                            else if (displayData1.length() == 4) displayData1 = "L0"+displayData1;
                            else if (displayData1.length() == 5) displayData1 = "L"+displayData1;
                            
                            arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(counter2), motilityResultsHoldCount++;
                            arrayMotilityResultsHold [motilityResultsHoldCount] = displayData1, motilityResultsHoldCount++;
                            arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                            
                            lineageSize = (int)lineageDataSort [counter4*10+6];
                            
                            arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(lineageSize), motilityResultsHoldCount++;
                            
                            lineageSize = (int)lineageDataSort [counter4*10+7];
                            
                            arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(lineageSize), motilityResultsHoldCount++;
                            
                            lineageSize = (int)lineageDataSort [counter4*10+8];
                            
                            arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(lineageSize), motilityResultsHoldCount++;
                            
                            lineageSize = (int)lineageDataSort [counter4*10+9];
                            
                            arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(lineageSize), motilityResultsHoldCount++;
                            
                            arrayMotilityResultsHold [motilityResultsHoldCount] = displayData1, motilityResultsHoldCount++;
                            
                            percentEventIntCount = (int)(lineageDataSort [counter4*10+3]*1000);
                            percentEventCount = percentEventIntCount/(double)1000;
                            
                            stringstream extension1;
                            extension1 << percentEventCount;
                            percentString = extension1.str();
                            
                            arrayMotilityResultsHold [motilityResultsHoldCount] = percentString, motilityResultsHoldCount++;
                            
                            percentEventIntCount = (int)(lineageDataSort [counter4*10+5]*1000);
                            percentEventCount = percentEventIntCount/(double)1000;
                            
                            stringstream extension2;
                            extension2 << percentEventCount;
                            percentString = extension2.str();
                            
                            arrayMotilityResultsHold [motilityResultsHoldCount] = percentString, motilityResultsHoldCount++;
                        }
                        
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = " ", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = " ", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = " ", motilityResultsHoldCount++;
                    }
                    else if (motilityTableCategoryHold == 2){
                        if (motilityResultsHoldCount+20 > motilityResultsHoldLimit){
                            string *arrayUpDate = new string [motilityResultsHoldCount+10];
                            
                            for (int counter4 = 0; counter4 < motilityResultsHoldCount; counter4++) arrayUpDate [counter4] = arrayMotilityResultsHold [counter4];
                            
                            delete [] arrayMotilityResultsHold;
                            arrayMotilityResultsHold = new string [motilityResultsHoldLimit+350*10+500];
                            motilityResultsHoldLimit = motilityResultsHoldLimit+350*10+500;
                            
                            for (int counter4 = 0; counter4 < motilityResultsHoldCount; counter4++) arrayMotilityResultsHold [counter4] = arrayUpDate [counter4];
                            delete [] arrayUpDate;
                        }
                        
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = arrayTableMain [counter2][4], motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = " ", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = " ", motilityResultsHoldCount++;
                        
                        lineageNoCheck = 0;
                        
                        for (int counter4 = 0; counter4 < cellDataSortCount/11; counter4++){
                            if (motilityResultsHoldCount+40 > motilityResultsHoldLimit){
                                string *arrayUpDate = new string [motilityResultsHoldCount+10];
                                
                                for (int counter5 = 0; counter5 < motilityResultsHoldCount; counter5++) arrayUpDate [counter5] = arrayMotilityResultsHold [counter5];
                                
                                delete [] arrayMotilityResultsHold;
                                arrayMotilityResultsHold = new string [motilityResultsHoldLimit+350*10+500];
                                motilityResultsHoldLimit = motilityResultsHoldLimit+350*10+500;
                                
                                for (int counter5 = 0; counter5 < motilityResultsHoldCount; counter5++) arrayMotilityResultsHold [counter5] = arrayUpDate [counter5];
                                delete [] arrayUpDate;
                            }
                            
                            lineageNoForDisplay = (int)cellDataSort [counter4*11];
                            
                            displayData1 = to_string(lineageNoForDisplay);
                            
                            if (displayData1.length() == 1) displayData1 = "L0000"+displayData1;
                            else if (displayData1.length() == 2) displayData1 = "L000"+displayData1;
                            else if (displayData1.length() == 3) displayData1 = "L00"+displayData1;
                            else if (displayData1.length() == 4) displayData1 = "L0"+displayData1;
                            else if (displayData1.length() == 5) displayData1 = "L"+displayData1;
                            
                            if (lineageNoCheck == 0 || lineageNoCheck != lineageNoForDisplay){
                                if (lineageNoCheck != 0){
                                    arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                                    arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                                    arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                                    arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                                    arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                                    arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                                    arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                                    arrayMotilityResultsHold [motilityResultsHoldCount] = " ", motilityResultsHoldCount++;
                                    arrayMotilityResultsHold [motilityResultsHoldCount] = " ", motilityResultsHoldCount++;
                                    arrayMotilityResultsHold [motilityResultsHoldCount] = " ", motilityResultsHoldCount++;
                                }
                                
                                lineageNoCheck = lineageNoForDisplay;
                                
                                arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                                arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                                arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                                arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                                arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                                arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                                arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                                arrayMotilityResultsHold [motilityResultsHoldCount] = displayData1, motilityResultsHoldCount++;
                                arrayMotilityResultsHold [motilityResultsHoldCount] = " ", motilityResultsHoldCount++;
                                arrayMotilityResultsHold [motilityResultsHoldCount] = " ", motilityResultsHoldCount++;
                                
                                cellNoDisplay = (int)cellDataSort [counter4*11+1];
                                
                                arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(counter2), motilityResultsHoldCount++;
                                arrayMotilityResultsHold [motilityResultsHoldCount] = displayData1, motilityResultsHoldCount++;
                                arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(cellNoDisplay), motilityResultsHoldCount++;
                                
                                cellSize = (int)cellDataSort [counter4*11+7];
                                
                                arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(cellSize), motilityResultsHoldCount++;
                                
                                cellSize = (int)cellDataSort [counter4*11+8];
                                
                                arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(cellSize), motilityResultsHoldCount++;
                                
                                cellSize = (int)cellDataSort [counter4*11+9];
                                
                                arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(cellSize), motilityResultsHoldCount++;
                                
                                cellSize = (int)cellDataSort [counter4*11+10];
                                
                                arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(cellSize), motilityResultsHoldCount++;
                                
                                arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(cellNoDisplay), motilityResultsHoldCount++;
                                
                                percentEventIntCount = (int)(cellDataSort [counter4*11+4]*1000);
                                percentEventCount = percentEventIntCount/(double)1000;
                                
                                stringstream extension1;
                                extension1 << percentEventCount;
                                percentString = extension1.str();
                                
                                arrayMotilityResultsHold [motilityResultsHoldCount] = percentString, motilityResultsHoldCount++;
                                
                                percentEventIntCount = (int)(cellDataSort [counter4*11+6]*1000);
                                percentEventCount = percentEventIntCount/(double)1000;
                                
                                stringstream extension2;
                                extension2 << percentEventCount;
                                percentString = extension2.str();
                                
                                arrayMotilityResultsHold [motilityResultsHoldCount] = percentString, motilityResultsHoldCount++;
                            }
                            else{
                                
                                cellNoDisplay = (int)cellDataSort [counter4*11+1];
                                
                                arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(counter2), motilityResultsHoldCount++;
                                arrayMotilityResultsHold [motilityResultsHoldCount] = displayData1, motilityResultsHoldCount++;
                                arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(cellNoDisplay), motilityResultsHoldCount++;
                                
                                cellSize = (int)cellDataSort [counter4*11+7];
                                
                                arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(cellSize), motilityResultsHoldCount++;
                                
                                cellSize = (int)cellDataSort [counter4*11+8];
                                
                                arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(cellSize), motilityResultsHoldCount++;
                                
                                cellSize = (int)cellDataSort [counter4*11+9];
                                
                                arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(cellSize), motilityResultsHoldCount++;
                                
                                cellSize = (int)cellDataSort [counter4*11+10];
                                
                                arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(cellSize), motilityResultsHoldCount++;
                                
                                arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(cellNoDisplay), motilityResultsHoldCount++;
                                
                                percentEventIntCount = (int)(cellDataSort [counter4*11+4]*1000);
                                percentEventCount = percentEventIntCount/(double)1000;
                                
                                stringstream extension1;
                                extension1 << percentEventCount;
                                percentString = extension1.str();
                                
                                arrayMotilityResultsHold [motilityResultsHoldCount] = percentString, motilityResultsHoldCount++;
                                
                                percentEventIntCount = (int)(cellDataSort [counter4*11+6]*1000);
                                percentEventCount = percentEventIntCount/(double)1000;
                                
                                stringstream extension2;
                                extension2 << percentEventCount;
                                percentString = extension2.str();
                                
                                arrayMotilityResultsHold [motilityResultsHoldCount] = percentString, motilityResultsHoldCount++;
                            }
                        }
                        
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = " ", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = " ", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = " ", motilityResultsHoldCount++;
                    }
                    else if (motilityTableCategoryHold == 3){
                        if (motilityResultsHoldCount+20 > motilityResultsHoldLimit){
                            string *arrayUpDate = new string [motilityResultsHoldCount+10];
                            
                            for (int counter4 = 0; counter4 < motilityResultsHoldCount; counter4++) arrayUpDate [counter4] = arrayMotilityResultsHold [counter4];
                            
                            delete [] arrayMotilityResultsHold;
                            arrayMotilityResultsHold = new string [motilityResultsHoldLimit+350*10+500];
                            motilityResultsHoldLimit = motilityResultsHoldLimit+350*10+500;
                            
                            for (int counter4 = 0; counter4 < motilityResultsHoldCount; counter4++) arrayMotilityResultsHold [counter4] = arrayUpDate [counter4];
                            delete [] arrayUpDate;
                        }
                        
                        arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(counter2), motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(treatXMin), motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(treatXMan), motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(treatYMin), motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(treatYMan), motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = arrayTableMain [counter2][4], motilityResultsHoldCount++;
                        
                        percentEventIntCount = (int)(treatDataTotal*1000);
                        percentEventCount = percentEventIntCount/(double)1000;
                        
                        stringstream extension1;
                        extension1 << percentEventCount;
                        percentString = extension1.str();
                        
                        arrayMotilityResultsHold [motilityResultsHoldCount] = percentString, motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = " ", motilityResultsHoldCount++;
                    }
                    else if (motilityTableCategoryHold == 4){
                        if (motilityResultsHoldCount+20 > motilityResultsHoldLimit){
                            string *arrayUpDate = new string [motilityResultsHoldCount+10];
                            
                            for (int counter4 = 0; counter4 < motilityResultsHoldCount; counter4++) arrayUpDate [counter4] = arrayMotilityResultsHold [counter4];
                            
                            delete [] arrayMotilityResultsHold;
                            arrayMotilityResultsHold = new string [motilityResultsHoldLimit+350*10+500];
                            motilityResultsHoldLimit = motilityResultsHoldLimit+350*10+500;
                            
                            for (int counter4 = 0; counter4 < motilityResultsHoldCount; counter4++) arrayMotilityResultsHold [counter4] = arrayUpDate [counter4];
                            delete [] arrayUpDate;
                        }
                        
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = arrayTableMain [counter2][4], motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = " ", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = " ", motilityResultsHoldCount++;
                        
                        for (int counter4 = 0; counter4 < lineageDataSortCount/10; counter4++){
                            if (motilityResultsHoldCount+20 > motilityResultsHoldLimit){
                                string *arrayUpDate = new string [motilityResultsHoldCount+10];
                                
                                for (int counter5 = 0; counter5 < motilityResultsHoldCount; counter5++) arrayUpDate [counter5] = arrayMotilityResultsHold [counter5];
                                
                                delete [] arrayMotilityResultsHold;
                                arrayMotilityResultsHold = new string [motilityResultsHoldLimit+350*10+500];
                                motilityResultsHoldLimit = motilityResultsHoldLimit+350*10+500;
                                
                                for (int counter5 = 0; counter5 < motilityResultsHoldCount; counter5++) arrayMotilityResultsHold [counter5] = arrayUpDate [counter5];
                                delete [] arrayUpDate;
                            }
                            
                            lineageNoForDisplay = (int)lineageDataSort [counter4*10];
                            
                            displayData1 = to_string(lineageNoForDisplay);
                            
                            if (displayData1.length() == 1) displayData1 = "L0000"+displayData1;
                            else if (displayData1.length() == 2) displayData1 = "L000"+displayData1;
                            else if (displayData1.length() == 3) displayData1 = "L00"+displayData1;
                            else if (displayData1.length() == 4) displayData1 = "L0"+displayData1;
                            else if (displayData1.length() == 5) displayData1 = "L"+displayData1;
                            
                            arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(counter2), motilityResultsHoldCount++;
                            arrayMotilityResultsHold [motilityResultsHoldCount] = displayData1, motilityResultsHoldCount++;
                            arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                            
                            lineageSize = (int)lineageDataSort [counter4*10+6];
                            
                            arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(lineageSize), motilityResultsHoldCount++;
                            
                            lineageSize = (int)lineageDataSort [counter4*10+7];
                            
                            arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(lineageSize), motilityResultsHoldCount++;
                            
                            lineageSize = (int)lineageDataSort [counter4*10+8];
                            
                            arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(lineageSize), motilityResultsHoldCount++;
                            
                            lineageSize = (int)lineageDataSort [counter4*10+9];
                            
                            arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(lineageSize), motilityResultsHoldCount++;
                            
                            arrayMotilityResultsHold [motilityResultsHoldCount] = displayData1, motilityResultsHoldCount++;
                            
                            percentEventIntCount = (int)(lineageDataSort [counter4*10+2]*1000);
                            percentEventCount = percentEventIntCount/(double)1000;
                            
                            stringstream extension1;
                            extension1 << percentEventCount;
                            percentString = extension1.str();
                            
                            arrayMotilityResultsHold [motilityResultsHoldCount] = percentString, motilityResultsHoldCount++;
                            arrayMotilityResultsHold [motilityResultsHoldCount] = " ", motilityResultsHoldCount++;
                        }
                        
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = " ", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = " ", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = " ", motilityResultsHoldCount++;
                    }
                    else if (motilityTableCategoryHold == 5){
                        if (motilityResultsHoldCount+20 > motilityResultsHoldLimit){
                            string *arrayUpDate = new string [motilityResultsHoldCount+10];
                            
                            for (int counter4 = 0; counter4 < motilityResultsHoldCount; counter4++) arrayUpDate [counter4] = arrayMotilityResultsHold [counter4];
                            
                            delete [] arrayMotilityResultsHold;
                            arrayMotilityResultsHold = new string [motilityResultsHoldLimit+350*10+500];
                            motilityResultsHoldLimit = motilityResultsHoldLimit+350*10+500;
                            
                            for (int counter4 = 0; counter4 < motilityResultsHoldCount; counter4++) arrayMotilityResultsHold [counter4] = arrayUpDate [counter4];
                            delete [] arrayUpDate;
                        }
                        
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = arrayTableMain [counter2][4], motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = " ", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = " ", motilityResultsHoldCount++;
                        
                        lineageNoCheck = 0;
                        
                        for (int counter4 = 0; counter4 < cellDataSortCount/11; counter4++){
                            if (motilityResultsHoldCount+40 > motilityResultsHoldLimit){
                                string *arrayUpDate = new string [motilityResultsHoldCount+10];
                                
                                for (int counter5 = 0; counter5 < motilityResultsHoldCount; counter5++) arrayUpDate [counter5] = arrayMotilityResultsHold [counter5];
                                
                                delete [] arrayMotilityResultsHold;
                                arrayMotilityResultsHold = new string [motilityResultsHoldLimit+350*10+500];
                                motilityResultsHoldLimit = motilityResultsHoldLimit+350*10+500;
                                
                                for (int counter5 = 0; counter5 < motilityResultsHoldCount; counter5++) arrayMotilityResultsHold [counter5] = arrayUpDate [counter5];
                                delete [] arrayUpDate;
                            }
                            
                            lineageNoForDisplay = (int)cellDataSort [counter4*11];
                            
                            displayData1 = to_string(lineageNoForDisplay);
                            
                            if (displayData1.length() == 1) displayData1 = "L0000"+displayData1;
                            else if (displayData1.length() == 2) displayData1 = "L000"+displayData1;
                            else if (displayData1.length() == 3) displayData1 = "L00"+displayData1;
                            else if (displayData1.length() == 4) displayData1 = "L0"+displayData1;
                            else if (displayData1.length() == 5) displayData1 = "L"+displayData1;
                            
                            if (lineageNoCheck == 0 || lineageNoCheck != lineageNoForDisplay){
                                if (lineageNoCheck != 0){
                                    arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                                    arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                                    arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                                    arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                                    arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                                    arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                                    arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                                    arrayMotilityResultsHold [motilityResultsHoldCount] = " ", motilityResultsHoldCount++;
                                    arrayMotilityResultsHold [motilityResultsHoldCount] = " ", motilityResultsHoldCount++;
                                    arrayMotilityResultsHold [motilityResultsHoldCount] = " ", motilityResultsHoldCount++;
                                }
                                
                                lineageNoCheck = lineageNoForDisplay;
                                
                                arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                                arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                                arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                                arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                                arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                                arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                                arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                                arrayMotilityResultsHold [motilityResultsHoldCount] = displayData1, motilityResultsHoldCount++;
                                arrayMotilityResultsHold [motilityResultsHoldCount] = " ", motilityResultsHoldCount++;
                                arrayMotilityResultsHold [motilityResultsHoldCount] = " ", motilityResultsHoldCount++;
                                
                                cellNoDisplay = (int)cellDataSort [counter4*11+1];
                                
                                arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(counter2), motilityResultsHoldCount++;
                                arrayMotilityResultsHold [motilityResultsHoldCount] = displayData1, motilityResultsHoldCount++;
                                arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(cellNoDisplay), motilityResultsHoldCount++;
                                
                                cellSize = (int)cellDataSort [counter4*11+7];
                                
                                arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(cellSize), motilityResultsHoldCount++;
                                
                                cellSize = (int)cellDataSort [counter4*11+8];
                                
                                arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(cellSize), motilityResultsHoldCount++;
                                
                                cellSize = (int)cellDataSort [counter4*11+9];
                                
                                arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(cellSize), motilityResultsHoldCount++;
                                
                                cellSize = (int)cellDataSort [counter4*11+10];
                                
                                arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(cellSize), motilityResultsHoldCount++;
                                
                                arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(cellNoDisplay), motilityResultsHoldCount++;
                                
                                percentEventIntCount = (int)(cellDataSort [counter4*11+3]*1000);
                                percentEventCount = percentEventIntCount/(double)1000;
                                
                                stringstream extension1;
                                extension1 << percentEventCount;
                                percentString = extension1.str();
                                
                                arrayMotilityResultsHold [motilityResultsHoldCount] = percentString, motilityResultsHoldCount++;
                                arrayMotilityResultsHold [motilityResultsHoldCount] = " ", motilityResultsHoldCount++;
                            }
                            else{
                                
                                cellNoDisplay = (int)cellDataSort [counter4*11+1];
                                
                                arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(counter2), motilityResultsHoldCount++;
                                arrayMotilityResultsHold [motilityResultsHoldCount] = displayData1, motilityResultsHoldCount++;
                                arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(cellNoDisplay), motilityResultsHoldCount++;
                                
                                cellSize = (int)cellDataSort [counter4*11+7];
                                
                                arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(cellSize), motilityResultsHoldCount++;
                                
                                cellSize = (int)cellDataSort [counter4*11+8];
                                
                                arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(cellSize), motilityResultsHoldCount++;
                                
                                cellSize = (int)cellDataSort [counter4*11+9];
                                
                                arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(cellSize), motilityResultsHoldCount++;
                                
                                cellSize = (int)cellDataSort [counter4*11+10];
                                
                                arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(cellSize), motilityResultsHoldCount++;
                                
                                arrayMotilityResultsHold [motilityResultsHoldCount] = to_string(cellNoDisplay), motilityResultsHoldCount++;
                                
                                percentEventIntCount = (int)(cellDataSort [counter4*11+3]*1000);
                                percentEventCount = percentEventIntCount/(double)1000;
                                
                                stringstream extension1;
                                extension1 << percentEventCount;
                                percentString = extension1.str();
                                
                                arrayMotilityResultsHold [motilityResultsHoldCount] = percentString, motilityResultsHoldCount++;
                                arrayMotilityResultsHold [motilityResultsHoldCount] = " ", motilityResultsHoldCount++;
                            }
                        }
                        
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = "D", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = " ", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = " ", motilityResultsHoldCount++;
                        arrayMotilityResultsHold [motilityResultsHoldCount] = " ", motilityResultsHoldCount++;
                    }
                    
                    delete [] arrayMotilityBasicInfo;
                    delete [] arrayMotilityDistance;
                    delete [] cellDataSort;
                    delete [] lineageDataSort;
                    delete [] cellNoExtract;
                    delete [] cellNoExtract2;
                    
                    if (motilityAnalysisPerformHold == 0) motilityAnalysisPerformHold = 1;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMotilityTable object:nil];
                }
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Check Time Range"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)displayOptionSet:(id)sender{
    if (motilityTableCategoryHold == 0 || motilityTableCategoryHold == 3){
        if (displayOptionStatus == 0){
            displayOptionStatus = 1;
            [displayStatusDisplay setStringValue:@"Cent"];
        }
        else if (displayOptionStatus == 1){
            displayOptionStatus = 2;
            [displayStatusDisplay setStringValue:@"Orig.+Shift"];
        }
        else if (displayOptionStatus == 2){
            displayOptionStatus = 3;
            [displayStatusDisplay setStringValue:@"Cent.+Shift"];
        }
        else if (displayOptionStatus == 3){
            displayOptionStatus = 0;
            [displayStatusDisplay setStringValue:@"Orig"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Mode Must Be Treat Average/Total"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)createExcelFile:(id)sender{
    if (motilityAnalysisPerformHold == 1 || motilityAnalysisPerformHold == 2){
        string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
        mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Motility";
        mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        DIR *dir;
        struct dirent *dent;
        
        string entry;
        string extractString;
        int maxEntryNo = 0;
        
        dir = opendir(resultSavePath2.c_str());
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("Motility") != -1){
                    extractString = entry.substr(entry.find("MB")+2, entry.find(".txt")-entry.find("MB")-2);
                    
                    if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                }
            }
            
            closedir(dir);
        }
        
        maxEntryNo++;
        
        string path = resultSavePath2+"/Motility-MB"+to_string(maxEntryNo)+".txt";
        
        ofstream oin;
        oin.open(path.c_str(), ios::out | ios::binary);
        
        int *arrayAscIIintData = new int [100], ascIIintDataCount = 0;
        
        ascIIconversion = [[ASCIIconversion alloc] init];
        
        ascIIstring = "Time Start: "+to_string(motilityTimeStartHold);
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
        
        oin.put(9);
        
        ascIIstring = "Time End: "+to_string(motilityTimeEndHold);
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
        
        oin.put(9);
        
        oin.put(13);
        oin.put(10);
        
        for (int counter1 = 0; counter1 < motilityResultsHoldCount/10; counter1++){
            ascIIstring = arrayMotilityResultsHold [counter1*10+7];
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = arrayMotilityResultsHold [counter1*10+8];
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = arrayMotilityResultsHold [counter1*10+9];
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            oin.put(13);
            oin.put(10);
        }
        
        delete [] arrayAscIIintData;
        
        oin.close();
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Perform analysis"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)createExcelFile2:(id)sender{
    if (lineageDataEntryCount != 0){
        if (motilityAnalysisPerformHold == 1 || motilityAnalysisPerformHold == 2){
            if (motilityTimeEndHold > 1 || motilityTimeStartHold < motilityTimeEndHold){
                string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
                mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Motility";
                mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                DIR *dir;
                struct dirent *dent;
                
                string entry;
                string extractString;
                int maxEntryNo = 0;
                
                dir = opendir(resultSavePath2.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("Motility") != -1){
                            extractString = entry.substr(entry.find("MB")+2, entry.find(".txt")-entry.find("MB")-2);
                            
                            if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                        }
                    }
                    
                    closedir(dir);
                }
                
                maxEntryNo++;
                
                string path = resultSavePath2+"/MotilityStat-MB"+to_string(maxEntryNo)+".txt";
                
                ofstream oin;
                oin.open(path.c_str(), ios::out | ios::binary);
                
                int *arrayAscIIintData = new int [100], ascIIintDataCount = 0;
                
                ascIIconversion = [[ASCIIconversion alloc] init];
                
                int timeStart = 0;
                int timeEnd = 0;
                int motilityBasicInfoCount = 0;
                int motilityDistanceCount = 0;
                int cellLineageTempCount = 0;
                int xPositionMotility = 0;
                int yPositionMotility = 0;
                int lingNoHoldMotility = 0;
                int cellNoHoldMotility = 0;
                int dataSetStart = 0;
                int maxLineageNo = 0;
                int cellDataSortCount = 0;
                int lineageDataSortCount = 0;
                int cellNoExtractCount = 0;
                int cellNoExtractCount2 = 0;
                int cellNoFind = 0;
                int terminationFlag = 0;
                int smallestCellNo = 0;
                int smallestCellPosition = 0;
                int percentEventIntCount = 0;
                int dataTemp = 0;
                int timePoint = 0;
                int lineageNoTemp = 0;
                int cellNoTemp = -1;
                int eventType = 0;
                unsigned long typeMarkFound = 0;
                unsigned long currentPosition = 0;
                
                double percentEventCount = 0;
                
                string percentString;
                
                for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
                    if (arraySelectedLing [counter2] == 1){
                        timeStart = motilityTimeStartHold;
                        timeEnd = motilityTimeEndHold;
                        
                        if (timeEnd > arrayTableDetail [counter2][3]) timeEnd = arrayTableDetail [counter2][3];
                        
                        int *arrayMotilityBasicInfo = new int [(arrayLineageDataEntryHold [counter2]/9)*7+100];
                        int *arrayCellLineageTemp = new int [(arrayLineageDataEntryHold [counter2]/9)*9+100];
                        double *arrayMotilityDistance = new double [arrayLineageDataEntryHold [counter2]/9+100];
                        
                        for (unsigned long counter3 = 0; counter3 < (arrayLineageDataEntryHold [counter2]/9)*7+100; counter3++){
                            arrayMotilityBasicInfo [counter3] = 0;
                        }
                        
                        for (unsigned long counter3 = 0; counter3 < (arrayLineageDataEntryHold [counter2]/9)*9+100; counter3++){
                            arrayCellLineageTemp [counter3] = 0;
                        }
                        
                        for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [counter2]/9+100; counter3++){
                            arrayMotilityDistance [counter3] = 0;
                        }
                        
                        for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [counter2]/9; counter3++){
                            if (maxLineageNo < arrayLineageData [counter2][counter3*9+6]) maxLineageNo = arrayLineageData [counter2][counter3*9+6];
                        }
                        
                        int *lineageInfo = new int [maxLineageNo*2+10];
                        
                        for (int counter3 = 0; counter3 < maxLineageNo*2+10; counter3++){
                            lineageInfo [counter3] = 0;
                        }
                        
                        if (activationStatus == 1){
                            timePoint = 0;
                            lineageNoTemp = 0;
                            cellNoTemp = -1;
                            eventType = 0;
                            typeMarkFound = 0;
                            currentPosition = 0;
                            cellLineageTempCount = 0;
                            
                            for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [counter2]/9; counter3++){
                                if ((arrayLineageData [counter2][counter3*9+5] != cellNoTemp || arrayLineageData [counter2][counter3*9+6] != lineageNoTemp) && timePoint == 0){
                                    timePoint = arrayLineageData [counter2][counter3*9+2];
                                    lineageNoTemp = arrayLineageData [counter2][counter3*9+6];
                                    cellNoTemp = arrayLineageData [counter2][counter3*9+5];
                                    eventType = arrayLineageData [counter2][counter3*9+3];
                                    currentPosition = counter3;
                                }
                                else if ((arrayLineageData [counter2][counter3*9+5] != cellNoTemp || arrayLineageData [counter2][counter3*9+6] != lineageNoTemp) && timePoint != 0){
                                    if (typeMarkFound != 0 && counter3-2 != typeMarkFound){
                                        for (unsigned long counter4 = typeMarkFound; counter4 <= counter3-1; counter4++){
                                            arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9], cellLineageTempCount++;
                                            arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+1], cellLineageTempCount++;
                                            arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+2], cellLineageTempCount++;
                                            arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+3], cellLineageTempCount++;
                                            arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+4], cellLineageTempCount++;
                                            arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+5], cellLineageTempCount++;
                                            arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+6], cellLineageTempCount++;
                                            arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+7], cellLineageTempCount++;
                                            arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+8], cellLineageTempCount++;
                                        }
                                        
                                        lineageInfo [arrayLineageData [counter2][(counter3-1)*9+6]*2] = arrayLineageData [counter2][(counter3-1)*9+6];
                                        lineageInfo [arrayLineageData [counter2][(counter3-1)*9+6]*2+1] = 1;
                                    }
                                    else{
                                        
                                        for (unsigned long counter4 = currentPosition; counter4 < counter3; counter4++){
                                            arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9], cellLineageTempCount++;
                                            arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+1], cellLineageTempCount++;
                                            arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+2], cellLineageTempCount++;
                                            arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+3], cellLineageTempCount++;
                                            arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+4], cellLineageTempCount++;
                                            arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+5], cellLineageTempCount++;
                                            arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+6], cellLineageTempCount++;
                                            arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+7], cellLineageTempCount++;
                                            arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+8], cellLineageTempCount++;
                                        }
                                        
                                        if (typeMarkFound != 0 && counter3-2 == typeMarkFound){
                                            lineageInfo [arrayLineageData [counter2][(counter3-1)*9+6]*2] = arrayLineageData [counter2][(counter3-1)*9+6];
                                            lineageInfo [arrayLineageData [counter2][(counter3-1)*9+6]*2+1] = 2;
                                        }
                                        else lineageInfo [arrayLineageData [counter2][(counter3-1)*9+6]*2] = arrayLineageData [counter2][(counter3-1)*9+6];
                                    }
                                    
                                    typeMarkFound = 0;
                                    
                                    timePoint = arrayLineageData [counter2][counter3*9+2];
                                    lineageNoTemp = arrayLineageData [counter2][counter3*9+6];
                                    cellNoTemp = arrayLineageData [counter2][counter3*9+5];
                                    eventType = arrayLineageData [counter2][counter3*9+3];
                                    currentPosition = counter3;
                                }
                                else if (arrayLineageData [counter2][counter3*9+3] == 10 && eventType == 1){
                                    typeMarkFound = counter3;
                                }
                                else if (counter3 == arrayLineageDataEntryHold [counter2]/9-1 && timePoint != 0){
                                    if (typeMarkFound != 0 && counter3-2 != typeMarkFound){
                                        for (unsigned long counter4 = typeMarkFound; counter4 <= counter3-1; counter4++){
                                            arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9], cellLineageTempCount++;
                                            arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+1], cellLineageTempCount++;
                                            arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+2], cellLineageTempCount++;
                                            arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+3], cellLineageTempCount++;
                                            arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+4], cellLineageTempCount++;
                                            arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+5], cellLineageTempCount++;
                                            arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+6], cellLineageTempCount++;
                                            arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+7], cellLineageTempCount++;
                                            arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+8], cellLineageTempCount++;
                                        }
                                        
                                        lineageInfo [arrayLineageData [counter2][(counter3-1)*9+6]*2] = arrayLineageData [counter2][(counter3-1)*9+6];
                                        lineageInfo [arrayLineageData [counter2][(counter3-1)*9+6]*2+1] = 1;
                                    }
                                    else{
                                        
                                        for (unsigned long counter4 = currentPosition; counter4 < counter3; counter4++){
                                            arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9], cellLineageTempCount++;
                                            arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+1], cellLineageTempCount++;
                                            arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+2], cellLineageTempCount++;
                                            arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+3], cellLineageTempCount++;
                                            arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+4], cellLineageTempCount++;
                                            arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+5], cellLineageTempCount++;
                                            arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+6], cellLineageTempCount++;
                                            arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+7], cellLineageTempCount++;
                                            arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [counter2][counter4*9+8], cellLineageTempCount++;
                                        }
                                        
                                        if (typeMarkFound != 0 && counter3-2 == typeMarkFound){
                                            lineageInfo [arrayLineageData [counter2][(counter3-1)*9+6]*2] = arrayLineageData [counter2][(counter3-1)*9+6];
                                            lineageInfo [arrayLineageData [counter2][(counter3-1)*9+6]*2+1] = 2;
                                        }
                                        else lineageInfo [arrayLineageData [counter2][(counter3-1)*9+6]*2] = arrayLineageData [counter2][(counter3-1)*9+6];
                                    }
                                    
                                    typeMarkFound = 0;
                                }
                            }
                            
                            motilityBasicInfoCount = 0;
                            motilityDistanceCount = 0;
                            dataSetStart = 0;
                            
                            for (int counter3 = 0; counter3 < cellLineageTempCount/9; counter3++){
                                if (arrayCellLineageTemp [counter3*9+2] >= timeStart && arrayCellLineageTemp [counter3*9+2] < timeEnd && dataSetStart == 0){
                                    xPositionMotility = arrayCellLineageTemp [counter3*9];
                                    yPositionMotility = arrayCellLineageTemp [counter3*9+1];
                                    
                                    lingNoHoldMotility = arrayCellLineageTemp [counter3*9+6];
                                    cellNoHoldMotility = arrayCellLineageTemp [counter3*9+5];
                                    
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+6], motilityBasicInfoCount++;
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+5], motilityBasicInfoCount++;
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9], motilityBasicInfoCount++;
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+1], motilityBasicInfoCount++;
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+2], motilityBasicInfoCount++;
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+3], motilityBasicInfoCount++;
                                    arrayMotilityDistance [motilityDistanceCount] = 999999999, motilityDistanceCount++;
                                    
                                    dataSetStart = 1;
                                }
                                else if (arrayCellLineageTemp [counter3*9+2] > timeStart && arrayCellLineageTemp [counter3*9+2] < timeEnd && lingNoHoldMotility == arrayCellLineageTemp [counter3*9+6] && cellNoHoldMotility == arrayCellLineageTemp [counter3*9+5] && dataSetStart == 1){
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+6], motilityBasicInfoCount++;
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+5], motilityBasicInfoCount++;
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9], motilityBasicInfoCount++;
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+1], motilityBasicInfoCount++;
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+2], motilityBasicInfoCount++;
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+3], motilityBasicInfoCount++;
                                    
                                    arrayMotilityDistance [motilityDistanceCount] = sqrt((xPositionMotility-arrayCellLineageTemp [counter3*9])*(xPositionMotility-arrayCellLineageTemp [counter3*9])+(yPositionMotility-arrayCellLineageTemp [counter3*9+1])*(yPositionMotility-arrayCellLineageTemp [counter3*9+1])), motilityDistanceCount++;
                                    
                                    xPositionMotility = arrayCellLineageTemp [counter3*9];
                                    yPositionMotility = arrayCellLineageTemp [counter3*9+1];
                                }
                                else if (arrayCellLineageTemp [counter3*9+2] == timeEnd && lingNoHoldMotility == arrayCellLineageTemp [counter3*9+6] && cellNoHoldMotility == arrayCellLineageTemp [counter3*9+5] && dataSetStart == 1){
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+6], motilityBasicInfoCount++;
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+5], motilityBasicInfoCount++;
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9], motilityBasicInfoCount++;
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+1], motilityBasicInfoCount++;
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+2], motilityBasicInfoCount++;
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+3], motilityBasicInfoCount++;
                                    
                                    arrayMotilityDistance [motilityDistanceCount] = sqrt((xPositionMotility-arrayCellLineageTemp [counter3*9])*(xPositionMotility-arrayCellLineageTemp [counter3*9])+(yPositionMotility-arrayCellLineageTemp [counter3*9+1])*(yPositionMotility-arrayCellLineageTemp [counter3*9+1])), motilityDistanceCount++;
                                    
                                    dataSetStart = 0;
                                }
                                else if (arrayCellLineageTemp [counter3*9+2] >= timeStart && arrayCellLineageTemp [counter3*9+2] < timeEnd && (lingNoHoldMotility != arrayCellLineageTemp [counter3*9+6] || cellNoHoldMotility != arrayCellLineageTemp [counter3*9+5]) && dataSetStart == 1){
                                    xPositionMotility = arrayCellLineageTemp [counter3*9];
                                    yPositionMotility = arrayCellLineageTemp [counter3*9+1];
                                    
                                    lingNoHoldMotility = arrayCellLineageTemp [counter3*9+6];
                                    cellNoHoldMotility = arrayCellLineageTemp [counter3*9+5];
                                    
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+6], motilityBasicInfoCount++;
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+5], motilityBasicInfoCount++;
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9], motilityBasicInfoCount++;
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+1], motilityBasicInfoCount++;
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+2], motilityBasicInfoCount++;
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+3], motilityBasicInfoCount++;
                                    arrayMotilityDistance [motilityDistanceCount] = 999999999, motilityDistanceCount++;
                                }
                            }
                        }
                        else{
                            
                            motilityBasicInfoCount = 0;
                            motilityDistanceCount = 0;
                            dataSetStart = 0;
                            
                            for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [counter2]/9; counter3++){
                                if (arrayLineageData [counter2][counter3*9+2] >= timeStart && arrayLineageData [counter2][counter3*9+2] < timeEnd && dataSetStart == 0){
                                    xPositionMotility = arrayLineageData [counter2][counter3*9];
                                    yPositionMotility = arrayLineageData [counter2][counter3*9+1];
                                    
                                    lingNoHoldMotility = arrayLineageData [counter2][counter3*9+6];
                                    cellNoHoldMotility = arrayLineageData [counter2][counter3*9+5];
                                    
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9+6], motilityBasicInfoCount++;
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9+5], motilityBasicInfoCount++;
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9], motilityBasicInfoCount++;
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9+1], motilityBasicInfoCount++;
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9+2], motilityBasicInfoCount++;
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9+3], motilityBasicInfoCount++;
                                    arrayMotilityDistance [motilityDistanceCount] = 999999999, motilityDistanceCount++;
                                    
                                    dataSetStart = 1;
                                }
                                else if (arrayLineageData [counter2][counter3*9+2] > timeStart && arrayLineageData [counter2][counter3*9+2] < timeEnd && lingNoHoldMotility == arrayLineageData [counter2][counter3*9+6] && cellNoHoldMotility == arrayLineageData [counter2][counter3*9+5] && dataSetStart == 1){
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9+6], motilityBasicInfoCount++;
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9+5], motilityBasicInfoCount++;
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9], motilityBasicInfoCount++;
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9+1], motilityBasicInfoCount++;
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9+2], motilityBasicInfoCount++;
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9+3], motilityBasicInfoCount++;
                                    
                                    arrayMotilityDistance [motilityDistanceCount] = sqrt((xPositionMotility-arrayLineageData [counter2][counter3*9])*(xPositionMotility-arrayLineageData [counter2][counter3*9])+(yPositionMotility-arrayLineageData [counter2][counter3*9+1])*(yPositionMotility-arrayLineageData [counter2][counter3*9+1])), motilityDistanceCount++;
                                    
                                    xPositionMotility = arrayLineageData [counter2][counter3*9];
                                    yPositionMotility = arrayLineageData [counter2][counter3*9+1];
                                }
                                else if (arrayLineageData [counter2][counter3*9+2] == timeEnd && lingNoHoldMotility == arrayLineageData [counter2][counter3*9+6] && cellNoHoldMotility == arrayLineageData [counter2][counter3*9+5] && dataSetStart == 1){
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9+6], motilityBasicInfoCount++;
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9+5], motilityBasicInfoCount++;
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9], motilityBasicInfoCount++;
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9+1], motilityBasicInfoCount++;
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9+2], motilityBasicInfoCount++;
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9+3], motilityBasicInfoCount++;
                                    
                                    arrayMotilityDistance [motilityDistanceCount] = sqrt((xPositionMotility-arrayLineageData [counter2][counter3*9])*(xPositionMotility-arrayLineageData [counter2][counter3*9])+(yPositionMotility-arrayLineageData [counter2][counter3*9+1])*(yPositionMotility-arrayLineageData [counter2][counter3*9+1])), motilityDistanceCount++;
                                    
                                    dataSetStart = 0;
                                }
                                else if (arrayLineageData [counter2][counter3*9+2] >= timeStart && arrayLineageData [counter2][counter3*9+2] < timeEnd && (lingNoHoldMotility != arrayLineageData [counter2][counter3*9+6] || cellNoHoldMotility != arrayLineageData [counter2][counter3*9+5]) && dataSetStart == 1){
                                    xPositionMotility = arrayLineageData [counter2][counter3*9];
                                    yPositionMotility = arrayLineageData [counter2][counter3*9+1];
                                    
                                    lingNoHoldMotility = arrayLineageData [counter2][counter3*9+6];
                                    cellNoHoldMotility = arrayLineageData [counter2][counter3*9+5];
                                    
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9+6], motilityBasicInfoCount++;
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9+5], motilityBasicInfoCount++;
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9], motilityBasicInfoCount++;
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9+1], motilityBasicInfoCount++;
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9+2], motilityBasicInfoCount++;
                                    arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [counter2][counter3*9+3], motilityBasicInfoCount++;
                                    arrayMotilityDistance [motilityDistanceCount] = 999999999, motilityDistanceCount++;
                                }
                            }
                        }
                        
                        delete [] arrayCellLineageTemp;
                        
                        //for (int counterA = 0; counterA < motilityBasicInfoCount/6; counterA++){
                        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<< arrayMotilityBasicInfo [counterA*6+counterB];
                        //    cout<<"  arrayMotilityBasicInfo "<<counterA<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < motilityDistanceCount; counterA++){
                        //    cout<<arrayMotilityDistance [counterA] <<" arrayMotilityDistance"<<endl;
                        //}
                        
                        double *cellDataSort = new double [(motilityBasicInfoCount/6)*2+100];
                        cellDataSortCount = 0;
                        
                        double *lineageDataSort = new double [maxLineageNo+100];
                        lineageDataSortCount = 0;
                        
                        int *cellNoExtract = new int [arrayTableDetail [counter2][9]+10];
                        int *cellNoExtract2 = new int [arrayTableDetail [counter2][9]+10];
                        
                        double sumDis = 0;
                        int endCount = 0;
                        
                        for (int counter3 = 1; counter3 <= maxLineageNo; counter3++){
                            cellNoExtractCount = 0;
                            
                            for (int counter4 = 0; counter4 < motilityBasicInfoCount/6; counter4++){
                                if (counter3 == arrayMotilityBasicInfo [counter4*6]){
                                    cellNoFind = 0;
                                    
                                    for (int counter5 = 0; counter5 < cellNoExtractCount; counter5++){
                                        if (cellNoExtract [counter5] == arrayMotilityBasicInfo [counter4*6+1]){
                                            cellNoFind = 1;
                                            break;
                                        }
                                    }
                                    
                                    if (cellNoFind == 0){
                                        cellNoExtract [cellNoExtractCount] = arrayMotilityBasicInfo [counter4*6+1], cellNoExtractCount++;
                                    }
                                }
                            }
                            
                            if (cellNoExtractCount != 0){
                                cellNoExtractCount2 = 0;
                                
                                do{
                                    
                                    terminationFlag = 1;
                                    smallestCellNo = 999999999;
                                    smallestCellPosition = 0;
                                    
                                    for (int counter4 = 0; counter4 < cellNoExtractCount; counter4++){
                                        if (cellNoExtract [counter4] < smallestCellNo && cellNoExtract [counter4] != -2){
                                            smallestCellNo = cellNoExtract [counter4];
                                            smallestCellPosition = counter4;
                                        }
                                    }
                                    
                                    if (smallestCellNo != 999999999){
                                        cellNoExtract2 [cellNoExtractCount2] = cellNoExtract [smallestCellPosition], cellNoExtractCount2++;
                                        cellNoExtract [smallestCellPosition] = -2;
                                    }
                                    else terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                                
                                for (int counter4 = 0; counter4 < cellNoExtractCount2; counter4++){
                                    cellDataSort [cellDataSortCount] = counter3, cellDataSortCount++; //----Ling no
                                    cellDataSort [cellDataSortCount] = cellNoExtract2 [counter4], cellDataSortCount++; //----Cell no
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < cellDataSortCount/2; counterA++){
                        //    for (int counterB = 0; counterB < 2; counterB++) cout<<" "<< to_string(cellDataSort [counterA*2+counterB]);
                        //    cout<<"  cellDataSort "<<counterA<<endl;
                        //}
                        
                        for (int counter3 = 0; counter3 < cellDataSortCount/2; counter3++){
                            cellNoFind = 0;
                            
                            for (int counter4 = 0; counter4 < lineageDataSortCount; counter4++){
                                if (cellDataSort [counter3*2] == lineageDataSort [counter4]){
                                    cellNoFind = 1;
                                    break;
                                }
                            }
                            
                            if (cellNoFind == 0){
                                lineageDataSort [lineageDataSortCount] = cellDataSort [counter3*2], lineageDataSortCount++;
                            }
                        }
                        
                        ascIIstring = "Time Start "+to_string(motilityTimeStartHold);
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                        
                        ascIIstring = "Time End "+to_string(motilityTimeEndHold);
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                        
                        oin.put(13);
                        oin.put(10);
                        
                        if (motilityTableCategoryHold == 0 || motilityTableCategoryHold == 3){
                            ascIIstring = arrayTableMain [counter2][4];
                            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                            
                            oin.put(9);
                            
                            oin.put(13);
                            oin.put(10);
                            
                            for (int counter3 = 0; counter3 < motilityBasicInfoCount/6; counter3++){
                                if (arrayMotilityDistance [counter3] != 999999999){
                                    percentEventIntCount = (int)(arrayMotilityDistance [counter3]*1000);
                                    percentEventCount = percentEventIntCount/(double)1000;
                                    
                                    stringstream extension1;
                                    extension1 << percentEventCount;
                                    percentString = extension1.str();
                                    
                                    ascIIstring = percentString;
                                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                    
                                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                    
                                    oin.put(9);
                                }
                            }
                            
                            oin.put(13);
                            oin.put(10);
                            
                            oin.put(13);
                            oin.put(10);
                            
                            ascIIstring = "Motility per time per cell";
                            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                            
                            oin.put(9);
                            
                            oin.put(13);
                            oin.put(10);
                            
                            oin.put(13);
                            oin.put(10);
                            
                            double totalMotilityPerTime = 0;
                            
                            int cellCount = 0;
                            
                            for (int counter3 = motilityTimeStartHold; counter3 <= motilityTimeEndHold; counter3++){
                                totalMotilityPerTime = 0;
                                
                                cellCount = 0;
                                
                                for (int counter4 = 0; counter4 < motilityBasicInfoCount/6; counter4++){
                                    if (arrayMotilityDistance [counter4] != 999999999){
                                        if (arrayMotilityBasicInfo [counter4*6+4] == counter3){
                                            totalMotilityPerTime = totalMotilityPerTime+arrayMotilityDistance [counter4];
                                            cellCount++;
                                        }
                                    }
                                }
                                
                                ascIIstring = to_string(counter3);
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                
                                oin.put(9);
                                
                                percentEventCount = totalMotilityPerTime/(double)cellCount;
                                
                                stringstream extension1;
                                extension1 << percentEventCount;
                                percentString = extension1.str();
                                
                                ascIIstring = percentString;
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                
                                oin.put(9);
                                
                                oin.put(13);
                                oin.put(10);
                            }
                            
                            oin.put(13);
                            oin.put(10);
                            
                            oin.put(13);
                            oin.put(10);
                        }
                        else if (motilityTableCategoryHold == 1 || motilityTableCategoryHold == 4){
                            ascIIstring = arrayTableMain [counter2][4];
                            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                            
                            oin.put(9);
                            
                            oin.put(13);
                            oin.put(10);
                            
                            for (int counter3 = 0; counter3 < lineageDataSortCount; counter3++){
                                dataTemp = (int)lineageDataSort [counter3];
                                
                                ascIIstring = "Lineage "+to_string(dataTemp);
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                
                                oin.put(9);
                                
                                for (int counter4 = 0; counter4 < motilityDistanceCount; counter4++){
                                    if (arrayMotilityDistance [counter4] != 999999999 && lineageDataSort [counter3] == arrayMotilityBasicInfo [counter4*6]){
                                        percentEventIntCount = (int)(arrayMotilityDistance [counter4]*1000);
                                        percentEventCount = percentEventIntCount/(double)1000;
                                        
                                        stringstream extension1;
                                        extension1 << percentEventCount;
                                        percentString = extension1.str();
                                        
                                        ascIIstring = percentString;
                                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                        
                                        for (int counter5 = 0; counter5 < ascIIintDataCount; counter5++) oin.put((char)arrayAscIIintData [counter5]);
                                        
                                        oin.put(9);
                                    }
                                }
                                
                                oin.put(13);
                                oin.put(10);
                            }
                            
                            oin.put(13);
                            oin.put(10);
                        }
                        else if (motilityTableCategoryHold == 2 || motilityTableCategoryHold == 5){
                            ascIIstring = arrayTableMain [counter2][4];
                            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                            
                            oin.put(9);
                            
                            oin.put(13);
                            oin.put(10);
                            
                            for (int counter3 = 0; counter3 < cellDataSortCount/2; counter3++){
                                dataTemp = (int)cellDataSort [counter3*2];
                                ascIIstring = "Lineage "+to_string(dataTemp)+" Cell";
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                
                                oin.put(9);
                                
                                for (int counter4 = 0; counter4 < motilityDistanceCount; counter4++){
                                    if (arrayMotilityDistance [counter4] != 999999999 && cellDataSort [counter3*2] == arrayMotilityBasicInfo [counter4*6] && cellDataSort [counter3*2+1] == arrayMotilityBasicInfo [counter4*6+1]){
                                        percentEventIntCount = (int)(arrayMotilityDistance [counter4]*1000);
                                        percentEventCount = percentEventIntCount/(double)1000;
                                        
                                        stringstream extension1;
                                        extension1 << percentEventCount;
                                        percentString = extension1.str();
                                        
                                        ascIIstring = percentString;
                                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                        
                                        for (int counter5 = 0; counter5 < ascIIintDataCount; counter5++) oin.put((char)arrayAscIIintData [counter5]);
                                        
                                        oin.put(9);
                                    }
                                }
                                
                                oin.put(13);
                                oin.put(10);
                            }
                            
                            oin.put(13);
                            oin.put(10);
                            
                            oin.put(13);
                            oin.put(10);
                            
                            for (int counter3 = 0; counter3 < cellDataSortCount/2; counter3++){
                                dataTemp = (int)cellDataSort [counter3*2];
                                ascIIstring = "Lineage "+to_string(dataTemp)+" Cell Accumulation";
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                
                                oin.put(9);
                                
                                sumDis = 0;
                                
                                for (int counter4 = 0; counter4 < motilityDistanceCount; counter4++){
                                    if (arrayMotilityDistance [counter4] != 999999999 && cellDataSort [counter3*2] == arrayMotilityBasicInfo [counter4*6] && cellDataSort [counter3*2+1] == arrayMotilityBasicInfo [counter4*6+1]){
                                        percentEventIntCount = (int)(arrayMotilityDistance [counter4]*1000);
                                        percentEventCount = percentEventIntCount/(double)1000;
                                        
                                        sumDis = sumDis+percentEventCount;
                                        
                                        stringstream extension1;
                                        extension1 << sumDis;
                                        percentString = extension1.str();
                                        
                                        ascIIstring = percentString;
                                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                        
                                        for (int counter5 = 0; counter5 < ascIIintDataCount; counter5++) oin.put((char)arrayAscIIintData [counter5]);
                                        
                                        oin.put(9);
                                    }
                                }
                                
                                oin.put(13);
                                oin.put(10);
                                
                                oin.put(13);
                                oin.put(10);
                            }
                            
                            if (selectCutLevelStatus == 1 && selectCutLevelHold >= 1){
                                for (int counter3 = 0; counter3 < cellDataSortCount/2; counter3++){
                                    dataTemp = (int)cellDataSort [counter3*2];
                                    ascIIstring = "Lineage "+to_string(dataTemp)+" Larger than "+to_string(selectCutLevelHold);
                                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                    
                                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                    
                                    oin.put(9);
                                    
                                    for (int counter4 = 0; counter4 < motilityDistanceCount; counter4++){
                                        if (arrayMotilityDistance [counter4] != 999999999 && cellDataSort [counter3*2] == arrayMotilityBasicInfo [counter4*6] && cellDataSort [counter3*2+1] == arrayMotilityBasicInfo [counter4*6+1]){
                                            percentEventIntCount = (int)(arrayMotilityDistance [counter4]*1000);
                                            percentEventCount = percentEventIntCount/(double)1000;
                                            
                                            if (percentEventCount >= selectCutLevelHold){
                                                stringstream extension1;
                                                extension1 << percentEventCount;
                                                percentString = extension1.str();
                                                
                                                ascIIstring = percentString;
                                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                                
                                                for (int counter5 = 0; counter5 < ascIIintDataCount; counter5++) oin.put((char)arrayAscIIintData [counter5]);
                                                
                                                oin.put(9);
                                            }
                                        }
                                    }
                                    
                                    oin.put(13);
                                    oin.put(10);
                                    
                                    oin.put(13);
                                    oin.put(10);
                                }
                            }
                            
                            for (int counter3 = 0; counter3 < cellDataSortCount/2; counter3++){
                                dataTemp = (int)cellDataSort [counter3*2];
                                ascIIstring = "Lineage "+to_string(dataTemp)+" Cell End Time";
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                
                                oin.put(9);
                                
                                endCount = 0;
                                
                                for (int counter4 = 0; counter4 < motilityDistanceCount; counter4++){
                                    if (arrayMotilityDistance [counter4] != 999999999 && cellDataSort [counter3*2] == arrayMotilityBasicInfo [counter4*6] && cellDataSort [counter3*2+1] == arrayMotilityBasicInfo [counter4*6+1]){
                                        endCount++;
                                    }
                                }
                                
                                ascIIstring = to_string(endCount);
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter5 = 0; counter5 < ascIIintDataCount; counter5++) oin.put((char)arrayAscIIintData [counter5]);
                                
                                oin.put(13);
                                oin.put(10);
                                
                                oin.put(13);
                                oin.put(10);
                            }
                            
                            if (selectTypeStatus != 0){
                                string cutType;
                                
                                if (selectTypeStatus == 1) cutType = "CD";
                                else if (selectTypeStatus == 2) cutType = "MD";
                                else if (selectTypeStatus == 3) cutType = "CF";
                                else if (selectTypeStatus == 4) cutType = "CD+MD";
                                else if (selectTypeStatus == 5) cutType = "CD+CF";
                                else if (selectTypeStatus == 6) cutType = "MD+CF";
                                else if (selectTypeStatus == 7) cutType = "CD+MD+CF";
                                else if (selectTypeStatus == 8) cutType = "BD";
                                
                                int dataTemp2 = 0;
                                int typeFind = 0;
                                
                                for (int counter3 = 0; counter3 < cellDataSortCount/2; counter3++){
                                    dataTemp = (int)cellDataSort [counter3*2];
                                    dataTemp2 = (int)cellDataSort [counter3*2+1];
                                    ascIIstring = "Lineage "+to_string(dataTemp)+" Cell"+to_string(dataTemp2)+" "+cutType;
                                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                    
                                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                    
                                    oin.put(9);
                                    
                                    for (int counter4 = 0; counter4 < motilityDistanceCount; counter4++){
                                        if (selectTypeStatus == 1){
                                            if (arrayMotilityDistance [counter4] != 999999999 && cellDataSort [counter3*2] == arrayMotilityBasicInfo [counter4*6] && cellDataSort [counter3*2+1] == arrayMotilityBasicInfo [counter4*6+1] && arrayMotilityBasicInfo [counter4*6] == 7){
                                                typeFind = 1;
                                            }
                                            else  if (selectTypeStatus == 2){
                                                if (arrayMotilityDistance [counter4] != 999999999 && cellDataSort [counter3*2] == arrayMotilityBasicInfo [counter4*6] && cellDataSort [counter3*2+1] == arrayMotilityBasicInfo [counter4*6+1] && (arrayMotilityBasicInfo [counter4*6] == 42 || arrayMotilityBasicInfo [counter4*6] == 52)){
                                                    typeFind = 1;
                                                }
                                            }
                                            else  if (selectTypeStatus == 3){
                                                if (arrayMotilityDistance [counter4] != 999999999 && cellDataSort [counter3*2] == arrayMotilityBasicInfo [counter4*6] && cellDataSort [counter3*2+1] == arrayMotilityBasicInfo [counter4*6+1] && (arrayMotilityBasicInfo [counter4*6] == 91)){
                                                    typeFind = 1;
                                                }
                                            }
                                            else  if (selectTypeStatus == 4){
                                                if (arrayMotilityDistance [counter4] != 999999999 && cellDataSort [counter3*2] == arrayMotilityBasicInfo [counter4*6] && cellDataSort [counter3*2+1] == arrayMotilityBasicInfo [counter4*6+1] && (arrayMotilityBasicInfo [counter4*6] == 42 || arrayMotilityBasicInfo [counter4*6] == 52 || arrayMotilityBasicInfo [counter4*6] == 7)){
                                                    typeFind = 1;
                                                }
                                            }
                                            else  if (selectTypeStatus == 5){
                                                if (arrayMotilityDistance [counter4] != 999999999 && cellDataSort [counter3*2] == arrayMotilityBasicInfo [counter4*6] && cellDataSort [counter3*2+1] == arrayMotilityBasicInfo [counter4*6+1] && (arrayMotilityBasicInfo [counter4*6] == 7 || arrayMotilityBasicInfo [counter4*6] == 91)){
                                                    typeFind = 1;
                                                }
                                            }
                                            else  if (selectTypeStatus == 6){
                                                if (arrayMotilityDistance [counter4] != 999999999 && cellDataSort [counter3*2] == arrayMotilityBasicInfo [counter4*6] && cellDataSort [counter3*2+1] == arrayMotilityBasicInfo [counter4*6+1] && (arrayMotilityBasicInfo [counter4*6] == 42 || arrayMotilityBasicInfo [counter4*6] == 52 || arrayMotilityBasicInfo [counter4*6] == 91)){
                                                    typeFind = 1;
                                                }
                                            }
                                            else  if (selectTypeStatus == 7){
                                                if (arrayMotilityDistance [counter4] != 999999999 && cellDataSort [counter3*2] == arrayMotilityBasicInfo [counter4*6] && cellDataSort [counter3*2+1] == arrayMotilityBasicInfo [counter4*6+1] && (arrayMotilityBasicInfo [counter4*6] == 42 || arrayMotilityBasicInfo [counter4*6] == 52 || arrayMotilityBasicInfo [counter4*6] == 91 || arrayMotilityBasicInfo [counter4*6] == 7)){
                                                    typeFind = 1;
                                                }
                                            }
                                            else  if (selectTypeStatus == 8){
                                                if (arrayMotilityDistance [counter4] != 999999999 && cellDataSort [counter3*2] == arrayMotilityBasicInfo [counter4*6] && cellDataSort [counter3*2+1] == arrayMotilityBasicInfo [counter4*6+1] && (arrayMotilityBasicInfo [counter4*6] == 32)){
                                                    typeFind = 1;
                                                }
                                            }
                                        }
                                    }
                                    
                                    if (typeFind == 1){
                                        for (int counter4 = 0; counter4 < motilityDistanceCount; counter4++){
                                            if (arrayMotilityDistance [counter4] != 999999999 && cellDataSort [counter3*2] == arrayMotilityBasicInfo [counter4*6] && cellDataSort [counter3*2+1] == arrayMotilityBasicInfo [counter4*6+1]){
                                                percentEventIntCount = (int)(arrayMotilityDistance [counter4]*1000);
                                                percentEventCount = percentEventIntCount/(double)1000;
                                                
                                                stringstream extension1;
                                                extension1 << percentEventCount;
                                                percentString = extension1.str();
                                                
                                                ascIIstring = percentString;
                                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                                
                                                for (int counter5 = 0; counter5 < ascIIintDataCount; counter5++) oin.put((char)arrayAscIIintData [counter5]);
                                                
                                                oin.put(9);
                                            }
                                        }
                                        
                                        oin.put(13);
                                        oin.put(10);
                                    }
                                    
                                    oin.put(13);
                                    oin.put(10);
                                }
                            }
                            
                            oin.put(13);
                            oin.put(10);
                        }
                        
                        if (activationStatus == 1){
                            ascIIstring = "Lineage information";
                            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                            
                            oin.put(9);
                            
                            oin.put(13);
                            oin.put(10);
                            
                            for (int counter3 = 1; counter3 <= maxLineageNo; counter3++){
                                ascIIstring = to_string (lineageInfo [counter3*2]);
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                
                                oin.put(9);
                                
                                if (lineageInfo [counter3*2+1] == 0){
                                    ascIIstring = "No activation";
                                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                    
                                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                    
                                    oin.put(9);
                                }
                                else if (lineageInfo [counter3*2+1] == 1){
                                    ascIIstring = "Activation";
                                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                    
                                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                    
                                    oin.put(9);
                                }
                                else if (lineageInfo [counter3*2+1] == 2){
                                    ascIIstring = "Dead cell";
                                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                    
                                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                    
                                    oin.put(9);
                                }
                                
                                oin.put(13);
                                oin.put(10);
                            }
                            
                            oin.put(13);
                            oin.put(10);
                        }
                        
                        timePoint = 0;
                        lineageNoTemp = 0;
                        cellNoTemp = -1;
                        
                        int currentXPosition = 0;
                        int currentYPosition = 0;
                        double distanseCal = 0;
                        double accumulate = 0;
                        
                        for (int counter3 = 0; counter3 < motilityBasicInfoCount/6; counter3++){
                            if ((arrayMotilityBasicInfo [counter3*6+1] != cellNoTemp || arrayMotilityBasicInfo [counter3*6] != lineageNoTemp) && timePoint == 0){
                                timePoint = arrayMotilityBasicInfo [counter3*6+4];
                                lineageNoTemp = arrayMotilityBasicInfo [counter3*6];
                                cellNoTemp = arrayMotilityBasicInfo [counter3*6+1];
                                currentXPosition = arrayMotilityBasicInfo [counter3*6+2];
                                currentYPosition = arrayMotilityBasicInfo [counter3*6+3];
                                arrayMotilityBasicInfo [counter3*6+5] = 0;
                                accumulate = 0;
                            }
                            else if (arrayMotilityBasicInfo [counter3*6+1] == cellNoTemp && arrayMotilityBasicInfo [counter3*6] == lineageNoTemp && timePoint != 0){
                                distanseCal = sqrt((currentXPosition-arrayMotilityBasicInfo [counter3*6+2])*(currentXPosition-arrayMotilityBasicInfo [counter3*6+2])+(currentYPosition-arrayMotilityBasicInfo [counter3*6+3])*(currentYPosition-arrayMotilityBasicInfo [counter3*6+3]));
                                
                                accumulate = accumulate+(int)(round(distanseCal));
                                
                                arrayMotilityBasicInfo [counter3*6+5] = (int)accumulate;
                            }
                            else if ((arrayMotilityBasicInfo [counter3*6+1] != cellNoTemp || arrayMotilityBasicInfo [counter3*6] != lineageNoTemp) && timePoint != 0){
                                timePoint = arrayMotilityBasicInfo [counter3*6+4];
                                lineageNoTemp = arrayMotilityBasicInfo [counter3*6];
                                cellNoTemp = arrayMotilityBasicInfo [counter3*6+1];
                                currentXPosition = arrayMotilityBasicInfo [counter3*6+2];
                                currentYPosition = arrayMotilityBasicInfo [counter3*6+3];
                                arrayMotilityBasicInfo [counter3*6+5] = 0;
                                
                                accumulate = 0;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < motilityBasicInfoCount/6; counterA++){
                        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<< arrayMotilityBasicInfo [counterA*6+counterB];
                        //    cout<<"  arrayMotilityBasicInfo "<<counterA<<endl;
                        //}
                        
                        ascIIstring = "Lineage no ";
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                        
                        ascIIstring = "Cell no ";
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                        
                        ascIIstring = "Accumulate distance ";
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                        
                        oin.put(13);
                        oin.put(10);
                        
                        for (int counter3 = 0; counter3 < motilityBasicInfoCount/6; counter3++){
                                ascIIstring = to_string(arrayMotilityBasicInfo [counter3*6]);
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                
                                oin.put(9);
                                
                                
                                
                                ascIIstring = to_string(arrayMotilityBasicInfo [counter3*6+1]);
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                
                                oin.put(9);
                                
                                ascIIstring = to_string(arrayMotilityBasicInfo [counter3*6+5]);
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                
                                oin.put(9);
                                
                                oin.put(13);
                                oin.put(10);
                        }
                        
                        delete [] lineageInfo;
                        
                        delete [] arrayMotilityBasicInfo;
                        delete [] arrayMotilityDistance;
                        delete [] cellDataSort;
                        delete [] lineageDataSort;
                        delete [] cellNoExtract;
                        delete [] cellNoExtract2;
                    }
                }
                
                oin.close();
                
                delete [] arrayAscIIintData;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Check Time Range"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Perform analysis"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)activationPoint:(id)sender{
    if (lineageDataEntryCount != 0){
        if (activationStatus == 0){
            activationStatus = 1;
            [activationPointDisplay setStringValue:@"On"];
        }
        else{
            
            activationStatus = 0;
            [activationPointDisplay setStringValue:@"Off"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)cutLevelSet:(id)sender{
    if (lineageDataEntryCount != 0){
        if (selectCutLevelStatus == 0){
            selectCutLevelStatus = 1;
            [cutLevelStatusDisplay setStringValue:@"On"];
        }
        else{
            
            selectCutLevelStatus = 0;
            [cutLevelStatusDisplay setStringValue:@"Off"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)cutTypeSet:(id)sender{
    if (lineageDataEntryCount != 0){
        if (selectTypeStatus == 0){
            selectTypeStatus = 1;
            [cutLevelTypeDisplay setStringValue:@"CD"];
        }
        else if (selectTypeStatus == 1){
            selectTypeStatus = 2;
            [cutLevelTypeDisplay setStringValue:@"MD"];
        }
        else if (selectTypeStatus == 2){
            selectTypeStatus = 3;
            [cutLevelTypeDisplay setStringValue:@"CF"];
        }
        else if (selectTypeStatus == 3){
            selectTypeStatus = 4;
            [cutLevelTypeDisplay setStringValue:@"CD+MD"];
        }
        else if (selectTypeStatus == 4){
            selectTypeStatus = 5;
            [cutLevelTypeDisplay setStringValue:@"CD+CF"];
        }
        else if (selectTypeStatus == 5){
            selectTypeStatus = 6;
            [cutLevelTypeDisplay setStringValue:@"MD+CF"];
        }
        else if (selectTypeStatus == 6){
            selectTypeStatus = 7;
            [cutLevelTypeDisplay setStringValue:@"CD+MD+CF"];
        }
        else if (selectTypeStatus == 7){
            selectTypeStatus = 8;
            [cutLevelTypeDisplay setStringValue:@"BD"];
        }
        else if (selectTypeStatus == 8){
            selectTypeStatus = 0;
            [cutLevelTypeDisplay setStringValue:@"Off"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)lineWidthSet:(id)sender{
    if (lingLineWidthMortHold == 5){
        lingLineWidthMortHold = 1;
        [lineWidthSetDisplay setStringValue:@"x1"];
    }
    else if (lingLineWidthMortHold == 1){
        lingLineWidthMortHold = 2;
        [lineWidthSetDisplay setStringValue:@"x2"];
    }
    else if (lingLineWidthMortHold == 2){
        lingLineWidthMortHold = 3;
        [lineWidthSetDisplay setStringValue:@"x3"];
    }
    else if (lingLineWidthMortHold == 3){
        lingLineWidthMortHold = 4;
        [lineWidthSetDisplay setStringValue:@"x4"];
    }
    else if (lingLineWidthMortHold == 4){
        lingLineWidthMortHold = 5;
        [lineWidthSetDisplay setStringValue:@"x5"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)lineWidthDisplaySet:(id)sender{
    if (lingLineWidthDisplayMortHold == 5){
        lingLineWidthDisplayMortHold = 1;
        [lineWidthSetWindowDisplay setStringValue:@"x1"];
    }
    else if (lingLineWidthDisplayMortHold == 1){
        lingLineWidthDisplayMortHold = 2;
        [lineWidthSetWindowDisplay setStringValue:@"x2"];
    }
    else if (lingLineWidthDisplayMortHold == 2){
        lingLineWidthDisplayMortHold = 3;
        [lineWidthSetWindowDisplay setStringValue:@"x3"];
    }
    else if (lingLineWidthDisplayMortHold == 3){
        lingLineWidthDisplayMortHold = 4;
        [lineWidthSetWindowDisplay setStringValue:@"x4"];
    }
    else if (lingLineWidthDisplayMortHold == 4){
        lingLineWidthDisplayMortHold = 5;
        [lineWidthSetWindowDisplay setStringValue:@"x5"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(void)reDisplayWindow{
    if (motilityOperation == 3){
        [motilityWindow makeKeyAndOrderFront:nil];
        motilityOperation = 1;
        [motilityTimer invalidate];
    }
}

-(IBAction)closeWindow:(id)sender{
    [motilityWindow orderOut:nil];
    motilityOperation = 2;
    motilityTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToMotilityController object:nil];
}

@end
