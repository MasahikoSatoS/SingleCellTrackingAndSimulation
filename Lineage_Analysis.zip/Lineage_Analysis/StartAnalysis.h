//
//  StartAnalysis.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 10/22/16.
//
//

#ifndef STARTANALYSIS_H
#define STARTANALYSIS_H
#import "Controller.h"
#endif

@interface StartAnalysis : NSObject{
}

-(IBAction)cellLineageList:(id)sender;
-(IBAction)growthCurve:(id)sender;
-(IBAction)cellDivision:(id)sender;
-(IBAction)doublingTime:(id)sender;
-(IBAction)categoryAnalysis:(id)sender;
-(IBAction)progenyAnalysis:(id)sender;
-(IBAction)trimMerge:(id)sender;
-(IBAction)eventAnalysis:(id)sender;
-(IBAction)lineageSelect:(id)sender;
-(IBAction)mainWindowMagSet:(id)sender;
-(IBAction)doubCompSet:(id)sender;
-(IBAction)motilitySet:(id)sender;
-(IBAction)simulationSet:(id)sender;

@end
