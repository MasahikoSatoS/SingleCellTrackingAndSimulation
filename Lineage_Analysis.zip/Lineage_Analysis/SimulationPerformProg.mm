//
//  SimulationPerformProg.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2020-12-08.
//

#import "SimulationPerformProg.h"

@implementation SimulationPerformProg

-(void)progPerform:(int)growthCycleMid :(int)growthCycleProgEnd :(int)growthCycleProgEnd2{
    int growthCycleBase = growthCycleProgEnd2;
    
    durationStart = growthCycleProgEnd;
    durationEnd = growthCycleProgEnd2;
    baseMidHold = growthCycleMid;
    
    expandFirstDVList = new int [10];
    expandFirstDVListCount = 0;
    expandDoubLingDoubBD = new int [10];
    expandDoubLingDoubBDCount = 0;
    expandDoubLingDoubTD = new int [10];
    expandDoubLingDoubTDCount = 0;
    expandDoubLingDoubCF = new int [101];
    expandDoubLingDoubCFCount = 0;
    
    expandBDCD = new int [10];
    expandBDCDCount = 0;
    expandBDCF = new int [10];
    expandBDCFCount = 0;
    expandNonCD = new int [10];
    expandNonCDCount = 0;
    expandBDCFCD = new int [10];
    expandBDCFCDCount = 0;
    
    expandTDCF = new int [10];
    expandTDCFCount = 0;
    expandTDCFCD = new int [10];
    expandTDCFCDCount = 0;
    expandTDCD = new int [10];
    expandTDCDCount = 0;
    
    firstEventList = new int [10];
    secondEventBDList = new int [10];
    secondEventBDCFList = new int [10];
    secondEventTDList = new int [10];
    secondEventTDCFList = new int [10];
    
    //----Temp lineage data----
    //1. Time
    //2. X
    //3. Y
    //4. Event
    //5. Partner cell No
    //6. Cell No
    //7. Ling No
    //8. Partner Ling No
    //9. Color paint
    
    //Max array size ~550000000000000000
    
    //----Create lineage data----
    int randInit = 0;
    int extendEnd = 0;
    int newCellNumber1 = 0;
    int newCellNumber2 = 0;
    int newCellNumber3 = 0;
    
    unsigned long tempListOfCellsCount = 0;
    unsigned long tempListOfCellsLimit = 0;
    
    //----tempListOfCells----
    //1. Ling no
    //2. Parent cell No
    //3. Cell No 1
    //4. Cell No 2
    //5. Cell No 3
    //6. Event
    //7. Doubling time
    
    int markingFlag = 0;
    string cellNumberExtract;
    string lineageNumberExtract;
    string newExtensionEntryNo;
    string digitExtract;
    
    //for (int counterA = 0; counterA < activeCellStatusListCount/12; counterA++){
    //    for (int counterB = 0; counterB < 12; counterB++) cout<<" "<<activeCellStatusList [counterA*14+counterB];
    //    cout<<" activeCellStatusList "<<counterA<<endl;
    //}
    
    //----Entry the first round data to the "activeCellStatusList"----
    //1. Cell no
    //2. Sib Cell no1
    //3. Sib Cell no2
    //4. Ling no
    //5. Doubling Time:
    //   First round, Start 1 and assigning Doubling time, or use initial length to an Event
    //   The first round: use T. BD. Following cycle: If TD flag is ON, use T TD.
    //   Doubling time limits are adjusted based on the doubling time of the previous event; variations are determined using Ling data.
    
    //6. Determine end events based on the frequency of BD, TD, CD, CF, and nonDiv events
    //   First round, apply Non-Div (no growth)--apply recovery % (recovery %, use once, remaining ones are non growing till the end or CD, use nonDiv CD parameter)
    //   First round (remaining): Determine based on BD, TD, nonDivCD frequency.
    //   Following round: Determine based on BD, TD, CF frequency. Check CD Event bias (determined based on the events occurred in a cell)
    //   If TD-BD count ON, and TD-BD limit set, reduce the BD chance 1/3
    //   End Event Type mark: BD:1/7(BD for recovery), TD:2, CD:3, NonDiv: 4 (if no recovery applies, set 5), CF: 6, Reaches Max division: 9
    //   Termination events are determined by the frequency of TD-CF, TD-BD, TD-TD, and TD-CD. Exclude TD and BD if TD is the second occurrence.
    //   Termination events are set based on the frequencies of TD-CF-BD, TD-CF-TD, and TD-CF-CD. If this is the second TD, exclude TD and BD.
    
    //7. Use Process Flag for event type determination and to hold the fusion partner cell number during fusion events
    
    //8. TD count
    
    //9.Set a flag if a TD-TD event occurs
    //10.Track TD-BD occurrences and decrement the count with each subsequent BD event. Remove BD suppression when count reaches zero
    //11. Parent Cell no.
    //12. Previous double time
    
    //----Summary of Expand and % arrays----
    //ExpandFirstDVList
    //ExpandDoubLingDoubBD
    //ExpandDoubLingDoubTD
    //ExpandDoubLingDoubCD
    
    //ExpandBDCD
    //ExpandBDCF
    //ExpandNonCD
    //ExpandBDCFCD
    
    //ExpandTDCF
    //ExpandTDCFCD
    //ExpandTDCD
    
    //FirstEventList; percentBD //1, percentTD //2, percentCD //3, nonDivPercent //4
    //SecondEventBDList; percentBD //1, percentTD //2, percentBDCD //5, percentBDCF //6
    //SecondEventBDCFList; percentBDCFBD //7, percentBDCFTD //8, percentBDCFCD //9
    //SecondEventTDList; percentTDCF //10, percentTDBD //11, percentTDTD //12, percentTDCD //13
    //SecondEventTDCFList; percentTDCFBD //14, percentTDCFTD //15, percentTDCFCD //16
    
    //SimProcessDataHold [57+2] = 3; TD-BD suppress
    //SimProcessDataHold [60+2] = nonDivLing;
    //SimProcessDataHold [63+2] = recoveryGR;
    //SimProcessDataHold [66+2] = recoveryCalculationPercentHold;
    //SimProcessDataHold [69+2] = totalNumberOfDiv;
    //SimProcessDataHold [72+2] = numberOfLing;
    //SimProcessDataHold [75+2] = timePointMax;
    
    //cout<<countBD<<" "<<countTD<<" "<<countCD<<" "<<countCF<<" count"<<endl;
    
    //for (int counterA = 0; counterA < 100; counterA++){
    //    cout<<counterA<<" "<<secondEventTDList [counterA]<<" SecondTD"<<endl;
    //}
    
    //for (int counterA = 0; counterA < activeCellStatusListCount/12; counterA++){
    //    for (int counterB = 0; counterB < 12; counterB++) cout<<" "<<activeCellStatusList [counterA*14+counterB];
    //    cout<<" activeCellStatusList "<<counterA<<endl;
    //}
    
    int *activeCellStatusListHold = new int [activeCellStatusListCount+10];
    int activeCellStatusListHoldCount = 0;
    
    for (int counter1 = 0; counter1 < activeCellStatusListCount; counter1++) activeCellStatusListHold [activeCellStatusListHoldCount] = activeCellStatusList [counter1], activeCellStatusListHoldCount++;
    
    //----Continue the creation of lineages until the "activeCellStatusList" becomes 0. Determine end event type, enter to cell lineage data, and update "activeCellStatusList" ----
    int terminationFlag = 0;
    int lowestValue = 0;
    int highestValue = 0;
    int eventCount = 0;
    int eventType = 0;
    int loopCheck = 0;
    int siblingFusionCheck1 = 0;
    int siblingFusionCheck2 = 0;
    int siblingFusionDoub1 = 0;
    int siblingFusionDoub2 = 0;
    int siblingFusionDoubLarge = 0;
    int siblingCellNo1 = 0;
    int siblingCellNo2 = 0;
    int cellDoubLimitCheck = 0;
    int siblingCellPosition1 = 0;
    int siblingCellPosition2 = 0;
    int siblingCellPositionSelect = 0;
    int siblingCellNoSelect = 0;
    int siblingCellDoubSelect = 0;
    int lineageAddTempCount = 0;
    int lineageAddTempLimit = 0;
    int parentTDCount = 0;
    int parentTDTD = 0;
    int parentTDBD = 0;
    int fusionCount = 0;
    int reachMaxDivision = 1000000000;
    int timeKeep = 0;
    int arrayOverflow = 0;
    int newLimit = 0;
    int startPositionListCount = 0;
    int cellNoFusionCheckHold = 0;
    int missingPartnerCheck = 0;
    int selectChange = 0;
    int firstTimeAssignment = 0;
    int loopCount = 0;
    int terminate2 = 0;
    int cellNoForSummary = 0;
    int lingNoForSummary = 0;
    int fusionForSummary = 0;
    int cycleMaxReachFlag = 0;
    unsigned long setTime = 0;
    
    double dataTempDouble = 0;
    unsigned long fusionPartnerListCount = 0;
    unsigned long entryCount2 = 0;
    string cellNumberString;
    
    int activeCellStatusListTempCount = 0;
    
    timeProgCount = 0;
    
    do{
        
        processingStatusCall = 1;
        loopCount++;
        processingStatus = "Prog: C"+to_string (loopCount);
        
        terminationFlag = 1;
        fusionCount = 0;
        timeProgCount++;
        
        for (int counter1 = 0; counter1 < activeCellStatusListCount/14; counter1++){
            if (terminateSimFlag == 1){
                terminate2 = 1;
                break;
            }
            
            cellDoubLimitCheck = activeCellStatusList [counter1*14];
            
            if (cellDoubLimitCheck < 0) cellDoubLimitCheck = cellDoubLimitCheck*-1;
            
            cellNumberString = to_string(cellDoubLimitCheck);
            
            //----When division reaches 15, change the growthCycleBase to the shortest time that reached 15 divisions plus the maximum time point----
            if (((int)cellNumberString.length() == 9 && (cellNumberString.substr(0, 1) == "5" || cellNumberString.substr(0, 1) == "6") && cellNumberString.substr(cellNumberString.length()-1) != "0") || cycleMaxReachFlag == 1){
                activeCellStatusList [counter1*14+4] = 50; //----When division reaches 15, add 100 points then terminate the cell----
                activeCellStatusList [counter1*14+5] = 9;
                activeCellStatusList [counter1*14+6] = 1;
                cycleMaxReachFlag = 1;
            }
            else{
                
                if (activeCellStatusList [counter1*14+5] == 5){ //---- Either set CD or extend another "End time"----
                    [self expandNonCDSet];
                    
                    dataTempDouble = ((expandNonCDCount/(double)2)/(double)simProcessDataProgHold [24])*100; //----Calculate % of CD occurrence----
                    
                    randInit = rand() % 100 + 0;
                    
                    if (randInit < dataTempDouble && expandNonCDCount != 0){ //----Set a 10% limit----
                        randInit = rand() % expandNonCDCount/2 + 0;
                        
                        activeCellStatusList [counter1*14+4] = expandNonCD [randInit*2];
                        activeCellStatusList [counter1*14+5] = 30;
                        activeCellStatusList [counter1*14+6] = 1;
                    }
                    else{
                        
                        randInit = rand() % (int)(round(simProcessDataProgHold [25]*(endVariationHold/(double)100))) + 0;
                        
                        if (randInit%2 == 0) activeCellStatusList [counter1*14+4] = (int)simProcessDataProgHold [25]+randInit; //----Add End time, set 5: no recovery apply----
                        else activeCellStatusList [counter1*14+4] = (int)simProcessDataProgHold [25]-randInit;
                        
                        //----Add End time, set 5: no recovery apply----
                        activeCellStatusList [counter1*14+5] = 5;
                        activeCellStatusList [counter1*14+6] = 1;
                    }
                }
                else if (activeCellStatusList [counter1*14+5] == 7){ //----BD for recovery----
                    eventType = 1; //----BD recovery, set BD for longer doubling time, next round will be normal BD or 7----
                    
                    if (eventType == 1){
                        //----Use expandDoubLingDoubBD, Set BD----
                        if (activeCellStatusList [counter1*14+11] == 0){
                            [self expandDoubLingDoubBDSet];
                            
                            if (expandDoubLingDoubBDCount != 0){
                                randInit = rand() % expandDoubLingDoubBDCount/2 + 0;
                                
                                activeCellStatusList [counter1*14+4] = expandDoubLingDoubBD [randInit*2];
                                activeCellStatusList [counter1*14+5] = 1;
                                activeCellStatusList [counter1*14+6] = 1;
                            }
                            else{
                                
                                [self randBDRangeSet];
                                
                                randInit = rand() % randBDRangeB + randBDRangeA;
                                
                                activeCellStatusList [counter1*14+4] = randInit;
                                activeCellStatusList [counter1*14+5] = 7;
                                activeCellStatusList [counter1*14+6] = 1;
                            }
                        }
                        else{
                            
                            [self expandDoubLingDoubBDSet];
                            loopCheck = 0;
                            
                            for (int counter2 = 0; counter2 < 100; counter2++){
                                if (expandDoubLingDoubBDCount != 0){
                                    randInit = rand() % expandDoubLingDoubBDCount/2 + 0;
                                    
                                    if (expandDoubLingDoubBD [randInit*2] > activeCellStatusList [counter1*14+11]-50 && expandDoubLingDoubBD [randInit*2] < activeCellStatusList [counter1*14+11]+50){
                                        activeCellStatusList [counter1*14+4] = expandDoubLingDoubBD [randInit*2];
                                        activeCellStatusList [counter1*14+5] = 1;
                                        activeCellStatusList [counter1*14+6] = 1;
                                        loopCheck = 1;
                                        break;
                                    }
                                }
                            }
                            
                            if (loopCheck == 0){
                                activeCellStatusList [counter1*14+4] = activeCellStatusList [counter1*14+11];
                                activeCellStatusList [counter1*14+5] = 7;
                                activeCellStatusList [counter1*14+6] = 1;
                            }
                        }
                    }
                }
                else if (activeCellStatusList [counter1*14+5] == 1){
                    siblingFusionCheck1 = 0;
                    siblingFusionDoub1 = 0;
                    siblingCellNo1 = 0;
                    
                    for (int counter2 = 0; counter2 < activeCellStatusListCount/14; counter2++){
                        if (activeCellStatusList [counter2*14+6] == 1 && activeCellStatusList [counter2*14+1] == activeCellStatusList [counter1*14] && activeCellStatusList [counter2*14+3] == activeCellStatusList [counter1*14+3]){
                            siblingCellNo1 = counter2;
                            
                            if (activeCellStatusList [counter2*14+5] != 0){
                                siblingFusionCheck1 = activeCellStatusList [counter2*14+5];
                                siblingFusionDoub1 = activeCellStatusList [counter2*14+4];
                            }
                            
                            break;
                        }
                    }
                    
                    //----Event type set----
                    eventType = 0;
                    
                    if (activeCellStatusList [counter1*14+9] == 0){//----Limit off----
                        if (siblingFusionCheck1 == 6){ //----If CF is set on another sibling, determine an event type other than CF
                            [self secondEventBDListSet];
                            loopCheck = 0;
                            
                            for (int counter2 = 0; counter2 < 100; counter2++){ //----Try up to 100 times to find a match; if unsuccessful, set BD--
                                randInit = rand() % 100 + 0;
                                
                                if (secondEventBDList [randInit] != 6){
                                    eventType = secondEventBDList [randInit];
                                    loopCheck = 1;
                                    break;
                                }
                            }
                            
                            if (loopCheck == 0) eventType = 1;
                        }
                        else{
                            
                            [self secondEventBDListSet];
                            randInit = rand() % 100 + 0;
                            
                            if (secondEventBDList [randInit] != 0) eventType = secondEventBDList [randInit];
                            else eventType = 1;
                        }
                    }
                    else if (activeCellStatusList [counter1*14+9] != 0){ //----Limit on
                        eventCount = 0;
                        eventType = 0;
                        
                        if (siblingFusionCheck1 == 6) eventType = 5; //----If CF is set on another sibling, set CD
                        else{
                            
                            [self secondEventBDListSet];
                            
                            for (int counter2 = 0; counter2 < 5; counter2++){ //----If BD is selected five times, set BD, or other events
                                randInit = rand() % 100 + 0;
                                
                                if (secondEventBDList [randInit] == 1) eventCount++;
                                else{
                                    
                                    eventType = secondEventBDList [randInit];
                                    break;
                                }
                            }
                            
                            if (eventCount == 5 || eventType == 0) eventType = 1;
                        }
                    }
                    
                    if (firstTimeAssignment == 0 && eventType == 1){
                        [self firstEventListSet];
                        randInit = rand() % 100 + 0;
                        
                        if (firstEventList [randInit] != 0){
                            if (firstEventList [randInit] == 3) eventType = 5;
                            else if (firstEventList [randInit] == 4) eventType = 10;
                            else eventType = firstEventList [randInit];
                        }
                    }
                    
                    //cout<<activeCellStatusList [counter1*14]<<" "<<activeCellStatusList [counter1*14+3]<<" "<<siblingCellNo1<<" "<<siblingFusionCheck1<<" "<<siblingFusionDoub1<<" "<<eventType<<" Type"<<endl;
                    
                    if (eventType == 1){
                        //----Use expandDoubLingDoubBD, Set BD----
                        if (activeCellStatusList [counter1*14+11] == 0){
                            if (siblingFusionCheck1 != 6){
                                [self expandDoubLingDoubBDSet];
                                
                                if (expandDoubLingDoubBDCount != 0){
                                    randInit = rand() % expandDoubLingDoubBDCount/2 + 0;
                                    
                                    activeCellStatusList [counter1*14+4] = expandDoubLingDoubBD [randInit*2];
                                    activeCellStatusList [counter1*14+5] = 1;
                                    activeCellStatusList [counter1*14+6] = 1;
                                    
                                    if (activeCellStatusList [counter1*14+9] != 0) activeCellStatusList [counter1*14+9]--;
                                }
                                else{
                                    
                                    [self randBDRangeSet];
                                    randInit = rand() % randBDRangeB + randBDRangeA;
                                    
                                    activeCellStatusList [counter1*14+4] = randInit;
                                    activeCellStatusList [counter1*14+5] = 1;
                                    activeCellStatusList [counter1*14+6] = 1;
                                    
                                    if (activeCellStatusList [counter1*14+9] != 0) activeCellStatusList [counter1*14+9]--;
                                }
                            }
                            else{
                                
                                [self randBDRangeSet];
                                
                                if (siblingFusionDoub1 < randBDRangeA) siblingFusionDoub1 = randBDRangeA;
                                
                                activeCellStatusList [counter1*14+4] = siblingFusionDoub1+10;
                                activeCellStatusList [counter1*14+5] = 1;
                                activeCellStatusList [counter1*14+6] = 1;
                                
                                if (activeCellStatusList [counter1*14+9] != 0) activeCellStatusList [counter1*14+9]--;
                            }
                        }
                        else{
                            
                            loopCheck = 0;
                            
                            for (int counter2 = 0; counter2 < 100; counter2++){ //----Adjust the doubling time bias by ±50 points from the previous doubling time----
                                if (siblingFusionCheck1 != 6){ //----BD set except ones that another sibling with CF----
                                    [self expandDoubLingDoubBDSet];
                                    
                                    if (expandDoubLingDoubBDCount != 0){
                                        randInit = rand() % expandDoubLingDoubBDCount/2 + 0;
                                        
                                        if (expandDoubLingDoubBD [randInit*2] > activeCellStatusList [counter1*14+11]-50 && expandDoubLingDoubBD [randInit*2] < activeCellStatusList [counter1*14+11]+50){
                                            
                                            activeCellStatusList [counter1*14+4] = expandDoubLingDoubBD [randInit*2];
                                            activeCellStatusList [counter1*14+5] = 1;
                                            activeCellStatusList [counter1*14+6] = 1;
                                            
                                            if (activeCellStatusList [counter1*14+9] != 0) activeCellStatusList [counter1*14+9]--;
                                            
                                            loopCheck = 1;
                                            break;
                                        }
                                    }
                                }
                                else if (siblingFusionCheck1 == 6){
                                    [self expandDoubLingDoubBDSet];
                                    
                                    if (expandDoubLingDoubBDCount != 0){
                                        randInit = rand() % expandDoubLingDoubBDCount/2 + 0;
                                        
                                        if (expandDoubLingDoubBD [randInit*2] > activeCellStatusList [counter1*14+11]-50 && expandDoubLingDoubBD [randInit*2] < activeCellStatusList [counter1*14+11]+50 && siblingFusionDoub1+10 < expandDoubLingDoubBD [randInit*2]){
                                            activeCellStatusList [counter1*14+4] = expandDoubLingDoubBD [randInit*2];
                                            activeCellStatusList [counter1*14+5] = 1;
                                            activeCellStatusList [counter1*14+6] = 1;
                                            
                                            if (activeCellStatusList [counter1*14+9] != 0) activeCellStatusList [counter1*14+9]--;
                                            
                                            loopCheck = 1;
                                            break;
                                        }
                                    }
                                }
                            }
                            
                            if (loopCheck == 0){ //----If no match is found, revert to the previous doubling time----
                                [self expandDoubLingDoubBDSet];
                                [self randBDRangeSet];
                                lowestValue = 100000;
                                highestValue = 0;
                                
                                for (int counter2 = 0; counter2 < expandDoubLingDoubBDCount/2; counter2++){
                                    if (lowestValue > expandDoubLingDoubBD [counter2*2]) lowestValue = expandDoubLingDoubBD [counter2*2];
                                    if (highestValue < expandDoubLingDoubBD [counter2*2]) highestValue = expandDoubLingDoubBD [counter2*2];
                                }
                                
                                if (siblingFusionDoub1 < randBDRangeA) siblingFusionDoub1 = randBDRangeA;
                                
                                if (lowestValue != 100000 && highestValue != 0){
                                    if ((highestValue+lowestValue)/(double)2 > siblingFusionDoub1+10){
                                        activeCellStatusList [counter1*14+4] = (int)(round((highestValue+lowestValue)/(double)2));
                                        activeCellStatusList [counter1*14+5] = 1;
                                        activeCellStatusList [counter1*14+6] = 1;
                                        
                                        if (activeCellStatusList [counter1*14+9] != 0) activeCellStatusList [counter1*14+9]--;
                                    }
                                    else{
                                        
                                        activeCellStatusList [counter1*14+4] = siblingFusionDoub1+10;
                                        activeCellStatusList [counter1*14+5] = 1;
                                        activeCellStatusList [counter1*14+6] = 1;
                                        
                                        if (activeCellStatusList [counter1*14+9] != 0) activeCellStatusList [counter1*14+9]--;
                                    }
                                }
                                else{
                                    
                                    activeCellStatusList [counter1*14+4] = siblingFusionDoub1+10;
                                    activeCellStatusList [counter1*14+5] = 1;
                                    activeCellStatusList [counter1*14+6] = 1;
                                    
                                    if (activeCellStatusList [counter1*14+9] != 0) activeCellStatusList [counter1*14+9]--;
                                }
                            }
                        }
                        
                        //cout<<activeCellStatusList [counter1*14+8]<<" "<<activeCellStatusList [counter1*14+7]<<" "<<activeCellStatusList [counter1*14]<<" "<<activeCellStatusList [counter1*14+3]<<" TypeB"<<endl;
                    }
                    else if (eventType == 2){
                        //----Use expandDoubLingDoubBD, Set TD----
                        if (activeCellStatusList [counter1*14+11] == 0){
                            if (siblingFusionCheck1 != 6){
                                [self expandDoubLingDoubBDSet];
                                
                                if (expandDoubLingDoubBDCount != 0){
                                    randInit = rand() % expandDoubLingDoubBDCount/2 + 0;
                                    
                                    activeCellStatusList [counter1*14+4] = expandDoubLingDoubBD [randInit*2];
                                    activeCellStatusList [counter1*14+5] = 2;
                                    activeCellStatusList [counter1*14+6] = 1;
                                    activeCellStatusList [counter1*14+7] = 1;
                                    activeCellStatusList [counter1*14+9] = 0;
                                    activeCellStatusList [counter1*14+8] = (int)simProcessDataProgHold [18];
                                }
                                else{
                                    
                                    [self randBDRangeSet];
                                    
                                    randInit = rand() % randBDRangeB + randBDRangeA;
                                    
                                    activeCellStatusList [counter1*14+4] = randInit;
                                    activeCellStatusList [counter1*14+5] = 2;
                                    activeCellStatusList [counter1*14+6] = 1;
                                    activeCellStatusList [counter1*14+7] = 1;
                                    activeCellStatusList [counter1*14+9] = 0;
                                    activeCellStatusList [counter1*14+8] = (int)simProcessDataProgHold [18];
                                }
                            }
                            else{
                                
                                [self randBDRangeSet];
                                
                                if (siblingFusionDoub1 < randBDRangeA) siblingFusionDoub1 = randBDRangeA;
                                
                                activeCellStatusList [counter1*14+4] = siblingFusionDoub1+10;
                                activeCellStatusList [counter1*14+5] = 2;
                                activeCellStatusList [counter1*14+6] = 1;
                                activeCellStatusList [counter1*14+7] = 1;
                                activeCellStatusList [counter1*14+9] = 0;
                                activeCellStatusList [counter1*14+8] = (int)simProcessDataProgHold [18];
                            }
                        }
                        else{
                            
                            loopCheck = 0;
                            
                            for (int counter2 = 0; counter2 < 100; counter2++){
                                if (siblingFusionCheck1 != 6){
                                    [self expandDoubLingDoubBDSet];
                                    
                                    if (expandDoubLingDoubBDCount != 0){
                                        randInit = rand() % expandDoubLingDoubBDCount/2 + 0;
                                        
                                        if (expandDoubLingDoubBD [randInit*2] > activeCellStatusList [counter1*14+11]-50 && expandDoubLingDoubBD [randInit*2] < activeCellStatusList [counter1*14+11]+50){
                                            activeCellStatusList [counter1*14+4] = expandDoubLingDoubBD [randInit*2];
                                            activeCellStatusList [counter1*14+5] = 2;
                                            activeCellStatusList [counter1*14+6] = 1;
                                            activeCellStatusList [counter1*14+7] = 1;
                                            activeCellStatusList [counter1*14+9] = 0;
                                            activeCellStatusList [counter1*14+8] = (int)simProcessDataProgHold [18];
                                            
                                            loopCheck = 1;
                                            break;
                                        }
                                    }
                                }
                                else if (siblingFusionCheck1 == 6){
                                    [self expandDoubLingDoubBDSet];
                                    
                                    if (expandDoubLingDoubBDCount != 0){
                                        randInit = rand() % expandDoubLingDoubBDCount/2 + 0;
                                        
                                        if (expandDoubLingDoubBD [randInit*2] > activeCellStatusList [counter1*14+11]-50 && expandDoubLingDoubBD [randInit*2] < activeCellStatusList [counter1*14+11]+50 && siblingFusionDoub1+10 < expandDoubLingDoubBD [randInit*2]){
                                            activeCellStatusList [counter1*14+4] = expandDoubLingDoubBD [randInit*2];
                                            activeCellStatusList [counter1*14+5] = 2;
                                            activeCellStatusList [counter1*14+6] = 1;
                                            activeCellStatusList [counter1*14+7] = 1;
                                            activeCellStatusList [counter1*14+9] = 0;
                                            activeCellStatusList [counter1*14+8] = (int)simProcessDataProgHold [18];
                                            
                                            loopCheck = 1;
                                            break;
                                        }
                                    }
                                }
                            }
                            
                            if (loopCheck == 0){
                                [self expandDoubLingDoubBDSet];
                                [self randBDRangeSet];
                                lowestValue = 100000;
                                highestValue = 0;
                                
                                for (int counter2 = 0; counter2 < expandDoubLingDoubBDCount/2; counter2++){
                                    if (lowestValue > expandDoubLingDoubBD [counter2*2]) lowestValue = expandDoubLingDoubBD [counter2*2];
                                    if (highestValue < expandDoubLingDoubBD [counter2*2]) highestValue = expandDoubLingDoubBD [counter2*2];
                                }
                                
                                if (siblingFusionDoub1 < randBDRangeA) siblingFusionDoub1 = randBDRangeA;
                                
                                if (lowestValue != 100000 && highestValue != 0){
                                    if ((highestValue+lowestValue)/(double)2 > siblingFusionDoub1+10){
                                        activeCellStatusList [counter1*14+4] = (int)(round((highestValue+lowestValue)/(double)2));
                                        activeCellStatusList [counter1*14+5] = 2;
                                        activeCellStatusList [counter1*14+6] = 1;
                                        activeCellStatusList [counter1*14+7] = 1;
                                        activeCellStatusList [counter1*14+9] = 0;
                                        activeCellStatusList [counter1*14+8] = (int)simProcessDataProgHold [18];
                                    }
                                    else{
                                        
                                        activeCellStatusList [counter1*14+4] = siblingFusionDoub1+10;
                                        activeCellStatusList [counter1*14+5] = 2;
                                        activeCellStatusList [counter1*14+6] = 1;
                                        activeCellStatusList [counter1*14+7] = 1;
                                        activeCellStatusList [counter1*14+9] = 0;
                                        activeCellStatusList [counter1*14+8] = (int)simProcessDataProgHold [18];
                                    }
                                }
                                else{
                                    
                                    activeCellStatusList [counter1*14+4] = siblingFusionDoub1+10;
                                    activeCellStatusList [counter1*14+5] = 2;
                                    activeCellStatusList [counter1*14+6] = 1;
                                    activeCellStatusList [counter1*14+7] = 1;
                                    activeCellStatusList [counter1*14+9] = 0;
                                    activeCellStatusList [counter1*14+8] = (int)simProcessDataProgHold [18];
                                }
                            }
                        }
                    }
                    else if (eventType == 5){
                        [self expandBDCDSet];
                        
                        if (expandBDCDCount == 0){
                            [self randBDRangeSet];
                            
                            randInit = rand() % randCDRangeB + randCDRangeA;
                            
                            if (siblingFusionCheck1 != 6){
                                activeCellStatusList [counter1*14+4] = randInit;
                                activeCellStatusList [counter1*14+5] = 3;
                                activeCellStatusList [counter1*14+6] = 1;
                                activeCellStatusList [counter1*14+9] = 0;
                            }
                            else{
                                
                                activeCellStatusList [counter1*14+4] = siblingFusionDoub1+10;
                                activeCellStatusList [counter1*14+5] = 3;
                                activeCellStatusList [counter1*14+6] = 1;
                                activeCellStatusList [counter1*14+9] = 0;
                            }
                        }
                        else{
                            
                            if (siblingFusionCheck1 != 6){
                                if (expandBDCDCount != 0){
                                    randInit = rand() % expandBDCDCount/2 + 0;
                                    activeCellStatusList [counter1*14+4] = expandBDCD [randInit*2];
                                    activeCellStatusList [counter1*14+5] = 3;
                                    activeCellStatusList [counter1*14+6] = 1;
                                    activeCellStatusList [counter1*14+9] = 0;
                                }
                                else{
                                    
                                    activeCellStatusList [counter1*14+4] = siblingFusionDoub1+10;
                                    activeCellStatusList [counter1*14+5] = 3;
                                    activeCellStatusList [counter1*14+6] = 1;
                                    activeCellStatusList [counter1*14+9] = 0;
                                }
                            }
                            else{
                                
                                if (expandBDCDCount != 0){
                                    randInit = rand() % expandBDCDCount/2 + 0;
                                    
                                    if(expandBDCD [randInit*2] > siblingFusionDoub1){
                                        activeCellStatusList [counter1*14+4] = expandBDCD [randInit*2]+10;
                                        activeCellStatusList [counter1*14+5] = 3;
                                        activeCellStatusList [counter1*14+6] = 1;
                                        activeCellStatusList [counter1*14+9] = 0;
                                    }
                                    else{
                                        
                                        activeCellStatusList [counter1*14+4] = siblingFusionDoub1+10;
                                        activeCellStatusList [counter1*14+5] = 3;
                                        activeCellStatusList [counter1*14+6] = 1;
                                        activeCellStatusList [counter1*14+9] = 0;
                                    }
                                }
                                else{
                                    
                                    activeCellStatusList [counter1*14+4] = siblingFusionDoub1+10;
                                    activeCellStatusList [counter1*14+5] = 3;
                                    activeCellStatusList [counter1*14+6] = 1;
                                    activeCellStatusList [counter1*14+9] = 0;
                                }
                            }
                        }
                    }
                    else if (eventType == 6){
                        [self expandBDCFSet];
                        
                        if (expandBDCFCount == 0){
                            [self randBDRangeSet];
                            randInit = rand() % randCDRangeB + randCDRangeA; //----Use CD data
                            
                            if (siblingFusionCheck1 != 6){
                                activeCellStatusList [counter1*14+4] = randInit;
                                activeCellStatusList [counter1*14+5] = 6;
                                activeCellStatusList [counter1*14+6] = 1;
                                activeCellStatusList [counter1*14+9] = 0;
                            }
                            else{
                                
                                if (siblingFusionDoub1 < randBDRangeA) siblingFusionDoub1 = randBDRangeA;
                                
                                activeCellStatusList [siblingCellNo1*14+4] = siblingFusionDoub1+10;
                                
                                activeCellStatusList [counter1*14+4] = siblingFusionDoub1; //----Switch--
                                activeCellStatusList [counter1*14+5] = 6;
                                activeCellStatusList [counter1*14+6] = 1;
                                activeCellStatusList [counter1*14+9] = 0;
                            }
                        }
                        else{
                            
                            if (siblingFusionCheck1 == 0){ //----Set fusion----
                                if (expandBDCFCount != 0){
                                    randInit = rand() % expandBDCFCount/2 + 0;
                                    activeCellStatusList [counter1*14+4] = expandBDCF [randInit*2];
                                    activeCellStatusList [counter1*14+5] = 6;
                                    activeCellStatusList [counter1*14+6] = 1;
                                    activeCellStatusList [counter1*14+9] = 0;
                                }
                                else {
                                    
                                    activeCellStatusList [counter1*14+4] = siblingFusionDoub1+10;
                                    activeCellStatusList [counter1*14+5] = 6;
                                    activeCellStatusList [counter1*14+6] = 1;
                                    activeCellStatusList [counter1*14+9] = 0;
                                }
                            }
                            else{ //----Recheck doubling times if events (BD, TD, CD) are set on another sibling----
                                
                                if (expandBDCDCount != 0){
                                    randInit = rand() % expandBDCDCount/2 + 0;
                                    
                                    if(expandBDCD [randInit*2] > siblingFusionDoub1){
                                        activeCellStatusList [counter1*14+4] = expandBDCD [randInit*2]+10;
                                        activeCellStatusList [counter1*14+5] = 3;
                                        activeCellStatusList [counter1*14+6] = 1;
                                        activeCellStatusList [counter1*14+9] = 0;
                                    }
                                    else{
                                        
                                        activeCellStatusList [counter1*14+4] = siblingFusionDoub1+10;
                                        activeCellStatusList [counter1*14+5] = 3;
                                        activeCellStatusList [counter1*14+6] = 1;
                                        activeCellStatusList [counter1*14+9] = 0;
                                    }
                                }
                                else{
                                    
                                    activeCellStatusList [siblingCellNo1*14+4] = siblingFusionDoub1+10;
                                    
                                    activeCellStatusList [counter1*14+4] = siblingFusionDoub1; //----Switch--
                                    activeCellStatusList [counter1*14+5] = 6;
                                    activeCellStatusList [counter1*14+6] = 1;
                                    activeCellStatusList [counter1*14+9] = 0;
                                }
                            }
                        }
                    }
                    else if (eventType == 10){
                        [self expandNonCDSet];
                        
                        dataTempDouble = ((expandNonCDCount/(double)2)/(double)simProcessDataProgHold [24])*100; //----Calculate % of CD occurrence----
                        
                        randInit = rand() % 100 + 0;
                        
                        if (randInit < dataTempDouble && expandNonCDCount != 0){ //----Set a 10% limit----
                            randInit = rand() % expandNonCDCount/2 + 0;
                            
                            activeCellStatusList [counter1*14+4] = expandNonCD [randInit*2];
                            activeCellStatusList [counter1*14+5] = 30;
                            activeCellStatusList [counter1*14+6] = 1;
                        }
                        else{
                            
                            randInit = rand() % (int)(round(simProcessDataProgHold [25]*(endVariationHold/(double)100))) + 0;
                            
                            if (randInit%2 == 0) activeCellStatusList [counter1*14+4] = (int)simProcessDataProgHold [25]+randInit; //----Add End time, set 5: no recovery apply----
                            else activeCellStatusList [counter1*14+4] = (int)simProcessDataProgHold [25]-randInit;
                            
                            //----Add End time, set 5: no recovery apply----
                            activeCellStatusList [counter1*14+5] = 5;
                            activeCellStatusList [counter1*14+6] = 1;
                        }
                    }
                }
                else if (activeCellStatusList [counter1*14+5] == 2){
                    siblingFusionCheck1 = 0;
                    siblingFusionCheck2 = 0;
                    siblingFusionDoub1 = 0;
                    siblingFusionDoub2 = 0;
                    siblingCellNo1 = 0;
                    siblingCellNo2 = 0;
                    
                    for (int counter2 = 0; counter2 < activeCellStatusListCount/14; counter2++){
                        if (activeCellStatusList [counter2*14+6] == 1 && (activeCellStatusList [counter2*14+1] == activeCellStatusList [counter1*14] || activeCellStatusList [counter2*14+2] == activeCellStatusList [counter1*14]) && activeCellStatusList [counter2*14+3] == activeCellStatusList [counter1*14+3]){
                            if (siblingFusionCheck1 == 0 && activeCellStatusList [counter2*14+5] != 0){
                                siblingFusionCheck1 = activeCellStatusList [counter2*14+5];
                                siblingFusionDoub1 = activeCellStatusList [counter2*14+4];
                                siblingCellNo1 = counter2;
                            }
                            else if (siblingFusionCheck1 != 0 && siblingFusionCheck2 == 0 && activeCellStatusList [counter2*14+5] != 0){
                                siblingFusionCheck2 = activeCellStatusList [counter2*14+5];
                                siblingFusionDoub2 = activeCellStatusList [counter2*14+4];
                                siblingCellNo2 = counter2;
                                break;
                            }
                        }
                    }
                    
                    //cout<<siblingCellNo1<<" "<<siblingFusionCheck1<<" "<<siblingFusionDoub1<<" Type"<<endl;
                    //cout<<siblingCellNo2<<" "<<siblingFusionCheck2<<" "<<siblingFusionDoub2<<" Type2"<<endl;
                    
                    //----Event type set----
                    eventType = 0;
                    
                    if (siblingFusionCheck1 == 6 && siblingFusionCheck2 == 6){
                        [self secondEventTDListSet];
                        
                        for (int counter2 = 0; counter2 < 100; counter2++){
                            randInit = rand() % 100 + 0;
                            
                            if (secondEventTDList [randInit] != 10){
                                eventType = secondEventTDList [randInit];
                                loopCheck = 1;
                                break;
                            }
                        }
                        
                        if (loopCheck == 0) eventType = 13;
                    }
                    else{
                        
                        [self secondEventTDListSet];
                        randInit = rand() % 100 + 0;
                        eventType = secondEventTDList [randInit];
                        
                        if (eventType == 0) eventType = 13;
                    }
                    
                    if ((activeCellStatusList [counter1*14+8] == 2 || activeCellStatusList [counter1*14+8] == 3) && activeCellStatusList [counter1*14+8] == activeCellStatusList [counter1*14+7] && eventType == 12){
                        eventType = 13;
                    }
                    
                    if (siblingFusionDoub1 < siblingFusionDoub2) siblingFusionDoubLarge = siblingFusionDoub2;
                    else siblingFusionDoubLarge = siblingFusionDoub1;
                    
                    if (siblingFusionCheck1 == 6 && siblingFusionCheck2 == 6 && eventType == 10){
                        eventType = 13;
                    }
                    
                    //cout<<siblingFusionCheckLarge<<" "<<siblingFusionDoubLarge<<" "<<siblingCellNoLarge<<" "<<eventType<<" Type3"<<endl;
                    
                    if (eventType == 10){ //----TDCF---siblingFusionCheck1 == 6 && siblingFusionCheck2 == 6 does not enter
                        loopCheck = 0;
                        
                        if (siblingFusionCheck1 != 0 && siblingFusionCheck2 != 0){
                            if (siblingFusionCheck1 == 6 && siblingFusionCheck2 != 6){
                                [self expandTDCFSet];
                                
                                if (expandTDCFCount == 0){
                                    [self randBDRangeSet];
                                    
                                    randInit = rand() % randCDRangeB + randCDRangeA; //----Use CD data
                                    
                                    if (siblingFusionDoub2 < randBDRangeA) siblingFusionDoub2 = randBDRangeA;
                                    
                                    if (siblingFusionDoub1 > siblingFusionDoub2){
                                        if (randInit > siblingFusionDoub1){
                                            activeCellStatusList [siblingCellNo2*14+4] = randInit+10;
                                            
                                            activeCellStatusList [counter1*14+4] = siblingFusionDoub2; //----Switch--
                                            activeCellStatusList [counter1*14+5] = 6;
                                            activeCellStatusList [counter1*14+6] = 1;
                                        }
                                        else{
                                            
                                            activeCellStatusList [siblingCellNo2*14+4] = siblingFusionDoub1+10;
                                            
                                            activeCellStatusList [counter1*14+4] = siblingFusionDoub2; //----Switch--
                                            activeCellStatusList [counter1*14+5] = 6;
                                            activeCellStatusList [counter1*14+6] = 1;
                                        }
                                    }
                                    else if (siblingFusionDoub1 < siblingFusionDoub2){
                                        if (randInit > siblingFusionDoub2){
                                            activeCellStatusList [siblingCellNo2*14+4] = randInit+10;
                                            
                                            activeCellStatusList [counter1*14+4] = siblingFusionDoub2; //----Switch--
                                            activeCellStatusList [counter1*14+5] = 6;
                                            activeCellStatusList [counter1*14+6] = 1;
                                        }
                                        else{
                                            
                                            activeCellStatusList [siblingCellNo2*14+4] = siblingFusionDoub2+10;
                                            
                                            activeCellStatusList [counter1*14+4] = siblingFusionDoub2; //----Switch--
                                            activeCellStatusList [counter1*14+5] = 6;
                                            activeCellStatusList [counter1*14+6] = 1;
                                        }
                                    }
                                }
                                else{
                                    
                                    if (siblingFusionDoub1 > siblingFusionDoub2){
                                        if (expandTDCFCount != 0){
                                            randInit = rand() % expandTDCFCount/2 + 0;
                                            
                                            if (expandTDCF [randInit*2] > siblingFusionDoub1){
                                                activeCellStatusList [siblingCellNo2*14+4] = expandTDCF [randInit*2]+10;
                                                
                                                activeCellStatusList [counter1*14+4] = siblingFusionDoub2; //----Switch--
                                                activeCellStatusList [counter1*14+5] = 6;
                                                activeCellStatusList [counter1*14+6] = 1;
                                            }
                                            else{
                                                
                                                activeCellStatusList [siblingCellNo2*14+4] = siblingFusionDoub1+10;
                                                
                                                activeCellStatusList [counter1*14+4] = siblingFusionDoub2; //----Switch--
                                                activeCellStatusList [counter1*14+5] = 6;
                                                activeCellStatusList [counter1*14+6] = 1;
                                            }
                                        }
                                        else{
                                            
                                            activeCellStatusList [siblingCellNo2*14+4] = siblingFusionDoub1+10;
                                            
                                            activeCellStatusList [counter1*14+4] = siblingFusionDoub2; //----Switch--
                                            activeCellStatusList [counter1*14+5] = 6;
                                            activeCellStatusList [counter1*14+6] = 1;
                                        }
                                    }
                                    else if (siblingFusionDoub1 < siblingFusionDoub2){
                                        if (expandTDCFCount != 0){
                                            randInit = rand() % expandTDCFCount/2 + 0;
                                            
                                            if (expandTDCF [randInit*2] > siblingFusionDoub2){
                                                activeCellStatusList [siblingCellNo2*14+4] = expandTDCF [randInit*2]+10;
                                                
                                                activeCellStatusList [counter1*14+4] = siblingFusionDoub2; //----Switch--
                                                activeCellStatusList [counter1*14+5] = 6;
                                                activeCellStatusList [counter1*14+6] = 1;
                                            }
                                            else{
                                                
                                                activeCellStatusList [siblingCellNo2*14+4] = siblingFusionDoub2+10;
                                                
                                                activeCellStatusList [counter1*14+4] = siblingFusionDoub2; //----Switch--
                                                activeCellStatusList [counter1*14+5] = 6;
                                                activeCellStatusList [counter1*14+6] = 1;
                                            }
                                        }
                                        else{
                                            
                                            activeCellStatusList [siblingCellNo2*14+4] = siblingFusionDoub2+10;
                                            
                                            activeCellStatusList [counter1*14+4] = siblingFusionDoub2; //----Switch--
                                            activeCellStatusList [counter1*14+5] = 6;
                                            activeCellStatusList [counter1*14+6] = 1;
                                        }
                                    }
                                }
                            }
                            else if (siblingFusionCheck1 != 6 && siblingFusionCheck2 == 6){
                                [self expandTDCFSet];
                                
                                if (expandTDCFCount == 0){
                                    [self randBDRangeSet];
                                    randInit = rand() % randCDRangeB + randCDRangeA; //----Use CD data
                                    
                                    if (siblingFusionDoub1 > siblingFusionDoub2){
                                        if (randInit > siblingFusionDoub1){
                                            activeCellStatusList [siblingCellNo1*14+4] = randInit+10;
                                            
                                            activeCellStatusList [counter1*14+4] = siblingFusionDoub1; //----Switch--
                                            activeCellStatusList [counter1*14+5] = 6;
                                            activeCellStatusList [counter1*14+6] = 1;
                                        }
                                        else{
                                            
                                            activeCellStatusList [siblingCellNo1*14+4] = siblingFusionDoub1+10;
                                            
                                            activeCellStatusList [counter1*14+4] = siblingFusionDoub1; //----Switch--
                                            activeCellStatusList [counter1*14+5] = 6;
                                            activeCellStatusList [counter1*14+6] = 1;
                                        }
                                    }
                                    else if (siblingFusionDoub1 < siblingFusionDoub2){
                                        if (randInit > siblingFusionDoub2){
                                            activeCellStatusList [siblingCellNo1*14+4] = randInit+10;
                                            
                                            activeCellStatusList [counter1*14+4] = siblingFusionDoub1; //----Switch--
                                            activeCellStatusList [counter1*14+5] = 6;
                                            activeCellStatusList [counter1*14+6] = 1;
                                        }
                                        else{
                                            
                                            activeCellStatusList [siblingCellNo1*14+4] = siblingFusionDoub2+10;
                                            
                                            activeCellStatusList [counter1*14+4] = siblingFusionDoub1; //----Switch--
                                            activeCellStatusList [counter1*14+5] = 6;
                                            activeCellStatusList [counter1*14+6] = 1;
                                        }
                                    }
                                }
                                else{
                                    
                                    if (siblingFusionDoub1 > siblingFusionDoub2){
                                        if (expandTDCFCount != 0){
                                            randInit = rand() % expandTDCFCount/2 + 0;
                                            
                                            if (expandTDCF [randInit*2] > siblingFusionDoub1){
                                                activeCellStatusList [siblingCellNo1*14+4] = expandTDCF [randInit*2]+10;
                                                
                                                activeCellStatusList [counter1*14+4] = siblingFusionDoub1; //----Switch--
                                                activeCellStatusList [counter1*14+5] = 6;
                                                activeCellStatusList [counter1*14+6] = 1;
                                            }
                                            else{
                                                
                                                activeCellStatusList [siblingCellNo1*14+4] = siblingFusionDoub1+10;
                                                
                                                activeCellStatusList [counter1*14+4] = siblingFusionDoub1; //----Switch--
                                                activeCellStatusList [counter1*14+5] = 6;
                                                activeCellStatusList [counter1*14+6] = 1;
                                            }
                                        }
                                        else{
                                            
                                            activeCellStatusList [siblingCellNo1*14+4] = siblingFusionDoub1+10;
                                            
                                            activeCellStatusList [counter1*14+4] = siblingFusionDoub1; //----Switch--
                                            activeCellStatusList [counter1*14+5] = 6;
                                            activeCellStatusList [counter1*14+6] = 1;
                                        }
                                    }
                                    else if (siblingFusionDoub1 < siblingFusionDoub2){
                                        if (expandTDCFCount != 0){
                                            randInit = rand() % expandTDCFCount/2 + 0;
                                            if (expandTDCF [randInit*2] >= siblingFusionDoub2){
                                                activeCellStatusList [siblingCellNo1*14+4] = expandTDCF [randInit*2]+10;
                                                
                                                activeCellStatusList [counter1*14+4] = siblingFusionDoub1; //----Switch--
                                                activeCellStatusList [counter1*14+5] = 6;
                                                activeCellStatusList [counter1*14+6] = 1;
                                            }
                                            else{
                                                
                                                activeCellStatusList [siblingCellNo1*14+4] = siblingFusionDoub2+10;
                                                
                                                activeCellStatusList [counter1*14+4] = siblingFusionDoub1; //----Switch--
                                                activeCellStatusList [counter1*14+5] = 6;
                                                activeCellStatusList [counter1*14+6] = 1;
                                            }
                                        }
                                        else{
                                            
                                            activeCellStatusList [siblingCellNo1*14+4] = siblingFusionDoub2+10;
                                            
                                            activeCellStatusList [counter1*14+4] = siblingFusionDoub1; //----Switch--
                                            activeCellStatusList [counter1*14+5] = 6;
                                            activeCellStatusList [counter1*14+6] = 1;
                                        }
                                    }
                                }
                            }
                            else if (siblingFusionCheck1 != 6 && siblingFusionCheck2 != 6){
                                activeCellStatusList [siblingCellNo1*14+4] = siblingFusionDoub1+10;
                                activeCellStatusList [siblingCellNo2*14+4] = siblingFusionDoub2+10;
                                
                                activeCellStatusList [counter1*14+4] = siblingFusionDoub2; //----Switch--
                                activeCellStatusList [counter1*14+5] = 6;
                                activeCellStatusList [counter1*14+6] = 1;
                            }
                        }
                        else if (siblingFusionCheck1 != 0 && siblingFusionCheck2 == 0){
                            [self expandTDCFSet];
                            
                            if (expandTDCFCount == 0){
                                [self randBDRangeSet];
                                randInit = rand() % randCDRangeB + randCDRangeA; //----Use CD data
                                
                                if (randInit > siblingFusionDoub1+10){
                                    activeCellStatusList [counter1*14+4] = randInit;
                                    activeCellStatusList [counter1*14+5] = 6;
                                    activeCellStatusList [counter1*14+6] = 1;
                                }
                                else{
                                    
                                    activeCellStatusList [counter1*14+4] = siblingFusionDoub1+5;
                                    activeCellStatusList [counter1*14+5] = 6;
                                    activeCellStatusList [counter1*14+6] = 1;
                                }
                            }
                            else{
                                
                                if (expandTDCFCount != 0){
                                    randInit = rand() % expandTDCFCount/2 + 0;
                                    
                                    if (expandTDCF [randInit*2] > siblingFusionDoub1+10){
                                        activeCellStatusList [counter1*14+4] = expandTDCF [randInit*2];
                                        activeCellStatusList [counter1*14+5] = 6;
                                        activeCellStatusList [counter1*14+6] = 1;
                                    }
                                    else{
                                        
                                        activeCellStatusList [counter1*14+4] = siblingFusionDoub1+5;
                                        activeCellStatusList [counter1*14+5] = 6;
                                        activeCellStatusList [counter1*14+6] = 1;
                                    }
                                }
                                else{
                                    
                                    activeCellStatusList [counter1*14+4] = siblingFusionDoub1+5;
                                    activeCellStatusList [counter1*14+5] = 6;
                                    activeCellStatusList [counter1*14+6] = 1;
                                }
                            }
                        }
                        else if (siblingFusionCheck1 == 0 && siblingFusionCheck2 == 0){
                            [self expandTDCFSet];
                            
                            if (expandTDCFCount == 0){
                                [self randBDRangeSet];
                                randInit = rand() % randCDRangeB + randCDRangeA; //----Use CD data
                                
                                activeCellStatusList [counter1*14+4] = randInit;
                                activeCellStatusList [counter1*14+5] = 6;
                                activeCellStatusList [counter1*14+6] = 1;
                            }
                            else{
                                
                                if (activeCellStatusList [counter1*14+11] == 0){
                                    randInit = rand() % expandTDCFCount/2 + 0;
                                    
                                    activeCellStatusList [counter1*14+4] = expandTDCF [randInit*2];
                                    activeCellStatusList [counter1*14+5] = 6;
                                    activeCellStatusList [counter1*14+6] = 1;
                                }
                                else{
                                    
                                    randInit = rand() % expandTDCFCount/2 + 0;
                                    
                                    activeCellStatusList [counter1*14+4] = expandTDCF [randInit*2];
                                    activeCellStatusList [counter1*14+5] = 6;
                                    activeCellStatusList [counter1*14+6] = 1;
                                }
                            }
                        }
                    }
                    else if (eventType == 11){
                        [self expandDoubLingDoubTDSet];
                        
                        if (expandDoubLingDoubTDCount == 0){
                            [self randBDRangeSet];
                            randInit = rand() % randBDRangeB + randBDRangeA; //----Use CD data
                            
                            if (randInit > siblingFusionDoubLarge+10){
                                activeCellStatusList [counter1*14+4] = randInit;
                                activeCellStatusList [counter1*14+5] = 1;
                                activeCellStatusList [counter1*14+6] = 1;
                                activeCellStatusList [counter1*14+9] = (int)simProcessDataProgHold [19];
                                activeCellStatusList [counter1*14+7] = 0;
                            }
                            else{
                                
                                if (siblingFusionDoubLarge < randBDRangeA) siblingFusionDoubLarge = randBDRangeA;
                                
                                activeCellStatusList [counter1*14+4] = siblingFusionDoubLarge+10;
                                activeCellStatusList [counter1*14+5] = 1;
                                activeCellStatusList [counter1*14+6] = 1;
                                activeCellStatusList [counter1*14+9] = (int)simProcessDataProgHold [19];
                                activeCellStatusList [counter1*14+7] = 0;
                            }
                        }
                        else{
                            
                            if (activeCellStatusList [counter1*14+11] == 0){
                                if (expandDoubLingDoubTDCount != 0){
                                    randInit = rand() % expandDoubLingDoubTDCount/2 + 0;
                                    
                                    if (randInit > siblingFusionDoubLarge+10){
                                        activeCellStatusList [counter1*14+4] = expandDoubLingDoubTD [randInit*2];
                                        activeCellStatusList [counter1*14+5] = 1;
                                        activeCellStatusList [counter1*14+6] = 1;
                                        activeCellStatusList [counter1*14+9] = (int)simProcessDataProgHold [19];
                                        activeCellStatusList [counter1*14+7] = 0;
                                    }
                                    else{
                                        
                                        if (siblingFusionDoubLarge < randBDRangeA) siblingFusionDoubLarge = randBDRangeA;
                                        
                                        activeCellStatusList [counter1*14+4] = siblingFusionDoubLarge+10;
                                        activeCellStatusList [counter1*14+5] = 1;
                                        activeCellStatusList [counter1*14+6] = 1;
                                        activeCellStatusList [counter1*14+9] = (int)simProcessDataProgHold [19];
                                        activeCellStatusList [counter1*14+7] = 0;
                                    }
                                }
                                else{
                                    
                                    [self randBDRangeSet];
                                    
                                    if (siblingFusionDoubLarge < randBDRangeA) siblingFusionDoubLarge = randBDRangeA;
                                    
                                    activeCellStatusList [counter1*14+4] = siblingFusionDoubLarge+10;
                                    activeCellStatusList [counter1*14+5] = 1;
                                    activeCellStatusList [counter1*14+6] = 1;
                                    activeCellStatusList [counter1*14+9] = (int)simProcessDataProgHold [19];
                                    activeCellStatusList [counter1*14+7] = 0;
                                }
                            }
                            else{
                                
                                if (expandDoubLingDoubTDCount != 0){
                                    randInit = rand() % expandDoubLingDoubTDCount/2 + 0;
                                    
                                    if (expandDoubLingDoubTD [randInit*2] > siblingFusionDoubLarge+10){
                                        activeCellStatusList [counter1*14+4] = expandDoubLingDoubTD [randInit*2];
                                        activeCellStatusList [counter1*14+5] = 1;
                                        activeCellStatusList [counter1*14+6] = 1;
                                        activeCellStatusList [counter1*14+9] = (int)simProcessDataProgHold [19];
                                        activeCellStatusList [counter1*14+7] = 0;
                                    }
                                    else{
                                        
                                        [self randBDRangeSet];
                                        
                                        if (siblingFusionDoubLarge < randBDRangeA) siblingFusionDoubLarge = randBDRangeA;
                                        
                                        activeCellStatusList [counter1*14+4] = siblingFusionDoubLarge+10;
                                        activeCellStatusList [counter1*14+5] = 1;
                                        activeCellStatusList [counter1*14+6] = 1;
                                        activeCellStatusList [counter1*14+9] = (int)simProcessDataProgHold [19];
                                        activeCellStatusList [counter1*14+7] = 0;
                                    }
                                }
                                else{
                                    
                                    [self randBDRangeSet];
                                    
                                    if (siblingFusionDoubLarge < randBDRangeA) siblingFusionDoubLarge = randBDRangeA;
                                    
                                    activeCellStatusList [counter1*14+4] = siblingFusionDoubLarge+10;
                                    activeCellStatusList [counter1*14+5] = 1;
                                    activeCellStatusList [counter1*14+6] = 1;
                                    activeCellStatusList [counter1*14+9] = (int)simProcessDataProgHold [19];
                                    activeCellStatusList [counter1*14+7] = 0;
                                }
                            }
                        }
                    }
                    else if (eventType == 12){
                        [self expandDoubLingDoubTDSet];
                        
                        if (expandDoubLingDoubTDCount == 0){
                            [self randBDRangeSet];
                            randInit = rand() % randBDRangeB + randBDRangeA; //----Use CD data
                            
                            if (randInit > siblingFusionDoubLarge+10){
                                activeCellStatusList [counter1*14+4] = randInit;
                                activeCellStatusList [counter1*14+5] = 2;
                                activeCellStatusList [counter1*14+6] = 1;
                                activeCellStatusList [counter1*14+7]++;
                            }
                            else{
                                
                                if (siblingFusionDoubLarge < randBDRangeA) siblingFusionDoubLarge = randBDRangeA;
                                
                                activeCellStatusList [counter1*14+4] = siblingFusionDoubLarge+10;
                                activeCellStatusList [counter1*14+5] = 2;
                                activeCellStatusList [counter1*14+6] = 1;
                                activeCellStatusList [counter1*14+7]++;
                            }
                        }
                        else{
                            
                            if (activeCellStatusList [counter1*14+11] == 0){
                                if (expandDoubLingDoubTDCount != 0){
                                    randInit = rand() % expandDoubLingDoubTDCount/2 + 0;
                                    
                                    if (randInit >= siblingFusionDoubLarge+10){
                                        activeCellStatusList [counter1*14+4] = expandDoubLingDoubTD [randInit*2];
                                        activeCellStatusList [counter1*14+5] = 2;
                                        activeCellStatusList [counter1*14+6] = 1;
                                        activeCellStatusList [counter1*14+7]++;
                                    }
                                    else{
                                        
                                        [self randBDRangeSet];
                                        
                                        if (siblingFusionDoubLarge < randBDRangeA) siblingFusionDoubLarge = randBDRangeA;
                                        
                                        activeCellStatusList [counter1*14+4] = siblingFusionDoubLarge+10;
                                        activeCellStatusList [counter1*14+5] = 2;
                                        activeCellStatusList [counter1*14+6] = 1;
                                        activeCellStatusList [counter1*14+7]++;
                                    }
                                }
                                else{
                                    
                                    [self randBDRangeSet];
                                    
                                    if (siblingFusionDoubLarge < randBDRangeA) siblingFusionDoubLarge = randBDRangeA;
                                    
                                    activeCellStatusList [counter1*14+4] = siblingFusionDoubLarge+10;
                                    activeCellStatusList [counter1*14+5] = 2;
                                    activeCellStatusList [counter1*14+6] = 1;
                                    activeCellStatusList [counter1*14+7]++;
                                }
                            }
                            else{
                                
                                if (expandDoubLingDoubTDCount != 0){
                                    randInit = rand() % expandDoubLingDoubTDCount/2 + 0;
                                    
                                    if (expandDoubLingDoubTD [randInit*2] > siblingFusionDoubLarge+10){
                                        activeCellStatusList [counter1*14+4] = expandDoubLingDoubTD [randInit*2];
                                        activeCellStatusList [counter1*14+5] = 2;
                                        activeCellStatusList [counter1*14+7]++;
                                    }
                                    else{
                                        
                                        [self randBDRangeSet];
                                        
                                        if (siblingFusionDoubLarge < randBDRangeA) siblingFusionDoubLarge = randBDRangeA;
                                        
                                        activeCellStatusList [counter1*14+4] = siblingFusionDoubLarge+10;
                                        activeCellStatusList [counter1*14+5] = 2;
                                        activeCellStatusList [counter1*14+7]++;
                                    }
                                }
                                else{
                                    
                                    [self randBDRangeSet];
                                    
                                    if (siblingFusionDoubLarge < randBDRangeA) siblingFusionDoubLarge = randBDRangeA;
                                    
                                    activeCellStatusList [counter1*14+4] = siblingFusionDoubLarge+10;
                                    activeCellStatusList [counter1*14+5] = 2;
                                    activeCellStatusList [counter1*14+7]++;
                                }
                            }
                        }
                    }
                    else if (eventType == 13){
                        [self expandTDCDSet];
                        
                        if (expandTDCDCount == 0){
                            [self randBDRangeSet];
                            randInit = rand() % randCDRangeB + randCDRangeA; //----Use CD data
                            
                            if (randInit > siblingFusionDoubLarge+10){
                                activeCellStatusList [counter1*14+4] = randInit;
                                activeCellStatusList [counter1*14+5] = 3;
                                activeCellStatusList [counter1*14+6] = 1;
                            }
                            else{
                                
                                activeCellStatusList [counter1*14+4] = siblingFusionDoubLarge+10;
                                activeCellStatusList [counter1*14+5] = 3;
                                activeCellStatusList [counter1*14+6] = 1;
                            }
                        }
                        else{
                            
                            if (expandTDCDCount != 0){
                                randInit = rand() % expandTDCDCount/2 + 0;
                                
                                if (expandTDCD [randInit*2] > siblingFusionDoubLarge+10){
                                    activeCellStatusList [counter1*14+4] = expandTDCD [randInit*2];
                                    activeCellStatusList [counter1*14+5] = 3;
                                    activeCellStatusList [counter1*14+6] = 1;
                                }
                                else{
                                    
                                    activeCellStatusList [counter1*14+4] = siblingFusionDoubLarge+10;
                                    activeCellStatusList [counter1*14+5] = 3;
                                    activeCellStatusList [counter1*14+6] = 1;
                                }
                            }
                            else{
                                
                                activeCellStatusList [counter1*14+4] = siblingFusionDoubLarge+10;
                                activeCellStatusList [counter1*14+5] = 3;
                                activeCellStatusList [counter1*14+6] = 1;
                            }
                        }
                    }
                }
            }
        }
        
        //for (int counterA = 0; counterA < activeCellStatusListCount/12; counterA++){
        //    for (int counterB = 0; counterB < 12; counterB++) cout<<" "<<activeCellStatusList [counterA*14+counterB];
        //    cout<<" activeCellStatusList "<<counterA<<endl;
        //}
        
        if (terminate2 == 0){
            for (int counter1 = 0; counter1 < activeCellStatusListCount/14; counter1++){
                activeCellStatusList [counter1*14+6] = 0;
            }
            
            //for (int counterA = 0; counterA < activeCellStatusListCount/12; counterA++){
            //    for (int counterB = 0; counterB < 12; counterB++) cout<<" "<<activeCellStatusList [counterA*14+counterB];
            //    cout<<" activeCellStatusList "<<counterA<<endl;
            //}
            
            siblingCellPosition1 = 0;
            siblingCellPosition2 = 0;
            
            //----Determine fusion partners; set different time points for end events of BD and TD, where fusion end is shorter than non-fusion end----
            for (int counter1 = 0; counter1 < activeCellStatusListCount/14; counter1++){
                if (terminateSimFlag == 1){
                    terminate2 = 1;
                    break;
                }
                
                if (activeCellStatusList [counter1*14+5] == 6){
                    if (activeCellStatusList [counter1*14+2] == 0){
                        siblingFusionDoub1 = 0;
                        siblingCellNo1 = 0;
                        
                        for (int counter2 = 0; counter2 < activeCellStatusListCount/14; counter2++){
                            if (activeCellStatusList [counter2*14+1] == activeCellStatusList [counter1*14] && activeCellStatusList [counter2*14+3] == activeCellStatusList [counter1*14+3]){
                                siblingCellNo1 = activeCellStatusList [counter2*14];
                                siblingFusionDoub1 = activeCellStatusList [counter2*14+4];
                                siblingCellPosition1 = counter2;
                                fusionCount++;
                                break;
                            }
                        }
                        
                        //cout<<siblingCellNo1<<" "<<siblingFusionCheck1<<" "<<siblingFusionDoub1<<" "<<siblingCellPosition1<<" "<<fusionCount<<" fuse1"<<endl;
                        
                        [self secondEventBDCFListSet];
                        randInit = rand() % 100 + 0;
                        
                        if (secondEventBDCFList [randInit] == 0){
                            activeCellStatusList [counter1*14+6] = siblingCellNo1;
                            fusionCount++;
                        }
                        else if (secondEventBDCFList [randInit] == 7){
                            [self expandDoubLingDoubCFSet];
                            loopCheck = 0;
                            
                            if (expandDoubLingDoubCFCount != 0){
                                randInit = rand() % expandDoubLingDoubCFCount/2 + 0;
                                
                                if (expandDoubLingDoubCF [randInit*2] > siblingFusionDoub1){
                                    activeCellStatusList [siblingCellPosition1*14+4] = expandDoubLingDoubCF [randInit*2];
                                    activeCellStatusList [siblingCellPosition1*14+5] = 1;
                                    activeCellStatusList [counter1*14+6] = siblingCellNo1;
                                    
                                    activeCellStatusList [siblingCellPosition1*14+7] = 0;
                                    activeCellStatusList [siblingCellPosition1*14+8] = 0;
                                    fusionCount++;
                                    loopCheck = 1;
                                }
                                else{
                                    
                                    activeCellStatusList [siblingCellPosition1*14+5] = 1;
                                    activeCellStatusList [counter1*14+6] = siblingCellNo1;
                                    
                                    activeCellStatusList [siblingCellPosition1*14+7] = 0;
                                    activeCellStatusList [siblingCellPosition1*14+8] = 0;
                                    fusionCount++;
                                    loopCheck = 1;
                                }
                            }
                            
                            if (loopCheck == 0){
                                activeCellStatusList [siblingCellPosition1*14+5] = 1;
                                activeCellStatusList [counter1*14+6] = siblingCellNo1;
                                
                                activeCellStatusList [siblingCellPosition1*14+7] = 0;
                                activeCellStatusList [siblingCellPosition1*14+8] = 0;
                                fusionCount++;
                            }
                        }
                        else if (secondEventBDCFList [randInit] == 8){
                            [self expandDoubLingDoubCFSet];
                            loopCheck = 0;
                            
                            if (expandDoubLingDoubCFCount != 0){
                                randInit = rand() % expandDoubLingDoubCFCount/2 + 0;
                                
                                if (expandDoubLingDoubCF [randInit*2] > siblingFusionDoub1){
                                    if (activeCellStatusList [siblingCellPosition1*14+5] != 2) activeCellStatusList [siblingCellPosition1*14+7]++;
                                    
                                    activeCellStatusList [siblingCellPosition1*14+4] = expandDoubLingDoubCF [randInit*2];
                                    activeCellStatusList [siblingCellPosition1*14+5] = 2;
                                    activeCellStatusList [counter1*14+6] = siblingCellNo1;
                                    activeCellStatusList [siblingCellPosition1*14+8] = (int)simProcessDataProgHold [18];
                                    fusionCount++;
                                    loopCheck = 1;
                                }
                                else{
                                    
                                    if (activeCellStatusList [siblingCellPosition1*14+5] != 2) activeCellStatusList [siblingCellPosition1*14+7]++;
                                    
                                    activeCellStatusList [siblingCellPosition1*14+5] = 2;
                                    activeCellStatusList [counter1*14+6] = siblingCellNo1;
                                    activeCellStatusList [siblingCellPosition1*14+8] = (int)simProcessDataProgHold [18];
                                    fusionCount++;
                                    loopCheck = 1;
                                }
                            }
                            
                            if (loopCheck == 0){
                                if (activeCellStatusList [siblingCellPosition1*14+5] != 2) activeCellStatusList [siblingCellPosition1*14+7]++;
                                
                                activeCellStatusList [siblingCellPosition1*14+5] = 2;
                                activeCellStatusList [counter1*14+6] = siblingCellNo1;
                                activeCellStatusList [siblingCellPosition1*14+8] = (int)simProcessDataProgHold [18];
                                fusionCount++;
                            }
                        }
                        else if (secondEventBDCFList [randInit] == 9){
                            [self expandBDCFCDSet];
                            
                            if (expandBDCFCDCount != 0){
                                randInit = rand() % expandBDCFCDCount/2 + 0;
                                
                                if (expandBDCFCD [randInit*2] > siblingFusionDoub1){
                                    activeCellStatusList [siblingCellPosition1*14+4] = expandBDCFCD [randInit*2];
                                    activeCellStatusList [siblingCellPosition1*14+5] = 3;
                                    activeCellStatusList [counter1*14+6] = siblingCellNo1;
                                    fusionCount++;
                                }
                                else{
                                    
                                    activeCellStatusList [siblingCellPosition1*14+5] = 3;
                                    activeCellStatusList [counter1*14+6] = siblingCellNo1;
                                    fusionCount++;
                                }
                            }
                            else{
                                
                                activeCellStatusList [siblingCellPosition1*14+5] = 3;
                                activeCellStatusList [counter1*14+6] = siblingCellNo1;
                                fusionCount++;
                            }
                        }
                    }
                    else{
                        
                        siblingFusionCheck1 = 0;
                        siblingFusionCheck2 = 0;
                        siblingFusionDoub1 = 0;
                        siblingFusionDoub2 = 0;
                        siblingCellNo1 = 0;
                        siblingCellNo2 = 0;
                        
                        for (int counter2 = 0; counter2 < activeCellStatusListCount/14; counter2++){
                            if ((activeCellStatusList [counter2*14+1] == activeCellStatusList [counter1*14] || activeCellStatusList [counter2*14+2] == activeCellStatusList [counter1*14]) && activeCellStatusList [counter2*14+3] == activeCellStatusList [counter1*14+3]){
                                if (siblingFusionCheck1 == 0 && activeCellStatusList [counter2*14+5] != 0){
                                    siblingFusionCheck1 = activeCellStatusList [counter2*14+5];
                                    siblingFusionDoub1 = activeCellStatusList [counter2*14+4];
                                    siblingCellNo1 = activeCellStatusList [counter2*14];
                                    siblingCellPosition1 = counter2;
                                }
                                else if (siblingFusionCheck1 != 0 && siblingFusionCheck2 == 0 && activeCellStatusList [counter2*14+5] != 0){
                                    siblingFusionCheck2 = activeCellStatusList [counter2*14+5];
                                    siblingFusionDoub2 = activeCellStatusList [counter2*14+4];
                                    siblingCellNo2 = activeCellStatusList [counter2*14];
                                    siblingCellPosition2 = counter2;
                                    break;
                                }
                            }
                        }
                        
                        //cout<<siblingCellNo1<<" "<<siblingFusionCheck1<<" "<<siblingFusionDoub1<<" "<<siblingCellPosition1<<" "<<fusionCount<<" fuse2"<<endl
                        //cout<<siblingCellNo2<<" "<<siblingFusionCheck2<<" "<<siblingFusionDoub2<<" "<<siblingCellPosition2<<" "<<fusionCount<<" fuse3"<<endl
                        
                        if (siblingFusionCheck1 == 6 && siblingFusionCheck2 != 6){ //----Sib2 is subject to change--
                            [self secondEventTDCFListSet];
                            randInit = rand() % 100 + 0;
                            
                            if (secondEventTDCFList [randInit] == 0){
                                activeCellStatusList [siblingCellPosition1*14+6] = siblingCellNo2;
                                activeCellStatusList [counter1*14+6] = siblingCellNo2;
                                fusionCount++;
                            }
                            else{
                                
                                if ((activeCellStatusList [counter1*14+8] == 2 || activeCellStatusList [counter1*14+8] == 3) && activeCellStatusList [counter1*14+8] == activeCellStatusList [counter1*14+7] && secondEventTDCFList [randInit] == 15){
                                    selectChange = 16;
                                }
                                else selectChange = secondEventTDCFList [randInit];
                                
                                if (selectChange == 14){
                                    [self expandDoubLingDoubCFSet];
                                    loopCheck = 0;
                                    
                                    if (expandDoubLingDoubCFCount != 0){
                                        randInit = rand() % expandDoubLingDoubCFCount/2 + 0;
                                        
                                        if (expandDoubLingDoubCF [randInit*2] > siblingFusionDoub2){
                                            activeCellStatusList [siblingCellPosition2*14+4] = expandDoubLingDoubCF [randInit*2];
                                            activeCellStatusList [siblingCellPosition2*14+5] = 1;
                                            activeCellStatusList [siblingCellPosition1*14+6] = siblingCellNo2;
                                            activeCellStatusList [counter1*14+6] = siblingCellNo2;
                                            
                                            activeCellStatusList [siblingCellPosition2*14+7] = 0;
                                            activeCellStatusList [siblingCellPosition2*14+8] = 0;
                                            fusionCount++;
                                            loopCheck = 1;
                                        }
                                        else{
                                            
                                            activeCellStatusList [siblingCellPosition2*14+5] = 1;
                                            activeCellStatusList [siblingCellPosition1*14+6] = siblingCellNo2;
                                            activeCellStatusList [counter1*14+6] = siblingCellNo2;
                                            
                                            activeCellStatusList [siblingCellPosition2*14+7] = 0;
                                            activeCellStatusList [siblingCellPosition2*14+8] = 0;
                                            fusionCount++;
                                            loopCheck = 1;
                                        }
                                    }
                                    
                                    if (loopCheck == 0){
                                        activeCellStatusList [siblingCellPosition2*14+5] = 1;
                                        activeCellStatusList [siblingCellPosition1*14+6] = siblingCellNo2;
                                        activeCellStatusList [counter1*14+6] = siblingCellNo2;
                                        
                                        activeCellStatusList [siblingCellPosition2*14+7] = 0;
                                        activeCellStatusList [siblingCellPosition2*14+8] = 0;
                                        fusionCount++;
                                    }
                                }
                                else if (selectChange == 15){
                                    [self expandDoubLingDoubCFSet];
                                    loopCheck = 0;
                                    
                                    if (expandDoubLingDoubCFCount != 0){
                                        randInit = rand() % expandDoubLingDoubCFCount/2 + 0;
                                        
                                        if (expandDoubLingDoubCF [randInit*2] > siblingFusionDoub2){
                                            if (activeCellStatusList [siblingCellPosition2*14+5] != 2) activeCellStatusList [siblingCellPosition2*14+7]++;
                                            
                                            activeCellStatusList [siblingCellPosition2*14+4] = expandDoubLingDoubCF [randInit*2];
                                            activeCellStatusList [siblingCellPosition2*14+5] = 2;
                                            activeCellStatusList [siblingCellPosition1*14+6] = siblingCellNo2;
                                            activeCellStatusList [counter1*14+6] = siblingCellNo2;
                                            activeCellStatusList [siblingCellPosition2*14+8] = (int)simProcessDataProgHold [18];
                                            fusionCount++;
                                            loopCheck = 1;
                                        }
                                        else{
                                            
                                            if (activeCellStatusList [siblingCellPosition2*14+5] != 2) activeCellStatusList [siblingCellPosition2*14+7]++;
                                            
                                            activeCellStatusList [siblingCellPosition2*14+5] = 2;
                                            activeCellStatusList [siblingCellPosition1*14+6] = siblingCellNo2;
                                            activeCellStatusList [counter1*14+6] = siblingCellNo2;
                                            activeCellStatusList [siblingCellPosition2*14+8] = (int)simProcessDataProgHold [18];
                                            fusionCount++;
                                            loopCheck = 1;
                                        }
                                    }
                                    
                                    if (loopCheck == 0){
                                        if (activeCellStatusList [siblingCellPosition2*14+5] != 2) activeCellStatusList [siblingCellPosition2*14+7]++;
                                        
                                        activeCellStatusList [siblingCellPosition2*14+5] = 2;
                                        activeCellStatusList [siblingCellPosition1*14+6] = siblingCellNo2;
                                        activeCellStatusList [counter1*14+6] = siblingCellNo2;
                                        activeCellStatusList [siblingCellPosition2*14+8] = (int)simProcessDataProgHold [18];
                                        fusionCount++;
                                    }
                                }
                                else if (selectChange == 16){
                                    [self expandTDCFCDSet];
                                    
                                    if (expandTDCFCDCount != 0){
                                        randInit = rand() % expandTDCFCDCount/2 + 0;
                                        
                                        if (expandTDCFCD [randInit*2] > siblingFusionDoub2){
                                            activeCellStatusList [siblingCellPosition2*14+4] = expandTDCFCD [randInit*2];
                                            activeCellStatusList [siblingCellPosition2*14+5] = 3;
                                            activeCellStatusList [siblingCellPosition1*14+6] = siblingCellNo2;
                                            activeCellStatusList [counter1*14+6] = siblingCellNo2;
                                            fusionCount++;
                                        }
                                        else{
                                            
                                            activeCellStatusList [siblingCellPosition2*14+5] = 3;
                                            activeCellStatusList [siblingCellPosition1*14+6] = siblingCellNo2;
                                            activeCellStatusList [counter1*14+6] = siblingCellNo2;
                                            fusionCount++;
                                        }
                                    }
                                    else{
                                        
                                        activeCellStatusList [siblingCellPosition2*14+5] = 3;
                                        activeCellStatusList [siblingCellPosition1*14+6] = siblingCellNo2;
                                        activeCellStatusList [counter1*14+6] = siblingCellNo2;
                                        fusionCount++;
                                    }
                                }
                            }
                        }
                        else if (siblingFusionCheck1 != 6 && siblingFusionCheck2 == 6){ //----Sib1 is subject to change--
                            [self secondEventTDCFListSet];
                            randInit = rand() % 100 + 0;
                            
                            if (secondEventTDCFList [randInit] == 0){
                                activeCellStatusList [siblingCellPosition2*14+6] = siblingCellNo1;
                                activeCellStatusList [counter1*14+6] = siblingCellNo1;
                                fusionCount++;
                            }
                            else{
                                
                                if ((activeCellStatusList [counter1*14+8] == 2 || activeCellStatusList [counter1*14+8] == 3) && activeCellStatusList [counter1*14+8] == activeCellStatusList [counter1*14+7] && secondEventTDCFList [randInit] == 15){
                                    selectChange = 16;
                                }
                                else selectChange = secondEventTDCFList [randInit];
                                
                                if (selectChange == 14){
                                    [self expandDoubLingDoubCFSet];
                                    loopCheck = 0;
                                    
                                    if (expandDoubLingDoubCFCount != 0){
                                        randInit = rand() % expandDoubLingDoubCFCount/2 + 0;
                                        
                                        if (expandDoubLingDoubCF [randInit*2] > siblingFusionDoub1){
                                            activeCellStatusList [siblingCellPosition1*14+4] = expandDoubLingDoubCF [randInit*2];
                                            activeCellStatusList [siblingCellPosition1*14+5] = 1;
                                            activeCellStatusList [siblingCellPosition2*14+6] = siblingCellNo1;
                                            activeCellStatusList [counter1*14+6] = siblingCellNo1;
                                            
                                            activeCellStatusList [siblingCellPosition1*14+7] = 0;
                                            activeCellStatusList [siblingCellPosition1*14+8] = 0;
                                            
                                            fusionCount++;
                                            loopCheck = 1;
                                        }
                                        else{
                                            
                                            activeCellStatusList [siblingCellPosition1*14+5] = 1;
                                            activeCellStatusList [siblingCellPosition2*14+6] = siblingCellNo1;
                                            activeCellStatusList [counter1*14+6] = siblingCellNo1;
                                            
                                            activeCellStatusList [siblingCellPosition1*14+7] = 0;
                                            activeCellStatusList [siblingCellPosition1*14+8] = 0;
                                            fusionCount++;
                                            loopCheck = 1;
                                        }
                                    }
                                    
                                    if (loopCheck == 0){
                                        activeCellStatusList [siblingCellPosition1*14+5] = 1;
                                        activeCellStatusList [siblingCellPosition2*14+6] = siblingCellNo1;
                                        activeCellStatusList [counter1*14+6] = siblingCellNo1;
                                        
                                        activeCellStatusList [siblingCellPosition1*14+7] = 0;
                                        activeCellStatusList [siblingCellPosition1*14+8] = 0;
                                        fusionCount++;
                                    }
                                }
                                else if (selectChange == 15){
                                    [self expandDoubLingDoubCFSet];
                                    loopCheck = 0;
                                    
                                    if (expandDoubLingDoubCFCount != 0){
                                        randInit = rand() % expandDoubLingDoubCFCount/2 + 0;
                                        
                                        if (expandDoubLingDoubCF [randInit*2] > siblingFusionDoub1){
                                            if (activeCellStatusList [siblingCellPosition1*14+5] != 2) activeCellStatusList [siblingCellPosition1*14+7]++;
                                            
                                            activeCellStatusList [siblingCellPosition1*14+4] = expandDoubLingDoubCF [randInit*2];
                                            activeCellStatusList [siblingCellPosition1*14+5] = 2;
                                            activeCellStatusList [siblingCellPosition2*14+6] = siblingCellNo1;
                                            activeCellStatusList [counter1*14+6] = siblingCellNo1;
                                            activeCellStatusList [siblingCellPosition1*14+8] = (int)simProcessDataProgHold [18];
                                            fusionCount++;
                                            loopCheck = 1;
                                        }
                                        else{
                                            
                                            if (activeCellStatusList [siblingCellPosition1*14+5] != 2) activeCellStatusList [siblingCellPosition1*14+7]++;
                                            
                                            activeCellStatusList [siblingCellPosition1*14+5] = 2;
                                            activeCellStatusList [siblingCellPosition2*14+6] = siblingCellNo1;
                                            activeCellStatusList [counter1*14+6] = siblingCellNo1;
                                            activeCellStatusList [siblingCellPosition1*14+8] = (int)simProcessDataProgHold [18];
                                            fusionCount++;
                                            loopCheck = 1;
                                        }
                                    }
                                    
                                    if (loopCheck == 0){
                                        if (activeCellStatusList [siblingCellPosition1*14+5] != 2) activeCellStatusList [siblingCellPosition1*14+7]++;
                                        
                                        activeCellStatusList [siblingCellPosition1*14+5] = 2;
                                        activeCellStatusList [siblingCellPosition2*14+6] = siblingCellNo1;
                                        activeCellStatusList [counter1*14+6] = siblingCellNo1;
                                        activeCellStatusList [siblingCellPosition1*14+8] = (int)simProcessDataProgHold [18];
                                        fusionCount++;
                                    }
                                }
                                else if (selectChange == 16){
                                    [self expandTDCFCDSet];
                                    
                                    if (expandTDCFCDCount != 0){
                                        randInit = rand() % expandTDCFCDCount/2 + 0;
                                        
                                        if (expandTDCFCD [randInit*2] > siblingFusionDoub1){
                                            activeCellStatusList [siblingCellPosition1*14+4] = expandTDCFCD [randInit*2];
                                            activeCellStatusList [siblingCellPosition1*14+5] = 3;
                                            activeCellStatusList [siblingCellPosition2*14+6] = siblingCellNo1;
                                            activeCellStatusList [counter1*14+6] = siblingCellNo1;
                                            fusionCount++;
                                        }
                                        else{
                                            
                                            activeCellStatusList [siblingCellPosition1*14+5] = 3;
                                            activeCellStatusList [siblingCellPosition2*14+6] = siblingCellNo1;
                                            activeCellStatusList [counter1*14+6] = siblingCellNo1;
                                            fusionCount++;
                                        }
                                    }
                                    else{
                                        
                                        activeCellStatusList [siblingCellPosition1*14+5] = 3;
                                        activeCellStatusList [siblingCellPosition2*14+6] = siblingCellNo1;
                                        activeCellStatusList [counter1*14+6] = siblingCellNo1;
                                        fusionCount++;
                                    }
                                }
                            }
                        }
                        else if (siblingFusionCheck1 != 6 && siblingFusionCheck2 != 6){
                            randInit = rand() % 1 + 0;
                            
                            if (randInit == 1){
                                siblingCellPositionSelect = siblingCellPosition1;
                                siblingCellNoSelect = siblingCellNo1;
                                siblingCellDoubSelect = siblingFusionDoub1;
                                fusionCount++;
                            }
                            else{
                                
                                siblingCellPositionSelect = siblingCellPosition2;
                                siblingCellNoSelect = siblingCellNo2;
                                siblingCellDoubSelect = siblingFusionDoub2;
                                fusionCount++;
                            }
                            
                            [self secondEventTDCFListSet];
                            randInit = rand() % 100 + 0;
                            
                            if (secondEventTDCFList [randInit] == 0){
                                activeCellStatusList [counter1*14+6] = siblingCellNoSelect;
                                fusionCount++;
                            }
                            else{
                                
                                if ((activeCellStatusList [counter1*14+8] == 2 || activeCellStatusList [counter1*14+8] == 3) && activeCellStatusList [counter1*14+8] == activeCellStatusList [counter1*14+7] && secondEventTDCFList [randInit] == 15){
                                    selectChange = 16;
                                }
                                else selectChange = secondEventTDCFList [randInit];
                                
                                if (selectChange == 14){
                                    [self expandDoubLingDoubCFSet];
                                    loopCheck = 0;
                                    
                                    if (expandDoubLingDoubCFCount != 0){
                                        randInit = rand() % expandDoubLingDoubCFCount/2 + 0;
                                        
                                        if (expandDoubLingDoubCF [randInit*2] > siblingCellDoubSelect){
                                            activeCellStatusList [siblingCellPositionSelect*14+4] = expandDoubLingDoubCF [randInit*2];
                                            activeCellStatusList [siblingCellPositionSelect*14+5] = 1;
                                            activeCellStatusList [counter1*14+6] = siblingCellNoSelect;
                                            
                                            activeCellStatusList [siblingCellPositionSelect*14+7] = 0;
                                            activeCellStatusList [siblingCellPositionSelect*14+8] = 0;
                                            
                                            fusionCount++;
                                            loopCheck = 1;
                                        }
                                        else{
                                            
                                            activeCellStatusList [siblingCellPositionSelect*14+5] = 1;
                                            activeCellStatusList [counter1*14+6] = siblingCellNoSelect;
                                            
                                            activeCellStatusList [siblingCellPositionSelect*14+7] = 0;
                                            activeCellStatusList [siblingCellPositionSelect*14+8] = 0;
                                            
                                            fusionCount++;
                                            loopCheck = 1;
                                        }
                                    }
                                    
                                    if (loopCheck == 0){
                                        activeCellStatusList [siblingCellPositionSelect*14+5] = 1;
                                        activeCellStatusList [counter1*14+6] = siblingCellNoSelect;
                                        
                                        activeCellStatusList [siblingCellPositionSelect*14+7] = 0;
                                        activeCellStatusList [siblingCellPositionSelect*14+8] = 0;
                                        
                                        fusionCount++;
                                    }
                                }
                                else if (selectChange == 15){
                                    [self expandDoubLingDoubCFSet];
                                    loopCheck = 0;
                                    
                                    if (expandDoubLingDoubCFCount != 0){
                                        randInit = rand() % expandDoubLingDoubCFCount/2 + 0;
                                        
                                        if (expandDoubLingDoubCF [randInit*2] > siblingCellDoubSelect){
                                            if (activeCellStatusList [siblingCellPositionSelect*14+5] != 2) activeCellStatusList [siblingCellPositionSelect*14+7]++;
                                            
                                            activeCellStatusList [siblingCellPositionSelect*14+4] = expandDoubLingDoubCF [randInit*2];
                                            activeCellStatusList [siblingCellPositionSelect*14+5] = 2;
                                            activeCellStatusList [counter1*14+6] = siblingCellNoSelect;
                                            activeCellStatusList [siblingCellPositionSelect*14+8] = (int)simProcessDataProgHold [18];
                                            
                                            fusionCount++;
                                            loopCheck = 1;
                                        }
                                        else{
                                            
                                            if (activeCellStatusList [siblingCellPositionSelect*14+5] != 2) activeCellStatusList [siblingCellPositionSelect*14+7]++;
                                            
                                            activeCellStatusList [siblingCellPosition1*14+5] = 2;
                                            activeCellStatusList [counter1*14+6] = siblingCellNoSelect;
                                            activeCellStatusList [siblingCellPositionSelect*14+8] = (int)simProcessDataProgHold [18];
                                            
                                            fusionCount++;
                                            loopCheck = 1;
                                        }
                                    }
                                    
                                    if (loopCheck == 0){
                                        if (activeCellStatusList [siblingCellPositionSelect*14+5] != 2) activeCellStatusList [siblingCellPositionSelect*14+7]++;
                                        
                                        activeCellStatusList [siblingCellPositionSelect*14+5] = 2;
                                        activeCellStatusList [counter1*14+6] = siblingCellNoSelect;
                                        activeCellStatusList [siblingCellPositionSelect*14+8] = (int)simProcessDataProgHold [18];
                                        
                                        fusionCount++;
                                    }
                                }
                                else if (selectChange == 16){
                                    [self expandTDCFCDSet];
                                    
                                    if (expandTDCFCDCount != 0){
                                        randInit = rand() % expandTDCFCDCount/2 + 0;
                                        
                                        if (expandTDCFCD [randInit*2] > siblingCellDoubSelect){
                                            activeCellStatusList [siblingCellPositionSelect*14+4] = expandTDCFCD [randInit*2];
                                            activeCellStatusList [siblingCellPositionSelect*14+5] = 3;
                                            activeCellStatusList [counter1*14+6] = siblingCellNoSelect;
                                            fusionCount++;
                                        }
                                        else{
                                            
                                            activeCellStatusList [siblingCellPositionSelect*14+5] = 3;
                                            activeCellStatusList [counter1*14+6] = siblingCellNoSelect;
                                            fusionCount++;
                                        }
                                    }
                                    else{
                                        
                                        activeCellStatusList [siblingCellPositionSelect*14+5] = 3;
                                        activeCellStatusList [counter1*14+6] = siblingCellNoSelect;
                                        fusionCount++;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            
            //for (int counterA = 0; counterA < activeCellStatusListCount/12; counterA++){
            //    for (int counterB = 0; counterB < 12; counterB++) cout<<" "<<activeCellStatusList [counterA*14+counterB];
            //    cout<<" activeCellStatusList "<<counterA<<endl;
            //}
            
            if (terminate2 == 0){
                int *lineageAddTemp = new int [10000000];
                lineageAddTempLimit = 10000000;
                
                int *tempListOfCells = new int [10000000];
                tempListOfCellsCount = 0;
                tempListOfCellsLimit = 10000000;
                
                long *fusionPartnerList = new long [fusionCount*5+100];
                fusionPartnerListCount = 0;
                
                long *startPositionList = new long [(activeCellStatusListCount/14)*3+10];
                startPositionListCount = 0;
                
                for (int counter1 = 0; counter1 < activeCellStatusListCount/14; counter1++){
                    if (terminateSimFlag == 1){
                        terminate2 = 1;
                        break;
                    }
                    
                    processingStatusCall2 = 1;
                    processingStatus2 = to_string(counter1)+"/"+to_string(activeCellStatusListCount/14);
                    
                    //cout<<extendEnd <<" "<<activeCellStatusList [counter1*14]<<" "<<activeCellStatusList [counter1*14+3]<<" "<<activeCellStatusListCount/12<<" "<<counter1<<" loop"<<endl;
                    
                    lineageAddTempCount = 0;
                    timeKeep = 0;
                    cellNoFusionCheckHold = -1;
                    markingFlag = 0;
                    
                    if (activeCellStatusList [counter1*14+5] == 5 || activeCellStatusList [counter1*14+5] == 9 || activeCellStatusList [counter1*14+5] == 70 || activeCellStatusList [counter1*14+5] == 30){
                        for (unsigned long counter2 = 0; counter2 < cellLineageSummaryArrayCount/9; counter2++){
                            if (cellLineageSummaryArray [counter2*9+2] == activeCellStatusList [counter1*14+3] && cellLineageSummaryArray [counter2*9+3] == activeCellStatusList [counter1*14]){
                                for (unsigned long counter3 = (unsigned long)cellLineageSummaryArray [counter2*9]/9; counter3 <= (unsigned long)cellLineageSummaryArray [counter2*9+1]/9; counter3++){
                                    if (lineageAddTempCount+11 > lineageAddTempLimit){
                                        int *arrayUpDate = new int [lineageAddTempCount+11];
                                        
                                        for (int counter4 = 0; counter4 < lineageAddTempCount; counter4++) arrayUpDate [counter4] = lineageAddTemp [counter4];
                                        
                                        delete [] lineageAddTemp;
                                        lineageAddTemp = new int [lineageAddTempLimit+1000000];
                                        lineageAddTempLimit = lineageAddTempLimit+1000000;
                                        
                                        for (int counter4 = 0; counter4 < lineageAddTempCount; counter4++) lineageAddTemp [counter4] = arrayUpDate [counter4];
                                        delete [] arrayUpDate;
                                    }
                                    
                                    lineageAddTemp [lineageAddTempCount] = cellLineageTempArray [counter3*11], lineageAddTempCount++;
                                    lineageAddTemp [lineageAddTempCount] = cellLineageTempArray [counter3*11+1], lineageAddTempCount++;
                                    lineageAddTemp [lineageAddTempCount] = cellLineageTempArray [counter3*11+2], lineageAddTempCount++;
                                    lineageAddTemp [lineageAddTempCount] = cellLineageTempArray [counter3*11+3], lineageAddTempCount++;
                                    lineageAddTemp [lineageAddTempCount] = cellLineageTempArray [counter3*11+4], lineageAddTempCount++;
                                    lineageAddTemp [lineageAddTempCount] = cellLineageTempArray [counter3*11+5], lineageAddTempCount++;
                                    lineageAddTemp [lineageAddTempCount] = cellLineageTempArray [counter3*11+6], lineageAddTempCount++;
                                    lineageAddTemp [lineageAddTempCount] = cellLineageTempArray [counter3*11+7], lineageAddTempCount++;
                                    lineageAddTemp [lineageAddTempCount] = cellLineageTempArray [counter3*11+8], lineageAddTempCount++;
                                    lineageAddTemp [lineageAddTempCount] = cellLineageTempArray [counter3*11+9], lineageAddTempCount++;
                                    lineageAddTemp [lineageAddTempCount] = cellLineageTempArray [counter3*11+10], lineageAddTempCount++;
                                    
                                    timeKeep = cellLineageTempArray [counter3*11+2];
                                    cellLineageTempArray [counter3*11+8] = -1;
                                    
                                    if (activeCellStatusList [counter1*14+5] == 70) activeCellStatusList [counter1*14+5] = 7;
                                    else if (activeCellStatusList [counter1*14+5] == 30) activeCellStatusList [counter1*14+5] = 3;
                                }
                                
                                break;
                            }
                        }
                    }
                    else{
                        
                        for (unsigned long counter2 = 0; counter2 < cellLineageSummaryArrayCount/9; counter2++){
                            if (cellLineageSummaryArray [counter2*9+2] == activeCellStatusList [counter1*14+3] && cellLineageSummaryArray [counter2*9+3] == activeCellStatusList [counter1*14]){
                                if (lineageAddTempCount+11 > lineageAddTempLimit){
                                    int *arrayUpDate = new int [lineageAddTempCount+11];
                                    
                                    for (int counter4 = 0; counter4 < lineageAddTempCount; counter4++) arrayUpDate [counter4] = lineageAddTemp [counter4];
                                    
                                    delete [] lineageAddTemp;
                                    lineageAddTemp = new int [lineageAddTempLimit+1000000];
                                    lineageAddTempLimit = lineageAddTempLimit+1000000;
                                    
                                    for (int counter4 = 0; counter4 < lineageAddTempCount; counter4++) lineageAddTemp [counter4] = arrayUpDate [counter4];
                                    delete [] arrayUpDate;
                                }
                                
                                setTime = (unsigned long)(cellLineageSummaryArray [counter2*9]);
                                
                                lineageAddTemp [lineageAddTempCount] = cellLineageTempArray [setTime], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = cellLineageTempArray [setTime+1], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = cellLineageTempArray [setTime+2], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = cellLineageTempArray [setTime+3], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = cellLineageTempArray [setTime+4], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = cellLineageTempArray [setTime+5], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = cellLineageTempArray [setTime+6], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = cellLineageTempArray [setTime+7], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = cellLineageTempArray [setTime+8], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = cellLineageTempArray [setTime+9], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = cellLineageTempArray [setTime+10], lineageAddTempCount++;
                                
                                timeKeep = cellLineageTempArray [setTime+2];
                                
                                cellLineageTempArray [setTime+8] = -1;
                                
                                break;
                            }
                        }
                    }
                    
                    if (activeCellStatusList [counter1*14+4]+timeKeep > growthCycleBase) extendEnd = growthCycleBase-timeKeep;
                    else extendEnd = (int)activeCellStatusList [counter1*14+4];
                    
                    //cout<<growthCycleBase<<" "<<extendEnd <<" "<<activeCellStatusList [counter1*14]<<" "<<activeCellStatusList [counter1*14+3]<<" "<<activeCellStatusList [counter1*14+5]<<" "<<activeCellStatusListCount/12<<" "<<counter1<<" "<<timeKeep<<" loop2"<<endl;
                    
                    if (timeKeep <= growthCycleBase){
                        timeKeep++;
                        
                        if (activeCellStatusListKeepCount+100 > activeCellStatusListKeepLimit){
                            int *arrayUpDate = new int [activeCellStatusListKeepCount+50];
                            
                            for (unsigned long counter3 = 0; counter3 < activeCellStatusListKeepCount; counter3++) arrayUpDate [counter3] = activeCellStatusListKeep [counter3];
                            
                            delete [] activeCellStatusListKeep;
                            activeCellStatusListKeep = new int [activeCellStatusListKeepLimit+100000];
                            activeCellStatusListKeepLimit = activeCellStatusListKeepLimit+100000;
                            
                            for (unsigned long counter3 = 0; counter3 < activeCellStatusListKeepCount; counter3++) activeCellStatusListKeep [counter3] = arrayUpDate [counter3];
                            delete [] arrayUpDate;
                        }
                        
                        
                        for (int counter2 = 0; counter2 < extendEnd; counter2++){
                            if (lineageAddTempCount+11 > lineageAddTempLimit){
                                int *arrayUpDate = new int [lineageAddTempCount+11];
                                
                                for (int counter3 = 0; counter3 < lineageAddTempCount; counter3++) arrayUpDate [counter3] = lineageAddTemp [counter3];
                                
                                delete [] lineageAddTemp;
                                lineageAddTemp = new int [lineageAddTempLimit+1000000];
                                lineageAddTempLimit = lineageAddTempLimit+1000000;
                                
                                for (int counter3 = 0; counter3 < lineageAddTempCount; counter3++) lineageAddTemp [counter3] = arrayUpDate [counter3];
                                delete [] arrayUpDate;
                            }
                            
                            lineageAddTemp [lineageAddTempCount] = 1, lineageAddTempCount++;
                            lineageAddTemp [lineageAddTempCount] = 1, lineageAddTempCount++;
                            lineageAddTemp [lineageAddTempCount] = timeKeep, lineageAddTempCount++;
                            lineageAddTemp [lineageAddTempCount] = 2, lineageAddTempCount++;
                            lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                            lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14], lineageAddTempCount++;
                            lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14+3], lineageAddTempCount++;
                            lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                            lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                            lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                            lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                            
                            if (timeKeep == growthCycleBase){
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+1], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+2], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+3], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+4], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+5], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+6], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+7], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+8], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+9], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+10], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+11], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+12], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+13], activeCellStatusListKeepCount++;
                                
                                cellNoFusionCheckHold = activeCellStatusList [counter1*14];
                                
                                activeCellStatusList [counter1*14+1] = -1;
                                
                                if (activeCellStatusList [counter1*14+5] != 5 && activeCellStatusList [counter1*14+5] != 4){
                                    markingFlag = 1;
                                }
                                
                                timeKeep++;
                                
                                break;
                            }
                            else timeKeep++;
                        }
                        
                        //cout<<growthCycleBase<<" "<<extendEnd <<" "<<activeCellStatusList [counter1*14]<<" "<<activeCellStatusList [counter1*14+3]<<" "<<activeCellStatusList [counter1*14+5]<<" "<<activeCellStatusListCount/12<<" "<<counter1<<" "<<timeKeep<<" loop3"<<endl;
                        
                        if (activeCellStatusList [counter1*14+5] == 9){
                            cellNoFusionCheckHold = activeCellStatusList [counter1*14];
                            activeCellStatusList [counter1*14+1] = -1;
                            
                            if (reachMaxDivision > timeKeep) reachMaxDivision = timeKeep;
                        }
                        
                        if (activeCellStatusList [counter1*14+5] == 5 && activeCellStatusList [counter1*14+1] != -1){
                            cellNoFusionCheckHold = activeCellStatusList [counter1*14];
                        }
                        
                        if (tempListOfCellsCount+20 > tempListOfCellsLimit){
                            int *arrayUpDate = new int [tempListOfCellsCount+10];
                            
                            for (unsigned long counter2 = 0; counter2 < tempListOfCellsCount; counter2++) arrayUpDate [counter2] = tempListOfCells [counter2];
                            
                            delete [] tempListOfCells;
                            tempListOfCells = new int [tempListOfCellsLimit+10000000];
                            tempListOfCellsLimit = tempListOfCellsLimit+10000000;
                            
                            for (unsigned long counter2 = 0; counter2 < tempListOfCellsCount; counter2++) tempListOfCells [counter2] = arrayUpDate [counter2];
                            delete [] arrayUpDate;
                        }
                        
                        if (lineageAddTempCount+50 > lineageAddTempLimit){
                            int *arrayUpDate = new int [lineageAddTempCount+11];
                            
                            for (int counter3 = 0; counter3 < lineageAddTempCount; counter3++) arrayUpDate [counter3] = lineageAddTemp [counter3];
                            
                            delete [] lineageAddTemp;
                            lineageAddTemp = new int [lineageAddTempLimit+1000000];
                            lineageAddTempLimit = lineageAddTempLimit+1000000;
                            
                            for (int counter3 = 0; counter3 < lineageAddTempCount; counter3++) lineageAddTemp [counter3] = arrayUpDate [counter3];
                            delete [] arrayUpDate;
                        }
                        
                        if (cellNoLingNoListCount+10 > cellNoLingNoListLimit){
                            int *arrayUpDate = new int [cellNoLingNoListCount+10];
                            
                            for (unsigned long counter3 = 0; counter3 < cellNoLingNoListCount; counter3++) arrayUpDate [counter3] = cellNoLingNoList [counter3];
                            
                            delete [] cellNoLingNoList;
                            cellNoLingNoList = new int [cellNoLingNoListLimit+100000];
                            cellNoLingNoListLimit = cellNoLingNoListLimit+100000;
                            
                            for (unsigned long counter3 = 0; counter3 < cellNoLingNoListCount; counter3++) cellNoLingNoList [counter3] = arrayUpDate [counter3];
                            delete [] arrayUpDate;
                        }
                        
                        if (activeCellStatusList [counter1*14+5] == 1 || activeCellStatusList [counter1*14+5] == 7){
                            if (timeKeep+2 <= growthCycleBase){
                                lineageAddTemp [lineageAddTempCount] = 1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = timeKeep, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 6, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14+3], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                
                                lineageAddTemp [lineageAddTempCount] = 1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = timeKeep+1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 32, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14+3], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                
                                createNewCellNo = [[CreateNewCellNo alloc] init];
                                newCellNumber1 = [createNewCellNo cellNumberAddition:counter1];
                                
                                cellNoLingNoList [cellNoLingNoListCount] = activeCellStatusList [counter1*14+3], cellNoLingNoListCount++;
                                cellNoLingNoList [cellNoLingNoListCount] = newCellNumber1, cellNoLingNoListCount++;
                                
                                createNewCellNo = [[CreateNewCellNo alloc] init];
                                newCellNumber2 = [createNewCellNo cellNumberSubtraction:counter1];
                                
                                cellNoLingNoList [cellNoLingNoListCount] = activeCellStatusList [counter1*14+3], cellNoLingNoListCount++;
                                cellNoLingNoList [cellNoLingNoListCount] = newCellNumber2, cellNoLingNoListCount++;
                                
                                lineageAddTemp [lineageAddTempCount] = 1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = timeKeep+2, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 31, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = newCellNumber1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14+3], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                
                                lineageAddTemp [lineageAddTempCount] = 1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = timeKeep+2, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 31, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = newCellNumber2, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14+3], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                
                                if (timeKeep+2 < growthCycleBase){
                                    tempListOfCells [tempListOfCellsCount] = activeCellStatusList [counter1*14+3], tempListOfCellsCount++;
                                    tempListOfCells [tempListOfCellsCount] = activeCellStatusList [counter1*14], tempListOfCellsCount++;
                                    tempListOfCells [tempListOfCellsCount] = newCellNumber1, tempListOfCellsCount++;
                                    tempListOfCells [tempListOfCellsCount] = newCellNumber2, tempListOfCellsCount++;
                                    tempListOfCells [tempListOfCellsCount] = 0, tempListOfCellsCount++;
                                    tempListOfCells [tempListOfCellsCount] = activeCellStatusList [counter1*14+5], tempListOfCellsCount++;
                                    tempListOfCells [tempListOfCellsCount] = activeCellStatusList [counter1*14+4], tempListOfCellsCount++;
                                }
                                else{
                                    
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = newCellNumber1, activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = newCellNumber2, activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = 0, activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusList [counter1*14+3], activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = 0, activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = 1, activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = 0, activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusList [counter1*14+7], activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusList [counter1*14+8], activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusList [counter1*14+9], activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusList [counter1*14], activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusList [counter1*14+4], activeCellStatusListKeepCount++;
                                    
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = 0, activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = 0, activeCellStatusListKeepCount++;
                                    
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = newCellNumber2, activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = newCellNumber1, activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = 0, activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusList [counter1*14+3], activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = 0, activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = 1, activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = 0, activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusList [counter1*14+7], activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusList [counter1*14+8], activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusList [counter1*14+9], activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusList [counter1*14], activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusList [counter1*14+4], activeCellStatusListKeepCount++;
                                    
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = 0, activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = 0, activeCellStatusListKeepCount++;
                                    
                                }
                                
                                cellNoFusionCheckHold = activeCellStatusList [counter1*14];
                                activeCellStatusList [counter1*14+1] = -1;
                            }
                            else if (timeKeep+1 == growthCycleBase){
                                lineageAddTemp [lineageAddTempCount] = 1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = timeKeep, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 2, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14+3], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                
                                lineageAddTemp [lineageAddTempCount] = 1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = timeKeep+1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 2, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14+3], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+1], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+2], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+3], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+4], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+5], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+6], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+7], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+8], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+9], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+10], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+11], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+12], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+13], activeCellStatusListKeepCount++;
                                
                                markingFlag = 1;
                                
                                cellNoFusionCheckHold = activeCellStatusList [counter1*14];
                                activeCellStatusList [counter1*14+1] = -1;
                            }
                            else if (timeKeep == growthCycleBase){
                                lineageAddTemp [lineageAddTempCount] = 1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = timeKeep, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 2, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14+3], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+1], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+2], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+3], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+4], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+5], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+6], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+7], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+8], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+9], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+10], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+11], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+12], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+13], activeCellStatusListKeepCount++;
                                
                                markingFlag = 1;
                                
                                cellNoFusionCheckHold = activeCellStatusList [counter1*14];
                                activeCellStatusList [counter1*14+1] = -1;
                            }
                        }
                        
                        if (activeCellStatusList [counter1*14+5] == 2){
                            if (timeKeep+2 <= growthCycleBase){
                                lineageAddTemp [lineageAddTempCount] = 1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = timeKeep, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 6, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14+3], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                
                                lineageAddTemp [lineageAddTempCount] = 1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = timeKeep+1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 42, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14+3], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                
                                createNewCellNo = [[CreateNewCellNo alloc] init];
                                newCellNumber1 = [createNewCellNo cellNumberAddition:counter1];
                                
                                cellNoLingNoList [cellNoLingNoListCount] = activeCellStatusList [counter1*14+3], cellNoLingNoListCount++;
                                cellNoLingNoList [cellNoLingNoListCount] = newCellNumber1, cellNoLingNoListCount++;
                                
                                createNewCellNo = [[CreateNewCellNo alloc] init];
                                newCellNumber2 = [createNewCellNo cellNumberSubtraction:counter1];
                                
                                cellNoLingNoList [cellNoLingNoListCount] = activeCellStatusList [counter1*14+3], cellNoLingNoListCount++;
                                cellNoLingNoList [cellNoLingNoListCount] = newCellNumber2, cellNoLingNoListCount++;
                                
                                createNewCellNo = [[CreateNewCellNo alloc] init];
                                newCellNumber3 = [createNewCellNo cellNumberAdditionSecond:counter1];
                                
                                cellNoLingNoList [cellNoLingNoListCount] = activeCellStatusList [counter1*14+3], cellNoLingNoListCount++;
                                cellNoLingNoList [cellNoLingNoListCount] = newCellNumber3, cellNoLingNoListCount++;
                                
                                lineageAddTemp [lineageAddTempCount] = 1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = timeKeep+2, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 41, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = newCellNumber1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14+3], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                
                                lineageAddTemp [lineageAddTempCount] = 1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = timeKeep+2, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 41, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = newCellNumber2, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14+3], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                
                                lineageAddTemp [lineageAddTempCount] = 1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = timeKeep+2, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 41, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = newCellNumber3, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14+3], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                
                                if (timeKeep+2 < growthCycleBase){
                                    tempListOfCells [tempListOfCellsCount] = activeCellStatusList [counter1*14+3], tempListOfCellsCount++;
                                    tempListOfCells [tempListOfCellsCount] = activeCellStatusList [counter1*14], tempListOfCellsCount++;
                                    tempListOfCells [tempListOfCellsCount] = newCellNumber1, tempListOfCellsCount++;
                                    tempListOfCells [tempListOfCellsCount] = newCellNumber2, tempListOfCellsCount++;
                                    tempListOfCells [tempListOfCellsCount] = newCellNumber3, tempListOfCellsCount++;
                                    tempListOfCells [tempListOfCellsCount] = activeCellStatusList [counter1*14+5], tempListOfCellsCount++;
                                    tempListOfCells [tempListOfCellsCount] = activeCellStatusList [counter1*14+4], tempListOfCellsCount++;
                                }
                                else{
                                    
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = newCellNumber1, activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = newCellNumber2, activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = newCellNumber3, activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusList [counter1*14+3], activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = 0, activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = 1, activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = 0, activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusList [counter1*14+7], activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusList [counter1*14+8], activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusList [counter1*14+9], activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusList [counter1*14], activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusList [counter1*14+4], activeCellStatusListKeepCount++;
                                    
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = 0, activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = 0, activeCellStatusListKeepCount++;
                                    
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = newCellNumber2, activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = newCellNumber3, activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = newCellNumber1, activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusList [counter1*14+3], activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = 0, activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = 1, activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = 0, activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusList [counter1*14+7], activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusList [counter1*14+8], activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusList [counter1*14+9], activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusList [counter1*14], activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusList [counter1*14+4], activeCellStatusListKeepCount++;
                                    
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = 0, activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = 0, activeCellStatusListKeepCount++;
                                    
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = newCellNumber3, activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = newCellNumber1, activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = newCellNumber2, activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusList [counter1*14+3], activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = 0, activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = 1, activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = 0, activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusList [counter1*14+7], activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusList [counter1*14+8], activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusList [counter1*14+9], activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusList [counter1*14], activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusList [counter1*14+4], activeCellStatusListKeepCount++;
                                    
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = 0, activeCellStatusListKeepCount++;
                                    activeCellStatusListKeep [activeCellStatusListKeepCount] = 0, activeCellStatusListKeepCount++;
                                }
                                
                                cellNoFusionCheckHold = activeCellStatusList [counter1*14];
                                activeCellStatusList [counter1*14+1] = -1;
                            }
                            else if (timeKeep+1 == growthCycleBase){
                                lineageAddTemp [lineageAddTempCount] = 1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = timeKeep, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 2, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14+3], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                
                                lineageAddTemp [lineageAddTempCount] = 1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = timeKeep+1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 2, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14+3], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+1], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+2], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+3], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+4], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+5], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+6], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+7], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+8], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+9], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+10], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+11], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+12], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+13], activeCellStatusListKeepCount++;
                                
                                markingFlag = 1;
                                
                                cellNoFusionCheckHold = activeCellStatusList [counter1*14];
                                activeCellStatusList [counter1*14+1] = -1;
                            }
                            else if (timeKeep == growthCycleBase){
                                lineageAddTemp [lineageAddTempCount] = 1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = timeKeep, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 2, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14+3], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+1], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+2], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+3], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+4], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+5], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+6], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+7], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+8], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+9], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+10], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+11], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+12], activeCellStatusListKeepCount++;
                                activeCellStatusListKeep [activeCellStatusListKeepCount] = activeCellStatusListHold [counter1*14+13], activeCellStatusListKeepCount++;
                                
                                markingFlag = 1;
                                
                                cellNoFusionCheckHold = activeCellStatusList [counter1*14];
                                activeCellStatusList [counter1*14+1] = -1;
                            }
                        }
                        
                        if (activeCellStatusList [counter1*14+5] == 3){
                            if (timeKeep <= growthCycleBase){
                                lineageAddTemp [lineageAddTempCount] = 1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = timeKeep, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 7, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14+3], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                
                                cellNoFusionCheckHold = activeCellStatusList [counter1*14];
                                activeCellStatusList [counter1*14+1] = -1;
                            }
                        }
                        
                        if (activeCellStatusList [counter1*14+5] == 6){
                            if (timeKeep+1 <= growthCycleBase){
                                if (activeCellStatusList [counter1*14+6] != 0){
                                    fusionPartnerList [fusionPartnerListCount] = (long)activeCellStatusList [counter1*14+6], fusionPartnerListCount++;
                                    fusionPartnerList [fusionPartnerListCount] = (long)activeCellStatusList [counter1*14+3], fusionPartnerListCount++;
                                    fusionPartnerList [fusionPartnerListCount] = (long)timeKeep, fusionPartnerListCount++;
                                    fusionPartnerList [fusionPartnerListCount] = (long)activeCellStatusList [counter1*14], fusionPartnerListCount++;
                                    fusionPartnerList [fusionPartnerListCount] = 0, fusionPartnerListCount++;
                                }
                                
                                lineageAddTemp [lineageAddTempCount] = 1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = timeKeep, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 91, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14+6], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14+3], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14+3], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                
                                cellNoFusionCheckHold = activeCellStatusList [counter1*14];
                                activeCellStatusList [counter1*14+1] = -1;
                            }
                            else if (timeKeep == growthCycleBase){
                                lineageAddTemp [lineageAddTempCount] = 1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 1, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = timeKeep, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 7, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14+6], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14+3], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = activeCellStatusList [counter1*14+3], lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                lineageAddTemp [lineageAddTempCount] = 0, lineageAddTempCount++;
                                
                                cellNoFusionCheckHold = activeCellStatusList [counter1*14];
                                activeCellStatusList [counter1*14+1] = -1;
                            }
                        }
                        
                        newLimit = 0;
                        
                        startPositionList [startPositionListCount] = (long)cellNoFusionCheckHold, startPositionListCount++;
                        startPositionList [startPositionListCount] = (long)activeCellStatusList [counter1*14+3], startPositionListCount++;
                        startPositionList [startPositionListCount] = (long)cellLineageTempArrayCount, startPositionListCount++;
                        
                        if (activeCellStatusList [counter1*14+5] == 6){
                            if (timeKeep+1 <= growthCycleBase){
                                if (activeCellStatusList [counter1*14+6] != 0){
                                    fusionPartnerList [fusionPartnerListCount-1] = (long)cellLineageTempArrayCount;
                                }
                            }
                        }
                        
                        for (int counter2 = 0; counter2 < lineageAddTempCount/11; counter2++){
                            if (cellLineageTempArrayLimit+(unsigned long)activeCellStatusListCount*(unsigned long)simProcessDataProgHold [25]*10+10 > 550000000000000000){
                                if (cellLineageTempArrayLimit < 550000000000000000) newLimit = 1;
                                else{
                                    
                                    arrayOverflow = 1;
                                    break;
                                }
                            }
                            
                            if (cellLineageTempArrayCount+9 > cellLineageTempArrayLimit){
                                int *arrayUpDate = new int [cellLineageTempArrayCount+10];
                                
                                for (unsigned long counter3 = 0; counter3 < cellLineageTempArrayCount; counter3++) arrayUpDate [counter3] = cellLineageTempArray [counter3];
                                
                                delete [] cellLineageTempArray;
                                
                                if (newLimit == 0){
                                    cellLineageTempArray = new int [cellLineageTempArrayLimit+(unsigned long)activeCellStatusListCount*(unsigned long)simProcessDataProgHold [25]*10+10];
                                    cellLineageTempArrayLimit = cellLineageTempArrayLimit+(unsigned long)activeCellStatusListCount*(unsigned long)simProcessDataProgHold [25]*10+10;
                                }
                                else{
                                    
                                    cellLineageTempArray = new int [550000000000000000];
                                    cellLineageTempArrayLimit = 550000000000000000;
                                }
                                
                                for (unsigned long counter3 = 0; counter3 < cellLineageTempArrayCount; counter3++) cellLineageTempArray [counter3] = arrayUpDate [counter3];
                                delete [] arrayUpDate;
                            }
                            
                            if (markingFlag == 1 && lineageAddTemp [counter2*11+3] != 1 && lineageAddTemp [counter2*11+3] != 31 && lineageAddTemp [counter2*11+3] != 41)  cellLineageTempArray [cellLineageTempArrayCount] = 10, cellLineageTempArrayCount++;
                            else cellLineageTempArray [cellLineageTempArrayCount] = lineageAddTemp [counter2*11], cellLineageTempArrayCount++;
                            
                            cellLineageTempArray [cellLineageTempArrayCount] = lineageAddTemp [counter2*11+1], cellLineageTempArrayCount++;
                            cellLineageTempArray [cellLineageTempArrayCount] = lineageAddTemp [counter2*11+2], cellLineageTempArrayCount++;
                            cellLineageTempArray [cellLineageTempArrayCount] = lineageAddTemp [counter2*11+3], cellLineageTempArrayCount++;
                            cellLineageTempArray [cellLineageTempArrayCount] = lineageAddTemp [counter2*11+4], cellLineageTempArrayCount++;
                            cellLineageTempArray [cellLineageTempArrayCount] = lineageAddTemp [counter2*11+5], cellLineageTempArrayCount++;
                            cellLineageTempArray [cellLineageTempArrayCount] = lineageAddTemp [counter2*11+6], cellLineageTempArrayCount++;
                            cellLineageTempArray [cellLineageTempArrayCount] = lineageAddTemp [counter2*11+7], cellLineageTempArrayCount++;
                            cellLineageTempArray [cellLineageTempArrayCount] = lineageAddTemp [counter2*11+8], cellLineageTempArrayCount++;
                            cellLineageTempArray [cellLineageTempArrayCount] = lineageAddTemp [counter2*10+9], cellLineageTempArrayCount++;
                            cellLineageTempArray [cellLineageTempArrayCount] = lineageAddTemp [counter2*11+10], cellLineageTempArrayCount++;
                        }
                    }
                    
                    if (arrayOverflow == 1){
                        break;
                    }
                }
                
                delete [] lineageAddTemp;
                
                //----Change growthCycleBase when Div reaches 15, reachMaxDivision hold the min Time point, so it will be used to trim at the end----
                if (reachMaxDivision != 1000000000 && reachMaxDivision < growthCycleBase){
                    growthCycleBase = reachMaxDivision;
                }
                
                //for (int counterA = 0; counterA < activeCellStatusListKeepCount/12; counterA++){
                //    for (int counterB = 0; counterB < 12; counterB++) cout<<" "<<activeCellStatusListKeep [counterA*14+counterB];
                //    cout<<" activeCellStatusListKeep "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < tempListOfCellsCount/7; counterA++){
                //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<tempListOfCells [counterA*7+counterB];
                //    cout<<" tempListOfCells "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < fusionPartnerListCount/5; counterA++){
                //    cout<<fusionPartnerList [counterA*5]<<" "<<fusionPartnerList [counterA*5+1]<<" "<<fusionPartnerList [counterA*5+2]<<" "<<fusionPartnerList [counterA*5+3]<<" "<<fusionPartnerList [counterA*5+4]<<" fusion2"<<endl;
                //}
                
                //for (int counterA = 0; counterA < startPositionListCount/3; counterA++){
                //    cout<<startPositionList [counterA*3]<<" "<<startPositionList [counterA*3+1]<<" "<<startPositionList [counterA*3+2]/9<<" startPositionList"<<endl;
                //}
                
                if (terminate2 == 0){
                    for (unsigned long counter1 = 0; counter1 < fusionPartnerListCount/5; counter1++){
                        missingPartnerCheck = 0;
                        
                        for (int counter2 = 0; counter2 < startPositionListCount/3; counter2++){
                            if (fusionPartnerList [counter1*5] == startPositionList [counter2*3] && fusionPartnerList [counter1*5+1] == startPositionList [counter2*3+1]){
                                missingPartnerCheck = 1;
                                
                                for (unsigned long counter3 = (unsigned long)startPositionList [counter2*3+2]/9; counter3 < cellLineageTempArrayCount/11; counter3++){
                                    if (cellLineageTempArray [counter3*11+5] == startPositionList [counter2*3] && cellLineageTempArray [counter3*11+6] == startPositionList [counter2*3+1] && cellLineageTempArray [counter3*11+2] == fusionPartnerList [counter1*5+2]){
                                        cellLineageTempArray [counter3*11+4] = (int)fusionPartnerList [counter1*5+3];
                                        cellLineageTempArray [counter3*11+7] = (int)fusionPartnerList [counter1*5+1];
                                        cellLineageTempArray [counter3*11+3] = 92;
                                        break;
                                    }
                                    else if (cellLineageTempArray [counter3*11+5] != startPositionList [counter2*3] || cellLineageTempArray [counter3*11+6] != startPositionList [counter2*3+1]){
                                        break;
                                    }
                                }
                                
                                break;
                            }
                        }
                        
                        if (missingPartnerCheck == 0){
                            for (unsigned long counter3 = (unsigned long)(fusionPartnerList [counter1*5+4]/9); counter3 < cellLineageTempArrayCount/11; counter3++){
                                if (cellLineageTempArray [counter3*11+5] == fusionPartnerList [counter1*5+1] && cellLineageTempArray [counter3*11+6] == fusionPartnerList [counter1*5+3] && cellLineageTempArray [counter3*11+3] == 91){
                                    cellLineageTempArray [counter3*11+4] = 0;
                                    cellLineageTempArray [counter3*11+7] = 0;
                                    cellLineageTempArray [counter3*11+3] = 7;
                                    break;
                                }
                            }
                        }
                    }
                }
                
                delete [] fusionPartnerList;
                delete [] startPositionList;
                
                //for (int counterA = 0; counterA < cellLineageTempArrayCount/9; counterA++){
                //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<cellLineageTempArray [counterA*9+counterB];
                //    cout<<" cellLineageTempArray "<<counterA<<endl;
                //}
                
                if (terminate2 == 0){
                    entryCount2 = 0;
                    
                    cellNoForSummary = 0;
                    lingNoForSummary = 0;
                    fusionForSummary = 0;
                    cellLineageSummaryArrayCount = 0;
                    
                    for (unsigned long counter2 = 0; counter2 < cellLineageTempArrayCount/11; counter2++){
                        if (cellLineageTempArray [counter2*11+8] != -1){
                            cellLineageTempArray [entryCount2] = cellLineageTempArray [counter2*11], entryCount2++;
                            cellLineageTempArray [entryCount2] = cellLineageTempArray [counter2*11+1], entryCount2++;
                            cellLineageTempArray [entryCount2] = cellLineageTempArray [counter2*11+2], entryCount2++;
                            cellLineageTempArray [entryCount2] = cellLineageTempArray [counter2*11+3], entryCount2++;
                            cellLineageTempArray [entryCount2] = cellLineageTempArray [counter2*11+4], entryCount2++;
                            cellLineageTempArray [entryCount2] = cellLineageTempArray [counter2*11+5], entryCount2++;
                            cellLineageTempArray [entryCount2] = cellLineageTempArray [counter2*11+6], entryCount2++;
                            cellLineageTempArray [entryCount2] = cellLineageTempArray [counter2*11+7], entryCount2++;
                            cellLineageTempArray [entryCount2] = cellLineageTempArray [counter2*11+8], entryCount2++;
                            cellLineageTempArray [entryCount2] = cellLineageTempArray [counter2*11+9], entryCount2++;
                            cellLineageTempArray [entryCount2] = cellLineageTempArray [counter2*11+10], entryCount2++;
                            
                            if (cellLineageTempArray [entryCount2-8] == 92) fusionForSummary = 1;
                            
                            if (cellLineageTempArray [entryCount2-6] != cellNoForSummary || cellLineageTempArray [entryCount2-5] != lingNoForSummary || counter2 == cellLineageTempArrayCount/11-1){
                                if (cellLineageSummaryArrayCount+50 > cellLineageSummaryArrayLimit){
                                    long *arrayUpDate = new long [cellLineageSummaryArrayCount+10];
                                    
                                    for (unsigned long counter3 = 0; counter3 < cellLineageSummaryArrayCount; counter3++) arrayUpDate [counter3] = cellLineageSummaryArray [counter3];
                                    
                                    delete [] cellLineageSummaryArray;
                                    cellLineageSummaryArray = new long [cellLineageSummaryArrayLimit+100000000];
                                    cellLineageSummaryArrayLimit = cellLineageSummaryArrayLimit+100000000;
                                    
                                    for (unsigned long counter3 = 0; counter3 < cellLineageSummaryArrayCount; counter3++) cellLineageSummaryArray [counter3] = arrayUpDate [counter3];
                                    delete [] arrayUpDate;
                                }
                                
                                if (cellLineageSummaryArrayCount == 0){
                                    cellNoForSummary = cellLineageTempArray [entryCount2-6];
                                    lingNoForSummary = cellLineageTempArray [entryCount2-5];
                                    
                                    fusionForSummary = 0;
                                    
                                    cellLineageSummaryArray [cellLineageSummaryArrayCount] = 0, cellLineageSummaryArrayCount++;
                                    cellLineageSummaryArray [cellLineageSummaryArrayCount] = 0, cellLineageSummaryArrayCount++;
                                    cellLineageSummaryArray [cellLineageSummaryArrayCount] = (long)lingNoForSummary, cellLineageSummaryArrayCount++;
                                    cellLineageSummaryArray [cellLineageSummaryArrayCount] = (long)cellNoForSummary, cellLineageSummaryArrayCount++;
                                    cellLineageSummaryArray [cellLineageSummaryArrayCount] = (long)cellLineageTempArray [entryCount2-7], cellLineageSummaryArrayCount++;
                                    cellLineageSummaryArray [cellLineageSummaryArrayCount] = (long)lingNoForSummary, cellLineageSummaryArrayCount++;
                                    cellLineageSummaryArray [cellLineageSummaryArrayCount] = (long)cellLineageTempArray [entryCount2-8], cellLineageSummaryArrayCount++;
                                    cellLineageSummaryArray [cellLineageSummaryArrayCount] = 0, cellLineageSummaryArrayCount++;
                                    cellLineageSummaryArray [cellLineageSummaryArrayCount] = 0, cellLineageSummaryArrayCount++;
                                }
                                else if (cellLineageSummaryArrayCount != 0 && counter2 != cellLineageTempArrayCount/11-1){
                                    cellLineageSummaryArray [cellLineageSummaryArrayCount-8] = (long)entryCount2-18;
                                    
                                    if ((long)cellLineageTempArray [entryCount2-19] == 31 || (long)cellLineageTempArray [entryCount2-19] == 41){
                                        cellLineageSummaryArray [cellLineageSummaryArrayCount-2] = 2;
                                    }
                                    else cellLineageSummaryArray [cellLineageSummaryArrayCount-2] = (long)cellLineageTempArray [entryCount2-19];
                                    
                                    if (fusionForSummary == 1) cellLineageSummaryArray [cellLineageSummaryArrayCount-1] = 1;
                                    
                                    cellNoForSummary = cellLineageTempArray [entryCount2-6];
                                    lingNoForSummary = cellLineageTempArray [entryCount2-5];
                                    
                                    fusionForSummary = 0;
                                    
                                    cellLineageSummaryArray [cellLineageSummaryArrayCount] = (long)entryCount2-9, cellLineageSummaryArrayCount++;
                                    cellLineageSummaryArray [cellLineageSummaryArrayCount] = 0, cellLineageSummaryArrayCount++;
                                    cellLineageSummaryArray [cellLineageSummaryArrayCount] = (long)lingNoForSummary, cellLineageSummaryArrayCount++;
                                    cellLineageSummaryArray [cellLineageSummaryArrayCount] = (long)cellNoForSummary, cellLineageSummaryArrayCount++;
                                    cellLineageSummaryArray [cellLineageSummaryArrayCount] = (long)cellLineageTempArray [entryCount2-7], cellLineageSummaryArrayCount++;
                                    cellLineageSummaryArray [cellLineageSummaryArrayCount] = (long)lingNoForSummary, cellLineageSummaryArrayCount++;
                                    cellLineageSummaryArray [cellLineageSummaryArrayCount] = (long)cellLineageTempArray [entryCount2-8], cellLineageSummaryArrayCount++;
                                    cellLineageSummaryArray [cellLineageSummaryArrayCount] = 0, cellLineageSummaryArrayCount++;
                                    cellLineageSummaryArray [cellLineageSummaryArrayCount] = 0, cellLineageSummaryArrayCount++;
                                }
                                else if (cellLineageSummaryArrayCount != 0 && counter2 == cellLineageTempArrayCount/11-1){
                                    if (cellLineageTempArray [entryCount2-17] != cellLineageTempArray [entryCount2-6] || cellLineageTempArray [entryCount2-16] != cellLineageTempArray [entryCount2-5]){
                                        cellLineageSummaryArray [cellLineageSummaryArrayCount-8] = (long)entryCount2-18;
                                        cellLineageSummaryArray [cellLineageSummaryArrayCount-2] = 2;
                                        if (fusionForSummary == 1) cellLineageSummaryArray [cellLineageSummaryArrayCount-1] = 1;
                                        
                                        cellLineageSummaryArray [cellLineageSummaryArrayCount] = (long)entryCount2-9, cellLineageSummaryArrayCount++;
                                        cellLineageSummaryArray [cellLineageSummaryArrayCount] = (long)entryCount2-9, cellLineageSummaryArrayCount++;
                                        cellLineageSummaryArray [cellLineageSummaryArrayCount] = (long)cellLineageTempArray [entryCount2-5], cellLineageSummaryArrayCount++;
                                        cellLineageSummaryArray [cellLineageSummaryArrayCount] = (long)cellLineageTempArray [entryCount2-6], cellLineageSummaryArrayCount++;
                                        cellLineageSummaryArray [cellLineageSummaryArrayCount] = (long)cellLineageTempArray [entryCount2-7], cellLineageSummaryArrayCount++;
                                        cellLineageSummaryArray [cellLineageSummaryArrayCount] = (long)cellLineageTempArray [entryCount2-5], cellLineageSummaryArrayCount++;
                                        cellLineageSummaryArray [cellLineageSummaryArrayCount] = (long)cellLineageTempArray [entryCount2-8], cellLineageSummaryArrayCount++;
                                        cellLineageSummaryArray [cellLineageSummaryArrayCount] = 2, cellLineageSummaryArrayCount++;
                                        cellLineageSummaryArray [cellLineageSummaryArrayCount] = 0, cellLineageSummaryArrayCount++;
                                    }
                                    else{
                                        
                                        cellLineageSummaryArray [cellLineageSummaryArrayCount-8] = (long)entryCount2-9;
                                        cellLineageSummaryArray [cellLineageSummaryArrayCount-2] = 2;
                                        if (fusionForSummary == 1) cellLineageSummaryArray [cellLineageSummaryArrayCount-1] = 1;
                                    }
                                }
                            }
                        }
                    }
                    
                    cellLineageTempArrayCount = entryCount2;
                    
                    //1. Ling no
                    //2. Parent
                    //3. Cell 1
                    //4. Cell 2
                    //5. Cell 3
                    //6. Event
                    //7. Double
                    
                    //----Enter cell info from tempListOfCells----
                    for (unsigned long counter1 = 0; counter1 < tempListOfCellsCount/7; counter1++){
                        parentTDCount = 0;
                        parentTDTD = 0;
                        parentTDBD = 0;
                        
                        for (int counter2 = 0; counter2 < activeCellStatusListCount/14; counter2++){
                            if (activeCellStatusList [counter2*14] == tempListOfCells [counter1*7+1] && activeCellStatusList [counter2*14+3] == tempListOfCells [counter1*7]){
                                parentTDCount = activeCellStatusList [counter2*14+7];
                                parentTDTD = activeCellStatusList [counter2*14+8];
                                parentTDBD = activeCellStatusList [counter2*14+9];
                                break;
                            }
                        }
                        
                        if (activeCellStatusListCount+50 > activeCellStatusListLimitHold){
                            int *arrayUpDate = new int [activeCellStatusListCount+10];
                            
                            for (int counter2 = 0; counter2 < activeCellStatusListCount; counter2++) arrayUpDate [counter2] = activeCellStatusList [counter2];
                            
                            delete [] activeCellStatusList;
                            activeCellStatusList = new int [activeCellStatusListLimitHold+10000];
                            activeCellStatusListLimitHold = activeCellStatusListLimitHold+10000;
                            
                            for (int counter2 = 0; counter2 < activeCellStatusListCount; counter2++) activeCellStatusList [counter2] = arrayUpDate [counter2];
                            delete [] arrayUpDate;
                        }
                        
                        if (tempListOfCells [counter1*7+5] == 1 || tempListOfCells [counter1*7+5] == 7){
                            activeCellStatusList [activeCellStatusListCount] = tempListOfCells [counter1*7+2], activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = tempListOfCells [counter1*7+3], activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = 0, activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = tempListOfCells [counter1*7], activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = 0, activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = tempListOfCells [counter1*7+5], activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = 0, activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = parentTDCount, activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = parentTDTD, activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = parentTDBD, activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = tempListOfCells [counter1*7+1], activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = tempListOfCells [counter1*7+6], activeCellStatusListCount++;
                            
                            activeCellStatusList [activeCellStatusListCount] = 0, activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = 0, activeCellStatusListCount++;
                            
                            activeCellStatusList [activeCellStatusListCount] = tempListOfCells [counter1*7+3], activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = tempListOfCells [counter1*7+2], activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = 0, activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = tempListOfCells [counter1*7], activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = 0, activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = tempListOfCells [counter1*7+5], activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = 0, activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = parentTDCount, activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = parentTDTD, activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = parentTDBD, activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = tempListOfCells [counter1*7+1], activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = tempListOfCells [counter1*7+6], activeCellStatusListCount++;
                            
                            activeCellStatusList [activeCellStatusListCount] = 0, activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = 0, activeCellStatusListCount++;
                        }
                        
                        if (tempListOfCells [counter1*7+5]== 2){
                            activeCellStatusList [activeCellStatusListCount] = tempListOfCells [counter1*7+2], activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = tempListOfCells [counter1*7+3], activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = tempListOfCells [counter1*7+4], activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = tempListOfCells [counter1*7], activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = 0, activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = 2, activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = 0, activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = parentTDCount, activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = parentTDTD, activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = parentTDBD, activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = tempListOfCells [counter1*7+1], activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = tempListOfCells [counter1*7+6], activeCellStatusListCount++;
                            
                            activeCellStatusList [activeCellStatusListCount] = 0, activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = 0, activeCellStatusListCount++;
                            
                            activeCellStatusList [activeCellStatusListCount] = tempListOfCells [counter1*7+3], activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = tempListOfCells [counter1*7+2], activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = tempListOfCells [counter1*7+4], activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = tempListOfCells [counter1*7], activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = 0, activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = 2, activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = 0, activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = parentTDCount, activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = parentTDTD, activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = parentTDBD, activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = tempListOfCells [counter1*7+1], activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = tempListOfCells [counter1*7+6], activeCellStatusListCount++;
                            
                            activeCellStatusList [activeCellStatusListCount] = 0, activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = 0, activeCellStatusListCount++;
                            
                            activeCellStatusList [activeCellStatusListCount] = tempListOfCells [counter1*7+4], activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = tempListOfCells [counter1*7+2], activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = tempListOfCells [counter1*7+3], activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = tempListOfCells [counter1*7], activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = 0, activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = 2, activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = 0, activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = parentTDCount, activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = parentTDTD, activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = parentTDBD, activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = tempListOfCells [counter1*7+1], activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = tempListOfCells [counter1*7+6], activeCellStatusListCount++;
                            
                            activeCellStatusList [activeCellStatusListCount] = 0, activeCellStatusListCount++;
                            activeCellStatusList [activeCellStatusListCount] = 0, activeCellStatusListCount++;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < activeCellStatusListCount/12; counterA++){
                    //    for (int counterB = 0; counterB < 12; counterB++) cout<<" "<<activeCellStatusList [counterA*14+counterB];
                    //    cout<<" activeCellStatusList "<<counterA<<endl;
                    //}
                    
                    //----Remove already entered data from "activeCellStatusList"----
                    int *activeCellStatusListTemp = new int [activeCellStatusListCount+100];
                    activeCellStatusListTempCount = 0;
                    
                    for (int counter1 = 0; counter1 < activeCellStatusListCount/14; counter1++){
                        if (activeCellStatusList [counter1*14+1] != -1){
                            activeCellStatusListTemp [activeCellStatusListTempCount] = activeCellStatusList [counter1*14], activeCellStatusListTempCount++;
                            activeCellStatusListTemp [activeCellStatusListTempCount] = activeCellStatusList [counter1*14+1], activeCellStatusListTempCount++;
                            activeCellStatusListTemp [activeCellStatusListTempCount] = activeCellStatusList [counter1*14+2], activeCellStatusListTempCount++;
                            activeCellStatusListTemp [activeCellStatusListTempCount] = activeCellStatusList [counter1*14+3], activeCellStatusListTempCount++;
                            activeCellStatusListTemp [activeCellStatusListTempCount] = activeCellStatusList [counter1*14+4], activeCellStatusListTempCount++;
                            activeCellStatusListTemp [activeCellStatusListTempCount] = activeCellStatusList [counter1*14+5], activeCellStatusListTempCount++;
                            activeCellStatusListTemp [activeCellStatusListTempCount] = 0, activeCellStatusListTempCount++;
                            activeCellStatusListTemp [activeCellStatusListTempCount] = activeCellStatusList [counter1*14+7], activeCellStatusListTempCount++;
                            activeCellStatusListTemp [activeCellStatusListTempCount] = activeCellStatusList [counter1*14+8], activeCellStatusListTempCount++;
                            activeCellStatusListTemp [activeCellStatusListTempCount] = activeCellStatusList [counter1*14+9], activeCellStatusListTempCount++;
                            activeCellStatusListTemp [activeCellStatusListTempCount] = activeCellStatusList [counter1*14+10], activeCellStatusListTempCount++;
                            activeCellStatusListTemp [activeCellStatusListTempCount] = activeCellStatusList [counter1*14+11], activeCellStatusListTempCount++;
                            activeCellStatusListTemp [activeCellStatusListTempCount] = activeCellStatusList [counter1*14+12], activeCellStatusListTempCount++;
                            activeCellStatusListTemp [activeCellStatusListTempCount] = activeCellStatusList [counter1*14+13], activeCellStatusListTempCount++;
                        }
                    }
                    
                    activeCellStatusListCount = 0;
                    
                    for (int counter1 = 0; counter1 < activeCellStatusListTempCount; counter1++) activeCellStatusList [activeCellStatusListCount] = activeCellStatusListTemp [counter1], activeCellStatusListCount++;
                    
                    delete [] activeCellStatusListTemp;
                }
                
                delete [] tempListOfCells;
                
                delete [] activeCellStatusListHold;
                activeCellStatusListHold = new int [activeCellStatusListCount+10];
                activeCellStatusListHoldCount = 0;
                
                firstTimeAssignment = 1;
                
                for (int counter1 = 0; counter1 < activeCellStatusListCount; counter1++) activeCellStatusListHold [activeCellStatusListHoldCount] = activeCellStatusList [counter1], activeCellStatusListHoldCount++;
                
                //for (int counterA = 0; counterA < activeCellStatusListCount/12; counterA++){
                //    for (int counterB = 0; counterB < 12; counterB++) cout<<" "<<activeCellStatusList [counterA*14+counterB];
                //    cout<<" activeCellStatusList "<<counterA<<endl;
                //}
                
                if (arrayOverflow == 1){
                    break;
                }
                
                if (activeCellStatusListCount == 0){
                    terminationFlag = 0;
                }
            }
        }
        
        if (terminateSimFlag == 1) terminationFlag = 0;
        
        //cout<<terminationFlag<<" "<<activeCellStatusListTempCount<<" "<<cellLineageTempArrayCount<<" End3"<<endl;
        
    } while (terminationFlag == 1);
    //----Main loop for simulation execution----
    
    //for (int counterA = 0; counterA < cellLineageTempArrayCount/9; counterA++){
    //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<cellLineageTempArray [counterA*9+counterB];
    //    cout<<" cellLineageTempArray "<<counterA<<endl;
    //}
    
    //for (int counterA = 0; counterA < activeCellStatusListKeepCount; counterA++) activeCellStatusList [activeCellStatusListCount] = activeCellStatusListKeep [counterA], activeCellStatusListCount++;
    
    delete [] expandFirstDVList;
    delete [] expandDoubLingDoubBD;
    delete [] expandDoubLingDoubTD;
    delete [] expandDoubLingDoubCF;
    delete [] expandBDCD;
    delete [] expandBDCF;
    delete [] expandNonCD;
    delete [] expandBDCFCD;
    delete [] expandTDCF;
    delete [] expandTDCFCD;
    delete [] expandTDCD;
    delete [] firstEventList;
    delete [] secondEventBDList;
    delete [] secondEventBDCFList;
    delete [] secondEventTDList;
    delete [] secondEventTDCFList;
    delete [] activeCellStatusListHold;
}

-(void)expandDoubLingDoubBDSet{
    int timeMax = (int)simProcessDataProgHold [25];
    int duration = durationEnd-durationStart;
    
    int *simulationDistributionDataTemp = new int [timeMax+10];
    int totalCountSim = 0;
    
    if (timeProgCount <= duration){
        if (baseMidHold != 0){
            for (int counter1 = 0; counter1 < timeMax; counter1++){
                simulationDistributionDataTemp [counter1] = simulationDistributionMidData [counter1*11+7]+(int)(round(((simulationDistributionProgData [counter1*11+7]-simulationDistributionMidData [counter1*11+7])/(double)duration)*timeProgCount));
            }
        }
        else{
            
            for (int counter1 = 0; counter1 < timeMax; counter1++){
                simulationDistributionDataTemp [counter1] = simulationDistributionData [counter1*11+7]+(int)(round(((simulationDistributionProgData [counter1*11+7]-simulationDistributionData [counter1*11+7])/(double)duration)*timeProgCount));
            }
        }
        
        for (int counter1 = 0; counter1 < timeMax; counter1++){
            if (simulationDistributionDataTemp [counter1] != 0) totalCountSim = totalCountSim+simulationDistributionDataTemp [counter1];
        }
    }
    else{
        
        for (int counter1 = 0; counter1 < timeMax; counter1++){
            if (simulationDistributionProgData [counter1*11+7] != 0) totalCountSim = totalCountSim+simulationDistributionProgData [counter1*11+7];
        }
    }
    
    //----Apply the bias----
    totalCountSim = (int)(round(totalCountSim*(double)simProcessDataProgHold [0]));
    
    delete [] expandDoubLingDoubBD;
    expandDoubLingDoubBD = new int [totalCountSim*2+10];
    expandDoubLingDoubBDCount = 0;
    
    int countTemp = 0;
    int adjustTemp = 0;
    
    for (int counter1 = 0; counter1 < timeMax; counter1++){
        if (simulationDistributionDataTemp [counter1] != 0){ //----
            //if (simProcessDataProgHold [0] > 1){
            //    if (simulationDistributionDataTemp [counter1] > 1) countTemp = (int)(round(simulationDistributionDataTemp [counter1]+(simulationDistributionDataTemp [counter1]-1)*(double)simProcessDataProgHold [0]));
            //    else countTemp = simulationDistributionDataTemp [counter1];
            //}
            //else countTemp = (int)(round(simulationDistributionDataTemp [counter1]*(double)simProcessDataProgHold [0]));
            
            countTemp = (int)simulationDistributionDataTemp [counter1];
            
            if (simProcessDataProgHold [0] != 1 && simProcessDataProgHold [0] > 0){
                adjustTemp = (int)((counter1+1)*(double)simProcessDataProgHold [0]);
                
                if (adjustTemp == 0) adjustTemp = 1;
            }
            else adjustTemp = counter1+1;
            
            
            for (int counter2 = 0; counter2 < countTemp; counter2++){
                expandDoubLingDoubBD [expandDoubLingDoubBDCount] = adjustTemp, expandDoubLingDoubBDCount++;
                expandDoubLingDoubBD [expandDoubLingDoubBDCount] = 0, expandDoubLingDoubBDCount++;
            }
        }
    }
    
    delete [] simulationDistributionDataTemp;
}

-(void)expandDoubLingDoubTDSet{
    int timeMax = (int)simProcessDataProgHold [25];
    int duration = durationEnd-durationStart;
    
    int *simulationDistributionDataTemp = new int [timeMax+10];
    int totalCountSim = 0;
    
    if (timeProgCount <= duration){
        if (baseMidHold != 0){
            for (int counter1 = 0; counter1 < timeMax; counter1++){
                simulationDistributionDataTemp [counter1] = simulationDistributionMidData [counter1*11+8]+(int)(round(((simulationDistributionProgData [counter1*11+8]-simulationDistributionMidData [counter1*11+8])/(double)duration)*timeProgCount));
            }
        }
        else{
            
            for (int counter1 = 0; counter1 < timeMax; counter1++){
                simulationDistributionDataTemp [counter1] = simulationDistributionData [counter1*11+8]+(int)(round(((simulationDistributionProgData [counter1*11+8]-simulationDistributionData [counter1*11+8])/(double)duration)*timeProgCount));
            }
        }
        
        for (int counter1 = 0; counter1 < timeMax; counter1++){
            if (simulationDistributionDataTemp [counter1] != 0) totalCountSim = totalCountSim+simulationDistributionDataTemp [counter1];
        }
    }
    else{
        
        for (int counter1 = 0; counter1 < timeMax; counter1++){
            if (simulationDistributionProgData [counter1*11+7] != 0) totalCountSim = totalCountSim+simulationDistributionProgData [counter1*11+8];
        }
    }
    
    //----Apply the bias----
    totalCountSim = (int)(round(totalCountSim*(double)simProcessDataProgHold [1]));
    
    delete [] expandDoubLingDoubTD;
    expandDoubLingDoubTD = new int [totalCountSim*2+10];
    expandDoubLingDoubTDCount = 0;
    
    int countTemp = 0;
    int adjustTemp = 0;
    
    for (int counter1 = 0; counter1 < timeMax; counter1++){
        if (simulationDistributionDataTemp [counter1] != 0){ //----
            //if (simProcessDataProgHold [1] > 1){
            //    if (simulationDistributionDataTemp [counter1] > 1) countTemp = (int)(round(simulationDistributionDataTemp [counter1]+(simulationDistributionDataTemp [counter1]-1)*(double)simProcessDataProgHold [1]));
            //    else countTemp = simulationDistributionDataTemp [counter1];
            // }
            //else countTemp = (int)(round(simulationDistributionDataTemp [counter1]*(double)simProcessDataProgHold [1]));
            
            countTemp = (int)simulationDistributionDataTemp [counter1];
            
            if (simProcessDataProgHold [1] != 1 && simProcessDataProgHold [1] > 0){
                adjustTemp = (int)((counter1+1)*(double)simProcessDataProgHold [1]);
                
                if (adjustTemp == 0) adjustTemp = 1;
            }
            else adjustTemp = counter1+1;
            
            
            for (int counter2 = 0; counter2 < countTemp; counter2++){
                expandDoubLingDoubTD [expandDoubLingDoubTDCount] = adjustTemp, expandDoubLingDoubTDCount++;
                expandDoubLingDoubTD [expandDoubLingDoubTDCount] = 0, expandDoubLingDoubTDCount++;
            }
        }
    }
    
    delete [] simulationDistributionDataTemp;
}

-(void)expandDoubLingDoubCFSet{
    int timeMax = (int)simProcessDataProgHold [25];
    int duration = durationEnd-durationStart;
    
    int *simulationDistributionDataTemp = new int [timeMax+10];
    int totalCountSim = 0;
    
    if (timeProgCount <= duration){
        if (baseMidHold != 0){
            for (int counter1 = 0; counter1 < timeMax; counter1++){
                simulationDistributionDataTemp [counter1] = simulationDistributionMidData [counter1*11+9]+(int)(round(((simulationDistributionProgData [counter1*11+9]-simulationDistributionMidData [counter1*11+9])/(double)duration)*timeProgCount));
            }
        }
        else{
            
            for (int counter1 = 0; counter1 < timeMax; counter1++){
                simulationDistributionDataTemp [counter1] = simulationDistributionData [counter1*11+9]+(int)(round(((simulationDistributionProgData [counter1*11+9]-simulationDistributionData [counter1*11+9])/(double)duration)*timeProgCount));
            }
        }
        
        for (int counter1 = 0; counter1 < timeMax; counter1++){
            if (simulationDistributionDataTemp [counter1] != 0) totalCountSim = totalCountSim+simulationDistributionDataTemp [counter1];
        }
    }
    else{
        
        for (int counter1 = 0; counter1 < timeMax; counter1++){
            if (simulationDistributionProgData [counter1*11+7] != 0) totalCountSim = totalCountSim+simulationDistributionProgData [counter1*11+9];
        }
    }
    
    //----Apply the bias----
    totalCountSim = (int)(round(totalCountSim*(double)simProcessDataProgHold [2]));
    
    delete [] expandDoubLingDoubCF;
    expandDoubLingDoubCF = new int [totalCountSim*2+10];
    expandDoubLingDoubCFCount = 0;
    
    int countTemp = 0;
    int adjustTemp = 0;
    
    for (int counter1 = 0; counter1 < timeMax; counter1++){
        if (simulationDistributionDataTemp [counter1] != 0){ //----
            //if (simProcessDataProgHold [2] > 1){
            //    if (simulationDistributionDataTemp [counter1] > 1) countTemp = (int)(round(simulationDistributionDataTemp [counter1]+(simulationDistributionDataTemp [counter1]-1)*(double)simProcessDataProgHold [2]));
            //    else countTemp = simulationDistributionDataTemp [counter1];
            //}
            //else countTemp = (int)(round(simulationDistributionDataTemp [counter1]*(double)simProcessDataProgHold [2]));
            
            countTemp = (int)simulationDistributionDataTemp [counter1];
            
            if (simProcessDataProgHold [2] != 1 && simProcessDataProgHold [2] > 0){
                adjustTemp = (int)((counter1+1)*(double)simProcessDataProgHold [2]);
                
                if (adjustTemp == 0) adjustTemp = 1;
            }
            else adjustTemp = counter1+1;
            
            
            for (int counter2 = 0; counter2 < countTemp; counter2++){
                expandDoubLingDoubCF [expandDoubLingDoubTDCount] = adjustTemp, expandDoubLingDoubCFCount++;
                expandDoubLingDoubCF [expandDoubLingDoubTDCount] = 0, expandDoubLingDoubCFCount++;
            }
        }
    }
    
    delete [] simulationDistributionDataTemp;
}

-(void)expandBDCDSet{
    int timeMax = (int)simProcessDataProgHold [25];
    int duration = durationEnd-durationStart;
    
    int *simulationDistributionDataTemp = new int [timeMax+10];
    int totalCountSim = 0;
    
    if (timeProgCount <= duration){
        if (baseMidHold != 0){
            for (int counter1 = 0; counter1 < timeMax; counter1++){
                simulationDistributionDataTemp [counter1] = simulationDistributionMidData [counter1*11]+(int)(round(((simulationDistributionProgData [counter1*11]-simulationDistributionMidData [counter1*11])/(double)duration)*timeProgCount));
            }
        }
        else{
            
            for (int counter1 = 0; counter1 < timeMax; counter1++){
                simulationDistributionDataTemp [counter1] = simulationDistributionData [counter1*11]+(int)(round(((simulationDistributionProgData [counter1*11]-simulationDistributionData [counter1*11])/(double)duration)*timeProgCount));
            }
        }
        
        for (int counter1 = 0; counter1 < timeMax; counter1++){
            if (simulationDistributionDataTemp [counter1] != 0) totalCountSim = totalCountSim+simulationDistributionDataTemp [counter1];
        }
    }
    else{
        
        for (int counter1 = 0; counter1 < timeMax; counter1++){
            if (simulationDistributionProgData [counter1*11+7] != 0) totalCountSim = totalCountSim+simulationDistributionProgData [counter1*11];
        }
    }
    
    //----Apply the bias----
    totalCountSim = (int)(round(totalCountSim*(double)simProcessDataProgHold [5]));
    
    delete [] expandBDCD;
    expandBDCD = new int [totalCountSim*2+10];
    expandBDCDCount = 0;
    
    int countTemp = 0;
    int adjustTemp = 0;
    
    for (int counter1 = 0; counter1 < timeMax; counter1++){
        if (simulationDistributionDataTemp [counter1] != 0){ //----
            //if (simProcessDataProgHold [5] > 1){
            //    if (simulationDistributionDataTemp [counter1] > 1) countTemp = (int)(round(simulationDistributionDataTemp [counter1]+(simulationDistributionDataTemp [counter1]-1)*(double)simProcessDataProgHold [5]));
            //    else countTemp = simulationDistributionDataTemp [counter1];
            //}
            //else countTemp = (int)(round(simulationDistributionDataTemp [counter1]*(double)simProcessDataProgHold [5]));
            
            countTemp = (int)simulationDistributionDataTemp [counter1];
            
            if (simProcessDataProgHold [5] != 1 && simProcessDataProgHold [5] > 0){
                adjustTemp = (int)((counter1+1)*(double)simProcessDataProgHold [5]);
                
                if (adjustTemp == 0) adjustTemp = 1;
            }
            else adjustTemp = counter1+1;
            
            
            
            for (int counter2 = 0; counter2 < countTemp; counter2++){
                expandBDCD [expandBDCDCount] = adjustTemp, expandBDCDCount++;
                expandBDCD [expandBDCDCount] = 0, expandBDCDCount++;
            }
        }
    }
    
    delete [] simulationDistributionDataTemp;
}

-(void)expandBDCFSet{
    int timeMax = (int)simProcessDataProgHold [25];
    int duration = durationEnd-durationStart;
    
    int *simulationDistributionDataTemp = new int [timeMax+10];
    int totalCountSim = 0;
    
    if (timeProgCount <= duration){
        if (baseMidHold != 0){
            for (int counter1 = 0; counter1 < timeMax; counter1++){
                simulationDistributionDataTemp [counter1] = simulationDistributionMidData [counter1*11+2]+(int)(round(((simulationDistributionProgData [counter1*11+2]-simulationDistributionMidData [counter1*11+2])/(double)duration)*timeProgCount));
            }
        }
        else{
            
            for (int counter1 = 0; counter1 < timeMax; counter1++){
                simulationDistributionDataTemp [counter1] = simulationDistributionData [counter1*11+2]+(int)(round(((simulationDistributionProgData [counter1*11+2]-simulationDistributionData [counter1*11+2])/(double)duration)*timeProgCount));
            }
        }
        
        for (int counter1 = 0; counter1 < timeMax; counter1++){
            if (simulationDistributionDataTemp [counter1] != 0) totalCountSim = totalCountSim+simulationDistributionDataTemp [counter1];
        }
    }
    else{
        
        for (int counter1 = 0; counter1 < timeMax; counter1++){
            if (simulationDistributionProgData [counter1*11+7] != 0) totalCountSim = totalCountSim+simulationDistributionProgData [counter1*11+2];
        }
    }
    
    //----Apply the bias----
    totalCountSim = (int)(round(totalCountSim*(double)simProcessDataProgHold [7]));
    
    delete [] expandBDCF;
    expandBDCF = new int [totalCountSim*2+10];
    expandBDCFCount = 0;
    
    int countTemp = 0;
    int adjustTemp = 0;
    
    for (int counter1 = 0; counter1 < timeMax; counter1++){
        if (simulationDistributionDataTemp [counter1] != 0){ //----
            //if (simProcessDataProgHold [7] > 1){
            //    if (simulationDistributionDataTemp [counter1] > 1) countTemp = (int)(round(simulationDistributionDataTemp [counter1]+(simulationDistributionDataTemp [counter1]-1)*(double)simProcessDataProgHold [7]));
            //    else countTemp = simulationDistributionDataTemp [counter1];
            // }
            //else countTemp = (int)(round(simulationDistributionDataTemp [counter1]*(double)simProcessDataProgHold [7]));
            
            countTemp = (int)simulationDistributionDataTemp [counter1];
            
            if (simProcessDataProgHold [7] != 1 && simProcessDataProgHold [7] > 0){
                adjustTemp = (int)((counter1+1)*(double)simProcessDataProgHold [7]);
                
                if (adjustTemp == 0) adjustTemp = 1;
            }
            else adjustTemp = counter1+1;
            
            
            for (int counter2 = 0; counter2 < countTemp; counter2++){
                expandBDCF [expandBDCFCount] = adjustTemp, expandBDCFCount++;
                expandBDCF [expandBDCFCount] = 0, expandBDCFCount++;
            }
        }
    }
    
    delete [] simulationDistributionDataTemp;
}

-(void)expandNonCDSet{
    int timeMax = (int)simProcessDataProgHold [25];
    int duration = durationEnd-durationStart;
    
    int *simulationDistributionDataTemp = new int [timeMax+10];
    int totalCountSim = 0;
    
    if (timeProgCount <= duration){
        if (baseMidHold != 0){
            for (int counter1 = 0; counter1 < timeMax; counter1++){
                simulationDistributionDataTemp [counter1] = simulationDistributionMidData [counter1*11+1]+(int)(round(((simulationDistributionProgData [counter1*11+1]-simulationDistributionMidData [counter1*11+1])/(double)duration)*timeProgCount));
            }
        }
        else{
            
            for (int counter1 = 0; counter1 < timeMax; counter1++){
                simulationDistributionDataTemp [counter1] = simulationDistributionData [counter1*11+1]+(int)(round(((simulationDistributionProgData [counter1*11+1]-simulationDistributionData [counter1*11+1])/(double)duration)*timeProgCount));
            }
        }
        
        for (int counter1 = 0; counter1 < timeMax; counter1++){
            if (simulationDistributionDataTemp [counter1] != 0) totalCountSim = totalCountSim+simulationDistributionDataTemp [counter1];
        }
    }
    else{
        
        for (int counter1 = 0; counter1 < timeMax; counter1++){
            if (simulationDistributionProgData [counter1*11+7] != 0) totalCountSim = totalCountSim+simulationDistributionProgData [counter1*11+1];
        }
    }
    
    //----Apply the bias----
    totalCountSim = (int)(round(totalCountSim*(double)simProcessDataProgHold [6]));
    
    delete [] expandNonCD;
    expandNonCD = new int [totalCountSim*2+10];
    expandNonCDCount = 0;
    
    int countTemp = 0;
    int adjustTemp = 0;
    
    for (int counter1 = 0; counter1 < timeMax; counter1++){
        if (simulationDistributionDataTemp [counter1] != 0){ //----
            //if (simProcessDataProgHold [6] > 1){
            //    if (simulationDistributionDataTemp [counter1] > 1) countTemp = (int)(round(simulationDistributionDataTemp [counter1]+(simulationDistributionDataTemp [counter1]-1)*(double)simProcessDataProgHold [6]));
            //    else countTemp = simulationDistributionDataTemp [counter1];
            //}
            //else countTemp = (int)(round(simulationDistributionDataTemp [counter1]*(double)simProcessDataProgHold [6]));
            
            countTemp = (int)simulationDistributionDataTemp [counter1];
            
            if (simProcessDataProgHold [6] != 1 && simProcessDataProgHold [6] > 0){
                adjustTemp = (int)((counter1+1)*(double)simProcessDataProgHold [6]);
                
                if (adjustTemp == 0) adjustTemp = 1;
            }
            else adjustTemp = counter1+1;
            
            
            for (int counter2 = 0; counter2 < countTemp; counter2++){
                expandNonCD [expandNonCDCount] = adjustTemp, expandNonCDCount++;
                expandNonCD [expandNonCDCount] = 0, expandNonCDCount++;
            }
        }
    }
    
    delete [] simulationDistributionDataTemp;
}

-(void)expandBDCFCDSet{
    int timeMax = (int)simProcessDataProgHold [25];
    int duration = durationEnd-durationStart;
    
    int *simulationDistributionDataTemp = new int [timeMax+10];
    int totalCountSim = 0;
    
    if (timeProgCount <= duration){
        if (baseMidHold != 0){
            for (int counter1 = 0; counter1 < timeMax; counter1++){
                simulationDistributionDataTemp [counter1] = simulationDistributionMidData [counter1*11+3]+(int)(round(((simulationDistributionProgData [counter1*11+3]-simulationDistributionMidData [counter1*11+3])/(double)duration)*timeProgCount));
            }
        }
        else{
            
            for (int counter1 = 0; counter1 < timeMax; counter1++){
                simulationDistributionDataTemp [counter1] = simulationDistributionData [counter1*11+3]+(int)(round(((simulationDistributionProgData [counter1*11+3]-simulationDistributionData [counter1*11+3])/(double)duration)*timeProgCount));
            }
        }
        
        for (int counter1 = 0; counter1 < timeMax; counter1++){
            if (simulationDistributionDataTemp [counter1] != 0) totalCountSim = totalCountSim+simulationDistributionDataTemp [counter1];
        }
    }
    else{
        
        for (int counter1 = 0; counter1 < timeMax; counter1++){
            if (simulationDistributionProgData [counter1*11+7] != 0) totalCountSim = totalCountSim+simulationDistributionProgData [counter1*11+3];
        }
    }
    
    //----Apply the bias----
    totalCountSim = (int)(round(totalCountSim*(double)simProcessDataProgHold [10]));
    
    delete [] expandBDCFCD;
    expandBDCFCD = new int [totalCountSim*2+10];
    expandBDCFCDCount = 0;
    
    int countTemp = 0;
    int adjustTemp = 0;
    
    for (int counter1 = 0; counter1 < timeMax; counter1++){
        if (simulationDistributionDataTemp [counter1] != 0){ //----
            //if (simProcessDataProgHold [10] > 1){
            //    if (simulationDistributionDataTemp [counter1] > 1) countTemp = (int)(round(simulationDistributionDataTemp [counter1]+(simulationDistributionDataTemp [counter1]-1)*(double)simProcessDataProgHold [10]));
            //    else countTemp = simulationDistributionDataTemp [counter1];
            //}
            //else countTemp = (int)(round(simulationDistributionDataTemp [counter1]*(double)simProcessDataProgHold [10]));
            
            countTemp = (int)simulationDistributionDataTemp [counter1];
            
            if (simProcessDataProgHold [10] != 1 && simProcessDataProgHold [10] > 0){
                adjustTemp = (int)((counter1+1)*(double)simProcessDataProgHold [10]);
                
                if (adjustTemp == 0) adjustTemp = 1;
            }
            else adjustTemp = counter1+1;
            
            
            for (int counter2 = 0; counter2 < countTemp; counter2++){
                expandBDCFCD [expandBDCFCDCount] = adjustTemp, expandBDCFCDCount++;
                expandBDCFCD [expandBDCFCDCount] = 0, expandBDCFCDCount++;
            }
        }
    }
    
    delete [] simulationDistributionDataTemp;
}

-(void)expandTDCFSet{
    int timeMax = (int)simProcessDataProgHold [25];
    int duration = durationEnd-durationStart;
    
    int *simulationDistributionDataTemp = new int [timeMax+10];
    int totalCountSim = 0;
    
    if (timeProgCount <= duration){
        if (baseMidHold != 0){
            for (int counter1 = 0; counter1 < timeMax; counter1++){
                simulationDistributionDataTemp [counter1] = simulationDistributionMidData [counter1*11+4]+(int)(round(((simulationDistributionProgData [counter1*11+4]-simulationDistributionMidData [counter1*11+4])/(double)duration)*timeProgCount));
            }
        }
        else{
            
            for (int counter1 = 0; counter1 < timeMax; counter1++){
                simulationDistributionDataTemp [counter1] = simulationDistributionData [counter1*11+4]+(int)(round(((simulationDistributionProgData [counter1*11+4]-simulationDistributionData [counter1*11+4])/(double)duration)*timeProgCount));
            }
        }
        
        for (int counter1 = 0; counter1 < timeMax; counter1++){
            if (simulationDistributionDataTemp [counter1] != 0) totalCountSim = totalCountSim+simulationDistributionDataTemp [counter1];
        }
    }
    else{
        
        for (int counter1 = 0; counter1 < timeMax; counter1++){
            if (simulationDistributionProgData [counter1*11+7] != 0) totalCountSim = totalCountSim+simulationDistributionProgData [counter1*11+4];
        }
    }
    
    //----Apply the bias----
    totalCountSim = (int)(round(totalCountSim*(double)simProcessDataProgHold [11]));
    
    delete [] expandTDCF;
    expandTDCF = new int [totalCountSim*2+10];
    expandTDCFCount = 0;
    
    int countTemp = 0;
    int adjustTemp = 0;
    
    for (int counter1 = 0; counter1 < timeMax; counter1++){
        if (simulationDistributionDataTemp [counter1] != 0){ //----
            //if (simProcessDataProgHold [11] > 1){
            //    if (simulationDistributionDataTemp [counter1] > 1) countTemp = (int)(round(simulationDistributionDataTemp [counter1]+(simulationDistributionDataTemp [counter1]-1)*(double)simProcessDataProgHold [11]));
            //    else countTemp = simulationDistributionDataTemp [counter1];
            //}
            //else countTemp = (int)(round(simulationDistributionDataTemp [counter1]*(double)simProcessDataProgHold [11]));
            
            countTemp = (int)simulationDistributionDataTemp [counter1];
            
            if (simProcessDataProgHold [11] != 1 && simProcessDataProgHold [11] > 0){
                adjustTemp = (int)((counter1+1)*(double)simProcessDataProgHold [11]);
                
                if (adjustTemp == 0) adjustTemp = 1;
            }
            else adjustTemp = counter1+1;
            
            
            for (int counter2 = 0; counter2 < countTemp; counter2++){
                expandTDCF [expandTDCFCount] = adjustTemp, expandTDCFCount++;
                expandTDCF [expandTDCFCount] = 0, expandTDCFCount++;
            }
        }
    }
    
    delete [] simulationDistributionDataTemp;
}

-(void)expandTDCFCDSet{
    int timeMax = (int)simProcessDataProgHold [25];
    int duration = durationEnd-durationStart;
    
    int *simulationDistributionDataTemp = new int [timeMax+10];
    int totalCountSim = 0;
    
    if (timeProgCount <= duration){
        if (baseMidHold != 0){
            for (int counter1 = 0; counter1 < timeMax; counter1++){
                simulationDistributionDataTemp [counter1] = simulationDistributionMidData [counter1*11+5]+(int)(round(((simulationDistributionProgData [counter1*11+5]-simulationDistributionMidData [counter1*11+5])/(double)duration)*timeProgCount));
            }
        }
        else{
            
            for (int counter1 = 0; counter1 < timeMax; counter1++){
                simulationDistributionDataTemp [counter1] = simulationDistributionData [counter1*11+5]+(int)(round(((simulationDistributionProgData [counter1*11+5]-simulationDistributionData [counter1*11+5])/(double)duration)*timeProgCount));
            }
        }
        
        for (int counter1 = 0; counter1 < timeMax; counter1++){
            if (simulationDistributionDataTemp [counter1] != 0) totalCountSim = totalCountSim+simulationDistributionDataTemp [counter1];
        }
    }
    else{
        
        for (int counter1 = 0; counter1 < timeMax; counter1++){
            if (simulationDistributionProgData [counter1*11+7] != 0) totalCountSim = totalCountSim+simulationDistributionProgData [counter1*11+5];
        }
    }
    
    //----Apply the bias----
    totalCountSim = (int)(round(totalCountSim*(double)simProcessDataProgHold [14]));
    
    delete [] expandTDCFCD;
    expandTDCFCD = new int [totalCountSim*2+10];
    expandTDCFCDCount = 0;
    
    int countTemp = 0;
    int adjustTemp = 0;
    
    for (int counter1 = 0; counter1 < timeMax; counter1++){
        if (simulationDistributionDataTemp [counter1] != 0){ //----
            //if (simProcessDataProgHold [14] > 1){
            //    if (simulationDistributionDataTemp [counter1] > 1) countTemp = (int)(round(simulationDistributionDataTemp [counter1]+(simulationDistributionDataTemp [counter1]-1)*(double)simProcessDataProgHold [14]));
            //    else countTemp = simulationDistributionDataTemp [counter1];
            //}
            //else countTemp = (int)(round(simulationDistributionDataTemp [counter1]*(double)simProcessDataProgHold [14]));
            
            countTemp = (int)simulationDistributionDataTemp [counter1];
            
            if (simProcessDataProgHold [14] != 1 && simProcessDataProgHold [14] > 0){
                adjustTemp = (int)((counter1+1)*(double)simProcessDataProgHold [14]);
                
                if (adjustTemp == 0) adjustTemp = 1;
            }
            else adjustTemp = counter1+1;
            
            
            for (int counter2 = 0; counter2 < countTemp; counter2++){
                expandTDCFCD [expandTDCFCDCount] = adjustTemp, expandTDCFCDCount++;
                expandTDCFCD [expandTDCFCDCount] = 0, expandTDCFCDCount++;
            }
        }
    }
    
    delete [] simulationDistributionDataTemp;
}

-(void)expandTDCDSet{
    int timeMax = (int)simProcessDataProgHold [25];
    int duration = durationEnd-durationStart;
    
    int *simulationDistributionDataTemp = new int [timeMax+10];
    int totalCountSim = 0;
    
    if (timeProgCount <= duration){
        if (baseMidHold != 0){
            for (int counter1 = 0; counter1 < timeMax; counter1++){
                simulationDistributionDataTemp [counter1] = simulationDistributionMidData [counter1*11+6]+(int)(round(((simulationDistributionProgData [counter1*11+6]-simulationDistributionMidData [counter1*11+6])/(double)duration)*timeProgCount));
            }
        }
        else{
            
            for (int counter1 = 0; counter1 < timeMax; counter1++){
                simulationDistributionDataTemp [counter1] = simulationDistributionData [counter1*11+6]+(int)(round(((simulationDistributionProgData [counter1*11+6]-simulationDistributionData [counter1*11+6])/(double)duration)*timeProgCount));
            }
        }
        
        for (int counter1 = 0; counter1 < timeMax; counter1++){
            if (simulationDistributionDataTemp [counter1] != 0) totalCountSim = totalCountSim+simulationDistributionDataTemp [counter1];
        }
    }
    else{
        
        for (int counter1 = 0; counter1 < timeMax; counter1++){
            if (simulationDistributionProgData [counter1*11+7] != 0) totalCountSim = totalCountSim+simulationDistributionProgData [counter1*11+6];
        }
    }
    
    //----Apply the bias----
    totalCountSim = (int)(round(totalCountSim*(double)simProcessDataProgHold [17]));
    
    delete [] expandTDCD;
    expandTDCD = new int [totalCountSim*2+10];
    expandTDCDCount = 0;
    
    int countTemp = 0;
    int adjustTemp = 0;
    
    for (int counter1 = 0; counter1 < timeMax; counter1++){
        if (simulationDistributionDataTemp [counter1] != 0){ //----
            //if (simProcessDataProgHold [17] > 1){
            //    if (simulationDistributionDataTemp [counter1] > 1) countTemp = (int)(round(simulationDistributionDataTemp [counter1]+(simulationDistributionDataTemp [counter1]-1)*(double)simProcessDataProgHold [17]));
            //    else countTemp = simulationDistributionDataTemp [counter1];
            //}
            //else countTemp = (int)(round(simulationDistributionDataTemp [counter1]*(double)simProcessDataProgHold [17]));
            
            countTemp = (int)simulationDistributionDataTemp [counter1];
            
            if (simProcessDataProgHold [17] != 1 && simProcessDataProgHold [17] > 0){
                adjustTemp = (int)((counter1+1)*(double)simProcessDataProgHold [17]);
                
                if (adjustTemp == 0) adjustTemp = 1;
            }
            else adjustTemp = counter1+1;
            
            
            for (int counter2 = 0; counter2 < countTemp; counter2++){
                expandTDCD [expandTDCDCount] = adjustTemp, expandTDCDCount++;
                expandTDCD [expandTDCDCount] = 0, expandTDCDCount++;
            }
        }
    }
    
    delete [] simulationDistributionDataTemp;
}

-(void)expandFirstDVListSet{
    int timeMax = (int)simProcessDataProgHold [25];
    int duration = durationEnd-durationStart;
    
    int *simulationDistributionDataTemp = new int [timeMax+10];
    
    int totalCountSim = 0;
    
    if (timeProgCount <= duration){
        if (baseMidHold != 0){
            for (int counter1 = 0; counter1 < timeMax; counter1++){
                simulationDistributionDataTemp [counter1] = simulationDistributionMidData [counter1*11+10]+(int)(round(((simulationDistributionProgData [counter1*11+10]-simulationDistributionMidData [counter1*11+10])/(double)duration)*timeProgCount));
            }
        }
        else{
            
            for (int counter1 = 0; counter1 < timeMax; counter1++){
                simulationDistributionDataTemp [counter1] = simulationDistributionData [counter1*11+10]+(int)(round(((simulationDistributionProgData [counter1*11+10]-simulationDistributionData [counter1*11+10])/(double)duration)*timeProgCount));
            }
        }
        
        for (int counter1 = 0; counter1 < timeMax; counter1++){
            if (simulationDistributionDataTemp [counter1] != 0) totalCountSim = totalCountSim+simulationDistributionDataTemp [counter1];
        }
    }
    else{
        
        for (int counter1 = 0; counter1 < timeMax; counter1++){
            if (simulationDistributionProgData [counter1*11+10] != 0) totalCountSim = totalCountSim+simulationDistributionProgData [counter1*11+10];
        }
    }
    
    //----Apply the bias----
    delete [] expandFirstDVList;
    expandFirstDVList = new int [totalCountSim*2+10];
    expandFirstDVListCount = 0;
    
    for (int counter1 = 0; counter1 < timeMax; counter1++){
        if (simulationDistributionDataTemp [counter1] != 0){ //----
            for (int counter2 = 0; counter2 < simulationDistributionDataTemp [counter1]; counter2++){
                expandFirstDVList [expandFirstDVListCount] = counter1+1, expandFirstDVListCount++;
                expandFirstDVList [expandFirstDVListCount] = 0, expandFirstDVListCount++;
            }
        }
    }
    
    delete [] simulationDistributionDataTemp;
}

-(void)firstEventListSet{
    int timeMax = (int)simProcessDataProgHold [25];
    int duration = durationEnd-durationStart;
    
    //----Expand percentage data to total 100%----
    delete [] firstEventList;
    firstEventList = new int [150];
    
    for (int counter1 = 0; counter1 < 150; counter1++){
        firstEventList [counter1] = 0;
    }
    
    int totalCountSimBaseCD = 0;
    int totalCountSimTagCD = 0;
    int totalNoOfNonDivCD = 0;
    int nonDivAdjust = 0;
    int numberOfLing = 0;
    int numberOfBDAd = 0;
    int numberOfTDAd = 0;
    
    if (timeProgCount <= duration){
        if (baseMidHold != 0){
            for (int counter1 = 0; counter1 < timeMax; counter1++){
                if (simulationDistributionMidData [counter1*11+1] != 0) totalCountSimBaseCD = totalCountSimBaseCD+simulationDistributionMidData [counter1*11+1];
                if (simulationDistributionProgData [counter1*11+1] != 0) totalCountSimTagCD = totalCountSimTagCD+simulationDistributionProgData [counter1*11+1];
            }
            
            nonDivAdjust = (int)(round(simProcessDataMiddleHold [20]+((simProcessDataProgHold [20]-simProcessDataMiddleHold [20])/(double)duration)*timeProgCount));
            numberOfLing = (int)(round(simProcessDataMiddleHold [24]+((simProcessDataProgHold [24]-simProcessDataMiddleHold [24])/(double)duration)*timeProgCount));
            numberOfBDAd = (int)(round(simProcessDataMiddleHold [3]+((simProcessDataProgHold [3]-simProcessDataMiddleHold [3])/(double)duration)*timeProgCount));
            numberOfTDAd = (int)(round(simProcessDataMiddleHold [4]+((simProcessDataProgHold [4]-simProcessDataMiddleHold [4])/(double)duration)*timeProgCount));
        }
        else{
            
            for (int counter1 = 0; counter1 < timeMax; counter1++){
                if (simulationDistributionData [counter1*11+1] != 0) totalCountSimBaseCD = totalCountSimBaseCD+simulationDistributionData [counter1*11+1];
                if (simulationDistributionProgData [counter1*11+1] != 0) totalCountSimTagCD = totalCountSimTagCD+simulationDistributionProgData [counter1*11+1];
            }
            
            nonDivAdjust = (int)(round(simProcessDataBaseHold [20]+((simProcessDataProgHold [20]-simProcessDataBaseHold [20])/(double)duration)*timeProgCount));
            numberOfLing = (int)(round(simProcessDataBaseHold [24]+((simProcessDataProgHold [24]-simProcessDataBaseHold [24])/(double)duration)*timeProgCount));
            numberOfBDAd = (int)(round(simProcessDataBaseHold [3]+((simProcessDataProgHold [3]-simProcessDataBaseHold [3])/(double)duration)*timeProgCount));
            numberOfTDAd = (int)(round(simProcessDataBaseHold [4]+((simProcessDataProgHold [4]-simProcessDataBaseHold [4])/(double)duration)*timeProgCount));
        }
        
        totalNoOfNonDivCD = totalCountSimBaseCD+(int)(round(((totalCountSimTagCD-totalCountSimBaseCD)/(double)duration)*timeProgCount));
    }
    else{
        
        for (int counter1 = 0; counter1 < timeMax; counter1++){
            if (simulationDistributionProgData [counter1*11+1] != 0) totalNoOfNonDivCD = totalNoOfNonDivCD+simulationDistributionProgData [counter1*11+1];
        }
        
        nonDivAdjust = (int)simProcessDataProgHold [20];
        numberOfLing = (int)simProcessDataProgHold [24];
        numberOfBDAd = (int)simProcessDataProgHold [3];
        numberOfTDAd = (int)simProcessDataProgHold [4];
    }
    
    int totalNoOfNonDivCDWithBias = (int)(round(totalNoOfNonDivCD*(double)simProcessDataProgHold [6])); //----Apply a bias value to the total of nonDivCD;
    int totalNumberOfNonDivLingCD = nonDivAdjust+totalNoOfNonDivCDWithBias; //----Calculate the sum of non-dividing cell lineages plus CDs that occur without cell division
    int remainingLingNo = numberOfLing-totalNumberOfNonDivLingCD; //----Remaining no. of cell ling
    
    if (remainingLingNo < 0) remainingLingNo = 0;
    
    int totalNoOfBDTD = numberOfBDAd+numberOfTDAd; //----Sum of BD and TD
    
    double nonDivIn100 = totalNumberOfNonDivLingCD/(double)(remainingLingNo+totalNumberOfNonDivLingCD); //----Non div portion of % (non Div Ling + CD without Div)
    double divIn100 = remainingLingNo/(double)(remainingLingNo+totalNumberOfNonDivLingCD); //----Div portion of % (BD and TD)
    
    //cout<<totalNoOfNonDivCD<<" "<<totalNoOfNonDivCDWithBias<<" "<<totalNumberOfNonDivLingCD<<" "<<remainingLingNo<<" "<<totalNoOfBDTD<<" "<<nonDivIn100<<" "<<divIn100<<" Total3"<<endl;
    
    int percentBD = 0; //--1
    int percentTD = 0; //--2
    int percentCD = 0; //--3
    int nonDivPercent = 0; //--4
    
    double percentTemp = 0;
    
    //----Determine % of each event A----
    if (totalNoOfBDTD != 0){
        percentTemp = (numberOfBDAd/(double)totalNoOfBDTD)*100;
        percentBD = (int)(round((percentTemp*divIn100)));
        percentTemp = (numberOfTDAd/(double)totalNoOfBDTD)*100;
        percentTD = (int)(round((percentTemp*divIn100)));
    }
    
    if (totalNumberOfNonDivLingCD != 0){
        percentTemp = (totalNoOfNonDivCDWithBias/(double)totalNumberOfNonDivLingCD)*100;
        percentCD = (int)(round(percentTemp*nonDivIn100));
        percentTemp = (nonDivAdjust/(double)totalNumberOfNonDivLingCD)*100;
        nonDivPercent = (int)(round(percentTemp*nonDivIn100));
    }
    
    if (totalNoOfNonDivCD > numberOfTDAd && percentCD < percentTD){
        percentBD = (percentBD+percentTD)-percentCD;
        percentTD = percentCD;
    }
    else if (totalNoOfNonDivCD < numberOfTDAd && percentCD > percentTD){
        nonDivPercent = (percentCD+nonDivPercent)-percentTD;
        percentCD = percentTD;
    }
    
    //----Total of percentBD, percentTD, percentCD, nonDivPercent has to be 100%
    
    //cout<<percentBD<<" "<<percentTD<<" "<<percentCD<<" "<<nonDivPercent<<" %"<<endl;
    
    int entryCount = 0; //----Enter type values following the percentage calculations
    
    for (int counter1 = 0; counter1 < nonDivPercent; counter1++){
        if (entryCount < 100) firstEventList [entryCount] = 4, entryCount++;
    }
    
    for (int counter1 = 0; counter1 < percentCD; counter1++){
        if (entryCount < 100) firstEventList [entryCount] = 3, entryCount++;
    }
    
    for (int counter1 = 0; counter1 < percentTD; counter1++){
        if (entryCount < 100) firstEventList [entryCount] = 2, entryCount++;
    }
    
    for (int counter1 = 0; counter1 < percentBD; counter1++){
        if (entryCount < 100) firstEventList [entryCount] = 1, entryCount++;
    }
    
    if (entryCount != 100){ //----If the % is less than 100 (due to the rounding), fill with 1 (percentBD)
        for (int counter1 = 0; counter1 < 100; counter1++){
            if (entryCount < 100) firstEventList [entryCount] = 1, entryCount++;
        }
    }
}

-(void)secondEventBDListSet{
    int timeMax = (int)simProcessDataProgHold [25];
    int duration = durationEnd-durationStart;
    
    //----Expand percentage data to total 100%----
    delete [] secondEventBDList;
    secondEventBDList = new int [150];
    
    for (int counter1 = 0; counter1 < 150; counter1++){
        secondEventBDList [counter1] = 0;
    }
    
    int numberOfBDAd = 0;
    int numberOfTDAd = 0;
    int totalNoOfBDCD1 = 0;
    int totalNoOfBDCF1 = 0;
    int totalNoOfBDCD2 = 0;
    int totalNoOfBDCF2 = 0;
    
    if (timeProgCount <= duration){
        if (baseMidHold != 0){
            for (int counter1 = 0; counter1 < timeMax; counter1++){
                if (simulationDistributionMidData [counter1*11] != 0) totalNoOfBDCD1 = totalNoOfBDCD1+simulationDistributionMidData [counter1*11];
                if (simulationDistributionProgData [counter1*11] != 0) totalNoOfBDCD2 = totalNoOfBDCD2+simulationDistributionProgData [counter1*11];
                if (simulationDistributionMidData [counter1*11+2] != 0) totalNoOfBDCF1 = totalNoOfBDCF1+simulationDistributionMidData [counter1*11+2];
                if (simulationDistributionProgData [counter1*11+2] != 0) totalNoOfBDCF2 = totalNoOfBDCF2+simulationDistributionProgData [counter1*11+2];
            }
            
            numberOfBDAd = (int)(round(simProcessDataMiddleHold [3]+((simProcessDataProgHold [3]-simProcessDataMiddleHold [3])/(double)duration)*timeProgCount));
            numberOfTDAd = (int)(round(simProcessDataMiddleHold [4]+((simProcessDataProgHold [4]-simProcessDataMiddleHold [4])/(double)duration)*timeProgCount));
        }
        else{
            
            for (int counter1 = 0; counter1 < timeMax; counter1++){
                if (simulationDistributionData [counter1*11] != 0) totalNoOfBDCD1 = totalNoOfBDCD1+simulationDistributionData [counter1*11];
                if (simulationDistributionProgData [counter1*11] != 0) totalNoOfBDCD2 = totalNoOfBDCD2+simulationDistributionProgData [counter1*11];
                if (simulationDistributionData [counter1*11+2] != 0) totalNoOfBDCF1 = totalNoOfBDCF1+simulationDistributionData [counter1*11+2];
                if (simulationDistributionProgData [counter1*11+2] != 0) totalNoOfBDCF2 = totalNoOfBDCF2+simulationDistributionProgData [counter1*11+2];
            }
            
            numberOfBDAd = (int)(round(simProcessDataBaseHold [3]+((simProcessDataProgHold [3]-simProcessDataBaseHold [3])/(double)duration)*timeProgCount));
            numberOfTDAd = (int)(round(simProcessDataBaseHold [4]+((simProcessDataProgHold [4]-simProcessDataBaseHold [4])/(double)duration)*timeProgCount));
        }
        
        totalNoOfBDCD1 = totalNoOfBDCD1+(int)(round(((totalNoOfBDCD2-totalNoOfBDCD1)/(double)duration)*timeProgCount));
        totalNoOfBDCF1 = totalNoOfBDCF1+(int)(round(((totalNoOfBDCF2-totalNoOfBDCF1)/(double)duration)*timeProgCount));
    }
    else{
        
        for (int counter1 = 0; counter1 < timeMax; counter1++){
            if (simulationDistributionProgData [counter1*11] != 0) totalNoOfBDCD1 = totalNoOfBDCD1+simulationDistributionProgData [counter1*11];
            if (simulationDistributionProgData [counter1*11+2] != 0) totalNoOfBDCD1 = totalNoOfBDCD1+simulationDistributionProgData [counter1*11+2];
        }
        
        numberOfBDAd = (int)simProcessDataProgHold [3];
        numberOfTDAd = (int)simProcessDataProgHold [4];
    }
    
    //----Determine % of each event B----
    int totalNoOfAfterBD = numberOfBDAd+numberOfTDAd+totalNoOfBDCD1+totalNoOfBDCF1;
    
    int percentBD = 0; //--1
    int percentTD = 0; //--2
    int percentBDCD = 0; //--5
    int percentBDCF = 0; //--6
    
    if (totalNoOfAfterBD != 0) percentBD = (int)(round((numberOfBDAd/(double)totalNoOfAfterBD)*100));
    if (totalNoOfAfterBD != 0) percentTD = (int)(round((numberOfTDAd/(double)totalNoOfAfterBD)*100));
    if (totalNoOfAfterBD != 0) percentBDCD = (int)(round((totalNoOfBDCD1/(double)totalNoOfAfterBD)*100));
    if (totalNoOfAfterBD != 0) percentBDCF = (int)(round((totalNoOfBDCF1/(double)totalNoOfAfterBD)*100));
    
    //cout<<percentBD<<" "<<percentTD<<" "<<percentBDCD<<" "<<percentBDCF<<" %"<<endl;
    
    if (totalNoOfAfterBD != 0){ //----Adjust low frequency events; if percentage is < 0.5 (rounded to 0), set to 1% and subtract 1% from other events
        if ((numberOfBDAd/(double)totalNoOfAfterBD)*100 != 0 && percentBD == 0){
            percentBD = 1;
            
            if (percentTD > 2) percentTD--;
            else if (percentBDCD > 2) percentBDCD--;
            else if (percentBDCF > 2) percentBDCF--;
        }
        
        if ((numberOfTDAd/(double)totalNoOfAfterBD)*100 != 0 && percentTD == 0){
            percentTD = 1;
            
            if (percentBD > 2) percentBD--;
            else if (percentBDCD > 2) percentBDCD--;
            else if (percentBDCF > 2) percentBDCF--;
        }
        
        if ((totalNoOfBDCD1/(double)totalNoOfAfterBD)*100 != 0 && percentBDCD == 0){
            percentBDCD = 1;
            
            if (percentBD > 2) percentBD--;
            else if (percentTD > 2) percentTD--;
            else if (percentBDCF > 2) percentBDCF--;
        }
        
        if ((totalNoOfBDCF1/(double)totalNoOfAfterBD)*100 != 0 && percentBDCF == 0){
            percentBDCF = 1;
            
            if (percentBD > 2) percentBD--;
            else if (percentTD > 2) percentTD--;
            else if (percentBDCD > 2) percentBDCD--;
        }
    }
    
    int entryCount = 0;
    
    for (int counter1 = 0; counter1 < percentBDCF; counter1++){
        if (entryCount < 100) secondEventBDList [entryCount] = 6, entryCount++;
    }
    
    for (int counter1 = 0; counter1 < percentBDCD; counter1++){
        if (entryCount < 100) secondEventBDList [entryCount] = 5, entryCount++;
    }
    
    for (int counter1 = 0; counter1 < percentTD; counter1++){
        if (entryCount < 100) secondEventBDList [entryCount] = 2, entryCount++;
    }
    
    for (int counter1 = 0; counter1 < percentBD; counter1++){
        if (entryCount < 100) secondEventBDList [entryCount] = 1, entryCount++;
    }
    
    if (entryCount != 100){
        for (int counter1 = 0; counter1 < 100; counter1++){
            if (entryCount < 100) secondEventBDList [entryCount] = 1, entryCount++;
        }
    }
    
    //for (int counterA = 0; counterA < 100; counterA++){
    //    cout<<counterA<<" "<<secondEventBDList [counterA]<<" Second"<<endl;
    //}
    
    //----Adjust frequency, SecondBD List----
    int totalEvent = numberOfBDAd+numberOfTDAd+totalNoOfBDCD1+totalNoOfBDCF1;
    int percentTotalBD = (int)(round(numberOfBDAd/(double)totalEvent));
    int percentTotalTD = (int)(round(numberOfTDAd/(double)totalEvent));
    int percentTotalCD = (int)(round(totalNoOfBDCD1/(double)totalEvent));
    int percentTotalCF = (int)(round(totalNoOfBDCF1/(double)totalEvent));
    
    int countBD = 0;
    int countTD = 0;
    int countCD = 0;
    int countCF = 0;
    
    int randInit = 0;
    
    for (int counter2 = 0; counter2 < 1000; counter2++){ //----Try up to 100 times to find a match; if unsuccessful, set BD--
        randInit = rand() % 100 + 0;
        
        if (secondEventBDList [randInit] == 1) countBD++;
        else if (secondEventBDList [randInit] == 2) countTD++;
        else if (secondEventBDList [randInit] == 5) countCD++;
        else if (secondEventBDList [randInit] == 6) countCF++;
    }
    
    int totalCheck = countBD+countTD+countCD+countCF;
    int percentCheckTD = 0;
    int percentCheckCD = 0;
    int percentCheckCF = 0;
    
    if (totalCheck != 0){
        percentCheckTD = (int)(round(countTD/(double)totalCheck));
        percentCheckCD = (int)(round(countCD/(double)totalCheck));
        percentCheckCF = (int)(round(countCF/(double)totalCheck));
        
        int checkCount = 0;
        
        if (percentCheckTD-percentTotalTD < 0 && percentTotalTD-percentCheckTD < percentTotalBD){
            checkCount = percentTotalTD-percentCheckTD;
            
            for (int counter2 = 0; counter2 < 100; counter2++){
                if (secondEventBDList [counter2] == 1){
                    secondEventBDList [counter2] = 2;
                    checkCount--;
                    
                    if (checkCount == 0){
                        break;
                    }
                }
            }
        }
        
        if (percentCheckCD-percentTotalCD < 0 && percentTotalCD-percentCheckCD < percentTotalBD-(percentTotalTD-percentCheckTD)){
            checkCount = percentTotalCD-percentCheckCD;
            
            for (int counter2 = 0; counter2 < 100; counter2++){
                if (secondEventBDList [counter2] == 1){
                    secondEventBDList [counter2] = 5;
                    checkCount--;
                    
                    if (checkCount == 0){
                        break;
                    }
                }
            }
        }
        
        if (percentCheckCF-percentTotalCF < 0 && percentTotalCF-percentCheckCF < percentTotalBD-(percentTotalTD-percentCheckTD)-(percentTotalCD-percentCheckCD)){
            checkCount = percentTotalCF-percentCheckCF;
            
            for (int counter2 = 0; counter2 < 100; counter2++){
                if (secondEventBDList [counter2] == 1){
                    secondEventBDList [counter2] = 6;
                    checkCount--;
                    
                    if (checkCount == 0){
                        break;
                    }
                }
            }
        }
    }
    
    //for (int counterA = 0; counterA < 100; counterA++){
    //    cout<<counterA<<" "<<secondEventBDList [counterA]<<" Second"<<endl;
    //}
}

-(void)secondEventBDCFListSet{
    int timeMax = (int)simProcessDataProgHold [25];
    int duration = durationEnd-durationStart;
    
    delete [] secondEventBDCFList;
    secondEventBDCFList = new int [150];
    
    for (int counter1 = 0; counter1 < 150; counter1++){
        secondEventBDCFList [counter1] = 0;
    }
    
    int numberOfBDCFCDAd = 0;
    int numberOfBDCFTDAd = 0;
    int totalNoOfBDCFCD1 = 0;
    int totalNoOfBDCFCD2 = 0;
    
    if (timeProgCount <= duration){
        if (baseMidHold != 0){
            for (int counter1 = 0; counter1 < timeMax; counter1++){
                if (simulationDistributionMidData [counter1*11+3] != 0) totalNoOfBDCFCD1 = totalNoOfBDCFCD1+simulationDistributionMidData [counter1*11+3];
                if (simulationDistributionProgData [counter1*11+3] != 0) totalNoOfBDCFCD2 = totalNoOfBDCFCD2+simulationDistributionProgData [counter1*11+3];
            }
            
            numberOfBDCFCDAd = (int)(round(simProcessDataMiddleHold [8]+((simProcessDataProgHold [8]-simProcessDataMiddleHold [8])/(double)duration)*timeProgCount));
            numberOfBDCFTDAd = (int)(round(simProcessDataMiddleHold [9]+((simProcessDataProgHold [9]-simProcessDataMiddleHold [9])/(double)duration)*timeProgCount));
        }
        else{
            
            for (int counter1 = 0; counter1 < timeMax; counter1++){
                if (simulationDistributionData [counter1*11+3] != 0) totalNoOfBDCFCD1 = totalNoOfBDCFCD1+simulationDistributionData [counter1*11+3];
                if (simulationDistributionProgData [counter1*11+3] != 0) totalNoOfBDCFCD2 = totalNoOfBDCFCD2+simulationDistributionProgData [counter1*11+3];
            }
            
            numberOfBDCFCDAd = (int)(round(simProcessDataBaseHold [8]+((simProcessDataProgHold [8]-simProcessDataBaseHold [8])/(double)duration)*timeProgCount));
            numberOfBDCFTDAd = (int)(round(simProcessDataBaseHold [9]+((simProcessDataProgHold [9]-simProcessDataBaseHold [9])/(double)duration)*timeProgCount));
        }
        
        totalNoOfBDCFCD1 = totalNoOfBDCFCD1+(int)(round(((totalNoOfBDCFCD2-totalNoOfBDCFCD1)/(double)duration)*timeProgCount));
    }
    else{
        
        for (int counter1 = 0; counter1 < timeMax; counter1++){
            if (simulationDistributionProgData [counter1*11+3] != 0) totalNoOfBDCFCD1 = totalNoOfBDCFCD1+simulationDistributionProgData [counter1*11+3];
        }
        
        numberOfBDCFCDAd = (int)simProcessDataProgHold [8];
        numberOfBDCFTDAd = (int)simProcessDataProgHold [9];
    }
    
    //----Determine % of each event C----
    int totalNoOfAfterBDCF = numberOfBDCFCDAd+numberOfBDCFTDAd+totalNoOfBDCFCD1;
    
    int percentBDCFBD = 0; //--7
    int percentBDCFTD = 0; //--8
    int percentBDCFCD = 0; //--9
    
    if (totalNoOfAfterBDCF != 0) percentBDCFBD = (int)(round((numberOfBDCFCDAd/(double)totalNoOfAfterBDCF)*100));
    if (totalNoOfAfterBDCF != 0) percentBDCFTD = (int)(round((numberOfBDCFTDAd/(double)totalNoOfAfterBDCF)*100));
    if (totalNoOfAfterBDCF != 0) percentBDCFCD = (int)(round((totalNoOfBDCFCD1/(double)totalNoOfAfterBDCF)*100));
    
    //cout<<percentBDCFBD<<" "<<percentBDCFTD<<" "<<percentBDCFCD<<" % "<<endl;
    
    if (totalNoOfAfterBDCF != 0){
        if ((numberOfBDCFCDAd/(double)totalNoOfAfterBDCF)*100 != 0 && percentBDCFBD == 0){
            percentBDCFBD = 1;
            
            if (percentBDCFTD > 2) percentBDCFTD--;
            else if (percentBDCFCD > 2) percentBDCFCD--;
        }
        
        if ((numberOfBDCFTDAd/(double)totalNoOfAfterBDCF)*100 != 0&& percentBDCFTD == 0){
            percentBDCFTD = 1;
            
            if (percentBDCFBD > 2) percentBDCFBD--;
            else if (percentBDCFCD > 2) percentBDCFCD--;
        }
        
        if ((totalNoOfBDCFCD1/(double)totalNoOfAfterBDCF)*100 != 0 && percentBDCFCD == 0){
            percentBDCFCD = 1;
            
            if (percentBDCFBD > 2) percentBDCFBD--;
            else if (percentBDCFTD > 2) percentBDCFTD--;
        }
    }
    
    int entryCount = 0;
    int lastEntry = 0;
    
    for (int counter1 = 0; counter1 < percentBDCFBD; counter1++){
        if (entryCount < 100){
            secondEventBDCFList [entryCount] = 7, entryCount++;
            lastEntry = 7;
        }
    }
    
    for (int counter1 = 0; counter1 < percentBDCFTD; counter1++){
        if (entryCount < 100){
            secondEventBDCFList [entryCount] = 8, entryCount++;
            lastEntry = 8;
        }
    }
    
    for (int counter1 = 0; counter1 < percentBDCFCD; counter1++){
        if (entryCount < 100){
            secondEventBDCFList [entryCount] = 9, entryCount++;
            lastEntry = 9;
        }
    }
    
    if (entryCount != 0 && entryCount != 100){
        for (int counter1 = 0; counter1 < 100; counter1++){
            if (entryCount < 100) secondEventBDCFList [entryCount] = lastEntry, entryCount++;
        }
    }
    
    //for (int counterA = 0; counterA < 100; counterA++){
    //    cout<<counterA<<" "<<secondEventBDCFList [counterA]<<" Second"<<endl;
    //}
}

-(void)secondEventTDListSet{
    int timeMax = (int)simProcessDataProgHold [25];
    int duration = durationEnd-durationStart;
    
    delete [] secondEventTDList;
    secondEventTDList = new int [150];
    
    for (int counter1 = 0; counter1 < 150; counter1++){
        secondEventTDList [counter1] = 0;
    }
    
    int numberOfTDBDAd = 0;
    int numberOfTDTDAd = 0;
    int totalNoOfTDCD1 = 0;
    int totalNoOfTDCF1 = 0;
    int totalNoOfTDCD2 = 0;
    int totalNoOfTDCF2 = 0;
    
    if (timeProgCount <= duration){
        if (baseMidHold != 0){
            for (int counter1 = 0; counter1 < timeMax; counter1++){
                if (simulationDistributionMidData [counter1*11+6] != 0) totalNoOfTDCD1 = totalNoOfTDCD1+simulationDistributionMidData [counter1*11+6];
                if (simulationDistributionProgData [counter1*11+6] != 0) totalNoOfTDCD2 = totalNoOfTDCD2+simulationDistributionProgData [counter1*11+6];
                if (simulationDistributionMidData [counter1*11+4] != 0) totalNoOfTDCF1 = totalNoOfTDCF1+simulationDistributionMidData [counter1*11+4];
                if (simulationDistributionProgData [counter1*11+4] != 0) totalNoOfTDCF2 = totalNoOfTDCF2+simulationDistributionProgData [counter1*11+4];
            }
            
            numberOfTDBDAd = (int)(round(simProcessDataMiddleHold [15]+((simProcessDataProgHold [15]-simProcessDataMiddleHold [15])/(double)duration)*timeProgCount));
            numberOfTDTDAd = (int)(round(simProcessDataMiddleHold [16]+((simProcessDataProgHold [16]-simProcessDataMiddleHold [16])/(double)duration)*timeProgCount));
        }
        else{
            
            for (int counter1 = 0; counter1 < timeMax; counter1++){
                if (simulationDistributionData [counter1*11+6] != 0) totalNoOfTDCD1 = totalNoOfTDCD1+simulationDistributionData [counter1*11+6];
                if (simulationDistributionProgData [counter1*11+6] != 0) totalNoOfTDCD2 = totalNoOfTDCD2+simulationDistributionProgData [counter1*11+6];
                if (simulationDistributionData [counter1*11+4] != 0) totalNoOfTDCF1 = totalNoOfTDCF1+simulationDistributionData [counter1*11+4];
                if (simulationDistributionProgData [counter1*11+4] != 0) totalNoOfTDCF2 = totalNoOfTDCF2+simulationDistributionProgData [counter1*11+4];
            }
            
            numberOfTDBDAd = (int)(round(simProcessDataBaseHold [15]+((simProcessDataProgHold [15]-simProcessDataBaseHold [15])/(double)duration)*timeProgCount));
            numberOfTDTDAd = (int)(round(simProcessDataBaseHold [16]+((simProcessDataProgHold [16]-simProcessDataBaseHold [16])/(double)duration)*timeProgCount));
        }
        
        totalNoOfTDCD1 = totalNoOfTDCD1+(int)(round(((totalNoOfTDCD2-totalNoOfTDCD1)/(double)duration)*timeProgCount));
        totalNoOfTDCF1 = totalNoOfTDCF1+(int)(round(((totalNoOfTDCF2-totalNoOfTDCF1)/(double)duration)*timeProgCount));
    }
    else{
        
        for (int counter1 = 0; counter1 < timeMax; counter1++){
            if (simulationDistributionProgData [counter1*11+6] != 0) totalNoOfTDCD1 = totalNoOfTDCD1+simulationDistributionProgData [counter1*11+6];
            if (simulationDistributionProgData [counter1*11+4] != 0) totalNoOfTDCF1 = totalNoOfTDCF1+simulationDistributionProgData [counter1*11+4];
        }
        
        numberOfTDBDAd = (int)simProcessDataProgHold [15];
        numberOfTDTDAd= (int)simProcessDataProgHold [16];
    }
    
    //----Determine % of each event D----
    int totalNoOfAfterTD = numberOfTDBDAd+numberOfTDTDAd+totalNoOfTDCD1+totalNoOfTDCF1;
    
    int percentTDCF = 0; //10
    int percentTDBD = 0; //11
    int percentTDTD = 0; //12
    int percentTDCD = 0; //13
    
    if (totalNoOfAfterTD != 0) percentTDBD = (int)(round((numberOfTDBDAd/(double)totalNoOfAfterTD)*100));
    if (totalNoOfAfterTD != 0) percentTDTD = (int)(round((numberOfTDTDAd/(double)totalNoOfAfterTD)*100));
    if (totalNoOfAfterTD != 0) percentTDCD = (int)(round((totalNoOfTDCD1/(double)totalNoOfAfterTD)*100));
    if (totalNoOfAfterTD != 0) percentTDCF = (int)(round((totalNoOfTDCF1/(double)totalNoOfAfterTD)*100));
    
    if (totalNoOfAfterTD != 0){
        if ((numberOfTDBDAd/(double)totalNoOfAfterTD)*100 != 0 && percentTDBD == 0){
            percentTDBD = 1;
            
            if (percentTDTD > 2) percentTDTD--;
            else if (percentTDCD > 2) percentTDCD--;
            else if (percentTDCF > 2) percentTDCF--;
        }
        
        if ((numberOfTDTDAd/(double)totalNoOfAfterTD)*100 != 0 && percentTDTD == 0){
            percentTDTD = 1;
            
            if (percentTDBD > 2) percentTDBD--;
            else if (percentTDCD > 2) percentTDCD--;
            else if (percentTDCF > 2) percentTDCF--;
        }
        
        if ((totalNoOfTDCD1/(double)totalNoOfAfterTD)*100 != 0 && percentTDCD == 0){
            percentTDCD = 1;
            
            if (percentTDBD > 2) percentTDBD--;
            else if (percentTDTD > 2) percentTDTD--;
            else if (percentTDCF > 2) percentTDCF--;
        }
        
        if ((totalNoOfTDCF1/(double)totalNoOfAfterTD)*100 != 0 && percentTDCF == 0){
            percentTDCF = 1;
            
            if (percentTDBD > 2) percentTDBD--;
            else if (percentTDTD > 2) percentTDTD--;
            else if (percentTDCD > 2) percentTDCD--;
        }
    }
    
    //cout<<percentTDCF<<" "<<percentTDBD<<" "<<percentTDTD<<" "<<percentTDCD<<" %"<<endl;
    
    int entryCount = 0;
    int lastEntry = 0;
    
    for (int counter1 = 0; counter1 < percentTDCF; counter1++){
        if (entryCount < 100){
            secondEventTDList [entryCount] = 10, entryCount++;
            lastEntry = 10;
        }
    }
    
    for (int counter1 = 0; counter1 < percentTDBD; counter1++){
        if (entryCount < 100){
            secondEventTDList [entryCount] = 11, entryCount++;
            lastEntry = 11;
        }
    }
    
    for (int counter1 = 0; counter1 < percentTDTD; counter1++){
        if (entryCount < 100){
            secondEventTDList [entryCount] = 12, entryCount++;
            lastEntry = 12;
        }
    }
    
    for (int counter1 = 0; counter1 < percentTDCD; counter1++){
        if (entryCount < 100){
            secondEventTDList [entryCount] = 13, entryCount++;
            lastEntry = 13;
        }
    }
    
    if (entryCount != 0 && entryCount != 100){
        for (int counter1 = 0; counter1 < 100; counter1++){
            if (entryCount < 100) secondEventTDList [entryCount] = lastEntry, entryCount++;
        }
    }
    
    //for (int counterA = 0; counterA < 100; counterA++){
    //    cout<<counterA<<" "<<secondEventTDList [counterA]<<" Second"<<endl;
    //}
}

-(void)secondEventTDCFListSet{
    int timeMax = (int)simProcessDataProgHold [25];
    int duration = durationEnd-durationStart;
    
    delete [] secondEventTDCFList;
    secondEventTDCFList = new int [150];
    
    for (int counter1 = 0; counter1 < 150; counter1++){
        secondEventTDCFList [counter1] = 0;
    }
    
    int numberOfTDCFBDAd = 0;
    int numberOfTDCFTDAd = 0;
    int totalNoOfTDCFCD1 = 0;
    int totalNoOfTDCFCD2 = 0;
    
    if (timeProgCount <= duration){
        if (baseMidHold != 0){
            for (int counter1 = 0; counter1 < timeMax; counter1++){
                if (simulationDistributionMidData [counter1*11+5] != 0) totalNoOfTDCFCD1 = totalNoOfTDCFCD1+simulationDistributionMidData [counter1*11+5];
                if (simulationDistributionProgData [counter1*11+5] != 0) totalNoOfTDCFCD2 = totalNoOfTDCFCD2+simulationDistributionProgData [counter1*11+5];
            }
            
            numberOfTDCFBDAd = (int)(round(simProcessDataMiddleHold [12]+((simProcessDataProgHold [12]-simProcessDataMiddleHold [12])/(double)duration)*timeProgCount));
            numberOfTDCFTDAd = (int)(round(simProcessDataMiddleHold [13]+((simProcessDataProgHold [13]-simProcessDataMiddleHold [13])/(double)duration)*timeProgCount));
        }
        else{
            
            for (int counter1 = 0; counter1 < timeMax; counter1++){
                if (simulationDistributionData [counter1*11+5] != 0) totalNoOfTDCFCD1 = totalNoOfTDCFCD1+simulationDistributionData [counter1*11+5];
                if (simulationDistributionProgData [counter1*11+5] != 0) totalNoOfTDCFCD2 = totalNoOfTDCFCD2+simulationDistributionProgData [counter1*11+5];
            }
            
            numberOfTDCFBDAd = (int)(round(simProcessDataBaseHold [12]+((simProcessDataProgHold [12]-simProcessDataBaseHold [12])/(double)duration)*timeProgCount));
            numberOfTDCFTDAd = (int)(round(simProcessDataBaseHold [13]+((simProcessDataProgHold [13]-simProcessDataBaseHold [13])/(double)duration)*timeProgCount));
        }
        
        totalNoOfTDCFCD1 = totalNoOfTDCFCD1+(int)(round(round(((totalNoOfTDCFCD2-totalNoOfTDCFCD1)/(double)duration)*timeProgCount)));
    }
    else{
        
        for (int counter1 = 0; counter1 < timeMax; counter1++){
            if (simulationDistributionProgData [counter1*11+5] != 0)totalNoOfTDCFCD1 = totalNoOfTDCFCD1+simulationDistributionProgData [counter1*11+5];
        }
        
        numberOfTDCFBDAd = (int)simProcessDataProgHold [12];
        numberOfTDCFTDAd = (int)simProcessDataProgHold [13];
    }
    
    int totalNoOfAfterTDCF = numberOfTDCFBDAd+numberOfTDCFTDAd+totalNoOfTDCFCD1;
    
    int percentTDCFBD = 0; //--14
    int percentTDCFTD = 0; //--15
    int percentTDCFCD = 0; //--16
    
    if (totalNoOfAfterTDCF != 0) percentTDCFBD = (int)(round((numberOfTDCFBDAd/(double)totalNoOfAfterTDCF)*100));
    if (totalNoOfAfterTDCF != 0) percentTDCFTD = (int)(round((numberOfTDCFTDAd/(double)totalNoOfAfterTDCF)*100));
    if (totalNoOfAfterTDCF != 0) percentTDCFCD = (int)(round((totalNoOfTDCFCD1/(double)totalNoOfAfterTDCF)*100));
    
    if (totalNoOfAfterTDCF != 0){
        if ((numberOfTDCFBDAd/(double)totalNoOfAfterTDCF)*100 != 0 && percentTDCFBD == 0){
            percentTDCFBD = 1;
            
            if (percentTDCFTD > 2) percentTDCFTD--;
            else if (percentTDCFCD > 2) percentTDCFCD--;
        }
        
        if ((numberOfTDCFTDAd/(double)totalNoOfAfterTDCF)*100 != 0&& percentTDCFTD == 0){
            percentTDCFTD = 1;
            
            if (percentTDCFBD > 2) percentTDCFBD--;
            else if (percentTDCFCD > 2) percentTDCFCD--;
        }
        
        if ((totalNoOfTDCFCD1/(double)totalNoOfAfterTDCF)*100 != 0 && percentTDCFCD == 0){
            percentTDCFCD = 1;
            
            if (percentTDCFBD > 2) percentTDCFBD--;
            else if (percentTDCFTD > 2) percentTDCFTD--;
        }
    }
    
    //cout<<percentTDCFBD<<" "<<percentTDCFTD<<" "<<percentTDCFCD<<" % "<<endl;
    
    int entryCount = 0;
    int lastEntry = 0;
    
    for (int counter1 = 0; counter1 < percentTDCFBD; counter1++){
        if (entryCount < 100){
            secondEventTDCFList [entryCount] = 14, entryCount++;
            lastEntry = 14;
        }
    }
    
    for (int counter1 = 0; counter1 < percentTDCFTD; counter1++){
        if (entryCount < 100){
            secondEventTDCFList [entryCount] = 15, entryCount++;
            lastEntry = 15;
        }
    }
    
    for (int counter1 = 0; counter1 < percentTDCFCD; counter1++){
        if (entryCount < 100){
            secondEventTDCFList [entryCount] = 16, entryCount++;
            lastEntry = 16;
        }
    }
    
    if (entryCount != 0 && entryCount != 100){
        for (int counter1 = 0; counter1 < 100; counter1++){
            if (entryCount < 100) secondEventTDCFList [entryCount] = lastEntry, entryCount++;
        }
    }
    
    //for (int counterA = 0; counterA < 100; counterA++){
    //    cout<<counterA<<" "<<secondEventTDCFList [counterA]<<" Second"<<endl;
    //}
}

-(void)randBDRangeSet{
    int duration = durationEnd-durationStart;
    int rangeBDAd = 0;
    int rangeCDAd = 0;
    
    if (timeProgCount <= duration){
        if (baseMidHold != 0){
            rangeBDAd = (int)(round(simProcessDataMiddleHold [26]+((simProcessDataProgHold [26]-simProcessDataMiddleHold [26])/(double)duration)*timeProgCount));
            rangeCDAd = (int)(round(simProcessDataMiddleHold [27]+((simProcessDataProgHold [27]-simProcessDataMiddleHold [27])/(double)duration)*timeProgCount));
        }
        else{
            
            rangeBDAd = (int)(round(simProcessDataBaseHold [26]+((simProcessDataProgHold [26]-simProcessDataBaseHold [26])/(double)duration)*timeProgCount));
            rangeCDAd = (int)(round(simProcessDataBaseHold [27]+((simProcessDataProgHold [27]-simProcessDataBaseHold [27])/(double)duration)*timeProgCount));
        }
    }
    else{
        
        rangeBDAd = (int)simProcessDataProgHold [26];
        rangeCDAd = (int)simProcessDataProgHold [27];
    }
    
    randBDRangeA = (int)(round(rangeBDAd-rangeBDAd*0.25));
    randBDRangeB = (int)(round(rangeBDAd+rangeBDAd*0.25));
    randCDRangeA = (int)(round(rangeCDAd-rangeCDAd*0.25));
    randCDRangeB = (int)(round(rangeCDAd+rangeCDAd*0.25));
    
    if (randBDRangeA == 0 && randBDRangeB == 0){
        randBDRangeA = (int)(round(simProcessDataProgHold [25]*0.8-simProcessDataProgHold [25]*0.8*0.25));
        randBDRangeB = (int)(round(simProcessDataProgHold [25]*0.8));
    }
    
    if (randCDRangeA == 0 && randCDRangeB == 0){
        randCDRangeA = (int)(round(simProcessDataProgHold [25]*0.5-simProcessDataProgHold [25]*0.5*0.25));
        randCDRangeB = (int)(round(simProcessDataProgHold [25]*0.5));
    }
}

@end
