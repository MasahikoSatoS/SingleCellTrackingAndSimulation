//
//  SourceS.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 10/21/16.
//
//

#import "SourceS.h"

@implementation SourceS

-(void)sourceMain{
    if (sourceStatusHold == 0){
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
    else if (sourceStatusHold == 1){
        string imageDisplayPath = analysisDataFolderPath+"/"+seriesName+"_AnalysisResults";
        string imageDisplayPath2;
        string imageDisplayPath3;
        string imageDisplayPath4;
        string stringExtract;
        string stringExtract2;
        string lineageAdditionalDataPath;
        
        DIR *dir;
        struct dirent *dent;
        DIR *dir2;
        struct dirent *dent2;
        DIR *dir3;
        struct dirent *dent3;
        
        ifstream fin;
        
        long sizeForCopy = 0;
        long sizeForCopy2 = 0;
        long sizeForCopy3 = 0;
        
        int identicalDataFound = 0;
        int ifDataMainTempCount = 0;
        int tableMainTempCount = 0;
        int lineageDataCount = 0;
        int stepCount = 0;
        int finData [60];
        int terminationFlag = 0;
        int ifTimeLineDataTempCount = 0;
        int ifStatusEntryCount = 0;
        
        unsigned long long readPosition = 0;
        
        fileDeleteCount = 0;
        
        dir = opendir(imageDisplayPath.c_str());
        
        if (dir != NULL){
            string entry; //----Analysis ID----
            string entry2; //----Treat name
            
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                    if ((int)entry.find("_IDResults") != -1){
                        imageDisplayPath2 = imageDisplayPath+"/"+entry;
                        
                        dir2 = opendir(imageDisplayPath2.c_str());
                        
                        if (dir2 != NULL){
                            while ((dent2 = readdir(dir2))){
                                entry2 = dent2 -> d_name;
                                
                                if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                    if ((int)entry2.find("_Results") != -1){
                                        if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                        arrayFileDelete [fileDeleteCount] = entry+"/"+entry2, fileDeleteCount++;
                                    }
                                }
                            }
                            
                            closedir(dir2);
                        }
                    }
                }
            }
            
            closedir(dir);
            
            //----Directory Sort----
            NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
            
            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                [unsortedArray addObject:@(arrayFileDelete [counter1].c_str())];
            }
            
            [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
            
            for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                arrayFileDelete [counter1] = [unsortedArray [counter1] UTF8String];
            }
        }
        
        string entry3; //----File name----
        string getString;
        
        struct stat sizeOfFile;
        
        for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
            imageDisplayPath3 = imageDisplayPath+"/"+arrayFileDelete [counter1];
            
            dir3 = opendir(imageDisplayPath3.c_str());
            
            if (dir3 != NULL){
                while ((dent3 = readdir(dir3))){
                    entry3 = dent3 -> d_name;
                    
                    if (entry3 != "." && entry3 != ".." && entry3 != ".DS_Store"){
                        if ((int)entry3.find("DetailTable") != -1){
                            identicalDataFound = 0;
                            
                            stringExtract = arrayFileDelete [counter1].substr(0, arrayFileDelete [counter1].find("_IDResults"));
                            stringExtract2 = arrayFileDelete [counter1].substr(arrayFileDelete [counter1].find("/")+1);
                            stringExtract2 = stringExtract2.substr(0, stringExtract2.find("_Results"));
                            
                            if (lineageDataEntryCount != 0){
                                for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
                                    if (arrayTableMain [counter2][2] == seriesName && arrayTableMain [counter2][3] == stringExtract && arrayTableMain [counter2][4] == stringExtract2){
                                        identicalDataFound = 1;
                                        break;
                                    }
                                }
                            }
                            
                            if (identicalDataFound == 0 && lineageDataEntryCount < 101){
                                imageDisplayPath4 = imageDisplayPath3+"/"+"LineageDataAnalysis";
                                
                                sizeForCopy = 0;
                                
                                if (stat(imageDisplayPath4.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                }
                                
                                //----Array for Lineage data----
                                int *arrayLineageDataTemp = new int [sizeForCopy+50];
                                lineageDataCount = 0;
                                
                                if (sizeForCopy != 0){
                                    fin.open(imageDisplayPath4.c_str(), ios::in | ios::binary);
                                    
                                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    fin.close();
                                    
                                    readPosition = 0;
                                    stepCount = 0;
                                    
                                    do{
                                        
                                        if (stepCount == 0){
                                            finData [0] = uploadTemp [readPosition], readPosition++; //--1 +-
                                            finData [1] = uploadTemp [readPosition], readPosition++;
                                            finData [2] = uploadTemp [readPosition], readPosition++; //--2 X Position
                                            finData [3] = uploadTemp [readPosition], readPosition++; //--3 +-
                                            finData [4] = uploadTemp [readPosition], readPosition++;
                                            finData [5] = uploadTemp [readPosition], readPosition++; //--4 Y Position
                                            finData [6] = uploadTemp [readPosition], readPosition++;
                                            finData [7] = uploadTemp [readPosition], readPosition++; //--5 Time point
                                            finData [8] = uploadTemp [readPosition], readPosition++; //--6 Event type
                                            finData [9] = uploadTemp [readPosition], readPosition++; //--7 +-
                                            finData [10] = uploadTemp [readPosition], readPosition++;
                                            finData [11] = uploadTemp [readPosition], readPosition++;
                                            finData [12] = uploadTemp [readPosition], readPosition++;
                                            finData [13] = uploadTemp [readPosition], readPosition++; //--8 Next cell/fuse no
                                            finData [14] = uploadTemp [readPosition], readPosition++; //--9 +-
                                            finData [15] = uploadTemp [readPosition], readPosition++;
                                            finData [16] = uploadTemp [readPosition], readPosition++;
                                            finData [17] = uploadTemp [readPosition], readPosition++;
                                            finData [18] = uploadTemp [readPosition], readPosition++; //--10 Cell no
                                            finData [19] = uploadTemp [readPosition], readPosition++;
                                            finData [20] = uploadTemp [readPosition], readPosition++;
                                            finData [21] = uploadTemp [readPosition], readPosition++; //--11 Ling no
                                            finData [22] = uploadTemp [readPosition], readPosition++;
                                            finData [23] = uploadTemp [readPosition], readPosition++;
                                            finData [24] = uploadTemp [readPosition], readPosition++; //--12 Ling no Fuse
                                            finData [25] = uploadTemp [readPosition], readPosition++;
                                            finData [26] = uploadTemp [readPosition], readPosition++;
                                            finData [27] = uploadTemp [readPosition], readPosition++; //--12 Ling no Fuse
                                            
                                            if (finData [0] == 1) finData [2] = (finData [1]*256+finData [2])*-1;
                                            else finData [2] = finData [1]*256+finData [2];
                                            
                                            if (finData [3] == 1) finData [5] = (finData [4]*256+finData [5])*-1;
                                            else finData [5] = finData [4]*256+finData [5];
                                            
                                            finData [7] = finData [6]*256+finData [7];
                                            
                                            if (finData [9] == 1) finData [13] = (finData [10]*16777216+finData [11]*65536+finData [12]*256+finData [13])*-1;
                                            else finData [13] = finData [10]*16777216+finData [11]*65536+finData [12]*256+finData [13];
                                            
                                            if (finData [14] == 1) finData [18] = (finData [15]*16777216+finData [16]*65536+finData [17]*256+finData [18])*-1;
                                            else finData [18] = finData [15]*16777216+finData [16]*65536+finData [17]*256+finData [18];
                                            
                                            finData [21] = finData [19]*65536+finData [20]*256+finData [21];
                                            finData [24] = finData [22]*65536+finData [23]*256+finData [24];
                                            finData [27] = finData [25]*65536+finData [26]*256+finData [27];
                                            
                                            if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                                            else{
                                                
                                                arrayLineageDataTemp [lineageDataCount] = finData [2], lineageDataCount++;
                                                arrayLineageDataTemp [lineageDataCount] = finData [5], lineageDataCount++;
                                                arrayLineageDataTemp [lineageDataCount] = finData [7], lineageDataCount++;
                                                arrayLineageDataTemp [lineageDataCount] = finData [8], lineageDataCount++;
                                                arrayLineageDataTemp [lineageDataCount] = finData [13], lineageDataCount++;
                                                arrayLineageDataTemp [lineageDataCount] = finData [18], lineageDataCount++;
                                                arrayLineageDataTemp [lineageDataCount] = finData [21], lineageDataCount++;
                                                arrayLineageDataTemp [lineageDataCount] = finData [24], lineageDataCount++;
                                                arrayLineageDataTemp [lineageDataCount] = finData [27], lineageDataCount++;
                                            }
                                        }
                                        
                                    } while (stepCount != 3);
                                    
                                    delete [] uploadTemp;
                                    
                                    fin.close();
                                }
                                
                                //for (int counterA = 0; counterA < lineageDataCount/9; counterA++){
                                //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayLineageDataTemp [counterA*9+counterB];
                                //    cout<<" arrayLineageDataTemp "<<counterA<<endl;
                                //}
                                
                                imageDisplayPath4 = imageDisplayPath3+"/"+"IFData";
                                
                                sizeForCopy = 0;
                                
                                if (stat(imageDisplayPath4.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                }
                                
                                //----Array for IFData----
                                int *arrayIFDataMainTemp = new int [sizeForCopy+50];
                                ifDataMainTempCount = 0;
                                
                                if (sizeForCopy != 0){
                                    fin.open(imageDisplayPath4.c_str(), ios::in | ios::binary);
                                    
                                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    fin.close();
                                    
                                    readPosition = 0;
                                    stepCount = 0;
                                    
                                    do{
                                        
                                        if (stepCount == 0){
                                            finData [0] = uploadTemp [readPosition], readPosition++; //--1 +-
                                            finData [1] = uploadTemp [readPosition], readPosition++; //--2 Cell no
                                            finData [2] = uploadTemp [readPosition], readPosition++;
                                            finData [3] = uploadTemp [readPosition], readPosition++;
                                            finData [4] = uploadTemp [readPosition], readPosition++;
                                            finData [5] = uploadTemp [readPosition], readPosition++; //--4 Ling no
                                            finData [6] = uploadTemp [readPosition], readPosition++;
                                            finData [7] = uploadTemp [readPosition], readPosition++;
                                            finData [8] = uploadTemp [readPosition], readPosition++; //--7 TP
                                            finData [9] = uploadTemp [readPosition], readPosition++;
                                            finData [10] = uploadTemp [readPosition], readPosition++; //--9 Live/IF
                                            finData [11] = uploadTemp [readPosition], readPosition++; //--10 Ch1 no
                                            finData [12] = uploadTemp [readPosition], readPosition++; //--11 Ch1 value
                                            finData [13] = uploadTemp [readPosition], readPosition++;
                                            finData [14] = uploadTemp [readPosition], readPosition++;
                                            finData [15] = uploadTemp [readPosition], readPosition++; //--11 Ch1 area
                                            finData [16] = uploadTemp [readPosition], readPosition++;
                                            finData [17] = uploadTemp [readPosition], readPosition++;
                                            finData [18] = uploadTemp [readPosition], readPosition++; //--17 Ch2 no
                                            finData [19] = uploadTemp [readPosition], readPosition++; //--18 Ch2 value
                                            finData [20] = uploadTemp [readPosition], readPosition++;
                                            finData [21] = uploadTemp [readPosition], readPosition++;
                                            finData [22] = uploadTemp [readPosition], readPosition++; //--21 Ch2 area
                                            finData [23] = uploadTemp [readPosition], readPosition++;
                                            finData [24] = uploadTemp [readPosition], readPosition++;
                                            finData [25] = uploadTemp [readPosition], readPosition++; //--24 Ch3 no
                                            finData [26] = uploadTemp [readPosition], readPosition++; //--25 Ch3 value
                                            finData [27] = uploadTemp [readPosition], readPosition++;
                                            finData [28] = uploadTemp [readPosition], readPosition++;
                                            finData [29] = uploadTemp [readPosition], readPosition++; //--28 Ch3 area
                                            finData [30] = uploadTemp [readPosition], readPosition++;
                                            finData [31] = uploadTemp [readPosition], readPosition++;
                                            
                                            finData [32] = uploadTemp [readPosition], readPosition++; //--31 Ch4 no
                                            finData [33] = uploadTemp [readPosition], readPosition++; //--32 Ch4 value
                                            finData [34] = uploadTemp [readPosition], readPosition++;
                                            finData [35] = uploadTemp [readPosition], readPosition++;
                                            finData [36] = uploadTemp [readPosition], readPosition++; //--35 Ch4 area
                                            finData [37] = uploadTemp [readPosition], readPosition++;
                                            finData [38] = uploadTemp [readPosition], readPosition++;
                                            finData [39] = uploadTemp [readPosition], readPosition++; //--38 Ch5 no
                                            finData [40] = uploadTemp [readPosition], readPosition++; //--39 Ch5 value
                                            finData [41] = uploadTemp [readPosition], readPosition++;
                                            finData [42] = uploadTemp [readPosition], readPosition++;
                                            finData [43] = uploadTemp [readPosition], readPosition++; //--42 Ch5 area
                                            finData [44] = uploadTemp [readPosition], readPosition++;
                                            finData [45] = uploadTemp [readPosition], readPosition++;
                                            finData [46] = uploadTemp [readPosition], readPosition++; //--46 Ch6 no
                                            finData [47] = uploadTemp [readPosition], readPosition++; //--47 Ch6 value
                                            finData [48] = uploadTemp [readPosition], readPosition++;
                                            finData [49] = uploadTemp [readPosition], readPosition++;
                                            finData [50] = uploadTemp [readPosition], readPosition++; //--50 Ch6 area
                                            finData [51] = uploadTemp [readPosition], readPosition++;
                                            finData [52] = uploadTemp [readPosition], readPosition++;
                                            
                                            if (finData [0] == 1) finData [4] = (finData [1]*16777216+finData [2]*65536+finData [3]*256+finData [4])*-1;
                                            else finData [4] = finData [1]*16777216+finData [2]*65536+finData [3]*256+finData [4];
                                            
                                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                            finData [9] = finData [8]*256+finData [9];
                                            finData [14] = finData [12]*65536+finData [13]*256+finData [14];
                                            finData [17] = finData [15]*65536+finData [16]*256+finData [17];
                                            finData [21] = finData [19]*65536+finData [20]*256+finData [21];
                                            finData [24] = finData [22]*65536+finData [23]*256+finData [24];
                                            finData [28] = finData [26]*65536+finData [27]*256+finData [28];
                                            finData [31] = finData [29]*65536+finData [30]*256+finData [31];
                                            
                                            finData [35] = finData [33]*65536+finData [34]*256+finData [35];
                                            finData [38] = finData [36]*65536+finData [37]*256+finData [38];
                                            finData [42] = finData [40]*65536+finData [41]*256+finData [42];
                                            finData [45] = finData [43]*65536+finData [44]*256+finData [45];
                                            finData [49] = finData [47]*65536+finData [48]*256+finData [49];
                                            finData [52] = finData [50]*65536+finData [51]*256+finData [52];
                                            
                                            if (finData [7] == 0 && finData [9] == 0) stepCount = 3;
                                            else{
                                                
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [4], ifDataMainTempCount++;
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [7], ifDataMainTempCount++;
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [9], ifDataMainTempCount++;
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [10], ifDataMainTempCount++;
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [11], ifDataMainTempCount++;
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [14], ifDataMainTempCount++;
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [17], ifDataMainTempCount++;
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [18], ifDataMainTempCount++;
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [21], ifDataMainTempCount++;
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [24], ifDataMainTempCount++;
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [25], ifDataMainTempCount++;
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [28], ifDataMainTempCount++;
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [31], ifDataMainTempCount++;
                                                
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [32], ifDataMainTempCount++;
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [35], ifDataMainTempCount++;
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [38], ifDataMainTempCount++;
                                                
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [39], ifDataMainTempCount++;
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [42], ifDataMainTempCount++;
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [45], ifDataMainTempCount++;
                                                
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [46], ifDataMainTempCount++;
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [49], ifDataMainTempCount++;
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [52], ifDataMainTempCount++;
                                            }
                                        }
                                        
                                    } while (stepCount != 3);
                                    
                                    delete [] uploadTemp;
                                    
                                    fin.close();
                                }
                                
                                //for (int counterA = 0; counterA < ifDataMainTempCount/13; counterA++){
                                //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<arrayIFDataMainTemp [counterA*13+counterB];
                                //    cout<<" arrayIFDataMainTemp "<<counterA+1<<endl;
                                //}
                                
                                imageDisplayPath4 = imageDisplayPath3+"/"+"IFTimeLine";
                                
                                sizeForCopy = 0;
                                
                                if (stat(imageDisplayPath4.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                }
                                
                                //----Array for IFTimeLine----
                                int *arrayIFTimeLineDataTemp = new int [sizeForCopy+50];
                                ifTimeLineDataTempCount = 0;
                                
                                fin.open(imageDisplayPath4.c_str(), ios::in);
                                
                                if (fin.is_open()){
                                    do{
                                        
                                        terminationFlag = 1;
                                        
                                        getline(fin, getString);
                                        
                                        if (getString != "") arrayIFTimeLineDataTemp [ifTimeLineDataTempCount] = atoi(getString.c_str()), ifTimeLineDataTempCount++;
                                        else terminationFlag = 0;
                                        
                                    } while (terminationFlag == 1);
                                    
                                    fin.close();
                                }
                                
                                //for (int counterA = 0; counterA < ifTimeLineDataTempCount/6; counterA++){
                                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayIFTimeLineDataTemp [counterA*6+counterB];
                                //    cout<<" arrayIFTimeLineDataTemp "<<counterA<<endl;
                                //}
                                
                                imageDisplayPath4 = imageDisplayPath3+"/"+"MainTable";
                                
                                sizeForCopy = 0;
                                
                                if (stat(imageDisplayPath4.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                }
                                
                                string *arrayTableMainTemp = new string [sizeForCopy+50];
                                tableMainTempCount = 0;
                                
                                fin.open(imageDisplayPath4.c_str(), ios::in);
                                
                                if (fin.is_open()){
                                    do{
                                        
                                        terminationFlag = 1;
                                        
                                        getline(fin, getString);
                                        
                                        if (getString != "") arrayTableMainTemp [tableMainTempCount] = getString, tableMainTempCount++;
                                        else terminationFlag = 0;
                                        
                                    } while (terminationFlag == 1);
                                    
                                    fin.close();
                                }
                                
                                imageDisplayPath4 = imageDisplayPath3+"/"+"IFDataStatus";
                                
                                sizeForCopy = 0;
                                
                                if (stat(imageDisplayPath4.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                }
                                
                                imageDisplayPath4 = imageDisplayPath3+"/"+"AreaData";
                                
                                sizeForCopy2 = 0;
                                
                                if (stat(imageDisplayPath4.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy2 = sizeOfFile.st_size;
                                }
                                
                                //----Array for Link Table----
                                imageDisplayPath4 = imageDisplayPath3+"/"+"LinkData";
                                
                                sizeForCopy3 = 0;
                                
                                if (stat(imageDisplayPath4.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy3 = sizeOfFile.st_size;
                                }
                                
                                //for (int counterA = 0; counterA < 1; counterA++){
                                //    for (int counterB = 0; counterB < tableMainTempCount; counterB++) cout<<" "<<arrayTableMainTemp [counterA+counterB];
                                //    cout<<" arrayTableMain "<<counterA<<endl;
                                //}
                                
                                if (firstReadFlag == 0){
                                    firstReadFlag = 1;
                                    lineageDataEntryCount = 0;
                                    lineageFluorescentDataTypeEntryCount = 0;
                                    
                                    arrayLineageDataEntryHold = new unsigned long [101];
                                    arrayIFDataEntryHold = new int [101];
                                    arrayIFTimeLineDataEntryHold = new int [101];
                                    arrayTableMainHold = new int [101];
                                    arrayIfTimeStatusHold = new int [101];
                                    arrayAreaDataHold = new int [101];
                                    lineageLinkHold = new int [101];
                                    
                                    arrayLineageData = new int *[101];
                                    arrayIFData = new int *[101];
                                    arrayIFTimeLineData = new int *[101];
                                    arrayTableMain = new string *[101];
                                    arrayTableDetail = new int *[101];
                                    arrayLineageDataType = new string *[101];
                                    arrayLineageFluorescentDataType = new string *[101];
                                    arrayIfTimeStatus = new int *[101];
                                    arrayAreaData = new int *[101];
                                    arrayLineageLink = new int *[101];
                                    
                                    for (int counter2 = 0; counter2 < 101; counter2++){
                                        arrayLineageData [counter2] = new int [lineageDataCount+10]; //==
                                        arrayIFData [counter2] = new int [ifDataMainTempCount+10];
                                        arrayIFTimeLineData [counter2] = new int [ifTimeLineDataTempCount+10];
                                        arrayTableMain [counter2] = new string [tableMainTempCount+10];
                                        arrayTableDetail [counter2] = new int [18];
                                        arrayLineageDataType [counter2] = new string [8];
                                        arrayLineageFluorescentDataType [counter2] = new string [9];
                                        arrayIfTimeStatus [counter2] = new int [sizeForCopy+50];
                                        arrayAreaData [counter2] = new int [sizeForCopy2+50];
                                        arrayLineageLink [counter2] = new int [sizeForCopy3+50];
                                    }
                                    
                                    arraySelectedLing = new int [101];
                                    
                                    for (int counter2 = 0; counter2 < 101; counter2++){
                                        arrayLineageDataEntryHold [counter2] = 0;
                                        arrayIFDataEntryHold [counter2] = 0;
                                        arrayIFTimeLineDataEntryHold [counter2] = 0;
                                        arrayTableMainHold [counter2] = 0;
                                        arraySelectedLing [counter2] = 0;
                                        arrayIfTimeStatusHold [counter2] = 0;
                                        arrayAreaDataHold [counter2] = 0;
                                        lineageLinkHold [counter2] = 0;
                                    }
                                    
                                    lineageFluorescentDataTypeEntryLimit = 101;
                                    
                                    lineageDataEntryCount++;
                                }
                                else if (lineageDataEntryCount < 101){
                                    delete [] arrayLineageData [lineageDataEntryCount];
                                    delete [] arrayIFData [lineageDataEntryCount];
                                    delete [] arrayIFTimeLineData [lineageDataEntryCount];
                                    delete [] arrayTableMain [lineageDataEntryCount];
                                    delete [] arrayIfTimeStatus [lineageDataEntryCount];
                                    delete [] arrayAreaData [lineageDataEntryCount];
                                    delete [] arrayLineageLink [lineageDataEntryCount];
                                    
                                    arrayLineageData [lineageDataEntryCount] = new int [lineageDataCount+10]; //==
                                    arrayIFData [lineageDataEntryCount] = new int [ifDataMainTempCount+10];
                                    arrayIFTimeLineData [lineageDataEntryCount] = new int [ifTimeLineDataTempCount+10];
                                    arrayTableMain [lineageDataEntryCount] = new string [tableMainTempCount+10];
                                    arrayIfTimeStatus [lineageDataEntryCount] = new int [sizeForCopy+50];
                                    arrayAreaData [lineageDataEntryCount] = new int [sizeForCopy2+50];
                                    arrayLineageLink [lineageDataEntryCount] = new int [sizeForCopy3+50];
                                    
                                    lineageDataEntryCount++;
                                }
                                else{
                                    
                                    NSAlert *alert = [[NSAlert alloc] init];
                                    [alert addButtonWithTitle:@"OK"];
                                    [alert setMessageText:@"Entry Limit Exceeded: 100"];
                                    [alert setAlertStyle:NSAlertStyleWarning];
                                    [alert runModal];
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                                    [sound play];
                                }
                                
                                if (lineageDataEntryCount-1 < 101){
                                    for (int counter2 = 0; counter2 < lineageDataCount; counter2++){
                                        arrayLineageData [lineageDataEntryCount-1][counter2] = arrayLineageDataTemp [counter2];
                                    }
                                    
                                    imageDisplayPath4 = imageDisplayPath3+"/"+"LineageDataAnalysisEntry";
                                    
                                    fin.open(imageDisplayPath4.c_str(), ios::in);
                                    
                                    if (fin.is_open()){
                                        getline(fin, getString);
                                        
                                        arrayLineageDataEntryHold [lineageDataEntryCount-1] = (unsigned long)(atoi(getString.c_str()));
                                        
                                        fin.close();
                                    }
                                    
                                    for (int counter2 = 0; counter2 < ifDataMainTempCount; counter2++){
                                        arrayIFData [lineageDataEntryCount-1][counter2] = arrayIFDataMainTemp [counter2]; //=====
                                    }
                                    
                                    imageDisplayPath4 = imageDisplayPath3+"/"+"IFDataEntry";
                                    
                                    fin.open(imageDisplayPath4.c_str(), ios::in);
                                    
                                    if (fin.is_open()){
                                        getline(fin, getString);
                                        
                                        arrayIFDataEntryHold [lineageDataEntryCount-1] = atoi(getString.c_str());
                                        
                                        fin.close();
                                    }
                                    
                                    for (int counter2 = 0; counter2 < ifTimeLineDataTempCount; counter2++){
                                        arrayIFTimeLineData [lineageDataEntryCount-1][counter2] = 0;
                                    }
                                    
                                    for (int counter2 = 0; counter2 < ifTimeLineDataTempCount; counter2++){
                                        arrayIFTimeLineData [lineageDataEntryCount-1][counter2] = arrayIFTimeLineDataTemp [counter2];
                                    }
                                    
                                    //for (int counterA = 0; counterA < ifTimeLineDataTempCount/6; counterA++){
                                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayIFTimeLineData [lineageDataEntryCount-1][counterA*6+counterB];
                                    //    cout<<" arrayIFTimeLineData "<<counterA<<endl;
                                    //}
                                    
                                    imageDisplayPath4 = imageDisplayPath3+"/"+"IFTimeLineEntry";
                                    
                                    fin.open(imageDisplayPath4.c_str(), ios::in);
                                    
                                    if (fin.is_open()){
                                        getline(fin, getString);
                                        
                                        arrayIFTimeLineDataEntryHold [lineageDataEntryCount-1] = atoi(getString.c_str());
                                        
                                        fin.close();
                                    }
                                    
                                    for (int counter2 = 0; counter2 < tableMainTempCount; counter2++){
                                        arrayTableMain [lineageDataEntryCount-1][counter2] = arrayTableMainTemp [counter2];
                                    }
                                    
                                    arrayTableMain [lineageDataEntryCount-1][0] = to_string(lineageDataEntryCount);
                                    
                                    //for (int counterA = 0; counterA < 1; counterA++){
                                    //    for (int counterB = 0; counterB < tableMainTempCount; counterB++) cout<<" "<< arrayTableMain [lineageDataEntryCount-1][counterA+counterB];
                                    //    cout<<" arrayTableMain "<<counterA<<endl;
                                    //}
                                    
                                    imageDisplayPath4 = imageDisplayPath3+"/"+"MainTableEntry";
                                    
                                    fin.open(imageDisplayPath4.c_str(), ios::in);
                                    
                                    if (fin.is_open()){
                                        getline(fin, getString);
                                        
                                        arrayTableMainHold [lineageDataEntryCount-1] = atoi(getString.c_str());
                                        
                                        fin.close();
                                    }
                                    
                                    imageDisplayPath4 = imageDisplayPath3+"/"+"DetailTable";
                                    
                                    fin.open(imageDisplayPath4.c_str(), ios::in);
                                    
                                    if (fin.is_open()){
                                        getline(fin, getString);
                                        arrayTableDetail [lineageDataEntryCount-1][0] = lineageDataEntryCount;
                                        getline(fin, getString);
                                        arrayTableDetail [lineageDataEntryCount-1][1] = atoi(getString.c_str());
                                        getline(fin, getString);
                                        arrayTableDetail [lineageDataEntryCount-1][2] = atoi(getString.c_str());
                                        getline(fin, getString);
                                        arrayTableDetail [lineageDataEntryCount-1][3] = atoi(getString.c_str());
                                        getline(fin, getString);
                                        arrayTableDetail [lineageDataEntryCount-1][4] = atoi(getString.c_str());
                                        getline(fin, getString);
                                        arrayTableDetail [lineageDataEntryCount-1][5] = atoi(getString.c_str());
                                        getline(fin, getString);
                                        arrayTableDetail [lineageDataEntryCount-1][6] = atoi(getString.c_str());
                                        getline(fin, getString);
                                        arrayTableDetail [lineageDataEntryCount-1][7] = atoi(getString.c_str());
                                        getline(fin, getString);
                                        arrayTableDetail [lineageDataEntryCount-1][8] = atoi(getString.c_str());
                                        getline(fin, getString);
                                        arrayTableDetail [lineageDataEntryCount-1][9] = atoi(getString.c_str());
                                        getline(fin, getString);
                                        arrayTableDetail [lineageDataEntryCount-1][10] = atoi(getString.c_str());
                                        getline(fin, getString);
                                        arrayTableDetail [lineageDataEntryCount-1][11] = atoi(getString.c_str());
                                        getline(fin, getString);
                                        arrayTableDetail [lineageDataEntryCount-1][12] = atoi(getString.c_str());
                                        getline(fin, getString);
                                        arrayTableDetail [lineageDataEntryCount-1][13] = atoi(getString.c_str());
                                        getline(fin, getString);
                                        arrayTableDetail [lineageDataEntryCount-1][14] = atoi(getString.c_str());
                                        getline(fin, getString);
                                        arrayTableDetail [lineageDataEntryCount-1][15] = atoi(getString.c_str());
                                        getline(fin, getString);
                                        arrayTableDetail [lineageDataEntryCount-1][16] = atoi(getString.c_str());
                                        
                                        fin.close();
                                    }
                                    
                                    imageDisplayPath4 = imageDisplayPath3+"/*LineageDataAddition.dat";
                                    
                                    fin.open(imageDisplayPath4.c_str(), ios::in);
                                    
                                    if (fin.is_open()){
                                        getline(fin, getString);
                                        arrayLineageDataType [lineageDataEntryCount-1][0] = to_string(lineageDataEntryCount);
                                        getline(fin, getString);
                                        arrayLineageDataType [lineageDataEntryCount-1][1] = getString;
                                        getline(fin, getString);
                                        arrayLineageDataType [lineageDataEntryCount-1][2] = getString;
                                        getline(fin, getString);
                                        arrayLineageDataType [lineageDataEntryCount-1][3] = getString;
                                        getline(fin, getString);
                                        arrayLineageDataType [lineageDataEntryCount-1][4] = getString;
                                        getline(fin, getString);
                                        arrayLineageDataType [lineageDataEntryCount-1][5] = getString;
                                        getline(fin, getString);
                                        arrayLineageDataType [lineageDataEntryCount-1][6] = getString;
                                        
                                        do{
                                            
                                            terminationFlag = 1;
                                            
                                            if (lineageFluorescentDataTypeEntryCount+9 > lineageFluorescentDataTypeEntryLimit) [self lineageFluorescentDataTypeUpDate];
                                            
                                            getline(fin, getString);
                                            
                                            if (getString == "") terminationFlag = 0;
                                            else{
                                                
                                                arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][0] = to_string(lineageDataEntryCount);
                                                getline(fin, getString);
                                                arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][1] = getString;
                                                getline(fin, getString);
                                                arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][2] = getString;
                                                getline(fin, getString);
                                                arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][3] = getString;
                                                getline(fin, getString);
                                                arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][4] = getString;
                                                getline(fin, getString);
                                                arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][5] = getString;
                                                getline(fin, getString);
                                                arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][6] = getString;
                                                getline(fin, getString);
                                                arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][7] = getString;
                                                
                                                lineageFluorescentDataTypeEntryCount++;
                                            }
                                            
                                        } while (terminationFlag == 1);
                                        
                                        fin.close();
                                    }
                                    
                                    //for (int counterA = 0; counterA < lineageDataEntryCount; counterA++){
                                    //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayLineageDataType [counterA][counterB];
                                    //    cout<<" arrayLineageDataType "<<counterA+1<<endl;
                                    //}
                                    
                                    //for (int counterA = 0; counterA < lineageFluorescentDataTypeEntryCount; counterA++){
                                    //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageFluorescentDataType [counterA][counterB];
                                    //    cout<<" arrayLineageFluorescentDataType "<<counterA+1<<endl;
                                    //}
                                    
                                    imageDisplayPath4 = imageDisplayPath3+"/"+"IFDataStatus";
                                    
                                    fin.open(imageDisplayPath4.c_str(), ios::in);
                                    
                                    if (fin.is_open()){
                                        ifStatusEntryCount = 0;
                                        
                                        do{
                                            
                                            terminationFlag = 1;
                                            
                                            getline(fin, getString);
                                            
                                            if (getString != "") arrayIfTimeStatus [lineageDataEntryCount-1][ifStatusEntryCount] = atoi(getString.c_str()), ifStatusEntryCount++;
                                            else terminationFlag = 0;
                                            
                                        } while (terminationFlag == 1);
                                        
                                        fin.close();
                                    }
                                    
                                    imageDisplayPath4 = imageDisplayPath3+"/"+"IFDataStatusEntry";
                                    
                                    fin.open(imageDisplayPath4.c_str(), ios::in);
                                    
                                    if (fin.is_open()){
                                        getline(fin, getString);
                                        
                                        arrayIfTimeStatusHold [lineageDataEntryCount-1] = atoi(getString.c_str());
                                        
                                        fin.close();
                                    }
                                    
                                    imageDisplayPath4 = imageDisplayPath3+"/"+"AreaData";
                                    
                                    fin.open(imageDisplayPath4.c_str(), ios::in);
                                    
                                    if (fin.is_open()){
                                        ifStatusEntryCount = 0;
                                        
                                        do{
                                            
                                            terminationFlag = 1;
                                            
                                            getline(fin, getString);
                                            
                                            if (getString != "") arrayAreaData [lineageDataEntryCount-1][ifStatusEntryCount] = atoi(getString.c_str()), ifStatusEntryCount++;
                                            else terminationFlag = 0;
                                            
                                        } while (terminationFlag == 1);
                                        
                                        fin.close();
                                    }
                                    
                                    imageDisplayPath4 = imageDisplayPath3+"/"+"AreaDataEntry";
                                    
                                    fin.open(imageDisplayPath4.c_str(), ios::in);
                                    
                                    if (fin.is_open()){
                                        getline(fin, getString);
                                        
                                        arrayAreaDataHold [lineageDataEntryCount-1] = atoi(getString.c_str());
                                        
                                        fin.close();
                                    }
                                    
                                    imageDisplayPath4 = imageDisplayPath3+"/"+"LinkData";
                                    
                                    fin.open(imageDisplayPath4.c_str(), ios::in);
                                    
                                    if (fin.is_open()){
                                        ifStatusEntryCount = 0;
                                        
                                        do{
                                            
                                            terminationFlag = 1;
                                            
                                            getline(fin, getString);
                                            
                                            if (getString != "") arrayLineageLink [lineageDataEntryCount-1][ifStatusEntryCount] = atoi(getString.c_str()), ifStatusEntryCount++;
                                            else terminationFlag = 0;
                                            
                                        } while (terminationFlag == 1);
                                        
                                        fin.close();
                                    }
                                    
                                    imageDisplayPath4 = imageDisplayPath3+"/"+"LinkDataEntry";
                                    
                                    fin.open(imageDisplayPath4.c_str(), ios::in);
                                    
                                    if (fin.is_open()){
                                        getline(fin, getString);
                                        
                                        lineageLinkHold [lineageDataEntryCount-1] = atoi(getString.c_str());
                                        
                                        fin.close();
                                    }
                                }
                                
                                if (initialArraySet == 0) initialArraySet = 1;
                                
                                delete [] arrayLineageDataTemp;
                                delete [] arrayIFDataMainTemp;
                                delete [] arrayTableMainTemp;
                                delete [] arrayIFTimeLineDataTemp;
                            }
                        }
                    }
                }
                
                closedir(dir3);
            }
        }
        
        upLoadingFlag = 1;
        
        if (lineageOpen == 1 && lineageWindowOperation != 2) lineageListCall = 1;
        if (growthCurveOpen == 1 && growthCurveWindowOperation != 2) growthCurveCall = 1;
        if (cellDivisionOpen == 1 && cellDivisionWindowOperation != 2) cellDivisionCall = 1; //========ADD POINT
        if (doublingTimeOpen == 1 && doublingTimeWindowOperation != 2) doublingTimeCall = 1;
        if (trimOpen == 1 && trimWindowOperation != 2) trimCall = 1;
        if (lineageSelectOpen == 1 && lineageSelectWindowOperation != 2) lineageSelectCall = 1;
        if (simulationOpen == 1 && simulationOperation != 2) simulationCall = 1;
    }
}

-(void)lineageFluorescentDataTypeUpDate{
    string **arrayLineageFluorescentDataTypeTemp = new string *[lineageFluorescentDataTypeEntryLimit];
    
    for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryLimit; counter1++){
        arrayLineageFluorescentDataTypeTemp [counter1] = new string [9];
    }
    
    int lineageFluorescentDataTypeEntryLimitTemp = lineageFluorescentDataTypeEntryLimit;
    int lineageFluorescentEntryCount = 0;
    
    for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryCount; counter1++){
        for (int counter2 = 0; counter2 < 8; counter2++){
            arrayLineageFluorescentDataTypeTemp [lineageFluorescentEntryCount][counter2] = arrayLineageFluorescentDataType [counter1][counter2];
        }
        
        lineageFluorescentEntryCount++;
    }
    
    for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryLimit; counter1++){
        delete [] arrayLineageFluorescentDataType [counter1];
    }
    
    delete [] arrayLineageFluorescentDataType;
    
    arrayLineageFluorescentDataType = new string *[lineageFluorescentDataTypeEntryLimit+320];
    
    for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryLimit+320; counter1++){
        arrayLineageFluorescentDataType [counter1] = new string [9];
    }
    
    lineageFluorescentDataTypeEntryLimit = lineageFluorescentDataTypeEntryLimit+320;
    lineageFluorescentDataTypeEntryCount = 0;
    
    for (int counter1 = 0; counter1 < lineageFluorescentEntryCount; counter1++){
        for (int counter2 = 0; counter2 < 8; counter2++){
            arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][counter2] = arrayLineageFluorescentDataTypeTemp [counter1][counter2];
        }
        
        lineageFluorescentDataTypeEntryCount++;
    }
    
    for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryLimitTemp; counter1++){
        delete [] arrayLineageFluorescentDataTypeTemp [counter1];
    }
    
    delete [] arrayLineageFluorescentDataTypeTemp;
}

-(void)fileDeleteUpDate{
    string *arrayUpDate = new string [fileDeleteCount+10];
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayUpDate [counter1] = arrayFileDelete [counter1];
    
    delete [] arrayFileDelete;
    arrayFileDelete = new string [fileDeleteLimit+500];
    fileDeleteLimit = fileDeleteLimit+500;
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayFileDelete [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

@end
