//
//  CellGrowthCurveAddition.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 12/14/16.
//
//

#import "CellGrowthCurveAddition.h"

NSString *notificationToGrowthCurveAddition = @"notificationExecuteGrowthCurveAddition";

@implementation CellGrowthCurveAddition

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToGrowthCurveAddition object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    [verticalLow setIntegerValue:verticalScaleLowHold];
    [verticalHigh setIntegerValue:verticalScaleHighHold];
    [horizontalLow setIntegerValue:horizontalScaleLowHold];
    [horizontalHigh setIntegerValue:horizontalScaleHighHold];
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToGrowthCurveAddition object:nil];
}

@end
