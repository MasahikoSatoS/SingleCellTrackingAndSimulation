//
//  MotilityController.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2018-03-06.
//
//

#ifndef MOTILITYCONTROLLER_H
#define MOTILITYCONTROLLER_H
#import "Controller.h" 
#endif

@interface MotilityController : NSObject<NSTextFieldDelegate>{
    int selectCutLevelHold; //Cut level
    int selectCutLevelStatus; //Cut level status
    int selectTypeStatus; //Select type
    
    IBOutlet NSTextField *lineColorDisplay;
    IBOutlet NSTextField *displayScaleDisplay;
    IBOutlet NSTextField *displayMaxDisplay;
    IBOutlet NSTextField *verticalStartDisplay;
    IBOutlet NSTextField *horizontalStartDisplay;
    IBOutlet NSTextField *timeStartDisplay;
    IBOutlet NSTextField *timeEndDisplay;
    IBOutlet NSTextField *tableModeDisplay;
    IBOutlet NSTextField *stepperMotilityDisplay;
    IBOutlet NSTextField *stepperMarkerStartDisplay;
    IBOutlet NSTextField *stepperMarkerEndDisplay;
    IBOutlet NSTextField *stepperMarkerMidDisplay;
    IBOutlet NSTextField *markerMidValueDisplay;
    IBOutlet NSTextField *activationPointDisplay;
    IBOutlet NSTextField *displayStatusDisplay;
    IBOutlet NSTextField *fixSizeDisplay;
    IBOutlet NSTextField *cutLevelDisplay;
    IBOutlet NSTextField *cutLevelStatusDisplay;
    IBOutlet NSTextField *cutLevelTypeDisplay;
    IBOutlet NSTextField *shiftXDisplay;
    IBOutlet NSTextField *shiftYDisplay;
    IBOutlet NSTextField *lineWidthSetDisplay;
    IBOutlet NSTextField *lineWidthSetWindowDisplay;
    
    IBOutlet NSStepper *stepperMotilityColor;
    IBOutlet NSStepper *stepperMarkerStartColor;
    IBOutlet NSStepper *stepperMarkerEndColor;
    IBOutlet NSStepper *stepperMarkerMidColor;
    
    IBOutlet NSWindow *motilityWindow;
    
    NSWindowController *mainWindowMotilityController;
    
    NSTimer *motilityTimer;
    
    id ascIIconversion;
}

-(id)init;
-(void)dealloc;
-(void)reDisplayWindow;

-(IBAction)closeWindow:(id)sender;
-(IBAction)stepperActionColor:(id)sender;
-(IBAction)stepperActionMarkerStartColor:(id)sender;
-(IBAction)stepperActionMarkerEndColor:(id)sender;
-(IBAction)stepperActionMarkerMidColor:(id)sender;
-(IBAction)lineColorSelect:(id)sender;
-(IBAction)tableCategorySelect:(id)sender;
-(IBAction)analysisStart:(id)sender;
-(IBAction)activationPoint:(id)sender;
-(IBAction)displayOptionSet:(id)sender;
-(IBAction)createExcelFile:(id)sender;
-(IBAction)createExcelFile2:(id)sender;
-(IBAction)fixSizeSet:(id)sender;
-(IBAction)cutLevelSet:(id)sender;
-(IBAction)cutTypeSet:(id)sender;
-(IBAction)lineWidthSet:(id)sender;
-(IBAction)lineWidthDisplaySet:(id)sender;

@end
