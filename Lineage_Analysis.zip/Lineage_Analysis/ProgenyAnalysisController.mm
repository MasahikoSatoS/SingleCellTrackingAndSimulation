//
//  ProgenyAnalysisController.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2017-05-22.
//
//

#import "ProgenyAnalysisController.h"

NSString *notificationToProgenyAnalysisController = @"notificationExecuteProgenyAnalysisController";

@implementation ProgenyAnalysisController

-(id)init{
    self = [super init];
    
    if (self != nil){
        progenyAnalysisTimeEd1Hold = 500;
        progenyAnalysisTimeEd2Hold = 500;
        progenyAnalysisRangeHold = 10;
        progenyAnalysisGroupHold = 5;
        progenyAnalysisZeroInclude = 0;
        sdCalculationHold = 0;
        percentMode = 1;
        normalizeHold = 100;
        progenyOfMDInclude = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToProgenyAnalysisController object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    progenyAnalysisProgenyWindowController = [[NSWindowController alloc] initWithWindowNibName:@"ProgenyAnalysis"];
    [progenyAnalysisProgenyWindowController showWindow:self];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToProgenyAnalysisTable object:self];
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToProgenyAnalysisTable2 object:self];
}

- (void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [progenyAnalysisProgenyWindow frame];
    CGFloat windowHeight = windowSize.size.height;
    
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [progenyAnalysisProgenyWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    [progenyAnalysisTimeEd1Display setDelegate:self];
    [progenyAnalysisTimeEd2Display setDelegate:self];
    [progenyAnalysisRangeDisplay setDelegate:self];
    [progenyAnalysisGroupDisplay setDelegate:self];
    [normalizeDisplay setDelegate:self];
    
    [progenyAnalysisTimeEd1Display setStringValue:@"500"];
    [progenyAnalysisTimeEd2Display setStringValue:@"500"];
    [normalizeDisplay setStringValue:@"100"];
    
    [progenyAnalysisRangeDisplay setStringValue:@"10"];
    [progenyAnalysisGroupDisplay setStringValue:@"5"];
    [zeroIncludeDisplay setStringValue:@"No"];
    [sdModeDisplay setStringValue:@"No"];
}

-(void)controlTextDidChange:(NSNotification *)aNotification{
    if ([[aNotification name] isEqualToString:@"NSControlTextDidChangeNotification"]){
        if ([aNotification object] == progenyAnalysisTimeEd1Display){
            int maxTimeFind = 0;
            
            for (int counter1 = 0; counter1 < lineageDataEntryCount; counter1++){
                if (arraySelectedLing [counter1] == 1){
                    if (maxTimeFind < arrayTableDetail [counter1][3]) maxTimeFind = arrayTableDetail [counter1][3];
                }
            }
            
            if (maxTimeFind > 200 && [progenyAnalysisTimeEd1Display intValue] >= 100 && [progenyAnalysisTimeEd1Display intValue] < maxTimeFind-100){
                progenyAnalysisTimeEd1Hold = [progenyAnalysisTimeEd1Display intValue];
            }
        }
        
        if ([aNotification object] == progenyAnalysisTimeEd2Display){
            int maxTimeFind = 0;
            
            for (int counter1 = 0; counter1 < lineageDataEntryCount; counter1++){
                if (arraySelectedLing [counter1] == 1){
                    if (maxTimeFind < arrayTableDetail [counter1][3]) maxTimeFind = arrayTableDetail [counter1][3];
                }
            }
            
            if (maxTimeFind > 200 && [progenyAnalysisTimeEd2Display intValue] >= 100 && [progenyAnalysisTimeEd2Display intValue] <= maxTimeFind){
                progenyAnalysisTimeEd2Hold = [progenyAnalysisTimeEd2Display intValue];
            }
        }
        
        if ([aNotification object] == progenyAnalysisRangeDisplay){
            if ([progenyAnalysisRangeDisplay intValue] >= 1 && [progenyAnalysisRangeDisplay intValue] < 100000){
                progenyAnalysisRangeHold = [progenyAnalysisRangeDisplay intValue];
                
                progenyAnalysisRangeHoldCount = 0;
                
                if (progenyAnalysisZeroInclude == 0){
                    arrayProgenyAnalysisRangeHold [0] = 1, progenyAnalysisRangeHoldCount++;
                    arrayProgenyAnalysisRangeHold [1] = 0, progenyAnalysisRangeHoldCount++;
                    arrayProgenyAnalysisRangeHold [2] = 0, progenyAnalysisRangeHoldCount++;
                    
                    int rangeStart = 1;
                    int rangeEnd = progenyAnalysisRangeHold;
                    int rangeIncrement = 0;
                    
                    for (int counter1 = 1; counter1 <= progenyAnalysisGroupHold; counter1++){
                        arrayProgenyAnalysisRangeHold [counter1*3] = counter1+1, progenyAnalysisRangeHoldCount++;
                        arrayProgenyAnalysisRangeHold [counter1*3+1] = rangeStart+rangeIncrement, progenyAnalysisRangeHoldCount++;
                        arrayProgenyAnalysisRangeHold [counter1*3+2] = rangeEnd+rangeIncrement, progenyAnalysisRangeHoldCount++;
                        
                        rangeIncrement = rangeIncrement+progenyAnalysisRangeHold;
                    }
                    
                    arrayProgenyAnalysisRangeHold [progenyAnalysisRangeHoldCount] = progenyAnalysisGroupHold+2, progenyAnalysisRangeHoldCount++;
                    arrayProgenyAnalysisRangeHold [progenyAnalysisRangeHoldCount] = rangeEnd+rangeIncrement-progenyAnalysisRangeHold+1, progenyAnalysisRangeHoldCount++;
                    arrayProgenyAnalysisRangeHold [progenyAnalysisRangeHoldCount] = 100000000, progenyAnalysisRangeHoldCount++;
                }
                else{
                    
                    int rangeStart = 0;
                    int rangeEnd = progenyAnalysisRangeHold-1;
                    int rangeIncrement = 0;
                    
                    for (int counter1 = 1; counter1 <= progenyAnalysisGroupHold; counter1++){
                        arrayProgenyAnalysisRangeHold [(counter1-1)*3] = counter1, progenyAnalysisRangeHoldCount++;
                        arrayProgenyAnalysisRangeHold [(counter1-1)*3+1] = rangeStart+rangeIncrement, progenyAnalysisRangeHoldCount++;
                        arrayProgenyAnalysisRangeHold [(counter1-1)*3+2] = rangeEnd+rangeIncrement, progenyAnalysisRangeHoldCount++;
                        
                        rangeIncrement = rangeIncrement+progenyAnalysisRangeHold;
                    }
                    
                    arrayProgenyAnalysisRangeHold [progenyAnalysisRangeHoldCount] = progenyAnalysisGroupHold+1, progenyAnalysisRangeHoldCount++;
                    arrayProgenyAnalysisRangeHold [progenyAnalysisRangeHoldCount] = rangeEnd+rangeIncrement-progenyAnalysisRangeHold+1, progenyAnalysisRangeHoldCount++;
                    arrayProgenyAnalysisRangeHold [progenyAnalysisRangeHoldCount] = 100000000, progenyAnalysisRangeHoldCount++;
                }
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToProgenyAnalysisTable2 object:self];
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        
        if ([aNotification object] == progenyAnalysisGroupDisplay){
            if ([progenyAnalysisGroupDisplay intValue] >= 3 && [progenyAnalysisGroupDisplay intValue] < 100){
                progenyAnalysisGroupHold = [progenyAnalysisGroupDisplay intValue];
                
                progenyAnalysisRangeHoldCount = 0;
                
                if (progenyAnalysisZeroInclude == 0){
                    int rangeStart = 1;
                    int rangeEnd = progenyAnalysisRangeHold;
                    int rangeIncrement = 0;
                    
                    for (int counter1 = 1; counter1 <= progenyAnalysisGroupHold; counter1++){
                        arrayProgenyAnalysisRangeHold [counter1*3] = counter1+1, progenyAnalysisRangeHoldCount++;
                        arrayProgenyAnalysisRangeHold [counter1*3+1] = rangeStart+rangeIncrement, progenyAnalysisRangeHoldCount++;
                        arrayProgenyAnalysisRangeHold [counter1*3+2] = rangeEnd+rangeIncrement, progenyAnalysisRangeHoldCount++;
                        
                        rangeIncrement = rangeIncrement+progenyAnalysisRangeHold;
                    }
                    
                    arrayProgenyAnalysisRangeHold [progenyAnalysisRangeHoldCount] = progenyAnalysisGroupHold+1, progenyAnalysisRangeHoldCount++;
                    arrayProgenyAnalysisRangeHold [progenyAnalysisRangeHoldCount] = rangeEnd+rangeIncrement-progenyAnalysisRangeHold*2+1, progenyAnalysisRangeHoldCount++;
                    arrayProgenyAnalysisRangeHold [progenyAnalysisRangeHoldCount] = 100000000, progenyAnalysisRangeHoldCount++;
                }
                else{
                    
                    int rangeStart = 0;
                    int rangeEnd = progenyAnalysisRangeHold-1;
                    int rangeIncrement = 0;
                    
                    for (int counter1 = 1; counter1 <= progenyAnalysisGroupHold; counter1++){
                        arrayProgenyAnalysisRangeHold [(counter1-1)*3] = counter1, progenyAnalysisRangeHoldCount++;
                        arrayProgenyAnalysisRangeHold [(counter1-1)*3+1] = rangeStart+rangeIncrement, progenyAnalysisRangeHoldCount++;
                        arrayProgenyAnalysisRangeHold [(counter1-1)*3+2] = rangeEnd+rangeIncrement, progenyAnalysisRangeHoldCount++;
                        
                        rangeIncrement = rangeIncrement+progenyAnalysisRangeHold;
                    }
                    
                    arrayProgenyAnalysisRangeHold [progenyAnalysisRangeHoldCount] = progenyAnalysisGroupHold+1, progenyAnalysisRangeHoldCount++;
                    arrayProgenyAnalysisRangeHold [progenyAnalysisRangeHoldCount] = rangeEnd+rangeIncrement-progenyAnalysisRangeHold+1, progenyAnalysisRangeHoldCount++;
                    arrayProgenyAnalysisRangeHold [progenyAnalysisRangeHoldCount] = 100000000, progenyAnalysisRangeHoldCount++;
                }
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToProgenyAnalysisTable2 object:self];
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        
        if ([aNotification object] == normalizeDisplay){
            if ([normalizeDisplay intValue] >= 100 && [normalizeDisplay intValue] < 1000000){
                normalizeHold = [normalizeDisplay intValue];
            }
        }
    }
}

-(IBAction)zeroStatusHold:(id)sender{
    if (lineageDataEntryCount != 0){
        if (progenyAnalysisZeroInclude == 0){
            progenyAnalysisZeroInclude = 1;
            progenyAnalysisRangeHoldCount = 0;
            
            int rangeStart = 0;
            int rangeEnd = progenyAnalysisRangeHold-1;
            int rangeIncrement = 0;
            
            for (int counter1 = 1; counter1 <= progenyAnalysisGroupHold; counter1++){
                arrayProgenyAnalysisRangeHold [(counter1-1)*3] = counter1, progenyAnalysisRangeHoldCount++;
                arrayProgenyAnalysisRangeHold [(counter1-1)*3+1] = rangeStart+rangeIncrement, progenyAnalysisRangeHoldCount++;
                arrayProgenyAnalysisRangeHold [(counter1-1)*3+2] = rangeEnd+rangeIncrement, progenyAnalysisRangeHoldCount++;
                
                rangeIncrement = rangeIncrement+progenyAnalysisRangeHold;
            }
            
            arrayProgenyAnalysisRangeHold [progenyAnalysisRangeHoldCount] = progenyAnalysisGroupHold+2, progenyAnalysisRangeHoldCount++;
            arrayProgenyAnalysisRangeHold [progenyAnalysisRangeHoldCount] = rangeEnd+rangeIncrement-progenyAnalysisRangeHold+1, progenyAnalysisRangeHoldCount++;
            arrayProgenyAnalysisRangeHold [progenyAnalysisRangeHoldCount] = 100000000, progenyAnalysisRangeHoldCount++;
            
            [zeroIncludeDisplay setStringValue:@"Yes"];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToProgenyAnalysisTable2 object:self];
        }
        else{
            
            progenyAnalysisZeroInclude = 0;
            progenyAnalysisRangeHoldCount = 0;
            
            arrayProgenyAnalysisRangeHold [0] = 1, progenyAnalysisRangeHoldCount++;
            arrayProgenyAnalysisRangeHold [1] = 0, progenyAnalysisRangeHoldCount++;
            arrayProgenyAnalysisRangeHold [2] = 0, progenyAnalysisRangeHoldCount++;
            
            int rangeStart = 1;
            int rangeEnd = progenyAnalysisRangeHold;
            int rangeIncrement = 0;
            
            for (int counter1 = 1; counter1 <= progenyAnalysisGroupHold; counter1++){
                arrayProgenyAnalysisRangeHold [counter1*3] = counter1+1, progenyAnalysisRangeHoldCount++;
                arrayProgenyAnalysisRangeHold [counter1*3+1] = rangeStart+rangeIncrement, progenyAnalysisRangeHoldCount++;
                arrayProgenyAnalysisRangeHold [counter1*3+2] = rangeEnd+rangeIncrement, progenyAnalysisRangeHoldCount++;
                
                rangeIncrement = rangeIncrement+progenyAnalysisRangeHold;
            }
            
            arrayProgenyAnalysisRangeHold [progenyAnalysisRangeHoldCount] = progenyAnalysisGroupHold+2, progenyAnalysisRangeHoldCount++;
            arrayProgenyAnalysisRangeHold [progenyAnalysisRangeHoldCount] = rangeEnd+rangeIncrement-progenyAnalysisRangeHold+1, progenyAnalysisRangeHoldCount++;
            arrayProgenyAnalysisRangeHold [progenyAnalysisRangeHoldCount] = 100000000, progenyAnalysisRangeHoldCount++;
            
            [zeroIncludeDisplay setStringValue:@"No"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToProgenyAnalysisTable2 object:self];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)analysisStart:(id)sender{
    if (lineageDataEntryCount != 0){
        [self analysisSet];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToProgenyAnalysisTable object:self];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)analysisSet{
    progenyAnalysisResultsHoldCount = 0;
    
    int lineageEntryNo = 0;
    unsigned long lineageEntrySize = 0;
    int totalEventCount = 0;
    int totalEventDGCount = 0;
    int totalEventDGPModeCount = 0;
    int percentEventIntCount = 0;
    int lineageProcessCount = 0;
    double percentEventCount = 0;
    
    string percentString;
    
    for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
        if (arraySelectedLing [counter2] == 1) lineageProcessCount++;
    }
    
    if (sdCalculationHold == 0 || (sdCalculationHold == 1 && lineageProcessCount < 3)){
        int lineageExtractProgenyCount = 0;
        int numberOfToalCells = 0;
        int firstCellGroupCount = 0;
        int firstRangeCount = 0;
        int terminationFlag = 0;
        int chasingCellPosition = 0;
        int endFindFlag = 0;
        int findCellCount = 0;
        int secondCellGroupCount = 0;
        int firstCellGroupListCount = 0;
        int daughterCellListCount = 0;
        int grandDaughterCellListCount = 0;
        int gdFirstDivisionTime = 0;
        int endFindCheck = 0;
        
        for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
            if (arraySelectedLing [counter2] == 1){
                
                //for (int counterA = 0; counterA < 1; counterA++){
                //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<< arrayTableMain [counter2][counterA+counterB];
                //    cout<<"  arrayTableMain "<<counterA<<endl;
                //}
                
                lineageEntrySize = arrayLineageDataEntryHold [counter2];
                lineageEntryNo = 0;
                
                int *lineageExtractProgeny = new int [lineageEntrySize+10];
                
                for (unsigned long counter3 = 0; counter3 < lineageEntrySize/9; counter3++){
                    if (arrayLineageData [counter2][counter3*9+6] > lineageEntryNo){
                        lineageEntryNo = arrayLineageData [counter2][counter3*9+6];
                    }
                }
                
                int *lineageList = new int [lineageEntryNo+10];
                
                for (int counter3 = 0; counter3 < lineageEntryNo; counter3++) lineageList [counter3] = 0;
                
                for (unsigned long counter3 = 0; counter3 < lineageEntrySize/9; counter3++){
                    lineageList [arrayLineageData [counter2][counter3*9+6]] = 1;
                }
                
                //for (int counterA = 0; counterA < lineageEntryNo; counterA++){
                //    cout<<counterA<<" "<<lineageList [counterA] <<" lineageList"<<endl;
                //}
                
                int *progenyAnalysisSort = new int [progenyAnalysisRangeHoldCount/3+10];
                
                for (int counter3 = 0; counter3 < progenyAnalysisRangeHoldCount/3+10; counter3++) progenyAnalysisSort [counter3] = 0;
                
                int *progenyAnalysisDGSort = new int [(progenyAnalysisRangeHoldCount/3)*(progenyAnalysisRangeHoldCount/3)+10];
                
                for (int counter3 = 0; counter3 < (progenyAnalysisRangeHoldCount/3)*(progenyAnalysisRangeHoldCount/3)+10; counter3++) progenyAnalysisDGSort [counter3] = 0;
                
                for (int counter3 = 1; counter3 <= lineageEntryNo; counter3++){
                    if (lineageList [counter3] == 1){
                        lineageExtractProgenyCount = 0;
                        numberOfToalCells = 0;
                        
                        for (unsigned long counter4 = 0; counter4 < lineageEntrySize/9; counter4++){
                            if (arrayLineageData [counter2][counter4*9+6] == counter3){
                                lineageExtractProgeny [lineageExtractProgenyCount] = arrayLineageData [counter2][counter4*9], lineageExtractProgenyCount++;
                                lineageExtractProgeny [lineageExtractProgenyCount] = arrayLineageData [counter2][counter4*9+1], lineageExtractProgenyCount++;
                                lineageExtractProgeny [lineageExtractProgenyCount] = arrayLineageData [counter2][counter4*9+2], lineageExtractProgenyCount++;
                                lineageExtractProgeny [lineageExtractProgenyCount] = arrayLineageData [counter2][counter4*9+3], lineageExtractProgenyCount++;
                                lineageExtractProgeny [lineageExtractProgenyCount] = arrayLineageData [counter2][counter4*9+4], lineageExtractProgenyCount++;
                                lineageExtractProgeny [lineageExtractProgenyCount] = arrayLineageData [counter2][counter4*9+5], lineageExtractProgenyCount++;
                                lineageExtractProgeny [lineageExtractProgenyCount] = arrayLineageData [counter2][counter4*9+6], lineageExtractProgenyCount++;
                                lineageExtractProgeny [lineageExtractProgenyCount] = arrayLineageData [counter2][counter4*9+7], lineageExtractProgenyCount++;
                                
                                if (arrayLineageData [counter2][counter4*9+3] == 1 || arrayLineageData [counter2][counter4*9+3] == 31 || arrayLineageData [counter2][counter4*9+3] == 41 || arrayLineageData [counter2][counter4*9+3] == 51){
                                    numberOfToalCells++;
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < lineageExtractProgenyCount/8; counterA++){
                        //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lineageExtractProgeny [counterA*8+counterB];
                        //    cout<<" lineageExtractProgeny "<<counterA<<endl;
                        //}
                        
                        int *firstCellGroup = new int [numberOfToalCells+10];
                        firstCellGroupCount = 0;
                        firstRangeCount = 0;
                        
                        if (progenyOfMDInclude == 1){
                            for (int counter4 = 0; counter4 < lineageExtractProgenyCount/8; counter4++){
                                if (lineageExtractProgeny [counter4*8+2] == progenyAnalysisTimeEd1Hold){
                                    firstCellGroup [firstCellGroupCount] = lineageExtractProgeny [counter4*8+5], firstCellGroupCount++;
                                }
                            }
                        }
                        else{
                            
                            int *firstCellGroupList = new int [numberOfToalCells+10];
                            firstCellGroupListCount = 0;
                            
                            for (int counter4 = 0; counter4 < lineageExtractProgenyCount/8; counter4++){
                                if (lineageExtractProgeny [counter4*8+2] == progenyAnalysisTimeEd1Hold){
                                    firstCellGroupList [firstCellGroupListCount] = lineageExtractProgeny [counter4*8+5], firstCellGroupListCount++;
                                }
                            }
                            
                            //for (int counterA = 0; counterA < firstCellGroupListCount; counterA++){
                            //    cout<<counterA<<" "<<firstCellGroupList [counterA]<<" firstCellGroupList"<<endl;
                            //}
                            
                            for (int counter4 = 0; counter4 < firstCellGroupListCount; counter4++){
                                for (int counter5 = 0; counter5 < lineageExtractProgenyCount/8; counter5++){
                                    if (lineageExtractProgeny [counter5*8+3] == 31 && lineageExtractProgeny [counter5*8+5] == firstCellGroupList [counter4]){
                                        firstCellGroup [firstCellGroupCount] = firstCellGroupList [counter4], firstCellGroupCount++;
                                        break;
                                    }
                                }
                            }
                            
                            delete [] firstCellGroupList;
                        }
                        
                        //for (int counterA = 0; counterA < firstCellGroupCount; counterA++){
                        //    cout<<counterA<<" "<<firstCellGroup [counterA]<<" firstCellGroup"<<endl;
                        //}
                        
                        if (firstCellGroupCount != 0){
                            for (int counter4 = 0; counter4 < progenyAnalysisRangeHoldCount/3; counter4++){
                                if (firstCellGroupCount >= arrayProgenyAnalysisRangeHold [counter4*3+1] && firstCellGroupCount <= arrayProgenyAnalysisRangeHold [counter4*3+2]){
                                    progenyAnalysisSort [counter4]++;
                                    firstRangeCount = counter4;
                                    break;
                                }
                            }
                        }
                        else{
                            
                            progenyAnalysisSort [0]++;
                            firstRangeCount = 0;
                        }
                        
                        int *daughterCellList = new int [numberOfToalCells+10];
                        daughterCellListCount = 0;
                        
                        if (progenyOfMDInclude == 1){
                            for (int counter4 = 0; counter4 < lineageExtractProgenyCount/8; counter4++){
                                if ((lineageExtractProgeny [counter4*8+3] == 31 || lineageExtractProgeny [counter4*8+3] == 41 || lineageExtractProgeny [counter4*8+3] == 51) && lineageExtractProgeny [counter4*8+4] == 0){
                                    daughterCellList [daughterCellListCount] = lineageExtractProgeny [counter4*8+5], daughterCellListCount++;
                                }
                            }
                        }
                        else{
                            
                            for (int counter4 = 0; counter4 < lineageExtractProgenyCount/8; counter4++){
                                if (lineageExtractProgeny [counter4*8+3] == 31 && lineageExtractProgeny [counter4*8+4] == 0){
                                    daughterCellList [daughterCellListCount] = lineageExtractProgeny [counter4*8+5], daughterCellListCount++;
                                }
                            }
                        }
                        
                        int *grandDaughterCellList = new int [daughterCellListCount*4];
                        grandDaughterCellListCount = 0;
                        
                        if (progenyOfMDInclude == 1){
                            for (int counter4 = 0; counter4 < daughterCellListCount; counter4++){
                                for (int counter5 = 0; counter5 < lineageExtractProgenyCount/8; counter5++){
                                    if ((lineageExtractProgeny [counter5*8+3] == 31 || lineageExtractProgeny [counter5*8+3] == 41 || lineageExtractProgeny [counter5*8+3] == 51) && lineageExtractProgeny [counter5*8+4] == daughterCellList [counter4]){
                                        grandDaughterCellList [grandDaughterCellListCount] = lineageExtractProgeny [counter5*8+5], grandDaughterCellListCount++;
                                    }
                                }
                            }
                        }
                        else{
                            
                            for (int counter4 = 0; counter4 < daughterCellListCount; counter4++){
                                for (int counter5 = 0; counter5 < lineageExtractProgenyCount/8; counter5++){
                                    if (lineageExtractProgeny [counter5*8+3] == 31 && lineageExtractProgeny [counter5*8+4] == daughterCellList [counter4]){
                                        grandDaughterCellList [grandDaughterCellListCount] = lineageExtractProgeny [counter5*8+5], grandDaughterCellListCount++;
                                    }
                                }
                            }
                        }
                        
                        delete [] daughterCellList;
                        
                        int *secondCellGroup = new int [numberOfToalCells+10];
                        
                        for (int counter4 = 0; counter4 < grandDaughterCellListCount; counter4++){
                            for (int counter5 = 0; counter5 < numberOfToalCells+10; counter5++) secondCellGroup [counter5] = -1;
                            
                            secondCellGroupCount = 0;
                            gdFirstDivisionTime = 0;
                            
                            secondCellGroup [secondCellGroupCount] = grandDaughterCellList [counter4], secondCellGroupCount++;
                            
                            if (progenyOfMDInclude == 1){
                                for (int counter5 = 0; counter5 < lineageExtractProgenyCount/8; counter5++){
                                    if ((lineageExtractProgeny [counter5*8+3] == 32 || lineageExtractProgeny [counter5*8+3] == 42 || lineageExtractProgeny [counter5*8+3] == 52) && lineageExtractProgeny [counter5*8+5] == grandDaughterCellList [counter4]){
                                        gdFirstDivisionTime = lineageExtractProgeny [counter5*8+2];
                                        break;
                                    }
                                }
                            }
                            else{
                                
                                for (int counter5 = 0; counter5 < lineageExtractProgenyCount/8; counter5++){
                                    if (lineageExtractProgeny [counter5*8+3] == 32 && lineageExtractProgeny [counter5*8+5] == grandDaughterCellList [counter4]){
                                        gdFirstDivisionTime = lineageExtractProgeny [counter5*8+2];
                                        break;
                                    }
                                }
                            }
                            
                            if (gdFirstDivisionTime != 0){
                                findCellCount = 0;
                                
                                do{
                                    
                                    terminationFlag = 0;
                                    endFindFlag = 0;
                                    chasingCellPosition = -1;
                                    
                                    for (int counter5 = 0; counter5 < secondCellGroupCount; counter5++){
                                        if (secondCellGroup [counter5] != -1){
                                            terminationFlag = 1;
                                            chasingCellPosition = counter5;
                                            break;
                                        }
                                    }
                                    
                                    if (chasingCellPosition != -1){
                                        if (progenyOfMDInclude == 1){
                                            for (int counter5 = 0; counter5 < lineageExtractProgenyCount/8; counter5++){
                                                if (lineageExtractProgeny [counter5*8+5] == secondCellGroup [chasingCellPosition] && lineageExtractProgeny [counter5*8+2] == progenyAnalysisTimeEd2Hold+gdFirstDivisionTime){
                                                    secondCellGroup [chasingCellPosition] = -1;
                                                    endFindFlag = 1;
                                                    findCellCount++;
                                                }
                                            }
                                        }
                                        else{
                                            
                                            endFindCheck = 0;
                                            
                                            for (int counter5 = 0; counter5 < lineageExtractProgenyCount/8; counter5++){
                                                if (lineageExtractProgeny [counter5*8+5] == secondCellGroup [chasingCellPosition] && lineageExtractProgeny [counter5*8+2] == progenyAnalysisTimeEd2Hold+gdFirstDivisionTime){
                                                    endFindCheck = 1;
                                                    endFindFlag = 1;
                                                }
                                            }
                                            
                                            if (endFindCheck == 1){
                                                for (int counter5 = 0; counter5 < lineageExtractProgenyCount/8; counter5++){
                                                    if (lineageExtractProgeny [counter5*8+3] == 31 && lineageExtractProgeny [counter5*8+5] == secondCellGroup [chasingCellPosition]){
                                                        secondCellGroup [chasingCellPosition] = -1;
                                                        findCellCount++;
                                                        break;
                                                    }
                                                    else if ((lineageExtractProgeny [counter5*8+3] == 41 || lineageExtractProgeny [counter5*8+3] == 51) && lineageExtractProgeny [counter5*8+5] == secondCellGroup [chasingCellPosition]){
                                                        secondCellGroup [chasingCellPosition] = -1;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        if (endFindFlag == 0){
                                            for (int counter5 = 0; counter5 < lineageExtractProgenyCount/8; counter5++){
                                                if (lineageExtractProgeny [counter5*8+4] == secondCellGroup [chasingCellPosition] && (lineageExtractProgeny [counter5*8+3] == 31 || lineageExtractProgeny [counter5*8+3] == 41 || lineageExtractProgeny [counter5*8+3] == 51)){
                                                    secondCellGroup [secondCellGroupCount] = lineageExtractProgeny [counter5*8+5], secondCellGroupCount++;
                                                }
                                            }
                                            
                                            secondCellGroup [chasingCellPosition] = -1;
                                        }
                                    }
                                    
                                } while (terminationFlag == 1);
                                
                                if (findCellCount != 0){
                                    for (int counter5 = 0; counter5 < progenyAnalysisRangeHoldCount/3; counter5++){
                                        if (findCellCount >= arrayProgenyAnalysisRangeHold [counter5*3+1] && findCellCount <= arrayProgenyAnalysisRangeHold [counter5*3+2]){
                                            progenyAnalysisDGSort [firstRangeCount*(progenyAnalysisRangeHoldCount/3)+counter5]++;
                                            break;
                                        }
                                    }
                                }
                                else progenyAnalysisDGSort [firstRangeCount*(progenyAnalysisRangeHoldCount/3)]++;
                            }
                            else progenyAnalysisDGSort [firstRangeCount*(progenyAnalysisRangeHoldCount/3)] = 0;
                        }
                        
                        delete [] firstCellGroup;
                        delete [] secondCellGroup;
                        delete [] grandDaughterCellList;
                    }
                }
                
                totalEventCount = 0;
                
                for (int counter3 = 0; counter3 < progenyAnalysisRangeHoldCount/3; counter3++){
                    totalEventCount = totalEventCount+progenyAnalysisSort [counter3];
                }
                
                //for (int counterA = 0; counterA < (progenyAnalysisRangeHoldCount/3)*(progenyAnalysisRangeHoldCount/3); counterA++){
                //    cout<<counterA<<" "<<progenyAnalysisDGSort [counterA]<<" progenyAnalysisDGSort"<<endl;
                //}
                
                arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = arrayTableMain [counter2][2], progenyAnalysisResultsHoldCount++;
                arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = arrayTableMain [counter2][3], progenyAnalysisResultsHoldCount++;
                arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = arrayTableMain [counter2][4], progenyAnalysisResultsHoldCount++;
                arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "-1", progenyAnalysisResultsHoldCount++;
                arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "-1", progenyAnalysisResultsHoldCount++;
                arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "-1", progenyAnalysisResultsHoldCount++;
                
                for (int counter3 = 0; counter3 < progenyAnalysisRangeHoldCount/3; counter3++){
                    if (progenyAnalysisResultsHoldCount+30 > progenyAnalysisResultsHoldLimit){
                        string *arrayUpDate = new string [progenyAnalysisResultsHoldCount+30];
                        
                        for (int counter4 = 0; counter4 < progenyAnalysisResultsHoldCount; counter4++) arrayUpDate [counter4] = arrayProgenyAnalysisResultsHold [counter4];
                        
                        delete [] arrayProgenyAnalysisResultsHold;
                        arrayProgenyAnalysisResultsHold = new string [progenyAnalysisResultsHoldLimit+350*6+500];
                        progenyAnalysisResultsHoldLimit = progenyAnalysisResultsHoldLimit+350*6+500;
                        
                        for (int counter4 = 0; counter4 < progenyAnalysisResultsHoldCount; counter4++) arrayProgenyAnalysisResultsHold [counter4] = arrayUpDate [counter4];
                        delete [] arrayUpDate;
                    }
                    
                    if (arrayProgenyAnalysisRangeHold [counter3*3+1] == 0 && arrayProgenyAnalysisRangeHold [counter3*3+2] == 0){
                        arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "0", progenyAnalysisResultsHoldCount++;
                    }
                    else if (arrayProgenyAnalysisRangeHold [counter3*3+2] == 100000000) arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = ">="+to_string(arrayProgenyAnalysisRangeHold [counter3*3+1]), progenyAnalysisResultsHoldCount++;
                    else arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = to_string(arrayProgenyAnalysisRangeHold [counter3*3+1])+"-"+to_string(arrayProgenyAnalysisRangeHold [counter3*3+2]), progenyAnalysisResultsHoldCount++;
                    
                    arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = to_string(progenyAnalysisSort [counter3]), progenyAnalysisResultsHoldCount++;
                    
                    if (totalEventCount != 0) percentEventCount = progenyAnalysisSort [counter3]/(double)totalEventCount;
                    else percentEventCount = 0;
                    
                    percentEventIntCount = (int)(percentEventCount*100000);
                    percentEventCount = percentEventIntCount/(double)1000;
                    
                    stringstream extension1;
                    extension1 << percentEventCount;
                    percentString = extension1.str();
                    
                    arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = percentString, progenyAnalysisResultsHoldCount++;
                    
                    totalEventDGCount = 0;
                    totalEventDGPModeCount = 0;
                    
                    for (int counter4 = counter3*(progenyAnalysisRangeHoldCount/3); counter4 < counter3*(progenyAnalysisRangeHoldCount/3)+progenyAnalysisRangeHoldCount/3; counter4++){
                        totalEventDGCount = totalEventDGCount+progenyAnalysisDGSort [counter4];
                    }
                    
                    if (percentMode == 1){
                        for (int counter4 = 0; counter4 < (progenyAnalysisRangeHoldCount/3)*(progenyAnalysisRangeHoldCount/3); counter4++){
                            totalEventDGPModeCount = totalEventDGPModeCount+progenyAnalysisDGSort [counter4];
                        }
                    }
                    
                    for (int counter4 = 0; counter4 < progenyAnalysisRangeHoldCount/3; counter4++){
                        if (progenyAnalysisResultsHoldCount+30 > progenyAnalysisResultsHoldLimit){
                            string *arrayUpDate = new string [progenyAnalysisResultsHoldCount+30];
                            
                            for (int counter5 = 0; counter5 < progenyAnalysisResultsHoldCount; counter5++) arrayUpDate [counter5] = arrayProgenyAnalysisResultsHold [counter5];
                            
                            delete [] arrayProgenyAnalysisResultsHold;
                            arrayProgenyAnalysisResultsHold = new string [progenyAnalysisResultsHoldLimit+350*6+500];
                            progenyAnalysisResultsHoldLimit = progenyAnalysisResultsHoldLimit+350*6+500;
                            
                            for (int counter5 = 0; counter5 < progenyAnalysisResultsHoldCount; counter5++) arrayProgenyAnalysisResultsHold [counter5] = arrayUpDate [counter5];
                            delete [] arrayUpDate;
                        }
                        
                        if (counter4 != 0){
                            arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "-1", progenyAnalysisResultsHoldCount++;
                            arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "-1", progenyAnalysisResultsHoldCount++;
                            arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "-1", progenyAnalysisResultsHoldCount++;
                        }
                        
                        if (arrayProgenyAnalysisRangeHold [counter4*3+1] == 0 && arrayProgenyAnalysisRangeHold [counter4*3+2] == 0){
                            arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "0", progenyAnalysisResultsHoldCount++;
                        }
                        else if (arrayProgenyAnalysisRangeHold [counter4*3+2] == 100000000) arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = ">="+to_string(arrayProgenyAnalysisRangeHold [counter4*3+1]), progenyAnalysisResultsHoldCount++;
                        else arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = to_string(arrayProgenyAnalysisRangeHold [counter4*3+1])+"-"+to_string(arrayProgenyAnalysisRangeHold [counter4*3+2]), progenyAnalysisResultsHoldCount++;
                        
                        arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = to_string(progenyAnalysisDGSort [counter3*(progenyAnalysisRangeHoldCount/3)+counter4]), progenyAnalysisResultsHoldCount++;
                        
                        if (percentMode == 0){
                            if (totalEventDGCount != 0) percentEventCount = progenyAnalysisDGSort [counter3*(progenyAnalysisRangeHoldCount/3)+counter4]/(double)totalEventDGCount;
                            else percentEventCount = 0;
                        }
                        else{
                            
                            if (totalEventDGPModeCount != 0) percentEventCount = progenyAnalysisDGSort [counter3*(progenyAnalysisRangeHoldCount/3)+counter4]/(double)totalEventDGPModeCount;
                            else percentEventCount = 0;
                        }
                        
                        percentEventIntCount = (int)(percentEventCount*100000);
                        percentEventCount = percentEventIntCount/(double)1000;
                        
                        stringstream extension2;
                        extension2 << percentEventCount;
                        percentString = extension2.str();
                        
                        arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = percentString, progenyAnalysisResultsHoldCount++;
                    }
                    
                    arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "-1", progenyAnalysisResultsHoldCount++;
                    arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "-1", progenyAnalysisResultsHoldCount++;
                    arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "-1", progenyAnalysisResultsHoldCount++;
                    arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "Total", progenyAnalysisResultsHoldCount++;
                    arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = to_string(totalEventDGCount), progenyAnalysisResultsHoldCount++;
                    
                    if (percentMode == 0){
                        if (totalEventDGCount != 0) arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "100", progenyAnalysisResultsHoldCount++;
                        else arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "0", progenyAnalysisResultsHoldCount++;
                    }
                    else{
                        
                        if (totalEventDGCount != 0) percentEventCount = totalEventDGCount/(double)totalEventDGPModeCount;
                        else percentEventCount = 0;
                        
                        percentEventIntCount = (int)(percentEventCount*100000);
                        percentEventCount = percentEventIntCount/(double)1000;
                        
                        stringstream extension3;
                        extension3 << percentEventCount;
                        percentString = extension3.str();
                        
                        arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = percentString, progenyAnalysisResultsHoldCount++;
                    }
                    
                    if (counter3 != progenyAnalysisRangeHoldCount/3-1){
                        arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "-1", progenyAnalysisResultsHoldCount++;
                        arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "-1", progenyAnalysisResultsHoldCount++;
                        arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "-1", progenyAnalysisResultsHoldCount++;
                        arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "-1", progenyAnalysisResultsHoldCount++;
                        arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "-1", progenyAnalysisResultsHoldCount++;
                        arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "-1", progenyAnalysisResultsHoldCount++;
                    }
                }
                
                arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "Total", progenyAnalysisResultsHoldCount++;
                arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = to_string(totalEventCount), progenyAnalysisResultsHoldCount++;
                arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "100", progenyAnalysisResultsHoldCount++;
                arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "", progenyAnalysisResultsHoldCount++;
                arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "", progenyAnalysisResultsHoldCount++;
                arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "", progenyAnalysisResultsHoldCount++;
                
                arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "-1", progenyAnalysisResultsHoldCount++;
                arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "-1", progenyAnalysisResultsHoldCount++;
                arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "-1", progenyAnalysisResultsHoldCount++;
                arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "-1", progenyAnalysisResultsHoldCount++;
                arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "-1", progenyAnalysisResultsHoldCount++;
                arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "-1", progenyAnalysisResultsHoldCount++;
                
                delete [] lineageList;
                delete [] progenyAnalysisSort;
                delete [] progenyAnalysisDGSort;
                delete [] lineageExtractProgeny;
            }
        }
    }
    else{
        
        double **dataHold = new double *[lineageProcessCount+1];
        double **dataHold2 = new double *[lineageProcessCount+1];
        int *totalHold = new int [lineageProcessCount+1];
        
        for (int counter2 = 0; counter2 < lineageProcessCount+1; counter2++){
            dataHold [counter2] = new double [progenyAnalysisRangeHoldCount/3+10];
            dataHold2 [counter2] = new double [progenyAnalysisRangeHoldCount/3+10];
            totalHold [counter2] = 0;
        }
        
        for (int counter2 = 0; counter2 < lineageProcessCount+1; counter2++){
            for (int counter3 = 0; counter3 < progenyAnalysisRangeHoldCount/3+10; counter3++){
                dataHold [counter2][counter3] = 0;
                dataHold2 [counter2][counter3] = 0;
            }
        }
        
        double **dataHoldDG = new double *[lineageProcessCount+1];
        double **dataHoldDG2 = new double *[lineageProcessCount+1];
        double *totalHoldDG = new double [(lineageProcessCount+1)*(progenyAnalysisRangeHoldCount/3)+1];
        double *totalHoldPercentDG = new double [(lineageProcessCount+1)*(progenyAnalysisRangeHoldCount/3)+1];
        
        for (int counter2 = 0; counter2 < lineageProcessCount+1; counter2++){
            dataHoldDG [counter2] = new double [(progenyAnalysisRangeHoldCount/3)*(progenyAnalysisRangeHoldCount/3)+10];
            dataHoldDG2 [counter2] = new double [(progenyAnalysisRangeHoldCount/3)*(progenyAnalysisRangeHoldCount/3)+10];
        }
        
        for (int counter2 = 0; counter2 < (lineageProcessCount+1)*(progenyAnalysisRangeHoldCount/3)+1; counter2++){
            totalHoldDG [counter2] = 0;
            totalHoldPercentDG [counter2] = 0;
        }
        
        for (int counter2 = 0; counter2 < lineageProcessCount+1; counter2++){
            for (int counter3 = 0; counter3 < (progenyAnalysisRangeHoldCount/3)*(progenyAnalysisRangeHoldCount/3)+10; counter3++){
                dataHoldDG [counter2][counter3] = 0;
                dataHoldDG2 [counter2][counter3] = 0;
            }
        }
        
        int lineageEntryCount = 0;
        int lineageExtractProgenyCount = 0;
        int numberOfToalCells = 0;
        int firstCellGroupCount = 0;
        int firstRangeCount = 0;
        int terminationFlag = 0;
        int chasingCellPosition = 0;
        int endFindFlag = 0;
        int findCellCount = 0;
        int secondCellGroupCount = 0;
        int rangeCount = 0;
        int entryCount = 0;
        int firstCellGroupListCount = 0;
        int daughterCellListCount = 0;
        int grandDaughterCellListCount = 0;
        int gdFirstDivisionTime = 0;
        int endFindCheck = 0;
        
        for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
            if (arraySelectedLing [counter2] == 1){
                
                //for (int counterA = 0; counterA < 1; counterA++){
                //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<< arrayTableMain [counter2][counterA+counterB];
                //    cout<<"  arrayTableMain "<<counterA<<endl;
                //}
                
                lineageEntrySize = arrayLineageDataEntryHold [counter2];
                lineageEntryNo = 0;
                
                int *lineageExtractProgeny = new int [lineageEntrySize+10];
                
                for (unsigned long counter3 = 0; counter3 < lineageEntrySize/9; counter3++){
                    if (arrayLineageData [counter2][counter3*9+6] > lineageEntryNo){
                        lineageEntryNo = arrayLineageData [counter2][counter3*9+6];
                    }
                }
                
                int *lineageList = new int [lineageEntryNo+10];
                
                for (int counter3 = 0; counter3 < lineageEntryNo; counter3++) lineageList [counter3] = 0;
                
                for (unsigned long counter3 = 0; counter3 < lineageEntrySize/9; counter3++){
                    lineageList [arrayLineageData [counter2][counter3*9+6]] = 1;
                }
                
                //for (int counterA = 1; counterA <= lineageEntryNo; counterA++){
                //    cout<<counterA<<" "<<lineageList [counterA] <<" lineageList"<<endl;
                //}
                
                for (int counter3 = 1; counter3 <= lineageEntryNo; counter3++){
                    if (lineageList [counter3] == 1){
                        lineageExtractProgenyCount = 0;
                        
                        numberOfToalCells = 0;
                        
                        for (unsigned long counter4 = 0; counter4 < lineageEntrySize/9; counter4++){
                            if (arrayLineageData [counter2][counter4*9+6] == counter3){
                                lineageExtractProgeny [lineageExtractProgenyCount] = arrayLineageData [counter2][counter4*9], lineageExtractProgenyCount++;
                                lineageExtractProgeny [lineageExtractProgenyCount] = arrayLineageData [counter2][counter4*9+1], lineageExtractProgenyCount++;
                                lineageExtractProgeny [lineageExtractProgenyCount] = arrayLineageData [counter2][counter4*9+2], lineageExtractProgenyCount++;
                                lineageExtractProgeny [lineageExtractProgenyCount] = arrayLineageData [counter2][counter4*9+3], lineageExtractProgenyCount++;
                                lineageExtractProgeny [lineageExtractProgenyCount] = arrayLineageData [counter2][counter4*9+4], lineageExtractProgenyCount++;
                                lineageExtractProgeny [lineageExtractProgenyCount] = arrayLineageData [counter2][counter4*9+5], lineageExtractProgenyCount++;
                                lineageExtractProgeny [lineageExtractProgenyCount] = arrayLineageData [counter2][counter4*9+6], lineageExtractProgenyCount++;
                                lineageExtractProgeny [lineageExtractProgenyCount] = arrayLineageData [counter2][counter4*9+7], lineageExtractProgenyCount++;
                                
                                if (arrayLineageData [counter2][counter4*9+3] == 1 || arrayLineageData [counter2][counter4*9+3] == 31 || arrayLineageData [counter2][counter4*9+3] == 41 || arrayLineageData [counter2][counter4*9+3] == 51){
                                    numberOfToalCells++;
                                }
                            }
                        }
                        
                        int *firstCellGroup = new int [numberOfToalCells+10];
                        firstCellGroupCount = 0;
                        firstRangeCount = 0;
                        
                        if (progenyOfMDInclude == 1){
                            for (int counter4 = 0; counter4 < lineageExtractProgenyCount/8; counter4++){
                                if (lineageExtractProgeny [counter4*8+2] == progenyAnalysisTimeEd1Hold){
                                    firstCellGroup [firstCellGroupCount] =  lineageExtractProgeny [counter4*8+5], firstCellGroupCount++;
                                }
                            }
                        }
                        else{
                            
                            int *firstCellGroupList = new int [numberOfToalCells+10];
                            firstCellGroupListCount = 0;
                            
                            for (int counter4 = 0; counter4 < lineageExtractProgenyCount/8; counter4++){
                                if (lineageExtractProgeny [counter4*8+2] == progenyAnalysisTimeEd1Hold){
                                    firstCellGroupList [firstCellGroupListCount] = lineageExtractProgeny [counter4*8+5], firstCellGroupListCount++;
                                }
                            }
                            
                            //for (int counterA = 0; counterA < firstCellGroupListCount; counterA++){
                            //    cout<<counterA<<" "<<firstCellGroupList [counterA]<<" firstCellGroupList"<<endl;
                            //}
                            
                            for (int counter4 = 0; counter4 < firstCellGroupListCount; counter4++){
                                for (int counter5 = 0; counter5 < lineageExtractProgenyCount/8; counter5++){
                                    if (lineageExtractProgeny [counter5*8+3] == 31 && lineageExtractProgeny [counter5*8+4] == firstCellGroupList [counter4]){
                                        firstCellGroup [firstCellGroupCount] = firstCellGroupList [counter4], firstCellGroupCount++;
                                        break;
                                    }
                                }
                            }
                            
                            delete [] firstCellGroupList;
                        }
                        
                        //for (int counterA = 0; counterA < firstCellGroupCount; counterA++){
                        //    cout<<counterA<<" "<<firstCellGroup [counterA]<<" first"<<endl;
                        //}
                        
                        if (firstCellGroupCount != 0){
                            for (int counter4 = 0; counter4 < progenyAnalysisRangeHoldCount/3; counter4++){
                                if (firstCellGroupCount >= arrayProgenyAnalysisRangeHold [counter4*3+1] && firstCellGroupCount <= arrayProgenyAnalysisRangeHold [counter4*3+2]){
                                    dataHold [lineageEntryCount][counter4]++;
                                    firstRangeCount = counter4;
                                    break;
                                }
                            }
                        }
                        else{
                            
                            dataHold [lineageEntryCount][0]++;
                            firstRangeCount = 0;
                        }
                        
                        int *daughterCellList = new int [numberOfToalCells+10];
                        daughterCellListCount = 0;
                        
                        if (progenyOfMDInclude == 1){
                            for (int counter4 = 0; counter4 < lineageExtractProgenyCount/8; counter4++){
                                if ((lineageExtractProgeny [counter4*8+3] == 31 || lineageExtractProgeny [counter4*8+3] == 41 || lineageExtractProgeny [counter4*8+3] == 51) && lineageExtractProgeny [counter4*8+4] == 0){
                                    daughterCellList [daughterCellListCount] = lineageExtractProgeny [counter4*8+5], daughterCellListCount++;
                                }
                            }
                        }
                        else{
                            
                            for (int counter4 = 0; counter4 < lineageExtractProgenyCount/8; counter4++){
                                if (lineageExtractProgeny [counter4*8+3] == 31 && lineageExtractProgeny [counter4*8+4] == 0){
                                    daughterCellList [daughterCellListCount] = lineageExtractProgeny [counter4*8+5], daughterCellListCount++;
                                }
                            }
                        }
                        
                        int *grandDaughterCellList = new int [daughterCellListCount*4];
                        grandDaughterCellListCount = 0;
                        
                        if (progenyOfMDInclude == 1){
                            for (int counter4 = 0; counter4 < daughterCellListCount; counter4++){
                                for (int counter5 = 0; counter5 < lineageExtractProgenyCount/8; counter5++){
                                    if ((lineageExtractProgeny [counter5*8+3] == 31 || lineageExtractProgeny [counter5*8+3] == 41 || lineageExtractProgeny [counter5*8+3] == 51) && lineageExtractProgeny [counter5*8+4] == daughterCellList [counter4]){
                                        grandDaughterCellList [grandDaughterCellListCount] = lineageExtractProgeny [counter5*8+5], grandDaughterCellListCount++;
                                    }
                                }
                            }
                        }
                        else{
                            
                            for (int counter4 = 0; counter4 < daughterCellListCount; counter4++){
                                for (int counter5 = 0; counter5 < lineageExtractProgenyCount/8; counter5++){
                                    if (lineageExtractProgeny [counter5*8+3] == 31 && lineageExtractProgeny [counter5*8+4] == daughterCellList [counter4]){
                                        grandDaughterCellList [grandDaughterCellListCount] = lineageExtractProgeny [counter5*8+5], grandDaughterCellListCount++;
                                    }
                                }
                            }
                        }
                        
                        delete [] daughterCellList;
                        
                        int *secondCellGroup = new int [numberOfToalCells+10];
                        
                        for (int counter4 = 0; counter4 < firstCellGroupCount; counter4++){
                            for (int counter5 = 0; counter5 < numberOfToalCells+10; counter5++) secondCellGroup [counter5] = -1;
                            secondCellGroupCount = 0;
                            gdFirstDivisionTime = 0;
                            
                            secondCellGroup [secondCellGroupCount] = firstCellGroup [counter4], secondCellGroupCount++;
                            
                            if (progenyOfMDInclude == 1){
                                for (int counter5 = 0; counter5 < lineageExtractProgenyCount/8; counter5++){
                                    if ((lineageExtractProgeny [counter5*8+3] == 32 || lineageExtractProgeny [counter5*8+3] == 42 || lineageExtractProgeny [counter5*8+3] == 52) && lineageExtractProgeny [counter5*8+5] == grandDaughterCellList [counter4]){
                                        gdFirstDivisionTime = lineageExtractProgeny [counter5*8+2];
                                        break;
                                    }
                                }
                            }
                            else{
                                
                                for (int counter5 = 0; counter5 < lineageExtractProgenyCount/8; counter5++){
                                    if (lineageExtractProgeny [counter5*8+3] == 32 && lineageExtractProgeny [counter5*8+5] == grandDaughterCellList [counter4]){
                                        gdFirstDivisionTime = lineageExtractProgeny [counter5*8+2];
                                        break;
                                    }
                                }
                            }
                            
                            if (gdFirstDivisionTime != 0){
                                findCellCount = 0;
                                
                                do{
                                    
                                    terminationFlag = 0;
                                    endFindFlag = 0;
                                    chasingCellPosition = -1;
                                    
                                    for (int counter5 = 0; counter5 < secondCellGroupCount; counter5++){
                                        if (secondCellGroup [counter5] != -1){
                                            terminationFlag = 1;
                                            chasingCellPosition = counter5;
                                            break;
                                        }
                                    }
                                    
                                    if (chasingCellPosition != -1){
                                        if (progenyOfMDInclude == 1){
                                            for (int counter5 = 0; counter5 < lineageExtractProgenyCount/8; counter5++){
                                                if (lineageExtractProgeny [counter5*8+5] == secondCellGroup [chasingCellPosition] && lineageExtractProgeny [counter5*8+2] == progenyAnalysisTimeEd2Hold){
                                                    secondCellGroup [chasingCellPosition] = -1;
                                                    endFindFlag = 1;
                                                    findCellCount++;
                                                }
                                            }
                                        }
                                        else{
                                            
                                            endFindCheck = 0;
                                            
                                            for (int counter5 = 0; counter5 < lineageExtractProgenyCount/8; counter5++){
                                                if (lineageExtractProgeny [counter5*8+5] == secondCellGroup [chasingCellPosition] && lineageExtractProgeny [counter5*8+2] == progenyAnalysisTimeEd2Hold+gdFirstDivisionTime){
                                                    endFindCheck = 1;
                                                    endFindFlag = 1;
                                                }
                                            }
                                            
                                            if (endFindCheck == 1){
                                                for (int counter5 = 0; counter5 < lineageExtractProgenyCount/8; counter5++){
                                                    if (lineageExtractProgeny [counter5*8+3] == 31 && lineageExtractProgeny [counter5*8+5] == secondCellGroup [chasingCellPosition]){
                                                        secondCellGroup [chasingCellPosition] = -1;
                                                        findCellCount++;
                                                        break;
                                                    }
                                                    else if ((lineageExtractProgeny [counter5*8+3] == 41 || lineageExtractProgeny [counter5*8+3] == 51) && lineageExtractProgeny [counter5*8+5] == secondCellGroup [chasingCellPosition]){
                                                        secondCellGroup [chasingCellPosition] = -1;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        if (endFindFlag == 0){
                                            for (int counter5 = 0; counter5 < lineageExtractProgenyCount/8; counter5++){
                                                if (lineageExtractProgeny [counter5*8+4] == secondCellGroup [chasingCellPosition] && (lineageExtractProgeny [counter5*8+3] == 31 || lineageExtractProgeny [counter5*8+3] == 41 || lineageExtractProgeny [counter5*8+3] == 51)){
                                                    secondCellGroup [secondCellGroupCount] = lineageExtractProgeny [counter5*8+5], secondCellGroupCount++;
                                                }
                                            }
                                            
                                            secondCellGroup [chasingCellPosition] = -1;
                                        }
                                    }
                                    
                                } while (terminationFlag == 1);
                                
                                if (findCellCount != 0){
                                    for (int counter5 = 0; counter5 < progenyAnalysisRangeHoldCount/3; counter5++){
                                        if (findCellCount >= arrayProgenyAnalysisRangeHold [counter5*3+1] && findCellCount <= arrayProgenyAnalysisRangeHold [counter5*3+2]){
                                            dataHoldDG [lineageEntryCount][firstRangeCount*(progenyAnalysisRangeHoldCount/3)+counter5]++;
                                            break;
                                        }
                                    }
                                }
                                else dataHoldDG [lineageEntryCount][firstRangeCount*(progenyAnalysisRangeHoldCount/3)]++;
                            }
                            else dataHoldDG [lineageEntryCount][firstRangeCount*(progenyAnalysisRangeHoldCount/3)] = 0;
                        }
                        
                        totalEventCount = 0;
                        
                        for (int counter4 = firstRangeCount*(progenyAnalysisRangeHoldCount/3); counter4 < progenyAnalysisRangeHoldCount/3+firstRangeCount*(progenyAnalysisRangeHoldCount/3); counter4++){
                            totalEventCount = (int)(totalEventCount+dataHoldDG [lineageEntryCount][counter4]);
                        }
                        
                        delete [] firstCellGroup;
                        delete [] secondCellGroup;
                        delete [] grandDaughterCellList;
                    }
                }
                
                totalEventCount = 0;
                
                for (int counter3 = 0; counter3 < progenyAnalysisRangeHoldCount/3; counter3++){
                    totalEventCount = (int)(totalEventCount+dataHold [lineageEntryCount][counter3]);
                }
                
                totalHold [lineageEntryCount] = totalEventCount;
                
                delete [] lineageList;
                delete [] lineageExtractProgeny;
                
                lineageEntryCount++;
            }
        }
        
        //for (int counterA = 0; counterA < lineageProcessCount; counterA++){
        //    for (int counterB = 0; counterB < progenyAnalysisRangeHoldCount/3; counterB++){
        //        cout<<counterA<<" "<<counterB<<" "<<dataHold [counterA][counterB]<<" "<<dataHold2 [counterA][counterB]<<" dataHold2"<<endl;
        //    }
        //}
        
        //for (int counterA = 0; counterA < lineageProcessCount; counterA++){
        //    for (int counterB = 0; counterB < (progenyAnalysisRangeHoldCount/3)*(progenyAnalysisRangeHoldCount/3); counterB++){
        //        cout<<counterA<<" "<<counterB<<" "<<dataHoldDG [counterA][counterB]<<" "<<dataHoldDG2 [counterA][counterB]<<" dataHoldDG2"<<endl;
        //    }
        //}
        
        //for (int counterA = 0; counterA < lineageProcessCount; counterA++){
        //    cout<<counterA<<" "<<totalHold [counterA]<<" totalHold"<<endl;
        //}
        
        for (int counter2 = 0; counter2 < lineageProcessCount; counter2++){
            for (int counter3 = 0; counter3 < progenyAnalysisRangeHoldCount/3; counter3++){
                if (totalHold [counter2] != 0){
                    dataHold2 [counter2][counter3] = (double)((dataHold [counter2][counter3]/(double)totalHold [counter2])*100);
                    dataHold [counter2][counter3] = (double)((dataHold [counter2][counter3]/(double)totalHold [counter2])*normalizeHold);
                }
            }
        }
        
        for (int counter2 = 0; counter2 < lineageProcessCount; counter2++){
            for (int counter3 = 0; counter3 < (progenyAnalysisRangeHoldCount/3)*(progenyAnalysisRangeHoldCount/3); counter3++){
                if (totalHold [counter2] != 0){
                    dataHoldDG2 [counter2][counter3] = (double)((dataHoldDG [counter2][counter3]/(double)totalHold [counter2])*100);
                    dataHoldDG [counter2][counter3] = (double)((dataHoldDG [counter2][counter3]/(double)totalHold [counter2])*normalizeHold);
                }
            }
        }
        
        if (percentMode == 1){
            double percentModeTotalCount = 0;
            
            for (int counter2 = 0; counter2 < lineageProcessCount; counter2++){
                for (int counter3 = 0; counter3 < (progenyAnalysisRangeHoldCount/3)*(progenyAnalysisRangeHoldCount/3); counter3++){
                    percentModeTotalCount = percentModeTotalCount+dataHoldDG [counter2][counter3];
                }
            }
            
            percentModeTotalCount = percentModeTotalCount/(double)lineageProcessCount;
            
            for (int counter2 = 0; counter2 < lineageProcessCount; counter2++){
                for (int counter3 = 0; counter3 < (progenyAnalysisRangeHoldCount/3)*(progenyAnalysisRangeHoldCount/3); counter3++){
                    if (totalHold [counter2] != 0){
                        dataHoldDG2 [counter2][counter3] = (double)((dataHoldDG [counter2][counter3]/(double)percentModeTotalCount)*100);
                    }
                }
            }
        }
        
        //for (int counterA = 0; counterA < lineageProcessCount; counterA++){
        //    for (int counterB = 0; counterB < (progenyAnalysisRangeHoldCount/3)*(progenyAnalysisRangeHoldCount/3); counterB++){
        //        cout<<counterA<<" "<<counterB<<" "<<dataHoldDG [counterA][counterB]<<" "<<dataHoldDG2 [counterA][counterB]<<" dataHoldDG2"<<endl;
        //    }
        //}
        
        //for (int counterA = 0; counterA < lineageProcessCount; counterA++){
        //    cout<<counterA<<" "<<totalHold [counterA]<<" totalHold"<<endl;
        //}
        
        //for (int counterA = 0; counterA < lineageProcessCount*(progenyAnalysisRangeHoldCount/3); counterA++){
        //    cout<<counterA<<" "<<totalHoldDG [counterA]<<" totalHoldDG"<<endl;
        //}
        
        for (int counter2 = 0; counter2 < lineageProcessCount; counter2++){
            rangeCount = 0;
            entryCount = 0;
            
            for (int counter3 = 0; counter3 < (progenyAnalysisRangeHoldCount/3)*(progenyAnalysisRangeHoldCount/3); counter3++){
                totalHoldDG [entryCount] = totalHoldDG [entryCount]+dataHoldDG [counter2][counter3];
                totalHoldPercentDG [entryCount] = totalHoldPercentDG [entryCount]+dataHoldDG2 [counter2][counter3];
                
                rangeCount++;
                
                if (rangeCount == progenyAnalysisRangeHoldCount/3){
                    rangeCount = 0;
                    entryCount++;
                }
            }
        }
        
        double *averageHold = new double [progenyAnalysisRangeHoldCount/3+10];
        double *sdHold = new double [progenyAnalysisRangeHoldCount/3+10];
        double *averagePercentHold = new double [progenyAnalysisRangeHoldCount/3+10];
        double *sdPercentHold = new double [progenyAnalysisRangeHoldCount/3+10];
        
        for (int counter2 = 0; counter2 < progenyAnalysisRangeHoldCount/3+10; counter2++){
            averageHold [counter2] = 0;
            sdHold [counter2] = 0;
            averagePercentHold [counter2] = 0;
            sdPercentHold [counter2] = 0;
        }
        
        for (int counter2 = 0; counter2 < lineageProcessCount; counter2++){
            for (int counter3 = 0; counter3 < progenyAnalysisRangeHoldCount/3; counter3++){
                averageHold [counter3] = averageHold [counter3]+dataHold [counter2][counter3];
                averagePercentHold [counter3] = averagePercentHold [counter3]+dataHold2 [counter2][counter3];
            }
        }
        
        //for (int counterA = 0; counterA < progenyAnalysisRangeHoldCount/3; counterA++){
        //    cout<<counterA<<" "<<averageHold [counterA]<<" averageHold"<<endl;
        //}
        
        //for (int counterA = 0; counterA < progenyAnalysisRangeHoldCount/3; counterA++){
        //    cout<<counterA<<" "<<averagePercentHold [counterA]<<" averagePercentHold"<<endl;
        //}
        
        double *averageHoldDG = new double [(progenyAnalysisRangeHoldCount/3)*(progenyAnalysisRangeHoldCount/3)+10];
        double *sdHoldDG = new double [(progenyAnalysisRangeHoldCount/3)*(progenyAnalysisRangeHoldCount/3)+10];
        double *averageTotalDG = new double [progenyAnalysisRangeHoldCount/3+10];
        double *sdTotalDG = new double [progenyAnalysisRangeHoldCount/3+10];
        double *averagePercentDG = new double [progenyAnalysisRangeHoldCount/3+10];
        double *sdPercentDG = new double [progenyAnalysisRangeHoldCount/3+10];
        double *averagePercentHoldDG = new double [(progenyAnalysisRangeHoldCount/3)*(progenyAnalysisRangeHoldCount/3)+10];
        double *sdPercentHoldDG = new double [(progenyAnalysisRangeHoldCount/3)*(progenyAnalysisRangeHoldCount/3)+10];
        
        for (int counter2 = 0; counter2 < (progenyAnalysisRangeHoldCount/3)*(progenyAnalysisRangeHoldCount/3)+10; counter2++){
            averageHoldDG [counter2] = 0;
            sdHoldDG [counter2] = 0;
            averagePercentHoldDG [counter2] = 0;
            sdPercentHoldDG [counter2] = 0;
        }
        
        for (int counter2 = 0; counter2 < progenyAnalysisRangeHoldCount/3; counter2++){
            averageTotalDG [counter2] = 0;
            averagePercentDG [counter2] = 0;
            sdTotalDG [counter2] = 0;
            sdPercentDG [counter2] = 0;
        }
        
        for (int counter2 = 0; counter2 < lineageProcessCount; counter2++){
            for (int counter3 = 0; counter3 < (progenyAnalysisRangeHoldCount/3)*(progenyAnalysisRangeHoldCount/3); counter3++){
                averageHoldDG [counter3] = averageHoldDG [counter3]+dataHoldDG [counter2][counter3];
                averagePercentHoldDG [counter3] = averagePercentHoldDG [counter3]+dataHoldDG2 [counter2][counter3];
            }
        }
        
        for (int counter2 = 0; counter2 < lineageProcessCount; counter2++){
            for (int counter3 = 0; counter3 < progenyAnalysisRangeHoldCount/3; counter3++){
                averageTotalDG [counter3] = averageTotalDG [counter3]+totalHoldDG [counter2*(progenyAnalysisRangeHoldCount/3)+counter3];
                averagePercentDG [counter3] = averagePercentDG [counter3]+totalHoldPercentDG [counter2*(progenyAnalysisRangeHoldCount/3)+counter3];
            }
        }
        
        //for (int counterA = 0; counterA < (progenyAnalysisRangeHoldCount/3)*(progenyAnalysisRangeHoldCount/3); counterA++){
        //    cout<<counterA<<" "<<averageHoldDG [counterA]<<" averageHoldDG"<<endl;
        //}
        
        //for (int counterA = 0; counterA < (progenyAnalysisRangeHoldCount/3)*(progenyAnalysisRangeHoldCount/3); counterA++){
        //    cout<<counterA<<" "<<averagePercentHoldDG [counterA]<<" averagePercentHoldDG"<<endl;
        //}
        
        //for (int counterA = 0; counterA < progenyAnalysisRangeHoldCount/3; counterA++){
        //    cout<<counterA<<" "<<averageTotalDG [counterA]<<" "<<averagePercentDG [counterA]<<" averagePercentDG"<<endl;
        //}
        
        for (int counter2 = 0; counter2 < progenyAnalysisRangeHoldCount/3; counter2++){
            if (lineageProcessCount != 0){
                averageHold [counter2] = averageHold [counter2]/(double)lineageProcessCount;
                averagePercentHold [counter2] = averagePercentHold [counter2]/(double)lineageProcessCount;
            }
        }
        
        for (int counter2 = 0; counter2 < progenyAnalysisRangeHoldCount/3; counter2++){
            if (lineageProcessCount != 0){
                averageTotalDG [counter2] = averageTotalDG [counter2]/(double)lineageProcessCount;
                averagePercentDG [counter2] = averagePercentDG [counter2]/(double)lineageProcessCount;
            }
        }
        
        for (int counter2 = 0; counter2 < (progenyAnalysisRangeHoldCount/3)*(progenyAnalysisRangeHoldCount/3); counter2++){
            if (lineageProcessCount != 0){
                averageHoldDG [counter2] = averageHoldDG [counter2]/(double)lineageProcessCount;
                averagePercentHoldDG [counter2] = averagePercentHoldDG [counter2]/(double)lineageProcessCount;
            }
        }
        
        //for (int counterA = 0; counterA < progenyAnalysisRangeHoldCount/3; counterA++){
        //    cout<<counterA<<" "<<averageHold [counterA]<<" averageHold"<<endl;
        //}
        
        //for (int counterA = 0; counterA < progenyAnalysisRangeHoldCount/3; counterA++){
        //    cout<<counterA<<" "<<averagePercentHold [counterA]<<" averagePercentHold"<<endl;
        //}
        
        //for (int counterA = 0; counterA < (progenyAnalysisRangeHoldCount/3)*(progenyAnalysisRangeHoldCount/3); counterA++){
        //    cout<<counterA<<" "<<averageHoldDG [counterA]<<" averageHoldDG"<<endl;
        //}
        
        //for (int counterA = 0; counterA < (progenyAnalysisRangeHoldCount/3)*(progenyAnalysisRangeHoldCount/3); counterA++){
        //    cout<<counterA<<" "<<averagePercentHoldDG [counterA]<<" averagePercentHoldDG"<<endl;
        //}
        
        for (int counter2 = 0; counter2 < lineageProcessCount; counter2++){
            for (int counter3 = 0; counter3 < progenyAnalysisRangeHoldCount/3; counter3++){
                sdHold [counter3] = sdHold [counter3]+(dataHold [counter2][counter3]-averageHold [counter3])*(dataHold [counter2][counter3]-averageHold [counter3]);
                sdPercentHold [counter3] = sdPercentHold [counter3]+(dataHold2 [counter2][counter3]-averagePercentHold [counter3])*(dataHold2 [counter2][counter3]-averagePercentHold [counter3]);
            }
        }
        
        for (int counter2 = 0; counter2 < lineageProcessCount; counter2++){
            for (int counter3 = 0; counter3 < progenyAnalysisRangeHoldCount/3; counter3++){
                sdTotalDG [counter3] = sdTotalDG [counter3]+(totalHoldDG [counter2*(progenyAnalysisRangeHoldCount/3)+counter3]-averageTotalDG [counter3])*(totalHoldDG [counter2*(progenyAnalysisRangeHoldCount/3)+counter3]-averageTotalDG [counter3]);
                sdPercentDG [counter3] = sdPercentDG [counter3]+(totalHoldPercentDG [counter2*(progenyAnalysisRangeHoldCount/3)+counter3]-averagePercentHoldDG [counter3])*(totalHoldPercentDG [counter2*(progenyAnalysisRangeHoldCount/3)+counter3]-averagePercentHoldDG [counter3]);
            }
        }
        
        //for (int counterA = 0; counterA < progenyAnalysisRangeHoldCount/3; counterA++){
        //    cout<<counterA<<" "<<sdHold [counterA]<<" sdHold"<<endl;
        //}
        
        //for (int counterA = 0; counterA < progenyAnalysisRangeHoldCount/3; counterA++){
        //    cout<<counterA<<" "<<sdPercentHold [counterA]<<" sdPercentHold"<<endl;
        //}
        
        for (int counter2 = 0; counter2 < progenyAnalysisRangeHoldCount/3; counter2++){
            if (lineageProcessCount != 0){
                sdHold [counter2] = sqrt(sdHold [counter2]/(double)lineageProcessCount);
                sdPercentHold [counter2] = sqrt(sdPercentHold [counter2]/(double)lineageProcessCount);
            }
        }
        
        for (int counter2 = 0; counter2 < progenyAnalysisRangeHoldCount/3; counter2++){
            if (lineageProcessCount != 0){
                sdTotalDG [counter2] = sqrt(sdTotalDG [counter2]/(double)lineageProcessCount);
                sdPercentDG [counter2] = sqrt(sdPercentDG [counter2]/(double)lineageProcessCount);
            }
        }
        
        for (int counter2 = 0; counter2 < lineageProcessCount; counter2++){
            for (int counter3 = 0; counter3 < (progenyAnalysisRangeHoldCount/3)*(progenyAnalysisRangeHoldCount/3); counter3++){
                sdHoldDG [counter3] = sdHoldDG [counter3]+(dataHoldDG [counter2][counter3]-averageHoldDG [counter3])*(dataHoldDG [counter2][counter3]-averageHoldDG [counter3]);
                sdPercentHoldDG [counter3] = sdPercentHoldDG [counter3]+(dataHoldDG2 [counter2][counter3]-averagePercentHoldDG [counter3])*(dataHoldDG2 [counter2][counter3]-averagePercentHoldDG [counter3]);
            }
        }
        
        for (int counter2 = 0; counter2 < (progenyAnalysisRangeHoldCount/3)*(progenyAnalysisRangeHoldCount/3); counter2++){
            if (lineageProcessCount != 0){
                sdHoldDG [counter2] = sqrt(sdHoldDG [counter2]/(double)lineageProcessCount);
                sdPercentHoldDG [counter2] = sqrt(sdPercentHoldDG [counter2]/(double)lineageProcessCount);
            }
        }
        
        double avEventCount = 0;
        double sdEventCount = 0;
        int avEventIntCount = 0;
        int sdEventIntCount = 0;
        
        string avString;
        string sdString;
        
        for (int counter3 = 0; counter3 < progenyAnalysisRangeHoldCount/3; counter3++){
            if (progenyAnalysisResultsHoldCount+30 > progenyAnalysisResultsHoldLimit){
                string *arrayUpDate = new string [progenyAnalysisResultsHoldCount+30];
                
                for (int counter5 = 0; counter5 < progenyAnalysisResultsHoldCount; counter5++) arrayUpDate [counter5] = arrayProgenyAnalysisResultsHold [counter5];
                
                delete [] arrayProgenyAnalysisResultsHold;
                arrayProgenyAnalysisResultsHold = new string [progenyAnalysisResultsHoldLimit+350*6+500];
                progenyAnalysisResultsHoldLimit = progenyAnalysisResultsHoldLimit+350*6+500;
                
                for (int counter5 = 0; counter5 < progenyAnalysisResultsHoldCount; counter5++) arrayProgenyAnalysisResultsHold [counter5] = arrayUpDate [counter5];
                delete [] arrayUpDate;
            }
            
            if (arrayProgenyAnalysisRangeHold [counter3*3+1] == 0 && arrayProgenyAnalysisRangeHold [counter3*3+2] == 0){
                arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "0", progenyAnalysisResultsHoldCount++;
            }
            else if (arrayProgenyAnalysisRangeHold [counter3*3+2] == 100000000) arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = ">="+to_string(arrayProgenyAnalysisRangeHold [counter3*3+1]), progenyAnalysisResultsHoldCount++;
            else arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = to_string(arrayProgenyAnalysisRangeHold [counter3*3+1])+"-"+to_string(arrayProgenyAnalysisRangeHold [counter3*3+2]), progenyAnalysisResultsHoldCount++;
            
            if (averageHold [counter3] != 0) avEventCount = averageHold [counter3];
            else avEventCount = 0;
            
            avEventIntCount = (int)(avEventCount*1000);
            avEventCount = avEventIntCount/(double)1000;
            
            stringstream extension1;
            extension1 << avEventCount;
            avString = extension1.str();
            
            if (sdHold [counter3] != 0) sdEventCount = sdHold [counter3];
            else sdEventCount = 0;
            
            sdEventIntCount = (int)(sdEventCount*1000);
            sdEventCount = sdEventIntCount/(double)1000;
            
            stringstream extension2;
            extension2 << sdEventCount;
            sdString = extension2.str();
            
            arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = avString+" ± "+sdString, progenyAnalysisResultsHoldCount++;
            
            if (averagePercentHold [counter3] != 0) avEventCount = averagePercentHold [counter3];
            else avEventCount = 0;
            
            avEventIntCount = (int)(avEventCount*1000);
            avEventCount = avEventIntCount/(double)1000;
            
            stringstream extension3;
            extension3 << avEventCount;
            avString = extension3.str();
            
            if (sdPercentHold [counter3] != 0) sdEventCount = sdPercentHold [counter3];
            else sdEventCount = 0;
            
            sdEventIntCount = (int)(sdEventCount*1000);
            sdEventCount = sdEventIntCount/(double)1000;
            
            stringstream extension4;
            extension4 << sdEventCount;
            sdString = extension4.str();
            
            arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = avString+" ± "+sdString, progenyAnalysisResultsHoldCount++;
            
            for (int counter4 = 0; counter4 < progenyAnalysisRangeHoldCount/3; counter4++){
                if (progenyAnalysisResultsHoldCount+30 > progenyAnalysisResultsHoldLimit){
                    string *arrayUpDate = new string [progenyAnalysisResultsHoldCount+30];
                    
                    for (int counter5 = 0; counter5 < progenyAnalysisResultsHoldCount; counter5++) arrayUpDate [counter5] = arrayProgenyAnalysisResultsHold [counter5];
                    
                    delete [] arrayProgenyAnalysisResultsHold;
                    arrayProgenyAnalysisResultsHold = new string [progenyAnalysisResultsHoldLimit+350*6+500];
                    progenyAnalysisResultsHoldLimit = progenyAnalysisResultsHoldLimit+350*6+500;
                    
                    for (int counter5 = 0; counter5 < progenyAnalysisResultsHoldCount; counter5++) arrayProgenyAnalysisResultsHold [counter5] = arrayUpDate [counter5];
                    delete [] arrayUpDate;
                }
                
                if (counter4 != 0){
                    arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "-1", progenyAnalysisResultsHoldCount++;
                    arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "-1", progenyAnalysisResultsHoldCount++;
                    arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "-1", progenyAnalysisResultsHoldCount++;
                }
                
                if (arrayProgenyAnalysisRangeHold [counter4*3+1] == 0 && arrayProgenyAnalysisRangeHold [counter4*3+2] == 0){
                    arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "0", progenyAnalysisResultsHoldCount++;
                }
                else if (arrayProgenyAnalysisRangeHold [counter4*3+2] == 100000000) arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = ">="+to_string(arrayProgenyAnalysisRangeHold [counter4*3+1]), progenyAnalysisResultsHoldCount++;
                else arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = to_string(arrayProgenyAnalysisRangeHold [counter4*3+1])+"-"+to_string(arrayProgenyAnalysisRangeHold [counter4*3+2]), progenyAnalysisResultsHoldCount++;
                
                if (averageHoldDG [counter3*(progenyAnalysisRangeHoldCount/3)+counter4] != 0) avEventCount = averageHoldDG [counter3*(progenyAnalysisRangeHoldCount/3)+counter4];
                else avEventCount = 0;
                
                avEventIntCount = (int)(avEventCount*1000);
                avEventCount = avEventIntCount/(double)1000;
                
                stringstream extension5;
                extension5 << avEventCount;
                avString = extension5.str();
                
                if (sdHoldDG [counter3*(progenyAnalysisRangeHoldCount/3)+counter4] != 0) sdEventCount = sdHoldDG [counter3*(progenyAnalysisRangeHoldCount/3)+counter4];
                else sdEventCount = 0;
                
                sdEventIntCount = (int)(sdEventCount*1000);
                sdEventCount = sdEventIntCount/(double)1000;
                
                stringstream extension6;
                extension6 << sdEventCount;
                sdString = extension6.str();
                
                arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = avString+" ± "+sdString, progenyAnalysisResultsHoldCount++;
                
                if (averagePercentHoldDG [counter3*(progenyAnalysisRangeHoldCount/3)+counter4] != 0) avEventCount = averagePercentHoldDG [counter3*(progenyAnalysisRangeHoldCount/3)+counter4];
                else avEventCount = 0;
                
                avEventIntCount = (int)(avEventCount*1000);
                avEventCount = avEventIntCount/(double)1000;
                
                stringstream extension7;
                extension7 << avEventCount;
                avString = extension7.str();
                
                if (sdPercentHoldDG [counter3*(progenyAnalysisRangeHoldCount/3)+counter4] != 0) sdEventCount = sdPercentHoldDG [counter3*(progenyAnalysisRangeHoldCount/3)+counter4];
                else sdEventCount = 0;
                
                sdEventIntCount = (int)(sdEventCount*1000);
                sdEventCount = sdEventIntCount/(double)1000;
                
                stringstream extension8;
                extension8 << sdEventCount;
                sdString = extension8.str();
                
                arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = avString+" ± "+sdString, progenyAnalysisResultsHoldCount++;
            }
            
            arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "-1", progenyAnalysisResultsHoldCount++;
            arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "-1", progenyAnalysisResultsHoldCount++;
            arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "-1", progenyAnalysisResultsHoldCount++;
            arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "Total", progenyAnalysisResultsHoldCount++;
            
            if (averageTotalDG [counter3] != 0) avEventCount = averageTotalDG [counter3];
            else avEventCount = 0;
            
            avEventIntCount = (int)(avEventCount*1000);
            avEventCount = avEventIntCount/(double)1000;
            
            stringstream extension9;
            extension9 << avEventCount;
            avString = extension9.str();
            
            if (sdTotalDG [counter3] != 0) sdEventCount = sdTotalDG [counter3];
            else sdEventCount = 0;
            
            sdEventIntCount = (int)(sdEventCount*1000);
            sdEventCount = sdEventIntCount/(double)1000;
            
            stringstream extension10;
            extension10 << sdEventCount;
            sdString = extension10.str();
            
            arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = avString+" ± "+sdString, progenyAnalysisResultsHoldCount++;
            
            if (percentMode == 0){
                arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "100", progenyAnalysisResultsHoldCount++;
            }
            else{
                
                if (averagePercentDG [counter3] != 0) avEventCount = averagePercentDG [counter3];
                else avEventCount = 0;
                
                avEventIntCount = (int)(avEventCount*1000);
                avEventCount = avEventIntCount/(double)1000;
                
                stringstream extension11;
                extension11 << avEventCount;
                avString = extension11.str();
                
                if (sdPercentDG [counter3] != 0) sdEventCount = sdPercentDG [counter3];
                else sdEventCount = 0;
                
                sdEventIntCount = (int)(sdEventCount*1000);
                sdEventCount = sdEventIntCount/(double)1000;
                
                stringstream extension12;
                extension12 << sdEventCount;
                sdString = extension12.str();
                
                arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = avString+" ± "+sdString, progenyAnalysisResultsHoldCount++;
            }
            
            if (counter3 != progenyAnalysisRangeHoldCount/3-1){
                arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "-1", progenyAnalysisResultsHoldCount++;
                arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "-1", progenyAnalysisResultsHoldCount++;
                arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "-1", progenyAnalysisResultsHoldCount++;
                arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "-1", progenyAnalysisResultsHoldCount++;
                arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "-1", progenyAnalysisResultsHoldCount++;
                arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "-1", progenyAnalysisResultsHoldCount++;
            }
        }
        
        arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "Total", progenyAnalysisResultsHoldCount++;
        arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = to_string(normalizeHold), progenyAnalysisResultsHoldCount++;
        arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "100", progenyAnalysisResultsHoldCount++;
        arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "", progenyAnalysisResultsHoldCount++;
        arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "", progenyAnalysisResultsHoldCount++;
        arrayProgenyAnalysisResultsHold [progenyAnalysisResultsHoldCount] = "", progenyAnalysisResultsHoldCount++;
        
        for (int counter2 = 0; counter2 < lineageProcessCount+1; counter2++){
            delete [] dataHold [counter2];
        }
        
        delete [] dataHold;
        
        delete [] totalHold;
        delete [] averageHold;
        delete [] sdHold;
        
        for (int counter2 = 0; counter2 < lineageProcessCount+1; counter2++){
            delete [] dataHold2 [counter2];
        }
        
        delete [] dataHold2;
        
        delete [] averagePercentHold;
        delete [] sdPercentHold;
        
        for (int counter2 = 0; counter2 < lineageProcessCount+1; counter2++){
            delete [] dataHoldDG [counter2];
        }
        
        delete [] dataHoldDG;
        
        delete [] totalHoldDG;
        delete [] averageHoldDG;
        delete [] sdHoldDG;
        
        for (int counter2 = 0; counter2 < lineageProcessCount+1; counter2++){
            delete [] dataHoldDG2 [counter2];
        }
        
        delete [] dataHoldDG2;
        
        delete [] totalHoldPercentDG;
        delete [] averagePercentHoldDG;
        delete [] sdPercentHoldDG;
        delete [] averageTotalDG;
        delete [] sdTotalDG;
        delete [] averagePercentDG;
        delete [] sdPercentDG;
    }
}

-(IBAction)percentModeSet:(id)sender{
    if (lineageDataEntryCount != 0){
        if (percentMode == 0){
            percentMode = 1;
            [percentModeDisplay setStringValue:@"All"];
        }
        else{
            
            percentMode = 0;
            [percentModeDisplay setStringValue:@"Ind."];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)createExcelFile:(id)sender{
    if (lineageDataEntryCount != 0){
        if (progenyAnalysisResultsHoldCount != 0){
            string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
            mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Progeny_Analysis";
            mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            DIR *dir;
            struct dirent *dent;
            
            string entry;
            string extractString;
            int maxEntryNo = 0;
            
            dir = opendir(resultSavePath2.c_str());
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("Progeny_Analysis") != -1){
                        extractString = entry.substr(entry.find("PA")+2, entry.find(".txt")-entry.find("PA")-2);
                        
                        if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                    }
                }
                
                closedir(dir);
            }
            
            maxEntryNo++;
            
            string path = resultSavePath2+"/Progeny_Analysis-PA"+to_string(maxEntryNo)+".txt";
            
            [self analysisSet];
            
            string progenyAnalysisString = "";
            
            ofstream oin;
            oin.open(path.c_str(), ios::out | ios::binary);
            
            int *arrayAscIIintData = new int [100], ascIIintDataCount = 0;
            
            ascIIconversion = [[ASCIIconversion alloc] init];
            
            if (sdCalculationHold == 0){
                ascIIstring = "Primary CK Time";
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = to_string(progenyAnalysisTimeEd1Hold);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = "Secondary CK Time";
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = to_string(progenyAnalysisTimeEd2Hold);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                oin.put(13);
                oin.put(10);
                
                for (int counter1 = 0; counter1 < progenyAnalysisResultsHoldCount/6; counter1++){
                    ascIIstring = arrayProgenyAnalysisResultsHold [counter1*6];
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = arrayProgenyAnalysisResultsHold [counter1*6+1];
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = arrayProgenyAnalysisResultsHold [counter1*6+2];
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = arrayProgenyAnalysisResultsHold [counter1*6+3];
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = arrayProgenyAnalysisResultsHold [counter1*6+4];
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = arrayProgenyAnalysisResultsHold [counter1*6+5];
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    oin.put(13);
                    oin.put(10);
                }
            }
            else{
                
                ascIIstring = "Primary CK Time";
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = to_string(progenyAnalysisTimeEd1Hold);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = "Secondary CK Time";
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = to_string(progenyAnalysisTimeEd2Hold);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                oin.put(13);
                oin.put(10);
                
                ascIIstring = "Total AV 1";
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = "Total SD 1";
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = "Percent 1";
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = "Percent SD 1";
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = "Total AV 2";
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = "Total SD 2";
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = "Percent 2";
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = "Percent SD 2";
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                oin.put(13);
                oin.put(10);
                
                for (int counter1 = 0; counter1 < progenyAnalysisResultsHoldCount/6; counter1++){
                    ascIIstring = arrayProgenyAnalysisResultsHold [counter1*6];
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = arrayProgenyAnalysisResultsHold [counter1*6+1];
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = arrayProgenyAnalysisResultsHold [counter1*6+2];
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = arrayProgenyAnalysisResultsHold [counter1*6+3];
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = arrayProgenyAnalysisResultsHold [counter1*6+4];
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = arrayProgenyAnalysisResultsHold [counter1*6+5];
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    oin.put(13);
                    oin.put(10);
                }
            }
            
            delete [] arrayAscIIintData;
            
            oin.close();
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Analysis Performed"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)createExcelFile2:(id)sender{
    if (lineageDataEntryCount != 0){
        if (progenyAnalysisResultsHoldCount != 0){
            string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
            mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Progeny_Analysis";
            mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            DIR *dir;
            struct dirent *dent;
            
            string entry;
            string extractString;
            int maxEntryNo = 0;
            
            dir = opendir(resultSavePath2.c_str());
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("Progeny_Analysis") != -1){
                        extractString = entry.substr(entry.find("PA")+2, entry.find(".txt")-entry.find("PA")-2);
                        
                        if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                    }
                }
                
                closedir(dir);
            }
            
            maxEntryNo++;
            
            string path = resultSavePath2+"/Progeny_Analysis-PA"+to_string(maxEntryNo)+".txt";
            
            int lineageExtractProgenyCount = 0;
            int numberOfToalCells = 0;
            int firstCellGroupCount = 0;
            int firstRangeCount = 0;
            int terminationFlag = 0;
            int chasingCellPosition = 0;
            int endFindFlag = 0;
            int findCellCount = 0;
            int secondCellGroupCount = 0;
            int firstCellGroupListCount = 0;
            int daughterCellListCount = 0;
            int grandDaughterCellListCount = 0;
            int gdFirstDivisionTime = 0;
            int endFindCheck = 0;
            unsigned long lineageEntrySize = 0;
            int lineageEntryNo = 0;
            int headingEntry = 0;
            int maxDisplayCount = 0;
            
            ofstream oin;
            oin.open(path.c_str(), ios::out | ios::binary);
            
            int *arrayAscIIintData = new int [100], ascIIintDataCount = 0;
            
            ascIIconversion = [[ASCIIconversion alloc] init];
            
            for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
                if (arraySelectedLing [counter2] == 1){
                    
                    //for (int counterA = 0; counterA < 1; counterA++){
                    //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<< arrayTableMain [counter2][counterA+counterB];
                    //    cout<<"  arrayTableMain "<<counterA<<endl;
                    //}
                    
                    lineageEntrySize = arrayLineageDataEntryHold [counter2];
                    lineageEntryNo = 0;
                    
                    int *lineageExtractProgeny = new int [lineageEntrySize+10];
                    
                    for (unsigned long counter3 = 0; counter3 < lineageEntrySize/9; counter3++){
                        if (arrayLineageData [counter2][counter3*9+6] > lineageEntryNo){
                            lineageEntryNo = arrayLineageData [counter2][counter3*9+6];
                        }
                    }
                    
                    int *lineageList = new int [lineageEntryNo+10];
                    
                    for (int counter3 = 0; counter3 < lineageEntryNo; counter3++) lineageList [counter3] = 0;
                    
                    for (unsigned long counter3 = 0; counter3 < lineageEntrySize/9; counter3++){
                        lineageList [arrayLineageData [counter2][counter3*9+6]] = 1;
                    }
                    
                    int *lineageTimeOneProgenyNOList = new int [lineageEntryNo+10];
                    
                    for (int counter3 = 0; counter3 < lineageEntryNo+10; counter3++) lineageTimeOneProgenyNOList [counter3] = -1;
                    
                    int maxGDCellNoFind = 0;
                    
                    for (unsigned long counter3 = 0; counter3 < lineageEntrySize/9; counter3++){
                        if (arrayLineageData [counter2][counter3*9+2] == progenyAnalysisTimeEd1Hold){
                            maxGDCellNoFind++;
                        }
                    }
                    
                    if (maxGDCellNoFind > lineageEntryNo) maxDisplayCount = maxGDCellNoFind;
                    else maxDisplayCount = lineageEntryNo;
                    
                    int *lineageGDCellNOList = new int [maxGDCellNoFind+10];
                    int lineageGDCellNOListEntryCount = 0;
                    
                    for (int counter3 = 0; counter3 < maxGDCellNoFind+10; counter3++) lineageGDCellNOList [counter3] = 0;
                    
                    int **lineageRangeGDCellNOList = new int *[progenyAnalysisRangeHoldCount/3+10];
                    
                    for (int counter3 = 0; counter3 < progenyAnalysisRangeHoldCount/3+10; counter3++){
                        lineageRangeGDCellNOList [counter3] = new int [maxGDCellNoFind+10];
                    }
                    
                    for (int counter3 = 0; counter3 < progenyAnalysisRangeHoldCount/3+10; counter3++){
                        for (int counter4 = 0; counter4 < maxGDCellNoFind+10; counter4++){
                            lineageRangeGDCellNOList [counter3][counter4] = 0;
                        }
                    }
                    
                    int *lineageRangeGDCellNOListEntryCount = new int [progenyAnalysisRangeHoldCount/3+10];
                    
                    for (int counter3 = 0; counter3 < progenyAnalysisRangeHoldCount/3+10; counter3++){
                        lineageRangeGDCellNOListEntryCount [counter3] = 0;
                    }
                    
                    //for (int counterA = 0; counterA < lineageEntryNo; counterA++){
                    //    cout<<counterA<<" "<<lineageList [counterA] <<" lineageList"<<endl;
                    //}
                    
                    int *progenyAnalysisSort = new int [progenyAnalysisRangeHoldCount/3+10];
                    
                    for (int counter3 = 0; counter3 < progenyAnalysisRangeHoldCount/3+10; counter3++) progenyAnalysisSort [counter3] = 0;
                    
                    int *progenyAnalysisDGSort = new int [(progenyAnalysisRangeHoldCount/3)*(progenyAnalysisRangeHoldCount/3)+10];
                    
                    for (int counter3 = 0; counter3 < (progenyAnalysisRangeHoldCount/3)*(progenyAnalysisRangeHoldCount/3)+10; counter3++) progenyAnalysisDGSort [counter3] = 0;
                    
                    for (int counter3 = 1; counter3 <= lineageEntryNo; counter3++){
                        if (lineageList [counter3] == 1){
                            lineageExtractProgenyCount = 0;
                            
                            numberOfToalCells = 0;
                            
                            for (unsigned long counter4 = 0; counter4 < lineageEntrySize/9; counter4++){
                                if (arrayLineageData [counter2][counter4*9+6] == counter3){
                                    lineageExtractProgeny [lineageExtractProgenyCount] = arrayLineageData [counter2][counter4*9], lineageExtractProgenyCount++;
                                    lineageExtractProgeny [lineageExtractProgenyCount] = arrayLineageData [counter2][counter4*9+1], lineageExtractProgenyCount++;
                                    lineageExtractProgeny [lineageExtractProgenyCount] = arrayLineageData [counter2][counter4*9+2], lineageExtractProgenyCount++;
                                    lineageExtractProgeny [lineageExtractProgenyCount] = arrayLineageData [counter2][counter4*9+3], lineageExtractProgenyCount++;
                                    lineageExtractProgeny [lineageExtractProgenyCount] = arrayLineageData [counter2][counter4*9+4], lineageExtractProgenyCount++;
                                    lineageExtractProgeny [lineageExtractProgenyCount] = arrayLineageData [counter2][counter4*9+5], lineageExtractProgenyCount++;
                                    lineageExtractProgeny [lineageExtractProgenyCount] = arrayLineageData [counter2][counter4*9+6], lineageExtractProgenyCount++;
                                    lineageExtractProgeny [lineageExtractProgenyCount] = arrayLineageData [counter2][counter4*9+7], lineageExtractProgenyCount++;
                                    
                                    if (arrayLineageData [counter2][counter4*9+3] == 1 || arrayLineageData [counter2][counter4*9+3] == 31 || arrayLineageData [counter2][counter4*9+3] == 41 || arrayLineageData [counter2][counter4*9+3] == 51){
                                        numberOfToalCells++;
                                    }
                                }
                            }
                            
                            //for (int counterA = 0; counterA < lineageExtractProgenyCount/8; counterA++){
                            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lineageExtractProgeny [counterA*8+counterB];
                            //    cout<<" lineageExtractProgeny "<<counterA<<endl;
                            //}
                            
                            int *firstCellGroup = new int [numberOfToalCells+10];
                            firstCellGroupCount = 0;
                            firstRangeCount = 0;
                            
                            if (progenyOfMDInclude == 1){
                                for (int counter4 = 0; counter4 < lineageExtractProgenyCount/8; counter4++){
                                    if (lineageExtractProgeny [counter4*8+2] == progenyAnalysisTimeEd1Hold){
                                        firstCellGroup [firstCellGroupCount] = lineageExtractProgeny [counter4*8+5], firstCellGroupCount++;
                                        
                                        if (lineageTimeOneProgenyNOList [counter3] != -1) lineageTimeOneProgenyNOList [counter3]++;
                                        else lineageTimeOneProgenyNOList [counter3] = 1;
                                    }
                                }
                            }
                            else{
                                
                                int *firstCellGroupList = new int [numberOfToalCells+10];
                                firstCellGroupListCount = 0;
                                
                                for (int counter4 = 0; counter4 < lineageExtractProgenyCount/8; counter4++){
                                    if (lineageExtractProgeny [counter4*8+2] == progenyAnalysisTimeEd1Hold){
                                        firstCellGroupList [firstCellGroupListCount] = lineageExtractProgeny [counter4*8+5], firstCellGroupListCount++;
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < firstCellGroupListCount; counterA++){
                                //    cout<<counterA<<" "<<firstCellGroupList [counterA]<<" firstCellGroupList"<<endl;
                                //}
                                
                                for (int counter4 = 0; counter4 < firstCellGroupListCount; counter4++){
                                    for (int counter5 = 0; counter5 < lineageExtractProgenyCount/8; counter5++){
                                        if (lineageExtractProgeny [counter5*8+3] == 31 && lineageExtractProgeny [counter5*8+5] == firstCellGroupList [counter4]){
                                            firstCellGroup [firstCellGroupCount] = firstCellGroupList [counter4], firstCellGroupCount++;
                                            
                                            if (lineageTimeOneProgenyNOList [counter3] != -1) lineageTimeOneProgenyNOList [counter3]++;
                                            else lineageTimeOneProgenyNOList [counter3] = 1;
                                            break;
                                        }
                                    }
                                }
                                
                                delete [] firstCellGroupList;
                            }
                            
                            //for (int counterA = 0; counterA < firstCellGroupCount; counterA++){
                            //    cout<<counterA<<" "<<firstCellGroup [counterA]<<" firstCellGroup"<<endl;
                            //}
                            
                            if (firstCellGroupCount != 0){
                                for (int counter4 = 0; counter4 < progenyAnalysisRangeHoldCount/3; counter4++){
                                    if (firstCellGroupCount >= arrayProgenyAnalysisRangeHold [counter4*3+1] && firstCellGroupCount <= arrayProgenyAnalysisRangeHold [counter4*3+2]){
                                        progenyAnalysisSort [counter4]++;
                                        firstRangeCount = counter4;
                                        break;
                                    }
                                }
                            }
                            else{
                                
                                progenyAnalysisSort [0]++;
                                firstRangeCount = 0;
                            }
                            
                            int *daughterCellList = new int [numberOfToalCells+10];
                            daughterCellListCount = 0;
                            
                            if (progenyOfMDInclude == 1){
                                for (int counter4 = 0; counter4 < lineageExtractProgenyCount/8; counter4++){
                                    if ((lineageExtractProgeny [counter4*8+3] == 31 || lineageExtractProgeny [counter4*8+3] == 41 || lineageExtractProgeny [counter4*8+3] == 51) && lineageExtractProgeny [counter4*8+4] == 0){
                                        daughterCellList [daughterCellListCount] = lineageExtractProgeny [counter4*8+5], daughterCellListCount++;
                                    }
                                }
                            }
                            else{
                                
                                for (int counter4 = 0; counter4 < lineageExtractProgenyCount/8; counter4++){
                                    if (lineageExtractProgeny [counter4*8+3] == 31 && lineageExtractProgeny [counter4*8+4] == 0){
                                        daughterCellList [daughterCellListCount] = lineageExtractProgeny [counter4*8+5], daughterCellListCount++;
                                    }
                                }
                            }
                            
                            int *grandDaughterCellList = new int [daughterCellListCount*4];
                            grandDaughterCellListCount = 0;
                            
                            if (progenyOfMDInclude == 1){
                                for (int counter4 = 0; counter4 < daughterCellListCount; counter4++){
                                    for (int counter5 = 0; counter5 < lineageExtractProgenyCount/8; counter5++){
                                        if ((lineageExtractProgeny [counter5*8+3] == 31 || lineageExtractProgeny [counter5*8+3] == 41 || lineageExtractProgeny [counter5*8+3] == 51) && lineageExtractProgeny [counter5*8+4] == daughterCellList [counter4]){
                                            grandDaughterCellList [grandDaughterCellListCount] = lineageExtractProgeny [counter5*8+5], grandDaughterCellListCount++;
                                        }
                                    }
                                }
                            }
                            else{
                                
                                for (int counter4 = 0; counter4 < daughterCellListCount; counter4++){
                                    for (int counter5 = 0; counter5 < lineageExtractProgenyCount/8; counter5++){
                                        if (lineageExtractProgeny [counter5*8+3] == 31 && lineageExtractProgeny [counter5*8+4] == daughterCellList [counter4]){
                                            grandDaughterCellList [grandDaughterCellListCount] = lineageExtractProgeny [counter5*8+5], grandDaughterCellListCount++;
                                        }
                                    }
                                }
                            }
                            
                            delete [] daughterCellList;
                            
                            int *secondCellGroup = new int [numberOfToalCells+10];
                            
                            for (int counter4 = 0; counter4 < grandDaughterCellListCount; counter4++){
                                for (int counter5 = 0; counter5 < numberOfToalCells+10; counter5++) secondCellGroup [counter5] = -1;
                                
                                secondCellGroupCount = 0;
                                gdFirstDivisionTime = 0;
                                
                                secondCellGroup [secondCellGroupCount] = grandDaughterCellList [counter4], secondCellGroupCount++;
                                
                                if (progenyOfMDInclude == 1){
                                    for (int counter5 = 0; counter5 < lineageExtractProgenyCount/8; counter5++){
                                        if ((lineageExtractProgeny [counter5*8+3] == 32 || lineageExtractProgeny [counter5*8+3] == 42 || lineageExtractProgeny [counter5*8+3] == 52) && lineageExtractProgeny [counter5*8+5] == grandDaughterCellList [counter4]){
                                            gdFirstDivisionTime = lineageExtractProgeny [counter5*8+2];
                                            break;
                                        }
                                    }
                                }
                                else{
                                    
                                    for (int counter5 = 0; counter5 < lineageExtractProgenyCount/8; counter5++){
                                        if (lineageExtractProgeny [counter5*8+3] == 32 && lineageExtractProgeny [counter5*8+5] == grandDaughterCellList [counter4]){
                                            gdFirstDivisionTime = lineageExtractProgeny [counter5*8+2];
                                            break;
                                        }
                                    }
                                }
                                
                                if (gdFirstDivisionTime != 0){
                                    findCellCount = 0;
                                    
                                    do{
                                        
                                        terminationFlag = 0;
                                        endFindFlag = 0;
                                        chasingCellPosition = -1;
                                        
                                        for (int counter5 = 0; counter5 < secondCellGroupCount; counter5++){
                                            if (secondCellGroup [counter5] != -1){
                                                terminationFlag = 1;
                                                chasingCellPosition = counter5;
                                                break;
                                            }
                                        }
                                        
                                        if (chasingCellPosition != -1){
                                            if (progenyOfMDInclude == 1){
                                                for (int counter5 = 0; counter5 < lineageExtractProgenyCount/8; counter5++){
                                                    if (lineageExtractProgeny [counter5*8+5] == secondCellGroup [chasingCellPosition] && lineageExtractProgeny [counter5*8+2] == progenyAnalysisTimeEd2Hold+gdFirstDivisionTime){
                                                        secondCellGroup [chasingCellPosition] = -1;
                                                        endFindFlag = 1;
                                                        findCellCount++;
                                                    }
                                                }
                                            }
                                            else{
                                                
                                                endFindCheck = 0;
                                                
                                                for (int counter5 = 0; counter5 < lineageExtractProgenyCount/8; counter5++){
                                                    if (lineageExtractProgeny [counter5*8+5] == secondCellGroup [chasingCellPosition] && lineageExtractProgeny [counter5*8+2] == progenyAnalysisTimeEd2Hold+gdFirstDivisionTime){
                                                        endFindCheck = 1;
                                                        endFindFlag = 1;
                                                    }
                                                }
                                                
                                                if (endFindCheck == 1){
                                                    for (int counter5 = 0; counter5 < lineageExtractProgenyCount/8; counter5++){
                                                        if (lineageExtractProgeny [counter5*8+3] == 31 && lineageExtractProgeny [counter5*8+5] == secondCellGroup [chasingCellPosition]){
                                                            secondCellGroup [chasingCellPosition] = -1;
                                                            findCellCount++;
                                                            break;
                                                        }
                                                        else if ((lineageExtractProgeny [counter5*8+3] == 41 || lineageExtractProgeny [counter5*8+3] == 51) && lineageExtractProgeny [counter5*8+5] == secondCellGroup [chasingCellPosition]){
                                                            secondCellGroup [chasingCellPosition] = -1;
                                                        }
                                                    }
                                                }
                                            }
                                            
                                            if (endFindFlag == 0){
                                                for (int counter5 = 0; counter5 < lineageExtractProgenyCount/8; counter5++){
                                                    if (lineageExtractProgeny [counter5*8+4] == secondCellGroup [chasingCellPosition] && (lineageExtractProgeny [counter5*8+3] == 31 || lineageExtractProgeny [counter5*8+3] == 41 || lineageExtractProgeny [counter5*8+3] == 51)){
                                                        secondCellGroup [secondCellGroupCount] = lineageExtractProgeny [counter5*8+5], secondCellGroupCount++;
                                                    }
                                                }
                                                
                                                secondCellGroup [chasingCellPosition] = -1;
                                            }
                                        }
                                        
                                    } while (terminationFlag == 1);
                                    
                                    if (findCellCount != 0){
                                        for (int counter5 = 0; counter5 < progenyAnalysisRangeHoldCount/3; counter5++){
                                            if (findCellCount >= arrayProgenyAnalysisRangeHold [counter5*3+1] && findCellCount <= arrayProgenyAnalysisRangeHold [counter5*3+2]){
                                                progenyAnalysisDGSort [firstRangeCount*(progenyAnalysisRangeHoldCount/3)+counter5]++;
                                                lineageGDCellNOList [lineageGDCellNOListEntryCount] = findCellCount, lineageGDCellNOListEntryCount++;
                                                
                                                lineageRangeGDCellNOList [firstRangeCount][lineageRangeGDCellNOListEntryCount [firstRangeCount]] = findCellCount, lineageRangeGDCellNOListEntryCount [firstRangeCount]++;
                                                break;
                                            }
                                        }
                                    }
                                    else progenyAnalysisDGSort [firstRangeCount*(progenyAnalysisRangeHoldCount/3)]++;
                                }
                                else progenyAnalysisDGSort [firstRangeCount*(progenyAnalysisRangeHoldCount/3)] = 0;
                            }
                            
                            delete [] firstCellGroup;
                            delete [] secondCellGroup;
                            delete [] grandDaughterCellList;
                        }
                    }
                    
                    if (headingEntry == 0){
                        ascIIstring = "ID-Treat";
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                        
                        oin.put(9);
                        
                        for (int counter3 = 1; counter3 <= maxDisplayCount; counter3++){
                            ascIIstring = to_string(counter3);
                            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                            
                            oin.put(9);
                        }
                        
                        oin.put(13);
                        oin.put(10);
                        
                        headingEntry = 1;
                    }
                    
                    ascIIstring = arrayTableMain [counter2][3]+" "+arrayTableMain [counter2][4];
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = "Progenitor Cells";
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = to_string(progenyAnalysisTimeEd1Hold);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    for (int counter3 = 3; counter3 <= maxDisplayCount; counter3++){
                        ascIIstring = " ";
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                    }
                    
                    oin.put(13);
                    oin.put(10);
                    
                    ascIIstring = " ";
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                    
                    oin.put(9);
                    
                    for (int counter4 = 1; counter4 <= maxDisplayCount; counter4++){
                        if (lineageEntryNo >= counter4){
                            if (lineageTimeOneProgenyNOList [counter4] != -1){
                                ascIIstring = to_string(lineageTimeOneProgenyNOList [counter4]);
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter5 = 0; counter5 < ascIIintDataCount; counter5++) oin.put((char)arrayAscIIintData [counter5]);
                                
                                oin.put(9);
                            }
                        }
                    }
                    
                    oin.put(13);
                    oin.put(10);
                    
                    ascIIstring = "GD Cells Total";
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = to_string(progenyAnalysisTimeEd1Hold);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    for (int counter3 = 3; counter3 <= maxDisplayCount; counter3++){
                        ascIIstring = " ";
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                    }
                    
                    oin.put(13);
                    oin.put(10);
                    
                    ascIIstring = " ";
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                    
                    oin.put(9);
                    
                    for (int counter4 = 0; counter4 <= maxDisplayCount; counter4++){
                        if (lineageGDCellNOListEntryCount > counter4){
                            ascIIstring = to_string(lineageGDCellNOList [counter4]);
                            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                            
                            for (int counter5 = 0; counter5 < ascIIintDataCount; counter5++) oin.put((char)arrayAscIIintData [counter5]);
                            
                            oin.put(9);
                        }
                    }
                    
                    oin.put(13);
                    oin.put(10);
                    
                    for (int counter3 = 0; counter3 < progenyAnalysisRangeHoldCount/3; counter3++){
                        if (100000000 != arrayProgenyAnalysisRangeHold [counter3*3+2]){
                            ascIIstring = "GD Cells "+to_string(arrayProgenyAnalysisRangeHold [counter3*3+1])+"-"+to_string(arrayProgenyAnalysisRangeHold [counter3*3+2]);
                        }
                        else ascIIstring = "GD Cells >= "+to_string(arrayProgenyAnalysisRangeHold [counter3*3+1]);
                        
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                        
                        for (int counter4 = 1; counter4 <= maxDisplayCount; counter4++){
                            ascIIstring = " ";
                            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                            
                            for (int counter5 = 0; counter5 < ascIIintDataCount; counter5++) oin.put((char)arrayAscIIintData [counter5]);
                            
                            oin.put(9);
                        }
                        
                        oin.put(13);
                        oin.put(10);
                        
                        ascIIstring = " ";
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                        
                        oin.put(13);
                        oin.put(10);
                        
                        for (int counter4 = 0; counter4 <= maxDisplayCount; counter4++){
                            if (lineageRangeGDCellNOListEntryCount [counter3] > counter4){
                                ascIIstring = to_string(lineageRangeGDCellNOList [counter3][counter4]);
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter5 = 0; counter5 < ascIIintDataCount; counter5++) oin.put((char)arrayAscIIintData [counter5]);
                                
                                oin.put(9);
                            }
                        }
                        
                        oin.put(13);
                        oin.put(10);
                        
                        for (int counter4 = 0; counter4 <= maxDisplayCount; counter4++){
                            ascIIstring = " ";
                            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                            
                            for (int counter5 = 0; counter5 < ascIIintDataCount; counter5++) oin.put((char)arrayAscIIintData [counter5]);
                            
                            oin.put(9);
                        }
                        
                        oin.put(13);
                        oin.put(10);
                    }
                    
                    for (int counter4 = 0; counter4 <= maxDisplayCount; counter4++){
                        ascIIstring = " ";
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter5 = 0; counter5 < ascIIintDataCount; counter5++) oin.put((char)arrayAscIIintData [counter5]);
                        
                        oin.put(9);
                    }
                    
                    oin.put(13);
                    oin.put(10);
                    
                    delete [] lineageExtractProgeny;
                    delete [] lineageList;
                    delete [] lineageTimeOneProgenyNOList;
                    delete [] progenyAnalysisSort;
                    delete [] progenyAnalysisDGSort;
                    
                    for (int counter3 = 0; counter3 < progenyAnalysisRangeHoldCount/3+10; counter3++){
                        delete [] lineageRangeGDCellNOList [counter3];
                    }
                    
                    delete [] lineageRangeGDCellNOList;
                    delete [] lineageRangeGDCellNOListEntryCount;
                }
            }
            
            oin.close();
            
            delete [] arrayAscIIintData;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Analysis Performed"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)sdCalculationHoldSet:(id)sender{
    if (lineageDataEntryCount != 0){
        if (sdCalculationHold == 0){
            sdCalculationHold = 1;
            [sdModeDisplay setStringValue:@"Yes"];
        }
        else{
            
            sdCalculationHold = 0;
            [sdModeDisplay setStringValue:@"No"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)progenyOfMDIncludeSet:(id)sender{
    if (lineageDataEntryCount != 0){
        if (progenyOfMDInclude == 0){
            progenyOfMDInclude = 1;
            [progenyOfMDIncludeDisplay setStringValue:@"Inc."];
        }
        else{
            
            progenyOfMDInclude = 0;
            [progenyOfMDIncludeDisplay setStringValue:@"Exc."];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)closeWindow:(id)sender{
    [progenyAnalysisProgenyWindow orderOut:self];
    progenyAnalysisWindowOperation = 2;
    
    progenyAnalysisProgenyTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
}

-(void)reDisplayWindow{
    if (progenyAnalysisWindowOperation == 3){
        [progenyAnalysisProgenyWindow makeKeyAndOrderFront:self];
        progenyAnalysisWindowOperation = 1;
        [progenyAnalysisProgenyTimer invalidate];
    }
}

-(void)lineageFluorescentDataTypeUpDate{
    string **arrayLineageFluorescentDataTypeTemp = new string *[lineageFluorescentDataTypeEntryLimit];
    
    for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryLimit; counter1++){
        arrayLineageFluorescentDataTypeTemp [counter1] = new string [9];
    }
    
    int lineageFluorescentDataTypeEntryLimitTemp = lineageFluorescentDataTypeEntryLimit;
    int lineageFluorescentEntryCount = 0;
    
    for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryCount; counter1++){
        for (int counter2 = 0; counter2 < 8; counter2++){
            arrayLineageFluorescentDataTypeTemp [lineageFluorescentEntryCount][counter2] = arrayLineageFluorescentDataType [counter1][counter2];
        }
        
        lineageFluorescentEntryCount++;
    }
    
    for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryLimit; counter1++){
        delete [] arrayLineageFluorescentDataType [counter1];
    }
    
    delete [] arrayLineageFluorescentDataType;
    
    arrayLineageFluorescentDataType = new string *[lineageFluorescentDataTypeEntryLimit+320];
    
    for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryLimit+320; counter1++){
        arrayLineageFluorescentDataType [counter1] = new string [9];
    }
    
    lineageFluorescentDataTypeEntryLimit = lineageFluorescentDataTypeEntryLimit+320;
    lineageFluorescentDataTypeEntryCount = 0;
    
    for (int counter1 = 0; counter1 < lineageFluorescentEntryCount; counter1++){
        for (int counter2 = 0; counter2 < 8; counter2++){
            arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][counter2] = arrayLineageFluorescentDataTypeTemp [counter1][counter2];
        }
        
        lineageFluorescentDataTypeEntryCount++;
    }
    
    for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryLimitTemp; counter1++){
        delete [] arrayLineageFluorescentDataTypeTemp [counter1];
    }
    
    delete [] arrayLineageFluorescentDataTypeTemp;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToProgenyAnalysisController object:nil];
}

@end
