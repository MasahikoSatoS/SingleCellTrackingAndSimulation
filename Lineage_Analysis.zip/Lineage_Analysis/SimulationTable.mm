//
//  SimulationTable.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2020-10-29.
//

#import "SimulationTable.h"

NSString *notificationToSimulationTable = @"notificationExecuteSimTable";

@implementation SimulationTable

-(id)init{
    self = [super init];
    
    if (self != nil){
        simOperationTableCount = 0;
        rowSimOperationTable = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToSimulationTable object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    [simulationTable setDataSource:self];
    [simulationTable reloadData];
}

-(int)numberOfRowsInTableView:(NSTableView *)aTableView{
    int tableViewContent = simListHoldCount/2;
    return tableViewContent;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    NSAttributedString *attrStr;
    
    if (simulationOperation != 0){
        string displayData1 = arraySimListHold [rowIndex*2];
        string displayData2 = arraySimListHold [rowIndex*2+1];
        
        displayData2 = displayData2.substr(displayData2.find("-")+1);
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData2.c_str()) attributes:attributes];
        }
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    else{
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    
    return attrStr;
}

-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex{
    simOperationTableCount++;
    simOperationTableCurrentRow = rowIndex;
    
    if (simOperationTableCount == 2){
        if (upLoadingProgress == 0){
            simOperationTableCurrentRow = rowSimOperationTable;
            
            string displayData1 = arraySimListHold [simOperationTableCurrentRow*2];
            string displayData2 = arraySimListHold [simOperationTableCurrentRow*2+1];
            
            [currentNameDisplay setStringValue:@(displayData1.c_str())];
            [currentTreatDisplay setStringValue:@(displayData2.c_str())];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Uploading In Progress"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        if (upLoadingProgress == 0){
            simOperationTableCurrentRow = rowIndex;
            
            string displayData1 = arraySimListHold [simOperationTableCurrentRow*2];
            string displayData2 = arraySimListHold [simOperationTableCurrentRow*2+1];
            
            [currentNameDisplay setStringValue:@(displayData1.c_str())];
            [currentTreatDisplay setStringValue:@(displayData2.c_str())];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Uploading In Progress"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    
    return YES;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToSimulationTable object:nil];
}

@end
