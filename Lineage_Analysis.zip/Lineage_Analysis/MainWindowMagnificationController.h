//
//  MainWindowMagnificationController.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2017-12-05.
//
//

#ifndef MAINWINDOWMAGNIFICATIONCONTROLLER_H
#define MAINWINDOWMAGNIFICATIONCONTROLLER_H
#import "Controller.h" 
#endif

@interface MainWindowMagnificationController : NSObject{
    IBOutlet NSTextField *optondisplay;
    IBOutlet NSTextField *lowXlowDisplay;
    IBOutlet NSTextField *highXHighDisplay;
    IBOutlet NSTextField *lowXHighDisplay;
    IBOutlet NSTextField *valueUKDisplay;
    IBOutlet NSTextField *drawingOptionDisplay;
    IBOutlet NSTextField *unknownDisplay;
    IBOutlet NSTextField *priorityNDDisplay;
    
    IBOutlet NSStepper *stepperLowLow;
    IBOutlet NSStepper *stepperHighHigh;
    IBOutlet NSStepper *stepperLowHigh;
    IBOutlet NSStepper *stepperValueUK;
    
    IBOutlet NSWindow *mainWindowMagWindow;
    
    NSWindowController *mainWindowMagController;
    
    NSTimer *mainWindowMagTimer;
}

-(id)init;
-(void)dealloc;
-(void)reDisplayWindow;

-(IBAction)closeWindow:(id)sender;

-(IBAction)stepperActionLowXLow:(id)sender;
-(IBAction)stepperActionHighXHigh:(id)sender;
-(IBAction)stepperActionLowXHigh:(id)sender;
-(IBAction)stepperActionValueUK:(id)sender;

-(IBAction)optionLineageSelect:(id)sender;
-(IBAction)optionDrawingSelect:(id)sender;
-(IBAction)unknownSelect:(id)sender;
-(IBAction)priorityNDSelect:(id)sender;

@end
