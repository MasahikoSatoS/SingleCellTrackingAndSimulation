//
//  LineageDataTable.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 9/7/16.
//
//

#import "LineageDataTable.h"

NSString *notificationToLineageDataTable = @"notificationExecuteLineageDataTable";

@implementation LineageDataTable

-(id)init{
    self = [super init];
    
    if (self != nil){
        tableViewLTCall = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToLineageDataTable object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    [tableViewLTList setDataSource:self];
    [tableViewLTList reloadData];
    
    lineageDataTableTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(display) userInfo:nil repeats:YES];
}

-(void)display{
    if (tableCallLTCount == 1){
        tableCallLTCount = 0;
        rowIndexLTHold = tableCurrentLTRowHold;
    }
    
    if (tableCallLTCount > 1) tableCallLTCount = 0;
    
    if (tableViewLTCall == 1){
        tableViewLTCall = 0;
        [tableViewLTList reloadData];
    }
}

-(int)numberOfRowsInTableView:(NSTableView *)aTableView{
    int tableViewContent = lineageDataEntryCount;
    return tableViewContent;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    NSAttributedString *attrStr;
    
    if (initialArraySet == 1){
        string displayData1 = arrayLineageDataType [rowIndex][0];
        string displayData2 = arrayLineageDataType [rowIndex][1];
        string displayData3 = arrayLineageDataType [rowIndex][2];
        string displayData4 = arrayLineageDataType [rowIndex][3];
        string displayData5 = arrayLineageDataType [rowIndex][4];
        string displayData6 = arrayLineageDataType [rowIndex][5];
        string displayData7 = arrayLineageDataType [rowIndex][6];
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        
        [attributes setObject:[NSFont boldSystemFontOfSize:10] forKey:NSFontAttributeName];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]){
            [attributes setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData2.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL3"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData3.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL4"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData4.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL5"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData5.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL6"]){
            [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData6.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL7"]){
            [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData7.c_str()) attributes:attributes];
        }
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    else{
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL3"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL4"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL5"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL6"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL7"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    
    return attrStr;
}

-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex{
    tableCallLTCount++;
    tableCurrentLTRowHold = rowIndex;
    
    if (tableCallLTCount == 2){
        if (upLoadingProgress == 0){
            tableCurrentLTRowHold = rowIndexLTHold;
            noOfFluorescentDisplay = atoi(arrayLineageDataType [tableCurrentLTRowHold][0].c_str());
            
            displayEntryNo = 0;
            
            for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryCount; counter1++){
                if (atoi(arrayLineageFluorescentDataType [counter1][0].c_str()) == noOfFluorescentDisplay){
                    displayEntryNo++;
                }
            }
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLineageDataFluorescentType object:self];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Uploading In Progress"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else if (tableCallLTCount == 1){
        if (upLoadingProgress == 0){
            tableCurrentLTRowHold = rowIndex;
            noOfFluorescentDisplay = atoi(arrayLineageDataType [tableCurrentLTRowHold][0].c_str());
            
            displayEntryNo = 0;
            
            for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryCount; counter1++){
                if (atoi(arrayLineageFluorescentDataType [counter1][0].c_str()) == noOfFluorescentDisplay){
                    displayEntryNo++;
                }
            }
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLineageDataFluorescentType object:self];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Uploading In Progress"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    
    return YES;
}

-(void)tableView:(NSTableView *)aTableView setObjectValue:(id)anObject forTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    NSString *columnIdentifier = [aTableColumn identifier];
    NSString *objectInfo = anObject;
    
    string stringExtract;
    
    if (upLoadingProgress == 0){
        if ([columnIdentifier isEqualToString:@"COL6"] && lineageDataEntryCount > rowIndex){
            string nameCheckString = [objectInfo UTF8String];
            
            if (atoi(nameCheckString.c_str()) > 0 && atoi(nameCheckString.c_str()) <= 30){
                int valueTemp = atoi(nameCheckString.c_str());
                arrayLineageDataType [rowIndex][5] = to_string(valueTemp);
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else if ([columnIdentifier isEqualToString:@"COL7"] && lineageDataEntryCount > rowIndex){
            string nameCheckString = [objectInfo UTF8String];
            
            if ((int)nameCheckString.length() <= 30){
                arrayLineageDataType [rowIndex][6] = nameCheckString;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        
        tableViewLTCall = 1;
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)dealloc{
    if (lineageDataTableTimer) [lineageDataTableTimer invalidate];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToLineageDataTable object:nil];
}

@end
