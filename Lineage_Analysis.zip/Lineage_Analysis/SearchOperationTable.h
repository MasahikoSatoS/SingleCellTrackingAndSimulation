//
//  SearchOperationTable.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 11/13/16.
//
//

#ifndef SEARCHOPERATIONTABLE_H
#define SEARCHOPERATIONTABLE_H
#import "Controller.h" 
#endif

@interface SearchOperationTable : NSObject <NSTableViewDataSource>{
    IBOutlet NSTableView *timeViewSearchTable;
}

-(id)init;
-(void)dealloc;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;
-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex;

@end
