//
//  EndTrimTable2.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2017-05-31.
//
//

#ifndef ENDTRIMTABLE2_H
#define ENDTRIMTABLE2_H
#import "Controller.h" 
#endif

@interface EndTrimTable2 : NSObject <NSTableViewDataSource>{
    IBOutlet NSTableView *endTrimTable2;
}

-(id)init;
-(void)dealloc;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;
-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex;

@end
