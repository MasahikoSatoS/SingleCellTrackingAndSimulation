//
//  CellDivisionDisplay.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 12/15/16.
//
//

#import "CellDivisionDisplay.h"

NSString *notificationToCellDivisionDisplay = @"notificationExecuteCellDivisionDisplay";

@implementation CellDivisionDisplay

-(id)initWithFrame:(NSRect)frame{
    self = [super initWithFrame:frame];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToCellDivisionDisplay object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    [self setNeedsDisplay:YES];
}

-(void)mouseDown:(NSEvent *)event{
    NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
    
    if (upLoadingProgress == 0){
        if (clickPoint.x > 718 && clickPoint.x < 760 && clickPoint.y >573 && clickPoint.y < 587){
            if (horizontalScaleHighDivisionHold-horizontalScaleLowDivisionHold < 100){
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Check Range"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
                
                [self setNeedsDisplay:YES];
            }
        }
        
        if (clickPoint.x > 668 && clickPoint.x < 710 && clickPoint.y >573 && clickPoint.y < 587){
            exportFlag6 = 1;
            
            string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
            mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Cell_Division";
            mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            DIR *dir;
            struct dirent *dent;
            
            string entry;
            string extractString;
            int maxEntryNo = 0;
            
            dir = opendir(resultSavePath2.c_str());
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("Cell_Division") != -1){
                        extractString = entry.substr(entry.find("CD")+2, entry.find(".tif")-entry.find("CD")-2);
                        
                        if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                    }
                }
                
                closedir(dir);
            }
            
            maxEntryNo++;
            
            exportResultPath = resultSavePath2+"/Cell_Division-CD"+to_string(maxEntryNo)+".tif";
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
            
            [self setNeedsDisplay:YES];
        }
        
        if (exportFlag6 == 2){
            exportFlag6 = 0;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
            
            [self setNeedsDisplay:YES];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(BOOL)acceptsFirstResponder{
    return YES;
}

-(void)drawRect:(NSRect)rect{
    if (exportFlag6 == 0){
        [[NSColor whiteColor] set];
        
        NSBezierPath *path;
        path = [NSBezierPath bezierPathWithRect: NSMakeRect(0, 0, 767, 591)];
        [path fill];
        
        //----Re-load----
        [NSBezierPath setDefaultLineWidth:1];
        
        NSPoint pointA;
        NSAttributedString *attrStrA;
        NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
        
        [[NSColor blueColor] set];
        path = [NSBezierPath bezierPathWithRect: NSMakeRect(718, 573, 42, 14)];
        [path stroke];
        
        string reloadString = "Reload";
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(reloadString.c_str()) attributes:attributesA];
        pointA.x = 720;
        pointA.y = 573;
        [attrStrA drawAtPoint:pointA];
        
        [[NSColor blueColor] set];
        path = [NSBezierPath bezierPathWithRect: NSMakeRect(668, 573, 42, 14)];
        [path stroke];
        
        reloadString = "Export";
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(reloadString.c_str()) attributes:attributesA];
        pointA.x = 670;
        pointA.y = 573;
        [attrStrA drawAtPoint:pointA];
        
        int entryNumberCount = 0;
        int maxEntry = 0;
        
        int *entryNumberTempHold = new int [40];
        int entryNumberTempHoldCount = 0;
        
        for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
            if (arraySelectedLing [counter2] == 1 && maxEntry < 8){
                entryNumberCount++;
                entryNumberTempHold [entryNumberTempHoldCount] = counter2, entryNumberTempHoldCount++;
                
                maxEntry++;
            }
        }
        
        int displayItem1 = 0;
        int displayItem2 = 0;
        int displayItem3 = 0;
        int displayItem4 = 0;
        int displayItem5 = 0;
        int displayItem6 = 0;
        int displayItem7 = 0;
        int displayItem8 = 0;
        
        if (entryNumberCount == 1) displayItem1 = 1;
        else if (entryNumberCount == 2){
            displayItem1 = 2;
            displayItem2 = 2;
        }
        else if (entryNumberCount == 3){
            displayItem1 = 3;
            displayItem2 = 3;
            displayItem3 = 3;
        }
        else if (entryNumberCount == 4){
            displayItem1 = 4;
            displayItem2 = 4;
            displayItem3 = 4;
            displayItem4 = 4;
        }
        else if (entryNumberCount == 5){
            displayItem1 = 5;
            displayItem2 = 5;
            displayItem3 = 5;
            displayItem4 = 5;
            displayItem5 = 5;
        }
        else if (entryNumberCount == 6){
            displayItem1 = 6;
            displayItem2 = 6;
            displayItem3 = 6;
            displayItem4 = 6;
            displayItem5 = 6;
            displayItem6 = 6;
        }
        else if (entryNumberCount == 7){
            displayItem1 = 7;
            displayItem2 = 7;
            displayItem3 = 7;
            displayItem4 = 7;
            displayItem5 = 7;
            displayItem6 = 7;
            displayItem7 = 7;
        }
        else if (entryNumberCount == 8){
            displayItem1 = 8;
            displayItem2 = 8;
            displayItem3 = 8;
            displayItem4 = 8;
            displayItem5 = 8;
            displayItem6 = 8;
            displayItem7 = 8;
            displayItem8 = 8;
        }
        
        int displayFlag = 0;
        int xStart = 0;
        int yStart = 0;
        int horizontalTime = 0;
        int lengthDivisionInt = 0;
        int numberOfDivision = 0;
        int lengthDivisionInt2 = 0;
        int numberOfDivision2 = 0;
        int lowestXPosition = 1000;
        int actualTime = 0;
        int xDimension = 0;
        int yDimension = 0;
        int fontSize = 0;
        int horizontalLabelShift = 0;
        int horizontalNumberShift = 0;
        
        double lengthDivision = 0;
        double lengthPix = 0;
        double sift = 0;
        double lengthDivision2 = 0;
        double lengthPix2 = 0;
        double horizontalTimeHr = 0;
        
        string treatNameGR;
        string timeString;
        
        NSPoint positionAA;
        NSPoint positionBB;
        NSPoint pointA2;
        
        CGFloat size2 = 0;
        
        for (int counter1 = 0; counter1 < displayItem1; counter1++){
            displayFlag = 0;
            horizontalLabelShift = 25;
            horizontalNumberShift = 20;
            
            if (counter1 == 0 && displayItem1 == 1){
                displayFlag = 1;
                xStart = 80;
                yStart = 100;
                xDimension = 650;
                yDimension = 350;
                fontSize = 12;
                horizontalLabelShift = 40;
            }
            else if (counter1 == 0 && displayItem1 == 2){
                displayFlag = 1;
                xStart = 60;
                yStart = 200;
                xDimension = 340;
                yDimension = 220;
                fontSize = 12;
                horizontalLabelShift = 40;
            }
            else if (counter1 == 1 && displayItem2 == 2){
                displayFlag = 1;
                xStart = 410;
                yStart = 200;
                xDimension = 340;
                yDimension = 220;
                fontSize = 12;
                horizontalLabelShift = 40;
            }
            else if (counter1 == 0 && displayItem1 == 3){
                displayFlag = 1;
                xStart = 60;
                yStart = 320;
                xDimension = 340;
                yDimension = 220;
                fontSize = 12;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 1 && displayItem2 == 3){
                displayFlag = 1;
                xStart = 410;
                yStart = 320;
                xDimension = 340;
                yDimension = 220;
                fontSize = 12;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 2 && displayItem3 == 3){
                displayFlag = 1;
                xStart = 60;
                yStart = 40;
                xDimension = 340;
                yDimension = 220;
                fontSize = 12;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 0 && displayItem1 == 4){
                displayFlag = 1;
                xStart = 60;
                yStart = 320;
                xDimension = 340;
                yDimension = 220;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 1 && displayItem2 == 4){
                displayFlag = 1;
                xStart = 410;
                yStart = 320;
                xDimension = 340;
                yDimension = 220;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 2 && displayItem3 == 4){
                displayFlag = 1;
                xStart = 60;
                yStart = 40;
                xDimension = 340;
                yDimension = 220;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 3 && displayItem4 == 4){
                displayFlag = 1;
                xStart = 410;
                yStart = 40;
                xDimension = 340;
                yDimension = 220;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 0 && displayItem1 == 5){
                displayFlag = 1;
                xStart = 60;
                yStart = 420;
                xDimension = 340;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 1 && displayItem2 == 5){
                displayFlag = 1;
                xStart = 410;
                yStart = 420;
                xDimension = 340;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 2 && displayItem3 == 5){
                displayFlag = 1;
                xStart = 60;
                yStart = 230;
                xDimension = 340;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 3 && displayItem4 == 5){
                displayFlag = 1;
                xStart = 410;
                yStart = 230;
                xDimension = 340;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 4 && displayItem5 == 5){
                displayFlag = 1;
                xStart = 60;
                yStart = 40;
                xDimension = 340;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 0 && displayItem1 == 6){
                displayFlag = 1;
                xStart = 60;
                yStart = 420;
                xDimension = 340;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 1 && displayItem2 == 6){
                displayFlag = 1;
                xStart = 410;
                yStart = 420;
                xDimension = 340;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 2 && displayItem3 == 6){
                displayFlag = 1;
                xStart = 60;
                yStart = 230;
                xDimension = 340;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 3 && displayItem4 == 6){
                displayFlag = 1;
                xStart = 410;
                yStart = 230;
                xDimension = 340;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 4 && displayItem5 == 6){
                displayFlag = 1;
                xStart = 60;
                yStart = 40;
                xDimension = 340;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 5 && displayItem6 == 6){
                displayFlag = 1;
                xStart = 410;
                yStart = 40;
                xDimension = 340;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 0 && displayItem1 == 7){
                displayFlag = 1;
                xStart = 60;
                yStart = 451;
                xDimension = 340;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 1 && displayItem2 == 7){
                displayFlag = 1;
                xStart = 410;
                yStart = 451;
                xDimension = 340;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 2 && displayItem3 == 7){
                displayFlag = 1;
                xStart = 60;
                yStart = 309;
                xDimension = 340;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 3 && displayItem4 == 7){
                displayFlag = 1;
                xStart = 410;
                yStart = 309;
                xDimension = 340;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 4 && displayItem5 == 7){
                displayFlag = 1;
                xStart = 60;
                yStart = 167;
                xDimension = 340;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 5 && displayItem6 == 7){
                displayFlag = 1;
                xStart = 410;
                yStart = 167;
                xDimension = 340;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 6 && displayItem7 == 7){
                displayFlag = 1;
                xStart = 60;
                yStart = 25;
                xDimension = 340;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 0 && displayItem1 == 8){
                displayFlag = 1;
                xStart = 60;
                yStart = 451;
                xDimension = 340;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 1 && displayItem2 == 8){
                displayFlag = 1;
                xStart = 410;
                yStart = 451;
                xDimension = 340;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 2 && displayItem3 == 8){
                displayFlag = 1;
                xStart = 60;
                yStart = 309;
                xDimension = 340;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 3 && displayItem4 == 8){
                displayFlag = 1;
                xStart = 410;
                yStart = 309;
                xDimension = 340;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 4 && displayItem5 == 8){
                displayFlag = 1;
                xStart = 60;
                yStart = 167;
                xDimension = 340;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 5 && displayItem6 == 8){
                displayFlag = 1;
                xStart = 410;
                yStart = 167;
                xDimension = 340;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 6 && displayItem7 == 8){
                displayFlag = 1;
                xStart = 60;
                yStart = 25;
                xDimension = 340;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 7 && displayItem8 == 8){
                displayFlag = 1;
                xStart = 410;
                yStart = 25;
                xDimension = 340;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            
            if (displayFlag == 1){
                [[NSColor blackColor] set];
                [NSBezierPath setDefaultLineWidth:1.5];
                
                path = [NSBezierPath bezierPathWithRect: NSMakeRect(xStart, yStart, xDimension, yDimension)];
                [path stroke];
                
                //----Horizontal Label----
                
                if (horizontalScaleHighDivisionHold < horizontalScaleLowDivisionHold+1000) horizontalScaleHighDivisionHold = horizontalScaleMaxDivisionHold;
                
                horizontalTime = horizontalScaleHighDivisionHold-horizontalScaleLowDivisionHold;
                timeString = "Time (hr)";
                
                NSString *timeNSstring = @(timeString.c_str());
                
                NSFont *font = [NSFont boldSystemFontOfSize:fontSize];
                NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                NSAttributedString *attrStrS = [[NSAttributedString alloc] initWithString:timeNSstring attributes:attributes];
                size2 = [attrStrS size].width;
                
                [attributesA setObject:[NSFont boldSystemFontOfSize:fontSize] forKey:NSFontAttributeName];
                [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                
                attrStrA = [[NSAttributedString alloc] initWithString:timeNSstring attributes:attributesA];
                pointA.x = xStart+(xDimension/2)-size2/(double)2;
                pointA.y = yStart-horizontalLabelShift-2;
                [attrStrA drawAtPoint:pointA];
                
                horizontalTimeHr = horizontalTime/(double)60;
                
                //----Horizontal Scale----
                lengthDivision = horizontalTimeHr/(double)5;
                lengthDivisionInt = 0;
                
                if (lengthDivision <= 25) lengthDivisionInt = 25;
                else if (lengthDivision > 25 && lengthDivision <= 50) lengthDivisionInt = 50;
                else if (lengthDivision > 50 && lengthDivision <= 100) lengthDivisionInt = 100;
                else if (lengthDivision > 100 && lengthDivision <= 150) lengthDivisionInt = 100;
                else if (lengthDivision > 150 && lengthDivision <= 200) lengthDivisionInt = 200;
                else if (lengthDivision > 200 && lengthDivision <= 250) lengthDivisionInt = 200;
                else if (lengthDivision > 250 && lengthDivision <= 300) lengthDivisionInt = 300;
                else if (lengthDivision > 300 && lengthDivision <= 350) lengthDivisionInt = 300;
                else if (lengthDivision > 350 && lengthDivision <= 400) lengthDivisionInt = 300;
                else if (lengthDivision > 400 && lengthDivision <= 450) lengthDivisionInt = 400;
                else if (lengthDivision > 450 && lengthDivision <= 500) lengthDivisionInt = 400;
                else if (lengthDivision > 500 && lengthDivision <= 1000) lengthDivisionInt = 500;
                else if (lengthDivision > 1000 && lengthDivision <= 5000) lengthDivisionInt = 1000;
                else if (lengthDivision > 5000) lengthDivisionInt = 1000;
                
                lengthPix = ((xDimension-10)/(double)horizontalTimeHr)*lengthDivisionInt;
                numberOfDivision = (int)((xDimension-10)/(double)lengthPix)+1;
                
                sift = 0;
                
                for (int counter2 = 0; counter2 < numberOfDivision; counter2++){
                    positionAA.x = xStart+lengthPix*counter2;
                    positionAA.y = yStart;
                    positionBB.x = xStart+lengthPix*counter2;
                    positionBB.y = yStart+5;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    
                    NSString *timeNSstring2 = @(to_string(counter2*lengthDivisionInt+(int)(horizontalScaleLowDivisionHold/(double)60)).c_str());
                    NSDictionary *attributes2 = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                    NSAttributedString *attrStrS2 = [[NSAttributedString alloc] initWithString:timeNSstring2 attributes:attributes2];
                    size2 = [attrStrS2 size].width;
                    
                    if (counter2*lengthDivision == 0) sift = 0;
                    else if (counter2*lengthDivision < 1000) sift = 1;
                    
                    NSAttributedString *attrStrA2;
                    NSMutableDictionary *attributesA2 = [NSMutableDictionary dictionary];
                    
                    [attributesA2 setObject:[NSFont boldSystemFontOfSize:fontSize] forKey:NSFontAttributeName];
                    [attributesA2 setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                    
                    attrStrA2 = [[NSAttributedString alloc] initWithString:timeNSstring2 attributes:attributesA];
                    pointA2.x = (xStart+lengthPix*counter2)-size2/(double)2-sift;
                    pointA2.y = yStart-horizontalNumberShift;
                    [attrStrA2 drawAtPoint:pointA2];
                }
                
                //----Base line Scale----
                positionAA.x = xStart;
                positionAA.y = yStart+(yDimension*0.2);
                positionBB.x = xStart+xDimension;
                positionBB.y = yStart+(yDimension*0.2);
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                
                if (belowDisplayType == 0){
                    [attributesA setObject:[NSFont boldSystemFontOfSize:fontSize] forKey:NSFontAttributeName];
                    [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                    
                    attrStrA = [[NSAttributedString alloc] initWithString:@"TD" attributes:attributesA];
                    pointA2.x = xStart+5;
                    pointA2.y = yStart+5;
                    [attrStrA drawAtPoint:pointA2];
                }
                else if (belowDisplayType == 1){
                    [attributesA setObject:[NSFont boldSystemFontOfSize:fontSize] forKey:NSFontAttributeName];
                    [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                    
                    attrStrA = [[NSAttributedString alloc] initWithString:@"QD" attributes:attributesA];
                    pointA2.x = xStart+5;
                    pointA2.y = yStart+5;
                    [attrStrA drawAtPoint:pointA2];
                }
                else if (belowDisplayType == 2){
                    [attributesA setObject:[NSFont boldSystemFontOfSize:fontSize] forKey:NSFontAttributeName];
                    [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                    
                    attrStrA = [[NSAttributedString alloc] initWithString:@"TD+QD" attributes:attributesA];
                    pointA2.x = xStart+5;
                    pointA2.y = yStart+5;
                    [attrStrA drawAtPoint:pointA2];
                }
                else if (belowDisplayType == 3){
                    [attributesA setObject:[NSFont boldSystemFontOfSize:fontSize] forKey:NSFontAttributeName];
                    [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                    
                    attrStrA = [[NSAttributedString alloc] initWithString:@"CD" attributes:attributesA];
                    pointA2.x = xStart+5;
                    pointA2.y = yStart+5;
                    [attrStrA drawAtPoint:pointA2];
                }
                else if (belowDisplayType == 4){
                    [attributesA setObject:[NSFont boldSystemFontOfSize:fontSize] forKey:NSFontAttributeName];
                    [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                    
                    attrStrA = [[NSAttributedString alloc] initWithString:@"FU" attributes:attributesA];
                    pointA2.x = xStart+5;
                    pointA2.y = yStart+5;
                    [attrStrA drawAtPoint:pointA2];
                }
                
                treatNameGR = arrayTableMain [entryNumberTempHold [counter1]][0]+": "+arrayTableMain [entryNumberTempHold [counter1]][4].substr(arrayTableMain [entryNumberTempHold [counter1]][4].find("-")+1);
                
                if ((int) treatNameGR.length() > 17){
                    treatNameGR = treatNameGR.substr(0, 16)+"..";
                }
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(treatNameGR.c_str()) attributes:attributesA];
                pointA2.x = xStart+4;
                pointA2.y = yStart+yDimension-14;
                [attrStrA drawAtPoint:pointA2];
                
                //----Vertical Scale Upper----
                lengthDivision2 = verticalScaleHighUpDivisionHold/(double)5;
                lengthDivisionInt2 = 0;
                
                if (lengthDivision2 <= 5) lengthDivisionInt2 = 5;
                else if (lengthDivision2 > 5 && lengthDivision2 <= 15) lengthDivisionInt2 = 5;
                else if (lengthDivision2 > 15 && lengthDivision2 <= 25) lengthDivisionInt2 = 5;
                else if (lengthDivision2 > 25 && lengthDivision2 <= 50) lengthDivisionInt2 = 50;
                else if (lengthDivision2 > 50 && lengthDivision2 <= 100) lengthDivisionInt2 = 100;
                else if (lengthDivision2 > 100 && lengthDivision2 <= 150) lengthDivisionInt2 = 100;
                else if (lengthDivision2 > 150 && lengthDivision2 <= 200) lengthDivisionInt2 = 200;
                else if (lengthDivision2 > 200 && lengthDivision2 <= 250) lengthDivisionInt2 = 200;
                else if (lengthDivision2 > 250 && lengthDivision2 <= 300) lengthDivisionInt2 = 300;
                else if (lengthDivision2 > 300 && lengthDivision2 <= 350) lengthDivisionInt2 = 300;
                else if (lengthDivision2 > 350 && lengthDivision2 <= 400) lengthDivisionInt2 = 300;
                else if (lengthDivision2 > 400 && lengthDivision2 <= 450) lengthDivisionInt2 = 400;
                else if (lengthDivision2 > 450 && lengthDivision2 <= 500) lengthDivisionInt2 = 400;
                else if (lengthDivision2 > 500 && lengthDivision2 <= 1000) lengthDivisionInt2 = 500;
                else if (lengthDivision2 > 1000 && lengthDivision2 <= 5000) lengthDivisionInt2 = 1000;
                else if (lengthDivision2 > 5000) lengthDivisionInt2 = 1000;
                
                lengthPix2 = ((yDimension*0.8)/(double)verticalScaleHighUpDivisionHold)*lengthDivisionInt2;
                numberOfDivision2 = (int)((yDimension*0.8)/(double)lengthPix2)+1;
                
                lowestXPosition = 1000;
                
                for (int counter2 = 0; counter2 < numberOfDivision2; counter2++){
                    if (yStart+yDimension*0.2+lengthPix2*counter2 < yStart+yDimension){
                        positionAA.x = xStart;
                        positionAA.y = yStart+yDimension*0.2+lengthPix2*counter2;
                        positionBB.x = xStart+5;
                        positionBB.y = yStart+yDimension*0.2+lengthPix2*counter2;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        if (counter1 == 0 || counter1 == 2 || counter1 == 4 || counter1 == 6 || counter1 == 8){
                            NSString *timeNSstring3 = @(to_string(counter2*lengthDivisionInt2).c_str());
                            NSDictionary *attributes3 = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                            NSAttributedString *attrStrS3 = [[NSAttributedString alloc] initWithString:timeNSstring3 attributes:attributes3];
                            size2 = [attrStrS3 size].width;
                            
                            NSAttributedString *attrStrA2;
                            NSMutableDictionary *attributesA2 = [NSMutableDictionary dictionary];
                            
                            [attributesA2 setObject:[NSFont boldSystemFontOfSize:fontSize] forKey:NSFontAttributeName];
                            [attributesA2 setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                            
                            attrStrA2 = [[NSAttributedString alloc] initWithString:timeNSstring3 attributes:attributesA];
                            pointA2.x = xStart-size2-10;
                            pointA2.y = yStart+yDimension*0.2+lengthPix2*counter2-5;
                            [attrStrA2 drawAtPoint:pointA2];
                            
                            if (lowestXPosition > xStart-size2-10) lowestXPosition = (int)(xStart-size2-10);
                        }
                    }
                }
                
                //----Vertical Scale Lower----
                lengthDivision2 = verticalScaleHighDownDivisionHold/(double)5;
                lengthDivisionInt2 = 0;
                
                if (lengthDivision2 <= 5) lengthDivisionInt2 = 5;
                else if (lengthDivision2 > 5 && lengthDivision2 <= 15) lengthDivisionInt2 = 5;
                else if (lengthDivision2 > 15 && lengthDivision2 <= 25) lengthDivisionInt2 = 5;
                else if (lengthDivision2 > 25 && lengthDivision2 <= 50) lengthDivisionInt2 = 50;
                else if (lengthDivision2 > 50 && lengthDivision2 <= 100) lengthDivisionInt2 = 100;
                else if (lengthDivision2 > 100 && lengthDivision2 <= 150) lengthDivisionInt2 = 100;
                else if (lengthDivision2 > 150 && lengthDivision2 <= 200) lengthDivisionInt2 = 200;
                else if (lengthDivision2 > 200 && lengthDivision2 <= 250) lengthDivisionInt2 = 200;
                else if (lengthDivision2 > 250 && lengthDivision2 <= 300) lengthDivisionInt2 = 300;
                else if (lengthDivision2 > 300 && lengthDivision2 <= 350) lengthDivisionInt2 = 300;
                else if (lengthDivision2 > 350 && lengthDivision2 <= 400) lengthDivisionInt2 = 300;
                else if (lengthDivision2 > 400 && lengthDivision2 <= 450) lengthDivisionInt2 = 400;
                else if (lengthDivision2 > 450 && lengthDivision2 <= 500) lengthDivisionInt2 = 400;
                else if (lengthDivision2 > 500 && lengthDivision2 <= 1000) lengthDivisionInt2 = 500;
                else if (lengthDivision2 > 1000 && lengthDivision2 <= 5000) lengthDivisionInt2 = 1000;
                else if (lengthDivision2 > 5000) lengthDivisionInt2 = 1000;
                
                lengthPix2 = ((yDimension*0.2)/(double)verticalScaleHighDownDivisionHold)*lengthDivisionInt2;
                numberOfDivision2 = (int)((yDimension*0.2)/(double)lengthPix2)+1;
                
                for (int counter2 = 1; counter2 < numberOfDivision2; counter2++){
                    if (yStart+yDimension*0.2-lengthPix2*counter2 > yStart){
                        
                        positionAA.x = xStart;
                        positionAA.y = yStart+yDimension*0.2-lengthPix2*counter2;
                        positionBB.x = xStart+5;
                        positionBB.y = yStart+yDimension*0.2-lengthPix2*counter2;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        if (counter1 == 0 || counter1 == 2 || counter1 == 4 || counter1 == 6 || counter1 == 8){
                            NSString *timeNSstring3 = @(to_string(counter2*lengthDivisionInt2+verticalScaleLowHold).c_str());
                            NSDictionary *attributes3 = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                            NSAttributedString *attrStrS3 = [[NSAttributedString alloc] initWithString:timeNSstring3 attributes:attributes3];
                            size2 = [attrStrS3 size].width;
                            
                            NSAttributedString *attrStrA2;
                            NSMutableDictionary *attributesA2 = [NSMutableDictionary dictionary];
                            
                            [attributesA2 setObject:[NSFont boldSystemFontOfSize:fontSize] forKey:NSFontAttributeName];
                            [attributesA2 setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                            
                            attrStrA2 = [[NSAttributedString alloc] initWithString:timeNSstring3 attributes:attributesA];
                            pointA2.x = xStart-size2-10;
                            pointA2.y = yStart+yDimension*0.2-lengthPix2*counter2-5;
                            [attrStrA2 drawAtPoint:pointA2];
                        }
                    }
                }
                
                if (counter1 == 0 || counter1 == 2 || counter1 == 4 || counter1 == 6 || counter1 == 8){
                    //----Vertical Label----
                    NSString *verticalNSstring = @"Number of Events";
                    
                    NSFont *font2 = [NSFont boldSystemFontOfSize:fontSize];
                    NSDictionary *attributes2 = [NSDictionary dictionaryWithObjectsAndKeys:font2, NSFontAttributeName, nil];
                    NSAttributedString *attrStrS2 = [[NSAttributedString alloc] initWithString:verticalNSstring attributes:attributes2];
                    size2 = [attrStrS2 size].width;
                    
                    NSGraphicsContext *context = [NSGraphicsContext currentContext];
                    NSAffineTransform *transform = [NSAffineTransform transform];
                    [transform rotateByDegrees:+90];
                    
                    [context saveGraphicsState];
                    [transform concat];
                    
                    NSAttributedString *attrStrB;
                    NSMutableDictionary *attributesB = [NSMutableDictionary dictionary];
                    NSString *titleStringB = @"Number of Events";
                    
                    [attributesB setObject:[NSFont boldSystemFontOfSize:fontSize] forKey:NSFontAttributeName];
                    [attributesB setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                    attrStrB = [[NSAttributedString alloc] initWithString:titleStringB attributes:attributesB];
                    
                    pointA.x = yStart+((yDimension/2)-size2/(double)2);
                    pointA.y = (lowestXPosition-5)*-1;
                    [attrStrB drawAtPoint:pointA];
                    
                    [context restoreGraphicsState];
                }
                
                [NSBezierPath setDefaultLineWidth:1.0];
                
                int *cellNumberHoldDD = new int [horizontalScaleMaxDivisionHold+50];
                int *cellNumberHoldTD = new int [horizontalScaleMaxDivisionHold+50];
                int *cellNumberHoldHD = new int [horizontalScaleMaxDivisionHold+50];
                int *cellNumberHoldFU = new int [horizontalScaleMaxDivisionHold+50];
                int *cellNumberHoldCD = new int [horizontalScaleMaxDivisionHold+50];
                
                for (int counter3 = 0; counter3 < horizontalScaleMaxDivisionHold+50; counter3++){
                    cellNumberHoldDD [counter3] = 0;
                    cellNumberHoldTD [counter3] = 0;
                    cellNumberHoldHD [counter3] = 0;
                    cellNumberHoldFU [counter3] = 0;
                    cellNumberHoldCD [counter3] = 0;
                }
                
                for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [entryNumberTempHold [counter1]]/9; counter3++){
                    actualTime = arrayLineageData [entryNumberTempHold [counter1]][counter3*9+2]*atoi(arrayLineageDataType [entryNumberTempHold [counter1]][5].c_str());
                    
                    if (arrayLineageData [entryNumberTempHold [counter1]][counter3*9+3] == 32){
                        cellNumberHoldDD [actualTime]++;
                    }
                    
                    if (arrayLineageData [entryNumberTempHold [counter1]][counter3*9+3] == 42){
                        cellNumberHoldTD [actualTime]++;
                    }
                    
                    if (arrayLineageData [entryNumberTempHold [counter1]][counter3*9+3] == 52){
                        cellNumberHoldHD [actualTime]++;
                    }
                    
                    if (arrayLineageData [entryNumberTempHold [counter1]][counter3*9+3] == 7){
                        cellNumberHoldFU [actualTime]++;
                    }
                    
                    if (arrayLineageData [entryNumberTempHold [counter1]][counter3*9+3] == 91){
                        cellNumberHoldCD [actualTime]++;
                    }
                }
                
                for (int counter2 = 0; counter2 <= horizontalScaleHighDivisionHold; counter2++){
                    if (counter2-horizontalScaleLowDivisionHold > 0 && counter2-horizontalScaleLowDivisionHold <= horizontalScaleHighDivisionHold){
                        if (cellNumberHoldDD[counter2] != 0){
                            [[NSColor blueColor] set];
                            
                            positionAA.x = xStart+(xDimension/(double)horizontalTime)*(counter2-horizontalScaleLowDivisionHold);
                            positionAA.y = yStart+yDimension*0.2;
                            positionBB.x = xStart+(xDimension/(double)horizontalTime)*(counter2-horizontalScaleLowDivisionHold);
                            
                            if (yStart+yDimension*0.2+((yDimension*0.8)/(double)verticalScaleHighUpDivisionHold)*cellNumberHoldDD[counter2] < yStart+yDimension){
                                positionBB.y = yStart+yDimension*0.2+((yDimension*0.8)/(double)verticalScaleHighUpDivisionHold)*cellNumberHoldDD[counter2];
                            }
                            else positionBB.y = yStart+yDimension;
                            
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                        
                        if (belowDisplayType == 0){
                            [[NSColor redColor] set];
                            
                            positionAA.x = xStart+(xDimension/(double)horizontalTime)*(counter2-horizontalScaleLowDivisionHold);
                            positionAA.y = yStart+yDimension*0.2;
                            positionBB.x = xStart+(xDimension/(double)horizontalTime)*(counter2-horizontalScaleLowDivisionHold);
                            
                            if (yStart+yDimension*0.2-((yDimension*0.2)/(double)verticalScaleHighDownDivisionHold)*cellNumberHoldTD[counter2] > yStart){
                                positionBB.y = yStart+yDimension*0.2-((yDimension*0.2)/(double)verticalScaleHighDownDivisionHold)*cellNumberHoldTD[counter2];
                            }
                            else positionBB.y = yStart;
                            
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                        else if (belowDisplayType == 1){
                            [[NSColor magentaColor] set];
                            
                            positionAA.x = xStart+(xDimension/(double)horizontalTime)*(counter2-horizontalScaleLowDivisionHold);
                            positionAA.y = yStart+yDimension*0.2;
                            positionBB.x = xStart+(xDimension/(double)horizontalTime)*(counter2-horizontalScaleLowDivisionHold);
                            
                            if (yStart+yDimension*0.2-((yDimension*0.2)/(double)verticalScaleHighDownDivisionHold)*cellNumberHoldHD[counter2] > yStart){
                                positionBB.y = yStart+yDimension*0.2-((yDimension*0.2)/(double)verticalScaleHighDownDivisionHold)*cellNumberHoldHD[counter2];
                            }
                            else positionBB.y = yStart;
                            
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                        else if (belowDisplayType == 2){
                            [[NSColor purpleColor] set];
                            
                            positionAA.x = xStart+(xDimension/(double)horizontalTime)*(counter2-horizontalScaleLowDivisionHold);
                            positionAA.y = yStart+yDimension*0.2;
                            positionBB.x = xStart+(xDimension/(double)horizontalTime)*(counter2-horizontalScaleLowDivisionHold);
                            
                            if (yStart+yDimension*0.2-((yDimension*0.2)/(double)verticalScaleHighDownDivisionHold)*(cellNumberHoldTD[counter2]+cellNumberHoldHD[counter2]) > yStart){
                                positionBB.y = yStart+yDimension*0.2-((yDimension*0.2)/(double)verticalScaleHighDownDivisionHold)*(cellNumberHoldTD[counter2]+cellNumberHoldHD[counter2]);
                            }
                            else positionBB.y = yStart;
                            
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                        else if (belowDisplayType == 3){
                            [[NSColor orangeColor] set];
                            
                            positionAA.x = xStart+(xDimension/(double)horizontalTime)*(counter2-horizontalScaleLowDivisionHold);
                            positionAA.y = yStart+yDimension*0.2;
                            positionBB.x = xStart+(xDimension/(double)horizontalTime)*(counter2-horizontalScaleLowDivisionHold);
                            
                            if (yStart+yDimension*0.2-((yDimension*0.2)/(double)verticalScaleHighDownDivisionHold)*cellNumberHoldFU[counter2] > yStart){
                                positionBB.y = yStart+yDimension*0.2-((yDimension*0.2)/(double)verticalScaleHighDownDivisionHold)*cellNumberHoldFU[counter2];
                            }
                            else positionBB.y = yStart;
                            
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                        else if (belowDisplayType == 4){
                            [[NSColor blackColor] set];
                            
                            positionAA.x = xStart+(xDimension/(double)horizontalTime)*(counter2-horizontalScaleLowDivisionHold);
                            positionAA.y = yStart+yDimension*0.2;
                            positionBB.x = xStart+(xDimension/(double)horizontalTime)*(counter2-horizontalScaleLowDivisionHold);
                            
                            if (yStart+yDimension*0.2-((yDimension*0.2)/(double)verticalScaleHighDownDivisionHold)*cellNumberHoldCD[counter2] > yStart){
                                positionBB.y = yStart+yDimension*0.2-((yDimension*0.2)/(double)verticalScaleHighDownDivisionHold)*cellNumberHoldCD[counter2];
                            }
                            else positionBB.y = yStart;
                            
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                    }
                }
                
                delete [] cellNumberHoldDD;
                delete [] cellNumberHoldTD;
                delete [] cellNumberHoldHD;
                delete [] cellNumberHoldFU;
                delete [] cellNumberHoldCD;
            }
        }
        
        delete [] entryNumberTempHold;
    }
    else{
        
        int magFactor = 4;
        
        NSBitmapImageRep *bitmapReps;
        bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:767*magFactor pixelsHigh:591*magFactor bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:767*magFactor*4 bitsPerPixel:32];
        
        [NSGraphicsContext saveGraphicsState];
        [NSGraphicsContext setCurrentContext:[NSGraphicsContext graphicsContextWithBitmapImageRep:bitmapReps]];
        
        [[NSColor whiteColor] set];
        
        NSBezierPath *path;
        path = [NSBezierPath bezierPathWithRect: NSMakeRect(0, 0, 767*magFactor, 591*magFactor)];
        [path fill];
        
        //----Re-load----
        [NSBezierPath setDefaultLineWidth:1*magFactor];
        
        NSPoint pointA;
        NSAttributedString *attrStrA;
        NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
        
        int entryNumberCount = 0;
        int maxEntry = 0;
        
        int *entryNumberTempHold = new int [40];
        int entryNumberTempHoldCount = 0;
        
        for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
            if (arraySelectedLing [counter2] == 1 && maxEntry < 8){
                entryNumberCount++;
                entryNumberTempHold [entryNumberTempHoldCount] = counter2, entryNumberTempHoldCount++;
                
                maxEntry++;
            }
        }
        
        int displayItem1 = 0;
        int displayItem2 = 0;
        int displayItem3 = 0;
        int displayItem4 = 0;
        int displayItem5 = 0;
        int displayItem6 = 0;
        int displayItem7 = 0;
        int displayItem8 = 0;
        
        if (entryNumberCount == 1) displayItem1 = 1;
        else if (entryNumberCount == 2){
            displayItem1 = 2;
            displayItem2 = 2;
        }
        else if (entryNumberCount == 3){
            displayItem1 = 3;
            displayItem2 = 3;
            displayItem3 = 3;
        }
        else if (entryNumberCount == 4){
            displayItem1 = 4;
            displayItem2 = 4;
            displayItem3 = 4;
            displayItem4 = 4;
        }
        else if (entryNumberCount == 5){
            displayItem1 = 5;
            displayItem2 = 5;
            displayItem3 = 5;
            displayItem4 = 5;
            displayItem5 = 5;
        }
        else if (entryNumberCount == 6){
            displayItem1 = 6;
            displayItem2 = 6;
            displayItem3 = 6;
            displayItem4 = 6;
            displayItem5 = 6;
            displayItem6 = 6;
        }
        else if (entryNumberCount == 7){
            displayItem1 = 7;
            displayItem2 = 7;
            displayItem3 = 7;
            displayItem4 = 7;
            displayItem5 = 7;
            displayItem6 = 7;
            displayItem7 = 7;
        }
        else if (entryNumberCount == 8){
            displayItem1 = 8;
            displayItem2 = 8;
            displayItem3 = 8;
            displayItem4 = 8;
            displayItem5 = 8;
            displayItem6 = 8;
            displayItem7 = 8;
            displayItem8 = 8;
        }
        
        int displayFlag = 0;
        int xStart = 0;
        int yStart = 0;
        int horizontalTime = 0;
        int lengthDivisionInt = 0;
        int numberOfDivision = 0;
        int lengthDivisionInt2 = 0;
        int numberOfDivision2 = 0;
        int lowestXPosition = 1000;
        int actualTime = 0;
        int xDimension = 0;
        int yDimension = 0;
        int fontSize = 0;
        int horizontalLabelShift = 0;
        int horizontalNumberShift = 0;
        
        double lengthDivision = 0;
        double lengthPix = 0;
        double sift = 0;
        double lengthDivision2 = 0;
        double lengthPix2 = 0;
        double horizontalTimeHr = 0;
        
        string treatNameGR;
        string timeString;
        
        NSPoint positionAA;
        NSPoint positionBB;
        NSPoint pointA2;
        
        CGFloat size2 = 0;
        
        for (int counter1 = 0; counter1 < displayItem1; counter1++){
            displayFlag = 0;
            horizontalLabelShift = 25;
            horizontalNumberShift = 20;
            
            if (counter1 == 0 && displayItem1 == 1){
                displayFlag = 1;
                xStart = 80;
                yStart = 100;
                xDimension = 650;
                yDimension = 350;
                fontSize = 12;
                horizontalLabelShift = 40;
            }
            else if (counter1 == 0 && displayItem1 == 2){
                displayFlag = 1;
                xStart = 60;
                yStart = 200;
                xDimension = 340;
                yDimension = 220;
                fontSize = 12;
                horizontalLabelShift = 40;
            }
            else if (counter1 == 1 && displayItem2 == 2){
                displayFlag = 1;
                xStart = 410;
                yStart = 200;
                xDimension = 340;
                yDimension = 220;
                fontSize = 12;
                horizontalLabelShift = 40;
            }
            else if (counter1 == 0 && displayItem1 == 3){
                displayFlag = 1;
                xStart = 60;
                yStart = 320;
                xDimension = 340;
                yDimension = 220;
                fontSize = 12;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 1 && displayItem2 == 3){
                displayFlag = 1;
                xStart = 410;
                yStart = 320;
                xDimension = 340;
                yDimension = 220;
                fontSize = 12;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 2 && displayItem3 == 3){
                displayFlag = 1;
                xStart = 60;
                yStart = 40;
                xDimension = 340;
                yDimension = 220;
                fontSize = 12;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 0 && displayItem1 == 4){
                displayFlag = 1;
                xStart = 60;
                yStart = 320;
                xDimension = 340;
                yDimension = 220;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 1 && displayItem2 == 4){
                displayFlag = 1;
                xStart = 410;
                yStart = 320;
                xDimension = 340;
                yDimension = 220;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 2 && displayItem3 == 4){
                displayFlag = 1;
                xStart = 60;
                yStart = 40;
                xDimension = 340;
                yDimension = 220;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 3 && displayItem4 == 4){
                displayFlag = 1;
                xStart = 410;
                yStart = 40;
                xDimension = 340;
                yDimension = 220;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 0 && displayItem1 == 5){
                displayFlag = 1;
                xStart = 60;
                yStart = 420;
                xDimension = 340;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 1 && displayItem2 == 5){
                displayFlag = 1;
                xStart = 410;
                yStart = 420;
                xDimension = 340;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 2 && displayItem3 == 5){
                displayFlag = 1;
                xStart = 60;
                yStart = 230;
                xDimension = 340;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 3 && displayItem4 == 5){
                displayFlag = 1;
                xStart = 410;
                yStart = 230;
                xDimension = 340;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 4 && displayItem5 == 5){
                displayFlag = 1;
                xStart = 60;
                yStart = 40;
                xDimension = 340;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 0 && displayItem1 == 6){
                displayFlag = 1;
                xStart = 60;
                yStart = 420;
                xDimension = 340;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 1 && displayItem2 == 6){
                displayFlag = 1;
                xStart = 410;
                yStart = 420;
                xDimension = 340;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 2 && displayItem3 == 6){
                displayFlag = 1;
                xStart = 60;
                yStart = 230;
                xDimension = 340;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 3 && displayItem4 == 6){
                displayFlag = 1;
                xStart = 410;
                yStart = 230;
                xDimension = 340;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 4 && displayItem5 == 6){
                displayFlag = 1;
                xStart = 60;
                yStart = 40;
                xDimension = 340;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 5 && displayItem6 == 6){
                displayFlag = 1;
                xStart = 410;
                yStart = 40;
                xDimension = 340;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 0 && displayItem1 == 7){
                displayFlag = 1;
                xStart = 60;
                yStart = 451;
                xDimension = 340;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 1 && displayItem2 == 7){
                displayFlag = 1;
                xStart = 410;
                yStart = 451;
                xDimension = 340;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 2 && displayItem3 == 7){
                displayFlag = 1;
                xStart = 60;
                yStart = 309;
                xDimension = 340;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 3 && displayItem4 == 7){
                displayFlag = 1;
                xStart = 410;
                yStart = 309;
                xDimension = 340;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 4 && displayItem5 == 7){
                displayFlag = 1;
                xStart = 60;
                yStart = 167;
                xDimension = 340;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 5 && displayItem6 == 7){
                displayFlag = 1;
                xStart = 410;
                yStart = 167;
                xDimension = 340;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 6 && displayItem7 == 7){
                displayFlag = 1;
                xStart = 60;
                yStart = 25;
                xDimension = 340;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 0 && displayItem1 == 8){
                displayFlag = 1;
                xStart = 60;
                yStart = 451;
                xDimension = 340;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 1 && displayItem2 == 8){
                displayFlag = 1;
                xStart = 410;
                yStart = 451;
                xDimension = 340;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 2 && displayItem3 == 8){
                displayFlag = 1;
                xStart = 60;
                yStart = 309;
                xDimension = 340;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 3 && displayItem4 == 8){
                displayFlag = 1;
                xStart = 410;
                yStart = 309;
                xDimension = 340;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 4 && displayItem5 == 8){
                displayFlag = 1;
                xStart = 60;
                yStart = 167;
                xDimension = 340;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 5 && displayItem6 == 8){
                displayFlag = 1;
                xStart = 410;
                yStart = 167;
                xDimension = 340;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 6 && displayItem7 == 8){
                displayFlag = 1;
                xStart = 60;
                yStart = 25;
                xDimension = 340;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 7 && displayItem8 == 8){
                displayFlag = 1;
                xStart = 410;
                yStart = 25;
                xDimension = 340;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            
            if (displayFlag == 1){
                [[NSColor blackColor] set];
                [NSBezierPath setDefaultLineWidth:1.5*magFactor];
                
                path = [NSBezierPath bezierPathWithRect: NSMakeRect(xStart*magFactor, yStart*magFactor, xDimension*magFactor, yDimension*magFactor)];
                [path stroke];
                
                //----Horizontal Label----
                
                if (horizontalScaleHighDivisionHold < horizontalScaleLowDivisionHold+1000) horizontalScaleHighDivisionHold = horizontalScaleMaxDivisionHold;
                
                horizontalTime = horizontalScaleHighDivisionHold-horizontalScaleLowDivisionHold;
                timeString = "Time (hr)";
                
                NSString *timeNSstring = @(timeString.c_str());
                
                NSFont *font = [NSFont boldSystemFontOfSize:fontSize*magFactor];
                NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                NSAttributedString *attrStrS = [[NSAttributedString alloc] initWithString:timeNSstring attributes:attributes];
                size2 = [attrStrS size].width;
                
                [attributesA setObject:[NSFont boldSystemFontOfSize:fontSize*magFactor] forKey:NSFontAttributeName];
                [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                
                attrStrA = [[NSAttributedString alloc] initWithString:timeNSstring attributes:attributesA];
                pointA.x = xStart*magFactor+(xDimension*magFactor/2)-size2/(double)2;
                pointA.y = yStart*magFactor-horizontalLabelShift*magFactor-2*magFactor;
                [attrStrA drawAtPoint:pointA];
                
                horizontalTimeHr = horizontalTime/(double)60;
                
                //----Horizontal Scale----
                lengthDivision = horizontalTimeHr/(double)5;
                lengthDivisionInt = 0;
                
                if (lengthDivision <= 25) lengthDivisionInt = 25;
                else if (lengthDivision > 25 && lengthDivision <= 50) lengthDivisionInt = 50;
                else if (lengthDivision > 50 && lengthDivision <= 100) lengthDivisionInt = 100;
                else if (lengthDivision > 100 && lengthDivision <= 150) lengthDivisionInt = 100;
                else if (lengthDivision > 150 && lengthDivision <= 200) lengthDivisionInt = 200;
                else if (lengthDivision > 200 && lengthDivision <= 250) lengthDivisionInt = 200;
                else if (lengthDivision > 250 && lengthDivision <= 300) lengthDivisionInt = 300;
                else if (lengthDivision > 300 && lengthDivision <= 350) lengthDivisionInt = 300;
                else if (lengthDivision > 350 && lengthDivision <= 400) lengthDivisionInt = 300;
                else if (lengthDivision > 400 && lengthDivision <= 450) lengthDivisionInt = 400;
                else if (lengthDivision > 450 && lengthDivision <= 500) lengthDivisionInt = 400;
                else if (lengthDivision > 500 && lengthDivision <= 1000) lengthDivisionInt = 500;
                else if (lengthDivision > 1000 && lengthDivision <= 5000) lengthDivisionInt = 1000;
                else if (lengthDivision > 5000) lengthDivisionInt = 1000;
                
                lengthPix = ((xDimension-10)/(double)horizontalTimeHr)*lengthDivisionInt;
                numberOfDivision = (int)((xDimension-10)/(double)lengthPix)+1;
                
                sift = 0;
                
                for (int counter2 = 0; counter2 < numberOfDivision; counter2++){
                    positionAA.x = xStart*magFactor+lengthPix*counter2*magFactor;
                    positionAA.y = yStart*magFactor;
                    positionBB.x = xStart*magFactor+lengthPix*counter2*magFactor;
                    positionBB.y = yStart*magFactor+5*magFactor;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    
                    NSString *timeNSstring2 = @(to_string(counter2*lengthDivisionInt+(int)(horizontalScaleLowDivisionHold/(double)60)).c_str());
                    NSDictionary *attributes2 = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                    NSAttributedString *attrStrS2 = [[NSAttributedString alloc] initWithString:timeNSstring2 attributes:attributes2];
                    size2 = [attrStrS2 size].width;
                    
                    if (counter2*lengthDivision == 0) sift = 0;
                    else if (counter2*lengthDivision < 1000) sift = 1;
                    
                    NSAttributedString *attrStrA2;
                    NSMutableDictionary *attributesA2 = [NSMutableDictionary dictionary];
                    
                    [attributesA2 setObject:[NSFont boldSystemFontOfSize:fontSize*magFactor] forKey:NSFontAttributeName];
                    [attributesA2 setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                    
                    attrStrA2 = [[NSAttributedString alloc] initWithString:timeNSstring2 attributes:attributesA];
                    pointA2.x = (xStart*magFactor+lengthPix*counter2*magFactor)-size2/(double)2-sift*magFactor;
                    pointA2.y = yStart*magFactor-horizontalNumberShift*magFactor;
                    [attrStrA2 drawAtPoint:pointA2];
                }
                
                //----Base line Scale----
                positionAA.x = xStart*magFactor;
                positionAA.y = yStart*magFactor+(yDimension*0.2*magFactor);
                positionBB.x = xStart*magFactor+xDimension*magFactor;
                positionBB.y = yStart*magFactor+(yDimension*0.2*magFactor);
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                
                if (belowDisplayType == 0){
                    [attributesA setObject:[NSFont boldSystemFontOfSize:fontSize*magFactor] forKey:NSFontAttributeName];
                    [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                    
                    attrStrA = [[NSAttributedString alloc] initWithString:@"TD" attributes:attributesA];
                    pointA2.x = xStart*magFactor+5*magFactor;
                    pointA2.y = yStart*magFactor+5*magFactor;
                    [attrStrA drawAtPoint:pointA2];
                }
                else if (belowDisplayType == 1){
                    [attributesA setObject:[NSFont boldSystemFontOfSize:fontSize*magFactor] forKey:NSFontAttributeName];
                    [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                    
                    attrStrA = [[NSAttributedString alloc] initWithString:@"QD" attributes:attributesA];
                    pointA2.x = xStart*magFactor+5*magFactor;
                    pointA2.y = yStart*magFactor+5*magFactor;
                    [attrStrA drawAtPoint:pointA2];
                }
                else if (belowDisplayType == 2){
                    [attributesA setObject:[NSFont boldSystemFontOfSize:fontSize*magFactor] forKey:NSFontAttributeName];
                    [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                    
                    attrStrA = [[NSAttributedString alloc] initWithString:@"TD+QD" attributes:attributesA];
                    pointA2.x = xStart*magFactor+5*magFactor;
                    pointA2.y = yStart*magFactor+5*magFactor;
                    [attrStrA drawAtPoint:pointA2];
                }
                else if (belowDisplayType == 3){
                    [attributesA setObject:[NSFont boldSystemFontOfSize:fontSize*magFactor] forKey:NSFontAttributeName];
                    [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                    
                    attrStrA = [[NSAttributedString alloc] initWithString:@"CD" attributes:attributesA];
                    pointA2.x = xStart*magFactor+5*magFactor;
                    pointA2.y = yStart*magFactor+5*magFactor;
                    [attrStrA drawAtPoint:pointA2];
                }
                else if (belowDisplayType == 4){
                    [attributesA setObject:[NSFont boldSystemFontOfSize:fontSize*magFactor] forKey:NSFontAttributeName];
                    [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                    
                    attrStrA = [[NSAttributedString alloc] initWithString:@"FU" attributes:attributesA];
                    pointA2.x = xStart*magFactor+5*magFactor;
                    pointA2.y = yStart*magFactor+5*magFactor;
                    [attrStrA drawAtPoint:pointA2];
                }
                
                treatNameGR = arrayTableMain [entryNumberTempHold [counter1]][0]+": "+arrayTableMain [entryNumberTempHold [counter1]][4].substr(arrayTableMain [entryNumberTempHold [counter1]][4].find("-")+1);
                
                if ((int) treatNameGR.length() > 17){
                    treatNameGR = treatNameGR.substr(0, 16)+"..";
                }
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(treatNameGR.c_str()) attributes:attributesA];
                pointA2.x = xStart*magFactor+4*magFactor;
                pointA2.y = yStart*magFactor+yDimension*magFactor-14*magFactor;
                [attrStrA drawAtPoint:pointA2];
                
                //----Vertical Scale Upper----
                lengthDivision2 = verticalScaleHighUpDivisionHold/(double)5;
                lengthDivisionInt2 = 0;
                
                if (lengthDivision2 <= 5) lengthDivisionInt2 = 5;
                else if (lengthDivision2 > 5 && lengthDivision2 <= 15) lengthDivisionInt2 = 5;
                else if (lengthDivision2 > 15 && lengthDivision2 <= 25) lengthDivisionInt2 = 5;
                else if (lengthDivision2 > 25 && lengthDivision2 <= 50) lengthDivisionInt2 = 50;
                else if (lengthDivision2 > 50 && lengthDivision2 <= 100) lengthDivisionInt2 = 100;
                else if (lengthDivision2 > 100 && lengthDivision2 <= 150) lengthDivisionInt2 = 100;
                else if (lengthDivision2 > 150 && lengthDivision2 <= 200) lengthDivisionInt2 = 200;
                else if (lengthDivision2 > 200 && lengthDivision2 <= 250) lengthDivisionInt2 = 200;
                else if (lengthDivision2 > 250 && lengthDivision2 <= 300) lengthDivisionInt2 = 300;
                else if (lengthDivision2 > 300 && lengthDivision2 <= 350) lengthDivisionInt2 = 300;
                else if (lengthDivision2 > 350 && lengthDivision2 <= 400) lengthDivisionInt2 = 300;
                else if (lengthDivision2 > 400 && lengthDivision2 <= 450) lengthDivisionInt2 = 400;
                else if (lengthDivision2 > 450 && lengthDivision2 <= 500) lengthDivisionInt2 = 400;
                else if (lengthDivision2 > 500 && lengthDivision2 <= 1000) lengthDivisionInt2 = 500;
                else if (lengthDivision2 > 1000 && lengthDivision2 <= 5000) lengthDivisionInt2 = 1000;
                else if (lengthDivision2 > 5000) lengthDivisionInt2 = 1000;
                
                lengthPix2 = ((yDimension*0.8)/(double)verticalScaleHighUpDivisionHold)*lengthDivisionInt2;
                numberOfDivision2 = (int)((yDimension*0.8)/(double)lengthPix2)+1;
                
                lowestXPosition = 1000;
                
                for (int counter2 = 0; counter2 < numberOfDivision2; counter2++){
                    if (yStart+yDimension*0.2+lengthPix2*counter2 < yStart+yDimension){
                        positionAA.x = xStart*magFactor;
                        positionAA.y = yStart*magFactor+yDimension*0.2*magFactor+lengthPix2*counter2*magFactor;
                        positionBB.x = xStart*magFactor+5*magFactor;
                        positionBB.y = yStart*magFactor+yDimension*0.2*magFactor+lengthPix2*counter2*magFactor;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        if (counter1 == 0 || counter1 == 2 || counter1 == 4 || counter1 == 6 || counter1 == 8){
                            NSString *timeNSstring3 = @(to_string(counter2*lengthDivisionInt2).c_str());
                            NSDictionary *attributes3 = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                            NSAttributedString *attrStrS3 = [[NSAttributedString alloc] initWithString:timeNSstring3 attributes:attributes3];
                            size2 = [attrStrS3 size].width;
                            
                            NSAttributedString *attrStrA2;
                            NSMutableDictionary *attributesA2 = [NSMutableDictionary dictionary];
                            
                            [attributesA2 setObject:[NSFont boldSystemFontOfSize:fontSize*magFactor] forKey:NSFontAttributeName];
                            [attributesA2 setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                            
                            attrStrA2 = [[NSAttributedString alloc] initWithString:timeNSstring3 attributes:attributesA];
                            pointA2.x = xStart*magFactor-size2-10*magFactor;
                            pointA2.y = yStart*magFactor+yDimension*0.2*magFactor+lengthPix2*counter2*magFactor-5*magFactor;
                            [attrStrA2 drawAtPoint:pointA2];
                            
                            if (lowestXPosition > xStart*magFactor-size2-10*magFactor) lowestXPosition = (int)(xStart*magFactor-size2-10*magFactor);
                        }
                    }
                }
                
                //----Vertical Scale Lower----
                lengthDivision2 = verticalScaleHighDownDivisionHold/(double)5;
                lengthDivisionInt2 = 0;
                
                if (lengthDivision2 <= 5) lengthDivisionInt2 = 5;
                else if (lengthDivision2 > 5 && lengthDivision2 <= 15) lengthDivisionInt2 = 5;
                else if (lengthDivision2 > 15 && lengthDivision2 <= 25) lengthDivisionInt2 = 5;
                else if (lengthDivision2 > 25 && lengthDivision2 <= 50) lengthDivisionInt2 = 50;
                else if (lengthDivision2 > 50 && lengthDivision2 <= 100) lengthDivisionInt2 = 100;
                else if (lengthDivision2 > 100 && lengthDivision2 <= 150) lengthDivisionInt2 = 100;
                else if (lengthDivision2 > 150 && lengthDivision2 <= 200) lengthDivisionInt2 = 200;
                else if (lengthDivision2 > 200 && lengthDivision2 <= 250) lengthDivisionInt2 = 200;
                else if (lengthDivision2 > 250 && lengthDivision2 <= 300) lengthDivisionInt2 = 300;
                else if (lengthDivision2 > 300 && lengthDivision2 <= 350) lengthDivisionInt2 = 300;
                else if (lengthDivision2 > 350 && lengthDivision2 <= 400) lengthDivisionInt2 = 300;
                else if (lengthDivision2 > 400 && lengthDivision2 <= 450) lengthDivisionInt2 = 400;
                else if (lengthDivision2 > 450 && lengthDivision2 <= 500) lengthDivisionInt2 = 400;
                else if (lengthDivision2 > 500 && lengthDivision2 <= 1000) lengthDivisionInt2 = 500;
                else if (lengthDivision2 > 1000 && lengthDivision2 <= 5000) lengthDivisionInt2 = 1000;
                else if (lengthDivision2 > 5000) lengthDivisionInt2 = 1000;
                
                lengthPix2 = ((yDimension*0.2)/(double)verticalScaleHighDownDivisionHold)*lengthDivisionInt2;
                numberOfDivision2 = (int)((yDimension*0.2)/(double)lengthPix2)+1;
                
                for (int counter2 = 1; counter2 < numberOfDivision2; counter2++){
                    if (yStart+yDimension*0.2-lengthPix2*counter2 > yStart){
                        
                        positionAA.x = xStart*magFactor;
                        positionAA.y = yStart*magFactor+yDimension*0.2*magFactor-lengthPix2*counter2*magFactor;
                        positionBB.x = xStart*magFactor+5*magFactor;
                        positionBB.y = yStart*magFactor+yDimension*0.2*magFactor-lengthPix2*counter2*magFactor;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        if (counter1 == 0 || counter1 == 2 || counter1 == 4 || counter1 == 6 || counter1 == 8){
                            NSString *timeNSstring3 = @(to_string(counter2*lengthDivisionInt2+verticalScaleLowHold).c_str());
                            NSDictionary *attributes3 = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                            NSAttributedString *attrStrS3 = [[NSAttributedString alloc] initWithString:timeNSstring3 attributes:attributes3];
                            size2 = [attrStrS3 size].width;
                            
                            NSAttributedString *attrStrA2;
                            NSMutableDictionary *attributesA2 = [NSMutableDictionary dictionary];
                            
                            [attributesA2 setObject:[NSFont boldSystemFontOfSize:fontSize*magFactor] forKey:NSFontAttributeName];
                            [attributesA2 setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                            
                            attrStrA2 = [[NSAttributedString alloc] initWithString:timeNSstring3 attributes:attributesA];
                            pointA2.x = xStart*magFactor-size2-10*magFactor;
                            pointA2.y = yStart*magFactor+yDimension*0.2*magFactor-lengthPix2*counter2*magFactor-5*magFactor;
                            [attrStrA2 drawAtPoint:pointA2];
                        }
                    }
                }
                
                if (counter1 == 0 || counter1 == 2 || counter1 == 4 || counter1 == 6 || counter1 == 8){
                    //----Vertical Label----
                    NSString *verticalNSstring = @"Number of Events";
                    
                    NSFont *font2 = [NSFont boldSystemFontOfSize:fontSize*magFactor];
                    NSDictionary *attributes2 = [NSDictionary dictionaryWithObjectsAndKeys:font2, NSFontAttributeName, nil];
                    NSAttributedString *attrStrS2 = [[NSAttributedString alloc] initWithString:verticalNSstring attributes:attributes2];
                    size2 = [attrStrS2 size].width;
                    
                    NSGraphicsContext *context = [NSGraphicsContext currentContext];
                    NSAffineTransform *transform = [NSAffineTransform transform];
                    [transform rotateByDegrees:+90];
                    
                    [context saveGraphicsState];
                    [transform concat];
                    
                    NSAttributedString *attrStrB;
                    NSMutableDictionary *attributesB = [NSMutableDictionary dictionary];
                    NSString *titleStringB = @"Number of Events";
                    
                    [attributesB setObject:[NSFont boldSystemFontOfSize:fontSize*magFactor] forKey:NSFontAttributeName];
                    [attributesB setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                    attrStrB = [[NSAttributedString alloc] initWithString:titleStringB attributes:attributesB];
                    
                    pointA.x = yStart*magFactor+(((yDimension*magFactor)/2)-size2/(double)2);
                    pointA.y = (lowestXPosition-5)*-1;
                    [attrStrB drawAtPoint:pointA];
                    
                    [context restoreGraphicsState];
                }
                
                [NSBezierPath setDefaultLineWidth:1.0*magFactor];
                
                int *cellNumberHoldDD = new int [horizontalScaleMaxDivisionHold+50];
                int *cellNumberHoldTD = new int [horizontalScaleMaxDivisionHold+50];
                int *cellNumberHoldHD = new int [horizontalScaleMaxDivisionHold+50];
                int *cellNumberHoldFU = new int [horizontalScaleMaxDivisionHold+50];
                int *cellNumberHoldCD = new int [horizontalScaleMaxDivisionHold+50];
                
                for (int counter3 = 0; counter3 < horizontalScaleMaxDivisionHold+50; counter3++){
                    cellNumberHoldDD [counter3] = 0;
                    cellNumberHoldTD [counter3] = 0;
                    cellNumberHoldHD [counter3] = 0;
                    cellNumberHoldFU [counter3] = 0;
                    cellNumberHoldCD [counter3] = 0;
                }
                
                for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [entryNumberTempHold [counter1]]/9; counter3++){
                    actualTime = arrayLineageData [entryNumberTempHold [counter1]][counter3*9+2]*atoi(arrayLineageDataType [entryNumberTempHold [counter1]][5].c_str());
                    
                    if (arrayLineageData [entryNumberTempHold [counter1]][counter3*9+3] == 32){
                        cellNumberHoldDD [actualTime]++;
                    }
                    
                    if (arrayLineageData [entryNumberTempHold [counter1]][counter3*9+3] == 42){
                        cellNumberHoldTD [actualTime]++;
                    }
                    
                    if (arrayLineageData [entryNumberTempHold [counter1]][counter3*9+3] == 52){
                        cellNumberHoldHD [actualTime]++;
                    }
                    
                    if (arrayLineageData [entryNumberTempHold [counter1]][counter3*9+3] == 7){
                        cellNumberHoldFU [actualTime]++;
                    }
                    
                    if (arrayLineageData [entryNumberTempHold [counter1]][counter3*9+3] == 91){
                        cellNumberHoldCD [actualTime]++;
                    }
                }
                
                for (int counter2 = 0; counter2 <= horizontalScaleHighDivisionHold; counter2++){
                    if (counter2*magFactor-horizontalScaleLowDivisionHold*magFactor > 0 && counter2*magFactor-horizontalScaleLowDivisionHold*magFactor <= horizontalScaleHighDivisionHold*magFactor){
                        if (cellNumberHoldDD[counter2] != 0){
                            [[NSColor blueColor] set];
                            
                            positionAA.x = xStart*magFactor+((xDimension*magFactor)/(double)(horizontalTime*magFactor))*(counter2*magFactor-horizontalScaleLowDivisionHold*magFactor);
                            positionAA.y = yStart*magFactor+yDimension*0.2*magFactor;
                            positionBB.x = xStart*magFactor+((xDimension*magFactor)/(double)(horizontalTime*magFactor))*(counter2*magFactor-horizontalScaleLowDivisionHold*magFactor);
                            
                            if (yStart*magFactor+yDimension*0.2*magFactor+((yDimension*0.8*magFactor)/(double)(verticalScaleHighUpDivisionHold*magFactor))*cellNumberHoldDD[counter2]*magFactor < yStart*magFactor+yDimension*magFactor){
                                positionBB.y = yStart*magFactor+yDimension*0.2*magFactor+(((yDimension*magFactor)*0.8)/(double)(verticalScaleHighUpDivisionHold*magFactor))*cellNumberHoldDD[counter2]*magFactor;
                            }
                            else positionBB.y = yStart*magFactor+yDimension*magFactor;
                            
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                        
                        if (belowDisplayType == 0){
                            [[NSColor redColor] set];
                            
                            positionAA.x = xStart*magFactor+((xDimension*magFactor)/(double)(horizontalTime*magFactor))*(counter2*magFactor-horizontalScaleLowDivisionHold*magFactor);
                            positionAA.y = yStart*magFactor+yDimension*0.2*magFactor;
                            positionBB.x = xStart*magFactor+((xDimension*magFactor)/(double)(horizontalTime*magFactor))*(counter2*magFactor-horizontalScaleLowDivisionHold*magFactor);
                            
                            if (yStart*magFactor+yDimension*0.2*magFactor-((yDimension*0.2*magFactor)/(double)(verticalScaleHighDownDivisionHold*magFactor))*cellNumberHoldTD[counter2]*magFactor > yStart*magFactor){
                                positionBB.y = yStart*magFactor+yDimension*0.2*magFactor-((yDimension*0.2*magFactor)/(double)(verticalScaleHighDownDivisionHold*magFactor))*cellNumberHoldTD[counter2]*magFactor;
                            }
                            else positionBB.y = yStart*magFactor;
                            
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                        else if (belowDisplayType == 1){
                            [[NSColor magentaColor] set];
                            
                            positionAA.x = xStart*magFactor+((xDimension*magFactor)/(double)(horizontalTime*magFactor))*(counter2*magFactor-horizontalScaleLowDivisionHold*magFactor);
                            positionAA.y = yStart*magFactor+yDimension*0.2*magFactor;
                            positionBB.x = xStart*magFactor+((xDimension*magFactor)/(double)(horizontalTime*magFactor))*(counter2*magFactor-horizontalScaleLowDivisionHold*magFactor);
                            
                            if (yStart*magFactor+yDimension*0.2*magFactor-((yDimension*0.2*magFactor)/(double)(verticalScaleHighDownDivisionHold*magFactor))*cellNumberHoldTD[counter2]*magFactor > yStart*magFactor){
                                positionBB.y = yStart*magFactor+yDimension*0.2*magFactor-((yDimension*0.2*magFactor)/(double)(verticalScaleHighDownDivisionHold*magFactor))*cellNumberHoldTD[counter2]*magFactor;
                            }
                            else positionBB.y = yStart*magFactor;
                            
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                        else if (belowDisplayType == 2){
                            [[NSColor purpleColor] set];
                            
                            positionAA.x = xStart*magFactor+((xDimension*magFactor)/(double)(horizontalTime*magFactor))*(counter2*magFactor-horizontalScaleLowDivisionHold*magFactor);
                            positionAA.y = yStart*magFactor+yDimension*0.2*magFactor;
                            positionBB.x = xStart*magFactor+((xDimension*magFactor)/(double)(horizontalTime*magFactor))*(counter2*magFactor-horizontalScaleLowDivisionHold*magFactor);
                            
                            if (yStart*magFactor+yDimension*0.2*magFactor-((yDimension*0.2*magFactor)/(double)(verticalScaleHighDownDivisionHold*magFactor))*cellNumberHoldTD[counter2]*magFactor > yStart*magFactor){
                                positionBB.y = yStart*magFactor+yDimension*0.2*magFactor-((yDimension*0.2*magFactor)/(double)(verticalScaleHighDownDivisionHold*magFactor))*cellNumberHoldTD[counter2]*magFactor;
                            }
                            else positionBB.y = yStart*magFactor;
                            
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                        else if (belowDisplayType == 3){
                            [[NSColor orangeColor] set];
                            
                            positionAA.x = xStart*magFactor+((xDimension*magFactor)/(double)(horizontalTime*magFactor))*(counter2*magFactor-horizontalScaleLowDivisionHold*magFactor);
                            positionAA.y = yStart*magFactor+yDimension*0.2*magFactor;
                            positionBB.x = xStart*magFactor+((xDimension*magFactor)/(double)(horizontalTime*magFactor))*(counter2*magFactor-horizontalScaleLowDivisionHold*magFactor);
                            
                            if (yStart*magFactor+yDimension*0.2*magFactor-((yDimension*0.2*magFactor)/(double)(verticalScaleHighDownDivisionHold*magFactor))*cellNumberHoldTD[counter2]*magFactor > yStart*magFactor){
                                positionBB.y = yStart*magFactor+yDimension*0.2*magFactor-((yDimension*0.2*magFactor)/(double)(verticalScaleHighDownDivisionHold*magFactor))*cellNumberHoldTD[counter2]*magFactor;
                            }
                            else positionBB.y = yStart*magFactor;
                            
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                        else if (belowDisplayType == 4){
                            [[NSColor blackColor] set];
                            
                            positionAA.x = xStart*magFactor+((xDimension*magFactor)/(double)(horizontalTime*magFactor))*(counter2*magFactor-horizontalScaleLowDivisionHold*magFactor);
                            positionAA.y = yStart*magFactor+yDimension*0.2*magFactor;
                            positionBB.x = xStart*magFactor+((xDimension*magFactor)/(double)(horizontalTime*magFactor))*(counter2*magFactor-horizontalScaleLowDivisionHold*magFactor);
                            
                            if (yStart*magFactor+yDimension*0.2*magFactor-((yDimension*0.2*magFactor)/(double)(verticalScaleHighDownDivisionHold*magFactor))*cellNumberHoldTD[counter2]*magFactor > yStart*magFactor){
                                positionBB.y = yStart*magFactor+yDimension*0.2*magFactor-((yDimension*0.2*magFactor)/(double)(verticalScaleHighDownDivisionHold*magFactor))*cellNumberHoldTD[counter2]*magFactor;
                            }
                            else positionBB.y = yStart*magFactor;
                            
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                    }
                }
                
                delete [] cellNumberHoldDD;
                delete [] cellNumberHoldTD;
                delete [] cellNumberHoldHD;
                delete [] cellNumberHoldFU;
                delete [] cellNumberHoldCD;
            }
        }
        
        delete [] entryNumberTempHold;
        
        [NSGraphicsContext restoreGraphicsState];
        
        NSData *imageExportData;
        imageExportData = [bitmapReps TIFFRepresentation];
        
        [imageExportData writeToFile:@(exportResultPath.c_str()) atomically:YES];
        
        exportFlag6 = 2;
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToCellDivisionDisplay object:nil];
}

@end
