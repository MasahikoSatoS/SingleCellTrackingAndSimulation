//
//  BackUpCheckController.h
//  Focal_Image_Selection
//
//  Created by Masahiko Sato on 2019-06-03.
//  Copyright Masahiko Sato 2019 All rights reserved.
//

#ifndef BACKUPCHECKCONTROLLER_H
#define BACKUPCHECKCONTROLLER_H
#import "Controller.h" 
#endif

@interface BackUpCheckController : NSObject{
    string bodyNameBack; //Body name backup
    
    IBOutlet NSTextField *backUpFileNameDisplay;
    
    IBOutlet NSWindow *backUpCheckWindow;
    IBOutlet NSBrowser *listBrowser;
    IBOutlet NSSlider *sliderContrast;
    
    NSTimer *backUpCheckTimer;
    NSWindowController *backUpCheckWindowController;
    
    id tiffFileRead;
}

-(id)init;
-(void)reDisplayWindow;
-(void)directoryInfoDataUpDate;
-(void)backUpDirectoryDataUpDate;
-(void)backUpFolderNoUpDate;
-(void)backUpFileDateUpDate;
-(void)dealloc;

-(IBAction)closeWindow:(id)sender;
-(IBAction)browserDoubleClick:(id)browser;
-(IBAction)sliderAction:(id)sender;
-(IBAction)tableReload:(id)sender;
-(IBAction)backUpDirectoryLoad:(id)sender;
-(IBAction)backUpDirectoryClear:(id)sender;

@end
