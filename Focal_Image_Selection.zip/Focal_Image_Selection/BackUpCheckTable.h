//
//  BackUpCheckTable.h
//  Focal_Image_Selection
//
//  Created by Masahiko Sato on 2019-06-03.
//  Copyright Masahiko Sato 2019 All rights reserved.
//

#ifndef BACKUPCHECKTABLE_H
#define BACKUPCHECKTABLE_H
#import "Controller.h" 
#endif

@interface BackUpCheckTable : NSObject <NSTableViewDataSource>{
    IBOutlet NSTableView *backUpTableViewList;
}

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;
-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex;

@end
