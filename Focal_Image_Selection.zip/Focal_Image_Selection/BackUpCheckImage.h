//
//  BackUpCheckImage.h
//  Focal_Image_Selection
//
//  Created by Masahiko Sato on 2019-06-03.
//  Copyright Masahiko Sato 2019 All rights reserved.
//

#ifndef BACKUPCHECKIMAGE_H
#define BACKUPCHECKIMAGE_H
#import "Controller.h" 
#endif

@interface BackUpCheckImage : NSView{
    double xPointDownBackUp; //Image display control
    double yPointDownBackUp; //Image display control
    double xPositionMoveBackUp; //Image display control
    double yPositionMoveBackUp; //Image display control
    double xPointDragBackUp; //Image display control
    double yPointDragBackUp; //Image display control
    double xPositionBackUp; //Image display control
    double yPositionBackUp; //Image display control
    double xPositionAdjustBackUp; //Image display control
    double yPositionAdjustBackUp; //Image display control
    int mouseDragFlagBackUp; //Image display control
    
    IBOutlet NSImage *backUpStackImage;
}

-(void)mouseDown:(NSEvent *)event;
-(void)mouseUp:(NSEvent *)event;
-(void)mouseDragged:(NSEvent *)event;
-(void)keyDown:(NSEvent *)event;
-(BOOL)acceptsFirstResponder;
-(void)dealloc;

@end
