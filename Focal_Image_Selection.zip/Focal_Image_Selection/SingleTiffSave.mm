//
//  SingleTiffSave.m
//  Focal_Image_Selection
//
//  Created by Masahiko Sato on 2021-06-16.
//  Copyright Masahiko Sato 2021 All rights reserved.
//

#import "SingleTiffSave.h"

@implementation SingleTiffSave

-(unsigned long)singleTiffLayerSave:(int)imageDimensionX :(int)imageDimensionY :(int)imageBitPerPix :(int)photometric :(int)samplePerPix :(double)xPositionImage :(double)yPositionImage :(int)mode :(unsigned long)ifDPrevious{
    //-----mode = 0; For single layer, mode = 1; for multilayer----
    //-----ifDPrevious-----IFD address of Next Address entry----
    //-----positionCount: last writing position, next writing position will be +1, ----
    
    unsigned long dataTemp = 0;
    long positionCount = 0;
    long sizeForCopy = 0;
    
    char *fileImageArray = new char [10];
    
    if (mode == 1 && ifDPrevious != 0){
        struct stat sizeOfFile;
        
        stat(fileSavePathHold.c_str(), &sizeOfFile);
        sizeForCopy = sizeOfFile.st_size;
        
        delete [] fileImageArray;
        fileImageArray = new char [(int)sizeForCopy];
        ifstream fin2;
        fin2.open(fileSavePathHold.c_str(), ios::in | ios::binary);
        
        fin2.read((char*)fileImageArray, sizeForCopy);
        fin2.close();
    }
    
    char value1 = 0;
    char value2 = 0;
    char value3 = 0;
    char value4 = 0;
    
    ofstream oin;
    
    oin.open(fileSavePathHold, ios::out | ios::binary);
    
    if (mode == 1 && ifDPrevious != 0){
        for (long counter4 = 0; counter4 < sizeForCopy; counter4++){
            oin.put(fileImageArray [counter4]), positionCount++;
        }
        
        positionCount--;
    }
    
    delete [] fileImageArray;
    
    char *idfPreset = new char [200];
    int idfPresetCount = 0;
    
    idfPreset [idfPresetCount] = 16, idfPresetCount++;
    idfPreset [idfPresetCount] = 0, idfPresetCount++;
    
    for (int counter4 = 0; counter4 < 16; counter4++){
        if (mode == 0 && counter4 == 0){ //----NewSubfileType----
            idfPreset [idfPresetCount] = (char)254, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 4, idfPresetCount++;//----LONG
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;//----Count field, 0: no data field entry
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
        }
        else if (mode == 1 && counter4 == 0){ //----NewSubfileType----
            idfPreset [idfPresetCount] = (char)254, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 4, idfPresetCount++;//----LONG
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 1, idfPresetCount++;//----Count field, 0: no data field entry
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 2, idfPresetCount++;//----Data field, 2: multilayer tiff
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
        }
        
        if (counter4 == 1){ //----Image Width----100
            value1 = (char)(imageDimensionX/16777216);
            dataTemp = (unsigned long)(imageDimensionX%16777216);
            value2 = (char)(dataTemp/65536);
            dataTemp = dataTemp%65536;
            value3 = (char)(dataTemp/256);
            dataTemp = dataTemp%256;
            value4 = (char)dataTemp;
            
            idfPreset [idfPresetCount] = 0, idfPresetCount++;//==+14
            idfPreset [idfPresetCount] = 1, idfPresetCount++;
            idfPreset [idfPresetCount] = 4, idfPresetCount++;//----LONG
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 1, idfPresetCount++;//----Count Field, 1:
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = value4, idfPresetCount++;//==+22 Width
            idfPreset [idfPresetCount] = value3, idfPresetCount++;
            idfPreset [idfPresetCount] = value2, idfPresetCount++;
            idfPreset [idfPresetCount] = value1, idfPresetCount++;
        }
        if (counter4 == 2){ //----Image Hight-----101
            value1 = (char)(imageDimensionY/16777216);
            dataTemp = (unsigned long)(imageDimensionY%16777216);
            value2 = (char)(dataTemp/65536);
            dataTemp = dataTemp%65536;
            value3 = (char)(dataTemp/256);
            dataTemp = dataTemp%256;
            value4 = (char)dataTemp;
            
            idfPreset [idfPresetCount] = 1, idfPresetCount++;//===+26
            idfPreset [idfPresetCount] = 1, idfPresetCount++;
            idfPreset [idfPresetCount] = 4, idfPresetCount++;//----LONG
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 1, idfPresetCount++;//----Count field. 1:
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = value4, idfPresetCount++;//==+34 Height
            idfPreset [idfPresetCount] = value3, idfPresetCount++;
            idfPreset [idfPresetCount] = value2, idfPresetCount++;
            idfPreset [idfPresetCount] = value1, idfPresetCount++;
        }
        if (counter4 == 3){ //----BitPerSample----102--Save either 8 bit Gray or  8 bit RGB without Alpha----
            idfPreset [idfPresetCount] = 2, idfPresetCount++;//===+38
            idfPreset [idfPresetCount] = 1, idfPresetCount++;
            idfPreset [idfPresetCount] = 3, idfPresetCount++;//----Short
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            
            //----Sample perPixel 1: Grayscale, 3: RGB, 4: RGB+alpha
            if (photometric <= 1) idfPreset [idfPresetCount] = 1, idfPresetCount++;
            else idfPreset [idfPresetCount] = 3, idfPresetCount++;
            
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            //====bit/sample+46, For Gray (8 bit, 8, 16 bit, 16) For RGB and RGB+Alpha (8 bit), enter pointer (08, 08, 08), (08, 08, 08, 08), For RGB and RGB+Alpha (16 bit), enter pointer (16, 16, 16), (16, 16, 16, 16)
            
            if (imageBitPerPix == 8 && photometric == 1){
                idfPreset [idfPresetCount] = 8, idfPresetCount++;
            }
            else if (imageBitPerPix == 16 && photometric == 1){
                idfPreset [idfPresetCount] = 16, idfPresetCount++;
            }
            else{
                
                idfPreset [idfPresetCount] = 0, idfPresetCount++;
            }
            
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
        }
        if (counter4 == 4){ //----Compression----103
            idfPreset [idfPresetCount] = 3, idfPresetCount++;//===+50
            idfPreset [idfPresetCount] = 1, idfPresetCount++;
            idfPreset [idfPresetCount] = 3, idfPresetCount++;//----SHORT
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 1, idfPresetCount++;//----Count Field, 1:
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 1, idfPresetCount++;//====+66, Compression, 1: non-compression
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
        }
        if (counter4 == 5){ //----Photometric Interpretation----106
            idfPreset [idfPresetCount] = 6, idfPresetCount++;//=======+62
            idfPreset [idfPresetCount] = 1, idfPresetCount++;
            idfPreset [idfPresetCount] = 3, idfPresetCount++;//----SHORT
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 1, idfPresetCount++;//----Count Field, 1:
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = (char)photometric, idfPresetCount++;//====PhotoMetric, Gray (0: 00 is white, 1: 00 is black), 2: RGB
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
        }
        if (counter4 == 6){ //----Image descriptor-----10E
            idfPreset [idfPresetCount] = 14, idfPresetCount++;//========+74
            idfPreset [idfPresetCount] = 1, idfPresetCount++;
            idfPreset [idfPresetCount] = 2, idfPresetCount++;//----ASCII
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;//====+78 comment length, Count field
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;//====+82 Comment Address pointer
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
        }
        if (counter4 == 7){ //-----StripOffset-----011
            idfPreset [idfPresetCount] = 17, idfPresetCount++;//======+86
            idfPreset [idfPresetCount] = 1, idfPresetCount++;
            idfPreset [idfPresetCount] = 4, idfPresetCount++;//----LONG
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;//====+90 number of block
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;//====+94 block start address, LONG
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
        }
        if (counter4 == 8){ //----Orientation----012
            idfPreset [idfPresetCount] = 18, idfPresetCount++;//======+98 Orientation
            idfPreset [idfPresetCount] = 1, idfPresetCount++;
            idfPreset [idfPresetCount] = 3, idfPresetCount++;//----SHORT
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 1, idfPresetCount++;//----Count field, 1:
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 1, idfPresetCount++;//-----Data field, 1: Normal
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
        }
        if (counter4 == 9){ //----SamplePerPix-----015
            idfPreset [idfPresetCount] = 21, idfPresetCount++;//====+110
            idfPreset [idfPresetCount] = 1, idfPresetCount++;
            idfPreset [idfPresetCount] = 3, idfPresetCount++;//----SHORT
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 1, idfPresetCount++;//-----Count field, 1:
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            
            if (photometric == 1){//----Gray 8 bit:1, Gray 16 bit: 1, RGB 8 bit : 3, RGB+Alpha: 4, RGB 16 bit: 3, RGB+Alpha: 4
                idfPreset [idfPresetCount] = 1, idfPresetCount++;
            }
            else idfPreset [idfPresetCount] = 3, idfPresetCount++;
            
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
        }
        if (counter4 == 10){ //----RowPerStrip----116
            idfPreset [idfPresetCount] = 22, idfPresetCount++;//====+122
            idfPreset [idfPresetCount] = 1, idfPresetCount++;
            idfPreset [idfPresetCount] = 3, idfPresetCount++;//----SHORT
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 1, idfPresetCount++;//----Count field, 1:
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;//====Strip/row+130, Total Bytes of a strip/Bite of Image width (124000 byte (width 6200, 4 bite per pix, five Rows/width*4 bites) = 5)
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
        }
        if (counter4 == 11){ //----StripByteCount-----117
            idfPreset [idfPresetCount] = 23, idfPresetCount++;//=====+134
            idfPreset [idfPresetCount] = 1, idfPresetCount++;
            idfPreset [idfPresetCount] = 4, idfPresetCount++;//----LONG
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;//====+138 Strip entry, No of Strip
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;//====+142 Strip/Count, Pointer address
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
        }
        if (counter4 == 12){ //----PlanarConfiguration-----11C
            idfPreset [idfPresetCount] = 28, idfPresetCount++;//=====+146 Planar configuration
            idfPreset [idfPresetCount] = 1, idfPresetCount++;
            idfPreset [idfPresetCount] = 3, idfPresetCount++;//-----SHORT
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 1, idfPresetCount++;//-----Count Field, 1:
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 1, idfPresetCount++;//----Only for RGB, 1: pix order
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
        }
        if (counter4 == 13){ //----Resolution Unit-----128
            idfPreset [idfPresetCount] = 40, idfPresetCount++;//=====+158 resolutionunit
            idfPreset [idfPresetCount] = 1, idfPresetCount++;
            idfPreset [idfPresetCount] = 3, idfPresetCount++;//----SHORT
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 1, idfPresetCount++;//----Count field, 1:
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 2, idfPresetCount++;//----Inch, 2:
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
        }
        if (counter4 == 14){ //-----Program Name----131
            idfPreset [idfPresetCount] = 49, idfPresetCount++;//=====+170
            idfPreset [idfPresetCount] = 1, idfPresetCount++;
            idfPreset [idfPresetCount] = 2, idfPresetCount++;//ASCII
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 8, idfPresetCount++;//----Length----(CLIALive-8 bytes)
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;//====+178 program name, address pointer
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
        }
        if (counter4 == 15){ //----Date and time-----132
            idfPreset [idfPresetCount] = 50, idfPresetCount++;//=====+182
            idfPreset [idfPresetCount] = 1, idfPresetCount++;
            idfPreset [idfPresetCount] = 2, idfPresetCount++;//ASCII
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;//----Length----
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;//====+190 Date and time
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
            idfPreset [idfPresetCount] = 0, idfPresetCount++;
        }
    }
    
    if (mode == 0 || ifDPrevious == 0){
        oin.put(73), oin.put(73), oin.put(42), oin.put(0);
        oin.put(0), oin.put(0), oin.put(0), oin.put(0); //----First IFD address
        
        positionCount = 7;
    }
    
    unsigned long blockStartingAddress = (unsigned long)positionCount+1;
    int rowStripCount = 0;
    int stripByteCount = 0;
    int firstStripBlock = 0;
    int newEntryStripCount = imageDimensionY/8+1;
    
    unsigned long *blockAddressList = new unsigned long [newEntryStripCount+10];
    int blockAddressListCount = 0;
    unsigned long *blockByteList = new unsigned long [newEntryStripCount+10];
    int blockByteListCount = 0;
    
    for (int counter3 = 0; counter3 < imageDimensionY; counter3++){
        for (int counter4 = 0; counter4 < imageDimensionX; counter4++){
            if (imageBitPerPix == 8 && photometric == 1){
                oin.put((char)arrayImageFileSave [counter3][counter4]), positionCount++;
                
                if (firstStripBlock == 0) stripByteCount++;
            }
            else if (imageBitPerPix == 16 && photometric == 1){
                value3 = (char)(arrayImageFileSave [counter3][counter4]/256);
                dataTemp = (unsigned long)(arrayImageFileSave [counter3][counter4]%256);
                value4 = (char)dataTemp;
                
                oin.put(value4), positionCount++;
                oin.put(value3), positionCount++;
                
                if (firstStripBlock == 0) stripByteCount = stripByteCount+2;
            }
            else if (imageBitPerPix == 8 && photometric == 2){
                oin.put((char)arrayImageFileSave [counter3][counter4*3]), positionCount++;
                oin.put((char)arrayImageFileSave [counter3][counter4*3+1]), positionCount++;
                oin.put((char)arrayImageFileSave [counter3][counter4*3+2]), positionCount++;
                
                if (firstStripBlock == 0) stripByteCount = stripByteCount+3;
            }
            else if (imageBitPerPix == 16 && photometric == 2){
                value3 = (char)(arrayImageFileSave [counter3][counter4*3]/256);
                dataTemp = (unsigned long)(arrayImageFileSave [counter3][counter4*3]%256);
                value4 = (char)dataTemp;
                
                oin.put(value4), positionCount++;
                oin.put(value3), positionCount++;
                
                value3 = (char)(arrayImageFileSave [counter3][counter4*3+1]/256);
                dataTemp = (unsigned long)(arrayImageFileSave [counter3][counter4*3+1]%256);
                value4 = (char)dataTemp;
                
                oin.put(value4), positionCount++;
                oin.put(value3), positionCount++;
                
                value3 = (char)(arrayImageFileSave [counter3][counter4*3+2]/256);
                dataTemp = (unsigned long)(arrayImageFileSave [counter3][counter4*3+2]%256);
                value4 = (char)dataTemp;
                
                oin.put(value4), positionCount++;
                oin.put(value3), positionCount++;
                
                if (firstStripBlock == 0) stripByteCount = stripByteCount+6;
            }
        }
        
        if (rowStripCount == 7){ //----RowPerStrip = 8----
            blockAddressList [blockAddressListCount] = blockStartingAddress, blockAddressListCount++;
            
            if (imageBitPerPix == 8 && photometric == 1){
                blockByteList [blockByteListCount] = (unsigned long)imageDimensionX*((unsigned long)rowStripCount+1), blockByteListCount++;
            }
            else if (imageBitPerPix == 16 && photometric == 1){
                blockByteList [blockByteListCount] = (unsigned long)imageDimensionX*((unsigned long)rowStripCount+1)*2, blockByteListCount++;
            }
            else if (imageBitPerPix == 8 && photometric == 2){
                blockByteList [blockByteListCount] = (unsigned long)imageDimensionX*((unsigned long)rowStripCount+1)*3, blockByteListCount++;
            }
            else if (imageBitPerPix == 16 && photometric == 2){
                blockByteList [blockByteListCount] = (unsigned long)imageDimensionX*((unsigned long)rowStripCount+1)*6, blockByteListCount++;
            }
            
            blockStartingAddress = (unsigned long)positionCount+1;
            
            rowStripCount = 0;
            firstStripBlock = 1;
        }
        else if (counter3 == imageDimensionY-1){
            rowStripCount++;
            
            blockAddressList [blockAddressListCount] = blockStartingAddress, blockAddressListCount++;
            
            if (imageBitPerPix == 8 && photometric == 1){
                blockByteList [blockByteListCount] = (unsigned long)imageDimensionX*(unsigned long)rowStripCount, blockByteListCount++;
            }
            else if (imageBitPerPix == 16 && photometric == 1){
                blockByteList [blockByteListCount] = (unsigned long)imageDimensionX*(unsigned long)rowStripCount*2, blockByteListCount++;
            }
            else if (imageBitPerPix == 8 && photometric == 2){
                blockByteList [blockByteListCount] = (unsigned long)imageDimensionX*(unsigned long)rowStripCount*3, blockByteListCount++;
            }
            else if (imageBitPerPix == 16 && photometric == 2){
                blockByteList [blockByteListCount] = (unsigned long)imageDimensionX*(unsigned long)rowStripCount*6, blockByteListCount++;
            }
            
            rowStripCount = 0;
        }
        else rowStripCount++;
    }
    
    ascIIconversion = [[ASCIIconversion alloc] init];
    
    unsigned long ifdStartingAddress = (unsigned long)positionCount+1;
    
    //----IFD address----
    if (mode == 0 || ifDPrevious == 0){
        value1 = (char)(ifdStartingAddress/16777216);
        dataTemp = ifdStartingAddress%16777216;
        value2 = (char)(dataTemp/65536);
        dataTemp = dataTemp%65536;
        value3 = (char)(dataTemp/256);
        dataTemp = dataTemp%256;
        value4 = (char)dataTemp;
        
        oin.seekp (4);
        oin.put(value4), oin.put(value3), oin.put(value2), oin.put(value1);
        oin.seekp (positionCount+1);
    }
    else{
        
        value1 = (char)(ifdStartingAddress/16777216);
        dataTemp = ifdStartingAddress%16777216;
        value2 = (char)(dataTemp/65536);
        dataTemp = dataTemp%65536;
        value3 = (char)(dataTemp/256);
        dataTemp = dataTemp%256;
        value4 = (char)dataTemp;
        
        oin.seekp ((long)ifDPrevious);
        oin.put(value4), oin.put(value3), oin.put(value2), oin.put(value1);
        oin.seekp (positionCount+1);
    }
    
    for (int counter3 = 0; counter3 < idfPresetCount; counter3++) oin.put((char)idfPreset [counter3]), positionCount++;
    
    //----BitPerSample----102--address----
    if (imageBitPerPix == 8 && photometric == 2){
        value1 = (char)((positionCount+1)/16777216);
        dataTemp = (unsigned long)((positionCount+1)%16777216);
        value2 = (char)(dataTemp/65536);
        dataTemp = dataTemp%65536;
        value3 = (char)(dataTemp/256);
        dataTemp = dataTemp%256;
        value4 = (char)dataTemp;
        
        oin.seekp ((long)ifdStartingAddress+46);
        oin.put(value4), oin.put(value3), oin.put(value2), oin.put(value1);
        oin.seekp (positionCount+1);
        
        oin.put(8), positionCount++;
        oin.put(0), positionCount++;
        oin.put(8), positionCount++;
        oin.put(0), positionCount++;
        oin.put(8), positionCount++;
        oin.put(0), positionCount++;
    }
    else if (imageBitPerPix == 16 && photometric == 2){
        value1 = (char)((positionCount+1)/16777216);
        dataTemp = (unsigned long)((positionCount+1)%16777216);
        value2 = (char)(dataTemp/65536);
        dataTemp = dataTemp%65536;
        value3 = (char)(dataTemp/256);
        dataTemp = dataTemp%256;
        value4 = (char)dataTemp;
        
        oin.seekp ((long)ifdStartingAddress+46);
        oin.put(value4), oin.put(value3), oin.put(value2), oin.put(value1);
        oin.seekp (positionCount+1);
        
        oin.put(0), positionCount++;
        oin.put(1), positionCount++;
        oin.put(0), positionCount++;
        oin.put(1), positionCount++;
        oin.put(0), positionCount++;
        oin.put(1), positionCount++;
    }
    
    //-----Comment address----
    value1 = (char)((positionCount+1)/16777216);
    dataTemp = (unsigned long)((positionCount+1)%16777216);
    value2 = (char)(dataTemp/65536);
    dataTemp = dataTemp%65536;
    value3 = (char)(dataTemp/256);
    dataTemp = dataTemp%256;
    value4 = (char)dataTemp;
    
    oin.seekp ((long)ifdStartingAddress+82); //----comment address
    oin.put(value4), oin.put(value3), oin.put(value2), oin.put(value1);
    oin.seekp (positionCount+1);
    
    int commentLength = 0;
    
    stringstream extention1;
    extention1 << xPositionImage;
    string xPositionTF = extention1.str();
    
    stringstream extention2;
    extention2 << yPositionImage;
    string yPositionTF = extention2.str();
    
    oin.put(0), positionCount++, commentLength++;
    oin.put(60), positionCount++, commentLength++;
    oin.put(34), positionCount++, commentLength++;
    
    string saveString = "stage-position-x";
    
    for (int counter3 = 0; counter3 < (int)saveString.length(); counter3++){
        ascIIstring = saveString.substr((unsigned long)counter3, 1);
        oin.put((char)[ascIIconversion ascIICode]), positionCount++, commentLength++;
    }
    
    oin.put(34), positionCount++, commentLength++;
    oin.put(0), positionCount++, commentLength++;
    
    saveString = "value=";
    
    for (int counter3 = 0; counter3 < (int)saveString.length(); counter3++){
        ascIIstring = saveString.substr((unsigned long)counter3, 1);
        oin.put((char)[ascIIconversion ascIICode]), positionCount++, commentLength++;
    }
    
    oin.put(34), positionCount++, commentLength++;
    
    for (int counter3 = 0; counter3 < (int)xPositionTF.length(); counter3++){
        ascIIstring = xPositionTF.substr((unsigned long)counter3, 1);
        oin.put((char)[ascIIconversion ascIICode]), positionCount++, commentLength++;
    }
    
    oin.put(34), positionCount++, commentLength++;
    oin.put(62), positionCount++, commentLength++;
    oin.put(13), positionCount++, commentLength++;
    oin.put(0), positionCount++, commentLength++;
    oin.put(0), positionCount++, commentLength++;
    oin.put(60), positionCount++, commentLength++;
    oin.put(34), positionCount++, commentLength++;
    
    saveString = "stage-position-y";
    
    for (int counter3 = 0; counter3 < (int)saveString.length(); counter3++){
        ascIIstring = saveString.substr((unsigned long)counter3, 1);
        oin.put((char)[ascIIconversion ascIICode]), positionCount++, commentLength++;
    }
    
    oin.put(34), positionCount++, commentLength++;
    oin.put(0), positionCount++, commentLength++;
    
    saveString = "value=", commentLength++;
    
    for (int counter3 = 0; counter3 < (int)saveString.length(); counter3++){
        ascIIstring = saveString.substr((unsigned long)counter3, 1);
        oin.put((char)[ascIIconversion ascIICode]), positionCount++, commentLength++;
    }
    
    oin.put(34), positionCount++;
    
    for (int counter3 = 0; counter3 < (int)yPositionTF.length(); counter3++){
        ascIIstring = yPositionTF.substr((unsigned long)counter3, 1);
        oin.put((char)[ascIIconversion ascIICode]), positionCount++, commentLength++;
    }
    
    oin.put(34), positionCount++, commentLength++;
    oin.put(62), positionCount++, commentLength++;
    oin.put(13), positionCount++, commentLength++;
    oin.put(0), positionCount++, commentLength++;
    oin.put(0), positionCount++, commentLength++;
    oin.put(60), positionCount++, commentLength++;
    oin.put(34), positionCount++, commentLength++;
    
    saveString = "SetInfo";
    
    for (int counter3 = 0; counter3 < (int)saveString.length(); counter3++){
        ascIIstring = saveString.substr((unsigned long)counter3, 1);
        oin.put((char)[ascIIconversion ascIICode]), positionCount++, commentLength++;
    }
    
    //----Comment length----
    oin.put(34), positionCount++, commentLength++;
    oin.put(62), positionCount++, commentLength++;
    oin.put(0), positionCount++, commentLength++;
    
    value1 = (char)(commentLength/16777216);
    dataTemp = (unsigned long)(commentLength%16777216);
    value2 = (char)(dataTemp/65536);
    dataTemp = dataTemp%65536;
    value3 = (char)(dataTemp/256);
    dataTemp = dataTemp%256;
    value4 = (char)dataTemp;
    
    oin.seekp ((long)ifdStartingAddress+78); //----Comment length
    oin.put(value4), oin.put(value3), oin.put(value2), oin.put(value1);
    oin.seekp (positionCount+1);
    
    //----Block address----
    value1 = (char)(blockAddressListCount/16777216);
    dataTemp = (unsigned long)(blockAddressListCount%16777216);
    value2 = (char)(dataTemp/65536);
    dataTemp = dataTemp%65536;
    value3 = (char)(dataTemp/256);
    dataTemp = dataTemp%256;
    value4 = (char)dataTemp;
    
    oin.seekp ((long)ifdStartingAddress+90); //----Number of block
    oin.put(value4), oin.put(value3), oin.put(value2), oin.put(value1);
    oin.seekp (positionCount+1);
    
    value1 = (char)((positionCount+1)/16777216);
    dataTemp = (unsigned long)((positionCount+1)%16777216);
    value2 = (char)(dataTemp/65536);
    dataTemp = dataTemp%65536;
    value3 = (char)(dataTemp/256);
    dataTemp = dataTemp%256;
    value4 = (char)dataTemp;
    
    oin.seekp ((long)ifdStartingAddress+94); //----Starting address
    oin.put(value4), oin.put(value3), oin.put(value2), oin.put(value1);
    oin.seekp (positionCount+1);
    
    for (int counter3 = 0; counter3 < blockAddressListCount; counter3++){
        value1 = (char)(blockAddressList [counter3]/16777216);
        dataTemp = blockAddressList [counter3]%16777216;
        value2 = (char)(dataTemp/65536);
        dataTemp = dataTemp%65536;
        value3 = (char)(dataTemp/256);
        dataTemp = dataTemp%256;
        value4 = (char)dataTemp;
        
        oin.put(value4), positionCount++, oin.put(value3), positionCount++, oin.put(value2), positionCount++, oin.put(value1), positionCount++;
    }
    
    //----RowPerStrip----
    int rowPerStripEntry = 0;
    
    if (imageBitPerPix == 8 && photometric == 1){
        if (stripByteCount/(double)imageDimensionX < 1) rowPerStripEntry = 1;
        else rowPerStripEntry = (int)(stripByteCount/(double)imageDimensionX);
    }
    else if (imageBitPerPix == 16 && photometric == 1){
        if (stripByteCount/(double)(imageDimensionX*2) < 1) rowPerStripEntry = 1;
        else rowPerStripEntry = (int)(stripByteCount/(double)(imageDimensionX*2));
    }
    else if (imageBitPerPix == 8 && photometric == 2){
        if (stripByteCount/(double)(imageDimensionX*3) < 1) rowPerStripEntry = 1;
        else rowPerStripEntry = (int)(stripByteCount/(double)(imageDimensionX*3));
    }
    else if (imageBitPerPix == 16 && photometric == 2){
        if (stripByteCount/(double)(imageDimensionX*6) < 1) rowPerStripEntry = 1;
        else rowPerStripEntry = (int)(stripByteCount/(double)(imageDimensionX*6));
    }
    
    value3 = (char)(rowPerStripEntry/256);
    dataTemp = (unsigned long)(rowPerStripEntry%256);
    value4 = (char)dataTemp;
    
    oin.seekp ((long)ifdStartingAddress+130); //----Strip/row
    oin.put(value4), oin.put(value3);
    oin.seekp (positionCount+1);
    
    //----Strip/count----
    value1 = (char)(blockByteListCount/16777216);
    dataTemp = (unsigned long)(blockByteListCount%16777216);
    value2 = (char)(dataTemp/65536);
    dataTemp = dataTemp%65536;
    value3 = (char)(dataTemp/256);
    dataTemp = dataTemp%256;
    value4 = (char)dataTemp;
    
    oin.seekp ((long)ifdStartingAddress+138); //----Strip byte, no of block
    oin.put(value4), oin.put(value3), oin.put(value2), oin.put(value1);
    oin.seekp (positionCount+1);
    
    value1 = (char)((positionCount+1)/16777216);
    dataTemp = (unsigned long)((positionCount+1)%16777216);
    value2 = (char)(dataTemp/65536);
    dataTemp = dataTemp%65536;
    value3 = (char)(dataTemp/256);
    dataTemp = dataTemp%256;
    value4 = (char)dataTemp;
    
    oin.seekp ((long)ifdStartingAddress+142); //----Strip byte, address
    oin.put(value4), oin.put(value3), oin.put(value2), oin.put(value1);
    oin.seekp (positionCount+1);
    
    for (int counter3 = 0; counter3 < blockByteListCount; counter3++){
        value1 = (char)(blockByteList [counter3]/16777216);
        dataTemp = blockByteList [counter3]%16777216;
        value2 = (char)(dataTemp/65536);
        dataTemp = dataTemp%65536;
        value3 = (char)(dataTemp/256);
        dataTemp = dataTemp%256;
        value4 = (char)dataTemp;
        
        oin.put(value4), positionCount++, oin.put(value3), positionCount++, oin.put(value2), positionCount++, oin.put(value1), positionCount++;
    }
    
    //----Software name-----
    value1 = (char)((positionCount+1)/16777216);
    dataTemp = (unsigned long)((positionCount+1)%16777216);
    value2 = (char)(dataTemp/65536);
    dataTemp = dataTemp%65536;
    value3 = (char)(dataTemp/256);
    dataTemp = dataTemp%256;
    value4 = (char)dataTemp;
    
    oin.seekp ((long)ifdStartingAddress+178);
    oin.put(value4), oin.put(value3), oin.put(value2), oin.put(value1);
    oin.seekp (positionCount+1);
    
    saveString = "CLIALive";
    
    for (int counter4 = 0; counter4 < (int)saveString.length(); counter4++){
        ascIIstring = saveString.substr((unsigned long)counter4, 1);
        oin.put((char)[ascIIconversion ascIICode]), positionCount++;
    }
    
    //----End mark----
    oin.put(0), positionCount++;
    
    saveString = "saic";
    
    for (int counter3 = 0; counter3 < (int)saveString.length(); counter3++){
        ascIIstring = saveString.substr((unsigned long)counter3, 1);
        oin.put((char)[ascIIconversion ascIICode]), positionCount++;
    }
    
    oin.put(0), positionCount++;
    
    delete [] blockAddressList;
    delete [] blockByteList;
    
    oin.close();
    
    delete [] idfPreset;
    
    return ifdStartingAddress+194;
}

@end
