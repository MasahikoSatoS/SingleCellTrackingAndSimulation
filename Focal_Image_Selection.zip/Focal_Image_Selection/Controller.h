//
//  Controller.h
//  Focal_Image_Selection
//
//  Created by Masahiko Sato on 28/12/09, 26/06/13 revised.
//  Copyright  Masahiko Sato 2009 All rights reserved.
//

#ifndef CONTROLLER_H
#define CONTROLLER_H
#import <Cocoa/Cocoa.h>
#import "ZImage.h"
#import "SplitProcessing.h"
#import "SingleTiffSave.h"
#import "TiffFileRead.h"
#import "TerminationMonitor.h"
#include <iostream>
#include <dirent.h>
#include <sys/stat.h>
#include <fstream>
#include <sstream>
#endif

using namespace std;

extern NSString *notificationToImageProcess;
extern NSString *notificationToImageDisplay;
extern NSString *notificationToTermination;
extern NSString *notificationToBackUpCheckControl;
extern NSString *notificationToBackUpCheckImage;
extern NSString *notificationToBackUpCheckTable;
extern NSString *notificationToBackUpCheckAddition;

//----Paths----
extern string productsFilesImagePath; //Products folder path for Source image
extern string productsFocalPlanePath; //Products file path for Focal Plane data
extern string productsFocalTreatmentPath; //Products file path for Treatment data
extern string productsFocalFOVPath; //Products file path for FOV data
extern string productsFocalTempPath; //Products file path for Temp
extern string namedFilesPath; //Named folder path
extern string focalSettingPath; //Setting data file path for Focal Selection
extern string nameAssignFilePath; //Name Assign. data file path
extern string backUpFolderPath; //backUpFolderPath
extern string instructionFIPath; //Instruction path
extern string instructionFIPath2; //Instruction path
extern string instructionCSPath; //Instruction path
extern string productsFocalPlaneTempPath; //Products focal plane temp path
extern string focalSettingTempPath; //Products setting temp path
extern string loadingCompletionPath; //Loading completion path
extern string backgroundImagePath; //Background image path
extern string pathNameString; //Path name

//----Basic Info----
extern string bodyName; //Body Name
extern string ascIIstring; //ASCII
extern string totalFOVNoHold; //Total FOV no
extern string autoFolderName; //Hold smallest folder name or Exit
extern string copyDirectoryInfo; //Hold copy directory
extern string fileSavePathHold; //Path for Tiff file save
extern int copySetStatus; //Hold copy set status
extern int totalFOVNoHoldInt; //Total FOV
extern int timePointRequest; //Time point display call
extern int currentTimePoint; //Current time point
extern int fluorescentCount; //Number of fluorescent channel
extern int tableViewCall; //Table display call
extern int processMode; //Mode 1: Auto process, Mode 2: Initial Setting (first), Mode 3: Initial Setting (second), Mode 4: Batch (Back-up)
extern int currentTableHead; //Position of "C"
extern int imageProcessTiming; //Control image process timing
extern int importTableEnd; //Hold imported Table End
extern int dicRangeSet; //DIC range hold
extern int firstImageExclude; //Exclude first image
extern int focusProcessFlag; //Set when processing is on
extern int progressValue; //Hold Progress indicator value
extern int progressTiming; //Hold Progress indicator timing
extern int photoMetricHold; //Photometric

//----Arrays----
extern int **arrayFocalPlaneData; //Focal plane data array
extern int focalPlaneDataLimit;
extern int focalPlaneDataHorizontal; //Plane data horizontal value hold
extern string *arrayTableDisplay; //Array for table display
extern int tableDisplayCount;
extern string *arrayNameListOfFiles; //Array for file names
extern int nameListOfFilesCount;
extern int nameListOfFilesStatus;
extern string *arrayTreatmentNameDisplay; //Array for Table Display, treatment name
extern int treatmentNameDisplayCount;
extern string *arrayFOVNameDisplay; //Array for Table Display, FOV
extern int fOVNameDisplayCount;
extern string *arrayProcessList; //Hold Info related to the treat name, FOV no, Ch, Process info and results
extern int processListCount;
extern uint8_t *fileReadArray;//Array holding image data
extern int **arrayImageFileSave;//Image array for tif save

//----Z image display----
extern int **arrayImageDataHoldZImage; //Z image array
extern int imageDataHoldZImageStatus;
extern int zImageHeight; //Z image data
extern int zImageWidth; //Z image data
extern int zImagePlane; //Z image data
extern int currentPlaneDisplayCall; //Current plane no display call
extern int planeNumberDisplay; //Current plane no hold
extern double fluorescentEnhance; //Fluorescent enhance factor
extern string zImageColorSet; //Color for Z image
extern int magnificationDisplay; //Magnification
extern int imageFirstLoadFlagDisplay; //Image first load flag
extern double windowWidthDisplay; //Window size
extern double windowHeightDisplay; //Window size

//----Fluorescent-----
extern string fluorescentNo1; //Fluorescent name
extern string fluorescentNo2; //Fluorescent name
extern string fluorescentNo3; //Fluorescent name
extern string fluorescentNo4; //Fluorescent name
extern string fluorescentNo5; //Fluorescent name
extern string fluorescentNo6; //Fluorescent name
extern string fluorescentNoName1; //Fluorescent number
extern string fluorescentNoName2; //Fluorescent number
extern string fluorescentNoName3; //Fluorescent number
extern string fluorescentNoName4; //Fluorescent number
extern string fluorescentNoName5; //Fluorescent number
extern string fluorescentNoName6; //Fluorescent number

//----File order process or delete-----
extern string *arrayFileDelete; //File info hold array
extern int fileDeleteCount;
extern int fileDeleteLimit;

//----Back up files display (for focal plane check)-----
extern int backUpOperation; //Backup window operation
extern int imageFirstLoadFlagBackUp; //Backup image first load
extern string *backUpDirectoryArray; //Directory array
extern int backUpDirectoryCount;
extern int backUpDirectoryLimit;
extern string *backUpFolderNoUpDateArray; //Backup folder number array
extern int backUpFolderNoUpDateCount;
extern int backUpFolderNoUpDateLimit;
extern int photometricBackHold; //Photometric for backup image display

extern string *backUpFileArray; //File array
extern int backUpFileCount;
extern int backUpFileLimit;
extern int **arrayImageDataHoldBackUpImage; //Image data hold
extern int imageDataHoldBackUpImageStatus;
extern int backUpImageHeight; //Image info
extern int backUpImageWidth; //Image info
extern int backUpImagePlane; //Plane no
extern int planeNumberBackUpDisplay; //Plane no for display
extern double fluorescentEnhanceBackUp; //Fluorescent enhance factor
extern string backUpImageColorSet; //Color no
extern int magnificationBackUpDisplay; //Magnification
extern double windowWidthBackUpDisplay; //Window info
extern double windowHeightBackUpDisplay; //Window info
extern int tableRowHoldBackUp; //Hold table row position
extern int backUpTableCallCount; //Table call
extern int backUpTableCurrentRowHold; //Table operation
extern int backUpTableNewRowHold; //Table operation
extern int currentPlaneVBackUpCall; //Plane no display call

//----Directory Info Backup----
extern string *arrayDirectoryInfo; //Array for directory info
extern int directoryInfoCount;
extern int directoryInfoLimit;

@interface Controller : NSObject <NSTableViewDataSource> {
    int firstCommunication; //Communication set
    int basicInfoRead; //Read status data
    int initialArraySet; //Flag for the initial array set for the table display
    int tableCallCount; //For Table view
    int rowIndexHold; //Table operation
    int tableCurrentRowHold; //Table operation
    int exitFlag; //Exit flag
    int firstTimeSet; //Set when the focal selection is performed first time
    int lastColumnNoHold; //Last column number
    int lastRowNoHold; //Last row number
    string lastTypeHold; //Last type
    string imageReadFile; //File for image display
    
    IBOutlet NSTableView *tableViewList;
    
    IBOutlet NSTextField *totalFOVDisplay;
    IBOutlet NSTextField *bodyNameDisplay;
    IBOutlet NSTextField *timePointDisplay;
    IBOutlet NSTextField *currentPlaneDisplay;
    IBOutlet NSTextField *focalNoDisplay;
    IBOutlet NSTextField *zFileName;
    IBOutlet NSTextField *processModeDisplay;
    IBOutlet NSTextField *channelTypeDisplay;
    IBOutlet NSTextField *dicRangeDisplay;
    IBOutlet NSTextField *includeExcludeDisplay;
    IBOutlet NSTextField *copyFolderInfoDisplay;
    IBOutlet NSSlider *sliderFluorescent;
    
    IBOutlet NSWindow *controllerWindow;
    IBOutlet NSProgressIndicator *progressIndicator;
    
    NSTimer *controllerTimer;
    
    id tiffFileRead;
}

//*******Table Entry*******
//Plane number start from "1";
//Line one and line break: -1000
//No entry: -2000;
//No entry after T: -2500;

//**Time point head**
//Focal Plane: -3000
//Focal Plane+cont: -3500
//Fixed plane: -6001, -6002, -6003,.....
//Fixed plane+cont: -7001, -7002, -7003,.....
//All-in-one: -4000;
//All-in-one+cont: -4500;
//All-in-one center: -8001;
//All-in-one+cont: -9001;
//Range: -10111222; start 111, end 222
//Range+cont: -11111222:
//Terminated: -5000;

-(id)init;
-(void)dealloc;
-(void)processStartSub;
-(void)communication;
-(void)displayData;
-(void)tableDataSave;
-(void)stopProcessMain;
-(void)fileDeleteUpDate;
-(void)saveParameter;
-(void)tableBackwardForward :(int)startingTimePoint :(int)currentCutOff;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;
-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex;
-(void)tableView:(NSTableView *)aTableView setObjectValue:(id)anObject forTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;

-(IBAction)focalPlaneSet:(id)sender;
-(IBAction)constantPlaneSet:(id)sender;
-(IBAction)focalPlaneContrastSet:(id)sender;
-(IBAction)allInFocusSet:(id)sender;
-(IBAction)terminationSet:(id)sender;
-(IBAction)rangeSet:(id)sender;
-(IBAction)omnibusProcess:(id)sender;
-(IBAction)stopProcess:(id)sender;
-(IBAction)processStart:(id)sender;
-(IBAction)fwOmnibus:(id)sender;
-(IBAction)bwOmnibus:(id)sender;
-(IBAction)fwHundred:(id)sender;
-(IBAction)bwHundred:(id)sender;
-(IBAction)imageLoad:(id)sender;
-(IBAction)tableTreatSet:(id)sender;
-(IBAction)tableTillEndSet:(id)sender;
-(IBAction)tableTreatAndTillEndSet:(id)sender;

-(IBAction)tableImport:(id)sender;
-(IBAction)sliderAction:(id)sender;
-(IBAction)dicRangeNone:(id)sender;
-(IBAction)dicRange20:(id)sender;
-(IBAction)dicRange40:(id)sender;
-(IBAction)dicRange60:(id)sender;
-(IBAction)dicRange80:(id)sender;
-(IBAction)firstInclude:(id)sender;
-(IBAction)firstIncExclude:(id)sender;
-(IBAction)copyFolderSet:(id)sender;
-(IBAction)copyFolderClear:(id)sender;
-(IBAction)copyFolderDummy:(id)sender;
-(IBAction)backUpCheckSet:(id)sender;

@end
