//
//  BackUpCheckAddition.h
//  Focal_Image_Selection
//
//  Created by Masahiko Sato on 2019-06-05.
//  Copyright Masahiko Sato 2019 All rights reserved.
//

#ifndef BACKUPCHECKADDITION_H
#define BACKUPCHECKADDITION_H
#import "Controller.h" 
#endif

@interface BackUpCheckAddition : NSObject{
    int timingCount; //Timing count
    
    IBOutlet NSTextField *currentPlaneNumber;
    
    NSTimer *backUpCheckTimer2;
}

-(id)init;
-(void)dealloc;
-(void)displayData;

@end
