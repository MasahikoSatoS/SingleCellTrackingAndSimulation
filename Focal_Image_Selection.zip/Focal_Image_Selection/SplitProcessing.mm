/*
 *  SplitProcessing.m
 *  Focal_Image_Selection
 *
 *  Created by Masahiko Sato on 30/12/09, 26/06/13 revised.
 *  Copyright Masahiko Sato 2009 All rights reserved.
 *
 */

#import "SplitProcessing.h"

NSString *notificationToImageProcess = @"notificationToExecuteImageProcess";

@implementation SplitProcessing

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToImageProcess object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
        focusProcessFlag = 1;
        
        int processProceed = 0;
        int copyCheck = 1;
        struct stat sizeOfFile;
        
        if (copySetStatus == 1){
            string *dicTreatNameList = new string [treatmentNameDisplayCount];
            int dicTreatNameListCount = 0;
            
            int *dicTreatNameListProcess = new int [treatmentNameDisplayCount];
            
            string treatNameTemp;
            
            for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                treatNameTemp = arrayTreatmentNameDisplay [counter1];
                
                if (treatNameTemp != "ND"){
                    dicTreatNameList [dicTreatNameListCount] = treatNameTemp;
                    dicTreatNameListProcess [dicTreatNameListCount] = 0;
                    dicTreatNameListCount++;
                }
            }
            
            //for (int counterA = 0; counterA < dicTreatNameListCount; counterA++){
            //    cout<<counterA<<" "<<dicTreatNameList [counterA]<<" "<<dicTreatNameListProcess [counterA]<<" List"<<endl;
            //}
            
            processListCount = 0;
            
            string treatmentNameTemp;
            string fovExtractTemp;
            string channelTemp;
            string fileColorType;
            
            for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                if (arrayTableDisplay [counter1*17] != " " && arrayTableDisplay [counter1*17+1] != " "){
                    treatmentNameTemp = arrayTableDisplay [counter1*17];
                    arrayProcessList [processListCount] = treatmentNameTemp, processListCount++;
                    fovExtractTemp = arrayTableDisplay [counter1*17+1];
                    
                    if ((int)fovExtractTemp.find("FOV") != -1) fovExtractTemp = fovExtractTemp.substr(fovExtractTemp.find("FOV")+3);
                    else if ((int)fovExtractTemp.find("-") != -1) fovExtractTemp = fovExtractTemp.substr(fovExtractTemp.find("-")+1);
                    else fovExtractTemp = " ";
                    
                    arrayProcessList [processListCount] = fovExtractTemp, processListCount++;
                    
                    fovExtractTemp = arrayTableDisplay [counter1*17+1];
                    
                    if ((int)fovExtractTemp.find("CH") != -1){
                        channelTemp = fovExtractTemp.substr(fovExtractTemp.find("CH")+2, fovExtractTemp.find("-")-fovExtractTemp.find("CH")-2);
                        
                        if (channelTemp == "1") fileColorType = fluorescentNo1;
                        else if (channelTemp == "2") fileColorType = fluorescentNo2;
                        else if (channelTemp == "3") fileColorType = fluorescentNo3;
                        else if (channelTemp == "4") fileColorType = fluorescentNo4;
                        else if (channelTemp == "5") fileColorType = fluorescentNo5;
                        else if (channelTemp == "6") fileColorType = fluorescentNo6;
                        
                        arrayProcessList [processListCount] = fileColorType, processListCount++;
                    }
                    else arrayProcessList [processListCount] = "0", processListCount++;
                    
                    arrayProcessList [processListCount] = "0", processListCount++;
                    arrayProcessList [processListCount] = "0", processListCount++;
                }
                else if (arrayTableDisplay [counter1*17] == " " && arrayTableDisplay [counter1*17+1] != " "){
                    arrayProcessList [processListCount] = treatmentNameTemp, processListCount++;
                    
                    fovExtractTemp = arrayTableDisplay [counter1*17+1];
                    
                    if ((int)fovExtractTemp.find("FOV") != -1) fovExtractTemp = fovExtractTemp.substr(fovExtractTemp.find("FOV")+3);
                    else if ((int)fovExtractTemp.find("-") != -1) fovExtractTemp = fovExtractTemp.substr(fovExtractTemp.find("-")+1);
                    else fovExtractTemp = " ";
                    
                    arrayProcessList [processListCount] = fovExtractTemp, processListCount++;
                    
                    fovExtractTemp = arrayTableDisplay [counter1*17+1];
                    
                    if ((int)fovExtractTemp.find("CH") != -1){
                        channelTemp = fovExtractTemp.substr(fovExtractTemp.find("CH")+2, fovExtractTemp.find("-")-fovExtractTemp.find("CH")-2);
                        
                        if (channelTemp == "1") fileColorType = fluorescentNo1;
                        else if (channelTemp == "2") fileColorType = fluorescentNo2;
                        else if (channelTemp == "3") fileColorType = fluorescentNo3;
                        else if (channelTemp == "4") fileColorType = fluorescentNo4;
                        else if (channelTemp == "5") fileColorType = fluorescentNo5;
                        else if (channelTemp == "6") fileColorType = fluorescentNo6;
                        
                        arrayProcessList [processListCount] = fileColorType, processListCount++;
                    }
                    else arrayProcessList [processListCount] = "0", processListCount++;
                    
                    arrayProcessList [processListCount] = "0", processListCount++;
                    arrayProcessList [processListCount] = "0", processListCount++;
                }
            }
            
            int entryCountTemp = 0;
            
            for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                if (arrayFocalPlaneData [counter1][currentTimePoint+1] != 0){
                    arrayProcessList [entryCountTemp*5+3] = to_string(arrayFocalPlaneData [counter1][currentTimePoint+1]), entryCountTemp++;
                }
            }
            
            //for (int counterA = 0; counterA < processListCount/5; counterA++){
            //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayProcessList [counterA*5+counterB];
            //    cout<<" arrayProcessList "<<counterA+1<<endl;
            //}
            
            for (int counter1 = 0; counter1 < dicTreatNameListCount; counter1++){
                treatNameTemp = dicTreatNameList [counter1];
                
                for (int counter2 = 0; counter2 < processListCount/5; counter2++){
                    if (arrayProcessList [counter2] == treatNameTemp && (arrayProcessList [counter2*5+3] == "-2500" || arrayProcessList [counter2*5+3] == "-5000")){
                        dicTreatNameListProcess [counter2] = -1;
                        break;
                    }
                }
            }
            
            string currentNumber = to_string(currentTimePoint);
            
            if (currentNumber.length() == 1) currentNumber = "000"+currentNumber;
            else if (currentNumber.length() == 2) currentNumber = "00"+currentNumber;
            else if (currentNumber.length() == 3) currentNumber = "0"+currentNumber;
            
            DIR *dir;
            struct dirent *dent;
            DIR *dir2;
            struct dirent *dent2;
            DIR *dir3;
            struct dirent *dent3;
            DIR *dir4;
            struct dirent *dent4;
            
            string entry;
            string entry2;
            string entry3;
            string entry4;
            string pathName2;
            string pathName3;
            string pathName4;
            string pathName2B;
            string pathName3B;
            string pathName4B;
            string stringExtract;
            string stringExtract2;
            string treatNameHoldTempCH;
            string treatNameHoldTemp2;
            
            int fovCount = 0;
            int fovFindCount = 0;
            int fovFindCountFluorescent1 = 0;
            int fovFindCountFluorescent2 = 0;
            int fovFindCountFluorescent3 = 0;
            int fovFindCountFluorescent4 = 0;
            int fovFindCountFluorescent5 = 0;
            int fovFindCountFluorescent6 = 0;
            int fileNoCount = 0;
            
            dir = opendir(copyDirectoryInfo.c_str());
            
            if (dir != NULL){
                while((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("Source_Images") != -1){
                        pathName2 = copyDirectoryInfo+"/"+entry;
                        
                        dir2 = opendir(pathName2.c_str());
                        
                        if (dir2 != NULL){
                            while((dent2 = readdir(dir2))){
                                entry2 = dent2 -> d_name;
                                
                                if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store" && (int)entry2.find("~Sorted") != -1){
                                    pathName3 = pathName2+"/"+entry2;
                                    treatNameHoldTemp2 = entry2.substr(0, entry2.find("~Sorted"));
                                    
                                    fovCount = 0;
                                    fovFindCount = 0;
                                    fovFindCountFluorescent1 = 0;
                                    fovFindCountFluorescent2 = 0;
                                    fovFindCountFluorescent3 = 0;
                                    
                                    dir3 = opendir(pathName3.c_str());
                                    
                                    if (dir3 != NULL){
                                        while((dent3 = readdir(dir3))){
                                            entry3 = dent3 -> d_name;
                                            
                                            if (entry3 != "." && entry3 != ".." && entry3 != ".DS_Store" && (int)entry3.find("FOV") != -1){
                                                pathName4 = pathName3+"/"+entry3;
                                                
                                                fovCount++;
                                                
                                                dir4 = opendir(pathName4.c_str());
                                                
                                                if (dir4 != NULL){
                                                    while((dent4 = readdir(dir4))){
                                                        entry4 = dent4 -> d_name;
                                                        
                                                        if (entry4 != "." && entry4 != ".." && entry4 != ".DS_Store" && ((int)entry4.find("bmp") != -1 || (int)entry4.find("tif") != -1)){
                                                            stringExtract = entry4.substr(entry4.find("_")+1, 4);
                                                            
                                                            if (entry4.substr(entry4.find("FOV")+6, 1) == "_"){
                                                                stringExtract2 = entry4.substr(entry4.find("FOV")+7, 1);
                                                                
                                                                if ((atoi(stringExtract.c_str()) == atoi(currentNumber.c_str()) && atoi(stringExtract2.c_str()) == atoi(fluorescentNo1.c_str()))){
                                                                    fovFindCountFluorescent1++;
                                                                    fileNoCount++;
                                                                }
                                                                else if ((atoi(stringExtract.c_str()) == atoi(currentNumber.c_str()) && atoi(stringExtract2.c_str()) == atoi(fluorescentNo2.c_str()))){
                                                                    fovFindCountFluorescent2++;
                                                                    fileNoCount++;
                                                                }
                                                                else if ((atoi(stringExtract.c_str()) == atoi(currentNumber.c_str()) && atoi(stringExtract2.c_str()) == atoi(fluorescentNo3.c_str()))){
                                                                    fovFindCountFluorescent3++;
                                                                    fileNoCount++;
                                                                }
                                                                else if ((atoi(stringExtract.c_str()) == atoi(currentNumber.c_str()) && atoi(stringExtract2.c_str()) == atoi(fluorescentNo4.c_str()))){
                                                                    fovFindCountFluorescent4++;
                                                                    fileNoCount++;
                                                                }
                                                                else if ((atoi(stringExtract.c_str()) == atoi(currentNumber.c_str()) && atoi(stringExtract2.c_str()) == atoi(fluorescentNo5.c_str()))){
                                                                    fovFindCountFluorescent5++;
                                                                    fileNoCount++;
                                                                }
                                                                else if ((atoi(stringExtract.c_str()) == atoi(currentNumber.c_str()) && atoi(stringExtract2.c_str()) == atoi(fluorescentNo6.c_str()))){
                                                                    fovFindCountFluorescent6++;
                                                                    fileNoCount++;
                                                                }
                                                            }
                                                            else if (entry4.substr(entry4.find("FOV")+6, 1) == "."){
                                                                if (atoi(stringExtract.c_str()) == atoi(currentNumber.c_str())){
                                                                    fovFindCount++;
                                                                    fileNoCount++;
                                                                }
                                                            }
                                                        }
                                                    }
                                                    
                                                    closedir(dir4);
                                                }
                                            }
                                        }
                                        
                                        closedir(dir3);
                                    }
                                    
                                    for (int counter1 = 0; counter1 < dicTreatNameListCount; counter1++){
                                        treatNameHoldTempCH = "0";
                                        
                                        if ((int)dicTreatNameList [counter1].find("CH") != -1){
                                            treatNameHoldTempCH = dicTreatNameList [counter1].substr(dicTreatNameList [counter1].find("CH")+2);
                                        }
                                        
                                        if (treatNameHoldTempCH == "0"){
                                            if (dicTreatNameListProcess [counter1] == 0 && fovFindCount != 0 && fovCount != fovFindCount){
                                                dicTreatNameListProcess [counter1] = -2;
                                            }
                                            else if (dicTreatNameListProcess [counter1] == 0 && fovFindCount == 0){
                                                dicTreatNameListProcess [counter1] = -2;
                                            }
                                            else if (dicTreatNameListProcess [counter1] == 0 && fovFindCount != 0 && fovCount == fovFindCount){
                                                dicTreatNameListProcess [counter1] = 1;
                                            }
                                        }
                                        
                                        if (treatNameHoldTempCH == "1"){
                                            if (dicTreatNameListProcess [counter1] == 0 && fovFindCountFluorescent1 != 0 && fovCount != fovFindCountFluorescent1){
                                                dicTreatNameListProcess [counter1] = -2;
                                            }
                                            else if (dicTreatNameListProcess [counter1] == 0 && fovFindCountFluorescent1 == 0 && fovCount != 0){
                                                dicTreatNameListProcess [counter1] = 2;
                                            }
                                            else if (dicTreatNameListProcess [counter1] == 0 && fovFindCountFluorescent1 != 0 && fovCount == fovFindCountFluorescent1){
                                                dicTreatNameListProcess [counter1] = 1;
                                            }
                                        }
                                        
                                        if (treatNameHoldTempCH == "2"){
                                            if (dicTreatNameListProcess [counter1] == 0 && fovFindCountFluorescent2 != 0 && fovCount != fovFindCountFluorescent2){
                                                dicTreatNameListProcess [counter1] = -2;
                                            }
                                            else if (dicTreatNameListProcess [counter1] == 0 && fovFindCountFluorescent2 == 0 && fovCount != 0){
                                                dicTreatNameListProcess [counter1] = 2;
                                            }
                                            else if (dicTreatNameListProcess [counter1] == 0 && fovFindCountFluorescent2 != 0 && fovCount == fovFindCountFluorescent2){
                                                dicTreatNameListProcess [counter1] = 1;
                                            }
                                        }
                                        
                                        if (treatNameHoldTempCH == "3"){
                                            if (dicTreatNameListProcess [counter1] == 0 && fovFindCountFluorescent3 != 0 && fovCount != fovFindCountFluorescent3){
                                                dicTreatNameListProcess [counter1] = -2;
                                            }
                                            else if (dicTreatNameListProcess [counter1] == 0 && fovFindCountFluorescent3 == 0 && fovCount != 0){
                                                dicTreatNameListProcess [counter1] = 2;
                                            }
                                            else if (dicTreatNameListProcess [counter1] == 0 && fovFindCountFluorescent3 != 0 && fovCount == fovFindCountFluorescent3){
                                                dicTreatNameListProcess [counter1] = 1;
                                            }
                                        }
                                        
                                        if (treatNameHoldTempCH == "4"){
                                            if (dicTreatNameListProcess [counter1] == 0 && fovFindCountFluorescent4 != 0 && fovCount != fovFindCountFluorescent4){
                                                dicTreatNameListProcess [counter1] = -2;
                                            }
                                            else if (dicTreatNameListProcess [counter1] == 0 && fovFindCountFluorescent4 == 0 && fovCount != 0){
                                                dicTreatNameListProcess [counter1] = 2;
                                            }
                                            else if (dicTreatNameListProcess [counter1] == 0 && fovFindCountFluorescent4 != 0 && fovCount == fovFindCountFluorescent4){
                                                dicTreatNameListProcess [counter1] = 1;
                                            }
                                        }
                                        
                                        if (treatNameHoldTempCH == "5"){
                                            if (dicTreatNameListProcess [counter1] == 0 && fovFindCountFluorescent5 != 0 && fovCount != fovFindCountFluorescent5){
                                                dicTreatNameListProcess [counter1] = -2;
                                            }
                                            else if (dicTreatNameListProcess [counter1] == 0 && fovFindCountFluorescent5 == 0 && fovCount != 0){
                                                dicTreatNameListProcess [counter1] = 2;
                                            }
                                            else if (dicTreatNameListProcess [counter1] == 0 && fovFindCountFluorescent5 != 0 && fovCount == fovFindCountFluorescent5){
                                                dicTreatNameListProcess [counter1] = 1;
                                            }
                                        }
                                        
                                        if (treatNameHoldTempCH == "6"){
                                            if (dicTreatNameListProcess [counter1] == 0 && fovFindCountFluorescent6 != 0 && fovCount != fovFindCountFluorescent6){
                                                dicTreatNameListProcess [counter1] = -2;
                                            }
                                            else if (dicTreatNameListProcess [counter1] == 0 && fovFindCountFluorescent6 == 0 && fovCount != 0){
                                                dicTreatNameListProcess [counter1] = 2;
                                            }
                                            else if (dicTreatNameListProcess [counter1] == 0 && fovFindCountFluorescent6 != 0 && fovCount == fovFindCountFluorescent6){
                                                dicTreatNameListProcess [counter1] = 1;
                                            }
                                        }
                                    }
                                }
                            }
                            
                            closedir(dir2);
                        }
                    }
                }
                
                closedir(dir);
            }
            
            for (int counter1 = 0; counter1 < dicTreatNameListCount; counter1++){
                if (dicTreatNameListProcess [counter1] == -2) copyCheck = 0;
            }
            
            //for (int counterA = 0; counterA < dicTreatNameListCount; counterA++){
            //    cout<<counterA<<" "<<dicTreatNameList [counterA]<<" "<<dicTreatNameListProcess [counterA]<<" List"<<endl;
            //}
            
            int progressCount = 0;
            
            if (copyCheck == 1){
                //----Main process----
                long sizeForCopy = 0;
                
                for (int counter1 = 0; counter1 < dicTreatNameListCount; counter1++){
                    if (dicTreatNameListProcess [counter1] == -1){
                        for (int counter2 = 0; counter2 < processListCount/5; counter2++){
                            if (arrayProcessList [counter2*5] == dicTreatNameList [counter1]){
                                arrayProcessList [counter2*5+4] = "-2500";
                            }
                        }
                    }
                    else if (dicTreatNameListProcess [counter1] == 1){
                        for (int counter2 = 0; counter2 < processListCount/5; counter2++){
                            if (arrayProcessList [counter2*5] == dicTreatNameList [counter1]){
                                arrayProcessList [counter2*5+4] = arrayProcessList [counter2*5+3];
                            }
                        }
                    }
                }
                
                string copySource = copyDirectoryInfo+"/"+"Source_Images";
                
                dir = opendir(copySource.c_str());
                
                if (dir != NULL){
                    while((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("~Sorted") != -1){
                            pathName2 = copySource+"/"+entry;
                            pathName2B = productsFocalTempPath+"/"+entry;
                            
                            dir2 = opendir(pathName2.c_str());
                            
                            if (dir2 != NULL){
                                while((dent2 = readdir(dir2))){
                                    entry2 = dent2 -> d_name;
                                    
                                    if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store" && (int)entry2.find("FOV") != -1){
                                        pathName3 = pathName2+"/"+entry2;
                                        pathName3B = pathName2B+"/"+entry2;
                                        
                                        dir3 = opendir(pathName3.c_str());
                                        
                                        if (dir3 != NULL){
                                            while((dent3 = readdir(dir3))){
                                                entry3 = dent3 -> d_name;
                                                
                                                if (entry3 != "." && entry3 != ".." && entry3 != ".DS_Store" && ((int)entry3.find("bmp") != -1 || (int)entry3.find("tif") != -1)){
                                                    pathName4 = pathName3+"/"+entry3;
                                                    pathName4B = pathName3B+"/"+entry3;
                                                    
                                                    stringExtract = entry3.substr(entry3.find("_")+1, 4);
                                                    
                                                    if (atoi(stringExtract.c_str()) == atoi(currentNumber.c_str())){
                                                        if (stat(pathName4.c_str(), &sizeOfFile) == 0){
                                                            sizeForCopy = sizeOfFile.st_size;
                                                            
                                                            ifstream infile (pathName4.c_str(), ifstream::binary);
                                                            ofstream outfile (pathName4B.c_str(), ofstream::binary);
                                                            
                                                            char* buffer = new char[sizeForCopy];
                                                            infile.read (buffer, sizeForCopy);
                                                            outfile.write (buffer, sizeForCopy);
                                                            delete[] buffer;
                                                            
                                                            outfile.close();
                                                            infile.close();
                                                            
                                                            progressCount++;
                                                        }
                                                    }
                                                }
                                            }
                                            
                                            closedir(dir3);
                                        }
                                    }
                                }
                                
                                closedir(dir2);
                            }
                        }
                    }
                    
                    closedir(dir);
                }
                
                processProceed = 1;
            }
            
            delete [] dicTreatNameList;
            delete [] dicTreatNameListProcess;
        }
        
        //for (int counterA = 0; counterA < processListCount/5; counterA++){
        //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayProcessList [counterA*5+counterB];
        //    cout<<" arrayProcessList "<<counterA+1<<endl;
        //}
        
        if (copyCheck == 0 || copySetStatus == 0){
            progressTiming = 1;
            progressValue = 10;
            
            do usleep(10);
            while (progressTiming == 1);
            
            progressTiming = 3;
            progressValue = 1;
            
            double maskMatrix [5][5] = {{0.0035, 0.0145, 0.0256, 0.0145, 0.0035}, {0.0145, 0.0586, 0.0952, 0.0556, 0.0145}, {0.0256, 0.0952, 0.1501, 0.0952, 0.0256}, {0.0145, 0.0586, 0.0952, 0.0586, 0.0145}, {0.0035, 0.0145, 0.0256, 0.0145, 0.0035}};
            
            //clock_t time1, time2, time3, time4, time5, time6, time7, time8;
            //time1 = clock();
            
            //===========Temp folder path clear==========
            string entry;
            
            DIR *dir;
            struct dirent *dent;
            DIR *dir2;
            struct dirent *dent2;
            DIR *dir3;
            struct dirent *dent3;
            
            dir = opendir(productsFocalTempPath.c_str());
            fileDeleteCount = 0;
            
            if (dir != NULL){
                string entry2;
                string entry3;
                string productDataPath1;
                string productDataPath2;
                string productDataPath3;
                
                while((dent = readdir(dir))){
                    entry = dent -> d_name;
                    productDataPath1 = productsFocalTempPath+"/"+entry;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        dir2 = opendir(productDataPath1.c_str());
                        
                        if (dir2 != NULL){
                            while((dent2 = readdir(dir2))){
                                entry2 = dent2 -> d_name;
                                productDataPath2 = productDataPath1+"/"+entry2;
                                
                                if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                    dir3 = opendir(productDataPath2.c_str());
                                    
                                    if (dir3 != NULL){
                                        while((dent3 = readdir(dir3))){
                                            entry3 = dent3 -> d_name;
                                            
                                            if (entry3 != "." && entry3 != ".." && entry3 != ".DS_Store"){
                                                if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                                arrayFileDelete [fileDeleteCount] = productDataPath2+"/"+entry3, fileDeleteCount++;
                                            }
                                        }
                                        
                                        closedir(dir3);
                                    }
                                }
                            }
                            
                            closedir(dir2);
                        }
                    }
                }
                
                closedir(dir);
                
                for(int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                    remove (arrayFileDelete [counter1].c_str());
                }
            }
            
            //time2 = clock();
            //cout<<"  Time1 "<<time2-time1<<" "<<endl;
            
            //=========Folder data update==========
            string folderName;
            
            if (processMode == 2 || processMode == 3 || processMode == 4 || processMode == 6 || processMode ==  8 || processMode == 9) folderName = bodyName+"-10001";
            else folderName = autoFolderName;
            
            string folderNumberCheck = folderName.substr(folderName.find("-1")+2);
            
            //==========File name read==========
            if (nameListOfFilesStatus == 1){
                delete [] arrayNameListOfFiles;
                nameListOfFilesStatus = 0;
            }
            
            arrayNameListOfFiles = new string [totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+50];
            nameListOfFilesCount = 0;
            nameListOfFilesStatus = 1;
            
            string processFilePath = namedFilesPath+"/"+folderName;
            
            dir = opendir(processFilePath.c_str());
            
            if (dir != NULL){
                while((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store") arrayNameListOfFiles [nameListOfFilesCount] = entry, nameListOfFilesCount++;
                }
                
                closedir(dir);
                
                //----Directory Sort-----
                NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                
                for (int counter1 = 0; counter1 < nameListOfFilesCount; counter1++){
                    [unsortedArray addObject:@(arrayNameListOfFiles [counter1].c_str())];
                }
                
                [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                
                for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                    arrayNameListOfFiles [counter1] = [unsortedArray [counter1] UTF8String];
                }
            }
            
            //-----XY position read-----
            progressTiming = 3;
            progressValue = 2;
            
            progressTiming = 5;
            
            do usleep(10);
            while (progressTiming == 5);
            
            progressTiming = 7;
            
            //=========Color information read=========
            processListCount = 0;
            
            string treatmentNameTemp;
            string fovExtractTemp;
            string channelTemp;
            string fileColorType;
            
            for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                if (arrayTableDisplay [counter1*17] != " " && arrayTableDisplay [counter1*17+1] != " "){
                    treatmentNameTemp = arrayTableDisplay [counter1*17];
                    arrayProcessList [processListCount] = treatmentNameTemp, processListCount++;
                    
                    fovExtractTemp = arrayTableDisplay [counter1*17+1];
                    
                    if ((int)fovExtractTemp.find("FOV") != -1) fovExtractTemp = fovExtractTemp.substr(fovExtractTemp.find("FOV")+3);
                    else{
                        
                        if ((int)fovExtractTemp.find("-") != -1) fovExtractTemp = fovExtractTemp.substr(fovExtractTemp.find("-")+1);
                        else fovExtractTemp = " ";
                    }
                    
                    arrayProcessList [processListCount] = fovExtractTemp, processListCount++;
                    
                    fovExtractTemp = arrayTableDisplay [counter1*17+1];
                    
                    if ((int)fovExtractTemp.find("CH") != -1){
                        channelTemp = fovExtractTemp.substr(fovExtractTemp.find("CH")+2, fovExtractTemp.find("-")-fovExtractTemp.find("CH")-2);
                        
                        if (channelTemp == "1") fileColorType = fluorescentNo1;
                        else if (channelTemp == "2") fileColorType = fluorescentNo2;
                        else if (channelTemp == "3") fileColorType = fluorescentNo3;
                        else if (channelTemp == "4") fileColorType = fluorescentNo4;
                        else if (channelTemp == "5") fileColorType = fluorescentNo5;
                        else if (channelTemp == "6") fileColorType = fluorescentNo6;
                        
                        arrayProcessList [processListCount] = fileColorType, processListCount++;
                    }
                    else arrayProcessList [processListCount] = "0", processListCount++;
                    
                    arrayProcessList [processListCount] = "0", processListCount++;
                    arrayProcessList [processListCount] = "0", processListCount++;
                }
                else if (arrayTableDisplay [counter1*17] == " " && arrayTableDisplay [counter1*17+1] != " "){
                    arrayProcessList [processListCount] = treatmentNameTemp, processListCount++;
                    
                    fovExtractTemp = arrayTableDisplay [counter1*17+1];
                    
                    if ((int)fovExtractTemp.find("FOV") != -1) fovExtractTemp = fovExtractTemp.substr(fovExtractTemp.find("FOV")+3);
                    else{
                        
                        if ((int)fovExtractTemp.find("-") != -1) fovExtractTemp = fovExtractTemp.substr(fovExtractTemp.find("-")+1);
                        else fovExtractTemp = " ";
                    }
                    
                    arrayProcessList [processListCount] = fovExtractTemp, processListCount++;
                    
                    fovExtractTemp = arrayTableDisplay [counter1*17+1];
                    
                    if ((int)fovExtractTemp.find("CH") != -1){
                        channelTemp = fovExtractTemp.substr(fovExtractTemp.find("CH")+2, fovExtractTemp.find("-")-fovExtractTemp.find("CH")-2);
                        
                        if (channelTemp == "1") fileColorType = fluorescentNo1;
                        else if (channelTemp == "2") fileColorType = fluorescentNo2;
                        else if (channelTemp == "3") fileColorType = fluorescentNo3;
                        else if (channelTemp == "4") fileColorType = fluorescentNo4;
                        else if (channelTemp == "5") fileColorType = fluorescentNo5;
                        else if (channelTemp == "6") fileColorType = fluorescentNo6;
                        
                        arrayProcessList [processListCount] = fileColorType, processListCount++;
                    }
                    else arrayProcessList [processListCount] = "0", processListCount++;
                    
                    arrayProcessList [processListCount] = "0", processListCount++;
                    arrayProcessList [processListCount] = "0", processListCount++;
                }
            }
            
            int entryCountTemp = 0;
            
            for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                if (arrayFocalPlaneData [counter1][currentTimePoint+1] != 0){
                    arrayProcessList [entryCountTemp*5+3] = to_string(arrayFocalPlaneData [counter1][currentTimePoint+1]), entryCountTemp++;
                }
            }
            
            //for (int counterA = 0; counterA < treatmentNameDisplayCount; counterA++){
            //    for (int counterB = 0; counterB < currentTimePoint+2; counterB++) cout<<" "<<arrayFocalPlaneData [counterA][counterB];
            //    cout<<"  arrayFocalPlaneData "<<counterA+1<<endl;
            //}
            
            //for (int counterA = 0; counterA < processListCount/5; counterA++){
            //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayProcessList [counterA*5+counterB];
            //    cout<<" arrayProcessList "<<counterA+1<<endl;
            //}
            
            //for (int counterA = 0; counterA < treatmentNameDisplayCount; counterA++){
            //    for (int counterB = 0; counterB < 17; counterB++) cout<<" "<<arrayTableDisplay [counterA*17+counterB];
            //    cout<<" arrayTableDisplay "<<counterA+1<<endl;
            //}
            
            string timePointExtractSave = to_string(currentTimePoint);
            
            if (timePointExtractSave.length() == 1) timePointExtractSave = "000"+timePointExtractSave;
            else if (timePointExtractSave.length() == 2) timePointExtractSave = "00"+timePointExtractSave;
            else if (timePointExtractSave.length() == 3) timePointExtractSave = "0"+timePointExtractSave;
            
            progressTiming = 1;
            progressValue = nameListOfFilesCount;
            
            do usleep(10);
            while (progressTiming == 1);
            
            int upDateNo = 0;
            int processTypeHoldInt = 0;
            int fixedPlaneNo = 0;
            int fixedAllInFlag = 0;
            int contrastSkipFlag = 0;
            int valueAverageInt = 0;
            int totalPix = 0;
            int pixNo90 = 0;
            int lowerLimitCount = 0;
            int higherLimitCount = 0;
            int valueShift = 0;
            int newPixValue = 0;
            int value1 = 0;
            int value2 = 0;
            int value3 = 0;
            int value4 = 0;
            int focalPlaneNo = 0;
            int bitGaussian = 0;
            int entryCount = 0;
            int objectFind = 0;
            int sdCount = 0;
            int firstPeak = 0;
            int firstPeakCount = 0;
            int secondPeak = 0;
            int secondPeakCount = 0;
            int firstPeakSet = 0;
            int secondPeakSet = 0;
            int currentValue = 0;
            int firstLow = 0;
            int firstHigh = 0;
            int secondLow = 0;
            int secondHigh = 0;
            int rangeDown = 0;
            int rangeTop = 0;
            int totalDiff = 0;
            int closeToCenter = 0;
            int dataA = 0;
            int focalPlaneValueTemp2 = 0;
            int limitTemp = 0;
            int focalPlaneNo2 = 0;
            int valueRangeCheck = 0;
            int pixValueFocal = 0;
            int focalPlaneValue = 0;
            int pixCountTemp = 0;
            int focalPlaneValueTemp = 0;
            int dicRangeValue = 0;
            int valueAverage1 = 0;
            int valueAverage2 = 0;
            int valueAverage3 = 0;
            int valueSelect = 0;
            int planeNumberFinal = 0;
            int terminationFlag = 0;
            
            double valueAverage = 0;
            double expansionFactor = 0;
            double totalForAverage = 0;
            double totalForStandardDev = 0;
            double sdValue = 0;
            double gX = 0;
            double gY = 0;
            
            string timePointExtract;
            string fovNumberExtract;
            string channelExtract;
            string fluorescentNameTemp;
            string channelTableNo;
            string processTypeHold;
            string savePath;
            string extractDown;
            string extractTop;
            string typeFindString;
            string extension;
            string saveStringTemp;
            string fileName;
            string tifExtension;
            
            //-----Tiff reading-----
            unsigned long stripFirstAddress = 0;
            unsigned long stripByteCountAddress = 0;
            unsigned long nextAddress = 0;
            unsigned long headPosition = 0;
            unsigned long headPositionHold = 0;
            unsigned long stripEntry = 0;
            unsigned long ifDPreviousHold = 0;
            long sizeForCopy = 0;
            
            double xPosition = 0;
            double yPosition = 0;
            
            int imageWidth = 0;
            int imageHeight = 0;
            int imageBit = 0; // Check 8, 16
            int imageCompression = 0; // Check 1
            int photoMetric = 0;//check 0, 1, 2
            int imageDimension = 0;
            int verticalBmp = 0;
            int horizontalBmpEntry = 0;
            int endianType = 0;
            int samplePerPix = 0;
            int loopCount = 0;
            int dataConversion [4];
            int mode = 1;
            int processType = 1;
            int numberOfLayers = 0;
            int sixteenX = 0;
            int sixteenY = 0;
            
            ifstream fin;
            
            //=========Process individual files=========
            for (int counter1 = 0; counter1 < nameListOfFilesCount; counter1++){
                //time5 = clock();
                //cout<<"  Time4 "<<time2-time1<<" "<<endl;
                
                progressTiming = 3;
                progressValue = counter1+1;
                
                fileName = arrayNameListOfFiles [counter1];
                processFilePath = namedFilesPath+"/"+folderName+"/"+fileName;
                
                treatmentNameTemp = fileName.substr(0, fileName.find("_"));
                timePointExtract = fileName.substr(fileName.find("_")+1, fileName.find("-")-fileName.find("_")-1);
                fovExtractTemp = fileName.substr(fileName.find("-")+1);
                
                if (((int)fovExtractTemp.find(".TIFF") != -1)) tifExtension = ".TIFF";
                else if (((int)fovExtractTemp.find(".Tiff") != -1)) tifExtension = ".TIFF";
                else if (((int)fovExtractTemp.find(".tiff") != -1)) tifExtension = ".tiff";
                else if (((int)fovExtractTemp.find(".TIF") != -1)) tifExtension = ".TIF";
                else if (((int)fovExtractTemp.find(".Tif") != -1)) tifExtension = ".Tif";
                else if (((int)fovExtractTemp.find(".tif") != -1)) tifExtension = ".tif";
                
                if ((int)fovExtractTemp.find("_") != -1){
                    fovNumberExtract = fovExtractTemp.substr(0, fovExtractTemp.find("_"));
                    fovExtractTemp = fovExtractTemp.substr(fovExtractTemp.find("_")+1);
                    channelExtract = fovExtractTemp.substr(0, fovExtractTemp.find("_"));
                    fovExtractTemp = fovExtractTemp.substr(fovExtractTemp.find("_")+1);
                    fluorescentNameTemp = fovExtractTemp.substr(0, fovExtractTemp.find(tifExtension));
                }
                else{
                    
                    fovNumberExtract = fovExtractTemp.substr(0, fovExtractTemp.find(tifExtension));
                    channelExtract = "0";
                    fluorescentNameTemp = "";
                }
                
                //for (int counterA = 0; counterA < processListCount/5; counterA++){
                //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayProcessList [counterA*5+counterB];
                //    cout<<" arrayProcessList "<<counterA+1<<endl;
                //}
                
                channelTableNo = "";
                
                if (fluorescentNo1 == channelExtract) channelTableNo = "1";
                else if (fluorescentNo2 == channelExtract) channelTableNo = "2";
                else if (fluorescentNo3 == channelExtract) channelTableNo = "3";
                else if (fluorescentNo4 == channelExtract) channelTableNo = "4";
                else if (fluorescentNo5 == channelExtract) channelTableNo = "5";
                else if (fluorescentNo6 == channelExtract) channelTableNo = "6";
                
                upDateNo = -1;
                
                //cout<<treatmentNameTemp<<" "<<treatmentNameTemp+"CH"+channelTableNo<<" "<<fovNumberExtract<<" "<<channelExtract<<" Info"<<endl;
                
                for (int counter2 = 0; counter2 < processListCount/5; counter2++){
                    if ((arrayProcessList [counter2*5] == treatmentNameTemp || arrayProcessList [counter2*5] == treatmentNameTemp+"CH"+channelTableNo) && arrayProcessList [counter2*5+1] == fovNumberExtract && arrayProcessList [counter2*5+2] == channelExtract){
                        processTypeHold = arrayProcessList [counter2*5+3];
                        upDateNo = counter2;
                        break;
                    }
                }
                
                //for (int counterA = 0; counterA < processListCount/5; counterA++){
                //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayProcessList [counterA*5+counterB];
                //    cout<<" arrayProcessList "<<counterA+1<<endl;
                //}
                
                if (fovNumberExtract.length() == 1) fovNumberExtract = "FOV00"+fovNumberExtract;
                else if (fovNumberExtract.length() == 2) fovNumberExtract = "FOV0"+fovNumberExtract;
                else if (fovNumberExtract.length() == 3) fovNumberExtract = "FOV"+fovNumberExtract;
                
                if (fluorescentNameTemp != ""){
                    fileSavePathHold =     productsFocalTempPath+"/"+treatmentNameTemp+"~Sorted/"+fovNumberExtract+"/"+treatmentNameTemp+"_"+timePointExtractSave+"-"+fovNumberExtract+"_"+channelExtract+"_"+fluorescentNameTemp+".tif";
                }
                else{
                    
                    fileSavePathHold = productsFocalTempPath+"/"+treatmentNameTemp+"~Sorted/"+fovNumberExtract+"/"+treatmentNameTemp+"_"+timePointExtractSave+"-"+fovNumberExtract+".tif";
                }
                
                //for (int counterA = 0; counterA < processListCount/5; counterA++){
                //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayProcessList [counterA*5+counterB];
                //    cout<<" arrayProcessList "<<counterA+1<<endl;
                //}
                
                if (processTypeHold == "-5000" || processTypeHold == "-2500") arrayProcessList [upDateNo*5+4] = "-2500"; //========No processing==========
                else{
                    
                    nextAddress = 0;
                    stripEntry = 0;
                    stripFirstAddress = 0;
                    stripByteCountAddress = 0;
                    
                    //=========File Read: File information get===========
                    if (stat(processFilePath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                        
                        fileReadArray = new uint8_t [(int)sizeForCopy+4];
                        fin.open(processFilePath.c_str(), ios::in | ios::binary);
                        fin.read((char*)fileReadArray, sizeForCopy+1);
                        fin.close();
                        
                        dataConversion [0] = fileReadArray [0];
                        dataConversion [1] = fileReadArray [1];
                        
                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                        else endianType = 0;
                        
                        int *arrayExtractedImage3 = new int [100];
                        
                        headPosition = 0;
                        
                        if (endianType == 1){
                            dataConversion [0] = fileReadArray [7];
                            dataConversion [1] = fileReadArray [6];
                            dataConversion [2] = fileReadArray [5];
                            dataConversion [3] = fileReadArray [4];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        else if (endianType == 0){
                            dataConversion [0] = fileReadArray [4];
                            dataConversion [1] = fileReadArray [5];
                            dataConversion [2] = fileReadArray [6];
                            dataConversion [3] = fileReadArray [7];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        
                        headPositionHold = headPosition;
                        loopCount = 1;
                        
                        do{
                            
                            terminationFlag = 1;
                            
                            if (endianType == 1){
                                self->tiffFileRead = [[TiffFileRead alloc] init];
                                [self->tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress :&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                            }
                            else if (endianType == 0){
                                self->tiffFileRead = [[TiffFileRead alloc] init];
                                [self->tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress :&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                            }
                            
                            if (nextAddress != 0){
                                headPosition = nextAddress;
                                loopCount++;
                            }
                            else terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                        
                        planeNumberFinal = loopCount;
                        
                        int **arrayImageDataHold = new int *[imageHeight*planeNumberFinal+2];
                        int **arrayImageDataHoldSource = new int *[imageHeight*planeNumberFinal+2];
                        int **arrayImageDataHoldTemp = new int *[imageHeight*planeNumberFinal+2];
                        int **arrayImageDataHoldRGBMax = new int *[imageHeight*planeNumberFinal+2];
                        
                        for (int counter2 = 0; counter2 < imageHeight*planeNumberFinal+2; counter2++){
                            arrayImageDataHold [counter2] = new int [imageWidth*3+2];
                            arrayImageDataHoldSource [counter2] = new int [imageWidth*3+2];
                            arrayImageDataHoldTemp [counter2] = new int [imageWidth*3+2];
                            arrayImageDataHoldRGBMax [counter2] = new int [imageWidth*3+2];
                        }
                        
                        //=========File read: get image data=========
                        verticalBmp = 0;
                        headPosition = headPositionHold;
                        
                        do{
                            
                            terminationFlag = 1;
                            
                            if (endianType == 1){
                                self->tiffFileRead = [[TiffFileRead alloc] init];
                                [self->tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress :&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                
                                if (imageWidth > imageHeight) imageDimension = imageWidth;
                                else imageDimension = imageHeight;
                                
                                self->tiffFileRead = [[TiffFileRead alloc] init];
                                delete [] arrayExtractedImage3;
                                
                                arrayExtractedImage3 = [self->tiffFileRead imageSetBigEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                            }
                            else if (endianType == 0){
                                self->tiffFileRead = [[TiffFileRead alloc] init];
                                [self->tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress :&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                
                                if (imageWidth > imageHeight) imageDimension = imageWidth;
                                else imageDimension = imageHeight;
                                
                                self->tiffFileRead = [[TiffFileRead alloc] init];
                                delete [] arrayExtractedImage3;
                                
                                arrayExtractedImage3 = [self->tiffFileRead imageSetLittleEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                            }
                            
                            horizontalBmpEntry = 0;
                            
                            if (photoMetric == 1){
                                for (int counter2 = 0; counter2 < imageWidth*imageHeight; counter2++){
                                    arrayImageDataHold [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter2]);
                                    arrayImageDataHoldSource [verticalBmp][horizontalBmpEntry] = arrayImageDataHold [verticalBmp][horizontalBmpEntry];
                                    horizontalBmpEntry++;
                                    
                                    if (horizontalBmpEntry == imageWidth){
                                        horizontalBmpEntry = 0;
                                        verticalBmp++;
                                    }
                                }
                            }
                            else if (photoMetric == 2){
                                for (int counter2 = 0; counter2 < imageWidth*imageHeight; counter2++){
                                    arrayImageDataHold [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter2*3]);
                                    arrayImageDataHoldSource [verticalBmp][horizontalBmpEntry] = arrayImageDataHold [verticalBmp][horizontalBmpEntry];
                                    horizontalBmpEntry++;
                                    
                                    arrayImageDataHold [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter2*3+1]);
                                    arrayImageDataHoldSource [verticalBmp][horizontalBmpEntry] = arrayImageDataHold [verticalBmp][horizontalBmpEntry];
                                    horizontalBmpEntry++;
                                    
                                    arrayImageDataHold [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter2*3+2]);
                                    arrayImageDataHoldSource [verticalBmp][horizontalBmpEntry] = arrayImageDataHold [verticalBmp][horizontalBmpEntry];
                                    horizontalBmpEntry++;
                                    
                                    if (horizontalBmpEntry == imageWidth*3){
                                        horizontalBmpEntry = 0;
                                        verticalBmp++;
                                    }
                                }
                            }
                            
                            if (nextAddress != 0){
                                headPosition = nextAddress;
                            }
                            else terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                        
                        //Plane number start from "1";
                        //Line one and line break: -1000
                        //No entry: -2000;
                        //No entry after T: -2500;
                        
                        //**Time point head**
                        //Focal Plane: -3000
                        //Focal Plane+cont: -3500
                        //Fixed plane: -6001, -6002, -6003,.....
                        //Fixed plane+cont: -7001, -7002, -7003,.....
                        //All-in-one: -4000;
                        //All-in-one+cont: -4500;
                        //All-in-one center: -8001;
                        //All-in-one+cont: -9001;
                        //Range: -10111222; start 111, end 222
                        //Range+cont: -11111222:
                        //Terminated: -5000;
                        
                        //==========Process List set (1. Treat name, 2. FOV, 3. CH, 4. Process info, 5. Update)==========
                        processTypeHoldInt = atoi(processTypeHold.c_str());
                        fixedPlaneNo = atoi(processTypeHold.c_str());
                        fixedAllInFlag = 0;
                        contrastSkipFlag = 0;
                        
                        extractDown = "";
                        extractTop = "";
                        
                        if (processTypeHoldInt == -3500 || processTypeHoldInt == -4500 || (processTypeHoldInt < -7000 && processTypeHoldInt > -8000) || (processTypeHoldInt < -9000 && processTypeHoldInt > -10000) ||  (processTypeHoldInt < -11000000 && processTypeHoldInt > -12000000)) contrastSkipFlag = 1;
                        
                        if ((processTypeHoldInt < -6000 && processTypeHoldInt > -7000) || (processTypeHoldInt < -7000 && processTypeHoldInt > -8000)){
                            typeFindString = processTypeHold.substr(2);
                            
                            processTypeHoldInt = atoi(typeFindString.c_str());
                            
                            if (processTypeHoldInt <= 0 || processTypeHoldInt > planeNumberFinal){
                                if (photoMetric == 1){
                                    if (contrastSkipFlag == 1){
                                        processTypeHoldInt = -3500;
                                        processTypeHold = "-3500";
                                    }
                                    else{
                                        
                                        processTypeHoldInt = -3000;
                                        processTypeHold = "-3000";
                                    }
                                }
                                else if (photoMetric == 2){
                                    processTypeHoldInt = -3000;
                                    processTypeHold = "-3000";
                                }
                            }
                        }
                        
                        if ((processTypeHoldInt < -8000 && processTypeHoldInt > -9000) || (processTypeHoldInt < -9000 && processTypeHoldInt > -10000)){
                            typeFindString = processTypeHold.substr(2);
                            fixedPlaneNo = atoi(typeFindString.c_str());
                            
                            if (fixedPlaneNo > planeNumberFinal){
                                if (contrastSkipFlag == 1){
                                    processTypeHoldInt = -4500;
                                    processTypeHold = "-4500";
                                    fixedPlaneNo = 0;
                                }
                                else{
                                    
                                    processTypeHoldInt = -4000;
                                    processTypeHold = "-4000";
                                    fixedPlaneNo = 0;
                                }
                            }
                            else fixedAllInFlag = 1;
                        }
                        
                        if ((processTypeHoldInt < -10000000 && processTypeHoldInt > -11000000) || (processTypeHoldInt < -11000000 && processTypeHoldInt > -12000000)){
                            extractDown = processTypeHold.substr(3, 3);
                            extractTop = processTypeHold.substr(6, 3);
                            
                            if (atoi(extractTop.c_str()) > planeNumberFinal){
                                extractTop = to_string(planeNumberFinal);
                            }
                            
                            if (atoi(extractTop.c_str())-atoi(extractDown.c_str()) < 5){
                                if (contrastSkipFlag == 1){
                                    processTypeHoldInt = -4500;
                                    processTypeHold = "-4500";
                                    fixedPlaneNo = 0;
                                }
                                else{
                                    
                                    processTypeHoldInt = -4000;
                                    processTypeHold = "-4000";
                                    fixedPlaneNo = 0;
                                }
                            }
                            else{
                                
                                fixedPlaneNo = atoi(extractDown.c_str())+(int)((atoi(extractTop.c_str())-atoi(extractDown.c_str()))/(double)2);
                                fixedAllInFlag = 1;
                            }
                        }
                        
                        if (planeNumberFinal == 1) processTypeHoldInt = 1;
                        
                        if (photoMetric == 2){
                            contrastSkipFlag = 0;
                            
                            if (processTypeHoldInt == -4000 || processTypeHoldInt == -4500  || (processTypeHoldInt < -8000 && processTypeHoldInt > -9000) || (processTypeHoldInt < -9000 && processTypeHoldInt > -10000) || (processTypeHoldInt < -10000000 && processTypeHoldInt > -11000000) || (processTypeHoldInt < -11000000 && processTypeHoldInt > -12000000)){
                                processTypeHoldInt = -3000;
                                processTypeHold = "-3000";
                            }
                        }
                        
                        //time6 = clock();
                        //cout<<"  Time5 "<<time6-time5<<" "<<endl;
                        
                        //========Fixed plane==========
                        /*
                         If a plane number is selected, extract the plane image.
                         If Adjust contrast is selected (AS), the mean value will be adjusted. If DIC range is set, adjust range.
                         If image is color, AS will not be applied.
                         If number of plane is 1, select the plane.
                         */
                        
                        if (processTypeHoldInt >= 1 && processTypeHoldInt <= planeNumberFinal){
                            //******Contrast normalize, not apply for color image******
                            if (contrastSkipFlag == 1 && channelTableNo == "" && photoMetric == 1){
                                //----Image value Min/Max Check-----
                                int *valueFrequency = new int [256];
                                
                                for (int counter2 = 0; counter2 <= 255; counter2++) valueFrequency [counter2] = 0;
                                
                                valueAverage = 0;
                                
                                for (int counter2 = 0; counter2 < planeNumberFinal; counter2++){
                                    for (int counter3 = 0; counter3 < imageHeight; counter3++){
                                        for (int counter4 = 0; counter4 < imageWidth; counter4++){
                                            valueAverage = valueAverage+arrayImageDataHold [counter2*imageHeight+counter3][counter4];
                                            valueFrequency [arrayImageDataHold [counter2*imageHeight+counter3][counter4]]++;
                                        }
                                    }
                                }
                                
                                //-----Mean and low/high check----
                                totalPix = planeNumberFinal*imageWidth*imageHeight;
                                valueAverageInt = (int)(valueAverage/(double)totalPix);
                                pixNo90 = valueFrequency [valueAverageInt];
                                
                                lowerLimitCount = 0;
                                higherLimitCount = 0;
                                
                                for (int counter2 = 1; counter2 <= 255; counter2++){
                                    if (valueAverageInt-counter2 >= 0){
                                        pixNo90 = pixNo90+valueFrequency [valueAverageInt-counter2];
                                        lowerLimitCount = valueAverageInt-counter2;
                                    }
                                    if (valueAverageInt+counter2 <= 255){
                                        pixNo90 = pixNo90+valueFrequency [valueAverageInt+counter2];
                                        higherLimitCount = valueAverageInt+counter2;
                                    }
                                    if (pixNo90/(double)totalPix > 0.8){
                                        break;
                                    }
                                }
                                
                                delete [] valueFrequency;
                                
                                //-----Mean and low/high adjust----
                                if (dicRangeSet == 0) dicRangeValue = 0;
                                else if (dicRangeSet == 1) dicRangeValue = 20;
                                else if (dicRangeSet == 2) dicRangeValue = 40;
                                else if (dicRangeSet == 3) dicRangeValue = 60;
                                else if (dicRangeSet == 4) dicRangeValue = 80;
                                
                                expansionFactor = dicRangeValue/(double)(higherLimitCount-lowerLimitCount);
                                valueShift = 100-valueAverageInt;
                                
                                //for (int counterA = 0; counterA < 50; counterA++){
                                //    for (int counterB = 0; counterB < 50; counterB++) cout<<" "<<arrayImageDataHold [(processTypeHoldInt-1)*imageHeight+counterA][counterB];
                                //    cout<<" "<<counterA<<" arrayImageDataHold "<<endl;
                                //}
                                
                                for (int counter2 = 0; counter2 < imageHeight; counter2++){
                                    for (int counter3 = 0; counter3 < imageWidth; counter3++){
                                        for (int counter4 = 0; counter4 < planeNumberFinal; counter4++){
                                            newPixValue = arrayImageDataHold [counter4*imageHeight+counter2][counter3]+valueShift;
                                            
                                            if (newPixValue < 100) newPixValue = newPixValue-(int)(abs(100-newPixValue)*expansionFactor);
                                            else newPixValue = newPixValue+(int)(abs(100-newPixValue)*expansionFactor);
                                            
                                            if (newPixValue < 0) newPixValue = 0;
                                            if (newPixValue > 255) newPixValue = 255;
                                            
                                            arrayImageDataHold [counter4*imageHeight+counter2][counter3] = newPixValue;
                                        }
                                    }
                                }
                            }
                            
                            if (planeNumberFinal == 1) processTypeHoldInt = 1;
                            
                            arrayImageFileSave = new int *[imageHeight+1];
                            
                            for (int counter3 = 0; counter3 < imageHeight+1; counter3++){
                                arrayImageFileSave [counter3] = new int [imageWidth*3+1];
                            }
                            
                            for (int counter3 = 0; counter3 < imageHeight; counter3++){
                                for (int counter4 = 0; counter4 < imageWidth*3; counter4++){
                                    arrayImageFileSave [counter3][counter4] = 0;
                                }
                            }
                            
                            if (photoMetric == 1){
                                for (int counter2 = 0; counter2 < imageHeight; counter2++){
                                    for (int counter3 = 0; counter3 < imageWidth; counter3++){
                                        arrayImageFileSave [counter2][counter3] = arrayImageDataHold [(processTypeHoldInt-1)*imageHeight+counter2][counter3];
                                    }
                                }
                            }
                            else if (photoMetric == 2){
                                
                                for (int counter2 = 0; counter2 < imageHeight; counter2++){
                                    for (int counter3 = 0; counter3 < imageWidth; counter3++){
                                        arrayImageFileSave [counter2][counter3*3] = arrayImageDataHold [(processTypeHoldInt-1)*imageHeight+counter2][counter3*3];
                                        arrayImageFileSave [counter2][counter3*3+1] = arrayImageDataHold [(processTypeHoldInt-1)*imageHeight+counter2][counter3*3+1];
                                        arrayImageFileSave [counter2][counter3*3+2] = arrayImageDataHold [(processTypeHoldInt-1)*imageHeight+counter2][counter3*3+2];
                                    }
                                }
                            }
                            
                            mode = 0;
                            ifDPreviousHold = 0;
                            imageBit = 8;
                            
                            if (xPosition == -1) xPosition = 100;
                            if (yPosition == -1) yPosition = 100;
                            
                            self->singleTiffSave = [[SingleTiffSave alloc] init];
                            [self->singleTiffSave singleTiffLayerSave:imageWidth:imageHeight:imageBit:photoMetric:samplePerPix:xPosition:yPosition:mode:ifDPreviousHold];
                            
                            for (int counter3 = 0; counter3 < imageHeight+1; counter3++){
                                delete [] arrayImageFileSave [counter3];
                            }
                            
                            delete [] arrayImageFileSave;
                            
                            extension = to_string(processTypeHoldInt);
                            
                            if (extension.length() == 1) extension = "00"+extension;
                            else if (extension.length() == 2) extension = "0"+extension;
                            
                            if (contrastSkipFlag == 0){
                                arrayProcessList [upDateNo*5+3] = "-6"+extension;
                                arrayProcessList [upDateNo*5+4] = processTypeHold;
                            }
                            else if (contrastSkipFlag == 1){
                                arrayProcessList [upDateNo*5+3] = "-7"+extension;
                                arrayProcessList [upDateNo*5+4] = processTypeHold;
                            }
                        }
                        else{
                            
                            //==========Focal plane select======
                            /*
                             *Focal Plane, All in focus mode will go through the process.
                             If Fixed mode is selected, but the selected plane no. is over the actual plane no, go to the Focal plane select.
                             
                             *First: arrayImageDataHoldRGBMax will be created. For photoMetric = 1, data will be same with arrayImageDataHold.
                             For photoMetric = 2, highest value from RGB will be selected.
                             *Second: If the mode is AS and photoMetric = 1, adjust contrast. For color image, skip this step.
                             *Third: Divide image into 16x16 blocks and determine SD of each block. arrayImageDataHoldRGBMax will be used. Then, find a plane, which has the lowest SD (focal plane).
                             *Forth: Perform Gaussian bluer using arrayImageDataHoldRGBMax. Then, perform Sobel edge extraction to find the most edge extracted plane.
                             *Fifth: Put the peak data obtained by 16x16 SD and Sobel edge extraction together and determine the focal plane.
                             
                             If the mode is Focal plane select, extract the selected image. If the mode is All in focus, use the plan data to create the focused image.
                             */
                            
                            //*********Set Image info to arrayImageDataHoldRGBMax********
                            int *valueFrequency = new int [256];
                            
                            for (int counter2 = 0; counter2 <= 255; counter2++) valueFrequency [counter2] = 0;
                            
                            valueAverage = 0;
                            
                            if (photoMetric == 1){
                                for (int counter2 = 0; counter2 < planeNumberFinal; counter2++){
                                    for (int counter3 = 0; counter3 < imageHeight; counter3++){
                                        for (int counter4 = 0; counter4 < imageWidth; counter4++){
                                            valueAverage = valueAverage+arrayImageDataHold [counter2*imageHeight+counter3][counter4];
                                            valueFrequency [arrayImageDataHold [counter2*imageHeight+counter3][counter4]]++;
                                            
                                            arrayImageDataHoldRGBMax [counter2*imageHeight+counter3][counter4] = arrayImageDataHold [counter2*imageHeight+counter3][counter4];
                                        }
                                    }
                                }
                            }
                            else if (photoMetric == 2){ //Take highest value of RGB, and set data to arrayImageDataHoldRGBMax
                                for (int counter2 = 0; counter2 < planeNumberFinal; counter2++){
                                    for (int counter3 = 0; counter3 < imageHeight; counter3++){
                                        for (int counter4 = 0; counter4 < imageWidth; counter4++){
                                            valueAverage1 = arrayImageDataHold [counter2*imageHeight+counter3][counter4*3];
                                            valueAverage2 = arrayImageDataHold [counter2*imageHeight+counter3][counter4*3+1];
                                            valueAverage3 = arrayImageDataHold [counter2*imageHeight+counter3][counter4*3+2];
                                            
                                            if (valueAverage1 > valueAverage2){
                                                if (valueAverage1 >= valueAverage3) valueSelect = valueAverage1;
                                                else if (valueAverage1 < valueAverage3) valueSelect = valueAverage3;
                                            }
                                            else if (valueAverage1 <= valueAverage2){
                                                if (valueAverage2 >= valueAverage3) valueSelect = valueAverage2;
                                                else if (valueAverage2 < valueAverage3) valueSelect = valueAverage3;
                                            }
                                            else if (valueAverage1 > valueAverage3){
                                                if (valueAverage1 >= valueAverage2) valueSelect = valueAverage1;
                                                else if (valueAverage1 < valueAverage2) valueSelect = valueAverage2;
                                            }
                                            else if (valueAverage1 <= valueAverage3){
                                                if (valueAverage2 >= valueAverage3) valueSelect = valueAverage2;
                                                else if (valueAverage2 < valueAverage3) valueSelect = valueAverage3;
                                            }
                                            else if (valueAverage2 > valueAverage3){
                                                if (valueAverage1 >= valueAverage3) valueSelect = valueAverage1;
                                                else if (valueAverage1 < valueAverage3) valueSelect = valueAverage3;
                                            }
                                            else if (valueAverage2 <= valueAverage3){
                                                if (valueAverage1 >= valueAverage3) valueSelect = valueAverage1;
                                                else if (valueAverage1 < valueAverage3) valueSelect = valueAverage3;
                                            }
                                            
                                            arrayImageDataHoldRGBMax [counter2*imageHeight+counter3][counter4] = valueSelect;
                                        }
                                    }
                                }
                            }
                            
                            //*********Contrast normalize, not for color image**********
                            if (contrastSkipFlag == 1 && channelTableNo == ""){
                                //-----Mean and low/high check----
                                totalPix = planeNumberFinal*imageWidth*imageHeight;
                                valueAverageInt = (int)(valueAverage/(double)totalPix);
                                pixNo90 = valueFrequency [valueAverageInt];
                                lowerLimitCount = 0;
                                higherLimitCount = 0;
                                
                                for (int counter2 = 1; counter2 <= 255; counter2++){
                                    if (valueAverageInt-counter2 >= 0){
                                        pixNo90 = pixNo90+valueFrequency [valueAverageInt-counter2];
                                        lowerLimitCount = valueAverageInt-counter2;
                                    }
                                    if (valueAverageInt+counter2 <= 255){
                                        pixNo90 = pixNo90+valueFrequency [valueAverageInt+counter2];
                                        higherLimitCount = valueAverageInt+counter2;
                                    }
                                    if (pixNo90/(double)totalPix > 0.8){
                                        break;
                                    }
                                }
                                
                                //-----Mean and low/high adjust----
                                if (dicRangeSet == 0) dicRangeValue = 0;
                                else if (dicRangeSet == 1) dicRangeValue = 20;
                                else if (dicRangeSet == 2) dicRangeValue = 40;
                                else if (dicRangeSet == 3) dicRangeValue = 60;
                                else if (dicRangeSet == 4) dicRangeValue = 80;
                                
                                expansionFactor = dicRangeValue/(double)(higherLimitCount-lowerLimitCount);
                                valueShift = 100-valueAverageInt;
                                
                                for (int counter2 = 0; counter2 < imageHeight; counter2++){
                                    for (int counter3 = 0; counter3 < imageWidth; counter3++){
                                        for (int counter4 = 0; counter4 < planeNumberFinal; counter4++){
                                            newPixValue = arrayImageDataHold [counter4*imageHeight+counter2][counter3]+valueShift;
                                            
                                            if (newPixValue < 100) newPixValue = newPixValue-(int)(abs(100-newPixValue)*expansionFactor);
                                            else newPixValue = newPixValue+(int)(abs(100-newPixValue)*expansionFactor);
                                            
                                            if (newPixValue < 0) newPixValue = 0;
                                            if (newPixValue > 255) newPixValue = 255;
                                            
                                            arrayImageDataHold [counter4*imageHeight+counter2][counter3] = newPixValue;
                                            arrayImageDataHoldRGBMax [counter4*imageHeight+counter2][counter3] = newPixValue;
                                        }
                                    }
                                }
                            }
                            
                            delete [] valueFrequency;
                            
                            //*******SD 16x16 check; if the number of block is not x 16, use max of x16, use arrayImageDataHoldRGBMax*******
                            double *sdList = new double [planeNumberFinal+1];
                            int *selectedPlane = new int [planeNumberFinal+1];
                            
                            for (int counter2 = 0; counter2 < planeNumberFinal+1; counter2++){
                                sdList[counter2] = 0;
                                selectedPlane [counter2] = 0;
                            }
                            
                            sixteenX = (int)(imageWidth/16);
                            sixteenY = (int)(imageHeight/16);
                            
                            for (int counter2 = 0; counter2 < sixteenY; counter2++){
                                for (int counter3 = 0; counter3 < sixteenX; counter3++){
                                    for (int counter4 = 0; counter4 < planeNumberFinal; counter4++){
                                        totalForAverage = 0;
                                        entryCount = 0;
                                        totalForStandardDev = 0;
                                        
                                        for (int counter5 = counter2*16; counter5 < counter2*16+16; counter5++){
                                            for (int counter6 = counter3*16; counter6 < counter3*16+16; counter6++){
                                                if (arrayImageDataHoldRGBMax [counter4*imageHeight+counter5][counter6] < 180 && arrayImageDataHoldRGBMax [counter4*imageHeight+counter5][counter6] > 80){
                                                    entryCount++;
                                                    totalForAverage = totalForAverage+arrayImageDataHoldRGBMax [counter4*imageHeight+counter5][counter6];
                                                }
                                            }
                                        }
                                        
                                        if (entryCount > 50){
                                            totalForAverage = totalForAverage/(double)entryCount;
                                            
                                            for (int counter5 = counter2*16; counter5 < counter2*16+16; counter5++){
                                                for (int counter6 = counter3*16; counter6 < counter3*16+16; counter6++){
                                                    if (arrayImageDataHoldRGBMax [counter4*imageHeight+counter5][counter6] < 180 && arrayImageDataHoldRGBMax [counter4*imageHeight+counter5][counter6] > 80){
                                                        totalForStandardDev = totalForStandardDev+(arrayImageDataHoldRGBMax [counter4*imageHeight+counter5][counter6]-totalForAverage)*(arrayImageDataHoldRGBMax [counter4*imageHeight+counter5][counter6]-totalForAverage);
                                                    }
                                                }
                                            }
                                        }
                                        
                                        if (entryCount > 50) totalForStandardDev = totalForStandardDev/(double)entryCount;
                                        
                                        if (totalForStandardDev < 10) sdList [counter4] = 0;
                                        else sdList [counter4] = totalForStandardDev;
                                    }
                                    
                                    objectFind = 0;
                                    sdValue = 0;
                                    sdCount = -1;
                                    
                                    for (int counter4 = 0; counter4 < planeNumberFinal; counter4++){
                                        if (sdList [counter4] != 0) objectFind = 1;
                                        if (sdList [counter4] > sdValue){
                                            sdValue = sdList [counter4];
                                            sdCount = counter4;
                                        }
                                    }
                                    
                                    if (objectFind != 0 && sdCount != -1) selectedPlane [sdCount]++;
                                }
                            }
                            
                            // for (int counter2 = 0; counter2 < planeNumberFinal+1; counter2++) cout<<counter2<<" "<<selectedPlane [counter2]<<" Selected"<<endl;
                            
                            //----Find plane, which has the lowest SD----
                            firstPeak = 0;
                            firstPeakCount = 0;
                            secondPeak = 0;
                            secondPeakCount = 0;
                            firstPeakSet = 0;
                            secondPeakSet = 0;
                            currentValue = 0;
                            
                            for (int counter2 = 0; counter2 < planeNumberFinal; counter2++){
                                if (counter2 == 0){
                                    currentValue = selectedPlane [counter2];
                                    firstPeak = selectedPlane [counter2];
                                    firstPeakCount = counter2;
                                }
                                else if (counter2 > 0 && currentValue <= selectedPlane [counter2] && firstPeakSet == 0){
                                    firstPeak = selectedPlane [counter2];
                                    firstPeakCount = counter2;
                                    currentValue = selectedPlane [counter2];
                                }
                                else if (counter2 > 0 && currentValue > selectedPlane [counter2] && firstPeakSet == 0 && secondPeakSet == 0){
                                    currentValue = selectedPlane [counter2];
                                    firstPeakSet = 1;
                                }
                                else if (counter2 > 0 && currentValue > selectedPlane [counter2] && firstPeakSet == 1 && secondPeakSet == 0){
                                    currentValue = selectedPlane [counter2];
                                }
                                else if (counter2 > 0 && currentValue <= selectedPlane [counter2] && firstPeakSet == 1 && secondPeakSet == 0){
                                    secondPeak = selectedPlane [counter2];
                                    secondPeakCount = counter2;
                                    currentValue = selectedPlane [counter2];
                                    secondPeakSet = 1;
                                }
                                else if (counter2 > 0 && currentValue <= selectedPlane [counter2] && firstPeakSet == 1 && secondPeakSet == 1){
                                    secondPeak = selectedPlane [counter2];
                                    secondPeakCount = counter2;
                                    currentValue = selectedPlane [counter2];
                                }
                                else if (counter2 > 0 && currentValue > selectedPlane [counter2] && firstPeakSet == 1 && secondPeakSet == 1){
                                    currentValue = selectedPlane [counter2];
                                    secondPeakSet = 2;
                                }
                                else if (counter2 > 0 && currentValue > selectedPlane [counter2] && firstPeakSet == 1 && secondPeakSet == 2){
                                    currentValue = selectedPlane [counter2];
                                }
                                else if (counter2 > 0 && currentValue <= selectedPlane [counter2] && firstPeakSet == 1 && secondPeakSet == 2){
                                    if (secondPeak > firstPeak){
                                        firstPeak = secondPeak;
                                        firstPeakCount = secondPeakCount;
                                        secondPeak = 0;
                                        secondPeakCount = 0;
                                        secondPeakSet = 0;
                                    }
                                    
                                    if (secondPeak < selectedPlane [counter2]){
                                        secondPeak = selectedPlane [counter2];
                                        secondPeakCount = counter2;
                                        secondPeakSet = 1;
                                    }
                                    
                                    currentValue = selectedPlane [counter2];
                                }
                            }
                            
                            if (secondPeak < firstPeak*(double)0.4) secondPeak = 0;
                            
                            firstLow = 0;
                            firstHigh = 0;
                            
                            for (int counter2 = firstPeakCount-1; counter2 >= 0; counter2--){
                                if (selectedPlane [counter2] > firstPeak*(double)0.9) firstLow = counter2;
                                else{
                                    
                                    break;
                                }
                            }
                            
                            for (int counter2 = firstPeakCount+1; counter2 < planeNumberFinal; counter2++){
                                if (selectedPlane [counter2] > firstPeak*(double)0.9) firstHigh = counter2;
                                else{
                                    
                                    break;
                                }
                            }
                            
                            if (firstLow != 0 && firstHigh != 0) firstPeakCount = (firstHigh+firstLow)/2;
                            else if (firstLow == 0 && firstHigh != 0) firstPeakCount = (firstHigh+firstPeakCount)/2;
                            else if (firstLow != 0 && firstHigh == 0) firstPeakCount = (firstPeakCount+firstLow)/2;
                            
                            if (secondPeak != 0){
                                secondLow = 0;
                                secondHigh = 0;
                                
                                for (int counter2 = secondPeakCount-1; counter2 >= 0; counter2--){
                                    if (selectedPlane [counter2] > secondPeak*(double)0.9) secondLow = counter2;
                                    else{
                                        
                                        break;
                                    }
                                }
                                
                                for (int counter2 = secondPeakCount+1; counter2 < planeNumberFinal; counter2++){
                                    if (selectedPlane [counter2] > secondPeak*(double)0.9) secondHigh = counter2;
                                    else{
                                        
                                        break;
                                    }
                                }
                                
                                if (secondLow != 0 && secondHigh != 0){
                                    secondPeakCount = (secondHigh+secondLow)/2;
                                    secondPeak = selectedPlane [secondPeakCount];
                                }
                                else if (secondLow == 0 && secondHigh != 0){
                                    secondPeakCount = (secondHigh+secondPeakCount)/2;
                                    secondPeak = selectedPlane [secondPeakCount];
                                }
                                else if (secondLow != 0 && secondHigh == 0){
                                    secondPeakCount = (secondPeakCount+secondLow)/2;
                                    secondPeak = selectedPlane [secondPeakCount];
                                }
                                
                                if (firstPeakCount >= secondPeakCount) secondPeak = 0;
                            }
                            
                            closeToCenter = planeNumberFinal/2;
                            
                            if (secondPeak == 0) focalPlaneNo = firstPeakCount+1;
                            else if (abs(closeToCenter-secondPeakCount) < abs(closeToCenter-firstPeakCount)) focalPlaneNo = secondPeakCount+1;
                            else if (abs(closeToCenter-secondPeakCount) >= abs(closeToCenter-firstPeakCount)) focalPlaneNo = firstPeakCount+1;
                            else focalPlaneNo = firstPeakCount+1;
                            
                            //cout<<firstPeakCount<<" "<<secondPeakCount<<" "<<focalPlaneNo<<" firstSecondPeakSD"<<endl;
                            
                            delete [] sdList;
                            
                            //*********Gaussian blur**********
                            for (int counter2 = 0; counter2 < planeNumberFinal; counter2++){
                                for (int counter3 = 0; counter3 < imageHeight; counter3++){
                                    for (int counter4 = 0; counter4 < imageWidth; counter4++){
                                        bitGaussian = 0;
                                        
                                        for (int counter5 = -2; counter5 <= 2; counter5++){
                                            for (int counter6 = -2; counter6 <= 2; counter6++){
                                                if (counter3+counter5 >= imageHeight || counter3+counter5 < 0 || counter4+counter6 >= imageWidth || counter4+counter6 < 0){
                                                    bitGaussian = bitGaussian+(int)(arrayImageDataHoldRGBMax [counter2*imageHeight+counter3][counter4]*maskMatrix [counter5+2][counter6+2]);
                                                }
                                                else bitGaussian = bitGaussian+(int)(arrayImageDataHoldRGBMax [counter2*imageHeight+counter3+counter5][counter4+counter6]*maskMatrix [counter5+2][counter6+2]);
                                            }
                                        }
                                        
                                        arrayImageDataHoldTemp [counter2*imageHeight+counter3][counter4] = bitGaussian;
                                    }
                                }
                            }
                            
                            //*******Sobel edge check, use arrayImageDataHoldTemp*******
                            int *sobelTotalList = new int [planeNumberFinal+1];
                            
                            for (int counter2 = 0; counter2 < planeNumberFinal+1; counter2++) sobelTotalList [counter2] = 0;
                            
                            for (int counter2 = 0; counter2 < planeNumberFinal; counter2++){
                                for (int counter3 = 0; counter3 < imageHeight; counter3++){
                                    for (int counter4 = 0; counter4 < imageWidth; counter4++){
                                        limitTemp = counter2*imageHeight;
                                        dataA = arrayImageDataHoldTemp [limitTemp+counter3][counter4];
                                        
                                        gX = 0;
                                        gY = 0;
                                        
                                        if (limitTemp+counter3-1 < limitTemp || limitTemp+counter3+1 >= limitTemp+imageHeight || counter4-1 < 0 || counter4+2 >= imageWidth){
                                            if (limitTemp+counter3-1 < limitTemp && counter4-1 < 0){
                                                gX = gX+dataA*-1;
                                                gY = gY+dataA;
                                            }
                                            
                                            if (limitTemp+counter3-1 >= limitTemp && limitTemp+counter3+1 < limitTemp+imageHeight && counter4-1 < 0) gY = gY+dataA*2;
                                            
                                            if (limitTemp+counter3+1 >= limitTemp+imageHeight && counter4-1 < 0){
                                                gX = gX+dataA;
                                                gY = gY+dataA;
                                            }
                                            
                                            if (limitTemp+counter3-1 < limitTemp && counter4-1 >= 0 && counter4+2 < imageWidth) gX = gX+dataA*-2;
                                            
                                            if (limitTemp+counter3+1 >= limitTemp+imageHeight && counter4-1 >= 0 && counter4+2 < imageWidth) gX = gX+dataA*2;
                                            
                                            if (limitTemp+counter3-1 < limitTemp && counter4+2 >= imageWidth){
                                                gX = gX+dataA*-1;
                                                gY = gY+dataA*-1;
                                            }
                                            
                                            if (limitTemp+counter3-1 >= limitTemp && limitTemp+counter3+1 < limitTemp+imageHeight && counter4+2 >= imageWidth) gY = gY+dataA*-2;
                                            
                                            if (limitTemp+counter3+1 >= limitTemp+imageHeight && counter4+2 >= imageWidth){
                                                gX = gX+dataA;
                                                gY = gY+dataA*-1;
                                            }
                                        }
                                        
                                        if (limitTemp+counter3-1 >= limitTemp && limitTemp+counter3+1 < limitTemp+imageHeight && counter4-1 >= 0 && counter4+2 < imageWidth){
                                            dataA = arrayImageDataHoldTemp [limitTemp+counter3-1][counter4-1];
                                            gX = gX+dataA;
                                            gY = gY+dataA*-1;
                                            
                                            dataA = arrayImageDataHoldTemp [limitTemp+counter3][counter4-1];
                                            gY = gY+dataA*-2;
                                            
                                            dataA = arrayImageDataHoldTemp [limitTemp+counter3+1][counter4-1];
                                            gX = gX+dataA*-1;
                                            gY = gY+dataA*-1;
                                            
                                            dataA = arrayImageDataHoldTemp [limitTemp+counter3-1][counter4];
                                            gX = gX+dataA*2;
                                            
                                            dataA = arrayImageDataHoldTemp [limitTemp+counter3+1][counter4];
                                            gX = gX+dataA*-2;
                                            
                                            dataA = arrayImageDataHoldTemp [limitTemp+counter3-1][counter4+1];
                                            gX = gX+dataA;
                                            gY = gY+dataA;
                                            
                                            dataA = arrayImageDataHoldTemp [limitTemp+counter3][counter4+1];
                                            gY = gY+dataA*2;
                                            
                                            dataA = arrayImageDataHoldTemp [limitTemp+counter3+1][counter4+1];
                                            gX = gX+dataA*-1;
                                            gY = gY+dataA;
                                        }
                                        
                                        if (sqrt(gX*gX+gY*gY) > 400 && sqrt(gX*gX+gY*gY) < 500) sobelTotalList [counter2]++;
                                    }
                                }
                            }
                            
                            //for (int counterA = 0; counterA < planeNumberFinal; counterA++) cout<<counterA<<" "<<sobelTotalList [counterA]<<" Sobel"<<endl;
                            
                            firstPeak = 0;
                            firstPeakCount = 0;
                            secondPeak = 0;
                            secondPeakCount = 0;
                            firstPeakSet = 0;
                            secondPeakSet = 0;
                            currentValue = 0;
                            
                            for (int counter2 = 0; counter2 < planeNumberFinal; counter2++){
                                if (counter2 == 0){
                                    currentValue = sobelTotalList [counter2];
                                    firstPeak = sobelTotalList [counter2];
                                    firstPeakCount = counter2;
                                }
                                else if (counter2 > 0 && currentValue <= sobelTotalList [counter2] && firstPeakSet == 0){
                                    firstPeak = sobelTotalList [counter2];
                                    firstPeakCount = counter2;
                                    currentValue = sobelTotalList [counter2];
                                }
                                else if (counter2 > 0 && currentValue > sobelTotalList [counter2] && firstPeakSet == 0 && secondPeakSet == 0){
                                    currentValue = sobelTotalList [counter2];
                                    firstPeakSet = 1;
                                }
                                else if (counter2 > 0 && currentValue > sobelTotalList [counter2] && firstPeakSet == 1 && secondPeakSet == 0){
                                    currentValue = sobelTotalList [counter2];
                                }
                                else if (counter2 > 0 && currentValue <= sobelTotalList [counter2] && firstPeakSet == 1 && secondPeakSet == 0){
                                    secondPeak = sobelTotalList [counter2];
                                    secondPeakCount = counter2;
                                    currentValue = sobelTotalList [counter2];
                                    secondPeakSet = 1;
                                }
                                else if (counter2 > 0 && currentValue <= sobelTotalList [counter2] && firstPeakSet == 1 && secondPeakSet == 1){
                                    secondPeak = sobelTotalList [counter2];
                                    secondPeakCount = counter2;
                                    currentValue = sobelTotalList [counter2];
                                }
                                else if (counter2 > 0 && currentValue > sobelTotalList [counter2] && firstPeakSet == 1 && secondPeakSet == 1){
                                    currentValue = sobelTotalList [counter2];
                                    secondPeakSet = 2;
                                }
                                else if (counter2 > 0 && currentValue > sobelTotalList [counter2] && firstPeakSet == 1 && secondPeakSet == 2){
                                    currentValue = sobelTotalList [counter2];
                                }
                                else if (counter2 > 0 && currentValue <= sobelTotalList [counter2] && firstPeakSet == 1 && secondPeakSet == 2){
                                    if (secondPeak > firstPeak){
                                        firstPeak = secondPeak;
                                        firstPeakCount = secondPeakCount;
                                        secondPeak = 0;
                                        secondPeakCount = 0;
                                        secondPeakSet = 0;
                                    }
                                    
                                    if (secondPeak < selectedPlane [counter2]){
                                        secondPeak = selectedPlane [counter2];
                                        secondPeakCount = counter2;
                                        secondPeakSet = 1;
                                    }
                                    
                                    currentValue = sobelTotalList [counter2];
                                }
                            }
                            
                            if (secondPeak < firstPeak*(double)0.4) secondPeak = 0;
                            
                            firstLow = 0;
                            firstHigh = 0;
                            
                            for (int counter2 = firstPeakCount-1; counter2 >= 0; counter2--){
                                if (selectedPlane [counter2] > firstPeak*(double)0.9) firstLow = counter2;
                                else{
                                    
                                    break;
                                }
                            }
                            
                            for (int counter2 = firstPeakCount+1; counter2 < planeNumberFinal; counter2++){
                                if (selectedPlane [counter2] > firstPeak*(double)0.9) firstHigh = counter2;
                                else{
                                    
                                    break;
                                }
                            }
                            
                            if (firstLow != 0 && firstHigh != 0) firstPeakCount = (firstHigh+firstLow)/2;
                            else if (firstLow == 0 && firstHigh != 0) firstPeakCount = (firstHigh+firstPeakCount)/2;
                            else if (firstLow != 0 && firstHigh == 0) firstPeakCount = (firstPeakCount+firstLow)/2;
                            
                            if (secondPeak != 0){
                                secondLow = 0;
                                secondHigh = 0;
                                
                                for (int counter2 = secondPeakCount-1; counter2 >= 0; counter2--){
                                    if (selectedPlane [counter2] > secondPeak*(double)0.9) secondLow = counter2;
                                    else{
                                        
                                        break;
                                    }
                                }
                                
                                for (int counter2 = secondPeakCount+1; counter2 < planeNumberFinal; counter2++){
                                    if (selectedPlane [counter2] > secondPeak*(double)0.9) secondHigh = counter2;
                                    else{
                                        
                                        break;
                                    }
                                }
                                
                                if (secondLow != 0 && secondHigh != 0){
                                    secondPeakCount = (secondHigh+secondLow)/2;
                                    secondPeak = selectedPlane [secondPeakCount];
                                }
                                else if (secondLow == 0 && secondHigh != 0){
                                    secondPeakCount = (secondHigh+secondPeakCount)/2;
                                    secondPeak = selectedPlane [secondPeakCount];
                                }
                                else if (secondLow != 0 && secondHigh == 0){
                                    secondPeakCount = (secondPeakCount+secondLow)/2;
                                    secondPeak = selectedPlane [secondPeakCount];
                                }
                                
                                if (firstPeakCount >= secondPeakCount) secondPeak = 0;
                            }
                            
                            //*********Select focal plane using SD and Sobel data*********
                            closeToCenter = planeNumberFinal/2;
                            
                            if (secondPeak == 0) focalPlaneNo2 = firstPeakCount+1;
                            else if (abs(closeToCenter-secondPeakCount) < abs(closeToCenter-firstPeakCount)) focalPlaneNo2 = secondPeakCount+1;
                            else if (abs(closeToCenter-secondPeakCount) >= abs(closeToCenter-firstPeakCount)) focalPlaneNo2 = firstPeakCount+1;
                            else focalPlaneNo2 = firstPeakCount+1;
                            
                            //cout<<firstPeakCount<<" "<<secondPeakCount<<" "<<focalPlaneNo2<<" "<<closeToCenter<<" firstSecondPeak"<<endl;
                            
                            if (closeToCenter-focalPlaneNo < closeToCenter-focalPlaneNo2){
                                if (focalPlaneNo < planeNumberFinal-3 && focalPlaneNo > 3 && closeToCenter > focalPlaneNo) focalPlaneNo = focalPlaneNo+1;
                                else if (focalPlaneNo < planeNumberFinal-3 && focalPlaneNo > 3 && closeToCenter < focalPlaneNo) focalPlaneNo = focalPlaneNo-1;
                                else focalPlaneNo = focalPlaneNo;
                            }
                            else if (closeToCenter-focalPlaneNo > closeToCenter-focalPlaneNo2){
                                if (focalPlaneNo2 < planeNumberFinal-4 && focalPlaneNo2 > 4 && closeToCenter > focalPlaneNo2) focalPlaneNo = focalPlaneNo2+2;
                                else if (focalPlaneNo2 < planeNumberFinal-4 && focalPlaneNo2 > 4 && closeToCenter < focalPlaneNo2) focalPlaneNo = focalPlaneNo2;
                                else if (focalPlaneNo2 >= planeNumberFinal-4) focalPlaneNo = focalPlaneNo2-1;
                                else if (focalPlaneNo2 <= 4) focalPlaneNo = focalPlaneNo2+1;
                                else focalPlaneNo = focalPlaneNo2;
                            }
                            else focalPlaneNo = focalPlaneNo2;
                            
                            //cout<<counter1<<" "<<focalPlaneNo<<" "<<focalPlaneNo2<<" plane no"<<endl;
                            
                            delete [] sobelTotalList;
                            delete [] selectedPlane;
                            
                            if (fixedAllInFlag == 1) focalPlaneNo = fixedPlaneNo;
                            
                            //time7 = clock();
                            //cout<<"  Time6 "<<time7-time6<<" "<<endl;
                            
                            //----Focal plane----
                            if (processTypeHold == "-3000" || processTypeHold == "-3500"){
                                arrayImageFileSave = new int *[imageHeight+1];
                                
                                for (int counter3 = 0; counter3 < imageHeight+1; counter3++){
                                    arrayImageFileSave [counter3] = new int [imageWidth*3+1];
                                }
                                
                                for (int counter3 = 0; counter3 < imageHeight; counter3++){
                                    for (int counter4 = 0; counter4 < imageWidth*3; counter4++){
                                        arrayImageFileSave [counter3][counter4] = 0;
                                    }
                                }
                                
                                if (photoMetric == 1){
                                    if (fluorescentNameTemp != ""){
                                        for (int counter2 = 0; counter2 < imageHeight; counter2++){
                                            for (int counter3 = 0; counter3 < imageWidth; counter3++){
                                                arrayImageFileSave [counter2][counter3] = arrayImageDataHoldSource [(focalPlaneNo-1)*imageHeight+counter2][counter3];
                                            }
                                        }
                                    }
                                    else{
                                        
                                        for (int counter2 = 0; counter2 < imageHeight; counter2++){
                                            for (int counter3 = 0; counter3 < imageWidth; counter3++){
                                                arrayImageFileSave [counter2][counter3] = arrayImageDataHold [(focalPlaneNo-1)*imageHeight+counter2][counter3];
                                            }
                                        }
                                    }
                                }
                                else if (photoMetric == 2){
                                    for (int counter2 = 0; counter2 < imageHeight; counter2++){
                                        for (int counter3 = 0; counter3 < imageWidth; counter3++){
                                            arrayImageFileSave [counter2][counter3*3] = arrayImageDataHold [(focalPlaneNo-1)*imageHeight+counter2][counter3*3];
                                            arrayImageFileSave [counter2][counter3*3+1] = arrayImageDataHold [(focalPlaneNo-1)*imageHeight+counter2][counter3*3+1];
                                            arrayImageFileSave [counter2][counter3*3+2] = arrayImageDataHold [(focalPlaneNo-1)*imageHeight+counter2][counter3*3+2];
                                        }
                                    }
                                }
                                
                                mode = 0;
                                ifDPreviousHold = 0;
                                imageBit = 8;
                                
                                if (xPosition == -1) xPosition = 100;
                                if (yPosition == -1) yPosition = 100;
                                
                                self->singleTiffSave = [[SingleTiffSave alloc] init];
                                [self->singleTiffSave singleTiffLayerSave:imageWidth:imageHeight:imageBit:photoMetric:samplePerPix:xPosition:yPosition:mode:ifDPreviousHold];
                                
                                
                                for (int counter3 = 0; counter3 < imageHeight+1; counter3++){
                                    delete [] arrayImageFileSave [counter3];
                                }
                                
                                delete [] arrayImageFileSave;
                                
                                
                                extension = to_string(focalPlaneNo);
                                
                                if (extension.length() == 1) extension = "00"+extension;
                                else if (extension.length() == 2) extension = "0"+extension;
                                
                                if (contrastSkipFlag == 0){
                                    arrayProcessList [upDateNo*5+3] = "-6"+extension;
                                    arrayProcessList [upDateNo*5+4] = "-3000";
                                }
                                else if (contrastSkipFlag == 1){
                                    arrayProcessList [upDateNo*5+3] = "-7"+extension;
                                    arrayProcessList [upDateNo*5+4] = "-3500";
                                }
                            }
                            
                            //----All-in-Focus----
                            if (processTypeHold == "-4000" || processTypeHold == "-4500" || (processTypeHoldInt < -8000 && processTypeHoldInt > -9000) || (processTypeHoldInt < -9000 && processTypeHoldInt > -10000) || (processTypeHoldInt < -10000000 && processTypeHoldInt > -11000000) || (processTypeHoldInt < -11000000 && processTypeHoldInt > -12000000)){
                                int *planeValue = new int [planeNumberFinal+1];
                                int *centerValue = new int [planeNumberFinal+1];
                                
                                /*
                                 All in focus, All in focus set PL, and Range
                                 *DIC channel:
                                 
                                 All in focus: use all plane, focus plane number is used to generate an all in focus image
                                 All in focus set PL: use setted plane to create an all in focus image
                                 Range: use planes within the range
                                 
                                 *Fluorescent chennel:
                                 All in focus: use all plane
                                 All in focus set PL: same with All in focus
                                 Range: use planes within the range
                                 */
                                
                                //for (int counterA = 0; counterA < imageWidth*2; counterA++){
                                //    for (int counterB = 0; counterB < imageWidth*2; counterB++) cout<<" "<<arrayImageDataHold [512*11][counterB];
                                //    cout<<" arrayImageDataHold "<<endl;
                                //}
                                
                                //for (int counterA = 0; counterA < 30; counterA++){
                                //  for (int counterB = 0; counterB < imageWidth; counterB++) cout<<" "<<arrayImageDataHoldTemp [counterA][counterB];
                                //  cout<<" arrayImageDataHoldTemp "<<counterA<<endl;
                                //}
                                
                                if (processTypeHold == "-4000" || processTypeHold == "-4500" || (processTypeHoldInt < -8000 && processTypeHoldInt > -9000) || (processTypeHoldInt < -9000 && processTypeHoldInt > -10000)){
                                    if (firstImageExclude == 0) rangeDown = 1;
                                    else rangeDown = 2;
                                    
                                    rangeTop = planeNumberFinal;
                                }
                                else{
                                    
                                    rangeDown = atoi(extractDown.c_str());
                                    rangeTop = atoi(extractTop.c_str());
                                }
                                
                                arrayImageFileSave = new int *[imageHeight+1];
                                
                                for (int counter3 = 0; counter3 < imageHeight+1; counter3++){
                                    arrayImageFileSave [counter3] = new int [imageWidth*3+1];
                                }
                                
                                for (int counter3 = 0; counter3 < imageHeight; counter3++){
                                    for (int counter4 = 0; counter4 < imageWidth*3; counter4++){
                                        arrayImageFileSave [counter3][counter4] = 0;
                                    }
                                }
                                
                                if (channelTableNo == ""){
                                    for (int counter2 = 0; counter2 < imageHeight; counter2++){
                                        for (int counter3 = 0; counter3 < imageWidth; counter3++){
                                            for (int counter4 = rangeDown; counter4 < rangeTop; counter4++){
                                                centerValue [counter4-1] = arrayImageDataHold [counter4*imageHeight+counter2][counter3];
                                                
                                                value1 = 500;
                                                value2 = 500;
                                                value3 = 500;
                                                value4 = 500;
                                                
                                                if (counter4*imageHeight+counter2-1 < counter4*imageHeight || counter4*imageHeight+counter2+1 >= counter4*imageHeight+imageHeight){
                                                    value1 = 0;
                                                    value2 = 0;
                                                    value3 = 0;
                                                }
                                                if (counter3-1 < 0 || counter3+1 >= imageWidth){
                                                    value1 = 0;
                                                    value3 = 0;
                                                    value4 = 0;
                                                }
                                                if (value1 == 500){
                                                    value1 = abs(arrayImageDataHoldTemp [counter4*imageHeight+counter2-1][counter3-1]-arrayImageDataHoldTemp [counter4*imageHeight+counter2+1][counter3+1]);
                                                }
                                                if (value2 == 500){
                                                    value2 = abs(arrayImageDataHoldTemp [counter4*imageHeight+counter2-1][counter3]-arrayImageDataHoldTemp [counter4*imageHeight+counter2+1][counter3]);
                                                }
                                                if (value3 == 500){
                                                    value3 = abs(arrayImageDataHoldTemp [counter4*imageHeight+counter2-1][counter3+1]-arrayImageDataHoldTemp [counter4*imageHeight+counter2+1][counter3-1]);
                                                }
                                                if (value4 == 500){
                                                    value4 = abs(arrayImageDataHoldTemp [counter4*imageHeight+counter2][counter3-1]-arrayImageDataHoldTemp [counter4*imageHeight+counter2][counter3+1]);
                                                }
                                                
                                                totalDiff = value1+value2+value3+value4;
                                                planeValue [counter4] = totalDiff;
                                            }
                                            
                                            valueRangeCheck = 0;
                                            pixValueFocal = centerValue [focalPlaneNo-1];
                                            focalPlaneValue = planeValue [focalPlaneNo-1];
                                            
                                            //for (int counterB = 0; counterB < rangeTop; counterB++) cout<<" "<<centerValue [counterB];
                                            //cout<<" planeValue "<<pixValueFocal<<" "<<focalPlaneValue<<" "<<focalPlaneNo<<endl;
                                            
                                            focalPlaneValueTemp = 100000;
                                            focalPlaneValueTemp2 = 0;
                                            
                                            for (int counter4 = focalPlaneNo-1; counter4 >= rangeDown; counter4--){
                                                if (focalPlaneValueTemp > planeValue [counter4]) focalPlaneValueTemp = planeValue [counter4];
                                                if (focalPlaneValueTemp2 < planeValue [counter4]) focalPlaneValueTemp2 = planeValue [counter4];
                                            }
                                            
                                            if (focalPlaneValueTemp == 100000 || abs(focalPlaneValueTemp-focalPlaneValueTemp2) < 10){
                                                valueRangeCheck = 1;
                                            }
                                            
                                            if (valueRangeCheck == 0){
                                                pixCountTemp = 0;
                                                focalPlaneValueTemp = 0;
                                                
                                                for (int counter4 = focalPlaneNo-1; counter4 >= rangeDown; counter4--){
                                                    if (planeValue [counter4] > focalPlaneValue && focalPlaneValueTemp < planeValue [counter4] && centerValue [counter4] < pixValueFocal){
                                                        pixCountTemp = counter4;
                                                        focalPlaneValueTemp = planeValue [counter4];
                                                    }
                                                }
                                                
                                                if (focalPlaneValueTemp != 0){
                                                    if (pixValueFocal > 225){
                                                        arrayImageFileSave [counter2][counter3] = pixValueFocal;
                                                    }
                                                    else if (pixValueFocal > 200 && centerValue [pixCountTemp] < pixValueFocal-20){
                                                        arrayImageFileSave [counter2][counter3] = (centerValue [pixCountTemp]+pixValueFocal)/2;
                                                    }
                                                    else if (pixValueFocal <= 200 && centerValue [pixCountTemp] > 200 && pixCountTemp == 0){
                                                        arrayImageFileSave [counter2][counter3] = pixValueFocal;
                                                    }
                                                    else arrayImageFileSave [counter2][counter3] = centerValue [pixCountTemp];
                                                }
                                                else{
                                                    
                                                    valueRangeCheck = 0;
                                                    focalPlaneValueTemp = 100000;
                                                    
                                                    for (int counter4 = focalPlaneNo+1; counter4 < rangeTop; counter4++){
                                                        if (focalPlaneValueTemp > planeValue [counter4]){
                                                            focalPlaneValueTemp = planeValue [counter4];
                                                        }
                                                    }
                                                    
                                                    if (focalPlaneValueTemp == 100000 || abs(focalPlaneValueTemp-focalPlaneValue) < 10){
                                                        valueRangeCheck = 1;
                                                    }
                                                    
                                                    if (valueRangeCheck == 0){
                                                        pixCountTemp = 0;
                                                        focalPlaneValueTemp = 0;
                                                        
                                                        for (int counter4 = focalPlaneNo+1; counter4 < rangeTop; counter4++){
                                                            if (planeValue [counter4] > focalPlaneValue && focalPlaneValueTemp < planeValue [counter4] && centerValue [counter4] > pixValueFocal){
                                                                pixCountTemp = counter4;
                                                                focalPlaneValueTemp = planeValue [counter4];
                                                            }
                                                        }
                                                        
                                                        if (focalPlaneValueTemp != 0){
                                                            if (pixValueFocal > 225){
                                                                arrayImageFileSave [counter2][counter3] = pixValueFocal;
                                                            }
                                                            else if (pixValueFocal > 200 && centerValue [pixCountTemp] < pixValueFocal-20){
                                                                arrayImageFileSave [counter2][counter3] = (centerValue [pixCountTemp]+pixValueFocal)/2;
                                                            }
                                                            else if (pixValueFocal <= 200 && centerValue [pixCountTemp] > 200 && pixCountTemp == 0){
                                                                arrayImageFileSave [counter2][counter3] = pixValueFocal;
                                                            }
                                                            else arrayImageFileSave [counter2][counter3] = centerValue [pixCountTemp];
                                                        }
                                                        else arrayImageFileSave [counter2][counter3] = centerValue [focalPlaneNo-1];
                                                    }
                                                    else arrayImageFileSave [counter2][counter3] = centerValue [focalPlaneNo-1];
                                                }
                                            }
                                            else arrayImageFileSave [counter2][counter3] = centerValue [focalPlaneNo-1];
                                        }
                                    }
                                }
                                else{
                                    
                                    for (int counter2 = 0; counter2 < imageHeight; counter2++){
                                        for (int counter3 = 0; counter3 < imageWidth; counter3++){
                                            for (int counter4 = rangeDown; counter4 < rangeTop; counter4++){
                                                planeValue [counter4] = arrayImageDataHoldSource [counter4*imageHeight+counter2][counter3];
                                            }
                                            
                                            focalPlaneValueTemp = 100000;
                                            focalPlaneValueTemp2 = 0;
                                            
                                            for (int counter4 = rangeDown; counter4 < rangeTop; counter4++){
                                                if (focalPlaneValueTemp > planeValue [counter4]){
                                                    focalPlaneValueTemp = planeValue [counter4];
                                                }
                                                
                                                if (focalPlaneValueTemp2 < planeValue [counter4]){
                                                    focalPlaneValueTemp2 = planeValue [counter4];
                                                }
                                            }
                                            
                                            if (focalPlaneValueTemp == 100000){
                                                arrayImageFileSave [counter2][counter3] = 0;
                                            }
                                            else{
                                                
                                                if (processTypeHold == "-4000" || (processTypeHoldInt < -8000 && processTypeHoldInt > -9000) || (processTypeHoldInt < -10000000 && processTypeHoldInt > -11000000)){
                                                    for (int counter4 = rangeDown; counter4 < rangeTop; counter4++){
                                                        focalPlaneValue = focalPlaneValue+planeValue [counter4];
                                                    }
                                                    
                                                    focalPlaneValue = (int)(focalPlaneValue/(double)(rangeTop-rangeDown));
                                                    arrayImageFileSave [counter2][counter3] = focalPlaneValue;
                                                }
                                                else arrayImageFileSave [counter2][counter3] = focalPlaneValueTemp2;
                                            }
                                        }
                                    }
                                }
                                
                                delete [] planeValue;
                                delete [] centerValue;
                                
                                mode = 0;
                                ifDPreviousHold = 0;
                                imageBit = 8;
                                
                                if (xPosition == -1) xPosition = 100;
                                if (yPosition == -1) yPosition = 100;
                                
                                self->singleTiffSave = [[SingleTiffSave alloc] init];
                                [self->singleTiffSave singleTiffLayerSave:imageWidth:imageHeight:imageBit:photoMetric:samplePerPix:xPosition:yPosition:mode:ifDPreviousHold];
                                
                                for (int counter3 = 0; counter3 < imageHeight+1; counter3++){
                                    delete [] arrayImageFileSave [counter3];
                                }
                                
                                delete [] arrayImageFileSave;
                                
                                
                                if (fixedAllInFlag == 1){
                                    if ((processTypeHoldInt < -8000 && processTypeHoldInt > -9000) || (processTypeHoldInt < -9000 && processTypeHoldInt > -10000)){
                                        extension = to_string(fixedPlaneNo);
                                        
                                        if (extension.length() == 1) extension = "00"+extension;
                                        else if (extension.length() == 2) extension = "0"+extension;
                                        
                                        if (contrastSkipFlag == 0){
                                            arrayProcessList [upDateNo*5+3] = "-8"+extension;
                                            arrayProcessList [upDateNo*5+4] = "-8"+extension;
                                        }
                                        else if (contrastSkipFlag == 1){
                                            arrayProcessList [upDateNo*5+3] = "-9"+extension;
                                            arrayProcessList [upDateNo*5+4] = "-9"+extension;
                                        }
                                    }
                                    else{
                                        
                                        extractDown = to_string(atoi(extractDown.c_str()));
                                        
                                        if (extractDown.length() == 1) extractDown = "00"+extractDown;
                                        else if (extractDown.length() == 2) extractDown = "0"+extractDown;
                                        
                                        extractTop = to_string(atoi(extractTop.c_str()));
                                        
                                        if (extractTop.length() == 1) extractTop = "00"+extractTop;
                                        else if (extractTop.length() == 2) extractTop = "0"+extractTop;
                                        
                                        if (contrastSkipFlag == 0){
                                            arrayProcessList [upDateNo*5+3] = "-10"+extractDown+extractTop;
                                            arrayProcessList [upDateNo*5+4] = "-10"+extractDown+extractTop;
                                        }
                                        else if (contrastSkipFlag == 1){
                                            arrayProcessList [upDateNo*5+3] = "-11"+extractDown+extractTop;
                                            arrayProcessList [upDateNo*5+4] = "-11"+extractDown+extractTop;
                                        }
                                    }
                                }
                                else{
                                    
                                    if (contrastSkipFlag == 0){
                                        arrayProcessList [upDateNo*5+4] = "-4000";
                                        arrayProcessList [upDateNo*5+4] = "-4000";
                                    }
                                    else if (contrastSkipFlag == 1){
                                        arrayProcessList [upDateNo*5+4] = "-4500";
                                        arrayProcessList [upDateNo*5+4] = "-4500";
                                    }
                                }
                            }
                            
                            //time8 = clock();
                            //cout<<"  Time7 "<<time8-time7<<" "<<endl;
                            
                            //for (int counterA = 0; counterA < 200; counterA++){
                            //    for (int counterB = 0; counterB < 200; counterB++) cout<<" "<<arrayFocalNumber [counterA][counterB];
                            //    cout<<" arrayFocalNumber "<<counterA<<endl;
                            // }
                        }
                        
                        for (int counter2 = 0; counter2 < imageHeight*planeNumberFinal+2; counter2++){
                            delete [] arrayImageDataHold [counter2];
                            delete [] arrayImageDataHoldSource [counter2];
                            delete [] arrayImageDataHoldTemp [counter2];
                            delete [] arrayImageDataHoldRGBMax [counter2];
                        }
                        
                        delete [] arrayImageDataHold;
                        delete [] arrayImageDataHoldSource;
                        delete [] arrayImageDataHoldTemp;
                        delete [] arrayImageDataHoldRGBMax;
                        
                        delete [] arrayExtractedImage3;
                        delete [] fileReadArray;
                    }
                }
            }
            
            //for (int counterA = 0; counterA < processListCount/5; counterA++){
            //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayProcessList [counterA*5+counterB];
            //    cout<<" arrayProcessList "<<counterA+1<<endl;
            //}
            
            if (nameListOfFilesStatus == 1){
                delete [] arrayNameListOfFiles;
                nameListOfFilesStatus = 0;
            }
            
            progressTiming = 5;
            
            do usleep(10);
            while (progressTiming == 5);
            
            progressTiming = 7;
            
            processProceed = 1;
        }
        
        if (processProceed == 1){
            //----update array----
            for (int counter1 = 0; counter1 < processListCount/5; counter1++){
                if (arrayProcessList [counter1*5+2] != "0" && arrayProcessList [counter1*5+3] == "-5000" && arrayProcessList [counter1*5+4] == "0"){
                    arrayProcessList [counter1*5+4] = "-2500";
                }
                else if (arrayProcessList [counter1*5+2] != "0" && arrayProcessList [counter1*5+4] == "0"){
                    arrayProcessList [counter1*5+4] = arrayProcessList [counter1*5+3];
                    arrayProcessList [counter1*5+3] = "-2000";
                }
            }
            
            //for (int counterA = 0; counterA < processListCount/5; counterA++){
            //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayProcessList [counterA*5+counterB];
            //    cout<<" arrayProcessList "<<counterA+1<<endl;
            //}
            
            // for (int counterA = 0; counterA < treatmentNameDisplayCount; counterA++){
            //     for (int counterB = 0; counterB < currentTimePoint+2; counterB++) cout<<" "<<arrayFocalPlaneData [counterA][counterB];
            //     cout<<"  arrayFocalPlaneData "<<counterA+1<<endl;
            // }
            
            ofstream oin;
            
            if (processMode == 2 || processMode == 3 || processMode == 6 || processMode == 7 || currentTimePoint >= importTableEnd){
                int processListEntryCount = 0;
                
                if (currentTimePoint+5 > focalPlaneDataLimit) [self focalPlaneDataUpData];
                
                for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                    if (arrayFOVNameDisplay [counter1] != "ND"){
                        arrayFocalPlaneData [counter1][currentTimePoint+1] = atoi(arrayProcessList [processListEntryCount*5+3].c_str());
                        arrayFocalPlaneData [counter1][currentTimePoint+2] = atoi(arrayProcessList [processListEntryCount*5+4].c_str());
                        processListEntryCount++;
                    }
                    else arrayFocalPlaneData [counter1][currentTimePoint+2] = 0;
                }
                
                //for (int counterA = 0; counterA < treatmentNameDisplayCount; counterA++){
                //    for (int counterB = 0; counterB < currentTimePoint+3; counterB++) cout<<" "<<arrayFocalPlaneData [counterA][counterB];
                //    cout<<"  arrayFocalPlaneData "<<counterA+1<<endl;
                //}
                
                if (processMode == 5 || processMode == 7) oin.open(productsFocalPlaneTempPath.c_str(), ios::out);
                else oin.open(productsFocalPlanePath.c_str(), ios::out);
                
                for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                    for (int counter2 = 0; counter2 < currentTimePoint+3; counter2++) oin<<arrayFocalPlaneData [counter1][counter2]<<endl;
                }
                
                oin.close();
            }
            else{
                
                int processListEntryCount = 0;
                
                if (currentTimePoint+5 > focalPlaneDataLimit) [self focalPlaneDataUpData];
                
                for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                    if (arrayFOVNameDisplay [counter1] != "ND"){
                        arrayFocalPlaneData [counter1][currentTimePoint+1] = atoi(arrayProcessList [processListEntryCount*5+3].c_str());
                        
                        if (arrayProcessList [processListEntryCount*5+3] == "-5000" || arrayProcessList [processListEntryCount*5+3] == "-2500"){
                            arrayFocalPlaneData [counter1][currentTimePoint+2] = -2500;
                        }
                        
                        processListEntryCount++;
                    }
                    else arrayFocalPlaneData [counter1][currentTimePoint+2] = 0;
                }
                
                //for (int counterA = 0; counterA < treatmentNameDisplayCount; counterA++){
                //    for (int counterB = 0; counterB < importTableEnd+2; counterB++) cout<<" "<<arrayFocalPlaneData [counterA][counterB];
                //    cout<<"  arrayFocalPlaneData "<<counterA+1<<endl;
                //}
                
                if (processMode == 5 || processMode == 7) oin.open(productsFocalPlaneTempPath.c_str(), ios::out);
                else oin.open(productsFocalPlanePath.c_str(), ios::out);
                
                for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                    for (int counter2 = 0; counter2 < importTableEnd+2; counter2++) oin<<arrayFocalPlaneData [counter1][counter2]<<endl;
                }
                
                oin.close();
            }
            
            int currentCutOff = 0;
            
            if (importTableEnd != -1) currentCutOff = importTableEnd;
            else currentCutOff = currentTimePoint+1;
            
            currentTimePoint++;
            
            if (importTableEnd != -1 && currentTimePoint > importTableEnd){
                importTableEnd = -1;
                currentCutOff = currentTimePoint;
            }
            
            int startingTimePoint = 1;
            tableDisplayCount = 0;
            
            if (currentTimePoint > 15){
                int remainingPoint = currentTimePoint%15;
                
                if (remainingPoint == 0) startingTimePoint = currentTimePoint;
                else  startingTimePoint = currentTimePoint-remainingPoint;
            }
            
            //----Line One set----
            arrayTableDisplay [tableDisplayCount] = "Name", tableDisplayCount++;
            arrayTableDisplay [tableDisplayCount] = "FOV", tableDisplayCount++;
            
            string extension;
            
            for (int counter1 = startingTimePoint; counter1 < startingTimePoint+15; counter1++){
                extension = to_string(counter1);
                
                if (importTableEnd == counter1 && importTableEnd != currentTimePoint) arrayTableDisplay [tableDisplayCount] = "E"+extension, tableDisplayCount++;
                else if (currentTimePoint == counter1) arrayTableDisplay [tableDisplayCount] = "C"+extension, currentTableHead = tableDisplayCount, tableDisplayCount++;
                else arrayTableDisplay [tableDisplayCount] = "T"+extension, tableDisplayCount++;
            }
            
            //for (int counterA = 0; counterA < treatmentNameDisplayCount; counterA++){
            //    for (int counterB = 0; counterB < 17; counterB++) cout<<" "<<arrayTableDisplay [counterA*17+counterB];
            //    cout<<" arrayTableDisplay "<<counterA+1<<endl;
            //}
            
            //for (int counterA = 0; counterA < treatmentNameDisplayCount; counterA++){
            //    for (int counterB = 0; counterB < currentTimePoint+2; counterB++) cout<<" "<<arrayFocalPlaneData [counterA][counterB];
            //    cout<<"  arrayFocalPlaneData "<<counterA+1<<endl;
            //}
            
            if (arrayTreatmentNameDisplay [0] != "nil"){
                string extract1;
                string extract2;
                
                for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                    if (arrayTreatmentNameDisplay [counter1] != "ND") arrayTableDisplay [tableDisplayCount] = arrayTreatmentNameDisplay [counter1], tableDisplayCount++;
                    else arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
                    
                    if (arrayFOVNameDisplay [counter1] != "ND") arrayTableDisplay [tableDisplayCount] = arrayFOVNameDisplay [counter1], tableDisplayCount++;
                    else arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
                    
                    if (arrayFOVNameDisplay [counter1] != "ND"){
                        for (int counter2 = startingTimePoint; counter2 < startingTimePoint+15; counter2++){
                            if (counter2 > currentCutOff) arrayTableDisplay [tableDisplayCount] = "0", tableDisplayCount++;
                            else if (counter2 == currentTimePoint){
                                if (arrayFocalPlaneData [counter1][counter2+1] == -1000) arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
                                else if (arrayFocalPlaneData [counter1][counter2+1] == -2000) arrayTableDisplay [tableDisplayCount] = "*", tableDisplayCount++;
                                else if (arrayFocalPlaneData [counter1][counter2+1] == -2500) arrayTableDisplay [tableDisplayCount] = "*", tableDisplayCount++;
                                else if (arrayFocalPlaneData [counter1][counter2+1] == -3000) arrayTableDisplay [tableDisplayCount] = "f", tableDisplayCount++;
                                else if (arrayFocalPlaneData [counter1][counter2+1] == -3500) arrayTableDisplay [tableDisplayCount] = "F", tableDisplayCount++;
                                else if (arrayFocalPlaneData [counter1][counter2+1] < -6000 && arrayFocalPlaneData [counter1][counter2+1] > -7000){
                                    extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                                    extension = extension.substr(2);
                                    extension = to_string(atoi(extension.c_str()));
                                    
                                    arrayTableDisplay [tableDisplayCount] = "p"+extension, tableDisplayCount++;
                                }
                                else if (arrayFocalPlaneData [counter1][counter2+1] < -7000 && arrayFocalPlaneData [counter1][counter2+1] > -8000){
                                    extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                                    extension = extension.substr(2);
                                    extension = to_string(atoi(extension.c_str()));
                                    
                                    arrayTableDisplay [tableDisplayCount] = "P"+extension, tableDisplayCount++;
                                }
                                else if (arrayFocalPlaneData [counter1][counter2+1] == -4000) arrayTableDisplay [tableDisplayCount] = "a", tableDisplayCount++;
                                else if (arrayFocalPlaneData [counter1][counter2+1] == -4500) arrayTableDisplay [tableDisplayCount] = "A", tableDisplayCount++;
                                else if (arrayFocalPlaneData [counter1][counter2+1] < -8000 && arrayFocalPlaneData [counter1][counter2+1] > -9000){
                                    extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                                    extension = extension.substr(2);
                                    extension = to_string(atoi(extension.c_str()));
                                    
                                    arrayTableDisplay [tableDisplayCount] = "s"+extension, tableDisplayCount++;
                                }
                                else if (arrayFocalPlaneData [counter1][counter2+1] < -9000 && arrayFocalPlaneData [counter1][counter2+1] > -10000){
                                    extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                                    extension = extension.substr(2);
                                    extension = to_string(atoi(extension.c_str()));
                                    
                                    arrayTableDisplay [tableDisplayCount] = "S"+extension, tableDisplayCount++;
                                }
                                else if (arrayFocalPlaneData [counter1][counter2+1] < -10000000 && arrayFocalPlaneData [counter1][counter2+1] > -11000000){
                                    extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                                    extract1 = extension.substr(3, 3);
                                    extract2 = extension.substr(6, 3);
                                    extract1 = to_string(atoi(extract1.c_str()));
                                    extract2 = to_string(atoi(extract2.c_str()));
                                    
                                    arrayTableDisplay [tableDisplayCount] = "r"+extract1+"-"+extract2, tableDisplayCount++;
                                }
                                else if (arrayFocalPlaneData [counter1][counter2+1] < -11000000 && arrayFocalPlaneData [counter1][counter2+1] > -12000000){
                                    extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                                    extract1 = extension.substr(3, 3);
                                    extract2 = extension.substr(6, 3);
                                    extract1 = to_string(atoi(extract1.c_str()));
                                    extract2 = to_string(atoi(extract2.c_str()));
                                    
                                    arrayTableDisplay [tableDisplayCount] = "R"+extract1+"-"+extract2, tableDisplayCount++;
                                }
                                else arrayTableDisplay [tableDisplayCount] = "ND", tableDisplayCount++;
                            }
                            else if (counter2 == importTableEnd){
                                if (arrayFocalPlaneData [counter1][counter2+1] == -1000) arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
                                else if (arrayFocalPlaneData [counter1][counter2+1] == -2000) arrayTableDisplay [tableDisplayCount] = "*", tableDisplayCount++;
                                else if (arrayFocalPlaneData [counter1][counter2+1] == -2500) arrayTableDisplay [tableDisplayCount] = "*", tableDisplayCount++;
                                else if (arrayFocalPlaneData [counter1][counter2+1] == -3000) arrayTableDisplay [tableDisplayCount] = "f", tableDisplayCount++;
                                else if (arrayFocalPlaneData [counter1][counter2+1] == -3500) arrayTableDisplay [tableDisplayCount] = "F", tableDisplayCount++;
                                else if (arrayFocalPlaneData [counter1][counter2+1] < -6000 && arrayFocalPlaneData [counter1][counter2+1] > -7000){
                                    extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                                    extension = extension.substr(2);
                                    extension = to_string(atoi(extension.c_str()));
                                    
                                    arrayTableDisplay [tableDisplayCount] = "p"+extension, tableDisplayCount++;
                                }
                                else if (arrayFocalPlaneData [counter1][counter2+1] < -7000 && arrayFocalPlaneData [counter1][counter2+1] > -8000){
                                    extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                                    extension = extension.substr(2);
                                    extension = to_string(atoi(extension.c_str()));
                                    
                                    arrayTableDisplay [tableDisplayCount] = "P"+extension, tableDisplayCount++;
                                }
                                else if (arrayFocalPlaneData [counter1][counter2+1] == -4000) arrayTableDisplay [tableDisplayCount] = "a", tableDisplayCount++;
                                else if (arrayFocalPlaneData [counter1][counter2+1] == -4500) arrayTableDisplay [tableDisplayCount] = "A", tableDisplayCount++;
                                else if (arrayFocalPlaneData [counter1][counter2+1] < -8000 && arrayFocalPlaneData [counter1][counter2+1] > -9000){
                                    extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                                    extension = extension.substr(2);
                                    extension = to_string(atoi(extension.c_str()));
                                    
                                    arrayTableDisplay [tableDisplayCount] = "s"+extension, tableDisplayCount++;
                                }
                                else if (arrayFocalPlaneData [counter1][counter2+1] < -9000 && arrayFocalPlaneData [counter1][counter2+1] > -10000){
                                    extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                                    extension = extension.substr(2);
                                    extension = to_string(atoi(extension.c_str()));
                                    
                                    arrayTableDisplay [tableDisplayCount] = "S"+extension, tableDisplayCount++;
                                }
                                else if (arrayFocalPlaneData [counter1][counter2+1] == -5000) arrayTableDisplay [tableDisplayCount] = "T", tableDisplayCount++;
                                else if (arrayFocalPlaneData [counter1][counter2+1] < -10000000 && arrayFocalPlaneData [counter1][counter2+1] > -11000000){
                                    extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                                    extract1 = extension.substr(3, 3);
                                    extract2 = extension.substr(6, 3);
                                    extract1 = to_string(atoi(extract1.c_str()));
                                    extract2 = to_string(atoi(extract2.c_str()));
                                    
                                    arrayTableDisplay [tableDisplayCount] = "r"+extract1+"-"+extract2, tableDisplayCount++;
                                }
                                else if (arrayFocalPlaneData [counter1][counter2+1] < -11000000 && arrayFocalPlaneData [counter1][counter2+1] > -12000000){
                                    extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                                    extract1 = extension.substr(3, 3);
                                    extract2 = extension.substr(6, 3);
                                    extract1 = to_string(atoi(extract1.c_str()));
                                    extract2 = to_string(atoi(extract2.c_str()));
                                    
                                    arrayTableDisplay [tableDisplayCount] = "R"+extract1+"-"+extract2, tableDisplayCount++;
                                }
                                else arrayTableDisplay [tableDisplayCount] = "ND", tableDisplayCount++;
                            }
                            else{
                                
                                if (arrayFocalPlaneData [counter1][counter2+1] == -1000) arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
                                else if (arrayFocalPlaneData [counter1][counter2+1] == -2000) arrayTableDisplay [tableDisplayCount] = "*", tableDisplayCount++;
                                else if (arrayFocalPlaneData [counter1][counter2+1] == -2500) arrayTableDisplay [tableDisplayCount] = "*", tableDisplayCount++;
                                else if (arrayFocalPlaneData [counter1][counter2+1] == -3000) arrayTableDisplay [tableDisplayCount] = "f", tableDisplayCount++;
                                else if (arrayFocalPlaneData [counter1][counter2+1] == -3500) arrayTableDisplay [tableDisplayCount] = "F", tableDisplayCount++;
                                else if (arrayFocalPlaneData [counter1][counter2+1] < -6000 && arrayFocalPlaneData [counter1][counter2+1] > -7000){
                                    extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                                    extension = extension.substr(2);
                                    extension = to_string(atoi(extension.c_str()));
                                    
                                    arrayTableDisplay [tableDisplayCount] = "p"+extension, tableDisplayCount++;
                                }
                                else if (arrayFocalPlaneData [counter1][counter2+1] < -7000 && arrayFocalPlaneData [counter1][counter2+1] > -8000){
                                    extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                                    extension = extension.substr(2);
                                    extension = to_string(atoi(extension.c_str()));
                                    
                                    arrayTableDisplay [tableDisplayCount] = "P"+extension, tableDisplayCount++;
                                }
                                else if (arrayFocalPlaneData [counter1][counter2+1] == -4000) arrayTableDisplay [tableDisplayCount] = "a", tableDisplayCount++;
                                else if (arrayFocalPlaneData [counter1][counter2+1] == -4500) arrayTableDisplay [tableDisplayCount] = "A", tableDisplayCount++;
                                else if (arrayFocalPlaneData [counter1][counter2+1] < -8000 && arrayFocalPlaneData [counter1][counter2+1] > -9000){
                                    extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                                    extension = extension.substr(2);
                                    extension = to_string(atoi(extension.c_str()));
                                    
                                    arrayTableDisplay [tableDisplayCount] = "s"+extension, tableDisplayCount++;
                                }
                                else if (arrayFocalPlaneData [counter1][counter2+1] < -9000 && arrayFocalPlaneData [counter1][counter2+1] > -10000){
                                    extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                                    extension = extension.substr(2);
                                    extension = to_string(atoi(extension.c_str()));
                                    
                                    arrayTableDisplay [tableDisplayCount] = "S"+extension, tableDisplayCount++;
                                }
                                else if (arrayFocalPlaneData [counter1][counter2+1] == -5000) arrayTableDisplay [tableDisplayCount] = "T", tableDisplayCount++;
                                else if (arrayFocalPlaneData [counter1][counter2+1] < -10000000 && arrayFocalPlaneData [counter1][counter2+1] > -11000000){
                                    extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                                    extract1 = extension.substr(3, 3);
                                    extract2 = extension.substr(6, 3);
                                    extract1 = to_string(atoi(extract1.c_str()));
                                    extract2 = to_string(atoi(extract2.c_str()));
                                    
                                    arrayTableDisplay [tableDisplayCount] = "r"+extract1+"-"+extract2, tableDisplayCount++;
                                }
                                else if (arrayFocalPlaneData [counter1][counter2+1] < -11000000 && arrayFocalPlaneData [counter1][counter2+1] > -12000000){
                                    extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                                    extract1 = extension.substr(3, 3);
                                    extract2 = extension.substr(6, 3);
                                    extract1 = to_string(atoi(extract1.c_str()));
                                    extract2 = to_string(atoi(extract2.c_str()));
                                    
                                    arrayTableDisplay [tableDisplayCount] = "R"+extract1+"-"+extract2, tableDisplayCount++;
                                }
                                else arrayTableDisplay [tableDisplayCount] = "ND", tableDisplayCount++;
                            }
                        }
                    }
                    else{
                        
                        for (int counter2 = 0; counter2 < 15; counter2++) arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
                    }
                }
            }
            
            //cout<<startingTimePoint<<" time "<<currentTimePoint<<endl;
            
            if (processMode == 5 || processMode == 7) oin.open(focalSettingTempPath.c_str(),ios::out);
            else oin.open(focalSettingPath.c_str(),ios::out);
            
            oin<<currentTimePoint<<endl;
            oin<<importTableEnd<<endl;
            oin<<dicRangeSet<<endl;
            oin<<firstImageExclude<<endl;
            oin<<copySetStatus<<endl;
            oin<<copyDirectoryInfo<<endl;
            
            oin.close();
            
            //for (int counterA = 0; counterA < treatmentNameDisplayCount; counterA++){
            //    for (int counterB = 0; counterB < 17; counterB++) cout<<" "<<arrayTableDisplay [counterA*17+counterB];
            //    cout<<" arrayTableDisplay "<<counterA+1<<endl;
            //}
            
            remove (instructionFIPath.c_str());
            remove (instructionFIPath2.c_str());
            tableViewCall = 1;
            
            if (processMode == 5 || processMode == 7 || processMode == 2 || processMode == 3 || processMode == 8){
                for (int counter1 = 0; counter1 < 10; counter1++){
                    oin.open(instructionCSPath.c_str(), ios::out);
                    
                    if (oin.is_open()){
                        oin<<"Next"<<endl;
                        oin.close();
                        
                        remove(loadingCompletionPath.c_str());
                        break;
                    }
                }
                
                timePointRequest = 1;
            }
        }
        
        if (processProceed == 1 && (processMode == 5 || processMode == 7 || processMode == 2 || processMode == 3 || processMode == 8)) imageProcessTiming = 1;
        else imageProcessTiming = 0;
        
        focusProcessFlag = 0;
    });
}

-(void)focalPlaneDataUpData{
    int countTemp = focalPlaneDataLimit;
    
    int **arrayUpDate = new int *[focalPlaneDataHorizontal];
    for (int counter1 = 0; counter1 < focalPlaneDataHorizontal; counter1++) arrayUpDate [counter1] = new int [countTemp];
    
    for (int counter1 = 0; counter1 < focalPlaneDataHorizontal; counter1++){
        for (int counter2 = 0; counter2 < countTemp; counter2++){
            arrayUpDate [counter1][counter2] = arrayFocalPlaneData [counter1][counter2];
        }
    }
    
    for (int counter1 = 0; counter1 < focalPlaneDataHorizontal; counter1++) delete [] arrayFocalPlaneData [counter1];
    delete [] arrayFocalPlaneData;
    
    arrayFocalPlaneData = new int *[focalPlaneDataHorizontal];
    focalPlaneDataLimit = focalPlaneDataLimit+500;
    
    for (int counter1 = 0; counter1 < focalPlaneDataHorizontal; counter1++) arrayFocalPlaneData [counter1] = new int [focalPlaneDataLimit];
    
    for (int counter1 = 0; counter1 < focalPlaneDataHorizontal; counter1++){
        for (int counter2 = 0; counter2 < focalPlaneDataLimit; counter2++) arrayFocalPlaneData [counter1][counter2] = 0;
    }
    
    for (int counter1 = 0; counter1 < focalPlaneDataHorizontal; counter1++){
        for (int counter2 = 0; counter2 < countTemp; counter2++){
            arrayFocalPlaneData [counter1][counter2] = arrayUpDate [counter1][counter2];
        }
    }
    
    for (int counter1 = 0; counter1 < focalPlaneDataHorizontal; counter1++) delete [] arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)fileDeleteUpDate{
    string *arrayUpDate = new string [fileDeleteCount+10];
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayUpDate [counter1] = arrayFileDelete [counter1];
    
    delete [] arrayFileDelete;
    arrayFileDelete = new string [fileDeleteLimit+500];
    fileDeleteLimit = fileDeleteLimit+500;
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayFileDelete [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToImageProcess object:nil];
}

@end
