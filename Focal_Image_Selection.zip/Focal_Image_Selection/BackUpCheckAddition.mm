//
//  BackUpCheckAddition.m
//  Focal_Image_Selection
//
//  Created by Masahiko Sato on 2019-06-05.
//

#import "BackUpCheckAddition.h"

NSString *notificationToBackUpCheckAddition = @"notificationExecuteBackUpCheckAddition";

@implementation BackUpCheckAddition

-(id)init{
    self = [super init];
    
    if (self != nil){
        timingCount = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToBackUpCheckAddition object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    backUpCheckTimer2 = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(displayData) userInfo:nil repeats:YES];
}

-(void)displayData{
    if (currentPlaneVBackUpCall == 1){
        [currentPlaneNumber setIntegerValue: planeNumberBackUpDisplay+1];
        
        timingCount++;
        
        if (timingCount == 20){
            currentPlaneVBackUpCall = 0;
            timingCount = 0;
        }
    }
}

-(void)dealloc{
    if (backUpCheckTimer2) [backUpCheckTimer2 invalidate];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToBackUpCheckAddition object:nil];
}

@end
