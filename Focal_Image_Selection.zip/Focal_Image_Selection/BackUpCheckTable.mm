//
//  BackUpCheckTable.m
//  Focal_Image_Selection
//
//  Created by Masahiko Sato on 2019-06-03.
//

#import "BackUpCheckTable.h"

NSString *notificationToBackUpCheckTable = @"notificationExecuteBackUpTable";

@implementation BackUpCheckTable

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToBackUpCheckTable object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    [backUpTableViewList setDataSource:self];
    [backUpTableViewList reloadData];
}

-(int)numberOfRowsInTableView:(NSTableView *)aTableView{
    int tableViewContent = backUpDirectoryCount;
    
    return tableViewContent;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    string directoryDisplay = backUpDirectoryArray [rowIndex];
    
    NSAttributedString *attrStr;
    
    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
    [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
    
    if ([[aTableColumn identifier] isEqualToString:@"COL1"]){
        [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(directoryDisplay.c_str()) attributes:attributes];
    }
    else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    
    return attrStr;
}

-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex{
    backUpTableCallCount++;
    backUpTableNewRowHold = rowIndex;
    
    if (backUpTableCallCount == 2) tableRowHoldBackUp = rowIndex;
    else tableRowHoldBackUp = rowIndex;
    
    return YES;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToBackUpCheckTable object:nil];
}

@end
