//
//  BackUpCheckImage.m
//  Focal_Image_Selection
//
//  Created by Masahiko Sato on 2019-06-03.
//

#import "BackUpCheckImage.h"

NSString *notificationToBackUpCheckImage = @"notificationExecuteBackUpImage";

@implementation BackUpCheckImage

-(id)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    
    if (self) {
        mouseDragFlagBackUp = 0;
        
        backUpStackImage = [[NSImage alloc] initWithContentsOfFile:@""];
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToBackUpCheckImage object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    if (imageDataHoldBackUpImageStatus == 1){
        if (backUpImageColorSet == "0"){
            if (photometricBackHold == 1){
                NSBitmapImageRep *bitmapReps;
                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:backUpImageHeight pixelsHigh:backUpImageWidth bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:backUpImageWidth bitsPerPixel:8];
                unsigned char *bitmapData = [bitmapReps bitmapData];
                
                int readDataTemp = 0;
                
                for (int counter2 = 0; counter2 < backUpImageHeight; counter2++){
                    for (int counter3 = 0; counter3 < backUpImageWidth; counter3++){
                        readDataTemp = (int)(arrayImageDataHoldBackUpImage [planeNumberBackUpDisplay*backUpImageHeight+counter2][counter3]*(double)fluorescentEnhanceBackUp);
                        
                        if (readDataTemp > 255) readDataTemp = 255;
                        
                        *bitmapData++ = (unsigned char)readDataTemp;
                    }
                }
                
                backUpStackImage = [[NSImage alloc] initWithSize:NSMakeSize(backUpImageWidth, backUpImageWidth)];
                [backUpStackImage addRepresentation:bitmapReps];
            }
            else if (photometricBackHold == 2){
                NSBitmapImageRep *bitmapReps;
                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:backUpImageHeight pixelsHigh:backUpImageWidth bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:backUpImageWidth*4 bitsPerPixel:32];
                
                unsigned char *bitmapData = [bitmapReps bitmapData];
                
                int readDataTemp = 0;
                
                for (int counter1 = 0; counter1 < backUpImageHeight; counter1++){
                    for (int counter2 = 0; counter2 < backUpImageWidth*3; counter2 = counter2+3){
                        readDataTemp = (int)(arrayImageDataHoldBackUpImage [planeNumberBackUpDisplay*backUpImageHeight+counter1][counter2]*(double)fluorescentEnhanceBackUp);
                        
                        if (readDataTemp > 255) readDataTemp = 255;
                        
                        *bitmapData++ = (unsigned char)readDataTemp;
                        
                        readDataTemp = (int)(arrayImageDataHoldBackUpImage [planeNumberBackUpDisplay*backUpImageHeight+counter1][counter2+1]*(double)fluorescentEnhanceBackUp);
                        
                        if (readDataTemp > 255) readDataTemp = 255;
                        
                        *bitmapData++ = (unsigned char)readDataTemp;
                        
                        readDataTemp = (int)(arrayImageDataHoldBackUpImage [planeNumberBackUpDisplay*backUpImageHeight+counter1][counter2+2]*(double)fluorescentEnhanceBackUp);
                        
                        if (readDataTemp > 255) readDataTemp = 255;
                        
                        *bitmapData++ = (unsigned char)readDataTemp;
                        
                        *bitmapData++ = 0;
                    }
                }
                
                backUpStackImage = [[NSImage alloc] initWithSize:NSMakeSize(backUpImageWidth, backUpImageWidth)];
                [backUpStackImage addRepresentation:bitmapReps];
            }
        }
        else{
            
            NSBitmapImageRep *bitmapReps;
            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:backUpImageHeight pixelsHigh:backUpImageWidth bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:backUpImageWidth*4 bitsPerPixel:32];
            
            NSUInteger zColourAry[3];
            
            int readDataTemp = 0;
            
            for (int counter2 = 0; counter2 < backUpImageHeight; counter2++){
                for (int counter3 = 0; counter3 < backUpImageWidth; counter3++){
                    readDataTemp = arrayImageDataHoldBackUpImage [planeNumberBackUpDisplay*backUpImageHeight+counter2][counter3];
                    
                    if (readDataTemp < 10) readDataTemp = 0;
                    else{
                        
                        readDataTemp = (int)(readDataTemp*fluorescentEnhanceBackUp);
                        
                        if (readDataTemp > 255) readDataTemp = 255;
                    }
                    
                    if (backUpImageColorSet == "1"){
                        zColourAry[0] = 0;
                        zColourAry[1] = 0;
                        zColourAry[2] = (NSUInteger)readDataTemp;
                    }
                    else if (backUpImageColorSet == "2"){
                        zColourAry[0] = 0;
                        zColourAry[1] = (NSUInteger)readDataTemp;
                        zColourAry[2] = 0;
                    }
                    else if (backUpImageColorSet == "3"){
                        zColourAry[0] = (NSUInteger)readDataTemp;
                        zColourAry[1] = (NSUInteger)readDataTemp;
                        zColourAry[2] = 0;
                    }
                    else if (backUpImageColorSet == "4"){
                        zColourAry[0] = (NSUInteger)readDataTemp;
                        zColourAry[1] = 0;
                        zColourAry[2] = 0;
                    }
                    else if (backUpImageColorSet == "5"){
                        zColourAry[0] = (NSUInteger)readDataTemp;
                        zColourAry[1] = 0;
                        zColourAry[2] = (NSUInteger)readDataTemp;
                    }
                    else if (backUpImageColorSet == "6"){
                        zColourAry[0] = 0;
                        zColourAry[1] = (NSUInteger)readDataTemp;
                        zColourAry[2] = (NSUInteger)readDataTemp;
                    }
                    else if (backUpImageColorSet == "7"){
                        zColourAry[0] = (NSUInteger)readDataTemp;
                        zColourAry[1] = (NSUInteger)(readDataTemp*0.647);
                        zColourAry[2] = 0;
                    }
                    else if (backUpImageColorSet == "8"){
                        zColourAry[0] = (NSUInteger)(readDataTemp*0.627);
                        zColourAry[1] = (NSUInteger)(readDataTemp*0.125);
                        zColourAry[2] = (NSUInteger)(readDataTemp*0.941);
                    }
                    else if (backUpImageColorSet == "9"){
                        zColourAry[0] = (NSUInteger)(readDataTemp*0.588);
                        zColourAry[1] = (NSUInteger)(readDataTemp*0.294);
                        zColourAry[2] = 0;
                    }
                    
                    [bitmapReps setPixel:zColourAry atX:counter3 y:counter2];
                }
            }
            
            backUpStackImage = [[NSImage alloc] initWithSize:NSMakeSize(backUpImageWidth, backUpImageWidth)];
            [backUpStackImage addRepresentation:bitmapReps];
        }
        
        if (imageFirstLoadFlagBackUp == 0){
            xPositionBackUp = 0;
            yPositionBackUp = 0;
            xPositionAdjustBackUp = 0;
            yPositionAdjustBackUp = 0;
            magnificationBackUpDisplay = 10;
            imageFirstLoadFlagBackUp = 1;
        }
        
        //-----Window size and Position re-adjust-----
        int vertical = 451+78;
        int horizontal = 451;
        
        windowWidthBackUpDisplay = backUpImageWidth/(double)horizontal;
        windowHeightBackUpDisplay = backUpImageWidth/(double)(vertical-78);
        
        xPositionAdjustBackUp = (backUpImageWidth-backUpImageHeight/(double)(magnificationBackUpDisplay*0.1))/(double)2;
        yPositionAdjustBackUp = (backUpImageWidth-backUpImageHeight/(double)(magnificationBackUpDisplay*0.1))/(double)2;
    }
    else{
        
        NSString *cellImageNSstring = [NSString stringWithCString:backgroundImagePath.c_str() encoding: NSASCIIStringEncoding];
        backUpStackImage = [[NSImage alloc] initWithContentsOfFile:cellImageNSstring];
    }
    
    [self setNeedsDisplay:YES];
}

//----First Responder----
-(BOOL)acceptsFirstResponder{
    return YES;
}

-(void)mouseDown:(NSEvent *)event{
    if (imageDataHoldBackUpImageStatus == 1){
        NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
        xPointDownBackUp = clickPoint.x;
        yPointDownBackUp = clickPoint.y;
        [self setNeedsDisplay:YES];
    }
}

-(void)mouseUp:(NSEvent *)event{
    if (imageDataHoldBackUpImageStatus == 1){
        xPositionBackUp = xPositionBackUp+xPositionMoveBackUp;
        yPositionBackUp = yPositionBackUp+yPositionMoveBackUp;
        xPositionMoveBackUp = 0;
        yPositionMoveBackUp = 0;
        mouseDragFlagBackUp = 0;
        [self setNeedsDisplay:YES];
    }
}

- (void)mouseDragged:(NSEvent *)event{
    if (imageDataHoldBackUpImageStatus == 1){
        NSPoint clickPoint= [self convertPoint:[event locationInWindow] fromView:nil];
        xPointDragBackUp = clickPoint.x;
        yPointDragBackUp = clickPoint.y;
        xPositionMoveBackUp = (xPointDownBackUp-xPointDragBackUp)*windowWidthBackUpDisplay/(double)(magnificationBackUpDisplay*0.1);
        yPositionMoveBackUp = (yPointDownBackUp-yPointDragBackUp)*windowHeightBackUpDisplay/(double)(magnificationBackUpDisplay*0.1);
        
        mouseDragFlagBackUp = 1;
        [self setNeedsDisplay:YES];
    }
}

-(void)keyDown:(NSEvent *)event{
    if (imageDataHoldBackUpImageStatus == 1){
        int keyCode = [event keyCode];
        int proceedFlag = 0;
        
        if (keyCode == 124){
            proceedFlag = 1;
            planeNumberBackUpDisplay++;
            
            if (planeNumberBackUpDisplay >= backUpImagePlane) planeNumberBackUpDisplay--;
            
            currentPlaneVBackUpCall = 1;
        }
        
        //-----Magnification Reduction-----
        if (keyCode == 123){
            proceedFlag = 1;
            planeNumberBackUpDisplay--;
            
            if (planeNumberBackUpDisplay < 0) planeNumberBackUpDisplay = 0;
            
            currentPlaneVBackUpCall = 1;
        }
        
        //-----Magnification Magnify-----
        if (keyCode == 125){
            if (magnificationBackUpDisplay >= 10 && magnificationBackUpDisplay <= 350){
                proceedFlag = 1;
                if (magnificationBackUpDisplay-10 < 10) magnificationBackUpDisplay = 10;
                else magnificationBackUpDisplay = magnificationBackUpDisplay-10;
                
                xPositionAdjustBackUp = -1*(backUpImageHeight/(double)(magnificationBackUpDisplay*0.1)-backUpImageHeight)/(double)2;
                yPositionAdjustBackUp = -1*(backUpImageHeight/(double)(magnificationBackUpDisplay*0.1)-backUpImageHeight)/(double)2;
            }
        }
        
        //-----Magnification Reduction-----
        if (keyCode == 126){
            if (magnificationBackUpDisplay >= 10 && magnificationBackUpDisplay <= 498){
                proceedFlag = 1;
                
                if (magnificationBackUpDisplay+10 > 498) magnificationBackUpDisplay = 498;
                else magnificationBackUpDisplay = magnificationBackUpDisplay+10;
                
                xPositionAdjustBackUp = (backUpImageHeight-backUpImageHeight/(double)(magnificationBackUpDisplay*0.1))/(double)2;
                yPositionAdjustBackUp = (backUpImageHeight-backUpImageHeight/(double)(magnificationBackUpDisplay*0.1))/(double)2;
            }
        }
        
        if (proceedFlag == 1){
            if (backUpImageColorSet == "0"){
                if (photometricBackHold == 1){
                    NSBitmapImageRep *bitmapReps;
                    bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:backUpImageHeight pixelsHigh:backUpImageWidth bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:backUpImageWidth bitsPerPixel:8];
                    unsigned char *bitmapData = [bitmapReps bitmapData];
                    
                    int readDataTemp = 0;
                    
                    for (int counter2 = 0; counter2 < backUpImageHeight; counter2++){
                        for (int counter3 = 0; counter3 < backUpImageWidth; counter3++){
                            readDataTemp = (int)(arrayImageDataHoldBackUpImage [planeNumberBackUpDisplay*backUpImageHeight+counter2][counter3]*(double)fluorescentEnhanceBackUp);
                            
                            if (readDataTemp > 255) readDataTemp = 255;
                            
                            *bitmapData++ = (unsigned char)readDataTemp;
                        }
                    }
                    
                    backUpStackImage = [[NSImage alloc] initWithSize:NSMakeSize(backUpImageWidth, backUpImageWidth)];
                    [backUpStackImage addRepresentation:bitmapReps];
                }
                else if (photometricBackHold == 2){
                    NSBitmapImageRep *bitmapReps;
                    bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:backUpImageHeight pixelsHigh:backUpImageWidth bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:backUpImageWidth*4 bitsPerPixel:32];
                    
                    unsigned char *bitmapData = [bitmapReps bitmapData];
                    
                    int readDataTemp = 0;
                    
                    for (int counter1 = 0; counter1 < backUpImageHeight; counter1++){
                        for (int counter2 = 0; counter2 < backUpImageWidth*3; counter2 = counter2+3){
                            readDataTemp = (int)(arrayImageDataHoldBackUpImage [planeNumberBackUpDisplay*backUpImageHeight+counter1][counter2]*(double)fluorescentEnhanceBackUp);
                            
                            if (readDataTemp > 255) readDataTemp = 255;
                            
                            *bitmapData++ = (unsigned char)readDataTemp;
                            
                            readDataTemp = (int)(arrayImageDataHoldBackUpImage [planeNumberBackUpDisplay*backUpImageHeight+counter1][counter2+1]*(double)fluorescentEnhanceBackUp);
                            
                            if (readDataTemp > 255) readDataTemp = 255;
                            
                            *bitmapData++ = (unsigned char)readDataTemp;
                            
                            readDataTemp = (int)(arrayImageDataHoldBackUpImage [planeNumberBackUpDisplay*backUpImageHeight+counter1][counter2+2]*(double)fluorescentEnhanceBackUp);
                            
                            if (readDataTemp > 255) readDataTemp = 255;
                            
                            *bitmapData++ = (unsigned char)readDataTemp;
                            
                            *bitmapData++ = 0;
                        }
                    }
                    
                    backUpStackImage = [[NSImage alloc] initWithSize:NSMakeSize(backUpImageWidth, backUpImageWidth)];
                    [backUpStackImage addRepresentation:bitmapReps];
                }
            }
            else{
                
                NSBitmapImageRep *bitmapReps;
                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:backUpImageHeight pixelsHigh:backUpImageWidth bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:backUpImageWidth*4 bitsPerPixel:32];
                
                NSUInteger zColourAry[3];
                
                int readDataTemp = 0;
                
                for (int counter2 = 0; counter2 < backUpImageHeight; counter2++){
                    for (int counter3 = 0; counter3 < backUpImageWidth; counter3++){
                        readDataTemp = arrayImageDataHoldBackUpImage [planeNumberBackUpDisplay*backUpImageHeight+counter2][counter3];
                        
                        if (readDataTemp < 10) readDataTemp = 0;
                        else{
                            
                            readDataTemp = (int)(readDataTemp*fluorescentEnhanceBackUp);
                            
                            if (readDataTemp > 255) readDataTemp = 255;
                        }
                        
                        if (backUpImageColorSet == "1"){
                            zColourAry[0] = 0;
                            zColourAry[1] = 0;
                            zColourAry[2] = (NSUInteger)readDataTemp;
                        }
                        else if (backUpImageColorSet == "2"){
                            zColourAry[0] = 0;
                            zColourAry[1] = (NSUInteger)readDataTemp;
                            zColourAry[2] = 0;
                        }
                        else if (backUpImageColorSet == "3"){
                            zColourAry[0] = (NSUInteger)readDataTemp;
                            zColourAry[1] = (NSUInteger)readDataTemp;
                            zColourAry[2] = 0;
                        }
                        else if (backUpImageColorSet == "4"){
                            zColourAry[0] = (NSUInteger)readDataTemp;
                            zColourAry[1] = 0;
                            zColourAry[2] = 0;
                        }
                        else if (backUpImageColorSet == "5"){
                            zColourAry[0] = (NSUInteger)readDataTemp;
                            zColourAry[1] = 0;
                            zColourAry[2] = (NSUInteger)readDataTemp;
                        }
                        else if (backUpImageColorSet == "6"){
                            zColourAry[0] = 0;
                            zColourAry[1] = (NSUInteger)readDataTemp;
                            zColourAry[2] = (NSUInteger)readDataTemp;
                        }
                        else if (backUpImageColorSet == "7"){
                            zColourAry[0] = (NSUInteger)readDataTemp;
                            zColourAry[1] = (NSUInteger)(readDataTemp*0.647);
                            zColourAry[2] = 0;
                        }
                        else if (backUpImageColorSet == "8"){
                            zColourAry[0] = (NSUInteger)(readDataTemp*0.627);
                            zColourAry[1] = (NSUInteger)(readDataTemp*0.125);
                            zColourAry[2] = (NSUInteger)(readDataTemp*0.941);
                        }
                        else if (backUpImageColorSet == "9"){
                            zColourAry[0] = (NSUInteger)(readDataTemp*0.588);
                            zColourAry[1] = (NSUInteger)(readDataTemp*0.294);
                            zColourAry[2] = 0;
                        }
                        
                        [bitmapReps setPixel:zColourAry atX:counter3 y:counter2];
                    }
                }
                
                backUpStackImage = [[NSImage alloc] initWithSize:NSMakeSize(backUpImageWidth, backUpImageWidth)];
                [backUpStackImage addRepresentation:bitmapReps];
            }
            
            [self setNeedsDisplay:YES];
        }
    }
}

-(void)drawRect:(NSRect)rect {
    NSRect srcRect;
    srcRect.origin.x = xPositionBackUp+xPositionAdjustBackUp+xPositionMoveBackUp;
    srcRect.origin.y = yPositionBackUp+yPositionAdjustBackUp+yPositionMoveBackUp;
    srcRect.size.width = backUpImageHeight/(double)(magnificationBackUpDisplay*0.1);
    srcRect.size.height = backUpImageHeight/(double)(magnificationBackUpDisplay*0.1);
    
    [backUpStackImage drawInRect:rect fromRect:srcRect operation:NSCompositingOperationCopy fraction:1.0f];
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToBackUpCheckImage object:nil];
}

@end
