//
//  main.m
//  Focal_Image_Selection
//
//  Created by Masahiko Sato on 13/03/14.
//  Copyright Masahiko Sato 2014. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[]){
    return NSApplicationMain(argc, (const char **) argv);
}
