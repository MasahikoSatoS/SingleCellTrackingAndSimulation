//
//  ZImage.h
//  Focal_Image_Selection
//
//  Created by Masahiko Sato on 3/14/2014.
//  Copyright Masahiko Sato 2014 All rights reserved.
//
//

#ifndef ZIMAGE_H
#define ZIMAGE_H
#import "Controller.h"
#endif

@interface ZImage : NSView {
    double xPointDownDisplay; //Display operation
    double yPointDownDisplay; //Display operation
    double xPositionMoveDisplay; //Display operation
    double yPositionMoveDisplay; //Display operation
    double xPointDragDisplay; //Display operation
    double yPointDragDisplay; //Display operation
    double xPositionDisplay; //Display operation
    double yPositionDisplay; //Display operation
    double xPositionAdjustDisplay; //Display operation
    double yPositionAdjustDisplay; //Display operation
    int mouseDragFlag; //Display operation
    
    IBOutlet NSImage *zStackImage;
}

-(void)mouseDown:(NSEvent *)event;
-(void)mouseUp:(NSEvent *)event;
-(void)mouseDragged:(NSEvent *)event;
-(void)keyDown:(NSEvent *)event;
-(BOOL)acceptsFirstResponder;
-(void)dealloc;

@end


