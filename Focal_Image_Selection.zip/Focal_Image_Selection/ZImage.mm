//
//  ZImage.m
//  Focal_Image_Selection
//
//  Created by Masahiko Sato on 3/14/2014.
//
//

#import "ZImage.h"

NSString *notificationToImageDisplay = @"notificationToImageDisplay";

@implementation ZImage

-(id)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    
    if (self) {
        mouseDragFlag = 0;
        
        zStackImage = [[NSImage alloc] initWithContentsOfFile:@""];
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToImageDisplay object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    if (imageDataHoldZImageStatus == 1){
        if (zImageColorSet == "0" || (zImageColorSet != "0" && photoMetricHold == 2)){
            if (photoMetricHold == 1){
                NSBitmapImageRep *bitmapReps;
                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:zImageHeight pixelsHigh:zImageWidth bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:zImageWidth bitsPerPixel:8];
                unsigned char *bitmapData = [bitmapReps bitmapData];
                
                int readDataTemp = 0;
                
                for (int counter2 = 0; counter2 < zImageHeight; counter2++){
                    for (int counter3 = 0; counter3 < zImageWidth; counter3++){
                        readDataTemp = (int)(arrayImageDataHoldZImage [planeNumberDisplay*zImageHeight+counter2][counter3]*(double)fluorescentEnhance);
                        
                        if (readDataTemp > 255) readDataTemp = 255;
                        
                        *bitmapData++ = (unsigned char)readDataTemp;
                    }
                }
                
                int displayDimension = 0;
                
                if (zImageWidth > zImageHeight) displayDimension = zImageHeight;
                else displayDimension = zImageWidth;
                
                zStackImage = [[NSImage alloc] initWithSize:NSMakeSize(displayDimension, displayDimension)];
                [zStackImage addRepresentation:bitmapReps];
            }
            else if (photoMetricHold == 2){
                NSBitmapImageRep *bitmapReps;
                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:zImageHeight pixelsHigh:zImageWidth bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:zImageWidth*4 bitsPerPixel:32];
                
                unsigned char *bitmapData = [bitmapReps bitmapData];
                
                int readDataTemp = 0;
                
                for (int counter1 = 0; counter1 < zImageHeight; counter1++){
                    for (int counter2 = 0; counter2 < zImageWidth*3; counter2 = counter2+3){
                        readDataTemp = (int)(arrayImageDataHoldZImage [planeNumberDisplay*zImageHeight+counter1][counter2]*(double)fluorescentEnhance);
                        
                        if (readDataTemp > 255) readDataTemp = 255;
                        
                        *bitmapData++ = (unsigned char)readDataTemp;
                        
                        readDataTemp = (int)(arrayImageDataHoldZImage [planeNumberDisplay*zImageHeight+counter1][counter2+1]*(double)fluorescentEnhance);
                        
                        if (readDataTemp > 255) readDataTemp = 255;
                        
                        *bitmapData++ = (unsigned char)readDataTemp;
                        
                        readDataTemp = (int)(arrayImageDataHoldZImage [planeNumberDisplay*zImageHeight+counter1][counter2+2]*(double)fluorescentEnhance);
                        
                        if (readDataTemp > 255) readDataTemp = 255;
                        
                        *bitmapData++ = (unsigned char)readDataTemp;
                        
                        *bitmapData++ = 0;
                    }
                }
                
                int displayDimension = 0;
                
                if (zImageWidth > zImageHeight) displayDimension = zImageHeight;
                else displayDimension = zImageWidth;
                
                zStackImage = [[NSImage alloc] initWithSize:NSMakeSize(displayDimension, displayDimension)];
                [zStackImage addRepresentation:bitmapReps];
            }
        }
        else{
            
            NSBitmapImageRep *bitmapReps;
            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:zImageHeight pixelsHigh:zImageWidth bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:zImageWidth*4 bitsPerPixel:32];
            
            NSUInteger zColourAry[3];
            
            int readDataTemp = 0;
            
            for (int counter2 = 0; counter2 < zImageHeight; counter2++){
                for (int counter3 = 0; counter3 < zImageWidth; counter3++){
                    readDataTemp = arrayImageDataHoldZImage [planeNumberDisplay*zImageHeight+counter2][counter3];
                    
                    if (readDataTemp < 10) readDataTemp = 0;
                    else{
                        
                        readDataTemp = (int)(readDataTemp*fluorescentEnhance);
                        
                        if (readDataTemp > 255) readDataTemp = 255;
                    }
                    
                    if (zImageColorSet == "1"){
                        zColourAry[0] = 0;
                        zColourAry[1] = 0;
                        zColourAry[2] = (NSUInteger)readDataTemp;
                    }
                    else if (zImageColorSet == "2"){
                        zColourAry[0] = 0;
                        zColourAry[1] = (NSUInteger)readDataTemp;
                        zColourAry[2] = 0;
                    }
                    else if (zImageColorSet == "3"){
                        zColourAry[0] = (NSUInteger)readDataTemp;
                        zColourAry[1] = (NSUInteger)readDataTemp;
                        zColourAry[2] = 0;
                    }
                    else if (zImageColorSet == "4"){
                        zColourAry[0] = (NSUInteger)readDataTemp;
                        zColourAry[1] = 0;
                        zColourAry[2] = 0;
                    }
                    else if (zImageColorSet == "5"){
                        zColourAry[0] = (NSUInteger)readDataTemp;
                        zColourAry[1] = 0;
                        zColourAry[2] = (NSUInteger)readDataTemp;
                    }
                    else if (zImageColorSet == "6"){
                        zColourAry[0] = 0;
                        zColourAry[1] = (NSUInteger)readDataTemp;
                        zColourAry[2] = (NSUInteger)readDataTemp;
                    }
                    else if (zImageColorSet == "7"){
                        zColourAry[0] = (NSUInteger)readDataTemp;
                        zColourAry[1] = (NSUInteger)(readDataTemp*0.647);
                        zColourAry[2] = 0;
                    }
                    else if (zImageColorSet == "8"){
                        zColourAry[0] = (NSUInteger)(readDataTemp*0.627);
                        zColourAry[1] = (NSUInteger)(readDataTemp*0.125);
                        zColourAry[2] = (NSUInteger)(readDataTemp*0.941);
                    }
                    else if (zImageColorSet == "9"){
                        zColourAry[0] = (NSUInteger)(readDataTemp*0.529);
                        zColourAry[1] = (NSUInteger)(readDataTemp*0.808);
                        zColourAry[2] = (NSUInteger)(readDataTemp*0.922);
                    }
                    
                    [bitmapReps setPixel:zColourAry atX:counter3 y:counter2];
                }
            }
            
            int displayDimension = 0;
            
            if (zImageWidth > zImageHeight) displayDimension = zImageHeight;
            else displayDimension = zImageWidth;
            
            zStackImage = [[NSImage alloc] initWithSize:NSMakeSize(displayDimension, displayDimension)];
            [zStackImage addRepresentation:bitmapReps];
        }
        
        if (imageFirstLoadFlagDisplay == 0){
            xPositionDisplay = 0;
            yPositionDisplay = 0;
            xPositionAdjustDisplay = 0;
            yPositionAdjustDisplay = 0;
            magnificationDisplay = 10;
            imageFirstLoadFlagDisplay = 1;
        }
        
        //-----Window size and Position re-adjust-----
        int vertical = 190+78;
        int horizontal = 190;
        
        windowWidthDisplay = zImageWidth/(double)horizontal;
        windowHeightDisplay = zImageWidth/(double)(vertical-78);
        
        xPositionAdjustDisplay = (zImageWidth-zImageHeight/(double)(magnificationDisplay*0.1))/(double)2;
        yPositionAdjustDisplay = (zImageWidth-zImageHeight/(double)(magnificationDisplay*0.1))/(double)2;
    }
    else{
        
        NSString *cellImageNSstring = [NSString stringWithCString:backgroundImagePath.c_str() encoding: NSASCIIStringEncoding];
        zStackImage = [[NSImage alloc] initWithContentsOfFile:cellImageNSstring];
    }
    
    [self setNeedsDisplay:YES];
}

//----First Responder----
-(BOOL)acceptsFirstResponder{
    return YES;
}

-(void)mouseDown:(NSEvent *)event{
    if (imageDataHoldZImageStatus == 1){
        NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
        xPointDownDisplay = clickPoint.x;
        yPointDownDisplay = clickPoint.y;
        [self setNeedsDisplay:YES];
    }
}

-(void)mouseUp:(NSEvent *)event{
    if (imageDataHoldZImageStatus == 1){
        xPositionDisplay = xPositionDisplay+xPositionMoveDisplay;
        yPositionDisplay = yPositionDisplay+yPositionMoveDisplay;
        xPositionMoveDisplay = 0;
        yPositionMoveDisplay = 0;
        mouseDragFlag = 0;
        [self setNeedsDisplay:YES];
    }
}

- (void)mouseDragged:(NSEvent *)event{
    if (imageDataHoldZImageStatus == 1){
        NSPoint clickPoint= [self convertPoint:[event locationInWindow] fromView:nil];
        xPointDragDisplay = clickPoint.x;
        yPointDragDisplay = clickPoint.y;
        xPositionMoveDisplay = (xPointDownDisplay-xPointDragDisplay)*windowWidthDisplay/(double)(magnificationDisplay*0.1);
        yPositionMoveDisplay = (yPointDownDisplay-yPointDragDisplay)*windowHeightDisplay/(double)(magnificationDisplay*0.1);
        
        mouseDragFlag = 1;
        [self setNeedsDisplay:YES];
    }
}

-(void)keyDown:(NSEvent *)event{
    if (imageDataHoldZImageStatus == 1){
        int keyCode = [event keyCode];
        int proceedFlag = 0;
        
        if (keyCode == 124){
            proceedFlag = 1;
            planeNumberDisplay++;
            
            if (planeNumberDisplay >= zImagePlane) planeNumberDisplay--;
            
            currentPlaneDisplayCall = 1;
        }
        
        //-----Magnification Reduction-----
        if (keyCode == 123){
            proceedFlag = 1;
            planeNumberDisplay--;
            
            if (planeNumberDisplay < 0) planeNumberDisplay = 0;
            
            currentPlaneDisplayCall = 1;
        }
        
        //-----Magnification Magnify-----
        if (keyCode == 125){
            if (magnificationDisplay >= 10 && magnificationDisplay <= 350){
                proceedFlag = 1;
                if (magnificationDisplay-10 < 10) magnificationDisplay = 10;
                else magnificationDisplay = magnificationDisplay-10;
                
                xPositionAdjustDisplay = -1*(zImageHeight/(double)(magnificationDisplay*0.1)-zImageHeight)/(double)2;
                yPositionAdjustDisplay = -1*(zImageHeight/(double)(magnificationDisplay*0.1)-zImageHeight)/(double)2;
            }
        }
        
        //-----Magnification Reduction-----
        if (keyCode == 126){
            if (magnificationDisplay >= 10 && magnificationDisplay <= 498){
                proceedFlag = 1;
                
                if (magnificationDisplay+10 > 498) magnificationDisplay = 498;
                else magnificationDisplay = magnificationDisplay+10;
                
                xPositionAdjustDisplay = (zImageHeight-zImageHeight/(double)(magnificationDisplay*0.1))/(double)2;
                yPositionAdjustDisplay = (zImageHeight-zImageHeight/(double)(magnificationDisplay*0.1))/(double)2;
            }
        }
        
        if (proceedFlag == 1){
            if (zImageColorSet == "0" || (zImageColorSet != "0" && photoMetricHold == 2)){
                if (photoMetricHold == 1){
                    NSBitmapImageRep *bitmapReps;
                    bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:zImageHeight pixelsHigh:zImageWidth bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:zImageWidth bitsPerPixel:8];
                    unsigned char *bitmapData = [bitmapReps bitmapData];
                    
                    int readDataTemp = 0;
                    
                    for (int counter2 = 0; counter2 < zImageHeight; counter2++){
                        for (int counter3 = 0; counter3 < zImageWidth; counter3++){
                            readDataTemp = (int)(arrayImageDataHoldZImage [planeNumberDisplay*zImageHeight+counter2][counter3]*(double)fluorescentEnhance);
                            
                            if (readDataTemp > 255) readDataTemp = 255;
                            
                            *bitmapData++ = (unsigned char)readDataTemp;
                        }
                    }
                    
                    int displayDimension = 0;
                    
                    if (zImageWidth > zImageHeight) displayDimension = zImageHeight;
                    else displayDimension = zImageWidth;
                    
                    zStackImage = [[NSImage alloc] initWithSize:NSMakeSize(displayDimension, displayDimension)];
                    [zStackImage addRepresentation:bitmapReps];
                }
                else if (photoMetricHold == 2){
                    NSBitmapImageRep *bitmapReps;
                    bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:zImageHeight pixelsHigh:zImageWidth bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:zImageWidth*4 bitsPerPixel:32];
                    
                    unsigned char *bitmapData = [bitmapReps bitmapData];
                    
                    int readDataTemp = 0;
                    
                    for (int counter1 = 0; counter1 < zImageHeight; counter1++){
                        for (int counter2 = 0; counter2 < zImageWidth*3; counter2 = counter2+3){
                            readDataTemp = (int)(arrayImageDataHoldZImage [planeNumberDisplay*zImageHeight+counter1][counter2]*(double)fluorescentEnhance);
                            
                            if (readDataTemp > 255) readDataTemp = 255;
                            
                            *bitmapData++ = (unsigned char)readDataTemp;
                            
                            readDataTemp = (int)(arrayImageDataHoldZImage [planeNumberDisplay*zImageHeight+counter1][counter2+1]*(double)fluorescentEnhance);
                            
                            if (readDataTemp > 255) readDataTemp = 255;
                            
                            *bitmapData++ = (unsigned char)readDataTemp;
                            
                            readDataTemp = (int)(arrayImageDataHoldZImage [planeNumberDisplay*zImageHeight+counter1][counter2+2]*(double)fluorescentEnhance);
                            
                            if (readDataTemp > 255) readDataTemp = 255;
                            
                            *bitmapData++ = (unsigned char)readDataTemp;
                            
                            *bitmapData++ = 0;
                        }
                    }
                    
                    int displayDimension = 0;
                    
                    if (zImageWidth > zImageHeight) displayDimension = zImageHeight;
                    else displayDimension = zImageWidth;
                    
                    zStackImage = [[NSImage alloc] initWithSize:NSMakeSize(displayDimension, displayDimension)];
                    [zStackImage addRepresentation:bitmapReps];
                }
            }
            else{
                
                NSBitmapImageRep *bitmapReps;
                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:zImageHeight pixelsHigh:zImageWidth bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:zImageWidth*4 bitsPerPixel:32];
                
                NSUInteger zColourAry[3];
                
                int readDataTemp = 0;
                
                for (int counter2 = 0; counter2 < zImageHeight; counter2++){
                    for (int counter3 = 0; counter3 < zImageWidth; counter3++){
                        readDataTemp = arrayImageDataHoldZImage [planeNumberDisplay*zImageHeight+counter2][counter3];
                        
                        if (readDataTemp < 10) readDataTemp = 0;
                        else{
                            
                            readDataTemp = (int)(readDataTemp*fluorescentEnhance);
                            
                            if (readDataTemp > 255) readDataTemp = 255;
                        }
                        
                        if (zImageColorSet == "1"){
                            zColourAry[0] = 0;
                            zColourAry[1] = 0;
                            zColourAry[2] = (NSUInteger)readDataTemp;
                        }
                        else if (zImageColorSet == "2"){
                            zColourAry[0] = 0;
                            zColourAry[1] = (NSUInteger)readDataTemp;
                            zColourAry[2] = 0;
                        }
                        else if (zImageColorSet == "3"){
                            zColourAry[0] = (NSUInteger)readDataTemp;
                            zColourAry[1] = (NSUInteger)readDataTemp;
                            zColourAry[2] = 0;
                        }
                        else if (zImageColorSet == "4"){
                            zColourAry[0] = (NSUInteger)readDataTemp;
                            zColourAry[1] = 0;
                            zColourAry[2] = 0;
                        }
                        else if (zImageColorSet == "5"){
                            zColourAry[0] = (NSUInteger)readDataTemp;
                            zColourAry[1] = 0;
                            zColourAry[2] = (NSUInteger)readDataTemp;
                        }
                        else if (zImageColorSet == "6"){
                            zColourAry[0] = 0;
                            zColourAry[1] = (NSUInteger)readDataTemp;
                            zColourAry[2] = (NSUInteger)readDataTemp;
                        }
                        else if (zImageColorSet == "7"){
                            zColourAry[0] = (NSUInteger)readDataTemp;
                            zColourAry[1] = (NSUInteger)(readDataTemp*0.647);
                            zColourAry[2] = 0;
                        }
                        else if (zImageColorSet == "8"){
                            zColourAry[0] = (NSUInteger)(readDataTemp*0.627);
                            zColourAry[1] = (NSUInteger)(readDataTemp*0.125);
                            zColourAry[2] = (NSUInteger)(readDataTemp*0.941);
                        }
                        else if (zImageColorSet == "9"){
                            zColourAry[0] = (NSUInteger)(readDataTemp*0.529);
                            zColourAry[1] = (NSUInteger)(readDataTemp*0.808);
                            zColourAry[2] = (NSUInteger)(readDataTemp*0.922);
                        }
                        
                        [bitmapReps setPixel:zColourAry atX:counter3 y:counter2];
                    }
                }
                
                int displayDimension = 0;
                
                if (zImageWidth > zImageHeight) displayDimension = zImageHeight;
                else displayDimension = zImageWidth;
                
                zStackImage = [[NSImage alloc] initWithSize:NSMakeSize(displayDimension, displayDimension)];
                [zStackImage addRepresentation:bitmapReps];
            }
            
            [self setNeedsDisplay:YES];
        }
    }
}

-(void)drawRect:(NSRect)rect {
    NSRect srcRect;
    srcRect.origin.x = xPositionDisplay+xPositionAdjustDisplay+xPositionMoveDisplay;
    srcRect.origin.y = yPositionDisplay+yPositionAdjustDisplay+yPositionMoveDisplay;
    srcRect.size.width = zImageHeight/(double)(magnificationDisplay*0.1);
    srcRect.size.height = zImageHeight/(double)(magnificationDisplay*0.1);
    
    [zStackImage drawInRect:rect fromRect:srcRect operation:NSCompositingOperationCopy fraction:1.0f];
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToImageDisplay object:nil];
}

@end
