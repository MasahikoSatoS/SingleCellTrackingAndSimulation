//
//  BackUpCheckController.m
//  Focal_Image_Selection
//
//  Created by Masahiko Sato on 2019-06-03.
//

#import "BackUpCheckController.h"

NSString *notificationToBackUpCheckControl = @"notificationExecuteBackUpCheckControl";

@implementation BackUpCheckController

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToBackUpCheckControl object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    backUpCheckWindowController = [[NSWindowController alloc] initWithWindowNibName:@"BackUpCheck"];
    [backUpCheckWindowController showWindow:self];
    
    bodyNameBack = "nil";
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackUpCheckImage object:self];
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackUpCheckTable object:self];
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackUpCheckAddition object:self];
}

-(void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [backUpCheckWindow frame];
    CGFloat windowHeight = windowSize.size.height;
    
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [backUpCheckWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    [listBrowser setTarget:self];
    [listBrowser setDoubleAction:@selector(browserDoubleClick:)];
    [listBrowser setAction:@selector(browserCellSelected:)];
    [listBrowser setSendsActionOnArrowKeys:YES];
}

-(int)browser:(NSBrowser *)sender numberOfRowsInColumn:(int)column{
    directoryInfoCount = 0;
    
    if (column == 0){
        string displayData3;
        int sequentialCount = 1;
        
        for (int counter1 = 0; counter1 < backUpFolderNoUpDateCount; counter1++){
            displayData3 = backUpFolderNoUpDateArray [counter1].substr(backUpFolderNoUpDateArray [counter1].find(bodyNameBack+"-1")+bodyNameBack.length()+2);
            
            if (displayData3.length() == 1) displayData3 = "000"+displayData3;
            else if (displayData3.length() == 2) displayData3 = "00"+displayData3;
            else if (displayData3.length() == 3) displayData3 = "0"+displayData3;
            
            if (directoryInfoCount+10 > directoryInfoLimit) [self directoryInfoDataUpDate];
            
            arrayDirectoryInfo [directoryInfoCount] = to_string(sequentialCount)+": "+displayData3, directoryInfoCount++;
            sequentialCount++;
        }
    }
    
    if (column == 1){
        NSString *path;
        path = [sender path];
        string imageNameTemp = [path UTF8String];
        
        imageNameTemp = imageNameTemp.substr(imageNameTemp.find(": ")+2);
        
        string targetDirectory = "nil";
        
        for (int counter1 = 0; counter1 < backUpFolderNoUpDateCount; counter1++){
            if ((int)backUpFolderNoUpDateArray [counter1].find(bodyNameBack+"-1"+imageNameTemp) != -1){
                targetDirectory = backUpFolderNoUpDateArray [counter1];
                break;
            }
        }
        
        if (targetDirectory != "nil"){
            string entry;
            
            DIR *dir;
            struct dirent *dent;
            
            dir = opendir(targetDirectory.c_str());
            
            if (dir != NULL){
                while((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store" && ((int)entry.find(".TIFF") != -1 || (int)entry.find(".Tiff") != -1 || (int)entry.find(".tiff") != -1 || (int)entry.find(".TIF") != -1 || (int)entry.find(".Tif") != -1 || (int)entry.find(".tif") != -1)){
                        if (backUpFileCount+10 > backUpFileLimit) [self backUpFileDateUpDate];
                        
                        backUpFileArray [backUpFileCount] = targetDirectory+"/"+entry, backUpFileCount++;
                        
                        if (directoryInfoCount+10 > directoryInfoLimit) [self directoryInfoDataUpDate];
                        
                        arrayDirectoryInfo [directoryInfoCount] = entry, directoryInfoCount++;
                    }
                }
                
                closedir(dir);
            }
        }
        
        //----Directory Sort-----
        NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
        
        for (int counter1 = 0; counter1 < directoryInfoCount; counter1++){
            [unsortedArray addObject:@(arrayDirectoryInfo [counter1].c_str())];
        }
        
        [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
        
        for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
            arrayDirectoryInfo [counter1] = [unsortedArray [counter1] UTF8String];
        }
    }
    
    return directoryInfoCount;
}

-(void)browser:(NSBrowser *)sender willDisplayCell:(id)cell atRow:(int)row column:(int)column{
    if (column == 0){
        string folderName = arrayDirectoryInfo [row];
        [cell setStringValue: @(folderName.c_str())];
        [cell setLoaded:YES];
    }
    if (column == 1){
        string folderName = arrayDirectoryInfo [row];
        [cell setStringValue: @(folderName.c_str())];
        [cell setLeaf:YES];
    }
}

-(void)browserCellSelected:(id)sender{
    NSString *nodePath = [listBrowser path];
    string nodePathString = [nodePath UTF8String];
    
    if (nodePathString != ""){
        string fileNameExtraction = nodePathString.substr(nodePathString.find("/")+1);
        string fileNameHold = fileNameExtraction.substr(fileNameExtraction.find("/")+1);
        
        [backUpFileNameDisplay setStringValue:@(fileNameHold .c_str())];
    }
}

-(IBAction)browserDoubleClick:(id)browser{
    NSString *nodePath = [browser path];
    string nodePathString = [nodePath UTF8String];
    
    if (nodePathString != ""){
        nodePathString = nodePathString.substr(1);
        
        if ((int)nodePathString.find("/") != -1){
            ifstream fin;
            
            string fileNameString = nodePathString.substr(nodePathString.find("/")+1);
            string imageDisplayPath;
            
            for (int counter1 = 0; counter1 < backUpFileCount; counter1++){
                if ((int)backUpFileArray [counter1].find(fileNameString) != -1){
                    imageDisplayPath = backUpFileArray [counter1];
                    break;
                }
            }
            
            fin.open(imageDisplayPath.c_str(),ios::in);
            
            if (fin.is_open()){
                fin.close();
                
                backUpImageColorSet = "0";
                
                if ((int)fileNameString.find("_1_") != -1){
                    backUpImageColorSet = "1";
                }
                else if ((int)fileNameString.find("_2_") != -1){
                    backUpImageColorSet = "2";
                }
                else if ((int)fileNameString.find("_3_") != -1){
                    backUpImageColorSet = "3";
                }
                else if ((int)fileNameString.find("_4_") != -1){
                    backUpImageColorSet = "4";
                }
                else if ((int)fileNameString.find("_5_") != -1){
                    backUpImageColorSet = "5";
                }
                else if ((int)fileNameString.find("_6_") != -1){
                    backUpImageColorSet = "6";
                }
                else if ((int)fileNameString.find("_7_") != -1){
                    backUpImageColorSet = "7";
                }
                else if ((int)fileNameString.find("_8_") != -1){
                    backUpImageColorSet = "8";
                }
                else if ((int)fileNameString.find("_9_") != -1){
                    backUpImageColorSet = "9";
                }
                else backUpImageColorSet = "0";
                
                if (imageDataHoldBackUpImageStatus == 1){
                    for (int counter1 = 0; counter1 < backUpImageWidth*backUpImagePlane+2; counter1++) delete [] arrayImageDataHoldBackUpImage [counter1];
                    delete [] arrayImageDataHoldBackUpImage;
                }
                
                //-----Tiff reading-----
                unsigned long stripFirstAddress = 0;
                unsigned long stripByteCountAddress = 0;
                unsigned long nextAddress = 0;
                unsigned long headPosition = 0;
                unsigned long headPositionHold = 0;
                unsigned long stripEntry = 0;
                long sizeForCopy = 0;
                
                double xPosition = 0;
                double yPosition = 0;
                
                int imageWidth = 0;
                int imageHeight = 0;
                int imageBit = 0; // Check 8, 16
                int imageCompression = 0; // Check 1
                int photoMetric = 0;//check 0, 1, 2
                int imageDimension = 0;
                int verticalBmp = 0;
                int horizontalBmpEntry = 0;
                int endianType = 0;
                int samplePerPix = 0;
                int loopCount = 0;
                int dataConversion [4];
                int processType = 1;
                int numberOfLayers = 0;
                int terminationFlag = 0;
                struct stat sizeOfFile;
                
                if (stat(imageDisplayPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                    
                    fileReadArray = new uint8_t [(int)sizeForCopy+4];
                    fin.open(imageDisplayPath.c_str(), ios::in | ios::binary);
                    fin.read((char*)fileReadArray, sizeForCopy+1);
                    fin.close();
                    
                    dataConversion [0] = fileReadArray [0];
                    dataConversion [1] = fileReadArray [1];
                    
                    if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                    else endianType = 0;
                    
                    int *arrayExtractedImage3 = new int [100];
                    
                    headPosition = 0;
                    
                    if (endianType == 1){
                        dataConversion [0] = fileReadArray [7];
                        dataConversion [1] = fileReadArray [6];
                        dataConversion [2] = fileReadArray [5];
                        dataConversion [3] = fileReadArray [4];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    else if (endianType == 0){
                        dataConversion [0] = fileReadArray [4];
                        dataConversion [1] = fileReadArray [5];
                        dataConversion [2] = fileReadArray [6];
                        dataConversion [3] = fileReadArray [7];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    
                    headPositionHold = headPosition;
                    loopCount = 1;
                    
                    backUpImageHeight = 0;
                    backUpImageWidth = 0;
                    backUpImagePlane = 1;
                    
                    do{
                        
                        terminationFlag = 1;
                        
                        if (endianType == 1){
                            tiffFileRead = [[TiffFileRead alloc] init];
                            [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress :&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                            
                            if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                backUpImageHeight = imageWidth;
                                backUpImageWidth = imageHeight;
                            }
                        }
                        else if (endianType == 0){
                            tiffFileRead = [[TiffFileRead alloc] init];
                            [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress :&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                            
                            if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                backUpImageHeight = imageWidth;
                                backUpImageWidth = imageHeight;
                            }
                        }
                        
                        if (nextAddress != 0){
                            headPosition = nextAddress;
                            loopCount++;
                        }
                        else terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                    
                    backUpImagePlane = loopCount;
                    
                    imageDataHoldBackUpImageStatus = 1;
                    
                    arrayImageDataHoldBackUpImage = new int *[backUpImageHeight*backUpImagePlane+2];
                    for (int counter1 = 0; counter1 < backUpImageHeight*backUpImagePlane+2; counter1++) arrayImageDataHoldBackUpImage [counter1] = new int [backUpImageWidth+2];
                    
                    
                    if (backUpImageWidth != 0 && backUpImageHeight != 0){
                        headPosition = headPositionHold;
                        
                        verticalBmp = 0;
                        
                        do{
                            
                            terminationFlag = 1;
                            
                            if (endianType == 1){
                                tiffFileRead = [[TiffFileRead alloc] init];
                                [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress :&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                
                                if (imageWidth > imageHeight) imageDimension = imageWidth;
                                else imageDimension = imageHeight;
                                
                                tiffFileRead = [[TiffFileRead alloc] init];
                                delete [] arrayExtractedImage3;
                                
                                arrayExtractedImage3 = [tiffFileRead imageSetBigEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                            }
                            else if (endianType == 0){
                                tiffFileRead = [[TiffFileRead alloc] init];
                                [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress :&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                
                                if (imageWidth > imageHeight) imageDimension = imageWidth;
                                else imageDimension = imageHeight;
                                
                                tiffFileRead = [[TiffFileRead alloc] init];
                                delete [] arrayExtractedImage3;
                                
                                arrayExtractedImage3 = [tiffFileRead imageSetLittleEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                            }
                            
                            horizontalBmpEntry = 0;
                            
                            if (photoMetric == 1){
                                for (int counter2 = 0; counter2 < imageWidth*imageHeight; counter2++){
                                    arrayImageDataHoldBackUpImage [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter2]);
                                    horizontalBmpEntry++;
                                    
                                    if (horizontalBmpEntry == imageWidth){
                                        horizontalBmpEntry = 0;
                                        verticalBmp++;
                                    }
                                }
                            }
                            else if (photoMetric == 2){
                                for (int counter2 = 0; counter2 < imageWidth*imageHeight; counter2++){
                                    arrayImageDataHoldBackUpImage [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter2*3]), horizontalBmpEntry++;
                                    arrayImageDataHoldBackUpImage [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter2*3+1]), horizontalBmpEntry++;
                                    arrayImageDataHoldBackUpImage [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter2*3+2]), horizontalBmpEntry++;
                                    
                                    if (horizontalBmpEntry == imageWidth*3){
                                        horizontalBmpEntry = 0;
                                        verticalBmp++;
                                    }
                                }
                            }
                            
                            photometricBackHold = photoMetric;
                            
                            if (nextAddress != 0){
                                headPosition = nextAddress;
                            }
                            else terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                    
                    delete [] arrayExtractedImage3;
                    delete [] fileReadArray;
                    
                    planeNumberBackUpDisplay = 0;
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackUpCheckImage object:self];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Image File Missing"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Image File Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)sliderAction:(id)sender{
    if (imageFirstLoadFlagBackUp == 1){
        fluorescentEnhanceBackUp = [sliderContrast doubleValue];
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackUpCheckImage object:self];
    }
}

-(IBAction)tableReload:(id)sender{
    if (backUpDirectoryCount != 0){
        string entry;
        
        DIR *dir;
        struct dirent *dent;
        
        backUpFolderNoUpDateCount = 0;
        
        for (int counter1 = 0; counter1 < backUpDirectoryCount; counter1++){
            dir = opendir(backUpDirectoryArray [counter1].c_str());
            
            if (dir != NULL){
                while((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store" && bodyNameBack != "" && (int)entry.find(bodyNameBack) != -1){
                        if (backUpFolderNoUpDateCount+10 > backUpFolderNoUpDateLimit) [self backUpFolderNoUpDate];
                        
                        backUpFolderNoUpDateArray [backUpFolderNoUpDateCount] = backUpDirectoryArray [counter1]+"/"+entry, backUpFolderNoUpDateCount++;
                    }
                }
                
                closedir(dir);
            }
        }
        
        //----Directory Sort-----
        NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
        
        for (int counter1 = 0; counter1 < backUpFolderNoUpDateCount; counter1++){
            [unsortedArray addObject:@(backUpFolderNoUpDateArray [counter1].c_str())];
        }
        
        [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
        
        for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
            backUpFolderNoUpDateArray [counter1] = [unsortedArray [counter1] UTF8String];
        }
        
        [listBrowser reloadColumn:0];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackUpCheckTable object:self];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Entry Found"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)backUpDirectoryLoad:(id)sender{
    NSOpenPanel* openDlg = [NSOpenPanel openPanel];
    [openDlg setCanChooseFiles:NO];
    [openDlg setCanChooseDirectories:YES];
    
    if ([openDlg runModal] == NSModalResponseOK){
        NSArray *files = [openDlg URLs];
        NSString *fileName = [[files objectAtIndex:0] absoluteString];
        
        string directoryPathExtract = [fileName UTF8String];
        
        int findString1 = (int)directoryPathExtract.find("/Users/");
        if (findString1 == -1) findString1 = (int)directoryPathExtract.find("/Volumes/");
        unsigned long directoryLength = directoryPathExtract.length();
        
        string directoryPath = directoryPathExtract.substr((unsigned long)findString1, directoryLength-(unsigned long)findString1-1);
        string extractedID;
        string extractedID2;
        
        int terminationFlag = 0;
        
        do{
            
            terminationFlag = 1;
            
            findString1 = (int)directoryPath.find("%20");
            if (findString1 != -1){
                extractedID2 = directoryPath.substr(0, (unsigned long)findString1);
                directoryPath = directoryPath.substr((unsigned long)findString1+3);
                directoryPath = extractedID2+" "+directoryPath;
            }
            else terminationFlag = 0;
            
        } while (terminationFlag == 1);
        
        if ((int)directoryPath.find("BackUpDummy") == -1){
            string batchProcessBackUpPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/BatchBackUpNameList";
            string getString;
            bodyNameBack = "";
            
            ifstream fin;
            fin.open(batchProcessBackUpPath.c_str(),ios::in);
            
            if (fin.is_open()){
                getline(fin, getString);
                bodyNameBack = getString;
                fin.close();
            }
            
            int matchFlag = 0;
            string entry;
            
            DIR *dir;
            struct dirent *dent;
            
            dir = opendir(directoryPath.c_str());
            
            if (dir != NULL){
                while((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store" && bodyNameBack != "" && (int)entry.find(bodyNameBack) != -1){
                        matchFlag = 1;
                        break;
                    }
                }
                
                closedir(dir);
            }
            
            int sameNameFind = 0;
            
            for (int counter1 = 0; counter1 < backUpDirectoryCount; counter1++){
                if (backUpDirectoryArray [counter1] == directoryPath){
                    sameNameFind = 1;
                    break;
                }
            }
            
            if (matchFlag == 1 && sameNameFind == 0){
                if (backUpDirectoryCount+10 > backUpDirectoryLimit) [self backUpDirectoryDataUpDate];
                
                backUpDirectoryArray [backUpDirectoryCount] = directoryPath, backUpDirectoryCount++;
                
                backUpFolderNoUpDateCount = 0;
                
                for (int counter1 = 0; counter1 < backUpDirectoryCount; counter1++){
                    dir = opendir(backUpDirectoryArray [counter1].c_str());
                    
                    if (dir != NULL){
                        while((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store" && bodyNameBack != "" && (int)entry.find(bodyNameBack) != -1){
                                if (backUpFolderNoUpDateCount+10 > backUpFolderNoUpDateLimit) [self backUpFolderNoUpDate];
                                
                                backUpFolderNoUpDateArray [backUpFolderNoUpDateCount] = backUpDirectoryArray [counter1]+"/"+entry, backUpFolderNoUpDateCount++;
                            }
                        }
                        
                        closedir(dir);
                    }
                }
                
                //----Directory Sort-----
                NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                
                for (int counter1 = 0; counter1 < backUpFolderNoUpDateCount; counter1++){
                    [unsortedArray addObject:@(backUpFolderNoUpDateArray [counter1].c_str())];
                }
                
                [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                
                for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                    backUpFolderNoUpDateArray [counter1] = [unsortedArray [counter1] UTF8String];
                }
                
                [listBrowser reloadColumn:0];
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackUpCheckTable object:self];
            }
            else{
                
                if (matchFlag == 0){
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"No Matching File Found"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                else{
                    
                    if (matchFlag == 1 && sameNameFind == 0){
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Directory Already Selected"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Dummy Folder Selected"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)backUpDirectoryClear:(id)sender{
    if (backUpDirectoryCount != 0){
        string directorySelect;
        
        for (int counter1 = 0; counter1 < backUpDirectoryCount; counter1++){
            if (counter1 == tableRowHoldBackUp){
                directorySelect = backUpDirectoryArray [counter1];
                break;
            }
        }
        
        int directoryEntryCount = 0;
        
        for (int counter1 = 0; counter1 < backUpDirectoryCount; counter1++){
            if (backUpDirectoryArray [counter1] != directorySelect){
                backUpDirectoryArray [directoryEntryCount] = backUpDirectoryArray [counter1];
                directoryEntryCount++;
            }
        }
        
        backUpDirectoryCount--;
        
        string entry;
        
        DIR *dir;
        struct dirent *dent;
        
        backUpFolderNoUpDateCount = 0;
        
        for (int counter1 = 0; counter1 < backUpDirectoryCount; counter1++){
            dir = opendir(backUpDirectoryArray [counter1].c_str());
            
            if (dir != NULL){
                while((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store" && bodyNameBack != "" && (int)entry.find(bodyNameBack) != -1){
                        if (backUpFolderNoUpDateCount+10 > backUpFolderNoUpDateLimit) [self backUpFolderNoUpDate];
                        
                        backUpFolderNoUpDateArray [backUpFolderNoUpDateCount] = backUpDirectoryArray [counter1]+"/"+entry, backUpFolderNoUpDateCount++;
                    }
                }
                
                closedir(dir);
            }
        }
        
        //----Directory Sort-----
        NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
        
        for (int counter1 = 0; counter1 < backUpFolderNoUpDateCount; counter1++){
            [unsortedArray addObject:@(backUpFolderNoUpDateArray [counter1].c_str())];
        }
        
        [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
        
        for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
            backUpFolderNoUpDateArray [counter1] = [unsortedArray [counter1] UTF8String];
        }
        
        [listBrowser reloadColumn:0];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackUpCheckTable object:self];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Entry Found"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)closeWindow:(id)sender{
    [backUpCheckWindow orderOut:self];
    backUpOperation = 2;
    backUpCheckTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
}

-(void)reDisplayWindow{
    if (backUpOperation == 3){
        [backUpCheckWindow makeKeyAndOrderFront:self];
        backUpOperation = 1;
        [backUpCheckTimer invalidate];
    }
}

-(void)directoryInfoDataUpDate{
    string *arrayUpDate = new string [directoryInfoCount+10];
    
    for (int counter1 = 0; counter1 < directoryInfoCount; counter1++) arrayUpDate [counter1] = arrayDirectoryInfo [counter1];
    
    delete [] arrayDirectoryInfo;
    arrayDirectoryInfo = new string [directoryInfoLimit+500];
    directoryInfoLimit = directoryInfoLimit+500;
    
    for (int counter1 = 0; counter1 < directoryInfoCount; counter1++) arrayDirectoryInfo [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)backUpDirectoryDataUpDate{
    string *arrayUpDate = new string [backUpDirectoryCount+10];
    
    for (int counter1 = 0; counter1 < backUpDirectoryCount; counter1++) arrayUpDate [counter1] = backUpDirectoryArray [counter1];
    
    delete [] backUpDirectoryArray;
    backUpDirectoryArray = new string [backUpDirectoryLimit+20];
    backUpDirectoryLimit = backUpDirectoryLimit+20;
    
    for (int counter1 = 0; counter1 < backUpDirectoryCount; counter1++) backUpDirectoryArray [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)backUpFolderNoUpDate{
    string *arrayUpDate = new string [backUpFolderNoUpDateCount+10];
    
    for (int counter1 = 0; counter1 < backUpFolderNoUpDateCount; counter1++) arrayUpDate [counter1] = backUpFolderNoUpDateArray [counter1];
    
    delete [] backUpFolderNoUpDateArray;
    backUpFolderNoUpDateArray = new string [backUpFolderNoUpDateLimit+1000];
    backUpDirectoryLimit = backUpFolderNoUpDateLimit+1000;
    
    for (int counter1 = 0; counter1 < backUpFolderNoUpDateCount; counter1++) backUpFolderNoUpDateArray [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)backUpFileDateUpDate{
    string *arrayUpDate = new string [backUpFileCount+10];
    
    for (int counter1 = 0; counter1 < backUpFileCount; counter1++) arrayUpDate [counter1] = backUpFileArray [counter1];
    
    delete [] backUpFileArray;
    backUpFileArray = new string [backUpFileLimit+1000];
    backUpFileLimit = backUpFileLimit+1000;
    
    for (int counter1 = 0; counter1 < backUpFileCount; counter1++) backUpFileArray [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)dealloc{
    if (backUpCheckTimer) [backUpCheckTimer invalidate];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToBackUpCheckControl object:nil];
}

@end
