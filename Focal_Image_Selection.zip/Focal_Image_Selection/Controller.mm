//
//  Controller.mm
//  Focal_Image_Selection
//
//  Created by Masahiko Sato on 28/12/09, 26/06/13 revised.
//  Copyright  Masahiko Sato 2009 All rights reserved.
//

#import "Controller.h"

//----Paths----
string productsFilesImagePath;
string productsFocalPlanePath;
string productsFocalTreatmentPath;
string productsFocalFOVPath;
string productsFocalTempPath;
string namedFilesPath;
string focalSettingPath;
string nameAssignFilePath;
string backUpFolderPath; 
string instructionFIPath;
string instructionFIPath2;
string instructionCSPath;
string productsFocalPlaneTempPath;
string focalSettingTempPath;
string loadingCompletionPath;
string backgroundImagePath;
string pathNameString;

//----Basic Info----
string bodyName;
string ascIIstring;
string totalFOVNoHold;
string autoFolderName;
string copyDirectoryInfo;
string fileSavePathHold;
int copySetStatus;
int totalFOVNoHoldInt;
int timePointRequest;
int currentTimePoint;
int fluorescentCount;
int tableViewCall;
int processMode;
int currentTableHead;
int imageProcessTiming;
int importTableEnd;
int dicRangeSet; 
int firstImageExclude;
int focusProcessFlag;
int progressValue;
int progressTiming;
int photoMetricHold;

//----Arrays----
int **arrayFocalPlaneData;
int focalPlaneDataLimit;
int focalPlaneDataHorizontal;
string *arrayTableDisplay;
int tableDisplayCount;
string *arrayNameListOfFiles;
int nameListOfFilesCount;
int nameListOfFilesStatus;
string *arrayTreatmentNameDisplay;
int treatmentNameDisplayCount;
string *arrayFOVNameDisplay;
int fOVNameDisplayCount;
string *arrayProcessList; 
int processListCount;
uint8_t *fileReadArray;
int **arrayImageFileSave;

//----Z image display----
int **arrayImageDataHoldZImage;
int imageDataHoldZImageStatus;
int zImageHeight;
int zImageWidth;
int zImagePlane;
int currentPlaneDisplayCall;
int planeNumberDisplay;
double fluorescentEnhance;
string zImageColorSet; 
int magnificationDisplay;
int imageFirstLoadFlagDisplay;
double windowWidthDisplay;
double windowHeightDisplay;

//----Fluorescent-----
string fluorescentNo1;
string fluorescentNo2;
string fluorescentNo3;
string fluorescentNo4;
string fluorescentNo5;
string fluorescentNo6;
string fluorescentNoName1;
string fluorescentNoName2;
string fluorescentNoName3;
string fluorescentNoName4;
string fluorescentNoName5;
string fluorescentNoName6;

//----File order process or delete-----
string *arrayFileDelete;
int fileDeleteCount;
int fileDeleteLimit;

//----Processing of Back up files-----
int backUpOperation;
int imageFirstLoadFlagBackUp;
string *backUpDirectoryArray;
int backUpDirectoryCount;
int backUpDirectoryLimit;
string *backUpFolderNoUpDateArray;
int backUpFolderNoUpDateCount;
int backUpFolderNoUpDateLimit;
int photometricBackHold;

string *backUpFileArray;
int backUpFileCount;
int backUpFileLimit;
int **arrayImageDataHoldBackUpImage;
int imageDataHoldBackUpImageStatus;
int backUpImageHeight;
int backUpImageWidth;
int backUpImagePlane;
int planeNumberBackUpDisplay;
double fluorescentEnhanceBackUp;
string backUpImageColorSet;
int magnificationBackUpDisplay;
double windowWidthBackUpDisplay;
double windowHeightBackUpDisplay;
int tableRowHoldBackUp; 
int backUpTableCallCount;
int backUpTableCurrentRowHold;
int backUpTableNewRowHold;
int currentPlaneVBackUpCall;

//----Directory temp save----
string *arrayDirectoryInfo;
int directoryInfoCount;
int directoryInfoLimit;

@implementation Controller

-(id)init{
    self = [super init];
    
    if (self != nil){
        copyDirectoryInfo = "nil";
        copySetStatus = 0;
        timePointRequest = 0;
        tableViewCall = 0;
        processMode = 0;
        imageProcessTiming = 0;
        focusProcessFlag = 0;
        progressValue = 0;
        progressTiming = 0;
        
        nameListOfFilesStatus = 0;
        
        imageDataHoldZImageStatus = 0;
        zImageHeight = 0;
        zImageWidth = 0;
        zImagePlane = 0;
        currentPlaneDisplayCall = 0;
        planeNumberDisplay = 0;
        fluorescentEnhance = 1;
        zImageColorSet = "0";
        magnificationDisplay = 10;
        imageFirstLoadFlagDisplay = 0;
        
        backUpOperation = 0;
        imageFirstLoadFlagBackUp = 0;
        imageDataHoldBackUpImageStatus = 0;
        backUpImageHeight = 0;
        backUpImageWidth = 0;
        backUpImagePlane = 0;
        planeNumberBackUpDisplay = 0;
        fluorescentEnhanceBackUp = 1;
        backUpImageColorSet = "0";
        magnificationBackUpDisplay = 10;
        tableRowHoldBackUp = 0;
        backUpTableCallCount = 0;
        backUpTableCurrentRowHold = 0;
        backUpTableNewRowHold = 0;
        currentPlaneVBackUpCall = 0;
        photometricBackHold = 0;
        
        firstCommunication = 0;
        basicInfoRead = 0;
        initialArraySet = 0;
        tableCallCount = 0;
        rowIndexHold = 0;
        tableCurrentRowHold = 0;
        exitFlag = 0;
        firstTimeSet = 0;
        lastColumnNoHold = 0;
        lastRowNoHold = 0;
        lastTypeHold = "X";
    }
    
    return self;
}

-(void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat xLength = screenRect.size.width;
    CGFloat yLength = screenRect.size.height;
    
    int mainControllerX = 800;
    
    NSRect windowSize = [controllerWindow frame];
    CGFloat windowWidth = windowSize.size.width;
    CGFloat windowHeight = windowSize.size.height;
    
    int displayPositionType = 0;
    
    if (80+mainControllerX+5+windowWidth+5+80 > xLength) displayPositionType = 1;
    
    CGFloat displayX;
    
    if (displayPositionType == 1) displayX = 350;
    else displayX = 80+mainControllerX+5;
    
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [controllerWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    [tableViewList setDataSource:self];
}

-(void)applicationDidFinishLaunching:(NSNotification*)notification{
    NSString *currentDirectoryPathNSString = [[NSBundle mainBundle] bundlePath];
    string userPathNameString = [currentDirectoryPathNSString cStringUsingEncoding:NSUTF8StringEncoding];
    
    if (userPathNameString.length() == 0) exit (0);
    else if ((int)userPathNameString.find("/Users/") == -1) exit (0);
    else{
        
        string pathName2 = userPathNameString.substr((unsigned long)userPathNameString.find("/Users/")+7);
        pathNameString = pathName2.substr(0, (unsigned long)pathName2.find("/"));
    }
    
    namedFilesPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"03_Named_Files";
    nameAssignFilePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/NAAssignedName";
    backUpFolderPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"04_BackUp_Folder";
    instructionFIPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/"+"FI_Instruction1";
    instructionFIPath2 = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/"+"FI_Instruction2";
    instructionCSPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/"+"CS_Instruction1";
    loadingCompletionPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/FSComplete1";
    backgroundImagePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/"+"Blank2.jpg";
    string analysisDataPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/AnalysisSetting";
    
    bodyName = "";
    totalFOVNoHold = "";
    
    string getString;
    
    ifstream fin;
    fin.open(analysisDataPath.c_str(),ios::in);
    
    if (fin.is_open()){
        getline(fin, getString), bodyName = getString;
        getline(fin, getString);
        getline(fin, getString), totalFOVNoHold = getString;
        fin.close();
    }
    
    fluorescentCount = 0;
    fluorescentNo1 = "nil";
    fluorescentNo2 = "nil";
    fluorescentNo3 = "nil";
    fluorescentNo4 = "nil";
    fluorescentNo5 = "nil";
    fluorescentNo6 = "nil";
    
    fin.open(nameAssignFilePath.c_str(),ios::in);
    
    if (fin.is_open()){
        for (int counter1 = 0; counter1 < 57; counter1++) getline(fin, getString);
        
        for (int counter1 = 0; counter1 < 6; counter1++){
            getline(fin, getString);
            
            if (getString != "nil")  fluorescentCount++;
            
            getline(fin, getString);
            
            if (getString != "0" && counter1 == 0) fluorescentNoName1 = getString;
            if (getString != "0" && counter1 == 1) fluorescentNoName2 = getString;
            if (getString != "0" && counter1 == 2) fluorescentNoName3 = getString;
            if (getString != "0" && counter1 == 3) fluorescentNoName4 = getString;
            if (getString != "0" && counter1 == 4) fluorescentNoName5 = getString;
            if (getString != "0" && counter1 == 5) fluorescentNoName6 = getString;
            
            getline(fin, getString);
            
            if (getString != "0" && counter1 == 0) fluorescentNo1 = getString;
            if (getString != "0" && counter1 == 1) fluorescentNo2 = getString;
            if (getString != "0" && counter1 == 2) fluorescentNo3 = getString;
            if (getString != "0" && counter1 == 3) fluorescentNo4 = getString;
            if (getString != "0" && counter1 == 4) fluorescentNo5 = getString;
            if (getString != "0" && counter1 == 5) fluorescentNo6 = getString;
        }
        
        fin.close();
    }
    
    [bodyNameDisplay setStringValue:@(bodyName.c_str())];
    [totalFOVDisplay setStringValue:@(totalFOVNoHold.c_str())];
    
    string productsFilesPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+bodyName+"_Products";
    string productsFilesInfoPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+bodyName+"_Products"+"/"+"Analysis_Information";
    productsFilesImagePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+bodyName+"_Products"+"/"+"Source_Images";
    productsFocalTempPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files"+"/"+bodyName+"_Products"+"/"+"Temp_Images";
    
    mkdir(productsFilesPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
    mkdir(productsFilesImagePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
    mkdir(productsFilesInfoPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
    mkdir(productsFocalTempPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
    
    productsFocalPlanePath = productsFilesInfoPath+"/"+"FI-FocalPlaneData";
    productsFocalTreatmentPath = productsFilesInfoPath+"/"+"FI-TreatmentNameData";
    productsFocalFOVPath = productsFilesInfoPath+"/"+"FI-FOVData";
    focalSettingPath = productsFilesInfoPath+"/"+"FI-BasicSetting";
    productsFocalPlaneTempPath = productsFocalTempPath+"/"+"FI-FocalPlaneData";
    focalSettingTempPath = productsFocalTempPath+"/"+"FI-BasicSetting";
    
    currentTimePoint = 0;
    importTableEnd = -1;
    
    fin.open(focalSettingPath.c_str(),ios::in);
    
    if (fin.is_open()){
        getline(fin, getString), currentTimePoint = atoi(getString.c_str()); //Time point
        getline(fin, getString), importTableEnd = atoi(getString.c_str()); //Import end point
        getline(fin, getString), dicRangeSet = atoi(getString.c_str()); //DIC range hold
        getline(fin, getString), firstImageExclude = atoi(getString.c_str()); //First image exclude setting
        getline(fin, getString), copySetStatus = atoi(getString.c_str());//Copy status
        getline(fin, getString), copyDirectoryInfo = getString; //copy directory
        
        fin.close();
        
        if (dicRangeSet == 0) [dicRangeDisplay setStringValue:@"None"];
        else if (dicRangeSet == 1) [dicRangeDisplay setStringValue:@"20"];
        else if (dicRangeSet == 2) [dicRangeDisplay setStringValue:@"40"];
        else if (dicRangeSet == 3) [dicRangeDisplay setStringValue:@"60"];
        else if (dicRangeSet == 4) [dicRangeDisplay setStringValue:@"80"];
        
        if (firstImageExclude == 1) [includeExcludeDisplay setStringValue:@"Exclude"];
        else [includeExcludeDisplay setStringValue:@"Include"];
        
        if (copySetStatus != 0){
            int findString1 = (int)copyDirectoryInfo.find("/Users/");
            
            if (findString1 == -1) findString1 = (int)copyDirectoryInfo.find("/Volumes/");
            unsigned long directoryLength = copyDirectoryInfo.length();
            
            string directoryPath = copyDirectoryInfo.substr((unsigned long)findString1, directoryLength-(unsigned long)findString1-1);
            string extractedID;
            string extractedID2;
            
            int terminationFlag = 0;
            
            do{
                
                terminationFlag = 1;
                
                findString1 = (int)directoryPath.find("%20");
                
                if (findString1 != -1){
                    extractedID2 = directoryPath.substr(0, (unsigned long)findString1);
                    directoryPath = directoryPath.substr((unsigned long)findString1+3);
                    directoryPath = extractedID2+" "+directoryPath;
                }
                else terminationFlag = 0;
                
            } while (terminationFlag == 1);
            
            extractedID = directoryPath;
            
            do{
                
                terminationFlag = 1;
                findString1 = (int)extractedID.find("/");
                
                if (findString1 != -1){
                    extractedID = extractedID.substr((unsigned long)findString1+1);
                }
                else terminationFlag = 0;
                
            } while (terminationFlag == 1);
            
            [copyFolderInfoDisplay setStringValue:@(extractedID.c_str())];
        }
        else [copyFolderInfoDisplay setStringValue:@"nil"];
    }
    else{
        
        currentTimePoint = 1;
        dicRangeSet = 0;
        firstImageExclude = 1;
        copySetStatus = 0;
        copyDirectoryInfo = "nil";
        
        [self saveParameter];
        
        [dicRangeDisplay setStringValue:@"None"];
        [includeExcludeDisplay setStringValue:@"Exclude"];
        [copyFolderInfoDisplay setStringValue:@"nil"];
    }
    
    [timePointDisplay setIntegerValue:currentTimePoint];
    
    totalFOVNoHoldInt = atoi(totalFOVNoHold.c_str());
    
    arrayFocalPlaneData = new int *[totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100];
    
    if (importTableEnd == -1){
        focalPlaneDataLimit = currentTimePoint+500;
        for (int counter1 = 0; counter1 < totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100; counter1++) arrayFocalPlaneData [counter1] = new int [currentTimePoint+500];
    }
    else{
        
        focalPlaneDataLimit = importTableEnd+500;
        for (int counter1 = 0; counter1 < totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100; counter1++) arrayFocalPlaneData [counter1] = new int [importTableEnd+500];
    }
    
    focalPlaneDataHorizontal = totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100;
    
    for (int counter1 = 0; counter1 < totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100; counter1++){
        for (int counter2 = 0; counter2 < currentTimePoint+100; counter2++) arrayFocalPlaneData [counter1][counter2] = 0;
    }
    
    arrayTreatmentNameDisplay = new string [totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100];
    arrayFOVNameDisplay = new string [totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100];
    
    treatmentNameDisplayCount = 0;
    fOVNameDisplayCount = 0;
    
    for (int counter1 = 0; counter1 < totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100; counter1++){
        arrayTreatmentNameDisplay [counter1] = "nil";
        arrayFOVNameDisplay [counter1] = "nil";
    }
    
    arrayProcessList = new string [(totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount)*5+100];
    processListCount = 0;
    
    int currentCutOff = 0;
    
    if (importTableEnd != -1) currentCutOff = importTableEnd;
    else currentCutOff = currentTimePoint;
    
    int lineCount = 0;
    fin.open(productsFocalPlanePath.c_str(),ios::in);
    
    if (fin.is_open()){
        do{
            
            getline(fin, getString);
            
            if (getString != ""){
                arrayFocalPlaneData [lineCount][0] = 0;
                
                getline(fin, getString);
                arrayFocalPlaneData [lineCount][1] = 0;
                
                if (lineCount == 0){
                    for (int counter1 = 1; counter1 <= currentCutOff; counter1++){
                        getline(fin, getString);
                        arrayFocalPlaneData [lineCount][counter1+1] = 0;
                    }
                }
                else{
                    
                    for (int counter1 = 1; counter1 < currentCutOff; counter1++){
                        getline(fin, getString);
                        arrayFocalPlaneData [lineCount][counter1+1] = atoi(getString.c_str());
                    }
                    
                    getline(fin, getString);
                    arrayFocalPlaneData [lineCount][currentCutOff+1] = atoi(getString.c_str());
                }
                
                lineCount++;
            }
            
        } while (getString != "");
        
        fin.close();
    }
    
    //for (int counterA = 0; counterA < lineCount; counterA++){
    //    for (int counterB = 0; counterB < currentCutOff+2; counterB++) cout<<" "<<arrayFocalPlaneData [counterA][counterB];
    //    cout<<"  arrayFocalPlaneData "<<counterA+1<<endl;
    //}
    
    fin.open(productsFocalTreatmentPath.c_str(),ios::in);
    
    if (fin.is_open()){
        do{
            
            getline(fin, getString);
            
            if (getString != "") arrayTreatmentNameDisplay [treatmentNameDisplayCount] = getString, treatmentNameDisplayCount++;
            
        } while (getString != "");
        
        fin.close();
    }
    
    //for (int counterA = 0; counterA < treatmentNameDisplayCount; counterA++) cout<<arrayTreatmentNameDisplay [counterA]<<" arrayTreatmentNameDisplay "<<endl;
    
    fin.open(productsFocalFOVPath.c_str(),ios::in);
    
    if (fin.is_open()){
        do{
            
            getline(fin, getString);
            
            if (getString != "") arrayFOVNameDisplay [fOVNameDisplayCount] = getString, fOVNameDisplayCount++;
            
        } while (getString != "");
        
        fin.close();
    }
    
    //for (int counterA = 0; counterA < fOVNameDisplayCount; counterA++) cout<<arrayFOVNameDisplay [counterA]<<" fOVNameDisplayCount "<<endl;
    
    string extension;
    string productDataPath1;
    
    int lastTimePoint = 0;
    
    for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
        if (arrayTreatmentNameDisplay [counter1] != "ND"){
            for (int counter2 = currentTimePoint+5; counter2 > 0; counter2--){
                extension = to_string(counter2);
                
                if (extension.length() == 1) extension = "000"+extension;
                else if (extension.length() == 2) extension = "00"+extension;
                else if (extension.length() == 3) extension = "0"+extension;
                
                productDataPath1 = productsFilesImagePath+"/"+arrayTreatmentNameDisplay [counter1]+"~Sorted/FOV001/"+arrayTreatmentNameDisplay [counter1]+"_"+extension+"-FOV001.tif";
                
                fin.open(productDataPath1.c_str(),ios::in);
                
                if (fin.is_open()){
                    fin.close();
                    
                    if (lastTimePoint < counter2) lastTimePoint = counter2;
                    break;
                }
                else{
                    
                    productDataPath1 = productsFilesImagePath+"/"+arrayTreatmentNameDisplay [counter1]+"~Sorted/FOV001/"+arrayTreatmentNameDisplay [counter1]+"_"+extension+"-FOV001.bmp";
                    
                    if (fin.is_open()){
                        fin.close();
                        
                        if (lastTimePoint < counter2) lastTimePoint = counter2;
                        break;
                    }
                }
            }
        }
    }
    
    if (lastTimePoint != 0 && lastTimePoint+1 < currentTimePoint){
        currentTimePoint = lastTimePoint+1;
        
        [self saveParameter];
    }
    
    int startingTimePoint = 1;
    tableDisplayCount = 0;
    arrayTableDisplay = new string [(totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100)*17];
    
    if (currentTimePoint > 15) startingTimePoint = currentTimePoint-15;
    
    //----Line One set----
    arrayTableDisplay [tableDisplayCount] = "Name", tableDisplayCount++;
    arrayTableDisplay [tableDisplayCount] = "FOV", tableDisplayCount++;
    
    for (int counter1 = startingTimePoint; counter1 < startingTimePoint+15; counter1++){
        extension = to_string(counter1);
        
        if (importTableEnd == counter1 && importTableEnd != currentTimePoint) arrayTableDisplay [tableDisplayCount] = "E"+extension, tableDisplayCount++;
        else if (currentTimePoint == counter1) arrayTableDisplay [tableDisplayCount] = "C"+extension, currentTableHead = tableDisplayCount, tableDisplayCount++;
        else arrayTableDisplay [tableDisplayCount] = "T"+extension, tableDisplayCount++;
    }
    
    if (arrayTreatmentNameDisplay [0] != "nil"){
        for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
            if (arrayTreatmentNameDisplay [counter1] != "ND") arrayTableDisplay [tableDisplayCount] = arrayTreatmentNameDisplay [counter1], tableDisplayCount++;
            else arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
            
            if (arrayFOVNameDisplay [counter1] != "ND") arrayTableDisplay [tableDisplayCount] = arrayFOVNameDisplay [counter1], tableDisplayCount++;
            else arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
            
            //Plane number start from "1";
            //Line one and line break: -1000
            //No entry: -2000;
            //No entry after T: -2500;
            
            //**Time point head**
            //Focal Plane: -3000
            //Focal Plane+cont: -3500
            //Fixed plane: -6001, -6002, -6003,.....
            //Fixed plane+cont: -7001, -7002, -7003,.....
            //All-in-one: -4000;
            //All-in-one+cont: -4500;
            //All-in-one center: -8001;
            //All-in-one+cont: -9001;
            //Range: -10111222; start 111, end 222
            //Range+cont: -11111222:
            //Terminated: -5000;
            
            string extract1;
            string extract2;
            
            if (arrayFOVNameDisplay [counter1] != "ND"){
                for (int counter2 = startingTimePoint; counter2 < startingTimePoint+15; counter2++){
                    if (counter2 > currentCutOff) arrayTableDisplay [tableDisplayCount] = "0", tableDisplayCount++;
                    else if (counter2 == currentTimePoint){
                        if (arrayFocalPlaneData [counter1][counter2+1] == -1000) arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -2000) arrayTableDisplay [tableDisplayCount] = "*", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -2500) arrayTableDisplay [tableDisplayCount] = "*", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -3000) arrayTableDisplay [tableDisplayCount] = "f", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -3500) arrayTableDisplay [tableDisplayCount] = "F", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] < -6000 && arrayFocalPlaneData [counter1][counter2+1] > -7000){
                            extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                            extension = extension.substr(2);
                            extension = to_string(atoi(extension.c_str()));
                            
                            arrayTableDisplay [tableDisplayCount] = "p"+extension, tableDisplayCount++;
                        }
                        else if (arrayFocalPlaneData [counter1][counter2+1] < -7000 && arrayFocalPlaneData [counter1][counter2+1] > -8000){
                            extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                            extension = extension.substr(2);
                            extension = to_string(atoi(extension.c_str()));
                            
                            arrayTableDisplay [tableDisplayCount] = "P"+extension, tableDisplayCount++;
                        }
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -4000) arrayTableDisplay [tableDisplayCount] = "a", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -4500) arrayTableDisplay [tableDisplayCount] = "A", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] < -8000 && arrayFocalPlaneData [counter1][counter2+1] > -9000){
                            extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                            extension = extension.substr(2);
                            extension = to_string(atoi(extension.c_str()));
                            
                            arrayTableDisplay [tableDisplayCount] = "s"+extension, tableDisplayCount++;
                        }
                        else if (arrayFocalPlaneData [counter1][counter2+1] < -9000 && arrayFocalPlaneData [counter1][counter2+1] > -10000){
                            extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                            extension = extension.substr(2);
                            extension = to_string(atoi(extension.c_str()));
                            
                            arrayTableDisplay [tableDisplayCount] = "S"+extension, tableDisplayCount++;
                        }
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -5000) arrayTableDisplay [tableDisplayCount] = "T", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] < -10000000 && arrayFocalPlaneData [counter1][counter2+1] > -11000000){
                            extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                            extract1 = extension.substr(3, 3);
                            extract2 = extension.substr(6, 3);
                            extract1 = to_string(atoi(extract1.c_str()));
                            extract2 = to_string(atoi(extract2.c_str()));
                            
                            arrayTableDisplay [tableDisplayCount] = "r"+extract1+"-"+extract2, tableDisplayCount++;
                        }
                        else if (arrayFocalPlaneData [counter1][counter2+1] < -11000000 && arrayFocalPlaneData [counter1][counter2+1] > -12000000){
                            extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                            extract1 = extension.substr(3, 3);
                            extract2 = extension.substr(6, 3);
                            extract1 = to_string(atoi(extract1.c_str()));
                            extract2 = to_string(atoi(extract2.c_str()));
                            
                            arrayTableDisplay [tableDisplayCount] = "R"+extract1+"-"+extract2, tableDisplayCount++;
                        }
                        else arrayTableDisplay [tableDisplayCount] = "ND", tableDisplayCount++;
                    }
                    else if (counter2 == importTableEnd){
                        if (arrayFocalPlaneData [counter1][counter2+1] == -1000) arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -2000) arrayTableDisplay [tableDisplayCount] = "*", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -2500) arrayTableDisplay [tableDisplayCount] = "*", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -3000) arrayTableDisplay [tableDisplayCount] = "f", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -3500) arrayTableDisplay [tableDisplayCount] = "F", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] < -6000 && arrayFocalPlaneData [counter1][counter2+1] > -7000){
                            extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                            extension = extension.substr(2);
                            extension = to_string(atoi(extension.c_str()));
                            
                            arrayTableDisplay [tableDisplayCount] = "p"+extension, tableDisplayCount++;
                        }
                        else if (arrayFocalPlaneData [counter1][counter2+1] < -7000 && arrayFocalPlaneData [counter1][counter2+1] > -8000){
                            extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                            extension = extension.substr(2);
                            extension = to_string(atoi(extension.c_str()));
                            
                            arrayTableDisplay [tableDisplayCount] = "P"+extension, tableDisplayCount++;
                        }
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -4000) arrayTableDisplay [tableDisplayCount] = "a", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -4500) arrayTableDisplay [tableDisplayCount] = "A", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] < -8000 && arrayFocalPlaneData [counter1][counter2+1] > -9000){
                            extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                            extension = extension.substr(2);
                            extension = to_string(atoi(extension.c_str()));
                            
                            arrayTableDisplay [tableDisplayCount] = "S"+extension, tableDisplayCount++;
                        }
                        else if (arrayFocalPlaneData [counter1][counter2+1] < -9000 && arrayFocalPlaneData [counter1][counter2+1] > -10000){
                            extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                            extension = extension.substr(2);
                            extension = to_string(atoi(extension.c_str()));
                            
                            arrayTableDisplay [tableDisplayCount] = "S"+extension, tableDisplayCount++;
                        }
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -5000) arrayTableDisplay [tableDisplayCount] = "T", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] < -10000000 && arrayFocalPlaneData [counter1][counter2+1] > -11000000){
                            extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                            extract1 = extension.substr(3, 3);
                            extract2 = extension.substr(6, 3);
                            extract1 = to_string(atoi(extract1.c_str()));
                            extract2 = to_string(atoi(extract2.c_str()));
                            
                            arrayTableDisplay [tableDisplayCount] = "r"+extract1+"-"+extract2, tableDisplayCount++;
                        }
                        else if (arrayFocalPlaneData [counter1][counter2+1] < -11000000 && arrayFocalPlaneData [counter1][counter2+1] > -12000000){
                            extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                            extract1 = extension.substr(3, 3);
                            extract2 = extension.substr(6, 3);
                            extract1 = to_string(atoi(extract1.c_str()));
                            extract2 = to_string(atoi(extract2.c_str()));
                            
                            arrayTableDisplay [tableDisplayCount] = "R"+extract1+"-"+extract2, tableDisplayCount++;
                        }
                        else arrayTableDisplay [tableDisplayCount] = "ND", tableDisplayCount++;
                    }
                    else{
                        
                        if (arrayFocalPlaneData [counter1][counter2+1] == -1000) arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -2000) arrayTableDisplay [tableDisplayCount] = "*", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -2500) arrayTableDisplay [tableDisplayCount] = "*", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -3000) arrayTableDisplay [tableDisplayCount] = "f", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -3500) arrayTableDisplay [tableDisplayCount] = "F", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] < -6000 && arrayFocalPlaneData [counter1][counter2+1] > -7000){
                            extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                            extension = extension.substr(2);
                            extension = to_string(atoi(extension.c_str()));
                            
                            arrayTableDisplay [tableDisplayCount] = "p"+extension, tableDisplayCount++;
                        }
                        else if (arrayFocalPlaneData [counter1][counter2+1] < -7000 && arrayFocalPlaneData [counter1][counter2+1] > -8000){
                            extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                            extension = extension.substr(2);
                            extension = to_string(atoi(extension.c_str()));
                            
                            arrayTableDisplay [tableDisplayCount] = "P"+extension, tableDisplayCount++;
                        }
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -4000) arrayTableDisplay [tableDisplayCount] = "a", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -4500) arrayTableDisplay [tableDisplayCount] = "A", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] < -8000 && arrayFocalPlaneData [counter1][counter2+1] > -9000){
                            extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                            extension = extension.substr(2);
                            extension = to_string(atoi(extension.c_str()));
                            
                            arrayTableDisplay [tableDisplayCount] = "s"+extension, tableDisplayCount++;
                        }
                        else if (arrayFocalPlaneData [counter1][counter2+1] < -9000 && arrayFocalPlaneData [counter1][counter2+1] > -10000){
                            extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                            extension = extension.substr(2);
                            extension = to_string(atoi(extension.c_str()));
                            
                            arrayTableDisplay [tableDisplayCount] = "S"+extension, tableDisplayCount++;
                        }
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -5000) arrayTableDisplay [tableDisplayCount] = "T", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] < -10000000 && arrayFocalPlaneData [counter1][counter2+1] > -11000000){
                            extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                            extract1 = extension.substr(3, 3);
                            extract2 = extension.substr(6, 3);
                            extract1 = to_string(atoi(extract1.c_str()));
                            extract2 = to_string(atoi(extract2.c_str()));
                            
                            arrayTableDisplay [tableDisplayCount] = "r"+extract1+"-"+extract2, tableDisplayCount++;
                        }
                        else if (arrayFocalPlaneData [counter1][counter2+1] < -11000000 && arrayFocalPlaneData [counter1][counter2+1] > -12000000){
                            extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                            extract1 = extension.substr(3, 3);
                            extract2 = extension.substr(6, 3);
                            extract1 = to_string(atoi(extract1.c_str()));
                            extract2 = to_string(atoi(extract2.c_str()));
                            
                            arrayTableDisplay [tableDisplayCount] = "R"+extract1+"-"+extract2, tableDisplayCount++;
                        }
                        else arrayTableDisplay [tableDisplayCount] = "ND", tableDisplayCount++;
                    }
                }
            }
            else{
                
                for (int counter2 = 0; counter2 < 15; counter2++) arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
            }
        }
    }
    
    //for (int counterA = 0; counterA < treatmentNameDisplayCount; counterA++){
    //    for (int counterB = 0; counterB < 17; counterB++) cout<<" "<<arrayTableDisplay [counterA*17+counterB];
    //    cout<<" arrayTableDisplay "<<counterA+1<<endl;
    //}
    
    arrayFileDelete = new string [100];
    fileDeleteCount = 0;
    fileDeleteLimit = 100;
    
    arrayDirectoryInfo = new string [500];
    directoryInfoCount = 0;
    directoryInfoLimit = 500;
    
    backUpDirectoryArray = new string [20];
    backUpDirectoryCount = 0;
    backUpDirectoryLimit = 20;
    
    backUpFolderNoUpDateArray = new string [100];
    backUpFolderNoUpDateCount = 0;
    backUpFolderNoUpDateLimit = 100;
    
    backUpFileArray = new string [1000];
    backUpFileCount = 0;
    backUpFileLimit = 1000;
    
    initialArraySet = 1;
    tableViewCall = 1;
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTermination object:self];
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay object:self];
    controllerTimer = [NSTimer scheduledTimerWithTimeInterval:0.3 target:self selector:@selector(displayData) userInfo:nil repeats:YES];
}

-(void)displayData{
    if (tableViewCall == 1){
        tableViewCall = 0;
        [tableViewList reloadData];
    }
    
    if (tableCallCount == 1){
        tableCallCount = 0;
        rowIndexHold = tableCurrentRowHold;
        
        if (arrayTableDisplay [rowIndexHold*17] != " "){
            if ((int)arrayTableDisplay [rowIndexHold*17].find("CH1") != -1) [channelTypeDisplay setStringValue:@(fluorescentNoName1.c_str())];
            else if ((int)arrayTableDisplay [rowIndexHold*17].find("CH2") != -1) [channelTypeDisplay setStringValue:@(fluorescentNoName2.c_str())];
            else if ((int)arrayTableDisplay [rowIndexHold*17].find("CH3") != -1) [channelTypeDisplay setStringValue:@(fluorescentNoName3.c_str())];
            else if ((int)arrayTableDisplay [rowIndexHold*17].find("CH4") != -1) [channelTypeDisplay setStringValue:@(fluorescentNoName4.c_str())];
            else if ((int)arrayTableDisplay [rowIndexHold*17].find("CH5") != -1) [channelTypeDisplay setStringValue:@(fluorescentNoName5.c_str())];
            else if ((int)arrayTableDisplay [rowIndexHold*17].find("CH6") != -1) [channelTypeDisplay setStringValue:@(fluorescentNoName6.c_str())];
            else [channelTypeDisplay setStringValue:@"DIC"];
        }
    }
    if (tableCallCount > 1) tableCallCount = 0;
    
    if (currentPlaneDisplayCall == 1){
        currentPlaneDisplayCall = 0;
        [currentPlaneDisplay setIntegerValue: planeNumberDisplay+1];
    }
    
    if (backUpTableCallCount == 1){
        backUpTableCallCount = 0;
        backUpTableCurrentRowHold = backUpTableNewRowHold;
    }
    
    if (backUpTableCallCount > 1) backUpTableCallCount = 0;
    
    if ((processMode == 5 || processMode == 7) && imageProcessTiming == 1){
        int instructionFIFlag = 0;
        
        string getString;
        
        ifstream fin;
        fin.open(instructionFIPath2.c_str(),ios::in);
        if (fin.is_open()){
            instructionFIFlag = 1;
            fin.close();
        }
        
        if (instructionFIFlag != 0){
            fin.open(instructionFIPath2.c_str(),ios::in);
            
            getline(fin, getString), autoFolderName = getString;
            
            if ((int)getString.find (bodyName+"-1") != -1){
                autoFolderName = getString;
                imageProcessTiming = 2;
            }
            else if (getString == "Exit") exitFlag = 1;
            
            fin.close();
        }
    }
    else if ((processMode == 5 || processMode == 7) && imageProcessTiming == 2){
        imageProcessTiming = 3;
        [self processStartSub];
    }
    
    if (exitFlag == 1) [self stopProcessMain];
    
    if (timePointRequest == 1){
        timePointRequest = 0;
        [timePointDisplay setIntegerValue:currentTimePoint];
    }
    
    if (progressTiming == 1){
        [progressIndicator setMinValue:0];
        [progressIndicator setMaxValue:progressValue];
        [progressIndicator startAnimation:self];
        [progressIndicator setHidden:NO];
        
        [progressIndicator setDoubleValue:progressValue*0.1];
        [progressIndicator displayIfNeeded];
        
        double bValue = [progressIndicator maxValue];
        
        if (progressIndicator){
            if (bValue == progressValue){
                [progressIndicator setDoubleValue:progressValue*0.1];
                [progressIndicator displayIfNeeded];
                
                double bValue2 = [progressIndicator doubleValue];
                
                if (bValue2 == progressValue*0.1){
                    progressTiming = 2;
                }
            }
        }
    }
    else if (progressTiming == 3){
        [progressIndicator setDoubleValue:progressValue];
        [progressIndicator displayIfNeeded];
        
        double bValue = [progressIndicator doubleValue];
        
        if (bValue == progressValue){
            progressTiming = 4;
        }
    }
    else if (progressTiming == 5){
        [progressIndicator setDoubleValue:0];
        [progressIndicator displayIfNeeded];
        
        double bValue = [progressIndicator doubleValue];
        
        if (bValue == 0){
            progressTiming = 6;
        }
    }
    else if (progressTiming == 7){
        [progressIndicator stopAnimation:self];
        
        if (!progressIndicator){
            progressTiming = 0;
        }
    }
    
    [self communication];
}

-(void)communication{
    //-----Initial establishment-----
    if (firstCommunication == 0){
        firstCommunication = 1;
        basicInfoRead = 2;
    }
    
    if (firstCommunication == 1 && basicInfoRead == 2){
        int receivedData = 0;
        int instructionFIFlag = 0;
        
        string getString = "nil";
        
        ifstream fin;
        fin.open(instructionFIPath.c_str(),ios::in);
        if (fin.is_open()){
            instructionFIFlag = 1;
            fin.close();
        }
        
        if (instructionFIFlag != 0){
            fin.open(instructionFIPath.c_str(),ios::in);
            
            getline(fin, getString);
            
            if (atoi(getString.c_str()) >= 2 && atoi(getString.c_str()) <= 8){
                receivedData = atoi(getString.c_str());
                remove (instructionFIPath.c_str());
            }
            
            fin.close();
        }
        
        if (receivedData != 0){
            processMode = receivedData;
            
            if (processMode == 2 || processMode == 8){
                remove(productsFocalPlanePath.c_str());
                remove(productsFocalTreatmentPath.c_str());
                remove(productsFocalFOVPath.c_str());
                remove(loadingCompletionPath.c_str());
                
                [processModeDisplay setStringValue:@"Init."];
                
                string *arrayWellName = new string [100];
                int *arrayFOVNo = new int [100];
                
                fluorescentCount = 0;
                
                fin.open(nameAssignFilePath.c_str(),ios::in);
                
                if (fin.is_open()){
                    getline(fin, getString);
                    getline(fin, getString);
                    getline(fin, getString);
                    
                    for (int counter1 = 0; counter1 < 16; counter1++){
                        getline(fin, getString);
                        getline(fin, getString);
                        arrayWellName [counter1] = getString;
                        
                        getline(fin, getString);
                        arrayFOVNo [counter1] = atoi(getString.c_str());
                    }
                    
                    getline(fin, getString);
                    getline(fin, getString);
                    getline(fin, getString);
                    getline(fin, getString);
                    getline(fin, getString);
                    getline(fin, getString);
                    
                    for (int counter1 = 0; counter1 < 6; counter1++){
                        getline(fin, getString);
                        
                        if (getString != "nil") fluorescentCount++;
                        
                        getline(fin, getString);
                        getline(fin, getString);
                        
                        if (getString != "0" && counter1 == 0) fluorescentNo1 = getString;
                        if (getString != "0" && counter1 == 1) fluorescentNo2 = getString;
                        if (getString != "0" && counter1 == 2) fluorescentNo3 = getString;
                        if (getString != "0" && counter1 == 3) fluorescentNo4 = getString;
                        if (getString != "0" && counter1 == 4) fluorescentNo5 = getString;
                        if (getString != "0" && counter1 == 5) fluorescentNo6 = getString;
                    }
                    
                    fin.close();
                }
                
                treatmentNameDisplayCount = 0;
                fOVNameDisplayCount = 0;
                
                arrayTreatmentNameDisplay [0] = "ND", treatmentNameDisplayCount++;
                arrayFOVNameDisplay [0] = "ND", fOVNameDisplayCount++;
                
                string extension;
                
                for (int counter1 = 0; counter1 < 16; counter1++){
                    if (arrayFOVNo [counter1] != 0){
                        arrayTreatmentNameDisplay [treatmentNameDisplayCount] = arrayWellName [counter1], treatmentNameDisplayCount++;
                        arrayFOVNameDisplay [fOVNameDisplayCount] = "FOV1", fOVNameDisplayCount++;
                        
                        for (int counter2 = 1; counter2 < arrayFOVNo [counter1]; counter2++){
                            extension = to_string(counter2+1);
                            
                            arrayTreatmentNameDisplay [treatmentNameDisplayCount] = "ND", treatmentNameDisplayCount++;
                            arrayFOVNameDisplay [fOVNameDisplayCount] = "FOV"+extension, fOVNameDisplayCount++;
                        }
                        
                        if (fluorescentCount >= 1){
                            arrayTreatmentNameDisplay [treatmentNameDisplayCount] = arrayWellName [counter1]+"CH1", treatmentNameDisplayCount++;
                            arrayFOVNameDisplay [fOVNameDisplayCount] = "CH1-1", fOVNameDisplayCount++;
                            
                            for (int counter2 = 1; counter2 < arrayFOVNo [counter1]; counter2++){
                                extension = to_string(counter2+1);
                                
                                arrayTreatmentNameDisplay [treatmentNameDisplayCount] = "ND", treatmentNameDisplayCount++;
                                arrayFOVNameDisplay [fOVNameDisplayCount] = "CH1-"+extension, fOVNameDisplayCount++;
                            }
                        }
                        
                        if (fluorescentCount >= 2){
                            arrayTreatmentNameDisplay [treatmentNameDisplayCount] = arrayWellName [counter1]+"CH2", treatmentNameDisplayCount++;
                            arrayFOVNameDisplay [fOVNameDisplayCount] = "CH2-1", fOVNameDisplayCount++;
                            
                            for (int counter2 = 1; counter2 < arrayFOVNo [counter1]; counter2++){
                                extension = to_string(counter2+1);
                                
                                arrayTreatmentNameDisplay [treatmentNameDisplayCount] = "ND", treatmentNameDisplayCount++;
                                arrayFOVNameDisplay [fOVNameDisplayCount] = "CH2-"+extension, fOVNameDisplayCount++;
                            }
                        }
                        
                        if (fluorescentCount >= 3){
                            arrayTreatmentNameDisplay [treatmentNameDisplayCount] = arrayWellName [counter1]+"CH3", treatmentNameDisplayCount++;
                            arrayFOVNameDisplay [fOVNameDisplayCount] = "CH3-1", fOVNameDisplayCount++;
                            
                            for (int counter2 = 1; counter2 < arrayFOVNo [counter1]; counter2++){
                                extension = to_string(counter2+1);
                                
                                arrayTreatmentNameDisplay [treatmentNameDisplayCount] = "ND", treatmentNameDisplayCount++;
                                arrayFOVNameDisplay [fOVNameDisplayCount] =  "CH3-"+extension, fOVNameDisplayCount++;
                            }
                        }
                        
                        if (fluorescentCount >= 4){
                            arrayTreatmentNameDisplay [treatmentNameDisplayCount] = arrayWellName [counter1]+"CH4", treatmentNameDisplayCount++;
                            arrayFOVNameDisplay [fOVNameDisplayCount] = "CH4-1", fOVNameDisplayCount++;
                            
                            for (int counter2 = 1; counter2 < arrayFOVNo [counter1]; counter2++){
                                extension = to_string(counter2+1);
                                
                                arrayTreatmentNameDisplay [treatmentNameDisplayCount] = "ND", treatmentNameDisplayCount++;
                                arrayFOVNameDisplay [fOVNameDisplayCount] =  "CH4-"+extension, fOVNameDisplayCount++;
                            }
                        }
                        
                        if (fluorescentCount >= 5){
                            arrayTreatmentNameDisplay [treatmentNameDisplayCount] = arrayWellName [counter1]+"CH5", treatmentNameDisplayCount++;
                            arrayFOVNameDisplay [fOVNameDisplayCount] = "CH5-1", fOVNameDisplayCount++;
                            
                            for (int counter2 = 1; counter2 < arrayFOVNo [counter1]; counter2++){
                                extension = to_string(counter2+1);
                                
                                arrayTreatmentNameDisplay [treatmentNameDisplayCount] = "ND", treatmentNameDisplayCount++;
                                arrayFOVNameDisplay [fOVNameDisplayCount] =  "CH5-"+extension, fOVNameDisplayCount++;
                            }
                        }
                        
                        if (fluorescentCount == 6){
                            arrayTreatmentNameDisplay [treatmentNameDisplayCount] = arrayWellName [counter1]+"CH6", treatmentNameDisplayCount++;
                            arrayFOVNameDisplay [fOVNameDisplayCount] = "CH6-1", fOVNameDisplayCount++;
                            
                            for (int counter2 = 1; counter2 < arrayFOVNo [counter1]; counter2++){
                                extension = to_string(counter2+1);
                                
                                arrayTreatmentNameDisplay [treatmentNameDisplayCount] = "ND", treatmentNameDisplayCount++;
                                arrayFOVNameDisplay [fOVNameDisplayCount] =  "CH6-"+extension, fOVNameDisplayCount++;
                            }
                        }
                        
                        arrayTreatmentNameDisplay [treatmentNameDisplayCount] = "ND", treatmentNameDisplayCount++;
                        arrayFOVNameDisplay [fOVNameDisplayCount] =  "ND", fOVNameDisplayCount++;
                    }
                }
                
                //for (int counterA = 0; counterA < treatmentNameDisplayCount; counterA++){
                //    cout<<counterA<<" "<<arrayTreatmentNameDisplay [counterA]<<" Treat"<<endl;
                //}
                
                //for (int counterA = 0; counterA < fOVNameDisplayCount; counterA++){
                //    cout<<counterA<<" "<<arrayFOVNameDisplay [counterA]<<" FOV"<<endl;
                //}
                
                treatmentNameDisplayCount--;
                fOVNameDisplayCount--;
                
                ofstream oin;
                oin.open(productsFocalTreatmentPath.c_str(), ios::out);
                
                for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++) oin<<arrayTreatmentNameDisplay [counter1]<<endl;
                
                oin.close();
                
                oin.open(productsFocalFOVPath.c_str(), ios::out);
                
                for (int counter1 = 0; counter1 < fOVNameDisplayCount; counter1++) oin<<arrayFOVNameDisplay [counter1]<<endl;
                
                oin.close();
                
                delete [] arrayWellName;
                delete [] arrayFOVNo;
                
                currentTimePoint = 1;
                importTableEnd = -1;
                
                [self saveParameter];
                
                tableDisplayCount = 0;
                currentTableHead = 2;
                
                arrayTableDisplay [tableDisplayCount] = "Name", tableDisplayCount++;
                arrayTableDisplay [tableDisplayCount] = "FOV", tableDisplayCount++;
                arrayTableDisplay [tableDisplayCount] = "C1", tableDisplayCount++;
                
                for (int counter1 = 3; counter1 < 17; counter1++){
                    extension = to_string(counter1-1);
                    arrayTableDisplay [tableDisplayCount] = "T"+extension, tableDisplayCount++;
                }
                
                for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                    if (arrayTreatmentNameDisplay [counter1] != "ND") arrayTableDisplay [tableDisplayCount] = arrayTreatmentNameDisplay [counter1], tableDisplayCount++;
                    else arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
                    
                    if (arrayFOVNameDisplay [counter1] != "ND") arrayTableDisplay [tableDisplayCount] = arrayFOVNameDisplay [counter1], tableDisplayCount++;
                    else arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
                    
                    if (arrayFOVNameDisplay [counter1] != "ND"){
                        arrayTableDisplay [tableDisplayCount] = "ND", tableDisplayCount++;
                        
                        for (int counter2 = 0; counter2 < 14; counter2++) arrayTableDisplay [tableDisplayCount] = "0", tableDisplayCount++;
                    }
                    else{
                        
                        for (int counter2 = 0; counter2 < 15; counter2++) arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
                    }
                }
                
                //for (int counterA = 0; counterA < treatmentNameDisplayCount; counterA++){
                //    for (int counterB = 0; counterB < 17; counterB++) cout<<" "<<arrayTableDisplay [counterA*17+counterB];
                //    cout<<" arrayTableDisplay "<<counterA+1<<endl;
                //}
                
                tableViewCall = 1;
            }
            else if (processMode == 3 || processMode == 9) [processModeDisplay setStringValue:@"Init."];
            else if (processMode == 4) [processModeDisplay setStringValue:@"Batch (BK)"];
            else if (processMode == 5){
                [processModeDisplay setStringValue:@"Batch (BK)"];
                imageProcessTiming = 1;
            }
            else if (processMode == 6) [processModeDisplay setStringValue:@"Auto"];
            else if (processMode == 7){
                [processModeDisplay setStringValue:@"Auto"];
                imageProcessTiming = 1;
            }
            
            if (processMode == 5 || processMode == 7) [NSApp miniaturizeAll:self];
            
            basicInfoRead = 3;
        }
    }
    
    if (firstCommunication == 1 && basicInfoRead == 3){
        basicInfoRead = 4;
    }
}

-(int)numberOfRowsInTableView:(NSTableView *)aTableView{
    int tableViewContent = tableDisplayCount/17;
    return tableViewContent;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    NSAttributedString *attrStr;
    
    if (initialArraySet == 1){
        string displayData1 = arrayTableDisplay [rowIndex*17];
        string displayData2 = arrayTableDisplay [rowIndex*17+1];
        string displayData3 = arrayTableDisplay [rowIndex*17+2];
        string displayData4 = arrayTableDisplay [rowIndex*17+3];
        string displayData5 = arrayTableDisplay [rowIndex*17+4];
        string displayData6 = arrayTableDisplay [rowIndex*17+5];
        string displayData7 = arrayTableDisplay [rowIndex*17+6];
        string displayData8 = arrayTableDisplay [rowIndex*17+7];
        string displayData9 = arrayTableDisplay [rowIndex*17+8];
        string displayData10 = arrayTableDisplay [rowIndex*17+9];
        string displayData11 = arrayTableDisplay [rowIndex*17+10];
        string displayData12 = arrayTableDisplay [rowIndex*17+11];
        string displayData13 = arrayTableDisplay [rowIndex*17+12];
        string displayData14 = arrayTableDisplay [rowIndex*17+13];
        string displayData15 = arrayTableDisplay [rowIndex*17+14];
        string displayData16 = arrayTableDisplay [rowIndex*17+15];
        string displayData17 = arrayTableDisplay [rowIndex*17+16];
        
        int findString3 = (int)displayData3.find("C");
        int findString4 = (int)displayData4.find("C");
        int findString5 = (int)displayData5.find("C");
        int findString6 = (int)displayData6.find("C");
        int findString7 = (int)displayData7.find("C");
        int findString8 = (int)displayData8.find("C");
        int findString9 = (int)displayData9.find("C");
        int findString10 = (int)displayData10.find("C");
        int findString11 = (int)displayData11.find("C");
        int findString12 = (int)displayData12.find("C");
        int findString13 = (int)displayData13.find("C");
        int findString14 = (int)displayData14.find("C");
        int findString15 = (int)displayData15.find("C");
        int findString16 = (int)displayData16.find("C");
        int findString17 = (int)displayData17.find("C");
        
        int findString23 = (int)displayData3.find("-");
        if (findString23 == -1 && (displayData3.find("a") || displayData3.find("f"))) findString23 = 10;
        
        int findString24 = (int)displayData4.find("-");
        if (findString24 == -1 && (displayData4.find("a") || displayData4.find("f"))) findString24 = 10;
        
        int findString25 = (int)displayData5.find("-");
        if (findString25 == -1 && (displayData5.find("a") || displayData5.find("f"))) findString25 = 10;
        
        int findString26 = (int)displayData6.find("-");
        if (findString26 == -1 && (displayData6.find("a") || displayData6.find("f"))) findString26 = 10;
        
        int findString27 = (int)displayData7.find("-");
        if (findString27 == -1 && (displayData7.find("a") || displayData7.find("f"))) findString27 = 10;
        
        int findString28 = (int)displayData8.find("-");
        if (findString28 == -1 && (displayData8.find("a") || displayData8.find("f"))) findString28 = 10;
        
        int findString29 = (int)displayData9.find("-");
        if (findString29 == -1 && (displayData9.find("a") || displayData9.find("f"))) findString29 = 10;
        
        int findString30 = (int)displayData10.find("-");
        if (findString30 == -1 && (displayData10.find("a") || displayData10.find("f"))) findString30 = 10;
        
        int findString31 = (int)displayData11.find("-");
        if (findString31 == -1 && (displayData11.find("a") || displayData11.find("f"))) findString31 = 10;
        
        int findString32 = (int)displayData12.find("-");
        if (findString32 == -1 && (displayData12.find("a") || displayData12.find("f"))) findString32 = 10;
        
        int findString33 = (int)displayData13.find("-");
        if (findString33 == -1 && (displayData13.find("a") || displayData13.find("f"))) findString33 = 10;
        
        int findString34 = (int)displayData14.find("-");
        if (findString34 == -1 && (displayData14.find("a") || displayData14.find("f"))) findString34 = 10;
        
        int findString35 = (int)displayData15.find("-");
        if (findString35 == -1 && (displayData15.find("a") || displayData15.find("f"))) findString35 = 10;
        
        int findString36 = (int)displayData16.find("-");
        if (findString36 == -1 && (displayData16.find("a") || displayData16.find("f"))) findString36 = 10;
        
        int findString37 = (int)displayData17.find("-");
        if (findString37 == -1 && (displayData17.find("a") || displayData17.find("f"))) findString37 = 10;
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        
        [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
        [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"] && rowIndex != 0){
            [attributes setObject:[NSFont boldSystemFontOfSize:10] forKey:NSFontAttributeName];
            [attributes setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL1"] && rowIndex == 0){
            [attributes setObject:[NSFont boldSystemFontOfSize:10] forKey:NSFontAttributeName];
            [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && rowIndex != 0){
            [attributes setObject:[NSFont boldSystemFontOfSize:10] forKey:NSFontAttributeName];
            [attributes setObject:[NSColor purpleColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData2.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && rowIndex == 0){
            [attributes setObject:[NSFont boldSystemFontOfSize:10] forKey:NSFontAttributeName];
            [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData2.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL3"] && rowIndex != 0){
            if (currentTableHead == 2) [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
            else [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            
            if (findString23 == 10) [attributes setObject:[NSFont systemFontOfSize:11] forKey:NSFontAttributeName];
            else if (findString23 != -1) [attributes setObject:[NSFont systemFontOfSize:9] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData3.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL3"] && rowIndex == 0){
            if (findString3 == -1) [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            else [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
            
            if (findString23 == 10) [attributes setObject:[NSFont systemFontOfSize:11] forKey:NSFontAttributeName];
            else if (findString23 != -1) [attributes setObject:[NSFont systemFontOfSize:9] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData3.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL4"] && rowIndex != 0){
            if (currentTableHead == 3) [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
            else [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            
            if (findString24 == 10) [attributes setObject:[NSFont systemFontOfSize:11] forKey:NSFontAttributeName];
            else if (findString24 != -1) [attributes setObject:[NSFont systemFontOfSize:9] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData4.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL4"] && rowIndex == 0){
            if (findString4 == -1) [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            else [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
            
            if (findString24 == 10) [attributes setObject:[NSFont systemFontOfSize:11] forKey:NSFontAttributeName];
            else if (findString24 != -1) [attributes setObject:[NSFont systemFontOfSize:9] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData4.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL5"] && rowIndex != 0){
            if (currentTableHead == 4) [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
            else [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            
            if (findString25 == 10) [attributes setObject:[NSFont systemFontOfSize:11] forKey:NSFontAttributeName];
            else if (findString25 != -1) [attributes setObject:[NSFont systemFontOfSize:9] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData5.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL5"] && rowIndex == 0){
            if (findString5 == -1) [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            else [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
            
            if (findString25 == 10) [attributes setObject:[NSFont systemFontOfSize:11] forKey:NSFontAttributeName];
            else if (findString25 != -1) [attributes setObject:[NSFont systemFontOfSize:9] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData5.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL6"] && rowIndex != 0){
            if (currentTableHead == 5) [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
            else [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            
            if (findString26 == 10) [attributes setObject:[NSFont systemFontOfSize:11] forKey:NSFontAttributeName];
            else if (findString26 != -1) [attributes setObject:[NSFont systemFontOfSize:9] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData6.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL6"] && rowIndex == 0){
            if (findString6 == -1) [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            else [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
            
            if (findString26 == 10) [attributes setObject:[NSFont systemFontOfSize:11] forKey:NSFontAttributeName];
            else if (findString26 != -1) [attributes setObject:[NSFont systemFontOfSize:9] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData6.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL7"] && rowIndex != 0){
            if (currentTableHead == 6) [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
            else [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            
            if (findString27 == 10) [attributes setObject:[NSFont systemFontOfSize:11] forKey:NSFontAttributeName];
            else if (findString27 != -1) [attributes setObject:[NSFont systemFontOfSize:9] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData7.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL7"] && rowIndex == 0){
            if (findString7 == -1) [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            else [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
            
            if (findString27 == 10) [attributes setObject:[NSFont systemFontOfSize:11] forKey:NSFontAttributeName];
            else if (findString27 != -1) [attributes setObject:[NSFont systemFontOfSize:9] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData7.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL8"] && rowIndex != 0){
            if (currentTableHead == 7) [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
            else [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            
            if (findString28 == 10) [attributes setObject:[NSFont systemFontOfSize:11] forKey:NSFontAttributeName];
            else if (findString28 != -1) [attributes setObject:[NSFont systemFontOfSize:9] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData8.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL8"] && rowIndex == 0){
            if (findString8 == -1) [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            else [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
            
            if (findString28 == 10) [attributes setObject:[NSFont systemFontOfSize:11] forKey:NSFontAttributeName];
            else if (findString28 != -1) [attributes setObject:[NSFont systemFontOfSize:9] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData8.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL9"] && rowIndex != 0){
            if (currentTableHead == 8) [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
            else [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            
            if (findString29 == 10) [attributes setObject:[NSFont systemFontOfSize:11] forKey:NSFontAttributeName];
            else if (findString29 != -1) [attributes setObject:[NSFont systemFontOfSize:9] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData9.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL9"] && rowIndex == 0){
            if (findString9 == -1) [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            else [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
            
            if (findString29 == 10) [attributes setObject:[NSFont systemFontOfSize:11] forKey:NSFontAttributeName];
            else if (findString29 != -1) [attributes setObject:[NSFont systemFontOfSize:9] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData9.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL10"] && rowIndex != 0){
            if (currentTableHead == 9) [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
            else [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            
            if (findString30 == 10) [attributes setObject:[NSFont systemFontOfSize:11] forKey:NSFontAttributeName];
            else if (findString30 != -1) [attributes setObject:[NSFont systemFontOfSize:9] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData10.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL10"] && rowIndex == 0){
            if (findString10 == -1) [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            else [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
            
            if (findString30 == 10) [attributes setObject:[NSFont systemFontOfSize:11] forKey:NSFontAttributeName];
            else if (findString30 != -1) [attributes setObject:[NSFont systemFontOfSize:9] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData10.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL11"] && rowIndex != 0){
            if (currentTableHead == 10) [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
            else [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            
            if (findString31 == 10) [attributes setObject:[NSFont systemFontOfSize:11] forKey:NSFontAttributeName];
            else if (findString31 != -1) [attributes setObject:[NSFont systemFontOfSize:9] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData11.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL11"] && rowIndex == 0){
            if (findString11 == -1) [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            else [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
            
            if (findString31 == 10) [attributes setObject:[NSFont systemFontOfSize:11] forKey:NSFontAttributeName];
            else if (findString31 != -1) [attributes setObject:[NSFont systemFontOfSize:9] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData11.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL12"] && rowIndex != 0){
            if (currentTableHead == 11) [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
            else [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            
            if (findString32 == 10) [attributes setObject:[NSFont systemFontOfSize:11] forKey:NSFontAttributeName];
            else if (findString32 != -1) [attributes setObject:[NSFont systemFontOfSize:9] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData12.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL12"] && rowIndex == 0){
            if (findString12 == -1) [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            else [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
            
            if (findString32 == 10) [attributes setObject:[NSFont systemFontOfSize:11] forKey:NSFontAttributeName];
            else if (findString32 != -1) [attributes setObject:[NSFont systemFontOfSize:9] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData12.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL13"] && rowIndex != 0){
            if (currentTableHead == 12) [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
            else [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            
            if (findString33 == 10) [attributes setObject:[NSFont systemFontOfSize:11] forKey:NSFontAttributeName];
            else if (findString33 != -1) [attributes setObject:[NSFont systemFontOfSize:9] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData13.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL13"] && rowIndex == 0){
            if (findString13 == -1) [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            else [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
            
            if (findString33 == 10) [attributes setObject:[NSFont systemFontOfSize:11] forKey:NSFontAttributeName];
            else if (findString33 != -1) [attributes setObject:[NSFont systemFontOfSize:9] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData13.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL14"] && rowIndex != 0){
            if (currentTableHead == 13) [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
            else [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            
            if (findString34 == 10) [attributes setObject:[NSFont systemFontOfSize:11] forKey:NSFontAttributeName];
            else if (findString34 != -1) [attributes setObject:[NSFont systemFontOfSize:9] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData14.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL14"] && rowIndex == 0){
            if (findString14 == -1) [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            else [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
            
            if (findString34 == 10) [attributes setObject:[NSFont systemFontOfSize:11] forKey:NSFontAttributeName];
            else if (findString34 != -1) [attributes setObject:[NSFont systemFontOfSize:9] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData14.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL15"] && rowIndex != 0){
            if (currentTableHead == 14) [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
            else [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            
            if (findString35 == 10) [attributes setObject:[NSFont systemFontOfSize:11] forKey:NSFontAttributeName];
            else if (findString35 != -1) [attributes setObject:[NSFont systemFontOfSize:9] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData15.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL15"] && rowIndex == 0){
            if (findString15 == -1) [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            else [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
            
            if (findString35 == 10) [attributes setObject:[NSFont systemFontOfSize:11] forKey:NSFontAttributeName];
            else if (findString35 != -1) [attributes setObject:[NSFont systemFontOfSize:9] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData15.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL16"] && rowIndex != 0){
            if (currentTableHead == 15) [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
            else [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            
            if (findString36 == 10) [attributes setObject:[NSFont systemFontOfSize:11] forKey:NSFontAttributeName];
            else if (findString36 != -1) [attributes setObject:[NSFont systemFontOfSize:9] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData16.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL16"] && rowIndex == 0){
            if (findString16 == -1) [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            else [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
            
            if (findString36 == 10) [attributes setObject:[NSFont systemFontOfSize:11] forKey:NSFontAttributeName];
            else if (findString36 != -1) [attributes setObject:[NSFont systemFontOfSize:9] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData16.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL17"] && rowIndex != 0){
            if (currentTableHead == 16) [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
            else [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            
            if (findString37 == 10) [attributes setObject:[NSFont systemFontOfSize:11] forKey:NSFontAttributeName];
            else if (findString37 != -1) [attributes setObject:[NSFont systemFontOfSize:9] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData17.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL17"] && rowIndex == 0){
            if (findString17 == -1) [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            else [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
            
            if (findString37 == 10) [attributes setObject:[NSFont systemFontOfSize:11] forKey:NSFontAttributeName];
            else if (findString37 != -1) [attributes setObject:[NSFont systemFontOfSize:9] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData17.c_str()) attributes:attributes];
        }
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    else{
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL3"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL4"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL5"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL6"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL7"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL8"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL9"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL10"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL11"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL12"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL13"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL14"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL15"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL16"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL17"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    
    return attrStr;
}

-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex{
    tableCallCount++;
    
    if (tableCallCount == 2) tableCurrentRowHold = rowIndexHold;
    else if (tableCallCount == 1) tableCurrentRowHold = rowIndex;
    
    return YES;
}

-(void)tableView:(NSTableView *)aTableView setObjectValue:(id)anObject forTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    NSString *columnIdentifier = [aTableColumn identifier];
    NSString *objectInfo = anObject;
    
    //NSLog (@"%@", columnIdentifier);
    //NSLog (@"%@", objectInfo);
    
    int columnNo = 3;
    
    if ([columnIdentifier isEqualToString:@"COL3"]) columnNo = 3;
    else if ([columnIdentifier isEqualToString:@"COL4"]) columnNo = 4;
    else if ([columnIdentifier isEqualToString:@"COL5"]) columnNo = 5;
    else if ([columnIdentifier isEqualToString:@"COL6"]) columnNo = 6;
    else if ([columnIdentifier isEqualToString:@"COL7"]) columnNo = 7;
    else if ([columnIdentifier isEqualToString:@"COL8"]) columnNo = 8;
    else if ([columnIdentifier isEqualToString:@"COL9"]) columnNo = 9;
    else if ([columnIdentifier isEqualToString:@"COL10"]) columnNo = 10;
    else if ([columnIdentifier isEqualToString:@"COL11"]) columnNo = 11;
    else if ([columnIdentifier isEqualToString:@"COL12"]) columnNo = 12;
    else if ([columnIdentifier isEqualToString:@"COL13"]) columnNo = 13;
    else if ([columnIdentifier isEqualToString:@"COL14"]) columnNo = 14;
    else if ([columnIdentifier isEqualToString:@"COL15"]) columnNo = 15;
    else if ([columnIdentifier isEqualToString:@"COL16"]) columnNo = 16;
    else if ([columnIdentifier isEqualToString:@"COL17"]) columnNo = 17;
    
    string stringExtract = arrayTableDisplay [columnNo-1].substr(1);
    
    if (columnNo >= 3 && columnNo <= 17 && rowIndex >= 1 && focusProcessFlag == 0){
        if (atoi(stringExtract.c_str()) <= currentTimePoint || atoi(stringExtract.c_str()) < importTableEnd){
            string extension;
            string objectString = [objectInfo UTF8String];
            
            int findString3 = (int)objectString.find("P");
            int findString4 = (int)objectString.find("p");
            int findString5 = (int)objectString.find("S");
            int findString6 = (int)objectString.find("s");
            int findString7 = (int)objectString.find("R");
            int findString8 = (int)objectString.find("r");
            
            int findString9 = (int)objectString.find("lP");
            int findString10 = (int)objectString.find("lp");
            int findString11 = (int)objectString.find("lS");
            int findString12 = (int)objectString.find("ls");
            int findString13 = (int)objectString.find("lR");
            int findString14 = (int)objectString.find("lr");
            
            if (findString9 != -1 || findString10 != -1 || findString11 != -1 || findString12 != -1 || findString13 != -1 || findString14 != -1) stringExtract = objectString.substr(2);
            else if (findString3 != -1 || findString4 != -1 || findString5 != -1 || findString6 != -1 || findString7 != -1 || findString8 != -1) stringExtract = objectString.substr(1);
            
            if (arrayTableDisplay [rowIndex*17+columnNo-1] != "0" && arrayTableDisplay [rowIndex*17+columnNo-1] != " " && arrayTableDisplay [rowIndex*17+columnNo-1] != "*" && arrayTableDisplay [rowIndex*17+columnNo-1] != "T"){
                if (objectString == "a" || objectString == "la"){
                    if (objectString == "a") arrayTableDisplay [rowIndex*17+columnNo-1] = "a";
                    else if (objectString == "la") arrayTableDisplay [rowIndex*17+columnNo-1] = "%a";
                    
                    lastColumnNoHold = columnNo;
                    lastRowNoHold = (int)rowIndex;
                    lastTypeHold = arrayTableDisplay [rowIndex*17+columnNo-1];
                    
                    [self tableDataSave];
                    tableViewCall = 1;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else if (objectString == "A" || objectString == "lA"){
                    if (objectString == "A") arrayTableDisplay [rowIndex*17+columnNo-1] = "A";
                    else if (objectString == "lA") arrayTableDisplay [rowIndex*17+columnNo-1] = "%A";
                    
                    lastColumnNoHold = columnNo;
                    lastRowNoHold = (int)rowIndex;
                    lastTypeHold = arrayTableDisplay [rowIndex*17+columnNo-1];
                    
                    [self tableDataSave];
                    tableViewCall = 1;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else if (objectString == "f" || objectString == "lf"){
                    if (objectString == "f") arrayTableDisplay [rowIndex*17+columnNo-1] = "f";
                    else if (objectString == "lf") arrayTableDisplay [rowIndex*17+columnNo-1] = "%f";
                    
                    lastColumnNoHold = columnNo;
                    lastRowNoHold = (int)rowIndex;
                    lastTypeHold = arrayTableDisplay [rowIndex*17+columnNo-1];
                    
                    [self tableDataSave];
                    tableViewCall = 1;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else if (objectString == "F" || objectString == "lF"){
                    if (objectString == "F") arrayTableDisplay [rowIndex*17+columnNo-1] = "F";
                    else if (objectString == "lF") arrayTableDisplay [rowIndex*17+columnNo-1] = "%F";
                    
                    lastColumnNoHold = columnNo;
                    lastRowNoHold = (int)rowIndex;
                    lastTypeHold = arrayTableDisplay [rowIndex*17+columnNo-1];
                    
                    [self tableDataSave];
                    tableViewCall = 1;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else if (findString3 != -1 && findString9 == -1 && atoi(stringExtract.c_str()) > 0 && atoi(stringExtract.c_str()) < 200){
                    extension = to_string(atoi(stringExtract.c_str()));
                    
                    arrayTableDisplay [rowIndex*17+columnNo-1] = "P"+extension;
                    
                    lastColumnNoHold = columnNo;
                    lastRowNoHold = (int)rowIndex;
                    lastTypeHold = arrayTableDisplay [rowIndex*17+columnNo-1];
                    
                    [self tableDataSave];
                    tableViewCall = 1;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else if (findString9 != -1 && atoi(stringExtract.c_str()) > 0 && atoi(stringExtract.c_str()) < 200){
                    extension = to_string(atoi(stringExtract.c_str()));
                    
                    arrayTableDisplay [rowIndex*17+columnNo-1] = "%P"+extension;
                    
                    lastColumnNoHold = columnNo;
                    lastRowNoHold = (int)rowIndex;
                    lastTypeHold = arrayTableDisplay [rowIndex*17+columnNo-1];
                    
                    [self tableDataSave];
                    tableViewCall = 1;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else if (findString4 != -1 && findString10 == -1 && atoi(stringExtract.c_str()) > 0 && atoi(stringExtract.c_str()) < 200){
                    extension = to_string(atoi(stringExtract.c_str()));
                    
                    arrayTableDisplay [rowIndex*17+columnNo-1] = "p"+extension;
                    
                    lastColumnNoHold = columnNo;
                    lastRowNoHold = (int)rowIndex;
                    lastTypeHold = arrayTableDisplay [rowIndex*17+columnNo-1];
                    
                    [self tableDataSave];
                    tableViewCall = 1;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else if (findString10 != -1 && atoi(stringExtract.c_str()) > 0 && atoi(stringExtract.c_str()) < 200){
                    extension = to_string(atoi(stringExtract.c_str()));
                    
                    arrayTableDisplay [rowIndex*17+columnNo-1] = "%p"+extension;
                    
                    lastColumnNoHold = columnNo;
                    lastRowNoHold = (int)rowIndex;
                    lastTypeHold = arrayTableDisplay [rowIndex*17+columnNo-1];
                    
                    [self tableDataSave];
                    tableViewCall = 1;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else if (findString5 != -1 && findString11 == -1 && atoi(stringExtract.c_str()) > 0 && atoi(stringExtract.c_str()) < 200){
                    extension = to_string(atoi(stringExtract.c_str()));
                    
                    arrayTableDisplay [rowIndex*17+columnNo-1] = "S"+extension;
                    
                    lastColumnNoHold = columnNo;
                    lastRowNoHold = (int)rowIndex;
                    lastTypeHold = arrayTableDisplay [rowIndex*17+columnNo-1];
                    
                    [self tableDataSave];
                    tableViewCall = 1;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else if (findString11 != -1 && atoi(stringExtract.c_str()) > 0 && atoi(stringExtract.c_str()) < 200){
                    extension = to_string(atoi(stringExtract.c_str()));
                    
                    arrayTableDisplay [rowIndex*17+columnNo-1] = "%S"+extension;
                    
                    lastColumnNoHold = columnNo;
                    lastRowNoHold = (int)rowIndex;
                    lastTypeHold = arrayTableDisplay [rowIndex*17+columnNo-1];
                    
                    [self tableDataSave];
                    tableViewCall = 1;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else if (findString6 != -1 && findString12 == -1 && atoi(stringExtract.c_str()) > 0 && atoi(stringExtract.c_str()) < 200){
                    extension = to_string(atoi(stringExtract.c_str()));
                    
                    arrayTableDisplay [rowIndex*17+columnNo-1] = "s"+extension;
                    
                    lastColumnNoHold = columnNo;
                    lastRowNoHold = (int)rowIndex;
                    lastTypeHold = arrayTableDisplay [rowIndex*17+columnNo-1];
                    
                    [self tableDataSave];
                    tableViewCall = 1;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else if (findString12 != -1 && atoi(stringExtract.c_str()) > 0 && atoi(stringExtract.c_str()) < 200){
                    extension = to_string(atoi(stringExtract.c_str()));
                    
                    arrayTableDisplay [rowIndex*17+columnNo-1] = "%s"+extension;
                    
                    lastColumnNoHold = columnNo;
                    lastRowNoHold = (int)rowIndex;
                    lastTypeHold = arrayTableDisplay [rowIndex*17+columnNo-1];
                    
                    [self tableDataSave];
                    tableViewCall = 1;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else if (findString7 != -1 && findString13 == -1){
                    string numberStart;
                    string numberEnd;
                    
                    if ((int)stringExtract.find("-") != -1){
                        numberStart = stringExtract.substr(0, stringExtract.find("-"));
                        numberEnd = stringExtract.substr(stringExtract.find("-")+1);
                        
                        if (atoi(numberStart.c_str()) > 0 && atoi(numberStart.c_str()) < 200 && atoi(numberEnd.c_str()) > 0 && atoi(numberEnd.c_str()) < 200 && atoi(numberStart.c_str()) < atoi(numberEnd.c_str()) && atoi(numberEnd.c_str())-atoi(numberStart.c_str()) >= 5){
                            extension = to_string(atoi(numberStart.c_str()));
                            string extension2 = to_string(atoi(numberEnd.c_str()));
                            
                            arrayTableDisplay [rowIndex*17+columnNo-1] = "R"+extension+"-"+extension2;
                            
                            lastColumnNoHold = columnNo;
                            lastRowNoHold = (int)rowIndex;
                            lastTypeHold = arrayTableDisplay [rowIndex*17+columnNo-1];
                            
                            [self tableDataSave];
                            tableViewCall = 1;
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                        else{
                            
                            lastColumnNoHold = 0;
                            lastRowNoHold = 0;
                            lastTypeHold = "X";
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else{
                        
                        lastColumnNoHold = 0;
                        lastRowNoHold = 0;
                        lastTypeHold = "X";
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else if (findString13 != -1){
                    string numberStart;
                    string numberEnd;
                    
                    if ((int)stringExtract.find("-") != -1){
                        numberStart = stringExtract.substr(0, stringExtract.find("-"));
                        numberEnd = stringExtract.substr(stringExtract.find("-")+1);
                        
                        if (atoi(numberStart.c_str()) > 0 && atoi(numberStart.c_str()) < 200 && atoi(numberEnd.c_str()) > 0 && atoi(numberEnd.c_str()) < 200 && atoi(numberStart.c_str()) < atoi(numberEnd.c_str()) && atoi(numberEnd.c_str())-atoi(numberStart.c_str()) >= 5){
                            extension = to_string(atoi(numberStart.c_str()));
                            string extension2 = to_string(atoi(numberEnd.c_str()));
                            
                            arrayTableDisplay [rowIndex*17+columnNo-1] = "%R"+extension+"-"+extension2;
                            
                            lastColumnNoHold = columnNo;
                            lastRowNoHold = (int)rowIndex;
                            lastTypeHold = arrayTableDisplay [rowIndex*17+columnNo-1];
                            
                            [self tableDataSave];
                            tableViewCall = 1;
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                        else{
                            
                            lastColumnNoHold = 0;
                            lastRowNoHold = 0;
                            lastTypeHold = "X";
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else{
                        
                        lastColumnNoHold = 0;
                        lastRowNoHold = 0;
                        lastTypeHold = "X";
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else if (findString8 != -1 && findString14 == -1){
                    string numberStart;
                    string numberEnd;
                    
                    if ((int)stringExtract.find("-") != -1){
                        numberStart = stringExtract.substr(0, stringExtract.find("-"));
                        numberEnd = stringExtract.substr(stringExtract.find("-")+1);
                        
                        if (atoi(numberStart.c_str()) > 0 && atoi(numberStart.c_str()) < 200 && atoi(numberEnd.c_str()) > 0 && atoi(numberEnd.c_str()) < 200 && atoi(numberStart.c_str()) < atoi(numberEnd.c_str()) && atoi(numberEnd.c_str())-atoi(numberStart.c_str()) >= 5){
                            extension = to_string(atoi(numberStart.c_str()));
                            string extension2 = to_string(atoi(numberEnd.c_str()));
                            
                            arrayTableDisplay [rowIndex*17+columnNo-1] = "r"+extension+"-"+extension2;
                            
                            lastColumnNoHold = columnNo;
                            lastRowNoHold = (int)rowIndex;
                            lastTypeHold = arrayTableDisplay [rowIndex*17+columnNo-1];
                            
                            [self tableDataSave];
                            tableViewCall = 1;
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                        else{
                            
                            lastColumnNoHold = 0;
                            lastRowNoHold = 0;
                            lastTypeHold = "X";
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else{
                        
                        lastColumnNoHold = 0;
                        lastRowNoHold = 0;
                        lastTypeHold = "X";
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else if (findString14 != -1){
                    if ((int)stringExtract.find("-") != -1){
                        string numberStart = stringExtract.substr(0, stringExtract.find("-"));
                        string numberEnd = stringExtract.substr(stringExtract.find("-")+1);
                        
                        if (atoi(numberStart.c_str()) > 0 && atoi(numberStart.c_str()) < 200 && atoi(numberEnd.c_str()) > 0 && atoi(numberEnd.c_str()) < 200 && atoi(numberStart.c_str()) < atoi(numberEnd.c_str()) && atoi(numberEnd.c_str())-atoi(numberStart.c_str()) >= 5){
                            extension = to_string(atoi(numberStart.c_str()));
                            string extension2 = to_string(atoi(numberEnd.c_str()));
                            
                            arrayTableDisplay [rowIndex*17+columnNo-1] = "%r"+extension+"-"+extension2;
                            
                            lastColumnNoHold = columnNo;
                            lastRowNoHold = (int)rowIndex;
                            lastTypeHold = arrayTableDisplay [rowIndex*17+columnNo-1];
                            
                            [self tableDataSave];
                            tableViewCall = 1;
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                        else{
                            
                            lastColumnNoHold = 0;
                            lastRowNoHold = 0;
                            lastTypeHold = "X";
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else{
                        
                        lastColumnNoHold = 0;
                        lastRowNoHold = 0;
                        lastTypeHold = "X";
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    lastColumnNoHold = 0;
                    lastRowNoHold = 0;
                    lastTypeHold = "X";
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                lastColumnNoHold = 0;
                lastRowNoHold = 0;
                lastTypeHold = "X";
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            lastColumnNoHold = 0;
            lastRowNoHold = 0;
            lastTypeHold = "X";
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        lastColumnNoHold = 0;
        lastRowNoHold = 0;
        lastTypeHold = "X";
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)focalPlaneSet:(id)sender{
    if (tableDisplayCount != 0 && focusProcessFlag == 0){
        string tableInfoRead;
        int rowNumberFind = 0;
        int findString = 0;
        
        lastColumnNoHold = 0;
        lastRowNoHold = 0;
        lastTypeHold = "X";
        
        for (int counter1 = 2; counter1 < 15; counter1++){
            tableInfoRead = arrayTableDisplay [counter1];
            findString = (int)tableInfoRead.find("C");
            
            if (findString != -1){
                rowNumberFind = counter1;
                break;
            }
        }
        
        string timePointExtractString = arrayTableDisplay [rowNumberFind];
        timePointExtractString = timePointExtractString.substr(1);
        
        if (findString != -1){
            if (rowIndexHold == 0){
                for (int counter1 = 1; counter1 < tableDisplayCount/17; counter1++){
                    if (arrayTableDisplay [counter1*17+rowNumberFind] != " " && arrayTableDisplay [counter1*17+rowNumberFind] != "*"){
                        arrayTableDisplay [counter1*17+rowNumberFind] = "f";
                    }
                }
                
                [self tableDataSave];
                tableViewCall = 1;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else if (rowIndexHold != 0){
                if (arrayTableDisplay [rowIndexHold*17] != " " && arrayTableDisplay [rowIndexHold*17] != "*"){
                    string treatNameTemp = arrayTableDisplay [rowIndexHold*17];
                    int stringLength = (int)treatNameTemp.length();
                    string stringExtract = treatNameTemp.substr((unsigned long)stringLength-3, 2);
                    string stringExtract2 = "";
                    
                    if (stringExtract == "CH") stringExtract2 = treatNameTemp.substr(0, (unsigned long)stringLength-3);
                    else stringExtract2 = treatNameTemp;
                    
                    int blockFlag = 0;
                    
                    for (int counter1 = 1; counter1 < tableDisplayCount/17; counter1++){
                        if (arrayTableDisplay [counter1*17] == stringExtract2){
                            if (arrayTableDisplay [counter1*17+rowNumberFind] == "T" && stringExtract == "CH"){
                                blockFlag = 1;
                                break;
                            }
                        }
                    }
                    
                    if (blockFlag == 0){
                        arrayTableDisplay [rowIndexHold*17+rowNumberFind] = "f";
                        
                        for (int counter1 = rowIndexHold+1; counter1 < tableDisplayCount/17; counter1++){
                            if (arrayTableDisplay [counter1*17+rowNumberFind] != " " && arrayTableDisplay [counter1*17] == " "){
                                arrayTableDisplay [counter1*17+rowNumberFind] = "f";
                            }
                            else {
                                
                                break;
                            }
                        }
                        
                        [self tableDataSave];
                        tableViewCall = 1;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                    else{
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Move Table To The Top"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)focalPlaneContrastSet:(id)sender{
    if (tableDisplayCount != 0 && focusProcessFlag == 0){
        string tableInfoRead;
        int rowNumberFind = 0;
        int findString = 0;
        
        lastColumnNoHold = 0;
        lastRowNoHold = 0;
        lastTypeHold = "X";
        
        for (int counter1 = 2; counter1 < 15; counter1++){
            tableInfoRead = arrayTableDisplay [counter1];
            findString = (int)tableInfoRead.find("C");
            
            if (findString != -1){
                rowNumberFind = counter1;
                break;
            }
        }
        
        string timePointExtractString = arrayTableDisplay [rowNumberFind];
        timePointExtractString = timePointExtractString.substr(1);
        
        if (findString != -1){
            if (rowIndexHold == 0){
                for (int counter1 = 1; counter1 < tableDisplayCount/17; counter1++){
                    if (arrayTableDisplay [counter1*17+rowNumberFind] != " " && arrayTableDisplay [counter1*17+rowNumberFind] != "*"){
                        arrayTableDisplay [counter1*17+rowNumberFind] = "F";
                    }
                }
                
                [self tableDataSave];
                tableViewCall = 1;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else if (rowIndexHold != 0){
                if (arrayTableDisplay [rowIndexHold*17] != " " && arrayTableDisplay [rowIndexHold*17] != "*"){
                    string treatNameTemp = arrayTableDisplay [rowIndexHold*17];
                    int stringLength = (int)treatNameTemp.length();
                    string stringExtract = treatNameTemp.substr((unsigned long)stringLength-3, 2);
                    string stringExtract2 = "";
                    
                    if (stringExtract == "CH") stringExtract2 = treatNameTemp.substr(0, (unsigned long)stringLength-3);
                    else stringExtract2 = treatNameTemp;
                    
                    int blockFlag = 0;
                    
                    for (int counter1 = 1; counter1 < tableDisplayCount/17; counter1++){
                        if (arrayTableDisplay [counter1*17] == stringExtract2){
                            if (arrayTableDisplay [counter1*17+rowNumberFind] == "T" && stringExtract == "CH"){
                                blockFlag = 1;
                                break;
                            }
                        }
                    }
                    
                    if (blockFlag == 0){
                        arrayTableDisplay [rowIndexHold*17+rowNumberFind] = "F";
                        
                        for (int counter1 = rowIndexHold+1; counter1 < tableDisplayCount/17; counter1++){
                            if (arrayTableDisplay [counter1*17+rowNumberFind] != " " && arrayTableDisplay [counter1*17] == " "){
                                arrayTableDisplay [counter1*17+rowNumberFind] = "F";
                            }
                            else {
                                
                                break;
                            }
                        }
                        
                        [self tableDataSave];
                        tableViewCall = 1;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                    else{
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Move Table To The Top"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)constantPlaneSet:(id)sender{
    int focalNumber = (int)[focalNoDisplay integerValue];
    
    lastColumnNoHold = 0;
    lastRowNoHold = 0;
    lastTypeHold = "X";
    
    if (focalNumber >= 1 && focalNumber < 200 && tableDisplayCount != 0 && focusProcessFlag == 0){
        string tableInfoRead;
        int rowNumberFind = 0;
        int findString = 0;
        
        string extension = to_string(focalNumber);
        
        for (int counter1 = 2; counter1 < 15; counter1++){
            tableInfoRead = arrayTableDisplay [counter1];
            findString = (int)tableInfoRead.find("C");
            
            if (findString != -1){
                rowNumberFind = counter1;
                break;
            }
        }
        
        string timePointExtractString = arrayTableDisplay [rowNumberFind];
        timePointExtractString = timePointExtractString.substr(1);
        
        if (findString != -1){
            if (rowIndexHold == 0){
                for (int counter1 = 1; counter1 < tableDisplayCount/17; counter1++){
                    if (arrayTableDisplay [counter1*17+rowNumberFind] != " " && arrayTableDisplay [counter1*17+rowNumberFind] != "*"){
                        arrayTableDisplay [counter1*17+rowNumberFind] = "p"+extension;
                    }
                }
                
                [self tableDataSave];
                tableViewCall = 1;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else if (rowIndexHold != 0){
                if (arrayTableDisplay [rowIndexHold*17] != " " && arrayTableDisplay [rowIndexHold*17] != "*"){
                    string treatNameTemp = arrayTableDisplay [rowIndexHold*17];
                    int stringLength = (int)treatNameTemp.length();
                    string stringExtract = treatNameTemp.substr((unsigned long)stringLength-3, 2);
                    string stringExtract2 = "";
                    
                    if (stringExtract == "CH") stringExtract2 = treatNameTemp.substr(0, (unsigned long)stringLength-3);
                    else stringExtract2 = treatNameTemp;
                    
                    int blockFlag = 0;
                    
                    for (int counter1 = 1; counter1 < tableDisplayCount/17; counter1++){
                        if (arrayTableDisplay [counter1*17] == stringExtract2){
                            if (arrayTableDisplay [counter1*17+rowNumberFind] == "T" && stringExtract == "CH"){
                                blockFlag = 1;
                                break;
                            }
                        }
                    }
                    
                    if (blockFlag == 0){
                        arrayTableDisplay [rowIndexHold*17+rowNumberFind] = "p"+extension;
                        
                        for (int counter1 = rowIndexHold+1; counter1 < tableDisplayCount/17; counter1++){
                            if (arrayTableDisplay [counter1*17+rowNumberFind] != " " && arrayTableDisplay [counter1*17] == " "){
                                arrayTableDisplay [counter1*17+rowNumberFind] = "p"+extension;
                            }
                            else {
                                
                                break;
                            }
                        }
                        
                        [self tableDataSave];
                        tableViewCall = 1;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                    else{
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Move Table To The Top"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)constantPlaneContrastSet:(id)sender{
    int focalNumber = (int)[focalNoDisplay integerValue];
    
    lastColumnNoHold = 0;
    lastRowNoHold = 0;
    lastTypeHold = "X";
    
    if (focalNumber >= 1 && focalNumber < 200 && tableDisplayCount != 0 && focusProcessFlag == 0){
        string tableInfoRead;
        int rowNumberFind = 0;
        int findString = 0;
        
        string extension = to_string(focalNumber);
        
        for (int counter1 = 2; counter1 < 15; counter1++){
            tableInfoRead = arrayTableDisplay [counter1];
            findString = (int)tableInfoRead.find("C");
            
            if (findString != -1){
                rowNumberFind = counter1;
                break;
            }
        }
        
        string timePointExtractString = arrayTableDisplay [rowNumberFind];
        timePointExtractString = timePointExtractString.substr(1);
        
        if (findString != -1){
            if (rowIndexHold == 0){
                for (int counter1 = 1; counter1 < tableDisplayCount/17; counter1++){
                    if (arrayTableDisplay [counter1*17+rowNumberFind] != " " && arrayTableDisplay [counter1*17+rowNumberFind] != "*"){
                        arrayTableDisplay [counter1*17+rowNumberFind] = "P"+extension;
                    }
                }
                
                [self tableDataSave];
                tableViewCall = 1;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else if (rowIndexHold != 0){
                if (arrayTableDisplay [rowIndexHold*17] != " " && arrayTableDisplay [rowIndexHold*17] != "*"){
                    string treatNameTemp = arrayTableDisplay [rowIndexHold*17];
                    int stringLength = (int)treatNameTemp.length();
                    string stringExtract = treatNameTemp.substr((unsigned long)stringLength-3, 2);
                    string stringExtract2 = "";
                    
                    if (stringExtract == "CH") stringExtract2 = treatNameTemp.substr(0, (unsigned long)stringLength-3);
                    else stringExtract2 = treatNameTemp;
                    
                    int blockFlag = 0;
                    
                    for (int counter1 = 1; counter1 < tableDisplayCount/17; counter1++){
                        if (arrayTableDisplay [counter1*17] == stringExtract2){
                            if (arrayTableDisplay [counter1*17+rowNumberFind] == "T" && stringExtract == "CH"){
                                blockFlag = 1;
                                break;
                            }
                        }
                    }
                    
                    if (blockFlag == 0){
                        arrayTableDisplay [rowIndexHold*17+rowNumberFind] = "P"+extension;
                        
                        for (int counter1 = rowIndexHold+1; counter1 < tableDisplayCount/17; counter1++){
                            if (arrayTableDisplay [counter1*17+rowNumberFind] != " " && arrayTableDisplay [counter1*17] == " "){
                                arrayTableDisplay [counter1*17+rowNumberFind] = "P"+extension;
                            }
                            else {
                                
                                break;
                            }
                        }
                        
                        [self tableDataSave];
                        tableViewCall = 1;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                    else{
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Move Table To The Top"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)rangeSet:(id)sender{
    NSString *inputString = [focalNoDisplay stringValue];
    string focalNumberString = [inputString UTF8String];
    
    lastColumnNoHold = 0;
    lastRowNoHold = 0;
    lastTypeHold = "X";
    
    int findString = (int)focalNumberString.find("-");
    
    if (findString != -1 && focusProcessFlag == 0){
        string numberStart = focalNumberString.substr(0, (unsigned long)findString);
        string numberEnd = focalNumberString.substr((unsigned long)findString+1);
        
        if (atoi(numberStart.c_str()) > 0 && atoi(numberStart.c_str()) < 200 && atoi(numberEnd.c_str()) > 0 && atoi(numberEnd.c_str()) < 200 && atoi(numberStart.c_str()) < atoi(numberEnd.c_str()) && atoi(numberEnd.c_str())-atoi(numberStart.c_str()) >= 5 && tableDisplayCount != 0){
            string tableInfoRead;
            int rowNumberFind = 0;
            findString = 0;
            
            for (int counter1 = 2; counter1 < 15; counter1++){
                tableInfoRead = arrayTableDisplay [counter1];
                findString = (int)tableInfoRead.find("C");
                
                if (findString != -1){
                    rowNumberFind = counter1;
                    break;
                }
            }
            
            string timePointExtractString = arrayTableDisplay [rowNumberFind];
            timePointExtractString = timePointExtractString.substr(1);
            
            numberStart = to_string(atoi(numberStart.c_str()));
            numberEnd = to_string(atoi(numberEnd.c_str()));
            
            if (findString != -1){
                if (rowIndexHold == 0){
                    for (int counter1 = 1; counter1 < tableDisplayCount/17; counter1++){
                        if (arrayTableDisplay [counter1*17+rowNumberFind] != " " && arrayTableDisplay [counter1*17+rowNumberFind] != "*"){
                            arrayTableDisplay [counter1*17+rowNumberFind] = "r"+numberStart+"-"+numberEnd;
                        }
                    }
                    
                    [self tableDataSave];
                    tableViewCall = 1;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else if (rowIndexHold != 0){
                    if (arrayTableDisplay [rowIndexHold*17] != " " && arrayTableDisplay [rowIndexHold*17] != "*"){
                        string treatNameTemp = arrayTableDisplay [rowIndexHold*17];
                        int stringLength = (int)treatNameTemp.length();
                        string stringExtract = treatNameTemp.substr((unsigned long)stringLength-3, 2);
                        string stringExtract2 = "";
                        
                        if (stringExtract == "CH") stringExtract2 = treatNameTemp.substr(0, (unsigned long)stringLength-3);
                        else stringExtract2 = treatNameTemp;
                        
                        int blockFlag = 0;
                        
                        for (int counter1 = 1; counter1 < tableDisplayCount/17; counter1++){
                            if (arrayTableDisplay [counter1*17] == stringExtract2){
                                if (arrayTableDisplay [counter1*17+rowNumberFind] == "T" && stringExtract == "CH"){
                                    blockFlag = 1;
                                    break;
                                }
                            }
                        }
                        
                        if (blockFlag == 0){
                            arrayTableDisplay [rowIndexHold*17+rowNumberFind] = "r"+numberStart+"-"+numberEnd;
                            
                            for (int counter1 = rowIndexHold+1; counter1 < tableDisplayCount/17; counter1++){
                                if (arrayTableDisplay [counter1*17+rowNumberFind] != " " && arrayTableDisplay [counter1*17] == " "){
                                    arrayTableDisplay [counter1*17+rowNumberFind] = "r"+numberStart+"-"+numberEnd;
                                }
                                else {
                                    
                                    break;
                                }
                            }
                            
                            [self tableDataSave];
                            tableViewCall = 1;
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                        else{
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else{
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Move Table To The Top"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)rangeContrastSet:(id)sender{
    NSString *inputString = [focalNoDisplay stringValue];
    string focalNumberString = [inputString UTF8String];
    
    lastColumnNoHold = 0;
    lastRowNoHold = 0;
    lastTypeHold = "X";
    
    int findString = (int)focalNumberString.find("-");
    
    if (findString != -1 && focusProcessFlag == 0){
        string numberStart = focalNumberString.substr(0, (unsigned long)findString);
        string numberEnd = focalNumberString.substr((unsigned long)findString+1);
        
        if (atoi(numberStart.c_str()) > 0 && atoi(numberStart.c_str()) < 200 && atoi(numberEnd.c_str()) > 0 && atoi(numberEnd.c_str()) < 200 && atoi(numberStart.c_str()) < atoi(numberEnd.c_str()) && atoi(numberEnd.c_str())-atoi(numberStart.c_str()) >= 5 && tableDisplayCount != 0){
            string tableInfoRead;
            int rowNumberFind = 0;
            findString = 0;
            
            for (int counter1 = 2; counter1 < 15; counter1++){
                tableInfoRead = arrayTableDisplay [counter1];
                findString = (int)tableInfoRead.find("C");
                
                if (findString != -1){
                    rowNumberFind = counter1;
                    break;
                }
            }
            
            string timePointExtractString = arrayTableDisplay [rowNumberFind];
            timePointExtractString = timePointExtractString.substr(1);
            numberStart = to_string(atoi(numberStart.c_str()));
            numberEnd = to_string(atoi(numberEnd.c_str()));
            
            if (findString != -1){
                if (rowIndexHold == 0){
                    for (int counter1 = 1; counter1 < tableDisplayCount/17; counter1++){
                        if (arrayTableDisplay [counter1*17+rowNumberFind] != " " && arrayTableDisplay [counter1*17+rowNumberFind] != "*"){
                            arrayTableDisplay [counter1*17+rowNumberFind] = "R"+numberStart+"-"+numberEnd;
                        }
                    }
                    
                    [self tableDataSave];
                    tableViewCall = 1;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else if (rowIndexHold != 0){
                    if (arrayTableDisplay [rowIndexHold*17] != " " && arrayTableDisplay [rowIndexHold*17] != "*"){
                        string treatNameTemp = arrayTableDisplay [rowIndexHold*17];
                        int stringLength = (int)treatNameTemp.length();
                        string stringExtract = treatNameTemp.substr((unsigned long)stringLength-3, 2);
                        string stringExtract2 = "";
                        
                        if (stringExtract == "CH") stringExtract2 = treatNameTemp.substr(0, (unsigned long)stringLength-3);
                        else stringExtract2 = treatNameTemp;
                        
                        int blockFlag = 0;
                        
                        for (int counter1 = 1; counter1 < tableDisplayCount/17; counter1++){
                            if (arrayTableDisplay [counter1*17] == stringExtract2){
                                if (arrayTableDisplay [counter1*17+rowNumberFind] == "T" && stringExtract == "CH"){
                                    blockFlag = 1;
                                    break;
                                }
                            }
                        }
                        
                        if (blockFlag == 0){
                            arrayTableDisplay [rowIndexHold*17+rowNumberFind] = "R"+numberStart+"-"+numberEnd;
                            
                            for (int counter1 = rowIndexHold+1; counter1 < tableDisplayCount/17; counter1++){
                                if (arrayTableDisplay [counter1*17+rowNumberFind] != " " && arrayTableDisplay [counter1*17] == " "){
                                    arrayTableDisplay [counter1*17+rowNumberFind] = "R"+numberStart+"-"+numberEnd;
                                }
                                else {
                                    
                                    break;
                                }
                            }
                            
                            [self tableDataSave];
                            tableViewCall = 1;
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                        else{
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else{
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Move Table To The Top"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)allInFocusSet:(id)sender{
    if (tableDisplayCount != 0 && focusProcessFlag == 0){
        string tableInfoRead;
        int rowNumberFind = 0;
        int findString = 0;
        
        lastColumnNoHold = 0;
        lastRowNoHold = 0;
        lastTypeHold = "X";
        
        for (int counter1 = 2; counter1 < 15; counter1++){
            tableInfoRead = arrayTableDisplay [counter1];
            findString = (int)tableInfoRead.find("C");
            
            if (findString != -1){
                rowNumberFind = counter1;
                break;
            }
        }
        
        string timePointExtractString = arrayTableDisplay [rowNumberFind];
        timePointExtractString = timePointExtractString.substr(1);
        
        if (findString != -1){
            if (rowIndexHold == 0){
                for (int counter1 = 1; counter1 < tableDisplayCount/17; counter1++){
                    if (arrayTableDisplay [counter1*17+rowNumberFind] != " " && arrayTableDisplay [rowIndexHold*17] != "*"){
                        arrayTableDisplay [counter1*17+rowNumberFind] = "a";
                    }
                }
                
                [self tableDataSave];
                tableViewCall = 1;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else if (rowIndexHold != 0){
                if (arrayTableDisplay [rowIndexHold*17] != " " && arrayTableDisplay [rowIndexHold*17] != "*"){
                    string treatNameTemp = arrayTableDisplay [rowIndexHold*17];
                    int stringLength = (int)treatNameTemp.length();
                    string stringExtract = treatNameTemp.substr((unsigned long)stringLength-3, 2);
                    string stringExtract2 = "";
                    
                    if (stringExtract == "CH") stringExtract2 = treatNameTemp.substr(0, (unsigned long)stringLength-3);
                    else stringExtract2 = treatNameTemp;
                    
                    int blockFlag = 0;
                    
                    for (int counter1 = 1; counter1 < tableDisplayCount/17; counter1++){
                        if (arrayTableDisplay [counter1*17] == stringExtract2){
                            if (arrayTableDisplay [counter1*17+rowNumberFind] == "T" && stringExtract == "CH"){
                                blockFlag = 1;
                                break;
                            }
                        }
                    }
                    
                    if (blockFlag == 0){
                        arrayTableDisplay [rowIndexHold*17+rowNumberFind] = "a";
                        
                        for (int counter1 = rowIndexHold+1; counter1 < tableDisplayCount/17; counter1++){
                            if (arrayTableDisplay [counter1*17+rowNumberFind] != " " && arrayTableDisplay [counter1*17] == " "){
                                arrayTableDisplay [counter1*17+rowNumberFind] = "a";
                            }
                            else {
                                
                                break;
                            }
                        }
                        
                        [self tableDataSave];
                        tableViewCall = 1;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                    else{
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
        }
        else {
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Move Table To The Top"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)allInFocusContrastSet:(id)sender{
    if (tableDisplayCount != 0 && focusProcessFlag == 0){
        string tableInfoRead;
        int rowNumberFind = 0;
        int findString = 0;
        
        lastColumnNoHold = 0;
        lastRowNoHold = 0;
        lastTypeHold = "X";
        
        for (int counter1 = 2; counter1 < 15; counter1++){
            tableInfoRead = arrayTableDisplay [counter1];
            findString = (int)tableInfoRead.find("C");
            
            if (findString != -1){
                rowNumberFind = counter1;
                break;
            }
        }
        
        string timePointExtractString = arrayTableDisplay [rowNumberFind];
        timePointExtractString = timePointExtractString.substr(1);
        
        if (findString != -1){
            if (rowIndexHold == 0){
                for (int counter1 = 1; counter1 < tableDisplayCount/17; counter1++){
                    if (arrayTableDisplay [counter1*17+rowNumberFind] != " " && arrayTableDisplay [rowIndexHold*17] != "*"){
                        arrayTableDisplay [counter1*17+rowNumberFind] = "A";
                    }
                }
                
                [self tableDataSave];
                tableViewCall = 1;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else if (rowIndexHold != 0){
                if (arrayTableDisplay [rowIndexHold*17] != " " && arrayTableDisplay [rowIndexHold*17] != "*"){
                    string treatNameTemp = arrayTableDisplay [rowIndexHold*17];
                    int stringLength = (int)treatNameTemp.length();
                    string stringExtract = treatNameTemp.substr((unsigned long)stringLength-3, 2);
                    string stringExtract2 = "";
                    
                    if (stringExtract == "CH") stringExtract2 = treatNameTemp.substr(0, (unsigned long)stringLength-3);
                    else stringExtract2 = treatNameTemp;
                    
                    int blockFlag = 0;
                    
                    for (int counter1 = 1; counter1 < tableDisplayCount/17; counter1++){
                        if (arrayTableDisplay [counter1*17] == stringExtract2){
                            if (arrayTableDisplay [counter1*17+rowNumberFind] == "T" && stringExtract == "CH"){
                                blockFlag = 1;
                                break;
                            }
                        }
                    }
                    
                    if (blockFlag == 0){
                        arrayTableDisplay [rowIndexHold*17+rowNumberFind] = "A";
                        
                        for (int counter1 = rowIndexHold+1; counter1 < tableDisplayCount/17; counter1++){
                            if (arrayTableDisplay [counter1*17+rowNumberFind] != " " && arrayTableDisplay [counter1*17] == " "){
                                arrayTableDisplay [counter1*17+rowNumberFind] = "A";
                            }
                            else {
                                
                                break;
                            }
                        }
                        
                        [self tableDataSave];
                        tableViewCall = 1;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                    else{
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
        }
        else {
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Move Table To The Top"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)allInFocusSelectSet:(id)sender{
    int focalNumber = (int)[focalNoDisplay integerValue];
    
    lastColumnNoHold = 0;
    lastRowNoHold = 0;
    lastTypeHold = "X";
    
    if (focalNumber >= 1 && focalNumber < 200 && tableDisplayCount != 0 && focusProcessFlag == 0){
        string tableInfoRead;
        int rowNumberFind = 0;
        int findString = 0;
        string extension = to_string(focalNumber);
        
        for (int counter1 = 2; counter1 < 15; counter1++){
            tableInfoRead = arrayTableDisplay [counter1];
            findString = (int)tableInfoRead.find("C");
            
            if (findString != -1){
                rowNumberFind = counter1;
                break;
            }
        }
        
        string timePointExtractString = arrayTableDisplay [rowNumberFind];
        timePointExtractString = timePointExtractString.substr(1);
        
        if (findString != -1){
            if (rowIndexHold == 0){
                for (int counter1 = 1; counter1 < tableDisplayCount/17; counter1++){
                    if (arrayTableDisplay [counter1*17+rowNumberFind] != " " && arrayTableDisplay [counter1*17+rowNumberFind] != "*"){
                        arrayTableDisplay [counter1*17+rowNumberFind] = "s"+extension;
                    }
                }
                
                [self tableDataSave];
                tableViewCall = 1;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else if (rowIndexHold != 0){
                if (arrayTableDisplay [rowIndexHold*17] != " " && arrayTableDisplay [rowIndexHold*17] != "*"){
                    string treatNameTemp = arrayTableDisplay [rowIndexHold*17];
                    int stringLength = (int)treatNameTemp.length();
                    string stringExtract = treatNameTemp.substr((unsigned long)stringLength-3, 2);
                    string stringExtract2 = "";
                    
                    if (stringExtract == "CH") stringExtract2 = treatNameTemp.substr(0, (unsigned long)stringLength-3);
                    else stringExtract2 = treatNameTemp;
                    
                    int blockFlag = 0;
                    
                    for (int counter1 = 1; counter1 < tableDisplayCount/17; counter1++){
                        if (arrayTableDisplay [counter1*17] == stringExtract2){
                            if (arrayTableDisplay [counter1*17+rowNumberFind] == "T" && stringExtract == "CH"){
                                blockFlag = 1;
                                break;
                            }
                        }
                    }
                    
                    if (blockFlag == 0){
                        arrayTableDisplay [rowIndexHold*17+rowNumberFind] = "s"+extension;
                        
                        for (int counter1 = rowIndexHold+1; counter1 < tableDisplayCount/17; counter1++){
                            if (arrayTableDisplay [counter1*17+rowNumberFind] != " " && arrayTableDisplay [counter1*17] == " "){
                                arrayTableDisplay [counter1*17+rowNumberFind] = "s"+extension;
                            }
                            else {
                                
                                break;
                            }
                        }
                        
                        [self tableDataSave];
                        tableViewCall = 1;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                    else{
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Move Table To The Top"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)allInFocusContrastSelectSet:(id)sender{
    int focalNumber = (int)[focalNoDisplay integerValue];
    
    lastColumnNoHold = 0;
    lastRowNoHold = 0;
    lastTypeHold = "X";
    
    if (focalNumber >= 1 && focalNumber < 200 && tableDisplayCount != 0 && focusProcessFlag == 0){
        string tableInfoRead;
        int rowNumberFind = 0;
        int findString = 0;
        
        string extension = to_string(focalNumber);
        
        for (int counter1 = 2; counter1 < 15; counter1++){
            tableInfoRead = arrayTableDisplay [counter1];
            findString = (int)tableInfoRead.find("C");
            
            if (findString != -1){
                rowNumberFind = counter1;
                break;
            }
        }
        
        string timePointExtractString = arrayTableDisplay [rowNumberFind];
        timePointExtractString = timePointExtractString.substr(1);
        
        if (findString != -1){
            if (rowIndexHold == 0){
                for (int counter1 = 1; counter1 < tableDisplayCount/17; counter1++){
                    if (arrayTableDisplay [counter1*17+rowNumberFind] != " " && arrayTableDisplay [counter1*17+rowNumberFind] != "*"){
                        arrayTableDisplay [counter1*17+rowNumberFind] = "S"+extension;
                    }
                }
                
                [self tableDataSave];
                tableViewCall = 1;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else if (rowIndexHold != 0){
                if (arrayTableDisplay [rowIndexHold*17] != " " && arrayTableDisplay [rowIndexHold*17] != "*"){
                    string treatNameTemp = arrayTableDisplay [rowIndexHold*17];
                    int stringLength = (int)treatNameTemp.length();
                    string stringExtract = treatNameTemp.substr((unsigned long)stringLength-3, 2);
                    string stringExtract2 = "";
                    
                    if (stringExtract == "CH") stringExtract2 = treatNameTemp.substr(0, (unsigned long)stringLength-3);
                    else stringExtract2 = treatNameTemp;
                    
                    int blockFlag = 0;
                    
                    for (int counter1 = 1; counter1 < tableDisplayCount/17; counter1++){
                        if (arrayTableDisplay [counter1*17] == stringExtract2){
                            if (arrayTableDisplay [counter1*17+rowNumberFind] == "T" && stringExtract == "CH"){
                                blockFlag = 1;
                                break;
                            }
                        }
                    }
                    
                    if (blockFlag == 0){
                        arrayTableDisplay [rowIndexHold*17+rowNumberFind] = "S"+extension;
                        
                        for (int counter1 = rowIndexHold+1; counter1 < tableDisplayCount/17; counter1++){
                            if (arrayTableDisplay [counter1*17+rowNumberFind] != " " && arrayTableDisplay [counter1*17] == " "){
                                arrayTableDisplay [counter1*17+rowNumberFind] = "S"+extension;
                            }
                            else {
                                
                                break;
                            }
                        }
                        
                        [self tableDataSave];
                        tableViewCall = 1;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                    else{
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Move Table To The Top"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)terminationSet:(id)sender{
    if (tableDisplayCount != 0 && focusProcessFlag == 0){
        int rowNumberFind = 0;
        string timeNumberstring = "";
        int findString = 0;
        string tableInfoRead;
        
        lastColumnNoHold = 0;
        lastRowNoHold = 0;
        lastTypeHold = "X";
        
        for (int counter1 = 2; counter1 < 15; counter1++){
            tableInfoRead = arrayTableDisplay [counter1];
            findString = (int)tableInfoRead.find("C");
            
            if (findString != -1){
                rowNumberFind = counter1;
                timeNumberstring = tableInfoRead.substr(1);
                break;
            }
        }
        
        string timePointExtractString = arrayTableDisplay [rowNumberFind];
        timePointExtractString = timePointExtractString.substr(1);
        
        if (findString != -1 && timeNumberstring != "1"){
            if (rowIndexHold == 0){
                for (int counter1 = 1; counter1 < tableDisplayCount/17; counter1++){
                    if (arrayTableDisplay [counter1*17+rowNumberFind] != " "){
                        arrayTableDisplay [counter1*17+rowNumberFind] = "T";
                    }
                }
                
                [self tableDataSave];
                tableViewCall = 1;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else if (rowIndexHold != 0){
                if (arrayTableDisplay [rowIndexHold*17] != " "){
                    string treatNameTemp = arrayTableDisplay [rowIndexHold*17];
                    int stringLength = (int)treatNameTemp.length();
                    string stringExtract = treatNameTemp.substr((unsigned long)stringLength-3, 2);
                    
                    if (stringExtract == "CH"){
                        arrayTableDisplay [rowIndexHold*17+rowNumberFind] = "T";
                        
                        for (int counter1 = rowIndexHold+1; counter1 < tableDisplayCount/17; counter1++){
                            if (arrayTableDisplay [counter1*17+rowNumberFind] != " " && arrayTableDisplay [counter1*17] == " "){
                                arrayTableDisplay [counter1*17+rowNumberFind] = "T";
                            }
                            else {
                                
                                break;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < treatmentNameDisplayCount; counterA++){
                        //    for (int counterB = 0; counterB < 17; counterB++) cout<<" "<<arrayTableDisplay [counterA*17+counterB];
                        //    cout<<" arrayTableDisplay "<<counterA+1<<endl;
                        //}
                        
                        [self tableDataSave];
                        tableViewCall = 1;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                    else{
                        
                        arrayTableDisplay [rowIndexHold*17+rowNumberFind] = "T";
                        
                        for (int counter1 = rowIndexHold+1; counter1 < tableDisplayCount/17; counter1++){
                            if (arrayTableDisplay [counter1*17+rowNumberFind] != " "){
                                arrayTableDisplay [counter1*17+rowNumberFind] = "T";
                            }
                            else {
                                
                                break;
                            }
                        }
                        
                        [self tableDataSave];
                        tableViewCall = 1;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                }
                else{
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Move The Table To The Top, But Not To Position C1"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)tableTreatSet:(id)sender{
    if (tableDisplayCount != 0 && focusProcessFlag == 0){
        if (lastColumnNoHold != 0 && lastRowNoHold != 0 && lastTypeHold != "X" && lastTypeHold != "T"){
            int tableFovNoFind = 0;
            
            if ((int)arrayTableDisplay [lastRowNoHold*17+1].length() > 3) tableFovNoFind = atoi(arrayTableDisplay [lastRowNoHold*17+1].substr(3).c_str());
            
            string tableTreatNameFind = "";
            tableTreatNameFind = arrayTableDisplay [(lastRowNoHold-tableFovNoFind+1)*17];
            
            if (tableFovNoFind != 0 && tableTreatNameFind != ""){
                int rowStart = lastRowNoHold-tableFovNoFind+1;
                int columnStart = lastColumnNoHold-1;
                int stringLength = (int)tableTreatNameFind.length();
                string stringExtract = tableTreatNameFind.substr((unsigned long)stringLength-3, 2);
                
                if (stringExtract == "CH"){
                    for (int counter1 = rowStart; counter1 < tableDisplayCount/17; counter1++){
                        if (arrayTableDisplay [counter1*17+columnStart] != " " && arrayTableDisplay [counter1*17] == " "){
                            arrayTableDisplay [counter1*17+columnStart] = lastTypeHold;
                        }
                        else {
                            
                            break;
                        }
                    }
                    
                    [self tableDataSave];
                    tableViewCall = 1;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else{
                    
                    for (int counter1 = rowStart; counter1 < tableDisplayCount/17; counter1++){
                        if (arrayTableDisplay [counter1*17+columnStart] != " "){
                            arrayTableDisplay [counter1*17+columnStart] = lastTypeHold;
                        }
                        else {
                            
                            break;
                        }
                    }
                    
                    [self tableDataSave];
                    tableViewCall = 1;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)tableTillEndSet:(id)sender{
    if (tableDisplayCount != 0 && focusProcessFlag == 0){
        if (lastColumnNoHold != 0 && lastRowNoHold != 0 && lastTypeHold != "X" && lastTypeHold != "T"){
            arrayTableDisplay [lastRowNoHold*17+lastColumnNoHold] = "%"+lastTypeHold;
            
            [self tableDataSave];
            tableViewCall = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)tableTreatAndTillEndSet:(id)sender{
    if (tableDisplayCount != 0 && focusProcessFlag == 0){
        if (lastColumnNoHold != 0 && lastRowNoHold != 0 && lastTypeHold != "X" && lastTypeHold != "T"){
            int tableFovNoFind = 0;
            
            if ((int)arrayTableDisplay [lastRowNoHold*17+1].length() > 3) tableFovNoFind = atoi(arrayTableDisplay [lastRowNoHold*17+1].substr(3).c_str());
            
            string tableTreatNameFind = "";
            tableTreatNameFind = arrayTableDisplay [(lastRowNoHold-tableFovNoFind+1)*17];
            
            if (tableFovNoFind != 0 && tableTreatNameFind != ""){
                int rowStart = lastRowNoHold-tableFovNoFind+1;
                int columnStart = lastColumnNoHold-1;
                int stringLength = (int)tableTreatNameFind.length();
                string stringExtract = tableTreatNameFind.substr((unsigned long)stringLength-3, 2);
                
                if (stringExtract == "CH"){
                    for (int counter1 = rowStart; counter1 < tableDisplayCount/17; counter1++){
                        if (arrayTableDisplay [counter1*17+columnStart] != " " && arrayTableDisplay [counter1*17] == " "){
                            arrayTableDisplay [counter1*17+columnStart] = "%"+lastTypeHold;
                            
                            [self tableDataSave];
                        }
                        else {
                            
                            break;
                        }
                    }
                    
                    tableViewCall = 1;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else{
                    
                    for (int counter1 = rowStart; counter1 < tableDisplayCount/17; counter1++){
                        if (arrayTableDisplay [counter1*17+columnStart] != " "){
                            arrayTableDisplay [counter1*17+columnStart] = "%"+lastTypeHold;
                            
                            [self tableDataSave];
                        }
                        else {
                            
                            break;
                        }
                    }
                    
                    tableViewCall = 1;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)tableDataSave{
    //for (int counterA = 0; counterA < 10; counterA++){
    //    for (int counterB = 0; counterB < 20; counterB++) cout<<" "<<arrayFocalPlaneData [counterA][counterB];
    //    cout<<"  arrayFocalPlaneData "<<counterA+1<<endl;
    //}
    
    //for (int counterA = 0; counterA < treatmentNameDisplayCount; counterA++){
    //    for (int counterB = 0; counterB < 17; counterB++) cout<<" "<<arrayTableDisplay [counterA*17+counterB];
    //    cout<<" arrayTableDisplay "<<counterA+1<<endl;
    //}
    
    int *arrayTableTemp = new int [treatmentNameDisplayCount*17];
    int tableTempCount = 0;
    int timePointStartToLast = 0;
    int columnStartToLast = 0;
    int markTempInt = 0;
    
    string stringExtract;
    string extension;
    string timeStringTemp;
    string timeStartTemp;
    string timeEndTemp;
    string markTemp = "";
    
    int tableConversion = 0;
    int findString2 = 0; //----Till the end
    int findString3 = 0;
    int findString4 = 0;
    int findString5 = 0; //----Till the end
    int findString6 = 0;
    int findString7 = 0; //----Till the end
    int findString8 = 0;
    
    for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
        for (int counter2 = 0; counter2 < 17; counter2++){
            tableConversion = atoi(arrayTableDisplay [counter1*17+counter2].c_str());
            findString2 = (int)arrayTableDisplay [counter1*17+counter2].find("%"); //----Till the end
            findString3 = (int)arrayTableDisplay [counter1*17+counter2].find("p");
            findString4 = (int)arrayTableDisplay [counter1*17+counter2].find("P");
            findString5 = (int)arrayTableDisplay [counter1*17+counter2].find("s"); //----Till the end
            findString6 = (int)arrayTableDisplay [counter1*17+counter2].find("S");
            findString7 = (int)arrayTableDisplay [counter1*17+counter2].find("r"); //----Till the end
            findString8 = (int)arrayTableDisplay [counter1*17+counter2].find("R");
            
            if (arrayTableDisplay [counter1*17+counter2] == "a" && findString2 == -1) arrayTableTemp [tableTempCount] = -4000, tableTempCount++;
            else if (arrayTableDisplay [counter1*17+counter2] == "%a"){
                arrayTableDisplay [counter1*17+counter2] = "a";
                arrayTableTemp [tableTempCount] = -4000, tableTempCount++;
                timeStringTemp = arrayTableDisplay [counter2].substr(1);
                
                timePointStartToLast = atoi(timeStringTemp.c_str());
                columnStartToLast = counter1;
                markTemp = "a";
                markTempInt = -4000;
            }
            else if (arrayTableDisplay [counter1*17+counter2] == "A" && findString2 == -1) arrayTableTemp [tableTempCount] = -4500, tableTempCount++;
            else if (arrayTableDisplay [counter1*17+counter2] == "%A"){
                arrayTableDisplay [counter1*17+counter2] = "A";
                arrayTableTemp [tableTempCount] = -4500, tableTempCount++;
                timeStringTemp = arrayTableDisplay [counter2].substr(1);
                
                timePointStartToLast = atoi(timeStringTemp.c_str());
                columnStartToLast = counter1;
                markTemp = "A";
                markTempInt = -4500;
            }
            else if (arrayTableDisplay [counter1*17+counter2] == "f"){
                arrayTableTemp [tableTempCount] = -3000, tableTempCount++;
            }
            else if (arrayTableDisplay [counter1*17+counter2] == "%f"){
                arrayTableDisplay [counter1*17+counter2] = "f";
                arrayTableTemp [tableTempCount] = -3000, tableTempCount++;
                timeStringTemp = arrayTableDisplay [counter2].substr(1);
                
                timePointStartToLast = atoi(timeStringTemp.c_str());
                columnStartToLast = counter1;
                markTemp = "f";
                markTempInt = -3000;
            }
            else if (arrayTableDisplay [counter1*17+counter2] == "F"){
                arrayTableTemp [tableTempCount] = -3500, tableTempCount++;
            }
            else if (arrayTableDisplay [counter1*17+counter2] == "%F"){
                arrayTableDisplay [counter1*17+counter2] = "F";
                arrayTableTemp [tableTempCount] = -3500, tableTempCount++;
                timeStringTemp = arrayTableDisplay [counter2].substr(1);
                
                timePointStartToLast = atoi(timeStringTemp.c_str());
                columnStartToLast = counter1;
                markTemp = "F";
                markTempInt = -3500;
            }
            else if (arrayTableDisplay [counter1*17+counter2] == "T")arrayTableTemp [tableTempCount] = -5000, tableTempCount++;
            else if (arrayTableDisplay [counter1*17+counter2] == "*") arrayTableTemp [tableTempCount] = -2500, tableTempCount++;
            else if (findString2 == -1 && findString3 != -1){
                stringExtract = arrayTableDisplay [counter1*17+counter2].substr(1);
                
                if (stringExtract.length() == 1) stringExtract = "00"+stringExtract;
                else if (stringExtract.length() == 2) stringExtract = "0"+stringExtract;
                
                stringExtract = "-6"+stringExtract;
                arrayTableTemp [tableTempCount] = atoi(stringExtract.c_str()), tableTempCount++;
            }
            else if (findString2 != -1 && findString3 != -1){
                stringExtract = arrayTableDisplay [counter1*17+counter2].substr(2);
                arrayTableDisplay [counter1*17+counter2] = arrayTableDisplay [counter1*17+counter2].substr(1);
                
                markTemp = "p"+stringExtract;
                
                if (stringExtract.length() == 1) stringExtract = "00"+stringExtract;
                else if (stringExtract.length() == 2) stringExtract = "0"+stringExtract;
                
                stringExtract = "-6"+stringExtract;
                arrayTableTemp [tableTempCount] = atoi(stringExtract.c_str()), tableTempCount++;
                
                timeStringTemp = arrayTableDisplay [counter2].substr(1);
                timePointStartToLast = atoi(timeStringTemp.c_str());
                columnStartToLast = counter1;
                
                markTempInt = atoi(stringExtract.c_str());
            }
            else if (findString2 == -1 && findString4 != -1){
                stringExtract = arrayTableDisplay [counter1*17+counter2].substr(1);
                
                if (stringExtract.length() == 1) stringExtract = "00"+stringExtract;
                else if (stringExtract.length() == 2) stringExtract = "0"+stringExtract;
                
                stringExtract = "-7"+stringExtract;
                arrayTableTemp [tableTempCount] = atoi(stringExtract.c_str()), tableTempCount++;
            }
            else if (findString2 != -1 && findString4 != -1){
                stringExtract = arrayTableDisplay [counter1*17+counter2].substr(2);
                arrayTableDisplay [counter1*17+counter2] = arrayTableDisplay [counter1*17+counter2].substr(1);
                
                markTemp = "P"+stringExtract;
                
                if (stringExtract.length() == 1) stringExtract = "00"+stringExtract;
                else if (stringExtract.length() == 2) stringExtract = "0"+stringExtract;
                
                stringExtract = "-7"+stringExtract;
                arrayTableTemp [tableTempCount] = atoi(stringExtract.c_str()), tableTempCount++;
                
                timeStringTemp = arrayTableDisplay [counter2].substr(1);
                timePointStartToLast = atoi(timeStringTemp.c_str());
                columnStartToLast = counter1;
                
                markTempInt = atoi(stringExtract.c_str());
            }
            else if (findString2 == -1 && findString5 != -1){
                stringExtract = arrayTableDisplay [counter1*17+counter2].substr(1);
                
                if (stringExtract.length() == 1) stringExtract = "00"+stringExtract;
                else if (stringExtract.length() == 2) stringExtract = "0"+stringExtract;
                
                stringExtract = "-8"+stringExtract;
                arrayTableTemp [tableTempCount] = atoi(stringExtract.c_str()), tableTempCount++;
            }
            else if (findString2 != -1 && findString5 != -1){
                stringExtract = arrayTableDisplay [counter1*17+counter2].substr(2);
                arrayTableDisplay [counter1*17+counter2] = arrayTableDisplay [counter1*17+counter2].substr(1);
                
                markTemp = "s"+stringExtract;
                
                if (stringExtract.length() == 1) stringExtract = "00"+stringExtract;
                else if (stringExtract.length() == 2) stringExtract = "0"+stringExtract;
                
                stringExtract = "-8"+stringExtract;
                arrayTableTemp [tableTempCount] = atoi(stringExtract.c_str()), tableTempCount++;
                
                timeStringTemp = arrayTableDisplay [counter2].substr(1);
                timePointStartToLast = atoi(timeStringTemp.c_str());
                columnStartToLast = counter1;
                
                markTempInt = atoi(stringExtract.c_str());
            }
            else if (findString2 == -1 && findString6 != -1){
                stringExtract = arrayTableDisplay [counter1*17+counter2].substr(1);
                
                if (stringExtract.length() == 1) stringExtract = "00"+stringExtract;
                else if (stringExtract.length() == 2) stringExtract = "0"+stringExtract;
                
                stringExtract = "-9"+stringExtract;
                arrayTableTemp [tableTempCount] = atoi(stringExtract.c_str()), tableTempCount++;
            }
            else if (findString2 != -1 && findString6 != -1){
                stringExtract = arrayTableDisplay [counter1*17+counter2].substr(2);
                arrayTableDisplay [counter1*17+counter2] = arrayTableDisplay [counter1*17+counter2].substr(1);
                
                markTemp = "S"+stringExtract;
                
                if (stringExtract.length() == 1) stringExtract = "00"+stringExtract;
                else if (stringExtract.length() == 2) stringExtract = "0"+stringExtract;
                
                stringExtract = "-9"+stringExtract;
                arrayTableTemp [tableTempCount] = atoi(stringExtract.c_str()), tableTempCount++;
                
                timeStringTemp = arrayTableDisplay [counter2].substr(1);
                timePointStartToLast = atoi(timeStringTemp.c_str());
                columnStartToLast = counter1;
                
                markTempInt = atoi(stringExtract.c_str());
            }
            else if (findString2 == -1 && findString7 != -1){
                stringExtract = arrayTableDisplay [counter1*17+counter2].substr(1);
                
                timeStartTemp = stringExtract.substr(0, stringExtract.find("-"));
                timeEndTemp = stringExtract.substr(stringExtract.find("-")+1);
                
                if (timeStartTemp.length() == 1) timeStartTemp = "00"+timeStartTemp;
                else if (timeStartTemp.length() == 2) timeStartTemp = "0"+timeStartTemp;
                
                if (timeEndTemp.length() == 1) timeEndTemp = "00"+timeEndTemp;
                else if (timeEndTemp.length() == 2) timeEndTemp = "0"+timeEndTemp;
                
                stringExtract = "-10"+timeStartTemp+timeEndTemp;
                arrayTableTemp [tableTempCount] = atoi(stringExtract.c_str()), tableTempCount++;
            }
            else if (findString2 != -1 && findString7 != -1){
                stringExtract = arrayTableDisplay [counter1*17+counter2].substr(2);
                
                arrayTableDisplay [counter1*17+counter2] = arrayTableDisplay [counter1*17+counter2].substr(1);
                
                timeStartTemp = stringExtract.substr(0, stringExtract.find("-"));
                timeEndTemp = stringExtract.substr(stringExtract.find("-")+1);
                
                markTemp = "r"+timeStartTemp+"-"+timeEndTemp;
                
                if (timeStartTemp.length() == 1) timeStartTemp = "00"+timeStartTemp;
                else if (timeStartTemp.length() == 2) timeStartTemp = "0"+timeStartTemp;
                
                if (timeEndTemp.length() == 1) timeEndTemp = "00"+timeEndTemp;
                else if (timeEndTemp.length() == 2) timeEndTemp = "0"+timeEndTemp;
                
                stringExtract = "-10"+timeStartTemp+timeEndTemp;
                arrayTableTemp [tableTempCount] = atoi(stringExtract.c_str()), tableTempCount++;
                
                timeStringTemp = arrayTableDisplay [counter2].substr(1);
                timePointStartToLast = atoi(timeStringTemp.c_str());
                columnStartToLast = counter1;
                
                markTempInt = atoi(stringExtract.c_str());
            }
            else if (findString2 == -1 && findString8 != -1){
                stringExtract = arrayTableDisplay [counter1*17+counter2].substr(1);
                
                timeStartTemp = stringExtract.substr(0, stringExtract.find("-"));
                timeEndTemp = stringExtract.substr(stringExtract.find("-")+1);
                
                if (timeStartTemp.length() == 1) timeStartTemp = "00"+timeStartTemp;
                else if (timeStartTemp.length() == 2) timeStartTemp = "0"+timeStartTemp;
                
                if (timeEndTemp.length() == 1) timeEndTemp = "00"+timeEndTemp;
                else if (timeEndTemp.length() == 2) timeEndTemp = "0"+timeEndTemp;
                
                stringExtract = "-11"+timeStartTemp+timeEndTemp;
                arrayTableTemp [tableTempCount] = atoi(stringExtract.c_str()), tableTempCount++;
            }
            else if (findString2 != -1 && findString8 != -1){
                stringExtract = arrayTableDisplay [counter1*17+counter2].substr(2);
                
                arrayTableDisplay [counter1*17+counter2] = arrayTableDisplay [counter1*17+counter2].substr(1);
                
                timeStartTemp = stringExtract.substr(0, stringExtract.find("-"));
                timeEndTemp = stringExtract.substr(stringExtract.find("-")+1);
                
                markTemp = "R"+timeStartTemp+"-"+timeEndTemp;
                
                if (timeStartTemp.length() == 1) timeStartTemp = "00"+timeStartTemp;
                else if (timeStartTemp.length() == 2) timeStartTemp = "0"+timeStartTemp;
                
                if (timeEndTemp.length() == 1) timeEndTemp = "00"+timeEndTemp;
                else if (timeEndTemp.length() == 2) timeEndTemp = "0"+timeEndTemp;
                
                stringExtract = "-11"+timeStartTemp+timeEndTemp;
                arrayTableTemp [tableTempCount] = atoi(stringExtract.c_str()), tableTempCount++;
                
                timeStringTemp = arrayTableDisplay [counter2].substr(1);
                timePointStartToLast = atoi(timeStringTemp.c_str());
                columnStartToLast = counter1;
                
                markTempInt = atoi(stringExtract.c_str());
            }
            else if (tableConversion > 0) arrayTableTemp [tableTempCount] = tableConversion, tableTempCount++;
            else if (tableConversion == -1000) arrayTableTemp [tableTempCount] = -1000, tableTempCount++;
            else if (tableConversion == -2000) arrayTableTemp [tableTempCount] = -2000, tableTempCount++;
            else if (tableConversion == -2500) arrayTableTemp [tableTempCount] = -2500, tableTempCount++;
            else if (tableConversion == 0) arrayTableTemp [tableTempCount] = 0, tableTempCount++;
            else arrayTableTemp [tableTempCount] = 0, tableTempCount++;
        }
    }
    
    //for (int counterA = 0; counterA < treatmentNameDisplayCount; counterA++){
    //    for (int counterB = 0; counterB < 17; counterB++) cout<<" "<<arrayTableTemp [counterA*17+counterB];
    //    cout<<" arrayTableTemp "<<counterA+1<<endl;
    //}
    
    int currentCutOff = 0;
    
    if (importTableEnd != -1) currentCutOff = importTableEnd;
    else currentCutOff = currentTimePoint;
    
    stringExtract = arrayTableDisplay [2].substr(1);
    int firstTimePoint = atoi (stringExtract.c_str());
    
    //for (int counterA = 0; counterA < 20; counterA++){
    //    for (int counterB = 0; counterB < 20; counterB++) cout<<" "<<arrayFocalPlaneData [counterA][counterB];
    //    cout<<"  arrayFocalPlaneData "<<counterA+1<<endl;
    // }
    
    int tableReadCount = 0;
    
    for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
        tableReadCount = 2;
        
        for (int counter2 = firstTimePoint; counter2 < firstTimePoint+15; counter2++){
            if (counter2 <= currentCutOff){
                arrayFocalPlaneData [counter1][counter2+1] = arrayTableTemp [counter1*17+tableReadCount];
                tableReadCount++;
            }
        }
    }
    
    //for (int counterA = 0; counterA < 20; counterA++){
    //    for (int counterB = 0; counterB < 20; counterB++) cout<<" "<<arrayFocalPlaneData [counterA][counterB];
    //    cout<<"  arrayFocalPlaneData "<<counterA+1<<endl;
    //}
    
    if (markTemp != ""){
        for (int counter1 = timePointStartToLast+1; counter1 < currentCutOff+2; counter1++){
            if (arrayFocalPlaneData [columnStartToLast][counter1] != -5000 && arrayFocalPlaneData [columnStartToLast][counter1] != -2500 && arrayFocalPlaneData [columnStartToLast][counter1] != -2000) arrayFocalPlaneData [columnStartToLast][counter1] = markTempInt;
        }
        
        //for (int counterA = 0; counterA < treatmentNameDisplayCount; counterA++){
        //  for (int counterB = 0; counterB < 17; counterB++) cout<<" "<<arrayTableDisplay [counterA*17+counterB];
        //   cout<<" arrayTableDisplay "<<counterA+1<<endl;
        // }
        
        // for (int counterA = 0; counterA < 20; counterA++){
        //   for (int counterB = 0; counterB < 20; counterB++) cout<<" "<<arrayFocalPlaneData [counterA][counterB];
        // cout<<"  arrayFocalPlaneData "<<counterA+1<<endl;
        //}
        
        string timeWriteTemp;
        string timeMarkTemp;
        string timeMarkSetTemp;
        int writingStart = 0;
        
        for (int counter1 = 0; counter1 < 17; counter1++){
            timeWriteTemp = arrayTableDisplay [counter1];
            timeMarkTemp = timeWriteTemp.substr(0, 1);
            timeWriteTemp = timeWriteTemp.substr(1);
            timeMarkSetTemp = arrayTableDisplay [columnStartToLast*17+counter1];
            
            if (timePointStartToLast == atoi(timeWriteTemp.c_str()) && writingStart == 0){
                writingStart = 1;
            }
            else if (writingStart == 1){
                if (timeMarkTemp != "C" && timeMarkTemp != "E" && timeMarkSetTemp != "T" && timeMarkSetTemp != "*") arrayTableDisplay [columnStartToLast*17+counter1] = markTemp;
                else{
                    
                    if (timeMarkTemp == "C" && timeMarkSetTemp != "T" && timeMarkSetTemp != "*"){
                        arrayTableDisplay [columnStartToLast*17+counter1] = markTemp;
                        writingStart = 0;
                    }
                    else if (timeMarkTemp == "E" && timeMarkSetTemp != "T" && timeMarkSetTemp != "*"){
                        arrayTableDisplay [columnStartToLast*17+counter1] = markTemp;
                        writingStart = 0;
                    }
                }
            }
        }
    }
    
    //for (int counterA = 0; counterA < treatmentNameDisplayCount; counterA++){
    //  for (int counterB = 0; counterB < 17; counterB++) cout<<" "<<arrayTableDisplay [counterA*17+counterB];
    //   cout<<" arrayTableDisplay "<<counterA+1<<endl;
    //}
    
    //for (int counterA = 0; counterA < treatmentNameDisplayCount; counterA++){
    //    for (int counterB = 0; counterB < 17; counterB++) cout<<" "<<arrayTableDisplay [counterA*17+counterB];
    //    cout<<" arrayTableDisplay "<<counterA+1<<endl;
    //}
    
    //for (int counterA = 0; counterA < 10; counterA++){
    //    for (int counterB = 0; counterB < currentCutOff+2; counterB++) cout<<" "<<arrayFocalPlaneData [counterA][counterB];
    //    cout<<"  arrayFocalPlaneData "<<counterA+1<<endl;
    //}
    
    ofstream oin;
    
    if (processMode == 5 || processMode == 7) oin.open(productsFocalPlaneTempPath.c_str(), ios::out);
    else oin.open(productsFocalPlanePath.c_str(), ios::out);
    
    for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
        for (int counter2 = 0; counter2 < currentCutOff+2; counter2++) oin<<arrayFocalPlaneData [counter1][counter2]<<endl;
    }
    
    oin.close();
    
    delete [] arrayTableTemp;
}

-(IBAction)omnibusProcess:(id)sender{
    if ((processMode == 2 || processMode == 8) && focusProcessFlag == 0){
        firstTimeSet = 0;
        currentTimePoint = 1;
        importTableEnd = -1;
        
        lastColumnNoHold = 0;
        lastRowNoHold = 0;
        lastTypeHold = "X";
        
        [self saveParameter];
        
        tableDisplayCount = 0;
        currentTableHead = 2;
        
        arrayTableDisplay [tableDisplayCount] = "Name", tableDisplayCount++;
        arrayTableDisplay [tableDisplayCount] = "FOV", tableDisplayCount++;
        arrayTableDisplay [tableDisplayCount] = "C1", tableDisplayCount++;
        
        string extension;
        
        for (int counter1 = 3; counter1 < 17; counter1++){
            extension = to_string(counter1-1);
            arrayTableDisplay [tableDisplayCount] = "T"+extension, tableDisplayCount++;
        }
        
        for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
            if (arrayTreatmentNameDisplay [counter1] != "ND") arrayTableDisplay [tableDisplayCount] = arrayTreatmentNameDisplay [counter1], tableDisplayCount++;
            else arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
            
            if (arrayFOVNameDisplay [counter1] != "ND") arrayTableDisplay [tableDisplayCount] = arrayFOVNameDisplay [counter1], tableDisplayCount++;
            else arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
            
            if (arrayFOVNameDisplay [counter1] != "ND"){
                arrayTableDisplay [tableDisplayCount] = "ND", tableDisplayCount++;
                
                for (int counter2 = 0; counter2 < 14; counter2++) arrayTableDisplay [tableDisplayCount] = "0", tableDisplayCount++;
            }
            else{
                
                for (int counter2 = 0; counter2 < 15; counter2++) arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
            }
        }
        
        [timePointDisplay setIntegerValue:currentTimePoint];
        
        //for (int counterA = 0; counterA < treatmentNameDisplayCount; counterA++){
        //    for (int counterB = 0; counterB < 17; counterB++) cout<<" "<<arrayTableDisplay [counterA*17+counterB];
        //    cout<<" arrayTableDisplay "<<counterA+1<<endl;
        //}
        
        [self tableDataSave];
        tableViewCall = 1;
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Init Mode Off Or File Processing In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)stopProcess:(id)sender{
    int loadingCompleteFlag = 0;
    
    lastColumnNoHold = 0;
    lastRowNoHold = 0;
    lastTypeHold = "X";
    
    ifstream fin;
    fin.open(loadingCompletionPath.c_str(),ios::in);
    
    if (fin.is_open()){
        loadingCompleteFlag = 1;
        fin.close();
    }
    
    if (loadingCompleteFlag == 1){
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"Cancel"];
        [alert addButtonWithTitle:@"Quit"];
        [alert setMessageText:@"File Processing In Progress"];
        [alert setInformativeText:@"Exiting will terminate the initial setup. Please wait for the FIS/CTS display"];
        [alert setAlertStyle:NSAlertStyleWarning];
        
        if ([alert runModal] == NSAlertSecondButtonReturn){
            remove (loadingCompletionPath.c_str());
            [self stopProcessMain];
        }
        
    }
    else [self stopProcessMain];
}

-(void)stopProcessMain{
    for (int counter1 = 0; counter1 < totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100; counter1++) delete [] arrayFocalPlaneData [counter1];
    delete [] arrayFocalPlaneData;
    
    delete [] arrayTreatmentNameDisplay;
    delete [] arrayFOVNameDisplay;
    delete [] arrayTableDisplay;
    delete [] arrayProcessList;
    delete [] arrayFileDelete;
    delete [] arrayDirectoryInfo;
    delete [] backUpDirectoryArray;
    delete [] backUpFolderNoUpDateArray;
    delete [] backUpFileArray;
    
    if (imageDataHoldZImageStatus == 1){
        for (int counter1 = 0; counter1 < zImageHeight*zImagePlane+2; counter1++) delete [] arrayImageDataHoldZImage [counter1];
        delete [] arrayImageDataHoldZImage;
    }
    
    if (imageDataHoldBackUpImageStatus == 1){
        for (int counter1 = 0; counter1 < backUpImageWidth*backUpImagePlane+2; counter1++) delete [] arrayImageDataHoldBackUpImage [counter1];
        delete [] arrayImageDataHoldBackUpImage;
    }
    
    exit (0);
}

-(IBAction)fwOmnibus:(id)sender{
    if (focusProcessFlag == 0){
        lastColumnNoHold = 0;
        lastRowNoHold = 0;
        lastTypeHold = "X";
        
        int currentCutOff = 0;
        
        if (importTableEnd != -1) currentCutOff = importTableEnd;
        else currentCutOff = currentTimePoint;
        
        string rowNumber = arrayTableDisplay [2];
        rowNumber = rowNumber.substr(1);
        
        int startingTimePoint;
        
        if (importTableEnd == -1){
            if (currentTimePoint >= atoi(rowNumber.c_str())+10){
                startingTimePoint = atoi(rowNumber.c_str())+10;
                tableDisplayCount = 0;
            }
            else{
                
                startingTimePoint = currentTimePoint;
                tableDisplayCount = 0;
            }
        }
        else{
            
            if (atoi(rowNumber.c_str())+10 < importTableEnd){
                startingTimePoint = atoi(rowNumber.c_str())+10;
                tableDisplayCount = 0;
            }
            else{
                
                startingTimePoint = importTableEnd;
                tableDisplayCount = 0;
            }
        }
        
        //for (int counterA = 0; counterA < treatmentNameDisplayCount; counterA++){
        //    for (int counterB = 0; counterB < 17; counterB++) cout<<" "<<arrayTableDisplay [counterA*17+counterB];
        //    cout<<" arrayTableDisplay "<<counterA+1<<endl;
        //}
        
        [self tableBackwardForward:startingTimePoint:currentCutOff];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"File Processing In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)fwHundred:(id)sender{
    if (focusProcessFlag == 0){
        lastColumnNoHold = 0;
        lastRowNoHold = 0;
        lastTypeHold = "X";
        
        int currentCutOff = 0;
        
        if (importTableEnd != -1) currentCutOff = importTableEnd;
        else currentCutOff = currentTimePoint;
        
        string rowNumber = arrayTableDisplay [2];
        rowNumber = rowNumber.substr(1);
        
        int startingTimePoint;
        
        if (importTableEnd == -1){
            if (currentTimePoint >= atoi(rowNumber.c_str())+100){
                startingTimePoint = atoi(rowNumber.c_str())+100;
                tableDisplayCount = 0;
            }
            else{
                
                startingTimePoint = currentTimePoint;
                tableDisplayCount = 0;
            }
        }
        else{
            
            if (atoi(rowNumber.c_str())+100 < importTableEnd){
                startingTimePoint = atoi(rowNumber.c_str())+100;
                tableDisplayCount = 0;
            }
            else{
                
                startingTimePoint = importTableEnd;
                tableDisplayCount = 0;
            }
        }
        
        [self tableBackwardForward:startingTimePoint:currentCutOff];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"File Processing In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)bwOmnibus:(id)sender{
    if (focusProcessFlag == 0){
        lastColumnNoHold = 0;
        lastRowNoHold = 0;
        lastTypeHold = "X";
        
        int currentCutOff = 0;
        
        if (importTableEnd != -1) currentCutOff = importTableEnd;
        else currentCutOff = currentTimePoint;
        
        string rowNumber = arrayTableDisplay [2];
        rowNumber = rowNumber.substr(1);
        
        int startingTimePoint;
        
        if (atoi(rowNumber.c_str())-10 > 0){
            startingTimePoint = atoi(rowNumber.c_str())-10;
            tableDisplayCount = 0;
        }
        else{
            
            startingTimePoint = 1;
            tableDisplayCount = 0;
        }
        
        [self tableBackwardForward:startingTimePoint:currentCutOff];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"File Processing In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)bwHundred:(id)sender{
    if (focusProcessFlag == 0){
        lastColumnNoHold = 0;
        lastRowNoHold = 0;
        lastTypeHold = "X";
        
        int currentCutOff = 0;
        
        if (importTableEnd != -1) currentCutOff = importTableEnd;
        else currentCutOff = currentTimePoint;
        
        string rowNumber = arrayTableDisplay [2];
        rowNumber = rowNumber.substr(1);
        
        int startingTimePoint;
        
        if (atoi(rowNumber.c_str())-100 > 0){
            startingTimePoint = atoi(rowNumber.c_str())-100;
            tableDisplayCount = 0;
        }
        else{
            
            startingTimePoint = 1;
            tableDisplayCount = 0;
        }
        
        [self tableBackwardForward:startingTimePoint:currentCutOff];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"File Processing In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)tableBackwardForward :(int)startingTimePoint :(int)currentCutOff{
    //----Line One set----
    arrayTableDisplay [tableDisplayCount] = "Name", tableDisplayCount++;
    arrayTableDisplay [tableDisplayCount] = "FOV", tableDisplayCount++;
    
    string extension;
    int currentHeadFind = 0;
    
    for (int counter1 = startingTimePoint; counter1 < startingTimePoint+15; counter1++){
        extension = to_string(counter1);
        
        if (importTableEnd == counter1 && importTableEnd != currentTimePoint) arrayTableDisplay [tableDisplayCount] = "E"+extension, tableDisplayCount++;
        else if (currentTimePoint == counter1){
            arrayTableDisplay [tableDisplayCount] = "C"+extension, currentTableHead = tableDisplayCount, tableDisplayCount++;
            currentHeadFind = 1;
        }
        else arrayTableDisplay [tableDisplayCount] = "T"+extension, tableDisplayCount++;
    }
    
    if (currentHeadFind == 0) currentTableHead = 17;
    
    if (arrayTreatmentNameDisplay [0] != "nil"){
        string extract1;
        string extract2;
        
        for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
            if (arrayTreatmentNameDisplay [counter1] != "ND") arrayTableDisplay [tableDisplayCount] = arrayTreatmentNameDisplay [counter1], tableDisplayCount++;
            else arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
            
            if (arrayFOVNameDisplay [counter1] != "ND") arrayTableDisplay [tableDisplayCount] = arrayFOVNameDisplay [counter1], tableDisplayCount++;
            else arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
            
            if (arrayFOVNameDisplay [counter1] != "ND"){
                for (int counter2 = startingTimePoint; counter2 < startingTimePoint+15; counter2++){
                    if (counter2 > currentCutOff) arrayTableDisplay [tableDisplayCount] = "0", tableDisplayCount++;
                    else if (counter2 == currentTimePoint){
                        if (arrayFocalPlaneData [counter1][counter2+1] == -1000) arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -2000) arrayTableDisplay [tableDisplayCount] = "*", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -2500) arrayTableDisplay [tableDisplayCount] = "*", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -3000) arrayTableDisplay [tableDisplayCount] = "f", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -3500) arrayTableDisplay [tableDisplayCount] = "F", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] < -6000 && arrayFocalPlaneData [counter1][counter2+1] > -7000){
                            extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                            extension = extension.substr(2);
                            extension = to_string(atoi(extension.c_str()));
                            
                            arrayTableDisplay [tableDisplayCount] = "p"+extension, tableDisplayCount++;
                        }
                        else if (arrayFocalPlaneData [counter1][counter2+1] < -7000 && arrayFocalPlaneData [counter1][counter2+1] > -8000){
                            extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                            extension = extension.substr(2);
                            extension = to_string(atoi(extension.c_str()));
                            
                            arrayTableDisplay [tableDisplayCount] = "P"+extension, tableDisplayCount++;
                        }
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -4000) arrayTableDisplay [tableDisplayCount] = "a", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -4500) arrayTableDisplay [tableDisplayCount] = "A", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] < -8000 && arrayFocalPlaneData [counter1][counter2+1] > -9000){
                            extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                            extension = extension.substr(2);
                            extension = to_string(atoi(extension.c_str()));
                            
                            arrayTableDisplay [tableDisplayCount] = "s"+extension, tableDisplayCount++;
                        }
                        else if (arrayFocalPlaneData [counter1][counter2+1] < -9000 && arrayFocalPlaneData [counter1][counter2+1] > -10000){
                            extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                            extension = extension.substr(2);
                            extension = to_string(atoi(extension.c_str()));
                            
                            arrayTableDisplay [tableDisplayCount] = "S"+extension, tableDisplayCount++;
                        }
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -5000) arrayTableDisplay [tableDisplayCount] = "T", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] < -10000000 && arrayFocalPlaneData [counter1][counter2+1] > -11000000){
                            extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                            extract1 = extension.substr(3, 3);
                            extract2 = extension.substr(6, 3);
                            extract1 = to_string(atoi(extract1.c_str()));
                            extract2 = to_string(atoi(extract2.c_str()));
                            
                            arrayTableDisplay [tableDisplayCount] = "r"+extract1+"-"+extract2, tableDisplayCount++;
                        }
                        else if (arrayFocalPlaneData [counter1][counter2+1] < -11000000 && arrayFocalPlaneData [counter1][counter2+1] > -12000000){
                            extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                            extract1 = extension.substr(3, 3);
                            extract2 = extension.substr(6, 3);
                            extract1 = to_string(atoi(extract1.c_str()));
                            extract2 = to_string(atoi(extract2.c_str()));
                            
                            arrayTableDisplay [tableDisplayCount] = "R"+extract1+"-"+extract2, tableDisplayCount++;
                        }
                        else arrayTableDisplay [tableDisplayCount] = "ND", tableDisplayCount++;
                    }
                    else if (counter2 == importTableEnd){
                        if (arrayFocalPlaneData [counter1][counter2+1] == -1000) arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -2000) arrayTableDisplay [tableDisplayCount] = "*", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -2500) arrayTableDisplay [tableDisplayCount] = "*", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -3000) arrayTableDisplay [tableDisplayCount] = "f", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -3500) arrayTableDisplay [tableDisplayCount] = "F", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] < -6000 && arrayFocalPlaneData [counter1][counter2+1] > -7000){
                            extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                            extension = extension.substr(2);
                            extension = to_string(atoi(extension.c_str()));
                            
                            arrayTableDisplay [tableDisplayCount] = "p"+extension, tableDisplayCount++;
                        }
                        else if (arrayFocalPlaneData [counter1][counter2+1] < -7000 && arrayFocalPlaneData [counter1][counter2+1] > -8000){
                            extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                            extension = extension.substr(2);
                            extension = to_string(atoi(extension.c_str()));
                            
                            arrayTableDisplay [tableDisplayCount] = "P"+extension, tableDisplayCount++;
                        }
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -4000) arrayTableDisplay [tableDisplayCount] = "a", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -4500) arrayTableDisplay [tableDisplayCount] = "A", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] < -8000 && arrayFocalPlaneData [counter1][counter2+1] > -9000){
                            extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                            extension = extension.substr(2);
                            extension = to_string(atoi(extension.c_str()));
                            
                            arrayTableDisplay [tableDisplayCount] = "s"+extension, tableDisplayCount++;
                        }
                        else if (arrayFocalPlaneData [counter1][counter2+1] < -9000 && arrayFocalPlaneData [counter1][counter2+1] > -10000){
                            extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                            extension = extension.substr(2);
                            extension = to_string(atoi(extension.c_str()));
                            
                            arrayTableDisplay [tableDisplayCount] = "S"+extension, tableDisplayCount++;
                        }
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -5000) arrayTableDisplay [tableDisplayCount] = "T", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] < -10000000 && arrayFocalPlaneData [counter1][counter2+1] > -11000000){
                            extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                            extract1 = extension.substr(3, 3);
                            extract2 = extension.substr(6, 3);
                            extract1 = to_string(atoi(extract1.c_str()));
                            extract2 = to_string(atoi(extract2.c_str()));
                            
                            arrayTableDisplay [tableDisplayCount] = "r"+extract1+"-"+extract2, tableDisplayCount++;
                        }
                        else if (arrayFocalPlaneData [counter1][counter2+1] < -11000000 && arrayFocalPlaneData [counter1][counter2+1] > -12000000){
                            extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                            extract1 = extension.substr(3, 3);
                            extract2 = extension.substr(6, 3);
                            extract1 = to_string(atoi(extract1.c_str()));
                            extract2 = to_string(atoi(extract2.c_str()));
                            
                            arrayTableDisplay [tableDisplayCount] = "R"+extract1+"-"+extract2, tableDisplayCount++;
                        }
                        else arrayTableDisplay [tableDisplayCount] = "ND", tableDisplayCount++;
                    }
                    else{
                        
                        if (arrayFocalPlaneData [counter1][counter2+1] == -1000) arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -2000) arrayTableDisplay [tableDisplayCount] = "*", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -2500) arrayTableDisplay [tableDisplayCount] = "*", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -3000) arrayTableDisplay [tableDisplayCount] = "f", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -3500) arrayTableDisplay [tableDisplayCount] = "F", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] < -6000 && arrayFocalPlaneData [counter1][counter2+1] > -7000){
                            extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                            extension = extension.substr(2);
                            extension = to_string(atoi(extension.c_str()));
                            
                            arrayTableDisplay [tableDisplayCount] = "p"+extension, tableDisplayCount++;
                        }
                        else if (arrayFocalPlaneData [counter1][counter2+1] < -7000 && arrayFocalPlaneData [counter1][counter2+1] > -8000){
                            extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                            extension = extension.substr(2);
                            extension = to_string(atoi(extension.c_str()));
                            
                            arrayTableDisplay [tableDisplayCount] = "P"+extension, tableDisplayCount++;
                        }
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -4000) arrayTableDisplay [tableDisplayCount] = "a", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -4500) arrayTableDisplay [tableDisplayCount] = "A", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] < -8000 && arrayFocalPlaneData [counter1][counter2+1] > -9000){
                            extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                            extension = extension.substr(2);
                            extension = to_string(atoi(extension.c_str()));
                            
                            arrayTableDisplay [tableDisplayCount] = "s"+extension, tableDisplayCount++;
                        }
                        else if (arrayFocalPlaneData [counter1][counter2+1] < -9000 && arrayFocalPlaneData [counter1][counter2+1] > -10000){
                            extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                            extension = extension.substr(2);
                            extension = to_string(atoi(extension.c_str()));
                            
                            arrayTableDisplay [tableDisplayCount] = "S"+extension, tableDisplayCount++;
                        }
                        else if (arrayFocalPlaneData [counter1][counter2+1] == -5000) arrayTableDisplay [tableDisplayCount] = "T", tableDisplayCount++;
                        else if (arrayFocalPlaneData [counter1][counter2+1] < -10000000 && arrayFocalPlaneData [counter1][counter2+1] > -11000000){
                            extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                            extract1 = extension.substr(3, 3);
                            extract2 = extension.substr(6, 3);
                            extract1 = to_string(atoi(extract1.c_str()));
                            extract2 = to_string(atoi(extract2.c_str()));
                            
                            arrayTableDisplay [tableDisplayCount] = "r"+extract1+"-"+extract2, tableDisplayCount++;
                        }
                        else if (arrayFocalPlaneData [counter1][counter2+1] < -11000000 && arrayFocalPlaneData [counter1][counter2+1] > -12000000){
                            extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                            extract1 = extension.substr(3, 3);
                            extract2 = extension.substr(6, 3);
                            extract1 = to_string(atoi(extract1.c_str()));
                            extract2 = to_string(atoi(extract2.c_str()));
                            
                            arrayTableDisplay [tableDisplayCount] = "R"+extract1+"-"+extract2, tableDisplayCount++;
                        }
                    }
                }
            }
            else{
                
                for (int counter2 = 0; counter2 < 15; counter2++) arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
            }
        }
        
        tableViewCall = 1;
    }
}

-(IBAction)processStart:(id)sender{
    if (focusProcessFlag == 0){
        lastColumnNoHold = 0;
        lastRowNoHold = 0;
        lastTypeHold = "X";
        
        if (tableDisplayCount != 0 && (processMode == 2 || processMode == 3 || processMode == 8 || processMode == 9)){
            int tableSetCheck = 0;
            
            if (firstTimeSet == 0){
                for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                    if (arrayTableDisplay [counter1*17+2] == "ND"){
                        tableSetCheck = 1;
                        break;
                    }
                }
                
                if (tableSetCheck == 0){
                    string entry;
                    string entry2;
                    string entry3;
                    string productDataPath1;
                    string productDataPath2;
                    string productDataPath3;
                    string productDataPath4;
                    
                    firstTimeSet = 1;
                    
                    //----Cleaning of source image folder----
                    DIR *dir;
                    struct dirent *dent;
                    DIR *dir2;
                    struct dirent *dent2;
                    DIR *dir3;
                    struct dirent *dent3;
                    
                    dir = opendir(productsFilesImagePath.c_str());
                    fileDeleteCount = 0;
                    
                    if (dir != NULL){
                        while((dent = readdir(dir))){
                            entry = dent -> d_name;
                            productDataPath1 = productsFilesImagePath+"/"+entry;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                dir2 = opendir(productDataPath1.c_str());
                                
                                if (dir2 != NULL){
                                    while((dent2 = readdir(dir2))){
                                        entry2 = dent2 -> d_name;
                                        productDataPath2 = productDataPath1+"/"+entry2;
                                        
                                        if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                            dir3 = opendir(productDataPath2.c_str());
                                            
                                            if (dir3 != NULL){
                                                while((dent3 = readdir(dir3))){
                                                    entry3 = dent3 -> d_name;
                                                    
                                                    if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                                    arrayFileDelete [fileDeleteCount] = productDataPath2+"/"+entry3, fileDeleteCount++;
                                                }
                                                
                                                closedir(dir3);
                                            }
                                        }
                                    }
                                    
                                    closedir(dir2);
                                }
                            }
                        }
                        
                        closedir(dir);
                        
                        for(int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                            remove (arrayFileDelete [counter1].c_str());
                        }
                    }
                    
                    dir = opendir(productsFilesImagePath.c_str());
                    fileDeleteCount = 0;
                    
                    if (dir != NULL){
                        while((dent = readdir(dir))){
                            entry = dent -> d_name;
                            productDataPath1 = productsFilesImagePath+"/"+entry;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                dir2 = opendir(productDataPath1.c_str());
                                
                                if (dir2 != NULL){
                                    while((dent2 = readdir(dir2))){
                                        entry2 = dent2 -> d_name;
                                        
                                        if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                        arrayFileDelete [fileDeleteCount] = productDataPath1+"/"+entry2, fileDeleteCount++;
                                    }
                                    
                                    closedir(dir2);
                                }
                            }
                        }
                        
                        closedir(dir);
                        
                        for(int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                            remove (arrayFileDelete [counter1].c_str());
                            rmdir (arrayFileDelete [counter1].c_str());
                        }
                    }
                    
                    fileDeleteCount = 0;
                    
                    dir = opendir(productsFilesImagePath.c_str());
                    
                    if (dir != NULL){
                        while((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                            arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                        }
                        
                        closedir(dir);
                        
                        for(int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                            productDataPath1 = productsFilesImagePath+"/"+arrayFileDelete [counter1];
                            remove (productDataPath1.c_str());
                            rmdir (productDataPath1.c_str());
                        }
                    }
                    
                    dir = opendir(productsFocalTempPath.c_str());
                    fileDeleteCount = 0;
                    
                    if (dir != NULL){
                        while((dent = readdir(dir))){
                            entry = dent -> d_name;
                            productDataPath1 = productsFocalTempPath+"/"+entry;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                dir2 = opendir(productDataPath1.c_str());
                                
                                if (dir2 != NULL){
                                    while((dent2 = readdir(dir2))){
                                        entry2 = dent2 -> d_name;
                                        productDataPath2 = productDataPath1+"/"+entry2;
                                        
                                        if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                            dir3 = opendir(productDataPath2.c_str());
                                            
                                            if (dir3 != NULL){
                                                while((dent3 = readdir(dir3))){
                                                    entry3 = dent3 -> d_name;
                                                    
                                                    if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                                    arrayFileDelete [fileDeleteCount] = productDataPath2+"/"+entry3, fileDeleteCount++;
                                                }
                                                
                                                closedir(dir3);
                                            }
                                        }
                                    }
                                    
                                    closedir(dir2);
                                }
                            }
                        }
                        
                        closedir(dir);
                        
                        for(int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                            remove (arrayFileDelete [counter1].c_str());
                        }
                    }
                    
                    dir = opendir(productsFocalTempPath.c_str());
                    fileDeleteCount = 0;
                    
                    if (dir != NULL){
                        while((dent = readdir(dir))){
                            entry = dent -> d_name;
                            productDataPath1 = productsFocalTempPath+"/"+entry;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                dir2 = opendir(productDataPath1.c_str());
                                
                                if (dir2 != NULL){
                                    while((dent2 = readdir(dir2))){
                                        entry2 = dent2 -> d_name;
                                        
                                        if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                        arrayFileDelete [fileDeleteCount] = productDataPath1+"/"+entry2, fileDeleteCount++;
                                    }
                                    
                                    closedir(dir2);
                                }
                            }
                        }
                        
                        closedir(dir);
                        
                        for(int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                            remove (arrayFileDelete [counter1].c_str());
                            rmdir (arrayFileDelete [counter1].c_str());
                        }
                    }
                    
                    fileDeleteCount = 0;
                    
                    dir = opendir(productsFocalTempPath.c_str());
                    
                    if (dir != NULL){
                        while((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                            arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                        }
                        
                        closedir(dir);
                        
                        for(int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                            productDataPath1 = productsFocalTempPath+"/"+arrayFileDelete [counter1];
                            remove (productDataPath1.c_str());
                            rmdir (productDataPath1.c_str());
                        }
                    }
                    
                    string processFilePath = namedFilesPath+"/"+bodyName+"-10001";
                    
                    dir = opendir(processFilePath.c_str());
                    
                    if (dir != NULL){
                        string nameExtract1;
                        string nameExtract2;
                        string folderNameCreate = "";
                        string tifExtension;
                        
                        while((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                nameExtract1 = entry.substr(entry.find("-")+1);
                                
                                if ((int)nameExtract1.find("_") == -1){
                                    if (folderNameCreate != entry.substr(0, entry.find("_"))){
                                        folderNameCreate = entry.substr(0, entry.find("_"));
                                        productDataPath1 = productsFilesImagePath+"/"+folderNameCreate+"~Sorted";
                                        productDataPath3 = productsFocalTempPath+"/"+folderNameCreate+"~Sorted";
                                        
                                        mkdir(productDataPath1.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                        mkdir(productDataPath3.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                    }
                                    
                                    if (((int)nameExtract1.find(".TIFF") != -1 || (int)nameExtract1.find(".Tiff") != -1 || (int)nameExtract1.find(".tiff") != -1 || (int)nameExtract1.find(".TIF") != -1 || (int)nameExtract1.find(".Tif") != -1 || (int)nameExtract1.find(".tif") != -1)){
                                        if (((int)nameExtract1.find(".TIFF") != -1)) tifExtension = ".TIFF";
                                        else if (((int)nameExtract1.find(".Tiff") != -1)) tifExtension = ".TIFF";
                                        else if (((int)nameExtract1.find(".tiff") != -1)) tifExtension = ".tiff";
                                        else if (((int)nameExtract1.find(".TIF") != -1)) tifExtension = ".TIF";
                                        else if (((int)nameExtract1.find(".Tif") != -1)) tifExtension = ".Tif";
                                        else if (((int)nameExtract1.find(".tif") != -1)) tifExtension = ".tif";
                                        
                                        nameExtract2 = nameExtract1.substr(0, nameExtract1.find(tifExtension));
                                        
                                        if (nameExtract2.length() == 1) nameExtract2 = "FOV00"+nameExtract2;
                                        else if (nameExtract2.length() == 2) nameExtract2 = "FOV0"+nameExtract2;
                                        else if (nameExtract2.length() == 3) nameExtract2 = "FOV"+nameExtract2;
                                        
                                        productDataPath2 = productsFilesImagePath+"/"+folderNameCreate+"~Sorted"+"/"+nameExtract2;
                                        productDataPath4 = productsFocalTempPath+"/"+folderNameCreate+"~Sorted"+"/"+nameExtract2;
                                        
                                        mkdir(productDataPath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                        mkdir(productDataPath4.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                    }
                                }
                            }
                        }
                        
                        closedir(dir);
                    }
                    
                    dir = opendir(backUpFolderPath.c_str());
                    fileDeleteCount = 0;
                    
                    if (dir != NULL){
                        while((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                int findString1 = (int)entry.find(bodyName+"-");
                                
                                if (findString1 != -1){
                                    productDataPath1 = backUpFolderPath+"/"+entry;
                                    
                                    dir2 = opendir(productDataPath1.c_str());
                                    
                                    if (dir2 != NULL){
                                        while((dent2 = readdir(dir2))){
                                            entry2 = dent2 -> d_name;
                                            
                                            if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                            arrayFileDelete [fileDeleteCount] = productDataPath1+"/"+entry2, fileDeleteCount++;
                                        }
                                        
                                        closedir(dir2);
                                    }
                                }
                            }
                        }
                        
                        closedir(dir);
                        
                        for(int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                            remove (arrayFileDelete [counter1].c_str());
                        }
                    }
                    
                    fileDeleteCount = 0;
                    
                    dir = opendir(backUpFolderPath.c_str());
                    
                    if (dir != NULL){
                        while((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                            arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                        }
                        
                        closedir(dir);
                        
                        for(int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                            entry = arrayFileDelete [counter1];
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                if ((int)entry.find(bodyName+"-") != -1){
                                    productDataPath1 = backUpFolderPath+"/"+entry;
                                    
                                    rmdir (productDataPath1.c_str());
                                }
                            }
                        }
                    }
                    
                    remove (loadingCompletionPath.c_str());
                    
                    ofstream oin;
                    oin.open(loadingCompletionPath.c_str(), ios::out);
                    oin<<"End"<<endl;
                    oin.close();
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    [self processStartSub];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Table Setup Incomplete"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Resetting The Table"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Data Missing Or Init Mode Off"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"File Processing In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)processStartSub{
    if (tableDisplayCount != 0){
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageProcess object:self];
    }
    else if (processMode == 2 || processMode == 3 || processMode == 4 || processMode == 6 || processMode ==  8 || processMode == 9){
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Folder Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)imageLoad:(id)sender{
    if (focusProcessFlag == 0){
        lastColumnNoHold = 0;
        lastRowNoHold = 0;
        lastTypeHold = "X";
        
        string currentNumber;
        
        for (int counter1 = 0; counter1 < 17; counter1++){
            currentNumber = arrayTableDisplay [counter1];
            int stringFind1 = (int)currentNumber.find("C");
            
            if (stringFind1 != -1){
                currentNumber = currentNumber.substr((unsigned long)stringFind1+1);
                break;
            }
        }
        
        if (currentNumber.length() == 1) currentNumber = "1000"+currentNumber;
        else if (currentNumber.length() == 2) currentNumber = "100"+currentNumber;
        else if (currentNumber.length() == 3) currentNumber = "10"+currentNumber;
        else if (currentNumber.length() == 4) currentNumber = "1"+currentNumber;
        
        string entry;
        int findFolder = 0;
        
        DIR *dir;
        struct dirent *dent;
        
        dir = opendir(namedFilesPath.c_str());
        
        if (dir != NULL){
            while((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                    if ((int)entry.find(currentNumber) != -1) findFolder = 1;
                }
            }
            
            closedir(dir);
        }
        
        if (findFolder == 1){
            string channelName;
            string fileColorType;
            string treatName = arrayTableDisplay [rowIndexHold*17];
            string fovName = arrayTableDisplay [rowIndexHold*17+1];
            
            if (treatName == " "){
                for (int counter1 = rowIndexHold-1; counter1 >= 1; counter1--){
                    if (arrayTableDisplay [counter1*17] != " "){
                        treatName = arrayTableDisplay [counter1*17];
                        break;
                    }
                }
            }
            
            int stringFind1 = (int)fovName.find("FOV");
            
            if (stringFind1 != -1){
                fovName = fovName.substr((unsigned long)stringFind1+3);
                channelName = "0";
                fileColorType = "0";
            }
            else{
                
                stringFind1 = (int)fovName.find("-");
                channelName = fovName.substr(fovName.find("CH")+2, 1);
                
                if (channelName == "1") fileColorType = fluorescentNo1;
                else if (channelName == "2") fileColorType = fluorescentNo2;
                else if (channelName == "3") fileColorType = fluorescentNo3;
                else if (channelName == "4") fileColorType = fluorescentNo4;
                else if (channelName == "5") fileColorType = fluorescentNo5;
                else if (channelName == "6") fileColorType = fluorescentNo6;
                
                fovName = fovName.substr((unsigned long)stringFind1+1);
                treatName = treatName.substr(0, treatName.length()-3);
            }
            
            zImageColorSet = fileColorType;
            
            //-----Folder data update-----
            string processFilePath = namedFilesPath+"/"+bodyName+"-"+currentNumber;
            
            imageReadFile = "";
            
            dir = opendir(processFilePath.c_str());
            
            if (dir != NULL){
                string fileTreatName;
                string stringExtract;
                string fileFovNo;
                string fileChName;
                string tifExtension;
                
                while((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        stringFind1 = (int)entry.find("_");
                        
                        fileTreatName = entry.substr(0, (unsigned long)stringFind1);
                        stringExtract = entry.substr(entry.find("-")+1);
                        
                        if ((int)stringExtract.find("_") == -1){
                            if (((int)stringExtract.find(".TIFF") != -1)) tifExtension = ".TIFF";
                            else if (((int)stringExtract.find(".Tiff") != -1)) tifExtension = ".TIFF";
                            else if (((int)stringExtract.find(".tiff") != -1)) tifExtension = ".tiff";
                            else if (((int)stringExtract.find(".TIF") != -1)) tifExtension = ".TIF";
                            else if (((int)stringExtract.find(".Tif") != -1)) tifExtension = ".Tif";
                            else if (((int)stringExtract.find(".tif") != -1)) tifExtension = ".tif";
                            
                            fileFovNo = stringExtract.substr(0, stringExtract.find(tifExtension));
                            fileChName = "0";
                        }
                        else{
                            
                            fileFovNo = stringExtract.substr(0, stringExtract.find("_"));
                            stringExtract = stringExtract.substr(stringExtract.find("_")+1);
                            fileChName = stringExtract.substr(0, 1);
                        }
                        
                        if (treatName == fileTreatName && fovName == fileFovNo && fileColorType == fileChName){
                            imageReadFile = processFilePath+"/"+entry;
                            break;
                        }
                    }
                }
                
                closedir(dir);
            }
            
            if (imageReadFile != ""){
                [zFileName setStringValue:@(entry.c_str())];
                [currentPlaneDisplay setStringValue:@"1"];
                
                if (imageDataHoldZImageStatus == 1){
                    for (int counter1 = 0; counter1 < zImageHeight*zImagePlane+2; counter1++) delete [] arrayImageDataHoldZImage [counter1];
                    delete [] arrayImageDataHoldZImage;
                }
                
                zImageHeight = 0;
                zImageWidth = 0;
                zImagePlane = 1;
                
                //-----Tiff reading-----
                unsigned long stripFirstAddress = 0;
                unsigned long stripByteCountAddress = 0;
                unsigned long nextAddress = 0;
                unsigned long headPosition = 0;
                unsigned long headPositionHold = 0;
                unsigned long stripEntry = 0;
                long sizeForCopy = 0;
                
                double xPosition = 0;
                double yPosition = 0;
                
                int imageWidth = 0;
                int imageHeight = 0;
                int imageBit = 0; // Check 8, 16
                int imageCompression = 0; // Check 1
                int photoMetric = 0;//check 0, 1, 2
                int imageDimension = 0;
                int verticalBmp = 0;
                int horizontalBmpEntry = 0;
                int endianType = 0;
                int samplePerPix = 0;
                int loopCount = 0;
                int dataConversion [4];
                int processType = 1;
                int numberOfLayers = 0;
                int terminationFlag = 0;
                struct stat sizeOfFile;
                
                if (stat(imageReadFile.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                    
                    ifstream fin;
                    
                    fileReadArray = new uint8_t [(int)sizeForCopy+4];
                    fin.open(imageReadFile.c_str(), ios::in | ios::binary);
                    fin.read((char*)fileReadArray, sizeForCopy+1);
                    fin.close();
                    
                    dataConversion [0] = fileReadArray [0];
                    dataConversion [1] = fileReadArray [1];
                    
                    if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                    else endianType = 0;
                    
                    int *arrayExtractedImage3 = new int [100];
                    
                    headPosition = 0;
                    
                    if (endianType == 1){
                        dataConversion [0] = fileReadArray [7];
                        dataConversion [1] = fileReadArray [6];
                        dataConversion [2] = fileReadArray [5];
                        dataConversion [3] = fileReadArray [4];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    else if (endianType == 0){
                        dataConversion [0] = fileReadArray [4];
                        dataConversion [1] = fileReadArray [5];
                        dataConversion [2] = fileReadArray [6];
                        dataConversion [3] = fileReadArray [7];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    
                    headPositionHold = headPosition;
                    loopCount = 1;
                    
                    zImageWidth = 0;
                    zImageHeight = 0;
                    
                    do{
                        
                        terminationFlag = 1;
                        
                        if (endianType == 1){
                            tiffFileRead = [[TiffFileRead alloc] init];
                            [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress :&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                            
                            if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                zImageWidth = imageWidth;
                                zImageHeight = imageHeight;
                            }
                        }
                        else if (endianType == 0){
                            tiffFileRead = [[TiffFileRead alloc] init];
                            [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress :&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                            
                            if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && photoMetric < 3){
                                zImageWidth = imageWidth;
                                zImageHeight = imageHeight;
                            }
                        }
                        
                        if (nextAddress != 0){
                            headPosition = nextAddress;
                            loopCount++;
                        }
                        else terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                    
                    zImagePlane = loopCount;
                    
                    imageDataHoldZImageStatus = 1;
                    
                    arrayImageDataHoldZImage = new int *[zImageHeight*zImagePlane+2];
                    for (int counter1 = 0; counter1 < zImageHeight*zImagePlane+2; counter1++) arrayImageDataHoldZImage [counter1] = new int [zImageWidth*3+2];
                    
                    if (zImageWidth > 0 && zImageHeight > 0){
                        headPosition = headPositionHold;
                        
                        verticalBmp = 0;
                        
                        do{
                            
                            terminationFlag = 1;
                            
                            if (endianType == 1){
                                tiffFileRead = [[TiffFileRead alloc] init];
                                [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress :&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                
                                if (imageWidth > imageHeight) imageDimension = imageWidth;
                                else imageDimension = imageHeight;
                                
                                tiffFileRead = [[TiffFileRead alloc] init];
                                delete [] arrayExtractedImage3;
                                
                                arrayExtractedImage3 = [tiffFileRead imageSetBigEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                            }
                            else if (endianType == 0){
                                tiffFileRead = [[TiffFileRead alloc] init];
                                [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress :&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                
                                if (imageWidth > imageHeight) imageDimension = imageWidth;
                                else imageDimension = imageHeight;
                                
                                tiffFileRead = [[TiffFileRead alloc] init];
                                delete [] arrayExtractedImage3;
                                
                                arrayExtractedImage3 = [tiffFileRead imageSetLittleEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                            }
                            
                            horizontalBmpEntry = 0;
                            
                            if (photoMetric == 1){
                                for (int counter2 = 0; counter2 < imageWidth*imageHeight; counter2++){
                                    arrayImageDataHoldZImage [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter2]);
                                    horizontalBmpEntry++;
                                    
                                    if (horizontalBmpEntry == imageWidth){
                                        horizontalBmpEntry = 0;
                                        verticalBmp++;
                                    }
                                }
                            }
                            else if (photoMetric == 2){
                                for (int counter2 = 0; counter2 < imageWidth*imageHeight; counter2++){
                                    arrayImageDataHoldZImage [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter2*3]), horizontalBmpEntry++;
                                    arrayImageDataHoldZImage [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter2*3+1]), horizontalBmpEntry++;
                                    arrayImageDataHoldZImage [verticalBmp][horizontalBmpEntry] = (int)(arrayExtractedImage3 [counter2*3+2]), horizontalBmpEntry++;
                                    
                                    if (horizontalBmpEntry == imageWidth*3){
                                        horizontalBmpEntry = 0;
                                        verticalBmp++;
                                    }
                                }
                            }
                            
                            photoMetricHold = photoMetric;
                            
                            if (nextAddress != 0){
                                headPosition = nextAddress;
                            }
                            else terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                    
                    delete [] arrayExtractedImage3;
                    delete [] fileReadArray;
                    
                    if (channelName == "0"){
                        //----Image value Min/Max Check-----
                        int *valueFrequency = new int [256];
                        
                        for (int counter1 = 0; counter1 <= 255; counter1++) valueFrequency [counter1] = 0;
                        
                        int valueAverage = 0;
                        
                        for (int counter1 = 0; counter1 < zImageHeight; counter1++){
                            for (int counter2 = 0; counter2 < zImageWidth; counter2++){
                                for (int counter3 = 0; counter3 < zImagePlane; counter3++){
                                    valueAverage = valueAverage+arrayImageDataHoldZImage [counter3*zImageHeight+counter1][counter2];
                                    valueFrequency [arrayImageDataHoldZImage [counter3*zImageHeight+counter1][counter2]]++;
                                }
                            }
                        }
                        
                        //-----Mean and low/high check----
                        int totalPix = zImagePlane*zImageHeight*zImageWidth;
                        valueAverage = (int)(valueAverage/(double)totalPix);
                        int pixNo90 = valueFrequency [valueAverage];
                        int lowerLimitCount = 0;
                        int higherLimitCount = 0;
                        
                        for (int counter1 = 1; counter1 <= 255; counter1++){
                            if (valueAverage-counter1 >= 0){
                                pixNo90 = pixNo90+valueFrequency [valueAverage-counter1];
                                lowerLimitCount = valueAverage-counter1;
                            }
                            if (valueAverage+counter1 <= 255){
                                pixNo90 = pixNo90+valueFrequency [valueAverage+counter1];
                                higherLimitCount = valueAverage+counter1;
                            }
                            if (pixNo90/(double)totalPix > 0.9){
                                break;
                            }
                        }
                        
                        delete [] valueFrequency;
                        
                        //-----Mean and low/high adjust----
                        int dicRangeValue = 0;
                        
                        if (dicRangeSet == 0) dicRangeValue = 0;
                        else if (dicRangeSet == 1) dicRangeValue = 20;
                        else if (dicRangeSet == 2) dicRangeValue = 40;
                        else if (dicRangeSet == 3) dicRangeValue = 60;
                        else if (dicRangeSet == 4) dicRangeValue = 80;
                        
                        double expansionFactor = dicRangeValue/(double)(higherLimitCount-lowerLimitCount);
                        int valueShift = 100-valueAverage;
                        int newPixValue = 0;
                        
                        for (int counter1 = 0; counter1 < zImageHeight; counter1++){
                            for (int counter2 = 0; counter2 < zImageWidth; counter2++){
                                for (int counter3 = 0; counter3 < zImagePlane; counter3++){
                                    newPixValue = arrayImageDataHoldZImage [counter3*zImageHeight+counter1][counter2]+valueShift;
                                    
                                    if (newPixValue < 100) newPixValue = newPixValue-(int)(abs(100-newPixValue)*expansionFactor);
                                    else newPixValue = newPixValue+(int)(abs(100-newPixValue)*expansionFactor);
                                    
                                    if (newPixValue < 0) newPixValue = 0;
                                    if (newPixValue > 255) newPixValue = 255;
                                    
                                    arrayImageDataHoldZImage [counter3*zImageHeight+counter1][counter2] = newPixValue;
                                }
                            }
                        }
                    }
                    
                    planeNumberDisplay = 0;
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay object:self];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"File Missing"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Folder Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"File Processing In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)tableImport:(id)sender{
    if (processMode == 8){
        lastColumnNoHold = 0;
        lastRowNoHold = 0;
        lastTypeHold = "X";
        
        int stringLength = (int)bodyName.length();
        string ifModeExtract = bodyName.substr((unsigned long)stringLength-2, 2);
        
        if (ifModeExtract != "IF"){
            if (focusProcessFlag == 0){
                NSOpenPanel* openDlg = [NSOpenPanel openPanel];
                [openDlg setCanChooseFiles:NO];
                [openDlg setCanChooseDirectories:YES];
                
                if ([openDlg runModal] == NSModalResponseOK){
                    NSArray *files = [openDlg URLs];
                    NSString *fileName = [[files objectAtIndex:0] absoluteString];
                    
                    string directoryPathExtract = [fileName UTF8String];
                    
                    int findString1 = (int)directoryPathExtract.find("/Users/");
                    if (findString1 == -1) findString1 = (int)directoryPathExtract.find("/Volumes/");
                    unsigned long directoryLength = directoryPathExtract.length();
                    
                    string directoryPath = directoryPathExtract.substr((unsigned long)findString1, directoryLength-(unsigned long)findString1-1);
                    string extractedID;
                    string extractedID2;
                    
                    int terminationFlag = 0;
                    
                    do{
                        
                        terminationFlag = 1;
                        
                        findString1 = (int)directoryPath.find("%20");
                        if (findString1 != -1){
                            extractedID2 = directoryPath.substr(0, (unsigned long)findString1);
                            directoryPath = directoryPath.substr((unsigned long)findString1+3);
                            directoryPath = extractedID2+" "+directoryPath;
                        }
                        else terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                    
                    extractedID = directoryPath;
                    
                    do{
                        
                        terminationFlag = 1;
                        findString1 = (int)extractedID.find("/");
                        
                        if (findString1 != -1){
                            extractedID = extractedID.substr((unsigned long)findString1+1);
                        }
                        else terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                    
                    int findString2 = (int)extractedID.find("_Products");
                    int findString3 = (int)extractedID.find("_Products_");
                    
                    if (extractedID != "" && findString2 != -1 && findString3 == -1){
                        string *arrayTreatmentNameDisplayTemp = new string [totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100];
                        int treatmentNameDisplayTempCount = 0;
                        
                        string *arrayFOVNameDisplayTemp = new string [totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100];
                        int fovNameDisplayTempCount = 0;
                        
                        string treatmentPath = directoryPath+"/"+"Analysis_Information"+"/"+"FI-TreatmentNameData";
                        string fovPath = directoryPath+"/"+"Analysis_Information"+"/"+"FI-FOVData";
                        string focalPath = directoryPath+"/"+"Analysis_Information"+"/"+"FI-FocalPlaneData";
                        string currentTimePath = directoryPath+"/"+"Analysis_Information"+"/"+"FI-BasicSetting";
                        string getString;
                        
                        ifstream fin;
                        fin.open(treatmentPath.c_str(),ios::in);
                        
                        if (fin.is_open()){
                            do{
                                
                                getline(fin, getString);
                                
                                if (getString != "" && treatmentNameDisplayTempCount < totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100) arrayTreatmentNameDisplayTemp [treatmentNameDisplayTempCount] = getString, treatmentNameDisplayTempCount++;
                                
                            } while (getString != "");
                            
                            fin.close();
                        }
                        
                        //for (int counterA = 0; counterA < treatmentNameDisplayTempCount; counterA++){
                        //    cout<<arrayTreatmentNameDisplayTemp [counterA]<<"  arrayTreatmentNameDisplayTemp "<<endl;
                        //}
                        
                        fin.open(fovPath.c_str(),ios::in);
                        
                        if (fin.is_open()){
                            do{
                                
                                getline(fin, getString);
                                
                                if (getString != "" && fovNameDisplayTempCount < totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100) arrayFOVNameDisplayTemp [fovNameDisplayTempCount] = getString, fovNameDisplayTempCount++;
                                
                            } while (getString != "");
                            
                            fin.close();
                        }
                        
                        //for (int counterA = 0; counterA < fovNameDisplayTempCount; counterA++){
                        //    cout<<arrayTreatmentNameDisplayTemp  [counterA] <<" "<<arrayFOVNameDisplayTemp [counterA]<<"  arrayFOVNameDisplayTemp "<<endl;
                        //}
                        
                        if (treatmentNameDisplayTempCount == treatmentNameDisplayCount && fovNameDisplayTempCount == fOVNameDisplayCount){
                            int *rowInfoData = new int [(totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount)*2+5], rowInfoDataCount = 0;
                            
                            string treatNameHold = "nil";
                            string stringExtract;
                            string currentFov;
                            
                            int missMatchFind = 0;
                            int treatAndFovHoldCount = 0;
                            int findTreatFlag = 0;
                            int findPosition = 0;
                            int treatAndFovHoldTableCount = 0;
                            
                            for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                                if (arrayTreatmentNameDisplay [counter1] != "ND"){
                                    treatNameHold = arrayTreatmentNameDisplay [counter1];
                                    stringExtract = treatNameHold.substr(treatNameHold.length()-3);
                                    
                                    if ((int)stringExtract.find("CH") == -1){
                                        treatAndFovHoldCount = 0;
                                        findTreatFlag = 0;
                                        currentFov = arrayFOVNameDisplay [counter1];
                                        
                                        for (int counter2 = 0; counter2 < treatmentNameDisplayCount; counter2++){
                                            if (arrayTreatmentNameDisplay [counter2] == treatNameHold && arrayFOVNameDisplay [counter2] != "ND" && findTreatFlag == 0){
                                                findTreatFlag = 1;
                                                treatAndFovHoldCount++;
                                            }
                                            else if ((arrayTreatmentNameDisplay [counter2] == treatNameHold || arrayTreatmentNameDisplay [counter2] == "ND") && arrayFOVNameDisplay [counter2] != "ND" && findTreatFlag == 1){
                                                treatAndFovHoldCount++;
                                            }
                                            else{
                                                
                                                if (findTreatFlag == 1){
                                                    break;
                                                }
                                            }
                                        }
                                        
                                        findPosition = 0;
                                        
                                        for (int counter2 = 0; counter2 < treatmentNameDisplayCount; counter2++){
                                            if (treatNameHold == arrayTreatmentNameDisplayTemp [counter2] && currentFov == arrayFOVNameDisplayTemp [counter2]){
                                                findPosition = counter2;
                                                break;
                                            }
                                        }
                                        
                                        if (findPosition == 0){
                                            missMatchFind = 1;
                                            break;
                                        }
                                        else{
                                            
                                            findTreatFlag = 0;
                                            treatAndFovHoldTableCount = 0;
                                            
                                            for (int counter2 = findPosition; counter2 < treatmentNameDisplayCount; counter2++){
                                                if (arrayTreatmentNameDisplayTemp [counter2] == treatNameHold && arrayFOVNameDisplayTemp [counter2] != "ND" && findTreatFlag == 0){
                                                    findTreatFlag = 1;
                                                    treatAndFovHoldTableCount++;
                                                }
                                                else if ((arrayTreatmentNameDisplayTemp [counter2] == treatNameHold || arrayTreatmentNameDisplayTemp [counter2] == "ND") && arrayFOVNameDisplayTemp [counter2] != "ND" && findTreatFlag == 1){
                                                    treatAndFovHoldTableCount++;
                                                }
                                                else{
                                                    
                                                    if (findTreatFlag == 1){
                                                        break;
                                                    }
                                                }
                                            }
                                            
                                            if (treatAndFovHoldTableCount == treatAndFovHoldCount){
                                                rowInfoData [rowInfoDataCount] = findPosition, rowInfoDataCount++;
                                                rowInfoData [rowInfoDataCount] = findPosition+treatAndFovHoldTableCount-1, rowInfoDataCount++;
                                            }
                                            else{
                                                
                                                missMatchFind = 1;
                                                break;
                                            }
                                        }
                                        
                                    }
                                    else{
                                        
                                        findTreatFlag = 0;
                                        treatAndFovHoldCount = 0;
                                        currentFov = arrayFOVNameDisplay [counter1];
                                        
                                        for (int counter2 = 0; counter2 < treatmentNameDisplayCount; counter2++){
                                            if (arrayTreatmentNameDisplay [counter2] == treatNameHold && arrayFOVNameDisplay [counter2] != "ND" && findTreatFlag == 0){
                                                findTreatFlag = 1;
                                                treatAndFovHoldCount++;
                                            }
                                            else if ((arrayTreatmentNameDisplay [counter2] == treatNameHold || arrayTreatmentNameDisplay [counter2] == "ND") && arrayFOVNameDisplay [counter2] != "ND" && findTreatFlag == 1){
                                                treatAndFovHoldCount++;
                                            }
                                            else{
                                                
                                                if (findTreatFlag == 1){
                                                    break;
                                                }
                                            }
                                        }
                                        
                                        findPosition = 0;
                                        
                                        for (int counter2 = 0; counter2 < treatmentNameDisplayCount; counter2++){
                                            if (treatNameHold == arrayTreatmentNameDisplayTemp [counter2] && currentFov == arrayFOVNameDisplayTemp [counter2]){
                                                findPosition = counter2;
                                                break;
                                            }
                                        }
                                        
                                        if (findPosition == 0){
                                            missMatchFind = 1;
                                            break;
                                        }
                                        else{
                                            
                                            findTreatFlag = 0;
                                            treatAndFovHoldTableCount = 0;
                                            
                                            for (int counter2 = findPosition; counter2 < treatmentNameDisplayCount; counter2++){
                                                if (arrayTreatmentNameDisplayTemp [counter2] == treatNameHold && arrayFOVNameDisplayTemp [counter2] != "ND" && findTreatFlag == 0){
                                                    findTreatFlag = 1;
                                                    treatAndFovHoldTableCount++;
                                                }
                                                else if ((arrayTreatmentNameDisplayTemp [counter2] == treatNameHold || arrayTreatmentNameDisplayTemp [counter2] == "ND") && arrayFOVNameDisplayTemp [counter2] != "ND" && findTreatFlag == 1){
                                                    treatAndFovHoldTableCount++;
                                                }
                                                else{
                                                    
                                                    if (findTreatFlag == 1){
                                                        break;
                                                    }
                                                }
                                            }
                                            
                                            if (treatAndFovHoldTableCount == treatAndFovHoldCount){
                                                rowInfoData [rowInfoDataCount-1] = findPosition+treatAndFovHoldTableCount-1;
                                            }
                                            else{
                                                
                                                missMatchFind = 1;
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                            
                            //for (int counterA = 0; counterA < rowInfoDataCount/2; counterA++){
                            //    cout<<rowInfoData[counterA*2]<<" "<<rowInfoData [counterA*2+1]<<" Row"<<endl;
                            //}
                            
                            if (missMatchFind == 0){
                                for (int counter1 = 0; counter1 < totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100; counter1++) delete [] arrayFocalPlaneData [counter1];
                                delete [] arrayFocalPlaneData;
                                
                                int entryCount = 0;
                                fin.open(focalPath.c_str(),ios::in);
                                
                                if (fin.is_open()){
                                    do{
                                        
                                        getline(fin, getString);
                                        
                                        if (getString != "") entryCount++;
                                        
                                    } while (getString != "");
                                    
                                    fin.close();
                                }
                                
                                importTableEnd = 0;
                                
                                fin.open(currentTimePath.c_str(),ios::in);
                                
                                if (fin.is_open()){
                                    getline(fin, getString), importTableEnd = atoi(getString.c_str()); //-----Time point-----
                                    fin.close();
                                }
                                
                                int **arrayFocalPlaneDataTemp = new int *[totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100];
                                
                                arrayFocalPlaneData = new int *[totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100];
                                focalPlaneDataLimit = importTableEnd+100;
                                
                                for (int counter1 = 0; counter1 < totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100; counter1++){
                                    arrayFocalPlaneData [counter1] = new int [importTableEnd+100];
                                    arrayFocalPlaneDataTemp [counter1] = new int [importTableEnd+100];
                                }
                                
                                int lineCount = 0;
                                fin.open(focalPath.c_str(),ios::in);
                                
                                if (fin.is_open()){
                                    do{
                                        
                                        getline(fin, getString);
                                        
                                        if (getString != ""){
                                            arrayFocalPlaneDataTemp [lineCount][0] = 0;
                                            
                                            getline(fin, getString);
                                            arrayFocalPlaneDataTemp [lineCount][1] = 0;
                                            
                                            if (lineCount == 0){
                                                for (int counter1 = 1; counter1 <= importTableEnd; counter1++) getline(fin, getString), arrayFocalPlaneDataTemp [lineCount][counter1+1] = 0;
                                            }
                                            else{
                                                
                                                for (int counter1 = 1; counter1 < importTableEnd; counter1++) getline(fin, getString), arrayFocalPlaneDataTemp [lineCount][counter1+1] = atoi(getString.c_str());
                                                
                                                getline(fin, getString);
                                                arrayFocalPlaneDataTemp [lineCount][importTableEnd+1] = atoi(getString.c_str());
                                            }
                                            
                                            lineCount++;
                                        }
                                        
                                    } while (getString != "");
                                    
                                    fin.close();
                                    
                                    //for (int counterA = 0; counterA < treatmentNameDisplayCount; counterA++){
                                    //    for (int counterB = 0; counterB < importTableEnd+1; counterB++) cout<<" "<<arrayFocalPlaneDataTemp [counterA][counterB];
                                    //    cout<<"  arrayFocalPlaneData "<<counterA+1<<endl;
                                    //}
                                    
                                    int rowEntry = 0;
                                    
                                    for (int counter1 = 0; counter1 < rowInfoDataCount/2; counter1++){
                                        for (int counter2 = 0; counter2 <= importTableEnd+1; counter2++) arrayFocalPlaneData [rowEntry][counter2] = 0;
                                        rowEntry++;
                                        
                                        for (int counter2 = rowInfoData [counter1*2]; counter2 <= rowInfoData [counter1*2+1]; counter2++){
                                            for (int counter3 = 0; counter3 <= importTableEnd+1; counter3++) arrayFocalPlaneData [rowEntry][counter3] = arrayFocalPlaneDataTemp [counter2][counter3];
                                            
                                            rowEntry++;
                                        }
                                    }
                                }
                                
                                for (int counter1 = 0; counter1 < totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100; counter1++){
                                    delete [] arrayFocalPlaneDataTemp [counter1];
                                }
                                
                                delete [] arrayFocalPlaneDataTemp;
                                
                                string extension;
                                
                                int startingTimePoint = 1;
                                tableDisplayCount = 0;
                                currentTimePoint = 1;
                                
                                //----Line One set----
                                arrayTableDisplay [tableDisplayCount] = "Name", tableDisplayCount++;
                                arrayTableDisplay [tableDisplayCount] = "FOV", tableDisplayCount++;
                                
                                for (int counter1 = startingTimePoint; counter1 < startingTimePoint+15; counter1++){
                                    extension = to_string(counter1);
                                    
                                    if (importTableEnd == counter1 && importTableEnd != currentTimePoint) arrayTableDisplay [tableDisplayCount] = "E"+extension, tableDisplayCount++;
                                    else if (counter1 == 1) arrayTableDisplay [tableDisplayCount] = "C"+extension, currentTableHead = tableDisplayCount, tableDisplayCount++;
                                    else arrayTableDisplay [tableDisplayCount] = "T"+extension, tableDisplayCount++;
                                }
                                
                                if (arrayTreatmentNameDisplay [0] != "nil"){
                                    string extract1;
                                    string extract2;
                                    
                                    for (int counter1 = 1; counter1 < treatmentNameDisplayCount; counter1++){
                                        if (arrayTreatmentNameDisplay [counter1] != "ND") arrayTableDisplay [tableDisplayCount] = arrayTreatmentNameDisplay [counter1], tableDisplayCount++;
                                        else arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
                                        
                                        if (arrayFOVNameDisplay [counter1] != "ND") arrayTableDisplay [tableDisplayCount] = arrayFOVNameDisplay [counter1], tableDisplayCount++;
                                        else arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
                                        
                                        if (arrayFOVNameDisplay [counter1] != "ND"){
                                            for (int counter2 = startingTimePoint; counter2 < startingTimePoint+15; counter2++){
                                                if (counter2 > importTableEnd) arrayTableDisplay [tableDisplayCount] = "0", tableDisplayCount++;
                                                else if (counter2 == importTableEnd){
                                                    if (arrayFocalPlaneData [counter1][counter2+1] == -1000) arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
                                                    else if (arrayFocalPlaneData [counter1][counter2+1] == -2000) arrayTableDisplay [tableDisplayCount] = "*", tableDisplayCount++;
                                                    else if (arrayFocalPlaneData [counter1][counter2+1] == -2500) arrayTableDisplay [tableDisplayCount] = "*", tableDisplayCount++;
                                                    else if (arrayFocalPlaneData [counter1][counter2+1] == -3000) arrayTableDisplay [tableDisplayCount] = "f", tableDisplayCount++;
                                                    else if (arrayFocalPlaneData [counter1][counter2+1] == -3500) arrayTableDisplay [tableDisplayCount] = "F", tableDisplayCount++;
                                                    else if (arrayFocalPlaneData [counter1][counter2+1] < -6000 && arrayFocalPlaneData [counter1][counter2+1] > -7000){
                                                        extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                                                        extension = extension.substr(2);
                                                        extension = to_string(atoi(extension.c_str()));
                                                        
                                                        arrayTableDisplay [tableDisplayCount] = "p"+extension, tableDisplayCount++;
                                                    }
                                                    else if (arrayFocalPlaneData [counter1][counter2+1] < -7000 && arrayFocalPlaneData [counter1][counter2+1] > -8000){
                                                        extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                                                        extension = extension.substr(2);
                                                        extension = to_string(atoi(extension.c_str()));
                                                        
                                                        arrayTableDisplay [tableDisplayCount] = "P"+extension, tableDisplayCount++;
                                                    }
                                                    else if (arrayFocalPlaneData [counter1][counter2+1] == -4000) arrayTableDisplay [tableDisplayCount] = "a", tableDisplayCount++;
                                                    else if (arrayFocalPlaneData [counter1][counter2+1] == -4500) arrayTableDisplay [tableDisplayCount] = "A", tableDisplayCount++;
                                                    else if (arrayFocalPlaneData [counter1][counter2+1] < -8000 && arrayFocalPlaneData [counter1][counter2+1] > -9000){
                                                        extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                                                        extension = extension.substr(2);
                                                        extension = to_string(atoi(extension.c_str()));
                                                        
                                                        arrayTableDisplay [tableDisplayCount] = "s"+extension, tableDisplayCount++;
                                                    }
                                                    else if (arrayFocalPlaneData [counter1][counter2+1] < -9000 && arrayFocalPlaneData [counter1][counter2+1] > -10000){
                                                        extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                                                        extension = extension.substr(2);
                                                        extension = to_string(atoi(extension.c_str()));
                                                        
                                                        arrayTableDisplay [tableDisplayCount] = "S"+extension, tableDisplayCount++;
                                                    }
                                                    else if (arrayFocalPlaneData [counter1][counter2+1] == -5000) arrayTableDisplay [tableDisplayCount] = "T", tableDisplayCount++;
                                                    else if (arrayFocalPlaneData [counter1][counter2+1] < -10000000 && arrayFocalPlaneData [counter1][counter2+1] > -11000000){
                                                        extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                                                        extract1 = extension.substr(3, 3);
                                                        extract2 = extension.substr(6, 3);
                                                        extract1 = to_string(atoi(extract1.c_str()));
                                                        extract2 = to_string(atoi(extract2.c_str()));
                                                        
                                                        arrayTableDisplay [tableDisplayCount] = "r"+extract1+"-"+extract2, tableDisplayCount++;
                                                    }
                                                    else if (arrayFocalPlaneData [counter1][counter2+1] < -11000000 && arrayFocalPlaneData [counter1][counter2+1] > -12000000){
                                                        extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                                                        extract1 = extension.substr(3, 3);
                                                        extract2 = extension.substr(6, 3);
                                                        extract1 = to_string(atoi(extract1.c_str()));
                                                        extract2 = to_string(atoi(extract2.c_str()));
                                                        
                                                        arrayTableDisplay [tableDisplayCount] = "R"+extract1+"-"+extract2, tableDisplayCount++;
                                                    }
                                                    else arrayTableDisplay [tableDisplayCount] = "ND", tableDisplayCount++;
                                                }
                                                else{
                                                    
                                                    if (arrayFocalPlaneData [counter1][counter2+1] == -1000) arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
                                                    else if (arrayFocalPlaneData [counter1][counter2+1] == -2000) arrayTableDisplay [tableDisplayCount] = "*", tableDisplayCount++;
                                                    else if (arrayFocalPlaneData [counter1][counter2+1] == -2500) arrayTableDisplay [tableDisplayCount] = "*", tableDisplayCount++;
                                                    else if (arrayFocalPlaneData [counter1][counter2+1] == -3000) arrayTableDisplay [tableDisplayCount] = "f", tableDisplayCount++;
                                                    else if (arrayFocalPlaneData [counter1][counter2+1] == -3500) arrayTableDisplay [tableDisplayCount] = "F", tableDisplayCount++;
                                                    else if (arrayFocalPlaneData [counter1][counter2+1] < -6000 && arrayFocalPlaneData [counter1][counter2+1] > -7000){
                                                        extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                                                        extension = extension.substr(2);
                                                        extension = to_string(atoi(extension.c_str()));
                                                        
                                                        arrayTableDisplay [tableDisplayCount] = "p"+extension, tableDisplayCount++;
                                                    }
                                                    else if (arrayFocalPlaneData [counter1][counter2+1] < -7000 && arrayFocalPlaneData [counter1][counter2+1] > -8000){
                                                        extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                                                        extension = extension.substr(2);
                                                        extension = to_string(atoi(extension.c_str()));
                                                        
                                                        arrayTableDisplay [tableDisplayCount] = "P"+extension, tableDisplayCount++;
                                                    }
                                                    else if (arrayFocalPlaneData [counter1][counter2+1] > 0){
                                                        extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                                                        
                                                        arrayTableDisplay [tableDisplayCount] = extension, tableDisplayCount++;
                                                    }
                                                    else if (arrayFocalPlaneData [counter1][counter2+1] == -4000) arrayTableDisplay [tableDisplayCount] = "a", tableDisplayCount++;
                                                    else if (arrayFocalPlaneData [counter1][counter2+1] == -4500) arrayTableDisplay [tableDisplayCount] = "A", tableDisplayCount++;
                                                    else if (arrayFocalPlaneData [counter1][counter2+1] < -8000 && arrayFocalPlaneData [counter1][counter2+1] > -9000){
                                                        extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                                                        extension = extension.substr(2);
                                                        extension = to_string(atoi(extension.c_str()));
                                                        
                                                        arrayTableDisplay [tableDisplayCount] = "s"+extension, tableDisplayCount++;
                                                    }
                                                    else if (arrayFocalPlaneData [counter1][counter2+1] < -9000 && arrayFocalPlaneData [counter1][counter2+1] > -10000){
                                                        extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                                                        extension = extension.substr(2);
                                                        extension = to_string(atoi(extension.c_str()));
                                                        
                                                        arrayTableDisplay [tableDisplayCount] = "S"+extension, tableDisplayCount++;
                                                    }
                                                    else if (arrayFocalPlaneData [counter1][counter2+1] == -5000) arrayTableDisplay [tableDisplayCount] = "T", tableDisplayCount++;
                                                    else if (arrayFocalPlaneData [counter1][counter2+1] < -10000000 && arrayFocalPlaneData [counter1][counter2+1] > -11000000){
                                                        extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                                                        extract1 = extension.substr(3, 3);
                                                        extract2 = extension.substr(6, 3);
                                                        extract1 = to_string(atoi(extract1.c_str()));
                                                        extract2 = to_string(atoi(extract2.c_str()));
                                                        
                                                        arrayTableDisplay [tableDisplayCount] = "r"+extract1+"-"+extract2, tableDisplayCount++;
                                                    }
                                                    else if (arrayFocalPlaneData [counter1][counter2+1] < -11000000 && arrayFocalPlaneData [counter1][counter2+1] > -12000000){
                                                        extension = to_string(arrayFocalPlaneData [counter1][counter2+1]);
                                                        extract1 = extension.substr(3, 3);
                                                        extract2 = extension.substr(6, 3);
                                                        extract1 = to_string(atoi(extract1.c_str()));
                                                        extract2 = to_string(atoi(extract2.c_str()));
                                                        
                                                        arrayTableDisplay [tableDisplayCount] = "R"+extract1+"-"+extract2, tableDisplayCount++;
                                                    }
                                                }
                                            }
                                        }
                                        else{
                                            
                                            for (int counter2 = 0; counter2 < 15; counter2++) arrayTableDisplay [tableDisplayCount] = " ", tableDisplayCount++;
                                        }
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < 10; counterA++){
                                //    for (int counterB = 0; counterB < 100; counterB++) cout<<" "<<arrayFocalPlaneData [counterA][counterB];
                                //    cout<<"  arrayFocalPlaneData "<<counterA+1<<endl;
                                //}
                                
                                ofstream oin;
                                
                                if (processMode == 5 || processMode == 7) oin.open(productsFocalPlaneTempPath.c_str(), ios::out);
                                else oin.open(productsFocalPlanePath.c_str(), ios::out);
                                
                                for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                                    for (int counter2 = 0; counter2 < importTableEnd+2; counter2++) oin<<arrayFocalPlaneData [counter1][counter2]<<endl;
                                }
                                
                                oin.close();
                                
                                if (processMode == 5 || processMode == 7) oin.open(focalSettingTempPath.c_str(),ios::out);
                                else oin.open(focalSettingPath.c_str(),ios::out);
                                
                                oin<<currentTimePoint<<endl;
                                oin<<importTableEnd<<endl;
                                oin<<dicRangeSet<<endl;
                                oin<<firstImageExclude<<endl;
                                oin<<copySetStatus<<endl;
                                oin<<copyDirectoryInfo<<endl;
                                
                                oin.close();
                                
                                tableViewCall = 1;
                                
                                NSSound *sound = [NSSound soundNamed:@"Ping"];
                                [sound play];
                            }
                            else{
                                
                                NSSound *sound = [NSSound soundNamed:@"Hero"];
                                [sound play];
                                
                                NSAlert *alert = [[NSAlert alloc] init];
                                
                                [alert addButtonWithTitle:@"OK"];
                                [alert setMessageText:@"Table Data Mismatch"];
                                [alert setAlertStyle:NSAlertStyleWarning];
                                [alert runModal];
                            }
                            
                            delete [] rowInfoData;
                        }
                        else{
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Table Data Mismatch"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                        }
                        
                        delete [] arrayTreatmentNameDisplayTemp;
                        delete [] arrayFOVNameDisplayTemp;
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Products Folder Missing"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"File Processing In Progress"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Copying Not Allowed In IF Mode"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Cheking Mode"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)copyFolderSet:(id)sender{
    /*
     Generate image for stitching using already created images.
     Copy: Select Product folder that contains relevant images
     Create a Dummy: Create a Dummy folder that contains empty Backup folders.
     Clear: Clear Setting
     
     Procedure; Perform focal selection as usual. When the time point reaches to the one using copy function, Set Copy and create a Dummy (this need to do once). Then continue the stitched image creation.
     If time point that stops copy is past, delete unnecessary files using Redo From function. Then Clear the setting. If the process continue, processing will be done using Backup folders.
     */
    
    if (processMode == 8 || processMode == 2 || processMode == 4 || processMode == 6){
        lastColumnNoHold = 0;
        lastRowNoHold = 0;
        lastTypeHold = "X";
        
        int stringLength = (int)bodyName.length();
        string ifModeExtract = bodyName.substr((unsigned long)stringLength-2, 2);
        
        if (ifModeExtract != "IF"){
            if (focusProcessFlag == 0){
                NSOpenPanel* openDlg = [NSOpenPanel openPanel];
                [openDlg setCanChooseFiles:NO];
                [openDlg setCanChooseDirectories:YES];
                
                if ([openDlg runModal] == NSModalResponseOK){
                    NSArray *files = [openDlg URLs];
                    NSString *fileName = [[files objectAtIndex:0] absoluteString];
                    
                    string directoryPathExtract = [fileName UTF8String];
                    
                    int findString1 = (int)directoryPathExtract.find("/Users/");
                    if (findString1 == -1) findString1 = (int)directoryPathExtract.find("/Volumes/");
                    unsigned long directoryLength = directoryPathExtract.length();
                    
                    string directoryPath = directoryPathExtract.substr((unsigned long)findString1, directoryLength-(unsigned long)findString1-1);
                    string extractedID;
                    string extractedID2;
                    
                    int terminationFlag = 0;
                    
                    do{
                        
                        terminationFlag = 1;
                        
                        findString1 = (int)directoryPath.find("%20");
                        if (findString1 != -1){
                            extractedID2 = directoryPath.substr(0, (unsigned long)findString1);
                            directoryPath = directoryPath.substr((unsigned long)findString1+3);
                            directoryPath = extractedID2+" "+directoryPath;
                        }
                        else terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                    
                    extractedID = directoryPath;
                    
                    do{
                        
                        terminationFlag = 1;
                        findString1 = (int)extractedID.find("/");
                        
                        if (findString1 != -1){
                            extractedID = extractedID.substr((unsigned long)findString1+1);
                        }
                        else terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                    
                    int findString2 = (int)extractedID.find("_Products");
                    int findString3 = (int)extractedID.find("_Products_");
                    
                    if (extractedID != "" && findString2 != -1 && findString3 == -1){
                        string *arrayTreatmentNameDisplayTemp = new string [totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100];
                        int treatmentNameDisplayTempCount = 0;
                        
                        string *arrayFOVNameDisplayTemp = new string [totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100];
                        int fovNameDisplayTempCount = 0;
                        
                        string treatmentPath = directoryPath+"/"+"Analysis_Information"+"/"+"FI-TreatmentNameData";
                        string fovPath = directoryPath+"/"+"Analysis_Information"+"/"+"FI-FOVData";
                        string focalPath = directoryPath+"/"+"Analysis_Information"+"/"+"FI-FocalPlaneData";
                        string currentTimePath = directoryPath+"/"+"Analysis_Information"+"/"+"FI-BasicSetting";
                        string getString;
                        
                        ifstream fin;
                        fin.open(treatmentPath.c_str(),ios::in);
                        
                        if (fin.is_open()){
                            do{
                                
                                getline(fin, getString);
                                
                                if (getString != "" && treatmentNameDisplayTempCount < totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100) arrayTreatmentNameDisplayTemp [treatmentNameDisplayTempCount] = getString, treatmentNameDisplayTempCount++;
                                
                            } while (getString != "");
                            
                            fin.close();
                        }
                        
                        //for (int counterA = 0; counterA < treatmentNameDisplayTempCount; counterA++){
                        //    cout<<arrayTreatmentNameDisplayTemp [counterA]<<"  arrayTreatmentNameDisplayTemp "<<endl;
                        //}
                        
                        fin.open(fovPath.c_str(),ios::in);
                        
                        if (fin.is_open()){
                            do{
                                
                                getline(fin, getString);
                                
                                if (getString != "" && fovNameDisplayTempCount < totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount+100) arrayFOVNameDisplayTemp [fovNameDisplayTempCount] = getString, fovNameDisplayTempCount++;
                                
                            } while (getString != "");
                            
                            fin.close();
                        }
                        
                        //for (int counterA = 0; counterA < fovNameDisplayTempCount; counterA++){
                        //    cout<<arrayTreatmentNameDisplayTemp  [counterA] <<" "<<arrayFOVNameDisplayTemp [counterA]<<"  arrayFOVNameDisplayTemp "<<endl;
                        //}
                        
                        if (treatmentNameDisplayTempCount == treatmentNameDisplayCount && fovNameDisplayTempCount == fOVNameDisplayCount){
                            int *rowInfoData = new int [(totalFOVNoHoldInt+totalFOVNoHoldInt*fluorescentCount)*2+5];
                            int rowInfoDataCount = 0;
                            
                            string treatNameHold = "nil";
                            string stringExtract;
                            string currentFov;
                            
                            int missMatchFind = 0;
                            int treatAndFovHoldCount = 0;
                            int findTreatFlag = 0;
                            int findPosition = 0;
                            int treatAndFovHoldTableCount = 0;
                            
                            for (int counter1 = 0; counter1 < treatmentNameDisplayCount; counter1++){
                                if (arrayTreatmentNameDisplay [counter1] != "ND"){
                                    treatNameHold = arrayTreatmentNameDisplay [counter1];
                                    stringExtract = treatNameHold.substr(treatNameHold.length()-3);
                                    
                                    if ((int)stringExtract.find("CH") == -1){
                                        treatAndFovHoldCount = 0;
                                        findTreatFlag = 0;
                                        currentFov = arrayFOVNameDisplay [counter1];
                                        
                                        for (int counter2 = 0; counter2 < treatmentNameDisplayCount; counter2++){
                                            if (arrayTreatmentNameDisplay [counter2] == treatNameHold && arrayFOVNameDisplay [counter2] != "ND" && findTreatFlag == 0){
                                                findTreatFlag = 1;
                                                treatAndFovHoldCount++;
                                            }
                                            else if ((arrayTreatmentNameDisplay [counter2] == treatNameHold || arrayTreatmentNameDisplay [counter2] == "ND") && arrayFOVNameDisplay [counter2] != "ND" && findTreatFlag == 1){
                                                treatAndFovHoldCount++;
                                            }
                                            else{
                                                
                                                if (findTreatFlag == 1){
                                                    break;
                                                }
                                            }
                                        }
                                        
                                        findPosition = 0;
                                        
                                        for (int counter2 = 0; counter2 < treatmentNameDisplayCount; counter2++){
                                            if (treatNameHold == arrayTreatmentNameDisplayTemp [counter2] && currentFov == arrayFOVNameDisplayTemp [counter2]){
                                                findPosition = counter2;
                                                break;
                                            }
                                        }
                                        
                                        if (findPosition == 0){
                                            missMatchFind = 1;
                                            break;
                                        }
                                        else{
                                            
                                            findTreatFlag = 0;
                                            treatAndFovHoldTableCount = 0;
                                            
                                            for (int counter2 = findPosition; counter2 < treatmentNameDisplayCount; counter2++){
                                                if (arrayTreatmentNameDisplayTemp [counter2] == treatNameHold && arrayFOVNameDisplayTemp [counter2] != "ND" && findTreatFlag == 0){
                                                    findTreatFlag = 1;
                                                    treatAndFovHoldTableCount++;
                                                }
                                                else if ((arrayTreatmentNameDisplayTemp [counter2] == treatNameHold || arrayTreatmentNameDisplayTemp [counter2] == "ND") && arrayFOVNameDisplayTemp [counter2] != "ND" && findTreatFlag == 1){
                                                    treatAndFovHoldTableCount++;
                                                }
                                                else{
                                                    
                                                    if (findTreatFlag == 1){
                                                        break;
                                                    }
                                                }
                                            }
                                            
                                            if (treatAndFovHoldTableCount == treatAndFovHoldCount){
                                                rowInfoData [rowInfoDataCount] = findPosition, rowInfoDataCount++;
                                                rowInfoData [rowInfoDataCount] = findPosition+treatAndFovHoldTableCount-1, rowInfoDataCount++;
                                            }
                                            else{
                                                
                                                missMatchFind = 1;
                                                break;
                                            }
                                        }
                                    }
                                    else{
                                        
                                        findTreatFlag = 0;
                                        treatAndFovHoldCount = 0;
                                        currentFov = arrayFOVNameDisplay [counter1];
                                        
                                        for (int counter2 = 0; counter2 < treatmentNameDisplayCount; counter2++){
                                            if (arrayTreatmentNameDisplay [counter2] == treatNameHold && arrayFOVNameDisplay [counter2] != "ND" && findTreatFlag == 0){
                                                findTreatFlag = 1;
                                                treatAndFovHoldCount++;
                                            }
                                            else  if ((arrayTreatmentNameDisplay [counter2] == treatNameHold || arrayTreatmentNameDisplay [counter2] == "ND") && arrayFOVNameDisplay [counter2] != "ND" && findTreatFlag == 1){
                                                treatAndFovHoldCount++;
                                            }
                                            else{
                                                
                                                if (findTreatFlag == 1){
                                                    break;
                                                }
                                            }
                                        }
                                        
                                        findPosition = 0;
                                        
                                        for (int counter2 = 0; counter2 < treatmentNameDisplayCount; counter2++){
                                            if (treatNameHold == arrayTreatmentNameDisplayTemp [counter2] && currentFov == arrayFOVNameDisplayTemp [counter2]){
                                                findPosition = counter2;
                                                break;
                                            }
                                        }
                                        
                                        if (findPosition == 0){
                                            missMatchFind = 1;
                                            break;
                                        }
                                        else{
                                            
                                            findTreatFlag = 0;
                                            treatAndFovHoldTableCount = 0;
                                            
                                            for (int counter2 = findPosition; counter2 < treatmentNameDisplayCount; counter2++){
                                                if (arrayTreatmentNameDisplayTemp [counter2] == treatNameHold && arrayFOVNameDisplayTemp [counter2] != "ND" && findTreatFlag == 0){
                                                    findTreatFlag = 1;
                                                    treatAndFovHoldTableCount++;
                                                }
                                                else if ((arrayTreatmentNameDisplayTemp [counter2] == treatNameHold || arrayTreatmentNameDisplayTemp [counter2] == "ND") && arrayFOVNameDisplayTemp [counter2] != "ND" && findTreatFlag == 1){
                                                    treatAndFovHoldTableCount++;
                                                }
                                                else{
                                                    
                                                    if (findTreatFlag == 1){
                                                        break;
                                                    }
                                                }
                                            }
                                            
                                            if (treatAndFovHoldTableCount == treatAndFovHoldCount){
                                                rowInfoData [rowInfoDataCount-1] = findPosition+treatAndFovHoldTableCount-1;
                                            }
                                            else{
                                                
                                                missMatchFind = 1;
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                            
                            //for (int counterA = 0; counterA < rowInfoDataCount/2; counterA++){
                            //    cout<<rowInfoData[counterA*2]<<" "<<rowInfoData [counterA*2+1]<<" Row"<<endl;
                            //}
                            
                            if (missMatchFind == 0){
                                copySetStatus = 1;
                                copyDirectoryInfo = directoryPath;
                                
                                [copyFolderInfoDisplay setStringValue:@(extractedID.c_str())];
                                
                                [self saveParameter];
                                
                                NSSound *sound = [NSSound soundNamed:@"Ping"];
                                [sound play];
                            }
                            else{
                                
                                NSSound *sound = [NSSound soundNamed:@"Hero"];
                                [sound play];
                                
                                NSAlert *alert = [[NSAlert alloc] init];
                                
                                [alert addButtonWithTitle:@"OK"];
                                [alert setMessageText:@"Table Data Mismatch"];
                                [alert setAlertStyle:NSAlertStyleWarning];
                                [alert runModal];
                            }
                            
                            delete [] rowInfoData;
                        }
                        else{
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Table Data Mismatch"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                        }
                        
                        delete [] arrayTreatmentNameDisplayTemp;
                        delete [] arrayFOVNameDisplayTemp;
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Products Folder Missing"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"File Processing In Progress"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Copying Not Allowed In IF Mode"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Cheking Mode"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)copyFolderDummy:(id)sender{
    if (processMode == 8 || processMode == 2 || processMode == 4 || processMode == 6){
        lastColumnNoHold = 0;
        lastRowNoHold = 0;
        lastTypeHold = "X";
        
        int stringLength = (int)bodyName.length();
        string ifModeExtract = bodyName.substr((unsigned long)stringLength-2, 2);
        
        if (ifModeExtract != "IF" && copySetStatus == 1){
            if (focusProcessFlag == 0){
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert addButtonWithTitle:@"Cancel"];
                [alert setMessageText:@"Creating Dummy Folder On The Desktop"];
                [alert setInformativeText:@"Add dummy to Batch List using Controller"];
                [alert setAlertStyle:NSAlertStyleWarning];
                
                if ([alert runModal] == NSAlertFirstButtonReturn){
                    DIR *dir;
                    struct dirent *dent;
                    DIR *dir2;
                    struct dirent *dent2;
                    DIR *dir3;
                    struct dirent *dent3;
                    
                    string entry;
                    string entry2;
                    string entry3;
                    string productDataPath1 = copyDirectoryInfo+"/Source_Images";
                    string productDataPath2;
                    string productDataPath3;
                    
                    int maxImageNumber = 0;
                    
                    dir = opendir(productDataPath1.c_str());
                    
                    if (dir != NULL){
                        while((dent = readdir(dir))){
                            entry = dent -> d_name;
                            productDataPath2 = productDataPath1+"/"+entry;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("~Sorted") != -1){
                                dir2 = opendir(productDataPath2.c_str());
                                
                                if (dir2 != NULL){
                                    while((dent2 = readdir(dir2))){
                                        entry2 = dent2 -> d_name;
                                        productDataPath3 = productDataPath2+"/"+entry2;
                                        
                                        if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store" && (int)entry2.find("FOV") != -1){
                                            dir3 = opendir(productDataPath3.c_str());
                                            
                                            if (dir3 != NULL){
                                                while((dent3 = readdir(dir3))){
                                                    entry3 = dent3 -> d_name;
                                                    
                                                    if (entry3 != "." && entry3 != ".." && entry3 != ".DS_Store" && ((int)entry3.find(".bmp") || (int)entry3.find(".tif"))){
                                                        if (atoi(entry3.substr(entry3.find("_")+1, 4).c_str()) > maxImageNumber) maxImageNumber = atoi(entry3.substr(entry3.find("_")+1, 4).c_str());
                                                    }
                                                }
                                                
                                                closedir(dir3);
                                            }
                                        }
                                    }
                                    
                                    closedir(dir2);
                                }
                            }
                        }
                        
                        closedir(dir);
                    }
                    
                    if (maxImageNumber != 0){
                        int findExistingFolders = 0;
                        
                        string dummyPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA-BackupDummy";
                        
                        mkdir(dummyPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                        
                        dir = opendir(dummyPath.c_str());
                        
                        if (dir != NULL){
                            while((dent = readdir(dir))){
                                entry = dent -> d_name;
                                
                                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                    findExistingFolders = 1;
                                    break;
                                }
                            }
                        }
                        
                        if (findExistingFolders == 1){
                            dir = opendir(dummyPath.c_str());
                            fileDeleteCount = 0;
                            
                            if (dir != NULL){
                                while((dent = readdir(dir))){
                                    entry = dent -> d_name;
                                    productDataPath1 = dummyPath+"/"+entry;
                                    
                                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                        dir2 = opendir(productDataPath1.c_str());
                                        
                                        if (dir2 != NULL){
                                            while((dent2 = readdir(dir2))){
                                                entry2 = dent2 -> d_name;
                                                
                                                if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                                arrayFileDelete [fileDeleteCount] = productDataPath1+"/"+entry2, fileDeleteCount++;
                                            }
                                        }
                                        
                                        closedir(dir2);
                                    }
                                }
                                
                                closedir(dir);
                                
                                for(int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                                    remove (arrayFileDelete [counter1].c_str());
                                }
                            }
                            
                            dir = opendir(dummyPath.c_str());
                            fileDeleteCount = 0;
                            
                            if (dir != NULL){
                                while((dent = readdir(dir))){
                                    entry = dent -> d_name;
                                    productDataPath1 = dummyPath+"/"+entry;
                                    
                                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                        if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                        arrayFileDelete [fileDeleteCount] = productDataPath1, fileDeleteCount++;
                                    }
                                }
                                
                                closedir(dir);
                                
                                for(int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                                    remove (arrayFileDelete [counter1].c_str());
                                }
                            }
                        }
                        
                        string batchProcessBackUpPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/BatchBackUpNameList";
                        string getString;
                        
                        ifstream fin;
                        
                        fin.open(batchProcessBackUpPath.c_str(),ios::in);
                        
                        if (fin.is_open()){
                            getline(fin, getString);
                            string batchBodyName = getString;
                            fin.close();
                            
                            string dummyPathFolder;
                            string numberString;
                            
                            for (int counter1 = 1; counter1 <= maxImageNumber; counter1++){
                                numberString = to_string(counter1);
                                
                                if (numberString.length() == 1) numberString = "1000"+numberString;
                                else if (numberString.length() == 2) numberString = "100"+numberString;
                                else if (numberString.length() == 3) numberString = "10"+numberString;
                                else if (numberString.length() == 4) numberString = "1"+numberString;
                                
                                dummyPathFolder = dummyPath+"/"+batchBodyName+"-"+numberString;
                                
                                mkdir(dummyPathFolder.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                
                                NSSound *sound = [NSSound soundNamed:@"Ping"];
                                [sound play];
                            }
                        }
                        else{
                            
                            NSAlert *alert2 = [[NSAlert alloc] init];
                            [alert2 addButtonWithTitle:@"OK"];
                            [alert2 setMessageText:@"No Batch body name has been found"];
                            [alert2 setAlertStyle:NSAlertStyleWarning];
                            [alert2 runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else{
                        
                        NSAlert *alert2 = [[NSAlert alloc] init];
                        [alert2 addButtonWithTitle:@"OK"];
                        [alert2 setMessageText:@"No image file has been found"];
                        [alert2 setAlertStyle:NSAlertStyleWarning];
                        [alert2 runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"File Processing In Progress"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Copying Not Allowed In IF Mode"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Cheking Mode"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)copyFolderClear:(id)sender{
    if (processMode == 8 || processMode == 2 || processMode == 4 || processMode == 6){
        lastColumnNoHold = 0;
        lastRowNoHold = 0;
        lastTypeHold = "X";
        
        int stringLength = (int)bodyName.length();
        string ifModeExtract = bodyName.substr((unsigned long)stringLength-2, 2);
        
        if (ifModeExtract != "IF"){
            if (focusProcessFlag == 0){
                copySetStatus = 0;
                copyDirectoryInfo = "nil";
                
                [copyFolderInfoDisplay setStringValue:@"nil"];
                
                [self saveParameter];
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"File Processing In Progress"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Copying Not Allowed In IF Mode"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Cheking Mode"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sliderAction:(id)sender{
    if (imageReadFile != ""){
        fluorescentEnhance = [sliderFluorescent doubleValue];
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay object:self];
    }
}

-(void)fileDeleteUpDate{
    string *arrayUpDate = new string [fileDeleteCount+10];
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayUpDate [counter1] = arrayFileDelete [counter1];
    
    delete [] arrayFileDelete;
    arrayFileDelete = new string [fileDeleteLimit+500];
    fileDeleteLimit = fileDeleteLimit+500;
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayFileDelete [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(IBAction)dicRangeNone:(id)sender{
    lastColumnNoHold = 0;
    lastRowNoHold = 0;
    lastTypeHold = "X";
    dicRangeSet = 0;
    
    [self saveParameter];
    
    [dicRangeDisplay setStringValue:@"None"];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)dicRange20:(id)sender{
    lastColumnNoHold = 0;
    lastRowNoHold = 0;
    lastTypeHold = "X";
    dicRangeSet = 1;
    
    [self saveParameter];
    
    [dicRangeDisplay setStringValue:@"20"];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)dicRange40:(id)sender{
    lastColumnNoHold = 0;
    lastRowNoHold = 0;
    lastTypeHold = "X";
    dicRangeSet = 2;
    
    [self saveParameter];
    
    [dicRangeDisplay setStringValue:@"40"];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)dicRange60:(id)sender{
    lastColumnNoHold = 0;
    lastRowNoHold = 0;
    lastTypeHold = "X";
    dicRangeSet = 3;
    
    [self saveParameter];
    
    [dicRangeDisplay setStringValue:@"60"];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)dicRange80:(id)sender{
    lastColumnNoHold = 0;
    lastRowNoHold = 0;
    lastTypeHold = "X";
    dicRangeSet = 4;
    
    [self saveParameter];
    
    [dicRangeDisplay setStringValue:@"80"];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)firstInclude:(id)sender{
    lastColumnNoHold = 0;
    lastRowNoHold = 0;
    lastTypeHold = "X";
    firstImageExclude = 0;
    
    [self saveParameter];
    
    [includeExcludeDisplay setStringValue:@"Include"];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)firstIncExclude:(id)sender{
    lastColumnNoHold = 0;
    lastRowNoHold = 0;
    lastTypeHold = "X";
    firstImageExclude = 1;
    
    [self saveParameter];
    
    [includeExcludeDisplay setStringValue:@"Exclude"];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)backUpCheckSet:(id)sender{
    if (backUpOperation == 0){
        backUpOperation = 1;
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackUpCheckControl object:self];
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToBackUpCheckImage object:self];
    }
    if (backUpOperation == 2) backUpOperation = 3;
}

-(void)saveParameter{
    ofstream oin;
    oin.open(focalSettingPath.c_str(), ios::out);
    
    oin<<currentTimePoint<<endl;
    oin<<importTableEnd<<endl;
    oin<<dicRangeSet<<endl;
    oin<<firstImageExclude<<endl;
    oin<<copySetStatus<<endl;
    oin<<copyDirectoryInfo<<endl;
    
    oin.close();
}

-(void)dealloc{
    if (controllerTimer) [controllerTimer invalidate];
}

@end
