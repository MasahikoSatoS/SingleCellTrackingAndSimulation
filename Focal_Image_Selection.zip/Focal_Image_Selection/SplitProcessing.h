/*
 *  SplitProcessing.h
 *  Focal_Image_Selection
 *
 *  Created by Masahiko Sato on 30/12/09, 26/06/13 revised.
 *  Copyright Masahiko Sato 2009 All rights reserved.
 *
 */

#ifndef SPLITPROCESSING_H
#define SPLITPROCESSING_H
#import "Controller.h"
#import "ASCIIconversion.h"
#endif

@interface SplitProcessing : NSObject {
    id singleTiffSave;
    id tiffFileRead;
}

-(id)init;
-(void)dealloc;
-(void)focalPlaneDataUpData;
-(void)fileDeleteUpDate;

@end
