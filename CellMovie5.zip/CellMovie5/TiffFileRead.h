//
//  TiffFileRead.h
//  CellMovie5
//
//  Created by Masahiko Sato on 2021-07-01.
//  Copyright Masahiko Sato 2021 All rights reserved.
//

#ifndef SINGLETIFFSAVE_H
#define SINGLETIFFSAVE_H
#import "Controller.h"
#endif

@interface TiffFileRead : NSObject{
}

-(void)tiffReadLittleEndian:(unsigned long)headPosition :(int*)imageWidth :(int*)imageHeight :(int*)imageBit :(int*)imageCompression :(int*)photoMetric : (double*)xPosition :(double*)yPosition :(int*)samplePerPix :(unsigned long*)stripFirstAddress :(unsigned long*)stripEntry :(unsigned long*)stripByteCountAddress :(unsigned long*)nextAddress :(int*)numberOfLayers;

-(void)tiffReadBigEndian:(unsigned long)headPosition :(int*)imageWidth :(int*)imageHeight :(int*)imageBit :(int*)imageCompression :(int*)photoMetric : (double*)xPosition :(double*)yPosition :(int*)samplePerPix :(unsigned long*)stripFirstAddress :(unsigned long*)stripEntry :(unsigned long*)stripByteCountAddress :(unsigned long*)nextAddress :(int*)numberOfLayers;

-(int*)imageSetLittleEndian:(int)imageDimension :(int)imageBit :(int)photoMetric :(int)samplePerPix :(unsigned long)stripEntry :(unsigned long)stripFirstAddress :(unsigned long) stripByteCountAddress :(int)processType;

-(int*)imageSetBigEndian:(int)imageDimension :(int)imageBit :(int)photoMetric :(int)samplePerPix :(unsigned long)stripEntry :(unsigned long)stripFirstAddress :(unsigned long) stripByteCountAddress :(int)processType;

@end
