//
//  ImageFileProcessing.h
//  Watson
//
//  Created by Masahiko Sato on 2019-09-25.
//  Copyright 2019 Masahiko Sato. All rights reserved.
//

#ifndef IMAGEFILEPROCESSING_H
#define IMAGEFILEPROCESSING_H
#import "Controller.h"
#endif

@interface ImageFileProcessing : NSObject{
    IBOutlet NSTextField *inputDataDisplay;
    IBOutlet NSTextField *totalRGBDisplay;
    IBOutlet NSProgressIndicator *backSave;
    
    id ascIIconversion;
    id singleTiffSave;
}

-(IBAction)cleanUPList:(id)sender;
-(IBAction)fileLoadStart:(id)sender;
-(IBAction)startProcess:(id)sender;
-(IBAction)autoContrastSet:(id)sender;
-(IBAction)autoContrastClear:(id)sender;
-(IBAction)autoTotalRGB:(id)sender;
-(IBAction)fileRemove:(id)sender;
-(IBAction)imageFolderCreateForSeg:(id)sender;

@end
