//
//  MovieDisplay.m
//  Watson
//
//  Created by Masahiko Sato on 2014-09-29.
//
//

#import "MovieDisplay.h"

NSString *notificationToMovieDisplay = @"notificationExecuteMovieDisplay";

@implementation MovieDisplay

-(id)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    
    if (self) {
        magnificationDisplay = 10;
        imageFirstLoadFlagDisplay = 0;
        clickList = 0;
        
        mouseDragFlag = 0;
        mouseDownFlag = 0;
        processingFovNo = 0;
        currentFOVNoHold = 0;
        colorAdjustFreeLock = 0;
        resolutionStatusHold = 0;
        
        movieImage = [[NSImage alloc] initWithContentsOfFile:@""];
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToMovieDisplay object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    if (imageLoadStatus != 0){
        int imageSetSize = 0;
        int counterIncrement = 0;
        
        if (stitchedImageDimension <= 1000){
            imageSetSize = stitchedImageDimension;
            counterIncrement = 1;
        }
        else if (stitchedImageDimension <= 4000){
            imageSetSize = stitchedImageDimension/2;
            counterIncrement = 2;
        }
        else{
            
            imageSetSize = stitchedImageDimension/4;
            counterIncrement = 4;
        }
        
        if (resolutionStatusHold == 1){
            imageSetSize = stitchedImageDimension;
            counterIncrement = 1;
        }
        
        if (photoMetricsHold == 1){
            NSBitmapImageRep *bitmapReps;
            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageSetSize  pixelsHigh:imageSetSize  bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageSetSize bitsPerPixel:8];
            unsigned char *bitmapData = [bitmapReps bitmapData];
            
            for (int counter1 = 0; counter1 < stitchedImageDimension; counter1 = counter1+counterIncrement){
                for (int counter2 = 0; counter2 < stitchedImageDimension; counter2 = counter2+counterIncrement){
                    *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2];
                }
            }
            
            movieImage = [[NSImage alloc] initWithSize:NSMakeSize(stitchedImageDimension, stitchedImageDimension)];
            [movieImage addRepresentation:bitmapReps];
        }
        else if (photoMetricsHold == 2){
            NSBitmapImageRep *bitmapReps;
            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageSetSize pixelsHigh:imageSetSize bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageSetSize*4 bitsPerPixel:32];
            
            unsigned char *bitmapData = [bitmapReps bitmapData];
            
            for (int counter1 = 0; counter1 < stitchedImageDimension; counter1 = counter1+counterIncrement){
                for (int counter2 = 0; counter2 < stitchedImageDimension*3; counter2 = counter2+counterIncrement*3){
                    *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2];
                    *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2+1];
                    *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2+2];
                    *bitmapData++ = 0;
                }
            }
            
            movieImage = [[NSImage alloc] initWithSize:NSMakeSize(stitchedImageDimension, stitchedImageDimension)];
            [movieImage addRepresentation:bitmapReps];
        }
        
        //For (int counterA = 0; counterA < stitchedImageDimension; counterA++){
        //    for (int counterB = 0; counterB < stitchedImageDimension; counterB++) cout<<" "<<imagePositionMap [counterA][counterB];
        //    cout<<"  imagePositionMap "<<counterA+1<<endl;
        //}
        
        if (imageFirstLoadFlagDisplay == 0){
            xPositionDisplay = 0;
            yPositionDisplay = 0;
            xPositionAdjustDisplay = 0;
            yPositionAdjustDisplay = 0;
            magnificationDisplay = 10;
            imageFirstLoadFlagDisplay = 1;
        }
        
        //-----Window size and Position re-adjust-----
        int vertical = 600+78;
        int horizontal = 600;
        
        windowWidthDisplay = stitchedImageDimension/(double)horizontal;
        windowHeightDisplay = stitchedImageDimension/(double)(vertical-78);
        
        xPositionAdjustDisplay = (stitchedImageDimension-stitchedImageDimension/(double)(magnificationDisplay*0.1))/(double)2;
        yPositionAdjustDisplay = (stitchedImageDimension-stitchedImageDimension/(double)(magnificationDisplay*0.1))/(double)2;
        
        [self setNeedsDisplay:YES];
    }
}

//-----First Responder-----
-(BOOL)acceptsFirstResponder{
    return YES;
}

-(void)mouseDown:(NSEvent *)event{
    if (imageLoadStatus != 0){
        NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
        xPointDownDisplay = clickPoint.x;
        yPointDownDisplay = clickPoint.y;
        
        double xPositionAdj = xPositionAdjustDisplay+xPositionDisplay;
        double yPositionAdj = yPositionAdjustDisplay+yPositionDisplay;
        double xCalValue = 1/(double)windowWidthDisplay*magnificationDisplay*0.1;
        double yCalValue = 1/(double)windowHeightDisplay*magnificationDisplay*0.1;
        
        int xCrickPosition = (int)(clickPoint.x/(double)xCalValue+xPositionAdj);
        int yCrickPosition = (int)((clickPoint.y/(double)yCalValue+yPositionAdj-stitchedImageDimension)*-1);
        
        if (listModeStatusHold == 1){
            clickList = -1;
            
            for (int counter1 = 0; counter1 < listDataCount; counter1++){
                if (xPointDownDisplay > 5 && xPointDownDisplay < 130 && yPointDownDisplay > 550-counter1*20 && yPointDownDisplay < 550-counter1*20+10){
                    clickList = counter1;
                    break;
                }
            }
            
            if (photoMetricsHold == 2 && clickList != -1){
                int tempValue1 = 0;
                int tempValue2 = 0;
                int tempValue3 = 0;
                
                if (imageFLStatus == "Lock" || (processingFovNo == 0 && imageFLStatus == "Free") || imageDisplayCall == 5){
                    for (int counter2 = 0; counter2 < fileListCount; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionH; counter3++){
                            for (int counter4 = 0; counter4 < imageDimensionW*3; counter4 = counter4+3){
                                if ((int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4]*(double)listDataHold[clickList*15]) > 255) tempValue1 = 255;
                                else tempValue1 = (int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4]*(double)listDataHold[clickList*15]);
                                
                                if ((int)(tempValue1+listDataHold[clickList*15+1]) > 255) tempValue1 = 255;
                                else tempValue1 = (int)(tempValue1+listDataHold[clickList*15+1]);
                                
                                if (tempValue1 > listDataHold[clickList*15+3]){
                                    if ((int)(tempValue1+listDataHold[clickList*15+2]) > 255) tempValue1 = 255;
                                    else tempValue1 = (int)(tempValue1+listDataHold[clickList*15+2]);
                                }
                                
                                if ((int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4+1]*(double)listDataHold[clickList*15]) > 255) tempValue2 = 255;
                                else tempValue2 = (int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4+1]*(double)listDataHold[clickList*15]);
                                
                                if ((int)(tempValue2+listDataHold[clickList*15+1]) > 255) tempValue2 = 255;
                                else tempValue2 = (int)(tempValue2+listDataHold[clickList*15+1]);
                                
                                if (tempValue2 > listDataHold[clickList*15+5]){
                                    if ((int)(tempValue2+listDataHold[clickList*15+4]) > 255) tempValue2 = 255;
                                    else tempValue2 = (int)(tempValue2+listDataHold[clickList*15+4]);
                                }
                                
                                if ((int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4+2]*(double)listDataHold[clickList*15]) > 255) tempValue3 = 255;
                                else tempValue3 = (int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4+2]*(double)listDataHold[clickList*15]);
                                
                                if ((int)(tempValue3+listDataHold[clickList*15+1]) > 255) tempValue3 = 255;
                                else tempValue3 = (int)(tempValue3+listDataHold[clickList*15+1]);
                                
                                if (tempValue3 > listDataHold[clickList*15+7]){
                                    if ((int)(tempValue3+listDataHold[clickList*15+6]) > 255) tempValue3 = 255;
                                    else tempValue3 = (int)(tempValue3+listDataHold[clickList*15+6]);
                                }
                                
                                if (colorSelectStatusHold == 1 && clickList != 0){
                                    if (tempValue1 <= listDataHold[clickList*15+8]-listDataHold[clickList*15+9] || tempValue1 > listDataHold[clickList*15+8]+listDataHold[clickList*15+9] || tempValue2 <= listDataHold[clickList*15+10]-listDataHold[clickList*15+11] || tempValue2 > listDataHold[clickList*15+10]+listDataHold[clickList*15+11] || tempValue3 <= listDataHold[clickList*15+12]-listDataHold[clickList*15+13] || tempValue3 > listDataHold[clickList*15+12]+listDataHold[clickList*15+13]){
                                        tempValue1 = 0;
                                        tempValue2 = 0;
                                        tempValue3 = 0;
                                    }
                                }
                                
                                arrayImageResults [counter2*imageDimensionH+counter3][counter4] = tempValue1;
                                arrayImageResults [counter2*imageDimensionH+counter3][counter4+1] = tempValue2;
                                arrayImageResults [counter2*imageDimensionH+counter3][counter4+2] = tempValue3;
                                
                                imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4] = tempValue1;
                                imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4+1] = tempValue2;
                                imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4+2] = tempValue3;
                            }
                        }
                    }
                }
                else{
                    
                    int newXPosition = xyPositionWritingData [(processingFovNo-1)*3+2];
                    int newYPosition = xyPositionWritingData [(processingFovNo-1)*3+1];
                    
                    int yImageCount = 0;
                    int xImageCount = 0;
                    
                    for (int counter1 = newYPosition; counter1 < newYPosition+imageDimensionH; counter1++){
                        for (int counter2 = newXPosition*3; counter2 < newXPosition*3+imageDimensionW*3; counter2 = counter2+3){
                            if ((int)(arrayImageDataHold [((int)listDataHold[clickList*15+14]-1)*imageDimensionH+yImageCount][xImageCount]*(double)listDataHold[clickList*15]) > 255) tempValue1 = 255;
                            else tempValue1 = (int)(arrayImageDataHold [((int)listDataHold[clickList*15+14]-1)*imageDimensionH+yImageCount][xImageCount]*(double)listDataHold[clickList*15]);
                            
                            if ((int)(tempValue1+listDataHold[clickList*15+1]) > 255) tempValue1 = 255;
                            else tempValue1 = (int)(tempValue1+listDataHold[clickList*15+1]);
                            
                            if (tempValue1 > listDataHold[clickList*15+3]){
                                if ((int)(tempValue1+listDataHold[clickList*15+2]) > 255) tempValue1 = 255;
                                else tempValue1 = (int)(tempValue1+listDataHold[clickList*15+2]);
                            }
                            
                            if ((int)(arrayImageDataHold [((int)listDataHold[clickList*15+14]-1)*imageDimensionH+yImageCount][xImageCount+1]*(double)listDataHold[clickList*15]) > 255) tempValue2 = 255;
                            else tempValue2 = (int)(arrayImageDataHold [((int)listDataHold[clickList*15+14]-1)*imageDimensionH+yImageCount][xImageCount+1]*(double)listDataHold[clickList*15]);
                            
                            if ((int)(tempValue2+listDataHold[clickList*15+1]) > 255) tempValue2 = 255;
                            else tempValue2 = (int)(tempValue2+listDataHold[clickList*15+1]);
                            
                            if (tempValue2 > listDataHold[clickList*15+5]){
                                if ((int)(tempValue2+listDataHold[clickList*15+4]) > 255) tempValue2 = 255;
                                else tempValue2 = (int)(tempValue2+listDataHold[clickList*15+4]);
                            }
                            
                            if ((int)(arrayImageDataHold [((int)listDataHold[clickList*15+14]-1)*imageDimensionH+yImageCount][xImageCount+2]*(double)listDataHold[clickList*15]) > 255) tempValue3 = 255;
                            else tempValue3 = (int)(arrayImageDataHold [((int)listDataHold[clickList*15+14]-1)*imageDimensionH+yImageCount][xImageCount+2]*(double)listDataHold[clickList*15]);
                            
                            if ((int)(tempValue3+listDataHold[clickList*15+1]) > 255) tempValue3 = 255;
                            else tempValue3 = (int)(tempValue3+listDataHold[clickList*15+1]);
                            
                            if (tempValue3 > listDataHold[clickList*15+7]){
                                if ((int)(tempValue3+listDataHold[clickList*15+6]) > 255) tempValue3 = 255;
                                else tempValue3 = (int)(tempValue3+listDataHold[clickList*15+6]);
                            }
                            
                            if (colorSelectStatusHold == 1 && clickList != 0){
                                if (tempValue1 <= listDataHold[clickList*15+8]-listDataHold[clickList*15+9] || tempValue1 > listDataHold[clickList*15+8]+listDataHold[clickList*15+9] || tempValue2 <= listDataHold[clickList*15+10]-listDataHold[clickList*15+11] || tempValue2 > listDataHold[clickList*15+10]+listDataHold[clickList*15+11] || tempValue3 <= listDataHold[clickList*15+12]-listDataHold[clickList*15+13] || tempValue3 > listDataHold[clickList*15+12]+listDataHold[clickList*15+13]){
                                    tempValue1 = 0;
                                    tempValue2 = 0;
                                    tempValue3 = 0;
                                }
                            }
                            
                            arrayImageResults [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount] = tempValue1;
                            arrayImageResults [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+1] = tempValue2;
                            arrayImageResults [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+2] = tempValue3;
                            
                            imageDisplayArray [counter1][counter2] = tempValue1;
                            imageDisplayArray [counter1][counter2+1] = tempValue2;
                            imageDisplayArray [counter1][counter2+2] = tempValue3;
                            
                            xImageCount = xImageCount+3;
                        }
                        
                        yImageCount++;
                        xImageCount = 0;
                    }
                }
                
                int imageSetSize = 0;
                int counterIncrement = 0;
                
                if (stitchedImageDimension <= 1000){
                    imageSetSize = stitchedImageDimension;
                    counterIncrement = 1;
                }
                else if (stitchedImageDimension <= 4000){
                    imageSetSize = stitchedImageDimension/2;
                    counterIncrement = 2;
                }
                else{
                    
                    imageSetSize = stitchedImageDimension/4;
                    counterIncrement = 4;
                }
                
                if (resolutionStatusHold == 1){
                    imageSetSize = stitchedImageDimension;
                    counterIncrement = 1;
                }
                
                NSBitmapImageRep *bitmapReps;
                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageSetSize pixelsHigh:imageSetSize bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageSetSize*4 bitsPerPixel:32];
                
                unsigned char *bitmapData = [bitmapReps bitmapData];
                
                for (int counter1 = 0; counter1 < stitchedImageDimension; counter1 = counter1+counterIncrement){
                    for (int counter2 = 0; counter2 < stitchedImageDimension*3; counter2 = counter2+counterIncrement*3){
                        *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2];
                        *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2+1];
                        *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2+2];
                        *bitmapData++ = 0;
                    }
                }
                
                movieImage = [[NSImage alloc] initWithSize:NSMakeSize(stitchedImageDimension, stitchedImageDimension)];
                [movieImage addRepresentation:bitmapReps];
                
                if (clickList == 0){
                    colorSelectStatusHold = 0;
                    imageDisplayCall = 3;
                }
                
                [self setNeedsDisplay:YES];
            }
        }
        
        if ((listModeStatusHold == 0 && xCrickPosition > 0 && yCrickPosition > 0) || (listModeStatusHold == 1 && clickList == -1 && xCrickPosition > 0 && yCrickPosition > 0)){
            if (imageFLStatus == "Free"){
                if (photoMetricsHold == 1){
                    if (imagePositionMap [yCrickPosition][xCrickPosition] != 0){
                        processingFovNo = imagePositionMap [yCrickPosition][xCrickPosition];
                        mouseDownFlag = 1;
                    }
                    else processingFovNo = 0;
                }
                else if (photoMetricsHold == 2){
                    if (imagePositionMap [yCrickPosition][xCrickPosition*3] != 0){
                        processingFovNo = imagePositionMap [yCrickPosition][xCrickPosition*3];
                        
                        if (colorPickStatusHold == 1 && colorSelectStatusHold == 0){
                            if (cursorRedMax == -1){
                                cursorRedMax = imageDisplayArray [yCrickPosition][xCrickPosition*3];
                                cursorRedMin = imageDisplayArray [yCrickPosition][xCrickPosition*3];
                            }
                            else{
                                
                                if (cursorRedMax == 0 && cursorRedMin == 0){
                                    cursorRedMax = imageDisplayArray [yCrickPosition][xCrickPosition*3];
                                    cursorRedMin = imageDisplayArray [yCrickPosition][xCrickPosition*3];
                                }
                                else{
                                    
                                    if (imageDisplayArray [yCrickPosition][xCrickPosition*3] > cursorRedMax) cursorRedMax = imageDisplayArray [yCrickPosition][xCrickPosition*3];
                                    if (imageDisplayArray [yCrickPosition][xCrickPosition*3] < cursorRedMin) cursorRedMin = imageDisplayArray [yCrickPosition][xCrickPosition*3];
                                }
                            }
                            
                            if (cursorGreenMax == -1){
                                cursorGreenMax = imageDisplayArray [yCrickPosition][xCrickPosition*3+1];
                                cursorGreenMin = imageDisplayArray [yCrickPosition][xCrickPosition*3+1];
                            }
                            else{
                                
                                if (cursorGreenMax == 0 && cursorGreenMin == 0){
                                    cursorGreenMax = imageDisplayArray [yCrickPosition][xCrickPosition*3+1];
                                    cursorGreenMin = imageDisplayArray [yCrickPosition][xCrickPosition*3+1];
                                }
                                else{
                                    
                                    if (imageDisplayArray [yCrickPosition][xCrickPosition*3] > cursorGreenMax) cursorGreenMax = imageDisplayArray [yCrickPosition][xCrickPosition*3+1];
                                    if (imageDisplayArray [yCrickPosition][xCrickPosition*3] < cursorGreenMin) cursorGreenMin = imageDisplayArray [yCrickPosition][xCrickPosition*3+1];
                                }
                            }
                            
                            if (cursorBlueMax == -1){
                                cursorBlueMax = imageDisplayArray [yCrickPosition][xCrickPosition*3+2];
                                cursorBlueMin = imageDisplayArray [yCrickPosition][xCrickPosition*3+2];
                            }
                            else{
                                
                                if (cursorBlueMax == 0 && cursorBlueMin == 0){
                                    cursorBlueMax = imageDisplayArray [yCrickPosition][xCrickPosition*3+2];
                                    cursorBlueMin = imageDisplayArray [yCrickPosition][xCrickPosition*3+2];
                                }
                                else{
                                    
                                    if (imageDisplayArray [yCrickPosition][xCrickPosition*3] > cursorBlueMax) cursorBlueMax = imageDisplayArray [yCrickPosition][xCrickPosition*3+2];
                                    if (imageDisplayArray [yCrickPosition][xCrickPosition*3] < cursorBlueMin) cursorBlueMin = imageDisplayArray [yCrickPosition][xCrickPosition*3+2];
                                }
                            }
                            
                            rangeDisplayCall = 1;
                        }
                        
                        mouseDownFlag = 1;
                    }
                    else processingFovNo = 0;
                }
                
                if (imageFLStatus == "Free" && processingFovNo > 0){
                    if (mouseDownFlag == 1){
                        xStartHold = xyPositionWritingData [(processingFovNo-1)*3+2];
                        yStartHold = xyPositionWritingData [(processingFovNo-1)*3+1];
                        mouseDownFlag = 2;
                    }
                    
                    int xStartCurrent = xyPositionWritingData [(processingFovNo-1)*3+2];
                    int yStartCurrent = xyPositionWritingData [(processingFovNo-1)*3+1];
                    
                    //For (int counterA = 0; counterA < fileListCount; counterA++){
                    //    cout<<xyPositionWritingData [counterA*3]<<" "<<xyPositionWritingData [counterA*3+1]<<" "<<xyPositionWritingData [counterA*3+2]<<" xyPositionWritingData"<<endl;
                    //}
                    
                    if (xStartHold >= 0 && xStartHold+imageDimensionW < stitchedImageDimension && yStartHold >= 0 && yStartHold+imageDimensionH < stitchedImageDimension){
                        xyPositionWritingData [(processingFovNo-1)*3+2] = xStartHold;
                        xyPositionWritingData [(processingFovNo-1)*3+1] = yStartHold;
                        
                        int newXPosition = xStartHold;
                        int newYPosition = yStartHold;
                        
                        int imageSetSize = 0;
                        int counterIncrement = 0;
                        
                        if (stitchedImageDimension <= 1000){
                            imageSetSize = stitchedImageDimension;
                            counterIncrement = 1;
                        }
                        else if (stitchedImageDimension <= 4000){
                            imageSetSize = stitchedImageDimension/2;
                            counterIncrement = 2;
                        }
                        else{
                            
                            imageSetSize = stitchedImageDimension/4;
                            counterIncrement = 4;
                        }
                        
                        if (resolutionStatusHold == 1){
                            imageSetSize = stitchedImageDimension;
                            counterIncrement = 1;
                        }
                        
                        if (photoMetricsHold == 1){
                            if (displayOrderHold == 0){
                                for (int counter1 = yStartCurrent; counter1 < yStartCurrent+imageDimensionH; counter1++){
                                    for (int counter2 = xStartCurrent; counter2 < xStartCurrent+imageDimensionW; counter2++){
                                        if (counter2 >= 0 && counter2 < stitchedImageDimension && counter1 >= 0 && counter1 < stitchedImageDimension && imagePositionMap [counter1][counter2] == processingFovNo){
                                            imageDisplayArray [counter1][counter2] = 0;
                                            imagePositionMap [counter1][counter2] = 0;
                                        }
                                    }
                                }
                            }
                            else{
                                
                                for (int counter1 = yStartCurrent; counter1 < yStartCurrent+imageDimensionH; counter1++){
                                    for (int counter2 = xStartCurrent; counter2 < xStartCurrent+imageDimensionW; counter2++){
                                        if (counter2 >= 0 && counter2 < stitchedImageDimension && counter1 >= 0 && counter1 < stitchedImageDimension){
                                            imageDisplayArray [counter1][counter2] = 0;
                                            imagePositionMap [counter1][counter2] = 0;
                                        }
                                    }
                                }
                            }
                            
                            int yImageCount = 0;
                            int xImageCount = 0;
                            
                            for (int counter1 = newYPosition; counter1 < newYPosition+imageDimensionH; counter1++){
                                for (int counter2 = newXPosition; counter2 < newXPosition+imageDimensionW; counter2++){
                                    if (counter1 < stitchedImageDimension && counter2 < stitchedImageDimension){
                                        if (imagePositionMap [counter1][counter2] == 0){
                                            imageDisplayArray [counter1][counter2] = arrayImageResults [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount];
                                            imagePositionMap [counter1][counter2] = processingFovNo;
                                        }
                                        
                                        xImageCount++;
                                    }
                                }
                                
                                yImageCount++;
                                xImageCount = 0;
                            }
                            
                            NSBitmapImageRep *bitmapReps;
                            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageSetSize  pixelsHigh:imageSetSize  bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageSetSize bitsPerPixel:8];
                            unsigned char *bitmapData = [bitmapReps bitmapData];
                            
                            for (int counter1 = 0; counter1 < stitchedImageDimension; counter1 = counter1+counterIncrement){
                                for (int counter2 = 0; counter2 < stitchedImageDimension; counter2 = counter2+counterIncrement){
                                    *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2];
                                }
                            }
                            
                            movieImage = [[NSImage alloc] initWithSize:NSMakeSize(stitchedImageDimension, stitchedImageDimension)];
                            [movieImage addRepresentation:bitmapReps];
                        }
                        else if (photoMetricsHold == 2){
                            if (displayOrderHold == 0){
                                for (int counter1 = yStartCurrent; counter1 < yStartCurrent+imageDimensionH; counter1++){
                                    for (int counter2 = xStartCurrent*3; counter2 < xStartCurrent*3+imageDimensionW*3; counter2 = counter2+3){
                                        if (counter2 >= 0 && counter2 < stitchedImageDimension*3 && counter1 >= 0 && counter1 < stitchedImageDimension && imagePositionMap [counter1][counter2] == processingFovNo){
                                            imageDisplayArray [counter1][counter2] = 0;
                                            imageDisplayArray [counter1][counter2+1] = 0;
                                            imageDisplayArray [counter1][counter2+2] = 0;
                                            imagePositionMap [counter1][counter2] = 0;
                                            imagePositionMap [counter1][counter2+1] = 0;
                                            imagePositionMap [counter1][counter2+2] = 0;
                                        }
                                    }
                                }
                            }
                            else{
                                
                                for (int counter1 = yStartCurrent; counter1 < yStartCurrent+imageDimensionH; counter1++){
                                    for (int counter2 = xStartCurrent*3; counter2 < xStartCurrent*3+imageDimensionW*3; counter2 = counter2+3){
                                        if (counter2 >= 0 && counter2 < stitchedImageDimension*3 && counter1 >= 0 && counter1 < stitchedImageDimension){
                                            imageDisplayArray [counter1][counter2] = 0;
                                            imageDisplayArray [counter1][counter2+1] = 0;
                                            imageDisplayArray [counter1][counter2+2] = 0;
                                            imagePositionMap [counter1][counter2] = 0;
                                            imagePositionMap [counter1][counter2+1] = 0;
                                            imagePositionMap [counter1][counter2+2] = 0;
                                        }
                                    }
                                }
                            }
                            
                            int yImageCount = 0;
                            int xImageCount = 0;
                            
                            for (int counter1 = newYPosition; counter1 < newYPosition+imageDimensionH; counter1++){
                                for (int counter2 = newXPosition*3; counter2 < newXPosition*3+imageDimensionW*3; counter2 = counter2+3){
                                    if (counter1 < stitchedImageDimension && counter2 < stitchedImageDimension*3){
                                        if (imagePositionMap [counter1][counter2] == 0){
                                            imageDisplayArray [counter1][counter2] = arrayImageResults [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount];
                                            imageDisplayArray [counter1][counter2+1] = arrayImageResults [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+1];
                                            imageDisplayArray [counter1][counter2+2] = arrayImageResults [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+2];
                                            
                                            imagePositionMap [counter1][counter2] = processingFovNo;
                                            imagePositionMap [counter1][counter2+1] = processingFovNo;
                                            imagePositionMap [counter1][counter2+2] = processingFovNo;
                                        }
                                        
                                        xImageCount = xImageCount+3;
                                    }
                                }
                                
                                yImageCount++;
                                xImageCount = 0;
                            }
                            
                            NSBitmapImageRep *bitmapReps;
                            bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageSetSize pixelsHigh:imageSetSize bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageSetSize*4 bitsPerPixel:32];
                            
                            unsigned char *bitmapData = [bitmapReps bitmapData];
                            
                            for (int counter1 = 0; counter1 < stitchedImageDimension; counter1 = counter1+counterIncrement){
                                for (int counter2 = 0; counter2 < stitchedImageDimension*3; counter2 = counter2+counterIncrement*3){
                                    *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2];
                                    *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2+1];
                                    *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2+2];
                                    *bitmapData++ = 0;
                                }
                            }
                            
                            movieImage = [[NSImage alloc] initWithSize:NSMakeSize(stitchedImageDimension, stitchedImageDimension)];
                            [movieImage addRepresentation:bitmapReps];
                        }
                    }
                }
            }
            else{
                
                if (currentFOVNoHold == 0) currentFOVNoHold = processingFovNo;
                else if (currentFOVNoHold != processingFovNo){
                    currentFOVNoHold = processingFovNo;
                }
                
                if (colorPickStatusHold == 1 && colorSelectStatusHold == 0){
                    if (cursorRedMax == -1){
                        cursorRedMax = imageDisplayArray [yCrickPosition][xCrickPosition*3];
                        cursorRedMin = imageDisplayArray [yCrickPosition][xCrickPosition*3];
                    }
                    else{
                        
                        if (cursorRedMax == 0 && cursorRedMin == 0){
                            cursorRedMax = imageDisplayArray [yCrickPosition][xCrickPosition*3];
                            cursorRedMin = imageDisplayArray [yCrickPosition][xCrickPosition*3];
                        }
                        else{
                            
                            if (imageDisplayArray [yCrickPosition][xCrickPosition*3] > cursorRedMax) cursorRedMax = imageDisplayArray [yCrickPosition][xCrickPosition*3];
                            if (imageDisplayArray [yCrickPosition][xCrickPosition*3] < cursorRedMin) cursorRedMin = imageDisplayArray [yCrickPosition][xCrickPosition*3];
                        }
                    }
                    
                    if (cursorGreenMax == -1){
                        cursorGreenMax = imageDisplayArray [yCrickPosition][xCrickPosition*3+1];
                        cursorGreenMin = imageDisplayArray [yCrickPosition][xCrickPosition*3+1];
                    }
                    else{
                        
                        if (cursorGreenMax == 0 && cursorGreenMin == 0){
                            cursorGreenMax = imageDisplayArray [yCrickPosition][xCrickPosition*3+1];
                            cursorGreenMin = imageDisplayArray [yCrickPosition][xCrickPosition*3+1];
                        }
                        else{
                            
                            if (imageDisplayArray [yCrickPosition][xCrickPosition*3] > cursorGreenMax) cursorGreenMax = imageDisplayArray [yCrickPosition][xCrickPosition*3+1];
                            if (imageDisplayArray [yCrickPosition][xCrickPosition*3] < cursorGreenMin) cursorGreenMin = imageDisplayArray [yCrickPosition][xCrickPosition*3+1];
                        }
                    }
                    
                    if (cursorBlueMax == -1){
                        cursorBlueMax = imageDisplayArray [yCrickPosition][xCrickPosition*3+2];
                        cursorBlueMin = imageDisplayArray [yCrickPosition][xCrickPosition*3+2];
                    }
                    else{
                        
                        if (cursorBlueMax == 0 && cursorBlueMin == 0){
                            cursorBlueMax = imageDisplayArray [yCrickPosition][xCrickPosition*3+2];
                            cursorBlueMin = imageDisplayArray [yCrickPosition][xCrickPosition*3+2];
                        }
                        else{
                            
                            if (imageDisplayArray [yCrickPosition][xCrickPosition*3] > cursorBlueMax) cursorBlueMax = imageDisplayArray [yCrickPosition][xCrickPosition*3+2];
                            if (imageDisplayArray [yCrickPosition][xCrickPosition*3] < cursorBlueMin) cursorBlueMin = imageDisplayArray [yCrickPosition][xCrickPosition*3+2];
                        }
                    }
                    
                    rangeDisplayCall = 1;
                }
            }
            
            [self setNeedsDisplay:YES];
        }
    }
}

-(void)mouseUp:(NSEvent *)event{
    if (imageLoadStatus != 0){
        xPositionDisplay = xPositionDisplay+xPositionMoveDisplay;
        yPositionDisplay = yPositionDisplay+yPositionMoveDisplay;
        xPositionMoveDisplay = 0;
        yPositionMoveDisplay = 0;
        mouseDragFlag = 0;
        mouseDownFlag = 0;
        
        [self setNeedsDisplay:YES];
    }
}

-(void)mouseDraged:(NSEvent *)event{
    if (imageLoadStatus != 0 && (colorAdjustFreeLock == 0 || (imageFLStatus == "Lock" && colorAdjustFreeLock == 1))){
        NSPoint clickPoint= [self convertPoint:[event locationInWindow] fromView:nil];
        xPointDragDisplay = clickPoint.x;
        yPointDragDisplay = clickPoint.y;
        
        if (imageFLStatus == "Lock"){
            xPositionMoveDisplay = (xPointDownDisplay-xPointDragDisplay)*windowWidthDisplay/(double)(magnificationDisplay*0.1);
            yPositionMoveDisplay = (yPointDownDisplay-yPointDragDisplay)*windowHeightDisplay/(double)(magnificationDisplay*0.1);
        }
        else if (processingFovNo > 0){
            if (mouseDownFlag == 1){
                xStartHold = xyPositionWritingData [(processingFovNo-1)*3+2];
                yStartHold = xyPositionWritingData [(processingFovNo-1)*3+1];
                mouseDownFlag = 2;
            }
            
            int xStartCurrent = xyPositionWritingData [(processingFovNo-1)*3+2];
            int yStartCurrent = xyPositionWritingData [(processingFovNo-1)*3+1];
            int xMovePosition = (int)((xPointDownDisplay-xPointDragDisplay)*windowWidthDisplay/(double)(magnificationDisplay*0.1));
            int yMovePosition = (int)((yPointDownDisplay-yPointDragDisplay)*windowHeightDisplay/(double)(magnificationDisplay*0.1));
            
            //For (int counterA = 0; counterA < fileListCount; counterA++){
            //    cout<<xyPositionWritingData [counterA*3]<<" "<<xyPositionWritingData [counterA*3+1]<<" "<<xyPositionWritingData [counterA*3+2]<<" xyPositionWritingData"<<endl;
            //}
            
            if (xStartHold-xMovePosition >= 0 && xStartHold-xMovePosition+imageDimensionW < stitchedImageDimension && yStartHold+yMovePosition >= 0 && yStartHold+yMovePosition+imageDimensionH < stitchedImageDimension){
                xyPositionWritingData [(processingFovNo-1)*3+2] = xStartHold-xMovePosition;
                xyPositionWritingData [(processingFovNo-1)*3+1] = yStartHold+yMovePosition;
                
                int newXPosition = xStartHold-xMovePosition;
                int newYPosition = yStartHold+yMovePosition;
                
                int imageSetSize = 0;
                int counterIncrement = 0;
                
                if (stitchedImageDimension <= 1000){
                    imageSetSize = stitchedImageDimension;
                    counterIncrement = 1;
                }
                else if (stitchedImageDimension <= 4000){
                    imageSetSize = stitchedImageDimension/2;
                    counterIncrement = 2;
                }
                else{
                    
                    imageSetSize = stitchedImageDimension/4;
                    counterIncrement = 4;
                }
                
                if (resolutionStatusHold == 1){
                    imageSetSize = stitchedImageDimension;
                    counterIncrement = 1;
                }
                
                if (photoMetricsHold == 1){
                    if (displayOrderHold == 0){
                        for (int counter1 = yStartCurrent; counter1 < yStartCurrent+imageDimensionH; counter1++){
                            for (int counter2 = xStartCurrent; counter2 < xStartCurrent+imageDimensionW; counter2++){
                                if (counter2 >= 0 && counter2 < stitchedImageDimension && counter1 >= 0 && counter1 < stitchedImageDimension && imagePositionMap [counter1][counter2] == processingFovNo){
                                    imageDisplayArray [counter1][counter2] = 0;
                                    imagePositionMap [counter1][counter2] = 0;
                                }
                            }
                        }
                    }
                    else{
                        
                        for (int counter1 = yStartCurrent; counter1 < yStartCurrent+imageDimensionH; counter1++){
                            for (int counter2 = xStartCurrent; counter2 < xStartCurrent+imageDimensionW; counter2++){
                                if (counter2 >= 0 && counter2 < stitchedImageDimension && counter1 >= 0 && counter1 < stitchedImageDimension){
                                    imageDisplayArray [counter1][counter2] = 0;
                                    imagePositionMap [counter1][counter2] = 0;
                                }
                            }
                        }
                    }
                    
                    int yImageCount = 0;
                    int xImageCount = 0;
                    
                    for (int counter1 = newYPosition; counter1 < newYPosition+imageDimensionH; counter1++){
                        for (int counter2 = newXPosition; counter2 < newXPosition+imageDimensionW; counter2++){
                            if (counter1 < stitchedImageDimension && counter2 < stitchedImageDimension){
                                if (imagePositionMap [counter1][counter2] == 0){
                                    imageDisplayArray [counter1][counter2] = arrayImageResults [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount];
                                    imagePositionMap [counter1][counter2] = processingFovNo;
                                }
                                
                                xImageCount++;
                            }
                        }
                        
                        yImageCount++;
                        xImageCount = 0;
                    }
                    
                    NSBitmapImageRep *bitmapReps;
                    bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageSetSize  pixelsHigh:imageSetSize  bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageSetSize bitsPerPixel:8];
                    unsigned char *bitmapData = [bitmapReps bitmapData];
                    
                    for (int counter1 = 0; counter1 < stitchedImageDimension; counter1 = counter1+counterIncrement){
                        for (int counter2 = 0; counter2 < stitchedImageDimension; counter2 = counter2+counterIncrement){
                            *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2];
                        }
                    }
                    
                    movieImage = [[NSImage alloc] initWithSize:NSMakeSize(stitchedImageDimension, stitchedImageDimension)];
                    [movieImage addRepresentation:bitmapReps];
                }
                else if (photoMetricsHold == 2){
                    if (displayOrderHold == 0){
                        for (int counter1 = yStartCurrent; counter1 < yStartCurrent+imageDimensionH; counter1++){
                            for (int counter2 = xStartCurrent*3; counter2 < xStartCurrent*3+imageDimensionW*3; counter2 = counter2+3){
                                if (counter2 >= 0 && counter2 < stitchedImageDimension*3 && counter1 >= 0 && counter1 < stitchedImageDimension && imagePositionMap [counter1][counter2] == processingFovNo){
                                    imageDisplayArray [counter1][counter2] = 0;
                                    imageDisplayArray [counter1][counter2+1] = 0;
                                    imageDisplayArray [counter1][counter2+2] = 0;
                                    imagePositionMap [counter1][counter2] = 0;
                                    imagePositionMap [counter1][counter2+1] = 0;
                                    imagePositionMap [counter1][counter2+2] = 0;
                                }
                            }
                        }
                    }
                    else{
                        
                        for (int counter1 = yStartCurrent; counter1 < yStartCurrent+imageDimensionH; counter1++){
                            for (int counter2 = xStartCurrent*3; counter2 < xStartCurrent*3+imageDimensionW*3; counter2 = counter2+3){
                                if (counter2 >= 0 && counter2 < stitchedImageDimension*3 && counter1 >= 0 && counter1 < stitchedImageDimension){
                                    imageDisplayArray [counter1][counter2] = 0;
                                    imageDisplayArray [counter1][counter2+1] = 0;
                                    imageDisplayArray [counter1][counter2+2] = 0;
                                    imagePositionMap [counter1][counter2] = 0;
                                    imagePositionMap [counter1][counter2+1] = 0;
                                    imagePositionMap [counter1][counter2+2] = 0;
                                }
                            }
                        }
                    }
                    
                    int yImageCount = 0;
                    int xImageCount = 0;
                    
                    for (int counter1 = newYPosition; counter1 < newYPosition+imageDimensionH; counter1++){
                        for (int counter2 = newXPosition*3; counter2 < newXPosition*3+imageDimensionW*3; counter2 = counter2+3){
                            if (counter1 < stitchedImageDimension && counter2 < stitchedImageDimension*3){
                                if (imagePositionMap [counter1][counter2] == 0){
                                    imageDisplayArray [counter1][counter2] = arrayImageResults [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount];
                                    imageDisplayArray [counter1][counter2+1] = arrayImageResults [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+1];
                                    imageDisplayArray [counter1][counter2+2] = arrayImageResults [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+2];
                                    
                                    imagePositionMap [counter1][counter2] = processingFovNo;
                                    imagePositionMap [counter1][counter2+1] = processingFovNo;
                                    imagePositionMap [counter1][counter2+2] = processingFovNo;
                                }
                                
                                xImageCount = xImageCount+3;
                            }
                        }
                        
                        yImageCount++;
                        xImageCount = 0;
                    }
                    
                    NSBitmapImageRep *bitmapReps;
                    bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageSetSize pixelsHigh:imageSetSize bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageSetSize*4 bitsPerPixel:32];
                    
                    unsigned char *bitmapData = [bitmapReps bitmapData];
                    
                    for (int counter1 = 0; counter1 < stitchedImageDimension; counter1 = counter1+counterIncrement){
                        for (int counter2 = 0; counter2 < stitchedImageDimension*3; counter2 = counter2+counterIncrement*3){
                            *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2];
                            *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2+1];
                            *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2+2];
                            *bitmapData++ = 0;
                        }
                    }
                    
                    movieImage = [[NSImage alloc] initWithSize:NSMakeSize(stitchedImageDimension, stitchedImageDimension)];
                    [movieImage addRepresentation:bitmapReps];
                }
            }
        }
        
        mouseDragFlag = 1;
        [self setNeedsDisplay:YES];
    }
}

-(void)keyDown:(NSEvent *)event{
    int keyCode = [event keyCode];
    
    if (imageLoadStatus != 0){
        if (keyCode == 6){ //-----Z-----
            xPositionDisplay = 0;
            yPositionDisplay = 0;
            xPositionAdjustDisplay = 0;
            yPositionAdjustDisplay = 0;
            magnificationDisplay = 10;
            
            xPositionAdjustDisplay = (stitchedImageDimension-stitchedImageDimension/(double)(magnificationDisplay*0.1))/(double)2;
            yPositionAdjustDisplay = (stitchedImageDimension-stitchedImageDimension/(double)(magnificationDisplay*0.1))/(double)2;
            
            [self setNeedsDisplay:YES];
        }
        
        if (keyCode == 34){ //-----I-----
            if (imageFLStatus == "Lock"){
                imageFLStatus = "Free";
                processingFovNo = 0;
                contrastLockRelease = 1;
            }
            else if (imageFLStatus == "Free"){
                imageFLStatus = "Lock";
                processingFovNo = -1;
            }
            
            [self setNeedsDisplay:YES];
        }
        
        if (keyCode == 35){ //-----P-----
            if (colorPickStatusHold == 0){
                colorPickStatusHold = 1;
                colorPickStatusCall = 1;
            }
            else if (colorPickStatusHold == 1){
                colorPickStatusHold = 0;
                colorPickStatusCall = 2;
            }
            
            [self setNeedsDisplay:YES];
        }
        
        if (keyCode == 31){ //-----I-----
            if (resolutionStatusHold == 0){
                resolutionStatusHold = 1;
            }
            else if (resolutionStatusHold  == 1){
                resolutionStatusHold = 0;
            }
            
            int imageSetSize = 0;
            int counterIncrement = 0;
            
            if (stitchedImageDimension <= 1000){
                imageSetSize = stitchedImageDimension;
                counterIncrement = 1;
            }
            else if (stitchedImageDimension <= 4000){
                imageSetSize = stitchedImageDimension/2;
                counterIncrement = 2;
            }
            else{
                
                imageSetSize = stitchedImageDimension/4;
                counterIncrement = 4;
            }
            
            if (resolutionStatusHold == 1){
                imageSetSize = stitchedImageDimension;
                counterIncrement = 1;
            }
            
            if (photoMetricsHold == 1){
                NSBitmapImageRep *bitmapReps;
                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageSetSize  pixelsHigh:imageSetSize  bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageSetSize bitsPerPixel:8];
                unsigned char *bitmapData = [bitmapReps bitmapData];
                
                for (int counter1 = 0; counter1 < stitchedImageDimension; counter1 = counter1+counterIncrement){
                    for (int counter2 = 0; counter2 < stitchedImageDimension; counter2 = counter2+counterIncrement){
                        *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2];
                    }
                }
                
                movieImage = [[NSImage alloc] initWithSize:NSMakeSize(stitchedImageDimension, stitchedImageDimension)];
                [movieImage addRepresentation:bitmapReps];
            }
            else if (photoMetricsHold == 2){
                NSBitmapImageRep *bitmapReps;
                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageSetSize pixelsHigh:imageSetSize bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageSetSize*4 bitsPerPixel:32];
                
                unsigned char *bitmapData = [bitmapReps bitmapData];
                
                for (int counter1 = 0; counter1 < stitchedImageDimension; counter1 = counter1+counterIncrement){
                    for (int counter2 = 0; counter2 < stitchedImageDimension*3; counter2 = counter2+counterIncrement*3){
                        *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2];
                        *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2+1];
                        *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2+2];
                        *bitmapData++ = 0;
                    }
                }
                
                movieImage = [[NSImage alloc] initWithSize:NSMakeSize(stitchedImageDimension, stitchedImageDimension)];
                [movieImage addRepresentation:bitmapReps];
            }
            
            [self setNeedsDisplay:YES];
        }
        
        if (keyCode == 15){ //-----R-----
            int stitchedImageDimensionHold = stitchedImageDimension;
            
            stitchedImageDimension = 0;
            
            int imagePositionXMax = 0;
            int imagePositionYMax = 0;
            int imagePositionXMin = 100000000;
            int imagePositionYMin = 100000000;
            
            for (int counter3 = 0; counter3 < fileListCount; counter3++){
                if (xyPositionData [counter3*3+2] > imagePositionXMax) imagePositionXMax = xyPositionData [counter3*3+2];
                if (xyPositionData [counter3*3+1] > imagePositionYMax) imagePositionYMax = xyPositionData [counter3*3+1];
                if (xyPositionData [counter3*3+2] < imagePositionXMin) imagePositionXMin = xyPositionData [counter3*3+2];
                if (xyPositionData [counter3*3+1] < imagePositionYMin) imagePositionYMin = xyPositionData [counter3*3+1];
            }
            
            if (imagePositionXMax == 0 || imagePositionXMin == 100000000){
                imagePositionXMax = 0;
                imagePositionXMin = 0;
            }
            
            if (imagePositionYMax == 0 || imagePositionYMin == 100000000){
                imagePositionYMax = 0;
                imagePositionYMin = 0;
            }
            
            imagePositionXMax = imagePositionXMax+imageDimensionW;
            imagePositionYMax = imagePositionYMax+imageDimensionH;
            
            int imagePositionXDimension = imagePositionXMax-imagePositionXMin;
            int imagePositionYDimension = imagePositionYMax-imagePositionYMin;
            int longerXAxeAdjust = 0;
            int longerYAxeAdjust = 0;
            
            if (imagePositionXDimension > imagePositionYDimension){
                stitchedImageDimension = imagePositionXDimension;
                longerYAxeAdjust = (int)((imagePositionXDimension-imagePositionYDimension)/(double)2);
            }
            else{
                
                stitchedImageDimension = imagePositionYDimension;
                longerXAxeAdjust = (int)((imagePositionYDimension-imagePositionXDimension)/(double)2);
            }
            
            int stitchedImageDimensionAddition = (int)(stitchedImageDimension*0.2);
            
            stitchedImageDimension = stitchedImageDimension+stitchedImageDimensionAddition;
            
            int dimensionAdjust = stitchedImageDimension/4;
            stitchedImageDimension = dimensionAdjust*4+4;
            
            for (int counter2 = 0; counter2 < fileListCount; counter2++){
                if (longerXAxeAdjust == 0){
                    xyPositionWritingData [counter2*3] = xyPositionData [counter2*3];
                    xyPositionWritingData [counter2*3+1] = xyPositionData [counter2*3+1]-imagePositionYMin+(int)(stitchedImageDimensionAddition/(double)2)+longerYAxeAdjust;
                    xyPositionWritingData [counter2*3+2] = xyPositionData [counter2*3+2]-imagePositionXMin+(int)(stitchedImageDimensionAddition/(double)2);
                }
                else{
                    
                    xyPositionWritingData [counter2*3] = xyPositionData [counter2*3];
                    xyPositionWritingData [counter2*3+1] = xyPositionData [counter2*3+1]-imagePositionYMin+(int)(stitchedImageDimensionAddition/(double)2);
                    xyPositionWritingData [counter2*3+2] = xyPositionData [counter2*3+2]-imagePositionXMin+(int)(stitchedImageDimensionAddition/(double)2)+longerXAxeAdjust;
                }
            }
            
            if (photoMetricsHold == 1){
                if (imageRangeAdjustStatus == 1){
                    for (int counter2 = 0; counter2 < stitchedImageDimensionHold+1; counter2++){
                        delete [] imageDisplayArray [counter2];
                        delete [] imagePositionMap [counter2];
                    }
                    
                    delete [] imageDisplayArray;
                    delete [] imagePositionMap;
                }
                
                imageRangeAdjustStatus = 1;
                
                imageDisplayArray = new int *[stitchedImageDimension+1];
                imagePositionMap = new int *[stitchedImageDimension+1];
                
                for (int counter2 = 0; counter2 < stitchedImageDimension+1; counter2++){
                    imageDisplayArray [counter2] = new int [stitchedImageDimension+1];
                    imagePositionMap [counter2] = new int [stitchedImageDimension+1];
                }
                
                for (int counter3 = 0; counter3 < stitchedImageDimension; counter3++){
                    for (int counter4 = 0; counter4 < stitchedImageDimension; counter4++){
                        imageDisplayArray [counter3][counter4] = 0;
                        imagePositionMap [counter3][counter4] = 0;
                    }
                }
                
                for (int counter2 = 0; counter2 < fileListCount; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionH; counter3++){
                        for (int counter4 = 0; counter4 < imageDimensionW; counter4++){
                            imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]+counter4] = arrayImageResults [counter2*imageDimensionH+counter3][counter4];
                            imagePositionMap [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]+counter4] = xyPositionWritingData [counter2*3];
                        }
                    }
                }
            }
            else if (photoMetricsHold == 2){
                if (imageRangeAdjustStatus == 1){
                    for (int counter2 = 0; counter2 < stitchedImageDimensionHold+1; counter2++){
                        delete [] imageDisplayArray [counter2];
                        delete [] imagePositionMap [counter2];
                    }
                    
                    delete [] imageDisplayArray;
                    delete [] imagePositionMap;
                }
                
                imageRangeAdjustStatus = 1;
                
                imageDisplayArray = new int *[stitchedImageDimension+1];
                imagePositionMap = new int *[stitchedImageDimension+1];
                
                for (int counter2 = 0; counter2 < stitchedImageDimension+1; counter2++){
                    imageDisplayArray [counter2] = new int [stitchedImageDimension*3+1];
                    imagePositionMap [counter2] = new int [stitchedImageDimension*3+1];
                }
                
                for (int counter2 = 0; counter2 < stitchedImageDimension; counter2++){
                    for (int counter3 = 0; counter3 < stitchedImageDimension*3; counter3++){
                        imageDisplayArray [counter2][counter3] = 0;
                        imagePositionMap [counter2][counter3] = 0;
                    }
                }
                
                for (int counter2 = 0; counter2 < fileListCount; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionH; counter3++){
                        for (int counter4 = 0; counter4 < imageDimensionW*3; counter4 = counter4+3){
                            imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4] = arrayImageResults [counter2*imageDimensionH+counter3][counter4];
                            imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4+1] = arrayImageResults [counter2*imageDimensionH+counter3][counter4+1];
                            imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4+2] = arrayImageResults [counter2*imageDimensionH+counter3][counter4+2];
                            
                            imagePositionMap [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4] = xyPositionWritingData [counter2*3];
                            imagePositionMap [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4+1] = xyPositionWritingData [counter2*3];
                            imagePositionMap [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4+2] = xyPositionWritingData [counter2*3];
                        }
                    }
                }
            }
            
            int imageSetSize = 0;
            int counterIncrement = 0;
            
            if (stitchedImageDimension <= 1000){
                imageSetSize = stitchedImageDimension;
                counterIncrement = 1;
            }
            else if (stitchedImageDimension <= 4000){
                imageSetSize = stitchedImageDimension/2;
                counterIncrement = 2;
            }
            else{
                
                imageSetSize = stitchedImageDimension/4;
                counterIncrement = 4;
            }
            
            if (resolutionStatusHold == 1){
                imageSetSize = stitchedImageDimension;
                counterIncrement = 1;
            }
            
            if (photoMetricsHold == 1){
                NSBitmapImageRep *bitmapReps;
                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageSetSize  pixelsHigh:imageSetSize  bitsPerSample:8 samplesPerPixel:1 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceWhiteColorSpace bytesPerRow:imageSetSize bitsPerPixel:8];
                unsigned char *bitmapData = [bitmapReps bitmapData];
                
                for (int counter1 = 0; counter1 < stitchedImageDimension; counter1 = counter1+counterIncrement){
                    for (int counter2 = 0; counter2 < stitchedImageDimension; counter2 = counter2+counterIncrement){
                        *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2];
                    }
                }
                
                movieImage = [[NSImage alloc] initWithSize:NSMakeSize(stitchedImageDimension, stitchedImageDimension)];
                [movieImage addRepresentation:bitmapReps];
            }
            else if (photoMetricsHold == 2){
                NSBitmapImageRep *bitmapReps;
                bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageSetSize pixelsHigh:imageSetSize bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageSetSize*4 bitsPerPixel:32];
                
                unsigned char *bitmapData = [bitmapReps bitmapData];
                
                for (int counter1 = 0; counter1 < stitchedImageDimension; counter1 = counter1+counterIncrement){
                    for (int counter2 = 0; counter2 < stitchedImageDimension*3; counter2 = counter2+counterIncrement*3){
                        *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2];
                        *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2+1];
                        *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2+2];
                        *bitmapData++ = 0;
                    }
                }
                
                movieImage = [[NSImage alloc] initWithSize:NSMakeSize(stitchedImageDimension, stitchedImageDimension)];
                [movieImage addRepresentation:bitmapReps];
            }
            
            [self setNeedsDisplay:YES];
        }
        
        if (keyCode == 13){ //-----W-----
            if (listModeStatusHold == 0){
                listModeStatusHold = 1;
            }
            else if (listModeStatusHold == 1){
                listModeStatusHold = 0;
                blurCutHold = 0;
                imageDisplayCall = 4;
            }
            
            [self setNeedsDisplay:YES];
        }
        
        if (keyCode == 8){ //-----C-----
            if (colorAdjustFreeLock == 0){
                colorAdjustFreeLock = 1;
            }
            else if (colorAdjustFreeLock == 1){
                colorAdjustFreeLock = 0;
            }
            
            [self setNeedsDisplay:YES];
        }
        
        if (keyCode == 0){ //-----A-----
            if (listDataCount < 28){
                listDataHold [listDataCount*15] = levelHoldContrast;
                listDataHold [listDataCount*15+1] = levelHoldBrightness;
                listDataHold [listDataCount*15+2] = levelHoldRed;
                listDataHold [listDataCount*15+3] = cutRedHold;
                listDataHold [listDataCount*15+4] = levelHoldGreen;
                listDataHold [listDataCount*15+5] = cutGreenHold;
                listDataHold [listDataCount*15+6] = levelHoldBlue;
                listDataHold [listDataCount*15+7] = cutBlueHold;
                listDataHold [listDataCount*15+8] = levelHoldRedPick;
                listDataHold [listDataCount*15+9] = cutRedHoldPick;
                listDataHold [listDataCount*15+10] = levelHoldGreenPick;
                listDataHold [listDataCount*15+11] = cutGreenHoldPick;
                listDataHold [listDataCount*15+12] = levelHoldBluePick;
                listDataHold [listDataCount*15+13] = cutBlueHoldPick;
                
                if (imageFLStatus == "Lock" || (processingFovNo == 0 && imageFLStatus == "Free")){
                    listDataHold [listDataCount*15+14] = 0;
                }
                else listDataHold [listDataCount*15+14] = processingFovNo;
                
                listDataCount++;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
                
                [self setNeedsDisplay:YES];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Maximum Of 27 Entries Allowed"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        
        if (keyCode == 2){ //-----D-----
            if (listDataCount > 0 && clickList > 0){
                int entryCount = 0;
                int deletionFind = 0;
                
                for (int counter1 = 0; counter1 < listDataCount; counter1++){
                    if (clickList != counter1){
                        listDataHold [entryCount*15] = listDataHold [counter1*15];
                        listDataHold [entryCount*15+1] = listDataHold [counter1*15+1];
                        listDataHold [entryCount*15+2] = listDataHold [counter1*15+2];
                        listDataHold [entryCount*15+3] = listDataHold [counter1*15+3];
                        listDataHold [entryCount*15+4] = listDataHold [counter1*15+4];
                        listDataHold [entryCount*15+5] = listDataHold [counter1*15+5];
                        listDataHold [entryCount*15+6] = listDataHold [counter1*15+6];
                        listDataHold [entryCount*15+7] = listDataHold [counter1*15+7];
                        listDataHold [entryCount*15+8] = listDataHold [counter1*15+8];
                        listDataHold [entryCount*15+9] = listDataHold [counter1*15+9];
                        listDataHold [entryCount*15+10] = listDataHold [counter1*15+10];
                        listDataHold [entryCount*15+11] = listDataHold [counter1*15+11];
                        listDataHold [entryCount*15+12] = listDataHold [counter1*15+12];
                        listDataHold [entryCount*15+13] = listDataHold [counter1*15+13];
                        listDataHold [entryCount*15+14] = listDataHold [counter1*15+14];
                        
                        entryCount++;
                    }
                    else deletionFind = 1;
                }
                
                if (deletionFind == 1){
                    listDataCount--;
                }
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
                
                [self setNeedsDisplay:YES];
            }
        }
        
        if (keyCode == 3 || keyCode == 9){ //-----F/V-----
            /*
             When Peach color button is on, use R, G, B, RG, RB, GB, or RGB value to calculate gray scale value. In the case that RG, RB, GB or RGB is selected, calculate average value of two or three channels.
             When no Peach button is set, generate RGB image.
             */
            
            if (colorSelectStatusHold == 1){
                if (photoMetricsHold == 2){
                    int tempValue1 = 0;
                    int tempValue2 = 0;
                    int tempValue3 = 0;
                    int tempValueIV1 = 0;
                    int tempValueIV2 = 0;
                    int tempValueIV3 = 0;
                    int allBlack = 0;
                    
                    for (int counter2 = 0; counter2 < fileListCount; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionH; counter3++){
                            for (int counter4 = 0; counter4 < imageDimensionW*3; counter4 = counter4+3){
                                allBlack = 0;
                                
                                for (int counter5 = 1; counter5 < listDataCount; counter5++){
                                    if (listDataHold[counter5*15+14] == 0){
                                        if ((int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4]*(double)listDataHold[counter5*15]) > 255) tempValue1 = 255;
                                        else tempValue1 = (int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4]*(double)listDataHold[counter5*15]);
                                        
                                        if ((int)(tempValue1+listDataHold[counter5*15+1]) > 255) tempValue1 = 255;
                                        else tempValue1 = (int)(tempValue1+listDataHold[counter5*15+1]);
                                        
                                        if (tempValue1 > listDataHold[counter5*15+3]){
                                            if ((int)(tempValue1+listDataHold[counter5*15+2]) > 255) tempValue1 = 255;
                                            else tempValue1 = (int)(tempValue1+listDataHold[counter5*15+2]);
                                        }
                                        
                                        if ((int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4+1]*(double)listDataHold[counter5*15]) > 255) tempValue2 = 255;
                                        else tempValue2 = (int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4+1]*(double)listDataHold[counter5*15]);
                                        
                                        if ((int)(tempValue2+listDataHold[counter5*15+1]) > 255) tempValue2 = 255;
                                        else tempValue2 = (int)(tempValue2+listDataHold[counter5*15+1]);
                                        
                                        if (tempValue2 > listDataHold[counter5*15+5]){
                                            if ((int)(tempValue2+listDataHold[counter5*15+4]) > 255) tempValue2 = 255;
                                            else tempValue2 = (int)(tempValue2+listDataHold[counter5*15+4]);
                                        }
                                        
                                        if ((int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4+2]*(double)listDataHold[counter5*15]) > 255) tempValue3 = 255;
                                        else tempValue3 = (int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4+2]*(double)listDataHold[counter5*15]);
                                        
                                        if ((int)(tempValue3+listDataHold[counter5*15+1]) > 255) tempValue3 = 255;
                                        else tempValue3 = (int)(tempValue3+listDataHold[counter5*15+1]);
                                        
                                        if (tempValue3 > listDataHold[counter5*15+7]){
                                            if ((int)(tempValue3+listDataHold[counter5*15+6]) > 255) tempValue3 = 255;
                                            else tempValue3 = (int)(tempValue3+listDataHold[counter5*15+6]);
                                        }
                                        
                                        tempValueIV1 = tempValue1;
                                        tempValueIV2 = tempValue2;
                                        tempValueIV3 = tempValue3;
                                        
                                        if (tempValue1 <= listDataHold[counter5*15+8]-listDataHold[counter5*15+9] || tempValue1 > listDataHold[counter5*15+8]+listDataHold[counter5*15+9] || tempValue2 <= listDataHold[counter5*15+10]-listDataHold[counter5*15+11] || tempValue2 > listDataHold[counter5*15+10]+listDataHold[counter5*15+11] || tempValue3 <= listDataHold[counter5*15+12]-listDataHold[counter5*15+13] || tempValue3 > listDataHold[counter5*15+12]+listDataHold[counter5*15+13]){
                                            
                                            tempValue1 = 0;
                                            tempValue2 = 0;
                                            tempValue3 = 0;
                                        }
                                        
                                        if (tempValue1 != 0 || tempValue2 != 0 || tempValue3 != 0){
                                            allBlack = 1;
                                            
                                            if (keyCode == 9){
                                                tempValue1 = 0;
                                                tempValue2 = 0;
                                                tempValue3 = 0;
                                            }
                                            
                                            break;
                                        }
                                    }
                                }
                                
                                if (allBlack == 0 && keyCode == 9){
                                    tempValue1 = tempValueIV1;
                                    tempValue2 = tempValueIV2;
                                    tempValue3 = tempValueIV3;
                                }
                                
                                arrayImageResults [counter2*imageDimensionH+counter3][counter4] = tempValue1;
                                arrayImageResults [counter2*imageDimensionH+counter3][counter4+1] = tempValue2;
                                arrayImageResults [counter2*imageDimensionH+counter3][counter4+2] = tempValue3;
                                
                                imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4] = tempValue1;
                                imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4+1] = tempValue2;
                                imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4+2] = tempValue3;
                            }
                        }
                    }
                    
                    int newXPosition = 0;
                    int newYPosition = 0;
                    int yImageCount = 0;
                    int xImageCount = 0;
                    int fovPosition = 0;
                    
                    for (int counter1 = 1; counter1 < listDataCount; counter1++){
                        if (listDataHold[counter1*15+14] != 0){
                            fovPosition = (int)listDataHold[counter1*15+14];
                            newXPosition = xyPositionWritingData [(fovPosition-1)*3+2];
                            newYPosition = xyPositionWritingData [(fovPosition-1)*3+1];
                            
                            yImageCount = 0;
                            xImageCount = 0;
                            
                            for (int counter2 = newYPosition; counter2 < newYPosition+imageDimensionH; counter2++){
                                for (int counter3 = newXPosition*3; counter3 < newXPosition*3+imageDimensionW*3; counter3 = counter3+3){
                                    if ((int)(arrayImageDataHold [(fovPosition-1)*imageDimensionH+yImageCount][xImageCount]*(double)listDataHold[counter1*15]) > 255) tempValue1 = 255;
                                    else tempValue1 = (int)(arrayImageDataHold [(fovPosition-1)*imageDimensionH+yImageCount][xImageCount]*(double)listDataHold[counter1*15]);
                                    
                                    if ((int)(tempValue1+listDataHold[counter1*15+1]) > 255) tempValue1 = 255;
                                    else tempValue1 = (int)(tempValue1+listDataHold[counter1*15+1]);
                                    
                                    if (tempValue1 > listDataHold[counter1*15+3]){
                                        if ((int)(tempValue1+listDataHold[counter1*15+2]) > 255) tempValue1 = 255;
                                        else tempValue1 = (int)(tempValue1+listDataHold[counter1*15+2]);
                                    }
                                    
                                    if ((int)(arrayImageDataHold [(fovPosition-1)*imageDimensionH+yImageCount][xImageCount+1]*(double)listDataHold[counter1*15]) > 255) tempValue2 = 255;
                                    else tempValue2 = (int)(arrayImageDataHold [(fovPosition-1)*imageDimensionH+yImageCount][xImageCount+1]*(double)listDataHold[counter1*15]);
                                    
                                    if ((int)(tempValue2+listDataHold[counter1*15+1]) > 255) tempValue2 = 255;
                                    else tempValue2 = (int)(tempValue2+listDataHold[counter1*15+1]);
                                    
                                    if (tempValue2 > listDataHold[counter1*15+5]){
                                        if ((int)(tempValue2+listDataHold[counter1*15+4]) > 255) tempValue2 = 255;
                                        else tempValue2 = (int)(tempValue2+listDataHold[counter1*15+4]);
                                    }
                                    
                                    if ((int)(arrayImageDataHold [(fovPosition-1)*imageDimensionH+yImageCount][xImageCount+2]*(double)listDataHold[counter1*15]) > 255) tempValue3 = 255;
                                    else tempValue3 = (int)(arrayImageDataHold [(fovPosition-1)*imageDimensionH+yImageCount][xImageCount+2]*(double)listDataHold[counter1*15]);
                                    
                                    if ((int)(tempValue3+listDataHold[counter1*15+1]) > 255) tempValue3 = 255;
                                    else tempValue3 = (int)(tempValue3+listDataHold[counter1*15+1]);
                                    
                                    if (tempValue3 > listDataHold[counter1*15+7]){
                                        if ((int)(tempValue3+listDataHold[counter1*15+6]) > 255) tempValue3 = 255;
                                        else tempValue3 = (int)(tempValue3+listDataHold[counter1*15+6]);
                                    }
                                    
                                    tempValueIV1 = tempValue1;
                                    tempValueIV2 = tempValue2;
                                    tempValueIV3 = tempValue3;
                                    
                                    if (tempValue1 <= listDataHold[counter1*15+8]-listDataHold[counter1*15+9] || tempValue1 > listDataHold[counter1*15+8]+listDataHold[counter1*15+9] || tempValue2 <= listDataHold[counter1*15+10]-listDataHold[counter1*15+11] || tempValue2 > listDataHold[counter1*15+10]+listDataHold[counter1*15+11] || tempValue3 <= listDataHold[counter1*15+12]-listDataHold[counter1*15+13] || tempValue3 > listDataHold[counter1*15+12]+listDataHold[counter1*15+13]){
                                        tempValue1 = 0;
                                        tempValue2 = 0;
                                        tempValue3 = 0;
                                    }
                                    
                                    if (tempValue1 == 0 && tempValue2 == 0 && tempValue3 == 0){
                                        if (keyCode == 9){
                                            tempValue1 = tempValueIV1;
                                            tempValue2 = tempValueIV2;
                                            tempValue3 = tempValueIV3;
                                        }
                                    }
                                    else if (tempValue1 != 0 || tempValue2 != 0 || tempValue3 != 0){
                                        if (keyCode == 9){
                                            tempValue1 = 0;
                                            tempValue2 = 0;
                                            tempValue3 = 0;
                                        }
                                    }
                                    
                                    arrayImageResults [(fovPosition-1)*imageDimensionH+yImageCount][xImageCount] = tempValue1;
                                    arrayImageResults [(fovPosition-1)*imageDimensionH+yImageCount][xImageCount+1] = tempValue2;
                                    arrayImageResults [(fovPosition-1)*imageDimensionH+yImageCount][xImageCount+2] = tempValue3;
                                    
                                    imageDisplayArray [counter2][counter3] = tempValue1;
                                    imageDisplayArray [counter2][counter3+1] = tempValue2;
                                    imageDisplayArray [counter2][counter3+2] = tempValue3;
                                    
                                    xImageCount = xImageCount+3;
                                }
                                
                                yImageCount++;
                                xImageCount = 0;
                            }
                        }
                    }
                    
                    for (int counter2 = 0; counter2 < stitchedImageDimension; counter2++){
                        for (int counter3 = 0; counter3 < stitchedImageDimension; counter3++){
                            if (mergeRStatusHold == 1 && mergeGStatusHold == 0 && mergeBStatusHold == 0){
                                imageDisplayArray [counter2][counter3*3] = imageDisplayArray [counter2][counter3*3];
                                imageDisplayArray [counter2][counter3*3+1] = imageDisplayArray [counter2][counter3*3];
                                imageDisplayArray [counter2][counter3*3+2] = imageDisplayArray [counter2][counter3*3];
                            }
                            else if (mergeRStatusHold == 0 && mergeGStatusHold == 1 && mergeBStatusHold == 0){
                                imageDisplayArray [counter2][counter3*3] = imageDisplayArray [counter2][counter3*3+1];
                                imageDisplayArray [counter2][counter3*3+1] = imageDisplayArray [counter2][counter3*3+1];
                                imageDisplayArray [counter2][counter3*3+2] = imageDisplayArray [counter2][counter3*3+1];
                            }
                            else if (mergeRStatusHold == 0 && mergeGStatusHold == 0 && mergeBStatusHold == 1){
                                imageDisplayArray [counter2][counter3*3] = imageDisplayArray [counter2][counter3*3+2];
                                imageDisplayArray [counter2][counter3*3+1] = imageDisplayArray [counter2][counter3*3+2];
                                imageDisplayArray [counter2][counter3*3+2] = imageDisplayArray [counter2][counter3*3+2];
                            }
                            else if (mergeRStatusHold == 1 && mergeGStatusHold == 1 && mergeBStatusHold == 0){
                                tempValue1 = (int)((imageDisplayArray [counter2][counter3*3]+imageDisplayArray [counter2][counter3*3+1])/(double)2);
                                imageDisplayArray [counter2][counter3*3] = tempValue1;
                                imageDisplayArray [counter2][counter3*3+1] = tempValue1;
                                imageDisplayArray [counter2][counter3*3+2] = tempValue1;
                            }
                            else if (mergeRStatusHold == 0 && mergeGStatusHold == 1 && mergeBStatusHold == 1){
                                tempValue1 = (int)((imageDisplayArray [counter2][counter3*3+1]+imageDisplayArray [counter2][counter3*3+2])/(double)2);
                                imageDisplayArray [counter2][counter3*3] = tempValue1;
                                imageDisplayArray [counter2][counter3*3+1] = tempValue1;
                                imageDisplayArray [counter2][counter3*3+2] = tempValue1;
                            }
                            else if (mergeRStatusHold == 1 && mergeGStatusHold == 0 && mergeBStatusHold == 1){
                                tempValue1 = (int)((imageDisplayArray [counter2][counter3*3]+imageDisplayArray [counter2][counter3*3+2])/(double)2);
                                imageDisplayArray [counter2][counter3*3] = tempValue1;
                                imageDisplayArray [counter2][counter3*3+1] = tempValue1;
                                imageDisplayArray [counter2][counter3*3+2] = tempValue1;
                            }
                            else if (mergeRStatusHold == 1 && mergeGStatusHold == 1 && mergeBStatusHold == 1){
                                tempValue1 = (int)((imageDisplayArray [counter2][counter3*3]+imageDisplayArray [counter2][counter3*3+1]+imageDisplayArray [counter2][counter3*3+2])/(double)3);
                                imageDisplayArray [counter2][counter3*3] = tempValue1;
                                imageDisplayArray [counter2][counter3*3+1] = tempValue1;
                                imageDisplayArray [counter2][counter3*3+2] = tempValue1;
                            }
                        }
                    }
                    
                    int imageSetSize = 0;
                    int counterIncrement = 0;
                    
                    if (stitchedImageDimension <= 1000){
                        imageSetSize = stitchedImageDimension;
                        counterIncrement = 1;
                    }
                    else if (stitchedImageDimension <= 4000){
                        imageSetSize = stitchedImageDimension/2;
                        counterIncrement = 2;
                    }
                    else{
                        
                        imageSetSize = stitchedImageDimension/4;
                        counterIncrement = 4;
                    }
                    
                    if (resolutionStatusHold == 1){
                        imageSetSize = stitchedImageDimension;
                        counterIncrement = 1;
                    }
                    
                    NSBitmapImageRep *bitmapReps;
                    bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageSetSize pixelsHigh:imageSetSize bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageSetSize*4 bitsPerPixel:32];
                    
                    unsigned char *bitmapData = [bitmapReps bitmapData];
                    
                    for (int counter1 = 0; counter1 < stitchedImageDimension; counter1 = counter1+counterIncrement){
                        for (int counter2 = 0; counter2 < stitchedImageDimension*3; counter2 = counter2+counterIncrement*3){
                            *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2];
                            *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2+1];
                            *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2+2];
                            *bitmapData++ = 0;
                        }
                    }
                    
                    movieImage = [[NSImage alloc] initWithSize:NSMakeSize(stitchedImageDimension, stitchedImageDimension)];
                    [movieImage addRepresentation:bitmapReps];
                    
                    [self setNeedsDisplay:YES];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Applicable Only To Color Images"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Mode Must Be Set To 'Extract'"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        
        if (keyCode == 1){ //-----S-----
            /*
             S: Blur
             Mode has to be Extract.
             Works only for color image
             Blur works for Extracted image.
             When F or V is performed, Blur is cancelled. To apply blur, do it again.
             Blur can be repeated times.
             In the Brightness mode, blue will be performed for R G B separately.
             When Blur cut off is set, cutoff value will be apply. Same cut off value will be applied for R G B. Value below the cut off is 0.
             */
            
            if (colorSelectStatusHold == 1){
                if (photoMetricsHold == 2){
                    double bitGaussianR = 0;
                    double bitGaussianG = 0;
                    double bitGaussianB = 0;
                    
                    double maskMatrix [5][5] = {{0.0035, 0.0145, 0.0256, 0.0145, 0.0035}, {0.0145, 0.0586, 0.0952, 0.0556, 0.0145}, {0.0256, 0.0952, 0.1501, 0.0952, 0.0256}, {0.0145, 0.0586, 0.0952, 0.0586, 0.0145}, {0.0035, 0.0145, 0.0256, 0.0145, 0.0035}};
                    
                    int **gaussianImageR = new int *[stitchedImageDimension+1];
                    int **gaussianImageG = new int *[stitchedImageDimension+1];
                    int **gaussianImageB = new int *[stitchedImageDimension+1];
                    
                    for (int counter2 = 0; counter2 < stitchedImageDimension+1; counter2++){
                        gaussianImageR [counter2] = new int [stitchedImageDimension*3+1];
                        gaussianImageG [counter2] = new int [stitchedImageDimension*3+1];
                        gaussianImageB [counter2] = new int [stitchedImageDimension*3+1];
                    }
                    
                    //-----Apply Gaussian blur-----
                    for (int counter2 = 0; counter2 < stitchedImageDimension; counter2++){
                        for (int counter3 = 0; counter3 < stitchedImageDimension; counter3++){
                            bitGaussianR = 0;
                            bitGaussianG = 0;
                            bitGaussianB = 0;
                            
                            for (int counter4 = -2; counter4 <= 2; counter4++){
                                for (int counter5 = -2; counter5 <= 2; counter5++){
                                    if (counter2+counter4 >= stitchedImageDimension || counter2+counter4 < 0 || counter3*3+counter5*3 >= stitchedImageDimension*3 || counter3*3+counter5*3 < 0){
                                        bitGaussianR = bitGaussianR+imageDisplayArray [counter2][counter3*3]*maskMatrix [counter4+2][counter5+2];
                                    }
                                    else bitGaussianR = bitGaussianR+imageDisplayArray [counter2+counter4][counter3*3+counter5*3]*maskMatrix [counter4+2][counter5+2];
                                    
                                    if (counter2+counter4 >= stitchedImageDimension || counter2+counter4 < 0 || counter3*3+1+counter5*3 >= stitchedImageDimension*3 || counter3*3+1+counter5*3 < 0){
                                        bitGaussianG = bitGaussianG+imageDisplayArray [counter2][counter3*3+1]*maskMatrix [counter4+2][counter5+2];
                                    }
                                    else bitGaussianG = bitGaussianG+imageDisplayArray [counter2+counter4][counter3*3+1+counter5*3]*maskMatrix [counter4+2][counter5+2];
                                    
                                    if (counter2+counter4 >= stitchedImageDimension || counter2+counter4 < 0 || counter3*3+2+counter5*3 >= stitchedImageDimension*3 || counter3*3+2+counter5*3 < 0){
                                        bitGaussianB = bitGaussianB+imageDisplayArray [counter2][counter3*3+2]*maskMatrix [counter4+2][counter5+2];
                                    }
                                    else bitGaussianB = bitGaussianB+imageDisplayArray [counter2+counter4][counter3*3+2+counter5*3]*maskMatrix [counter4+2][counter5+2];
                                }
                            }
                            
                            if (blurCutHold == 0){
                                gaussianImageR [counter2][counter3] = (int)bitGaussianR;
                                gaussianImageG [counter2][counter3] = (int)bitGaussianG;
                                gaussianImageB [counter2][counter3] = (int)bitGaussianB;
                            }
                            else if (blurCutHold == 1){
                                if (bitGaussianR != 0 || bitGaussianG != 0 || bitGaussianB != 0){
                                    if (levelHoldBlur < bitGaussianR || levelHoldBlur < bitGaussianG || levelHoldBlur < bitGaussianB){
                                        gaussianImageR [counter2][counter3] = (int)bitGaussianR;
                                        gaussianImageG [counter2][counter3] = (int)bitGaussianG;
                                        gaussianImageB [counter2][counter3] = (int)bitGaussianB;
                                    }
                                    else{
                                        
                                        gaussianImageR [counter2][counter3] = 0;
                                        gaussianImageG [counter2][counter3] = 0;
                                        gaussianImageB [counter2][counter3] = 0;
                                    }
                                }
                                else{
                                    
                                    gaussianImageR [counter2][counter3] = 0;
                                    gaussianImageG [counter2][counter3] = 0;
                                    gaussianImageB [counter2][counter3] = 0;
                                }
                            }
                        }
                    }
                    
                    for (int counter2 = 0; counter2 < stitchedImageDimension; counter2++){
                        for (int counter3 = 0; counter3 < stitchedImageDimension; counter3++){
                            imageDisplayArray [counter2][counter3*3] = gaussianImageR [counter2][counter3];
                            imageDisplayArray [counter2][counter3*3+1] = gaussianImageG [counter2][counter3];
                            imageDisplayArray [counter2][counter3*3+2] = gaussianImageB [counter2][counter3];
                        }
                    }
                    
                    for (int counter2 = 0; counter2 < stitchedImageDimension+1; counter2++){
                        delete [] gaussianImageR [counter2];
                        delete [] gaussianImageG [counter2];
                        delete [] gaussianImageB [counter2];
                    }
                    
                    delete [] gaussianImageR;
                    delete [] gaussianImageG;
                    delete [] gaussianImageB;
                    
                    int imageSetSize = 0;
                    int counterIncrement = 0;
                    
                    if (stitchedImageDimension <= 1000){
                        imageSetSize = stitchedImageDimension;
                        counterIncrement = 1;
                    }
                    else if (stitchedImageDimension <= 4000){
                        imageSetSize = stitchedImageDimension/2;
                        counterIncrement = 2;
                    }
                    else{
                        
                        imageSetSize = stitchedImageDimension/4;
                        counterIncrement = 4;
                    }
                    
                    if (resolutionStatusHold == 1){
                        imageSetSize = stitchedImageDimension;
                        counterIncrement = 1;
                    }
                    
                    NSBitmapImageRep *bitmapReps;
                    bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageSetSize pixelsHigh:imageSetSize bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageSetSize*4 bitsPerPixel:32];
                    
                    unsigned char *bitmapData = [bitmapReps bitmapData];
                    
                    for (int counter1 = 0; counter1 < stitchedImageDimension; counter1 = counter1+counterIncrement){
                        for (int counter2 = 0; counter2 < stitchedImageDimension*3; counter2 = counter2+counterIncrement*3){
                            *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2];
                            *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2+1];
                            *bitmapData++ = (unsigned char)imageDisplayArray [counter1][counter2+2];
                            *bitmapData++ = 0;
                        }
                    }
                    
                    movieImage = [[NSImage alloc] initWithSize:NSMakeSize(stitchedImageDimension, stitchedImageDimension)];
                    [movieImage addRepresentation:bitmapReps];
                    
                    [self setNeedsDisplay:YES];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Only for color image"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Mode Must Be Set To 'Extract'"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        
        if (keyCode == 11){ //-----B-----
            if (contrastLockRelease == 2){
                contrastLockRelease = 3;
            }
        }
        
        //-----Magnification Magnify-----
        if (keyCode == 125){
            if (magnificationDisplay >= 10 && magnificationDisplay <= 490){
                if (magnificationDisplay-10 < 10) magnificationDisplay = 10;
                else magnificationDisplay = magnificationDisplay-10;
                
                xPositionAdjustDisplay = -1*(stitchedImageDimension/(double)(magnificationDisplay*0.1)-stitchedImageDimension)/(double)2;
                yPositionAdjustDisplay = -1*(stitchedImageDimension/(double)(magnificationDisplay*0.1)-stitchedImageDimension)/(double)2;
            }
            else if (magnificationDisplay < 10) magnificationDisplay = 10;
            
            [self setNeedsDisplay:YES];
        }
        
        //-----Magnification Reduction-----
        if (keyCode == 126){
            if (magnificationDisplay >= 10 && magnificationDisplay <= 490){
                if (magnificationDisplay+10 > 490) magnificationDisplay = 490;
                else magnificationDisplay = magnificationDisplay+10;
                
                xPositionAdjustDisplay = (stitchedImageDimension-stitchedImageDimension/(double)(magnificationDisplay*0.1))/(double)2;
                yPositionAdjustDisplay = (stitchedImageDimension-stitchedImageDimension/(double)(magnificationDisplay*0.1))/(double)2;
            }
            else if (magnificationDisplay > 490) magnificationDisplay = 490;
            
            [self setNeedsDisplay:YES];
        }
    }
}

-(void)drawRect:(NSRect)rect {
    NSRect srcRect;
    
    srcRect.origin.x = xPositionDisplay+xPositionAdjustDisplay+xPositionMoveDisplay;
    srcRect.origin.y = yPositionDisplay+yPositionAdjustDisplay+yPositionMoveDisplay;
    srcRect.size.width = stitchedImageDimension/(double)(magnificationDisplay*0.1);
    srcRect.size.height = stitchedImageDimension/(double)(magnificationDisplay*0.1);
    
    [movieImage drawInRect:rect fromRect:srcRect operation:NSCompositingOperationCopy fraction:1.0f];
    
    if (mouseDragFlag == 0 && imageDataHoldStatus == 1){
        double xPositionAdj = xPositionAdjustDisplay+xPositionDisplay;
        double yPositionAdj = yPositionAdjustDisplay+yPositionDisplay;
        double xCalValue = 1/(double)windowWidthDisplay*magnificationDisplay*0.1;
        double yCalValue = 1/(double)windowHeightDisplay*magnificationDisplay*0.1;
        double magnificationFont = magnificationDisplay*0.3*5.0*4992/(double)stitchedImageDimension;
        
        NSPoint pointA;
        NSAttributedString *attrStrA;
        NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
        [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
        [attributesA setObject:[NSFont systemFontOfSize:magnificationFont] forKey:NSFontAttributeName];
        
        NSString *fovNumberDisplay;
        string extension;
        
        for (int counter1 = 0; counter1 < fileListCount; counter1++){
            fovNumberDisplay = [NSString stringWithFormat:@"%d", counter1+1];
            attrStrA = [[NSAttributedString alloc] initWithString:fovNumberDisplay attributes:attributesA];
            pointA.x = (xyPositionWritingData [counter1*3+2]+imageDimensionW/2-xPositionAdj)*xCalValue;
            pointA.y = ((stitchedImageDimension-(xyPositionWritingData [counter1*3+1]+imageDimensionH/2))-yPositionAdj)*yCalValue;
            [attrStrA drawAtPoint:pointA];
        }
        
        [attributesA setObject:[NSFont systemFontOfSize:12] forKey:NSFontAttributeName];
        [attributesA setObject:[NSColor blackColor] forKey: NSBackgroundColorAttributeName];
        
        if ((imageFLStatus == "Free" && colorAdjustFreeLock == 0) || imageFLStatus == "Lock"){
            extension = "Lock/Free: "+imageFLStatus;
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(extension.c_str()) attributes:attributesA];
            pointA.x = 5;
            pointA.y = 580;
            [attrStrA drawAtPoint:pointA];
        }
        else{
            
            extension = "Lock/Free: Fix";
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(extension.c_str()) attributes:attributesA];
            pointA.x = 5;
            pointA.y = 580;
            [attrStrA drawAtPoint:pointA];
        }
        
        if (imageFLStatus == "Free"){
            extension = "FOV no: "+to_string(processingFovNo);
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(extension.c_str()) attributes:attributesA];
            pointA.x = 130;
            pointA.y = 580;
            [attrStrA drawAtPoint:pointA];
        }
        
        if (resolutionStatusHold == 1){
            extension = "Resolution: O";
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(extension.c_str()) attributes:attributesA];
            pointA.x = 230;
            pointA.y = 580;
            [attrStrA drawAtPoint:pointA];
        }
        else if (resolutionStatusHold == 0){
            extension = "Resolution: R";
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(extension.c_str()) attributes:attributesA];
            pointA.x = 230;
            pointA.y = 580;
            [attrStrA drawAtPoint:pointA];
        }
        
        if (colorPickStatusHold == 0){
            extension = "Color pick: Off";
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(extension.c_str()) attributes:attributesA];
            pointA.x = 350;
            pointA.y = 580;
            [attrStrA drawAtPoint:pointA];
        }
        else if (colorPickStatusHold == 1){
            extension = "Color pick: On";
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(extension.c_str()) attributes:attributesA];
            pointA.x = 350;
            pointA.y = 580;
            [attrStrA drawAtPoint:pointA];
        }
        
        if (listModeStatusHold == 1){
            extension = "List Mode";
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(extension.c_str()) attributes:attributesA];
            pointA.x = 470;
            pointA.y = 580;
            [attrStrA drawAtPoint:pointA];
            
            int valueTempR = 0;
            int valueTempG = 0;
            int valueTempB = 0;
            int fovTemp = 0;
            string fovTempString;
            
            for (int counter1 = 0; counter1 < listDataCount; counter1++){
                [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
                
                if (counter1 == 0){
                    extension = "Original";
                    
                    attrStrA = [[NSAttributedString alloc] initWithString:@(extension.c_str()) attributes:attributesA];
                    pointA.x = 5;
                    pointA.y = 550;
                    [attrStrA drawAtPoint:pointA];
                }
                else if (counter1 == clickList){
                    [attributesA setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
                    
                    valueTempR = (int)listDataHold [counter1*15+8];
                    valueTempG = (int)listDataHold [counter1*15+10];
                    valueTempB = (int)listDataHold [counter1*15+12];
                    fovTemp = (int)listDataHold [counter1*15+14];
                    
                    if (fovTemp == 0) fovTempString = "A";
                    else fovTempString = to_string(fovTemp);
                    
                    extension = to_string(counter1)+". R: "+to_string(valueTempR)+" G: "+to_string(valueTempG)+" B: "+to_string(valueTempB)+" F: "+fovTempString;
                    
                    attrStrA = [[NSAttributedString alloc] initWithString:@(extension.c_str()) attributes:attributesA];
                    pointA.x = 5;
                    pointA.y = 550-counter1*20;
                    [attrStrA drawAtPoint:pointA];
                }
                else{
                    
                    valueTempR = (int)listDataHold [counter1*15+8];
                    valueTempG = (int)listDataHold [counter1*15+10];
                    valueTempB = (int)listDataHold [counter1*15+12];
                    fovTemp = (int)listDataHold [counter1*15+14];
                    
                    if (fovTemp == 0) fovTempString = "A";
                    else fovTempString = to_string(fovTemp);
                    
                    extension = to_string(counter1)+". R: "+to_string(valueTempR)+" G: "+to_string(valueTempG)+" B: "+to_string(valueTempB)+" F: "+fovTempString;
                    
                    attrStrA = [[NSAttributedString alloc] initWithString:@(extension.c_str()) attributes:attributesA];
                    pointA.x = 5;
                    pointA.y = 550-counter1*20;
                    [attrStrA drawAtPoint:pointA];
                }
            }
        }
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToMovieDisplay object:nil];
}

@end
