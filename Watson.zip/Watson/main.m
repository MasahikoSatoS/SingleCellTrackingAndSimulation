//
//  main.m
//  Watson
//
//  Created by Masahiko Sato on 14/09/29.
//  Copyright Masahiko Sato 2014. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[]){
    return NSApplicationMain(argc, (const char **) argv);
}
