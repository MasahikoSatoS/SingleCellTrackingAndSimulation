//
//  MovieDisplay.h
//  Watson
//
//  Created by Masahiko Sato on 2014-09-29.
//  Copyright 2014 Masahiko Sato. All rights reserved.
//
//

#ifndef MOVIEDISPLAY_H
#define MOVIEDISPLAY_H
#import "Controller.h"
#endif

@interface MovieDisplay : NSView {
    int magnificationDisplay; //Image magnification
    double windowWidthDisplay; //Window size X
    double windowHeightDisplay; //Window size Y
    double xPositionDisplay; //X Position
    double yPositionDisplay; //Y Position
    
    int imageFirstLoadFlagDisplay; //Set when the first image is displayed
    int clickList; //Clicked list
    
    int mouseDragFlag; //Display operation
    int mouseDownFlag; //Display operation
    int xStartHold; //X Start position
    int yStartHold; //Y Start position
    int colorAdjustFreeLock; //Color adjust
    int resolutionStatusHold; //Resolution
    int currentFOVNoHold; //Current FOV no
    
    double xPositionAdjustDisplay; //Display operation
    double yPositionAdjustDisplay; //Display operation
    double xPointDownDisplay; //Display operation
    double yPointDownDisplay; //Display operation
    double xPositionMoveDisplay; //Display operation
    double yPositionMoveDisplay; //Display operation
    double xPointDragDisplay; //Display operation
    double yPointDragDisplay; //Display operation
    
    IBOutlet NSImage *movieImage;
}

-(void)mouseDown:(NSEvent *)event;
-(void)mouseUp:(NSEvent *)event;
-(void)mouseDraged:(NSEvent *)event;
-(void)keyDown:(NSEvent *)event;
-(BOOL)acceptsFirstResponder;
-(void)dealloc;

@end
