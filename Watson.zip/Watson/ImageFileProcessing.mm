//
//  ImageFileProcessing.m
//  Watson
//
//  Created by Masahiko Sato on 2019-09-25.
//

#import "ImageFileProcessing.h"

@implementation ImageFileProcessing

-(IBAction)fileLoadStart:(id)sender{
    if (copyProgressFlag == 0){
        NSString *inputDataCheck = [inputDataDisplay stringValue];
        string inputData = [[inputDataDisplay stringValue] UTF8String];
        
        ascIIconversion = [[ASCIIconversion alloc] init];
        int checkResults = [ascIIconversion nameCheck:inputDataCheck];
        
        if (checkResults == 0){
            if (inputData.length() < 4 || inputData.length() > 15) checkResults = 1;
        }
        
        if (checkResults == 0){
            NSOpenPanel *openDlg = [NSOpenPanel openPanel];
            [openDlg setCanChooseFiles:NO];
            [openDlg setCanChooseDirectories:YES];
            [openDlg setCanCreateDirectories:YES];
            
            if ([openDlg runModal] == NSModalResponseOK){
                NSArray *files = [openDlg URLs];
                NSString *fileName = [[files objectAtIndex:0] absoluteString];
                
                string directoryPathExtract = [fileName UTF8String];
                
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
                    copyProgressFlag = 1;
                    progressTiming = 6;
                    
                    do usleep(10);
                    while (progressTiming == 6);
                    
                    int findString1 = (int)directoryPathExtract.find("/Users/");
                    if (findString1 == -1) findString1 = (int)directoryPathExtract.find("/Volumes/");
                    
                    unsigned long directoryLength = directoryPathExtract.length();
                    string extractedID = directoryPathExtract.substr((unsigned long)findString1, directoryLength-(unsigned long)findString1-1);
                    string extractedID2;
                    
                    int terminationFlag = 0;
                    
                    do{
                        
                        terminationFlag = 1;
                        
                        if ((int)extractedID.find("%20") != -1){
                            extractedID2 = extractedID.substr(0, extractedID.find("%20"));
                            extractedID = extractedID.substr(extractedID.find("%20")+3);
                            extractedID = extractedID2+" "+extractedID;
                        }
                        else terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                    
                    string directoryPath3 = extractedID;
                    string entry;
                    
                    DIR *dir;
                    struct dirent *dent;
                    
                    string *fileList2 = new string [100];
                    int fileListCount2 = 0;
                    int fileListLimit2 = 100;
                    
                    dir = opendir(directoryPath3.c_str());
                    
                    if (dir != NULL){
                        while((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                if ((int)entry.find(".TIFF") != -1 || (int)entry.find(".Tiff") != -1 || (int)entry.find(".tiff") != -1 || (int)entry.find(".TIF") != -1 || (int)entry.find(".Tif") != -1 || (int)entry.find(".tif") != -1){
                                    
                                    if (fileListLimit2 < fileListCount2+10){
                                        string *arrayUpDate = new string [fileListCount2+10];
                                        
                                        for (int counter1 = 0; counter1 < fileListCount2; counter1++) arrayUpDate [counter1] = fileList2 [counter1];
                                        
                                        delete [] fileList2;
                                        fileList2 = new string [fileListLimit2+500];
                                        fileListLimit2 = fileListLimit2+500;
                                        
                                        for (int counter1 = 0; counter1 < fileListCount2; counter1++) fileList2 [counter1] = arrayUpDate [counter1];
                                        delete [] arrayUpDate;
                                    }
                                    
                                    fileList2 [fileListCount2] = entry, fileListCount2++;
                                }
                            }
                        }
                        
                        closedir(dir);
                        
                        //-----Directory Sort-----
                        NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                        
                        for (int counter1 = 0; counter1 < fileListCount2; counter1++){
                            [unsortedArray addObject:@(fileList2 [counter1].c_str())];
                        }
                        
                        [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                        
                        for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                            fileList2 [counter1] = [unsortedArray [counter1] UTF8String];
                        }
                        
                        string *fileList3 = new string [fileListCount2+10];
                        int fileListCount3 = 0;
                        
                        for (int counter1 = 0; counter1 < fileListCount2; counter1++){
                            if (((int)fileList2 [counter1].find(".T") != -1 && (int)fileList2 [counter1].find(".T")-4 >= 4 && atoi(fileList2 [counter1].substr(fileList2 [counter1].find(".T")-4, 4).c_str()) > 0) || ((int)fileList2 [counter1].find(".t") != -1 && (int)fileList2 [counter1].find(".t")-4 >= 4 && atoi(fileList2 [counter1].substr(fileList2 [counter1].find(".t")-4, 4).c_str()) > 0)){
                                fileList3 [fileListCount3] = fileList2 [counter1], fileListCount3++;
                            }
                        }
                        
                        if (fileListCount3 != 0){
                            string *fileNameList = new string [fileListCount3+10];
                            string matchString;
                            
                            int fileNameListEntryCount = 0;
                            int matchFind = 0;
                            
                            for (int counter1 = 0; counter1 < fileListCount3; counter1++){
                                matchFind = 0;
                                
                                for (int counter2 = 0; counter2 < fileNameListEntryCount; counter2++){
                                    matchString = "";
                                    
                                    if ((int)fileList3 [counter1].find(".T") != -1){
                                        matchString = fileList3 [counter1].substr(0, fileList3 [counter1].find(".T")-4);
                                    }
                                    else if ((int)fileList3 [counter1].find(".t") != -1){
                                        matchString = fileList3 [counter1].substr(0, fileList3 [counter1].find(".t")-4);
                                    }
                                    
                                    if (matchString == fileNameList [counter2]){
                                        matchFind = 1;
                                        break;
                                    }
                                }
                                
                                if (matchFind == 0){
                                    if ((int)fileList3 [counter1].find(".T") != -1){
                                        fileNameList [fileNameListEntryCount] = fileList3 [counter1].substr(0, fileList3 [counter1].find(".T")-4), fileNameListEntryCount++;
                                    }
                                    else if ((int)fileList3 [counter1].find(".t") != -1){
                                        fileNameList [fileNameListEntryCount] = fileList3 [counter1].substr(0, fileList3 [counter1].find(".t")-4), fileNameListEntryCount++;
                                    }
                                }
                            }
                            
                            string imageDisplayListPath5 = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files";
                            
                            int sameNameFind = 0;
                            
                            dir = opendir(imageDisplayListPath5.c_str());
                            
                            if (dir != NULL){
                                while((dent = readdir(dir))){
                                    entry = dent -> d_name;
                                    
                                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                        if ((int)entry.find(inputData) != -1) sameNameFind = 1;
                                    }
                                }
                                
                                closedir(dir);
                            }
                            
                            if (sameNameFind == 0){
                                string imageDisplayListPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files/"+inputData+"_ProductsH";
                                mkdir(imageDisplayListPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                
                                string imageDisplayListPath2;
                                string imageDisplayListPath3;
                                string imageDisplayListPathOriginal;
                                string imageDisplayListPathCurrent;
                                string sourceListPath;
                                string countEntryString;
                                
                                int countEntry = 0;
                                int fileNoCount = 0;
                                long sizeForCopy = 0;
                                
                                struct stat sizeOfFile;
                                
                                for (int counter1 = 0; counter1 < fileNameListEntryCount; counter1++){
                                    imageDisplayListPath2 = imageDisplayListPath+"/"+fileNameList [counter1]+"_Capture";
                                    mkdir(imageDisplayListPath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                    
                                    fileNoCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < fileListCount3; counter2++){
                                        if ((int)fileList3 [counter2].find(fileNameList [counter1]) != -1) fileNoCount++;
                                    }
                                    
                                    countEntry = 1;
                                    
                                    for (int counter2 = 0; counter2 < fileListCount3; counter2++){
                                        imageDisplayListPathOriginal = imageDisplayListPath2+"/"+"Original";
                                        mkdir(imageDisplayListPathOriginal.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                        
                                        imageDisplayListPathCurrent = imageDisplayListPath2+"/"+"Current";
                                        mkdir(imageDisplayListPathCurrent.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                        
                                        if ((int)fileList3 [counter2].find(fileNameList [counter1]) != -1){
                                            countEntryString = to_string (countEntry);
                                            
                                            if (countEntryString.length() == 1) countEntryString = "000"+countEntryString;
                                            else if (countEntryString.length() == 2) countEntryString = "00"+countEntryString;
                                            else if (countEntryString.length() == 3) countEntryString = "0"+countEntryString;
                                            
                                            sourceListPath = directoryPath3+"/"+fileList3 [counter2];
                                            imageDisplayListPath3 = imageDisplayListPathOriginal+"/"+fileNameList [counter1]+"-"+countEntryString+".tif";
                                            
                                            if (stat(sourceListPath.c_str(), &sizeOfFile) == 0){
                                                sizeForCopy = sizeOfFile.st_size;
                                                
                                                ifstream infile (sourceListPath.c_str(), ifstream::binary);
                                                ofstream outfile (imageDisplayListPath3.c_str(), ofstream::binary);
                                                
                                                char *buffer = new char[sizeForCopy];
                                                infile.read (buffer, sizeForCopy);
                                                outfile.write (buffer, sizeForCopy);
                                                delete [] buffer;
                                                
                                                outfile.close();
                                                infile.close();
                                            }
                                            
                                            imageDisplayListPath3 = imageDisplayListPathCurrent+"/"+fileNameList [counter1]+"-"+countEntryString+".tif";
                                            
                                            if (stat(sourceListPath.c_str(), &sizeOfFile) == 0){
                                                sizeForCopy = sizeOfFile.st_size;
                                                
                                                ifstream infile (sourceListPath.c_str(), ifstream::binary);
                                                ofstream outfile (imageDisplayListPath3.c_str(), ofstream::binary);
                                                
                                                char *buffer = new char[sizeForCopy];
                                                infile.read (buffer, sizeForCopy);
                                                outfile.write (buffer, sizeForCopy);
                                                delete [] buffer;
                                                
                                                outfile.close();
                                                infile.close();
                                            }
                                            
                                            countEntry++;
                                        }
                                    }
                                    
                                    if (tableListHoldCount*85+100 > tableListHoldLimit){
                                        string *arrayUpDate = new string [tableListHoldCount*85+10];
                                        
                                        for (int counter3 = 0; counter3 < tableListHoldCount*85; counter3++) arrayUpDate [counter3] = tableListHold [counter3];
                                        delete [] tableListHold;
                                        tableListHold = new string [tableListHoldLimit+1000];
                                        tableListHoldLimit = tableListHoldLimit+1000;
                                        
                                        for (int counter3 = 0; counter3 < tableListHoldCount*85; counter3++) tableListHold [counter3] = arrayUpDate [counter3];
                                        delete [] arrayUpDate;
                                    }
                                    
                                    tableListHold [tableListHoldCount*85] = "0";
                                    tableListHold [tableListHoldCount*85+1] = inputData;
                                    tableListHold [tableListHoldCount*85+2] = fileNameList [counter1];
                                    tableListHold [tableListHoldCount*85+3] = to_string(fileNoCount);
                                    
                                    for (int counter3 = 0; counter3 < 81; counter3++){
                                        tableListHold [tableListHoldCount*85+counter3+4] = "nil";
                                    }
                                    
                                    tableListHoldCount++;
                                }
                                
                                ofstream oin;
                                
                                //For (int counterA = 0; counterA < tableListHoldCount*85; counterA++){
                                //    cout<<tableListHold [counterA]<<" tableListHold"<<endl;
                                //}
                                
                                oin.open(tableListPath.c_str(), ios::out);
                                
                                for (int counter1 = 0; counter1 < tableListHoldCount*85; counter1++){
                                    oin<<tableListHold [counter1]<<endl;
                                }
                                
                                oin.close();
                                
                                initialArraySet = 1;
                                tableDisplayCall = 1;
                                productDisplayCall = 1;
                            }
                            else warningSet = 2;
                            
                            delete [] fileNameList;
                        }
                        else warningSet = 1;
                        
                        delete [] fileList3;
                    }
                    
                    delete [] fileList2;
                    
                    progressTiming = 8;
                    copyProgressFlag = 0;
                });
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Incorrect Name Format"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)startProcess:(id)sender{
    //-----Saved file format is either RGB (without alpha, 8 bit) or Gray (8bit)-----
    if (copyProgressFlag == 0){
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
            copyProgressFlag = 1;
            progressTiming = 6;
            
            do usleep(10);
            while (progressTiming == 6);
            
            if (currentImageName != ""){
                string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
                mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Histo_Images";
                mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                DIR *dir;
                struct dirent *dent;
                
                string entry;
                string extractString;
                int maxEntryNo = 0;
                
                dir = opendir(resultSavePath2.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("Histo_Images") != -1){
                            extractString = entry.substr(entry.find("HI")+2, entry.find(".tif")-entry.find("HI")-2);
                            
                            if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                        }
                    }
                    
                    closedir(dir);
                }
                
                maxEntryNo++;
                
                fileSavePathHold = resultSavePath2+"/Histo_Images-HI"+to_string(maxEntryNo)+"-"+currentImageName+".tif";
                
                double xPosition = 0;
                double yPosition = 0;
                
                int mode = 0;
                
                arrayImageFileSave = new int *[stitchedImageDimension+1];
                
                for (int counter5 = 0; counter5 < stitchedImageDimension+1; counter5++){
                    arrayImageFileSave [counter5] = new int [stitchedImageDimension*3+1];
                }
                
                for (int counter5 = 0; counter5 < stitchedImageDimension; counter5++){
                    for (int counter6 = 0; counter6 < stitchedImageDimension; counter6++){
                        if (photoMetricsHold == 1){
                            arrayImageFileSave [counter5][counter6] = imageDisplayArray [counter5][counter6];
                        }
                        else if (photoMetricsHold == 2){
                            arrayImageFileSave [counter5][counter6*3] = imageDisplayArray [counter5][counter6*3];
                            arrayImageFileSave [counter5][counter6*3+1] = imageDisplayArray [counter5][counter6*3+1];
                            arrayImageFileSave [counter5][counter6*3+2] = imageDisplayArray [counter5][counter6*3+2];
                        }
                    }
                }
                
                if (xPosition == -1) xPosition = 100;
                if (yPosition == -1) yPosition = 100;
                
                self->singleTiffSave = [[SingleTiffSave alloc] init];
                [self->singleTiffSave singleTiffLayerSave:stitchedImageDimension:stitchedImageDimension:imageBitHold:photoMetricsHold:samplePerPixHold:xPosition:yPosition:mode:(unsigned long)mode];
                
                for (int counter3 = 0; counter3 < stitchedImageDimension+1; counter3++){
                    delete [] arrayImageFileSave [counter3];
                }
                
                delete [] arrayImageFileSave;
                
                ofstream oin;
                
                if (listDataCount > 1){
                    string imagingParameterPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/ImageDataList";
                    string *imageDataListTemp = new string [10000];
                    
                    int imageDataListTempCount = 0;
                    int imageDataListTempLimit = 10000;
                    int terminationFlag = 0;
                    
                    ifstream fin;
                    
                    string getString;
                    
                    fin.open(imagingParameterPath.c_str(),ios::in);
                    
                    if (fin.is_open()){
                        do{
                            
                            terminationFlag = 1;
                            
                            if (imageDataListTempCount*422+450 > imageDataListTempLimit){
                                string *arrayUpDate = new string [imageDataListTempCount*422+10];
                                
                                for (int counter1 = 0; counter1 < imageDataListTempCount*422; counter1++) arrayUpDate [counter1] = imageDataListTemp [counter1];
                                delete [] imageDataListTemp;
                                imageDataListTemp = new string [imageDataListTempLimit+10000];
                                imageDataListTempLimit = imageDataListTempLimit+10000;
                                
                                for (int counter1 = 0; counter1 < imageDataListTempCount*422; counter1++) imageDataListTemp [counter1] = arrayUpDate [counter1];
                                delete [] arrayUpDate;
                            }
                            
                            for (int counter1 = 0; counter1 < 422; counter1++){
                                getline(fin, getString), imageDataListTemp [imageDataListTempCount*422+counter1] = getString;
                                
                                if (getString == ""){
                                    terminationFlag = 0;
                                    break;
                                }
                            }
                            
                            if (terminationFlag != 0) imageDataListTempCount++;
                            
                        } while (terminationFlag == 1);
                        
                        fin.close();
                    }
                    
                    string *imageDataListTemp2 = new string [(imageDataListTempCount+1)*422+10];
                    int imageDataListTempCount2 = 0;
                    
                    for (int counter1 = 0; counter1 < imageDataListTempCount; counter1++){
                        if (imageDataListTemp [counter1*422] != analysisNameHold || imageDataListTemp [counter1*422+1] != treatNameHold){
                            for (int counter2 = 0; counter2 < 422; counter2++){
                                imageDataListTemp2 [imageDataListTempCount2*422+counter2] = imageDataListTemp [counter1*422+counter2];
                            }
                            
                            imageDataListTempCount2++;
                        }
                    }
                    
                    imageDataListTemp2 [imageDataListTempCount2*422] = analysisNameHold;
                    imageDataListTemp2 [imageDataListTempCount2*422+1] = treatNameHold;
                    
                    for (int counter1 = 0; counter1 < listDataCount*15; counter1++){
                        imageDataListTemp2 [imageDataListTempCount2*422+counter1+2] = to_string(listDataHold [counter1]);
                    }
                    
                    for (int counter1 = listDataCount*15; counter1 < 422; counter1++){
                        imageDataListTemp2 [imageDataListTempCount2*422+counter1+2] = "A";
                    }
                    
                    imageDataListTempCount2++;
                    
                    oin.open(imagingParameterPath.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 < imageDataListTempCount2*422; counter1++){
                        oin<<imageDataListTemp2 [counter1]<<endl;
                    }
                    
                    oin.close();
                    
                    delete [] imageDataListTemp;
                    delete [] imageDataListTemp2;
                }
                
                if (listModeStatusHold == 0 && colorSelectStatusHold == 0){
                    //-----Current update-----
                    string imageDisplayListPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files/"+analysisNameHold+"_ProductsH/"+treatNameHold+"_Capture/Current";
                    
                    string *fileList2 = new string [100];
                    int fileListCount2 = 0;
                    int fileListLimit2 = 100;
                    
                    dir = opendir(imageDisplayListPath.c_str());
                    
                    if (dir != NULL){
                        while((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                if ((int)entry.find(".tif") != -1){
                                    if (fileListLimit2 < fileListCount2+10){
                                        string *arrayUpDate = new string [fileListCount2+10];
                                        
                                        for (int counter1 = 0; counter1 < fileListCount2; counter1++) arrayUpDate [counter1] = fileList2 [counter1];
                                        
                                        delete [] fileList2;
                                        fileList2 = new string [fileListLimit2+500];
                                        fileListLimit2 = fileListLimit2+500;
                                        
                                        for (int counter1 = 0; counter1 < fileListCount2; counter1++) fileList2 [counter1] = arrayUpDate [counter1];
                                        delete [] arrayUpDate;
                                    }
                                    
                                    fileList2 [fileListCount2] = entry, fileListCount2++;
                                }
                            }
                        }
                        
                        closedir(dir);
                        
                        //-----Directory Sort-----
                        NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                        
                        for (int counter1 = 0; counter1 < fileListCount2; counter1++){
                            [unsortedArray addObject:@(fileList2 [counter1].c_str())];
                        }
                        
                        [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                        
                        for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                            fileList2 [counter1] = [unsortedArray [counter1] UTF8String];
                        }
                        
                        for (int counter1 = 0; counter1 < fileListCount2; counter1++){
                            fileSavePathHold = imageDisplayListPath+"/"+fileList2 [counter1];
                            
                            arrayImageFileSave = new int *[imageDimensionH+20];
                            
                            if (photoMetricsHold == 1){
                                for (int counter2 = 0; counter2 < imageDimensionH+20; counter2++){
                                    arrayImageFileSave [counter2] = new int [imageDimensionW+20];
                                }
                            }
                            else if (photoMetricsHold == 2){
                                for (int counter2 = 0; counter2 < imageDimensionH+20; counter2++){
                                    arrayImageFileSave [counter2] = new int [imageDimensionW*3+20];
                                }
                            }
                            
                            if (photoMetricsHold == 1){
                                for (int counter3 = 0; counter3 < imageDimensionH; counter3++){
                                    for (int counter4 = 0; counter4 < imageDimensionW; counter4++){
                                        arrayImageFileSave [counter3][counter4] = arrayImageResults [counter1*imageDimensionH+counter3][counter4];
                                    }
                                }
                            }
                            else if (photoMetricsHold == 2){
                                for (int counter3 = 0; counter3 < imageDimensionH; counter3++){
                                    for (int counter4 = 0; counter4 < imageDimensionW*3; counter4 = counter4+3){
                                        arrayImageFileSave [counter3][counter4] = arrayImageResults [counter1*imageDimensionH+counter3][counter4];
                                        arrayImageFileSave [counter3][counter4+1] = arrayImageResults [counter1*imageDimensionH+counter3][counter4+1];
                                        arrayImageFileSave [counter3][counter4+2] = arrayImageResults [counter1*imageDimensionH+counter3][counter4+2];
                                    }
                                }
                            }
                            
                            xPosition = xyPositionWritingData [counter1*3+2];
                            yPosition = xyPositionWritingData [counter1*3+1];
                            
                            self->singleTiffSave = [[SingleTiffSave alloc] init];
                            [self->singleTiffSave singleTiffLayerSave:imageDimensionW:imageDimensionH:imageBitHold:photoMetricsHold:samplePerPixHold:xPosition:yPosition:mode:(unsigned long)mode];
                            
                            for (int counter2 = 0; counter2 < imageDimensionH+20; counter2++){
                                delete [] arrayImageFileSave  [counter2];
                            }
                            
                            delete [] arrayImageFileSave ;
                        }
                    }
                    
                    //-----Position Map Save-----
                    string imageDisplayMapPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files/"+analysisNameHold+"_ProductsH/"+treatNameHold+"_Capture/FOVMap.dat";
                    
                    oin.open(imageDisplayMapPath.c_str(),ios::out);
                    
                    if (photoMetricsHold == 1){
                        char *dataHold = new char [imageDimensionH*imageDimensionW*fileListCount2+10];
                        long indexCount = 0;
                        int dataTemp2 = 0;
                        int xPositionInt = 0;
                        int yPositionInt = 0;
                        
                        for (int counter1 = 0; counter1 < fileListCount2; counter1++){
                            xPositionInt = xyPositionWritingData [counter1*3+2];
                            yPositionInt = xyPositionWritingData [counter1*3+1];
                            
                            for (int counter2 = yPositionInt; counter2 < yPositionInt+imageDimensionH; counter2++){
                                for (int counter3 = xPositionInt; counter3 < xPositionInt+imageDimensionW; counter3++){
                                    dataTemp2 = imagePositionMap [counter2][counter3];
                                    
                                    if (counter1+1 == dataTemp2) dataHold [indexCount] = (char)dataTemp2, indexCount++;
                                    else dataHold [indexCount] = 0, indexCount++;
                                }
                            }
                        }
                        
                        ofstream outfile2 (imageDisplayMapPath.c_str(), ofstream::binary);
                        outfile2.write(dataHold, indexCount);
                        outfile2.close();
                        
                        delete [] dataHold;
                    }
                    else if (photoMetricsHold == 2){
                        char *dataHold = new char [imageDimensionH*imageDimensionW*fileListCount2+10];
                        long indexCount = 0;
                        int dataTemp2 = 0;
                        int xPositionInt = 0;
                        int yPositionInt = 0;
                        
                        for (int counter1 = 0; counter1 < fileListCount2; counter1++){
                            xPositionInt = xyPositionWritingData [counter1*3+2];
                            yPositionInt = xyPositionWritingData [counter1*3+1];
                            
                            for (int counter2 = yPositionInt; counter2 < yPositionInt+imageDimensionH; counter2++){
                                for (int counter3 = xPositionInt*3; counter3 < xPositionInt*3+imageDimensionW*3; counter3 = counter3+3){
                                    dataTemp2 = imagePositionMap [counter2][counter3];
                                    
                                    if (counter1+1 == dataTemp2) dataHold [indexCount] = (char)dataTemp2, indexCount++;
                                    else dataHold [indexCount] = 0, indexCount++;
                                }
                            }
                        }
                        
                        ofstream outfile2 (imageDisplayMapPath.c_str(), ofstream::binary);
                        outfile2.write(dataHold, indexCount);
                        outfile2.close();
                        
                        delete [] dataHold;
                    }
                    
                    oin.close();
                    
                    delete [] fileList2;
                }
            }
            
            progressTiming = 8;
            copyProgressFlag = 0;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        });
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)autoContrastSet:(id)sender{
    if (imageLoadStatus == 1 && copyProgressFlag == 0){
        unsigned long *totalValueList = new unsigned long [fileListCount*4+10];
        unsigned long *averageCount = new unsigned long [fileListCount*4+10];
        double *averageCal = new double [fileListCount*4+10];
        int *averageAddition = new int [fileListCount*7+10];
        double *multiply = new double [fileListCount*4+10];
        
        for (int counter2 = 0; counter2 < fileListCount*4+10; counter2++){
            totalValueList [counter2] = 0;
            averageCount [counter2] = 0;
            averageCal [counter2] = 0;
            multiply [counter2] = 0;
        }
        
        for (int counter2 = 0; counter2 < fileListCount*7+10; counter2++) averageAddition [counter2] = 0;
        
        if (photoMetricsHold == 1){
            int tempValue1 = 0;
            
            for (int counter2 = 0; counter2 < fileListCount; counter2++){
                for (int counter3 = 0; counter3 < imageDimensionH; counter3++){
                    for (int counter4 = 0; counter4 < imageDimensionW; counter4++){
                        totalValueList [counter2] = totalValueList [counter2]+(unsigned long)arrayImageResults [counter2*imageDimensionH+counter3][counter4];
                        averageCount [counter2]++;
                    }
                }
            }
            
            for (int counter2 = 0; counter2 < fileListCount; counter2++){
                averageCal [counter2] = (double)(totalValueList [counter2]/(double)averageCount [counter2]);
                averageAddition [counter2] = (int)(autoValueHold-averageCal [counter2]);
            }
            
            for (int counter2 = 0; counter2 < fileListCount; counter2++){
                for (int counter3 = 0; counter3 < imageDimensionH; counter3++){
                    for (int counter4 = 0; counter4 < imageDimensionW; counter4++){
                        if ((int)(arrayImageResults [counter2*imageDimensionH+counter3][counter4]+averageAddition [counter2]) > 255) tempValue1 = 255;
                        else if ((int)(arrayImageResults [counter2*imageDimensionH+counter3][counter4]+averageAddition [counter2]) < 0) tempValue1 = 0;
                        else tempValue1 = (int)(arrayImageResults [counter2*imageDimensionH+counter3][counter4]+averageAddition [counter2]);
                        
                        arrayImageResults [counter2*imageDimensionH+counter3][counter4] = tempValue1;
                        imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]+counter4] = tempValue1;
                    }
                }
            }
        }
        else if (photoMetricsHold == 2){
            int tempValue1 = 0;
            int tempValue2 = 0;
            int tempValue3 = 0;
            
            /*
             totalValueList: each FOV
             1.R: total
             2.G: total
             3.B: total
             4.RGB: total
             */
            
            for (int counter2 = 0; counter2 < fileListCount; counter2++){
                for (int counter3 = 0; counter3 < imageDimensionH; counter3++){
                    for (int counter4 = 0; counter4 < imageDimensionW*3; counter4 = counter4+3){
                        totalValueList [counter2*4] = totalValueList [counter2*4]+(unsigned long)arrayImageResults [counter2*imageDimensionH+counter3][counter4];
                        totalValueList [counter2*4+1] = totalValueList [counter2*4+1]+(unsigned long)arrayImageResults [counter2*imageDimensionH+counter3][counter4+1];
                        totalValueList [counter2*4+2] = totalValueList [counter2*4+2]+(unsigned long)arrayImageResults [counter2*imageDimensionH+counter3][counter4+2];
                        totalValueList [counter2*4+3] = totalValueList [counter2*4+3]+(unsigned long)arrayImageResults [counter2*imageDimensionH+counter3][counter4]+(unsigned long)arrayImageResults [counter2*imageDimensionH+counter3][counter4+1]+(unsigned long)arrayImageResults [counter2*imageDimensionH+counter3][counter4+2];
                        
                        averageCount [counter2*4]++;
                        averageCount [counter2*4+1]++;
                        averageCount [counter2*4+2]++;
                        averageCount [counter2*4+3] = averageCount [counter2*4+3]+3;
                    }
                }
            }
            
            /*
             averageCal: each FOV
             1.R: average
             2.G: average
             3.B: average
             4.RGB: average
             */
            
            for (int counter2 = 0; counter2 < fileListCount; counter2++){
                averageCal [counter2*4] = (double)(totalValueList [counter2*4]/(double)averageCount [counter2*4]);
                averageCal [counter2*4+1] = (double)(totalValueList [counter2*4+1]/(double)averageCount [counter2*4+1]);
                averageCal [counter2*4+2] = (double)(totalValueList [counter2*4+2]/(double)averageCount [counter2*4+2]);
                averageCal [counter2*4+3] = (double)(totalValueList [counter2*4+3]/(double)averageCount [counter2*4+3]);
            }
            
            //For (int counterA = 0; counterA < fileListCount; counterA++){
            //    cout<<averageCal [counterA*4]<<" "<<averageCal [counterA*4+1]<<" "<<averageCal [counterA*4+2]<<" "<<averageCal [counterA*4+3]<<" averageCal"<<endl;
            //}
            
            //-----Get overall averages-----
            double redAverage = 0;
            double greenAverage = 0;
            double blueAverage = 0;
            
            for (int counter2 = 0; counter2 < fileListCount; counter2++){
                redAverage = redAverage+averageCal [counter2*4];
                greenAverage = greenAverage+averageCal [counter2*4+1];
                blueAverage = blueAverage+averageCal [counter2*4+2];
            }
            
            //-----Get adjusting value for each FOV. Overall average-average of each FOV
            redAverage = redAverage/(double)fileListCount;
            greenAverage = greenAverage/(double)fileListCount;
            blueAverage = blueAverage/(double)fileListCount;
            
            for (int counter2 = 0; counter2 < fileListCount; counter2++){
                averageAddition [counter2*7] = (int)(redAverage-averageCal [counter2*4]);
                averageAddition [counter2*7+1] = (int)(greenAverage-averageCal [counter2*4+1]);
                averageAddition [counter2*7+2] = (int)(blueAverage-averageCal [counter2*4+2]);
                averageAddition [counter2*7+3] = (int)(autoValueHold-averageCal [counter2*4+3]);
            }
            
            int fovFindFlag = 0;
            
            if (processingFovNo > 0 && processingFovNo <= fileListCount){
                fovFindFlag = 1;
                
                for (int counter2 = 0; counter2 < fileListCount; counter2++){
                    averageAddition [counter2*7+4] = (int)(averageCal [counter2*4]-averageCal [(processingFovNo-1)*4]);
                    averageAddition [counter2*7+5] = (int)(averageCal [counter2*4+1]-averageCal [(processingFovNo-1)*4+1]);
                    averageAddition [counter2*7+6] = (int)(averageCal [counter2*4+2]-averageCal [(processingFovNo-1)*4+2]);
                }
                
                for (int counter2 = 0; counter2 < fileListCount; counter2++){
                    multiply [counter2*4] = averageCal [(processingFovNo-1)*4]/(double)averageCal [counter2*4];
                    multiply [counter2*4+1] = averageCal [(processingFovNo-1)*4+1]/(double)averageCal [counter2*4+1];
                    multiply [counter2*4+2] = averageCal [(processingFovNo-1)*4+2]/(double)averageCal [counter2*4+2];
                }
            }
            
            //For (int counterA = 0; counterA < fileListCount; counterA++){
            //    cout<<averageAddition [counterA*7]<<" "<<averageAddition [counterA*7+1]<<" "<<averageAddition [counterA*7+2]<<" "<<averageAddition [counterA*7+3]<<" "<<averageAddition [counterA*7+4]<<" "<<averageAddition [counterA*7+5]<<" "<<averageAddition [counterA*7+6]<<" averageAddition"<<endl;
            //}
            
            /*
             //-----totalRGBHold
             //-----First determine overall Average value of each RGB channel. Then, determine a difference between the average of each FOV and overall average, or use the Set value.
             //-----Then adding vales of each FOV for each RGB channel are determined.
             //-----0 (Total or FOV, but no FOV mode). Use the Set value to determine the adding value. R value+Set Adding value, G value+Set Adding value, B value+Set Adding value.
             //-----1 (RGB) R value+R Adding value, G value+G Adding value, B value+B Adding value
             //-----2 (R) R value+R Adding value, G value+R Adding value, B value+R Adding value
             //-----3 (G) R value+G Adding value, G value+G Adding value, B value+G Adding value
             //-----4 (B) R value+B Adding value, G value+B Adding value, B value+B Adding value
             //-----5 (RG) R value+average of RG Adding value, G value+average of RG Adding value, B value+average of RG Adding value
             //-----6 (RB) R value+average of RB Adding value, G value+average of RB Adding value, B value+average of RB Adding value
             //-----7 (GB) R value+average of GB Adding value, G value+average of GB Adding value, B value+average of GB Adding value
             
             //-----FOV modes, determine Adding value based on the selected FOV values
             //-----8 (FOV) R value+R (sel) Adding value, G (sel) value+G Adding value, B (sel) value+B Adding value
             
             //-----FOV RGB mode, determine multiplying value based on the selected FOV
             //-----9 (FOVR) R value+R (sel) Multiplying value, G (sel) value+R Multiplying value, B (sel) value+R Multiplying value
             //-----10 (FOVG) R value+G (sel) Multiplying value, G (sel) value+G Multiplying value, B (sel) value+G Multiplying value
             //-----11 (FOVB) R value+B (sel) Multiplying value, G (sel) value+B Multiplying value, B (sel) value+B Multiplying value
             */
            
            for (int counter2 = 0; counter2 < fileListCount; counter2++){
                for (int counter3 = 0; counter3 < imageDimensionH; counter3++){
                    for (int counter4 = 0; counter4 < imageDimensionW*3; counter4 = counter4+3){
                        if (totalRGBHold == 1){
                            if (arrayImageResults [counter2*imageDimensionH+counter3][counter4]+averageAddition [counter2*7] > 255) tempValue1 = 255;
                            else if (arrayImageResults [counter2*imageDimensionH+counter3][counter4]+averageAddition [counter2*7] < 0) tempValue1 = 0;
                            else tempValue1 = arrayImageResults [counter2*imageDimensionH+counter3][counter4]+averageAddition [counter2*7];
                            
                            if (arrayImageResults [counter2*imageDimensionH+counter3][counter4+1]+averageAddition [counter2*7+1] > 255) tempValue2 = 255;
                            else if (arrayImageResults [counter2*imageDimensionH+counter3][counter4+1]+averageAddition [counter2*7+1] < 0) tempValue2 = 0;
                            else tempValue2 = arrayImageResults [counter2*imageDimensionH+counter3][counter4+1]+averageAddition [counter2*7+1];
                            
                            if (arrayImageResults [counter2*imageDimensionH+counter3][counter4+2]+averageAddition [counter2*7+2] > 255) tempValue3 = 255;
                            else if (arrayImageResults [counter2*imageDimensionH+counter3][counter4+2]+averageAddition [counter2*7+2] < 0) tempValue3 = 0;
                            else tempValue3 = arrayImageResults [counter2*imageDimensionH+counter3][counter4+2]+averageAddition [counter2*7+2];
                        }
                        else if (totalRGBHold == 0 ||(fovFindFlag == 0 && totalRGBHold == 8)){
                            if (arrayImageResults [counter2*imageDimensionH+counter3][counter4]+averageAddition [counter2*7+3] > 255) tempValue1 = 255;
                            else if (arrayImageResults [counter2*imageDimensionH+counter3][counter4]+averageAddition [counter2*7+3] < 0) tempValue1 = 0;
                            else tempValue1 = arrayImageResults [counter2*imageDimensionH+counter3][counter4]+averageAddition [counter2*7+3];
                            
                            if (arrayImageResults [counter2*imageDimensionH+counter3][counter4+1]+averageAddition [counter2*7+3] > 255) tempValue2 = 255;
                            else if (arrayImageResults [counter2*imageDimensionH+counter3][counter4+1]+averageAddition [counter2*7+3] < 0) tempValue2 = 0;
                            else tempValue2 = arrayImageResults [counter2*imageDimensionH+counter3][counter4+1]+averageAddition [counter2*7+3];
                            
                            if (arrayImageResults [counter2*imageDimensionH+counter3][counter4+2]+averageAddition [counter2*7+3] > 255) tempValue3 = 255;
                            else if (arrayImageResults [counter2*imageDimensionH+counter3][counter4+2]+averageAddition [counter2*7+3] < 0) tempValue3 = 0;
                            else tempValue3 = arrayImageResults [counter2*imageDimensionH+counter3][counter4+2]+averageAddition [counter2*7+3];
                        }
                        else if (totalRGBHold == 2){
                            if (arrayImageResults [counter2*imageDimensionH+counter3][counter4]+averageAddition [counter2*7] > 255) tempValue1 = 255;
                            else if (arrayImageResults [counter2*imageDimensionH+counter3][counter4]+averageAddition [counter2*7] < 0) tempValue1 = 0;
                            else tempValue1 = arrayImageResults [counter2*imageDimensionH+counter3][counter4]+averageAddition [counter2*7];
                            
                            if (arrayImageResults [counter2*imageDimensionH+counter3][counter4+1]+averageAddition [counter2*7] > 255) tempValue2 = 255;
                            else if (arrayImageResults [counter2*imageDimensionH+counter3][counter4+1]+averageAddition [counter2*7] < 0) tempValue2 = 0;
                            else tempValue2 = arrayImageResults [counter2*imageDimensionH+counter3][counter4+1]+averageAddition [counter2*7];
                            
                            if (arrayImageResults [counter2*imageDimensionH+counter3][counter4+2]+averageAddition [counter2*7] > 255) tempValue3 = 255;
                            else if (arrayImageResults [counter2*imageDimensionH+counter3][counter4+2]+averageAddition [counter2*7] < 0) tempValue3 = 0;
                            else tempValue3 = arrayImageResults [counter2*imageDimensionH+counter3][counter4+2]+averageAddition [counter2*7];
                        }
                        else if (totalRGBHold == 3){
                            if (arrayImageResults [counter2*imageDimensionH+counter3][counter4]+averageAddition [counter2*7+1] > 255) tempValue1 = 255;
                            else if (arrayImageResults [counter2*imageDimensionH+counter3][counter4]+averageAddition [counter2*7+1] < 0) tempValue1 = 0;
                            else tempValue1 = arrayImageResults [counter2*imageDimensionH+counter3][counter4]+averageAddition [counter2*7+1];
                            
                            if (arrayImageResults [counter2*imageDimensionH+counter3][counter4+1]+averageAddition [counter2*7+1] > 255) tempValue2 = 255;
                            else if (arrayImageResults [counter2*imageDimensionH+counter3][counter4+1]+averageAddition [counter2*7+1] < 0) tempValue2 = 0;
                            else tempValue2 = arrayImageResults [counter2*imageDimensionH+counter3][counter4+1]+averageAddition [counter2*7+1];
                            
                            if (arrayImageResults [counter2*imageDimensionH+counter3][counter4+2]+averageAddition [counter2*7+1] > 255) tempValue3 = 255;
                            else if (arrayImageResults [counter2*imageDimensionH+counter3][counter4+2]+averageAddition [counter2*7+1] < 0) tempValue3 = 0;
                            else tempValue3 = arrayImageResults [counter2*imageDimensionH+counter3][counter4+2]+averageAddition [counter2*7+1];
                        }
                        else if (totalRGBHold == 4){
                            if (arrayImageResults [counter2*imageDimensionH+counter3][counter4]+averageAddition [counter2*7+2] > 255) tempValue1 = 255;
                            else if (arrayImageResults [counter2*imageDimensionH+counter3][counter4]+averageAddition [counter2*7+2] < 0) tempValue1 = 0;
                            else tempValue1 = arrayImageResults [counter2*imageDimensionH+counter3][counter4]+averageAddition [counter2*7+2];
                            
                            if (arrayImageResults [counter2*imageDimensionH+counter3][counter4+1]+averageAddition [counter2*7+2] > 255) tempValue2 = 255;
                            else if (arrayImageResults [counter2*imageDimensionH+counter3][counter4+1]+averageAddition [counter2*7+2] < 0) tempValue2 = 0;
                            else tempValue2 = arrayImageResults [counter2*imageDimensionH+counter3][counter4+1]+averageAddition [counter2*7+2];
                            
                            if (arrayImageResults [counter2*imageDimensionH+counter3][counter4+2]+averageAddition [counter2*7+2] > 255) tempValue3 = 255;
                            else if (arrayImageResults [counter2*imageDimensionH+counter3][counter4+2]+averageAddition [counter2*7+2] < 0) tempValue3 = 0;
                            else tempValue3 = arrayImageResults [counter2*imageDimensionH+counter3][counter4+2]+averageAddition [counter2*7+2];
                        }
                        else if (totalRGBHold == 5){
                            if (arrayImageResults [counter2*imageDimensionH+counter3][counter4]+(int)((averageAddition [counter2*7]+averageAddition [counter2*7+1])/(double)2) > 255) tempValue1 = 255;
                            else if (arrayImageResults [counter2*imageDimensionH+counter3][counter4]+(int)((averageAddition [counter2*7]+averageAddition [counter2*7+1])/(double)2) < 0) tempValue1 = 0;
                            else tempValue1 = arrayImageResults [counter2*imageDimensionH+counter3][counter4]+(int)((averageAddition [counter2*7]+averageAddition [counter2*7+1])/(double)2);
                            
                            if (arrayImageResults [counter2*imageDimensionH+counter3][counter4+1]+(int)((averageAddition [counter2*7]+averageAddition [counter2*7+1])/(double)2) > 255) tempValue2 = 255;
                            else if (arrayImageResults [counter2*imageDimensionH+counter3][counter4+1]+(int)((averageAddition [counter2*7]+averageAddition [counter2*7+1])/(double)2) < 0) tempValue2 = 0;
                            else tempValue2 = arrayImageResults [counter2*imageDimensionH+counter3][counter4+1]+(int)((averageAddition [counter2*7]+averageAddition [counter2*7+1])/(double)2);
                            
                            if (arrayImageResults [counter2*imageDimensionH+counter3][counter4+2]+(int)((averageAddition [counter2*7]+averageAddition [counter2*7+1])/(double)2) > 255) tempValue3 = 255;
                            else if (arrayImageResults [counter2*imageDimensionH+counter3][counter4+2]+(int)((averageAddition [counter2*7]+averageAddition [counter2*7+1])/(double)2) < 0) tempValue3 = 0;
                            else tempValue3 = arrayImageResults [counter2*imageDimensionH+counter3][counter4+2]+(int)((averageAddition [counter2*7]+averageAddition [counter2*7+1])/(double)2);
                        }
                        else if (totalRGBHold == 6){
                            if (arrayImageResults [counter2*imageDimensionH+counter3][counter4]+(int)((averageAddition [counter2*7]+averageAddition [counter2*7+2])/(double)2) > 255) tempValue1 = 255;
                            else if (arrayImageResults [counter2*imageDimensionH+counter3][counter4]+(int)((averageAddition [counter2*7]+averageAddition [counter2*7+2])/(double)2) < 0) tempValue1 = 0;
                            else tempValue1 = arrayImageResults [counter2*imageDimensionH+counter3][counter4]+(int)((averageAddition [counter2*7]+averageAddition [counter2*7+2])/(double)2);
                            
                            if (arrayImageResults [counter2*imageDimensionH+counter3][counter4+1]+(int)((averageAddition [counter2*7]+averageAddition [counter2*7+2])/(double)2) > 255) tempValue2 = 255;
                            else if (arrayImageResults [counter2*imageDimensionH+counter3][counter4+1]+(int)((averageAddition [counter2*7]+averageAddition [counter2*7+2])/(double)2) < 0) tempValue2 = 0;
                            else tempValue2 = arrayImageResults [counter2*imageDimensionH+counter3][counter4+1]+(int)((averageAddition [counter2*7]+averageAddition [counter2*7+2])/(double)2);
                            
                            if (arrayImageResults [counter2*imageDimensionH+counter3][counter4+2]+(int)((averageAddition [counter2*7]+averageAddition [counter2*7+2])/(double)2) > 255) tempValue3 = 255;
                            else if (arrayImageResults [counter2*imageDimensionH+counter3][counter4+2]+(int)((averageAddition [counter2*7]+averageAddition [counter2*7+2])/(double)2) < 0) tempValue3 = 0;
                            else tempValue3 = arrayImageResults [counter2*imageDimensionH+counter3][counter4+2]+(int)((averageAddition [counter2*7]+averageAddition [counter2*7+2])/(double)2);
                        }
                        else if (totalRGBHold == 7){
                            if (arrayImageResults [counter2*imageDimensionH+counter3][counter4]+(int)((averageAddition [counter2*7+1]+averageAddition [counter2*7+2])/(double)2) > 255) tempValue1 = 255;
                            else if (arrayImageResults [counter2*imageDimensionH+counter3][counter4]+(int)((averageAddition [counter2*7+1]+averageAddition [counter2*7+2])/(double)2) < 0) tempValue1 = 0;
                            else tempValue1 = arrayImageResults [counter2*imageDimensionH+counter3][counter4]+(int)((averageAddition [counter2*7+1]+averageAddition [counter2*7+2])/(double)2);
                            
                            if (arrayImageResults [counter2*imageDimensionH+counter3][counter4+1]+(int)((averageAddition [counter2*7+1]+averageAddition [counter2*7+2])/(double)2) > 255) tempValue2 = 255;
                            else if (arrayImageResults [counter2*imageDimensionH+counter3][counter4+1]+(int)((averageAddition [counter2*7+1]+averageAddition [counter2*7+2])/(double)2) < 0) tempValue2 = 0;
                            else tempValue2 = arrayImageResults [counter2*imageDimensionH+counter3][counter4+1]+(int)((averageAddition [counter2*7+1]+averageAddition [counter2*7+2])/(double)2);
                            
                            if (arrayImageResults [counter2*imageDimensionH+counter3][counter4+2]+(int)((averageAddition [counter2*7+1]+averageAddition [counter2*7+2])/(double)2) > 255) tempValue3 = 255;
                            else if (arrayImageResults [counter2*imageDimensionH+counter3][counter4+2]+(int)((averageAddition [counter2*7+1]+averageAddition [counter2*7+2])/(double)2) < 0) tempValue3 = 0;
                            else tempValue3 = arrayImageResults [counter2*imageDimensionH+counter3][counter4+2]+(int)((averageAddition [counter2*7+1]+averageAddition [counter2*7+2])/(double)2);
                        }
                        else if (totalRGBHold == 8){
                            if (arrayImageResults [counter2*imageDimensionH+counter3][counter4]+averageAddition [counter2*7+4] > 255) tempValue1 = 255;
                            else if (arrayImageResults [counter2*imageDimensionH+counter3][counter4]+averageAddition [counter2*7+4] < 0) tempValue1 = 0;
                            else tempValue1 = arrayImageResults [counter2*imageDimensionH+counter3][counter4]+averageAddition [counter2*7+4];
                            
                            if (arrayImageResults [counter2*imageDimensionH+counter3][counter4+1]+averageAddition [counter2*7+5] > 255) tempValue2 = 255;
                            else if (arrayImageResults [counter2*imageDimensionH+counter3][counter4+1]+averageAddition [counter2*7+5] < 0) tempValue2 = 0;
                            else tempValue2 = arrayImageResults [counter2*imageDimensionH+counter3][counter4+1]+averageAddition [counter2*7+5];
                            
                            if (arrayImageResults [counter2*imageDimensionH+counter3][counter4+2]+averageAddition [counter2*7+6] > 255) tempValue3 = 255;
                            else if (arrayImageResults [counter2*imageDimensionH+counter3][counter4+2]+averageAddition [counter2*7+6] < 0) tempValue3 = 0;
                            else tempValue3 = arrayImageResults [counter2*imageDimensionH+counter3][counter4+2]+averageAddition [counter2*7+6];
                        }
                        else if (totalRGBHold == 9){
                            if ((int)(arrayImageResults [counter2*imageDimensionH+counter3][counter4]*multiply [counter2*4]) > 255) tempValue1 = 255;
                            else if ((int)(arrayImageResults [counter2*imageDimensionH+counter3][counter4]*multiply [counter2*4]) < 0) tempValue1 = 0;
                            else tempValue1 = (int)(arrayImageResults [counter2*imageDimensionH+counter3][counter4]*multiply [counter2*4]);
                            
                            if ((int)(arrayImageResults [counter2*imageDimensionH+counter3][counter4+1]*multiply [counter2*4]) > 255) tempValue2 = 255;
                            else if ((int)(arrayImageResults [counter2*imageDimensionH+counter3][counter4+1]*multiply [counter2*4]) < 0) tempValue2 = 0;
                            else tempValue2 = (int)(arrayImageResults [counter2*imageDimensionH+counter3][counter4+1]*multiply [counter2*4]);
                            
                            if ((int)(arrayImageResults [counter2*imageDimensionH+counter3][counter4+2]*multiply [counter2*4]) > 255) tempValue3 = 255;
                            else if ((int)(arrayImageResults [counter2*imageDimensionH+counter3][counter4+2]*multiply [counter2*4]) < 0) tempValue3 = 0;
                            else tempValue3 = (int)(arrayImageResults [counter2*imageDimensionH+counter3][counter4+2]*multiply [counter2*4]);
                        }
                        else if (totalRGBHold == 10){
                            if ((int)(arrayImageResults [counter2*imageDimensionH+counter3][counter4]*multiply [counter2*4+1]) > 255) tempValue1 = 255;
                            else if ((int)(arrayImageResults [counter2*imageDimensionH+counter3][counter4]*multiply [counter2*4+1]) < 0) tempValue1 = 0;
                            else tempValue1 = (int)(arrayImageResults [counter2*imageDimensionH+counter3][counter4]*multiply [counter2*4+1]);
                            
                            if ((int)(arrayImageResults [counter2*imageDimensionH+counter3][counter4+1]*multiply [counter2*4+1]) > 255) tempValue2 = 255;
                            else if ((int)(arrayImageResults [counter2*imageDimensionH+counter3][counter4+1]*multiply [counter2*4+1]) < 0) tempValue2 = 0;
                            else tempValue2 = (int)(arrayImageResults [counter2*imageDimensionH+counter3][counter4+1]*multiply [counter2*4+1]);
                            
                            if ((int)(arrayImageResults [counter2*imageDimensionH+counter3][counter4+2]*multiply [counter2*4+1]) > 255) tempValue3 = 255;
                            else if ((int)(arrayImageResults [counter2*imageDimensionH+counter3][counter4+2]*multiply [counter2*4+1]) < 0) tempValue3 = 0;
                            else tempValue3 = (int)(arrayImageResults [counter2*imageDimensionH+counter3][counter4+2]*multiply [counter2*4+1]);
                        }
                        else if (totalRGBHold == 11){
                            if ((int)(arrayImageResults [counter2*imageDimensionH+counter3][counter4]*multiply [counter2*4+2]) > 255) tempValue1 = 255;
                            else if ((int)(arrayImageResults [counter2*imageDimensionH+counter3][counter4]*multiply [counter2*4+2]) < 0) tempValue1 = 0;
                            else tempValue1 = (int)(arrayImageResults [counter2*imageDimensionH+counter3][counter4]*multiply [counter2*4+2]);
                            
                            if ((int)(arrayImageResults [counter2*imageDimensionH+counter3][counter4+1]*multiply [counter2*4+2]) > 255) tempValue2 = 255;
                            else if ((int)(arrayImageResults [counter2*imageDimensionH+counter3][counter4+1]*multiply [counter2*4+2]) < 0) tempValue2 = 0;
                            else tempValue2 = (int)(arrayImageResults [counter2*imageDimensionH+counter3][counter4+1]*multiply [counter2*4+2]);
                            
                            if ((int)(arrayImageResults [counter2*imageDimensionH+counter3][counter4+2]*multiply [counter2*4+2]) > 255) tempValue3 = 255;
                            else if ((int)(arrayImageResults [counter2*imageDimensionH+counter3][counter4+2]*multiply [counter2*4+2]) < 0) tempValue3 = 0;
                            else tempValue3 = (int)(arrayImageResults [counter2*imageDimensionH+counter3][counter4+2]*multiply [counter2*4+2]);
                        }
                        
                        arrayImageResults [counter2*imageDimensionH+counter3][counter4] = tempValue1;
                        arrayImageResults [counter2*imageDimensionH+counter3][counter4+1] = tempValue2;
                        arrayImageResults [counter2*imageDimensionH+counter3][counter4+2] = tempValue3;
                        
                        imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4] = tempValue1;
                        imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4+1] = tempValue2;
                        imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4+2] = tempValue3;
                    }
                }
            }
        }
        
        delete [] totalValueList;
        delete [] averageCount;
        delete [] averageCal;
        delete [] averageAddition;
        delete [] multiply;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
    }
    else{
        
        if (imageLoadStatus != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Data Entered"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Other Processes In Progress"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)autoContrastClear:(id)sender{
    if (imageLoadStatus == 1 && copyProgressFlag == 0){
        imageDisplayCall = 3;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        if (imageLoadStatus != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Data Entered"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Other Processes In Progress"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)autoTotalRGB:(id)sender{
    if (totalRGBHold == 0){
        totalRGBHold = 1;
        [totalRGBDisplay setStringValue:@"RGB"];
    }
    else if (totalRGBHold == 1){
        totalRGBHold = 2;
        [totalRGBDisplay setStringValue:@"R"];
    }
    else if (totalRGBHold == 2){
        totalRGBHold = 3;
        [totalRGBDisplay setStringValue:@"G"];
    }
    else if (totalRGBHold == 3){
        totalRGBHold = 4;
        [totalRGBDisplay setStringValue:@"B"];
    }
    else if (totalRGBHold == 4){
        totalRGBHold = 5;
        [totalRGBDisplay setStringValue:@"RG"];
    }
    else if (totalRGBHold == 5){
        totalRGBHold = 6;
        [totalRGBDisplay setStringValue:@"RB"];
    }
    else if (totalRGBHold == 6){
        totalRGBHold = 7;
        [totalRGBDisplay setStringValue:@"GB"];
    }
    else if (totalRGBHold == 7){
        totalRGBHold = 8;
        [totalRGBDisplay setStringValue:@"FOV"];
    }
    else if (totalRGBHold == 8){
        totalRGBHold = 9;
        [totalRGBDisplay setStringValue:@"FOVR"];
    }
    else if (totalRGBHold == 9){
        totalRGBHold = 10;
        [totalRGBDisplay setStringValue:@"FOVG"];
    }
    else if (totalRGBHold == 10){
        totalRGBHold = 11;
        [totalRGBDisplay setStringValue:@"FOVB"];
    }
    else if (totalRGBHold == 11){
        totalRGBHold = 0;
        [totalRGBDisplay setStringValue:@"Total"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)cleanUPList:(id)sender{
    if (imageLoadStatus == 1 && copyProgressFlag == 0){
        string *tableHoldListTemp = new string [tableListHoldCount*2+10];
        string productDataPath1;
        
        int tableHoldListTempCount = 0;
        
        DIR *dir;
        struct dirent *dent;
        DIR *dir2;
        struct dirent *dent2;
        
        dir = opendir(imageDataPath.c_str());
        
        if (dir != NULL){
            string entry;
            string entry2;
            
            while((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("_ProductsH") != -1){
                    productDataPath1 = imageDataPath+"/"+entry;
                    
                    dir2 = opendir(productDataPath1.c_str());
                    
                    if (dir2 != NULL){
                        while ((dent2 = readdir(dir2))){
                            entry2 = dent2 -> d_name;
                            
                            if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store" && (int)entry2.find("_Capture") != -1){
                                tableHoldListTemp [tableHoldListTempCount] = entry.substr(0, entry.find("_ProductsH")), tableHoldListTempCount++;
                                tableHoldListTemp [tableHoldListTempCount] = entry2.substr(0, entry2.find("_Capture")), tableHoldListTempCount++;
                            }
                        }
                        
                        closedir(dir2);
                    }
                }
            }
            
            closedir(dir);
        }
        
        //For (int counterA = 0; counterA < tableHoldListTempCount/2; counterA++){
        //    cout<<tableHoldListTemp [counterA*2] <<" "<<tableHoldListTemp [counterA*2+1]<<" tableHoldListTemp"<<endl;
        //}
        
        string *tableActiveTemp = new string [tableListHoldCount*85+100];
        
        int tableActiveTempCount = 0;
        int matchFind = 0;
        
        for (int counter1 = 0; counter1 < tableListHoldCount; counter1++){
            matchFind = 0;
            
            for (int counter2 = 0; counter2 < tableHoldListTempCount/2; counter2++){
                if (tableHoldListTemp [counter2*2] == tableListHold [counter1*85+1] && tableHoldListTemp [counter2*2+1] == tableListHold [counter1*85+2]){
                    matchFind = 1;
                    break;
                }
            }
            
            if (matchFind == 1){
                tableActiveTemp [tableActiveTempCount*85] = tableListHold [counter1*85];
                tableActiveTemp [tableActiveTempCount*85+1] = tableListHold [counter1*85+1];
                tableActiveTemp [tableActiveTempCount*85+2] = tableListHold [counter1*85+2];
                tableActiveTemp [tableActiveTempCount*85+3] = tableListHold [counter1*85+3];
                
                for (int counter2 = 0; counter2 < 81; counter2++){
                    tableActiveTemp [tableActiveTempCount*85+counter2+4] = tableListHold [counter1*85+counter2+4];
                }
                
                tableActiveTempCount++;
            }
        }
        
        //For (int counterA = 0; counterA < tableActiveTempCount*85; counterA++){
        //    cout<<tableActiveTemp [counterA]<<" tableActiveTemp"<<endl;
        //}
        
        tableListHoldCount = 0;
        
        for (int counter1 = 0; counter1 < tableActiveTempCount; counter1++){
            tableListHold [tableListHoldCount*85] = tableActiveTemp [counter1*85];
            tableListHold [tableListHoldCount*85+1] = tableActiveTemp [counter1*85+1];
            tableListHold [tableListHoldCount*85+2] = tableActiveTemp [counter1*85+2];
            tableListHold [tableListHoldCount*85+3] = tableActiveTemp [counter1*85+3];
            
            for (int counter2 = 0; counter2 < 81; counter2++){
                tableListHold [tableListHoldCount*85+counter2+4] = tableActiveTemp [counter1*85+counter2+4];
            }
            
            tableListHoldCount++;
        }
        
        ofstream oin;
        
        oin.open(tableListPath.c_str(), ios::out);
        
        for (int counter1 = 0; counter1 < tableListHoldCount*85; counter1++){
            oin<<tableListHold [counter1]<<endl;
        }
        
        oin.close();
        
        delete [] tableHoldListTemp;
        delete [] tableActiveTemp;
        
        string imagingParameterPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/ImageDataList";
        string *imageDataListTemp = new string [10000];
        
        int imageDataListTempCount = 0;
        int imageDataListTempLimit = 10000;
        int terminationFlag = 0;
        
        string getString;
        
        ifstream fin;
        fin.open(imagingParameterPath.c_str(),ios::in);
        
        if (fin.is_open()){
            do{
                
                terminationFlag = 1;
                
                if (imageDataListTempCount*422+450 > imageDataListTempLimit){
                    string *arrayUpDate = new string [imageDataListTempCount*422+10];
                    
                    for (int counter1 = 0; counter1 < imageDataListTempCount*422; counter1++) arrayUpDate [counter1] = imageDataListTemp [counter1];
                    delete [] imageDataListTemp;
                    imageDataListTemp = new string [imageDataListTempLimit+10000];
                    imageDataListTempLimit = imageDataListTempLimit+10000;
                    
                    for (int counter1 = 0; counter1 < imageDataListTempCount*422; counter1++) imageDataListTemp [counter1] = arrayUpDate [counter1];
                    delete [] arrayUpDate;
                }
                
                for (int counter1 = 0; counter1 < 422; counter1++){
                    getline(fin, getString), imageDataListTemp [imageDataListTempCount*422+counter1] = getString;
                    
                    if (getString == ""){
                        terminationFlag = 0;
                        break;
                    }
                }
                
                if (terminationFlag != 0) imageDataListTempCount++;
                
            } while (terminationFlag == 1);
            
            fin.close();
        }
        
        string *imageDataListTemp2 = new string [(imageDataListTempCount+1)*422+10];
        int imageDataListTempCount2 = 0;
        
        for (int counter1 = 0; counter1 < imageDataListTempCount; counter1++){
            matchFind = 0;
            
            for (int counter2 = 0; counter2 < tableHoldListTempCount/2; counter2++){
                if (tableHoldListTemp [counter2*2] == imageDataListTemp [counter1*422] && tableHoldListTemp [counter2*2+1] == imageDataListTemp [counter1*422+1]){
                    matchFind = 1;
                    break;
                }
            }
            
            if (matchFind == 1){
                for (int counter2 = 0; counter2 < 422; counter2++){
                    imageDataListTemp2 [imageDataListTempCount2*422+counter2] = imageDataListTemp [counter1*422+counter2];
                }
                
                imageDataListTempCount2++;
            }
        }
        
        oin.open(imagingParameterPath.c_str(), ios::out);
        
        for (int counter1 = 0; counter1 < imageDataListTempCount2*422; counter1++){
            oin<<imageDataListTemp2 [counter1]<<endl;
        }
        
        oin.close();
        
        delete [] imageDataListTemp;
        delete [] imageDataListTemp2;
        
        tableDisplayCall = 1;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        if (imageLoadStatus != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Data Entered"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Other Processes In Progress"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)fileRemove:(id)sender{
    if (imageLoadStatus == 1 && copyProgressFlag == 0 && processingFovNo > 1){
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
            copyProgressFlag = 1;
            progressTiming = 6;
            
            do usleep(10);
            while (progressTiming == 6);
            
            string imageDisplayNewPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files/"+analysisNameHold+"_ProductsH/";
            
            DIR *dir;
            struct dirent *dent;
            
            string entry;
            string extractString = "";
            
            dir = opendir(imageDisplayNewPath.c_str());
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    extractString = treatNameHold+"R";
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find(extractString) != -1) extractString = extractString+"R";
                    else{
                        
                        break;
                    }
                }
                
                closedir(dir);
            }
            
            string imageDisplayNewPath2 = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files/"+analysisNameHold+"_ProductsH/"+extractString+"_Capture";
            mkdir(imageDisplayNewPath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            string imageDisplayOriginalPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files/"+analysisNameHold+"_ProductsH/"+extractString+"_Capture/Original";
            mkdir(imageDisplayOriginalPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            string imageDisplayCurrentPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files/"+analysisNameHold+"_ProductsH/"+extractString+"_Capture/Current";
            mkdir(imageDisplayCurrentPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            string imageDisplaySourceOriginalPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files/"+analysisNameHold+"_ProductsH/"+treatNameHold+"_Capture/Original";
            string imageDisplaySourceCurrentPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files/"+analysisNameHold+"_ProductsH/"+treatNameHold+"_Capture/Current";
            
            string *fileList2 = new string [fileListCount+10];
            int fileListCount2 = 0;
            
            dir = opendir(imageDisplaySourceOriginalPath.c_str());
            
            if (dir != NULL){
                while((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        if ((int)entry.find(".tif") != -1){
                            fileList2 [fileListCount2] = entry, fileListCount2++;
                        }
                    }
                }
                
                closedir(dir);
                
                //-----Directory Sort-----
                NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                
                for (int counter1 = 0; counter1 < fileListCount2; counter1++){
                    [unsortedArray addObject:@(fileList2 [counter1].c_str())];
                }
                
                [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                
                for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                    fileList2 [counter1] = [unsortedArray [counter1] UTF8String];
                }
                
                long sizeForCopy = 0;
                int counterRemove = 1;
                
                string countEntryString;
                string sourceListPath;
                string savePath;
                
                struct stat sizeOfFile;
                
                for (int counter1 = 0; counter1 < fileListCount2; counter1++){
                    countEntryString = to_string (counterRemove);
                    
                    if (countEntryString.length() == 1) countEntryString = "000"+countEntryString;
                    else if (countEntryString.length() == 2) countEntryString = "00"+countEntryString;
                    else if (countEntryString.length() == 3) countEntryString = "0"+countEntryString;
                    
                    if (atoi(fileList2 [counter1].substr(fileList2 [counter1].find(".tif")-4, 4).c_str()) != processingFovNo){
                        sourceListPath = imageDisplaySourceOriginalPath+"/"+fileList2 [counter1];
                        savePath = imageDisplayOriginalPath+"/"+fileList2 [counter1].substr(0, fileList2 [counter1].find("-")+1)+countEntryString+".tif";
                        
                        if (stat(sourceListPath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            ifstream infile (sourceListPath.c_str(), ifstream::binary);
                            ofstream outfile (savePath.c_str(), ofstream::binary);
                            
                            char *buffer = new char[sizeForCopy];
                            infile.read (buffer, sizeForCopy);
                            outfile.write (buffer, sizeForCopy);
                            delete [] buffer;
                            
                            outfile.close();
                            infile.close();
                        }
                        
                        counterRemove++;
                    }
                }
            }
            
            dir = opendir(imageDisplaySourceCurrentPath.c_str());
            
            fileListCount2 = 0;
            
            if (dir != NULL){
                while((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        if ((int)entry.find(".tif") != -1){
                            fileList2 [fileListCount2] = entry, fileListCount2++;
                        }
                    }
                }
                
                closedir(dir);
                
                //-----Directory Sort-----
                NSMutableArray *unsortedArray2 = [[NSMutableArray alloc] init];
                
                for (int counter1 = 0; counter1 < fileListCount2; counter1++){
                    [unsortedArray2 addObject:@(fileList2 [counter1].c_str())];
                }
                
                [unsortedArray2 sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                
                for (NSUInteger counter1 = 0; counter1 < [unsortedArray2 count]; counter1++){
                    fileList2 [counter1] = [unsortedArray2 [counter1] UTF8String];
                }
                
                long sizeForCopy = 0;
                int counterRemove = 1;
                
                string countEntryString;
                string sourceListPath;
                string savePath;
                
                struct stat sizeOfFile;
                
                for (int counter1 = 0; counter1 < fileListCount2; counter1++){
                    countEntryString = to_string (counterRemove);
                    
                    if (countEntryString.length() == 1) countEntryString = "000"+countEntryString;
                    else if (countEntryString.length() == 2) countEntryString = "00"+countEntryString;
                    else if (countEntryString.length() == 3) countEntryString = "0"+countEntryString;
                    
                    if (atoi(fileList2 [counter1].substr(fileList2 [counter1].find(".tif")-4, 4).c_str()) != processingFovNo){
                        sourceListPath = imageDisplaySourceCurrentPath+"/"+fileList2 [counter1];
                        savePath = imageDisplayCurrentPath+"/"+fileList2 [counter1].substr(0, fileList2 [counter1].find("-")+1)+countEntryString+".tif";
                        
                        if (stat(sourceListPath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            ifstream infile (sourceListPath.c_str(), ifstream::binary);
                            ofstream outfile (savePath.c_str(), ofstream::binary);
                            
                            char *buffer = new char[sizeForCopy];
                            infile.read (buffer, sizeForCopy);
                            outfile.write (buffer, sizeForCopy);
                            delete [] buffer;
                            
                            outfile.close();
                            infile.close();
                        }
                        
                        counterRemove++;
                    }
                }
            }
            
            delete [] fileList2;
            
            if (tableListHoldCount*85+100 > tableListHoldLimit){
                string *arrayUpDate = new string [tableListHoldCount*85+10];
                
                for (int counter3 = 0; counter3 < tableListHoldCount*85; counter3++) arrayUpDate [counter3] = tableListHold [counter3];
                delete [] tableListHold;
                tableListHold = new string [tableListHoldLimit+1000];
                tableListHoldLimit = tableListHoldLimit+1000;
                
                for (int counter3 = 0; counter3 < tableListHoldCount*85; counter3++) tableListHold [counter3] = arrayUpDate [counter3];
                delete [] arrayUpDate;
            }
            
            tableListHold [tableListHoldCount*85] = "0";
            tableListHold [tableListHoldCount*85+1] = analysisNameHold;
            tableListHold [tableListHoldCount*85+2] = extractString;
            tableListHold [tableListHoldCount*85+3] = to_string(fileListCount-1);
            
            for (int counter3 = 0; counter3 < 81; counter3++){
                tableListHold [tableListHoldCount*85+counter3+4] = "nil";
            }
            
            tableListHoldCount++;
            
            ofstream oin;
            
            oin.open(tableListPath.c_str(), ios::out);
            
            for (int counter1 = 0; counter1 < tableListHoldCount*85; counter1++) oin<<tableListHold [counter1]<<endl;
            
            oin.close();
            
            tableDisplayCall = 1;
            productDisplayCall = 2;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
            
            progressTiming = 8;
            copyProgressFlag = 0;
        });
    }
    else{
        
        if (imageLoadStatus == 0 && copyProgressFlag == 1){
            if (imageLoadStatus == 0){
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Data Entered"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Other Processes In Progress"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else if (processingFovNo <= 1){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Select One Or Two FOVs"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)imageFolderCreateForSeg:(id)sender{
    if (copyProgressFlag == 0){
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
            copyProgressFlag = 1;
            progressTiming = 6;
            
            do usleep(10);
            while (progressTiming == 6);
            
            if (currentImageName != ""){
                string imageDataPath2 = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"06_Cell_Tracking_images";
                
                DIR *dir;
                struct dirent *dent;
                
                string entry;
                string extractString;
                int maxEntryNo = 0;
                
                dir = opendir(imageDataPath2.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find(currentImageName) != -1){
                            if (entry.substr(currentImageName.length(), 1) == "_"){
                                if (maxEntryNo == 0) maxEntryNo = 1;
                            }
                            else extractString = entry.substr(currentImageName.length(), entry.find("_Image")-currentImageName.length());
                            
                            if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                        }
                    }
                    
                    closedir(dir);
                }
                
                maxEntryNo++;
                
                string resultSavePath;
                
                if (maxEntryNo == 1){
                    resultSavePath = imageDataPath2+"/"+currentImageName+"_Image";
                    mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                }
                else{
                    
                    resultSavePath = imageDataPath2+"/"+currentImageName+to_string(maxEntryNo)+"_Image";
                    mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                }
                
                string resultSavePath2 = resultSavePath+"/"+currentImageName+"_Stitch";
                mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                arrayImageFileSave = new int *[stitchedImageDimension+1];
                
                for (int counter5 = 0; counter5 < stitchedImageDimension+1; counter5++){
                    arrayImageFileSave [counter5] = new int [stitchedImageDimension+1];
                }
                
                for (int counter3 = 0; counter3 < stitchedImageDimension; counter3++){
                    for (int counter4 = 0; counter4 < stitchedImageDimension; counter4++){
                        if (photoMetricsHold == 1 && imageBitHold == 8){
                            arrayImageFileSave [counter3][counter4] = imageDisplayArray [counter3][counter4];
                        }
                        else if (photoMetricsHold == 1 && imageBitHold == 16){
                            arrayImageFileSave [counter3][counter4] = (int)(imageDisplayArray [counter3][counter4]/(double)256);
                        }
                        else if (photoMetricsHold == 2 && imageBitHold == 8){
                            arrayImageFileSave [counter3][counter4] = (int)((imageDisplayArray [counter3][counter4*3]+imageDisplayArray[counter3][counter4*3+1]+imageDisplayArray[counter3][counter4*3+2])/(double)3);
                        }
                        else if (photoMetricsHold == 2 && imageBitHold == 16){
                            arrayImageFileSave [counter3][counter4] = (int)(((imageDisplayArray [counter3][counter4*3]+imageDisplayArray[counter3][counter4*3+1]+imageDisplayArray[counter3][counter4*3+2])/(double)3)/(double)256);
                        }
                    }
                }
                
                fileSavePathHold = resultSavePath2+"/STimage 0001.tif";
                
                double xPosition = 0;
                double yPosition = 0;
                int mode = 0;
                int imageBit = 8;
                int photoMetrics = 1;
                int samplePerPix = 1;
                
                self->singleTiffSave = [[SingleTiffSave alloc] init];
                [self->singleTiffSave singleTiffLayerSave:stitchedImageDimension:stitchedImageDimension:imageBit:photoMetrics:samplePerPix:xPosition:yPosition:mode:(unsigned long)mode];
                
                for (int counter3 = 0; counter3 < stitchedImageDimension+1; counter3++){
                    delete [] arrayImageFileSave [counter3];
                }
                
                delete [] arrayImageFileSave;
            }
            
            progressTiming = 8;
            copyProgressFlag = 0;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        });
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

@end
