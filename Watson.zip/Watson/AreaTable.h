//
//  AreaTable.h
//  CellMovieQuant
//
//  Created by Masahiko Sato on 2019-01-07.
//

#ifndef AREATABLE_H
#define AREATABLE_H
#import "Controller.h" //CNT
#endif

@interface AreaTable : NSObject <NSTableViewDataSource>{
    IBOutlet NSTableView *areaSummaryTable;
}

-(id)init;
-(void)dealloc;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;

@end
