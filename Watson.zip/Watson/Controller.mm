//
//  Controller.m
//  Watson
//
//  Created by Masahiko Sato on 2014-09-29.
//
//

#import "Controller.h"

//-----Basic info-----
string pathNameString;
string analysisNameHold;
string treatNameHold;
string imageDataPath;

//-----Arrays-----
string *fileList;
int fileListCount;
int fileListLimit;
string *arrayDirectoryInfo;
int directoryInfoCount;
int directoryInfoLimit;
string fileSavePathHold;
int **arrayImageFileSave;
uint8_t *fileReadArray;

//-----Basic operation-----
string tableListPath;
int imageLoadStatus;
double levelHoldContrast;
double levelHoldBrightness;
double levelHoldBlur;
double levelHoldRed;
double levelHoldGreen;
double levelHoldBlue;
double cutRedHold;
double cutGreenHold;
double cutBlueHold;
double levelHoldRedPick;
double levelHoldGreenPick;
double levelHoldBluePick;
double cutRedHoldPick;
double cutGreenHoldPick;
double cutBlueHoldPick;
int tableDisplayCall;
int productDisplayCall;
int progressTiming;
int copyProgressFlag;

int initialArraySet;
int imageDimensionH;
int imageDimensionW;
int imageBitHold;
int photoMetricsHold;
int samplePerPixHold;

//-----Image display-----
int stitchedImageDimension;
int **imageDisplayArray;
int imageDisplayCall;
int processingFovNo;
double autoValueHold;
int totalRGBHold;

//-----List-----
string *tableListHold;
int tableListHoldCount;
int tableListHoldLimit;
string currentListName;
string currentListNumber;
string *currentListInformation;
int *imageSetPositionList;

//-----Current image-----
string currentImageName;
int **arrayImageDataHold;
int imageDataHoldStatus;
int **arrayImageOriginal;
int **arrayImageResults;
int imageRangeAdjustStatus;
int **imagePositionMap;
int *xyPositionData;
int *xyPositionDataOriginal;
int *xyPositionWritingData;
string imageFLStatus;
int contrastLockRelease;

//-----Others-----
string ascIIstring;
int warningSet;
int cursorRedMax;
int cursorGreenMax;
int cursorBlueMax;
int cursorRedMin;
int cursorGreenMin;
int cursorBlueMin;
int colorSelectStatusHold;
int rangeDisplayCall;
int colorPickStatusHold;
int colorPickStatusCall;
int listModeStatusHold;
double *listDataHold;
int listDataCount;
int blurCutHold;
int mergeRStatusHold;
int mergeGStatusHold;
int mergeBStatusHold;
int displayOrderHold;

@implementation Controller

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSString *currentDirectoryPathNSString = [[NSBundle mainBundle] bundlePath];
        string userPathNameString = [currentDirectoryPathNSString cStringUsingEncoding:NSUTF8StringEncoding];
        
        if (userPathNameString.length() == 0) exit (0);
        else if ((int)userPathNameString.find("/Users/") == -1) exit (0);
        else{
            
            string pathName2 = userPathNameString.substr((unsigned long)userPathNameString.find("/Users/")+7);
            pathNameString = pathName2.substr(0, (unsigned long)pathName2.find("/"));
        }
        
        analysisNameHold = "";
        treatNameHold = "";
        
        arrayDirectoryInfo = new string [100];
        directoryInfoCount = 0;
        directoryInfoLimit = 100;
        
        imageLoadStatus = 0;
        levelHoldContrast = 1;
        levelHoldBrightness = 0;
        levelHoldBlur = 0;
        levelHoldRed = 0;
        levelHoldGreen = 0;
        levelHoldBlue = 0;
        cutRedHold = 0;
        cutGreenHold = 0;
        cutBlueHold = 0;
        levelHoldRedPick = 0;
        levelHoldGreenPick = 0;
        levelHoldBluePick = 0;
        cutRedHoldPick = 10;
        cutGreenHoldPick = 10;
        cutBlueHoldPick = 10;
        tableDisplayCall = 0;
        productDisplayCall = 0;
        progressTiming = 0;
        copyProgressFlag = 0;
        
        initialArraySet = 0;
        imageDimensionH = 0;
        imageDimensionW = 0;
        imageBitHold = 0;
        photoMetricsHold = 0;
        samplePerPixHold = 0;
        
        stitchedImageDimension = 0;
        imageDisplayCall = 0;
        processingFovNo = 0;
        autoValueHold = 100;
        totalRGBHold = 0;
        
        currentListName = "";
        currentListNumber = "";
        
        currentImageName = "";
        imageDataHoldStatus = 0;
        imageRangeAdjustStatus = 0;
        imageFLStatus = "Lock";
        contrastLockRelease = 0;
        
        warningSet = 0;
        cursorRedMax = -1;
        cursorGreenMax = -1;
        cursorBlueMax = -1;
        cursorRedMin = -1;
        cursorGreenMin = -1;
        cursorBlueMin = -1;
        colorSelectStatusHold = 0;
        rangeDisplayCall = 0;
        colorPickStatusHold = 0;
        colorPickStatusCall = 0;
        listModeStatusHold = 0;
        blurCutHold = 0;
        mergeRStatusHold = 0;
        mergeGStatusHold = 0;
        mergeBStatusHold = 0;
        displayOrderHold = 0;
        
        treatListCallCount = 0;
        tableCurrentRowHold = 0;
        rowIndexHold = 0;
        currentNoOfImage = 0;
        sliderStart = 0;
        sliderEnd = 0;
        mapLoadHold = 0;
        
        sliderContrastMax = 5;
        sliderContrastMin = 0.01;
        sliderContrastDiff = 4.99;
        sliderBrightnessMax = 255;
        sliderBrightnessMin = 0;
        sliderBrightnessDiff = 255;
        
        sliderRedMax = 255;
        sliderRedMin = 0;
        sliderRedDiff = 255;
        sliderGreenMax = 255;
        sliderGreenMin = 0;
        sliderGreenDiff = 255;
        sliderBlueMax = 255;
        sliderBlueMin = 0;
        sliderBlueDiff = 255;
        
        sliderCutRedMax = 255;
        sliderCutRedMin = 0;
        sliderCutRedDiff = 255;
        sliderCutGreenMax = 255;
        sliderCutGreenMin = 0;
        sliderCutGreenDiff = 255;
        sliderCutBlueMax = 255;
        sliderCutBlueMin = 0;
        sliderCutBlueDiff = 255;
    }
    
    return self;
}

-(void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat xLength = screenRect.size.width;
    CGFloat yLength = screenRect.size.height;
    
    int mainControllerX = 800;
    
    NSRect windowSize = [controllerWindow frame];
    CGFloat windowWidth = windowSize.size.width;
    CGFloat windowHeight = windowSize.size.height;
    
    int displayPositionType = 0;
    
    if (80+mainControllerX+5+windowWidth+5+80 > xLength) displayPositionType = 1;
    
    CGFloat displayX;
    
    if (displayPositionType == 1) displayX = 550;
    else displayX = 80+mainControllerX+5;
    
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [controllerWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    imageDataPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files";
    
    [listBrowser setTarget:self];
    [listBrowser setDoubleAction:@selector(browserDoubleClick:)];
    
    [tableList setDataSource:self];
    
    for (NSTableColumn* column in [tableList tableColumns]) {
        if ([[column identifier] isEqualToString:@"COL1"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"Name" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL2"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"No. files" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
    }
}

-(void)applicationDidFinishLaunching:(NSNotification*)notification{
    tableListPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/TableList";
    
    tableListHold = new string [1000];
    tableListHoldCount = 0;
    tableListHoldLimit = 1000;
    
    //set status (0 no, 1 set), product folder name, list name, no of files, 11--99, if empty, nil or number
    
    currentListInformation = new string [100];
    imageSetPositionList = new int [300];
    
    fileList = new string [100];
    fileListCount = 0;
    fileListLimit = 100;
    
    xyPositionData = new int [300];
    xyPositionDataOriginal = new int [300];
    xyPositionWritingData = new int [300];
    
    listDataHold = new double [500];
    
    for (int counter2 = 0; counter2 < 15; counter2++){
        listDataHold [counter2] = 0;
    }
    
    listDataCount = 1;
    
    [numberOfFilesDisplay setStringValue:@"nil"];
    [analysisNameDisplay setStringValue:@"nil"];
    [fileImageSizeDisplay setStringValue:@"nil x nil"];
    
    [contrastLevel setStringValue:@"nil"];
    [brightnessLevel setStringValue:@"nil"];
    [redLevel setStringValue:@"nil"];
    [redCut setStringValue:@"nil"];
    [greenLevel setStringValue:@"nil"];
    [greenCut setStringValue:@"nil"];
    [blueLevel setStringValue:@"nil"];
    [blueCut setStringValue:@"nil"];
    [autoValueDisplay setIntegerValue:100];
    
    [listBrowser reloadColumn:0];
    
    timerCD = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(display) userInfo:nil repeats:YES];
}

-(void)controlTextDidChange:(NSNotification *)aNotification{
    if ([[aNotification name] isEqualToString:@"NSControlTextDidChangeNotification"]){
        if ([aNotification object] == autoValueDisplay){
            if ([autoValueDisplay intValue] >= 10 && [autoValueDisplay intValue] <= 245){
                [stepperAuto setIntValue:[autoValueDisplay intValue]];
                autoValueHold = [autoValueDisplay intValue];
            }
        }
    }
}

-(void)display{
    if (treatListCallCount == 1){
        treatListCallCount = 0;
        rowIndexHold = tableCurrentRowHold;
    }
    
    if (treatListCallCount > 1) treatListCallCount = 0;
    
    if (sliderStart == 1 && sliderEnd == 0){
        sliderEnd = 1;
        sliderStart = 0;
    }
    
    if (sliderEnd == 1){
        if (sliderStart == 1) sliderStart = 0;
        else{
            
            sliderStart = 0;
            sliderEnd = 0;
            
            [self imageSlider];
        }
    }
    
    if (imageDisplayCall == 1){
        imageDisplayCall = 0;
        
        [loadFileNameDisplay setStringValue:@(currentListName.c_str())];
        [loadFileNumberDisplay setStringValue:@(currentListNumber.c_str())];
        
        [xyAssign11 setStringValue:@(currentListInformation [0].c_str())];
        [xyAssign12 setStringValue:@(currentListInformation [1].c_str())];
        [xyAssign13 setStringValue:@(currentListInformation [2].c_str())];
        [xyAssign14 setStringValue:@(currentListInformation [3].c_str())];
        [xyAssign15 setStringValue:@(currentListInformation [4].c_str())];
        [xyAssign16 setStringValue:@(currentListInformation [5].c_str())];
        [xyAssign17 setStringValue:@(currentListInformation [6].c_str())];
        [xyAssign18 setStringValue:@(currentListInformation [7].c_str())];
        [xyAssign19 setStringValue:@(currentListInformation [8].c_str())];
        
        [xyAssign21 setStringValue:@(currentListInformation [9].c_str())];
        [xyAssign22 setStringValue:@(currentListInformation [10].c_str())];
        [xyAssign23 setStringValue:@(currentListInformation [11].c_str())];
        [xyAssign24 setStringValue:@(currentListInformation [12].c_str())];
        [xyAssign25 setStringValue:@(currentListInformation [13].c_str())];
        [xyAssign26 setStringValue:@(currentListInformation [14].c_str())];
        [xyAssign27 setStringValue:@(currentListInformation [15].c_str())];
        [xyAssign28 setStringValue:@(currentListInformation [16].c_str())];
        [xyAssign29 setStringValue:@(currentListInformation [17].c_str())];
        
        [xyAssign31 setStringValue:@(currentListInformation [18].c_str())];
        [xyAssign32 setStringValue:@(currentListInformation [19].c_str())];
        [xyAssign33 setStringValue:@(currentListInformation [20].c_str())];
        [xyAssign34 setStringValue:@(currentListInformation [21].c_str())];
        [xyAssign35 setStringValue:@(currentListInformation [22].c_str())];
        [xyAssign36 setStringValue:@(currentListInformation [23].c_str())];
        [xyAssign37 setStringValue:@(currentListInformation [24].c_str())];
        [xyAssign38 setStringValue:@(currentListInformation [25].c_str())];
        [xyAssign39 setStringValue:@(currentListInformation [26].c_str())];
        
        [xyAssign41 setStringValue:@(currentListInformation [27].c_str())];
        [xyAssign42 setStringValue:@(currentListInformation [28].c_str())];
        [xyAssign43 setStringValue:@(currentListInformation [29].c_str())];
        [xyAssign44 setStringValue:@(currentListInformation [30].c_str())];
        [xyAssign45 setStringValue:@(currentListInformation [31].c_str())];
        [xyAssign46 setStringValue:@(currentListInformation [32].c_str())];
        [xyAssign47 setStringValue:@(currentListInformation [33].c_str())];
        [xyAssign48 setStringValue:@(currentListInformation [34].c_str())];
        [xyAssign49 setStringValue:@(currentListInformation [35].c_str())];
        
        [xyAssign51 setStringValue:@(currentListInformation [36].c_str())];
        [xyAssign52 setStringValue:@(currentListInformation [37].c_str())];
        [xyAssign53 setStringValue:@(currentListInformation [38].c_str())];
        [xyAssign54 setStringValue:@(currentListInformation [39].c_str())];
        [xyAssign55 setStringValue:@(currentListInformation [40].c_str())];
        [xyAssign56 setStringValue:@(currentListInformation [41].c_str())];
        [xyAssign57 setStringValue:@(currentListInformation [42].c_str())];
        [xyAssign58 setStringValue:@(currentListInformation [43].c_str())];
        [xyAssign59 setStringValue:@(currentListInformation [44].c_str())];
        
        [xyAssign61 setStringValue:@(currentListInformation [45].c_str())];
        [xyAssign62 setStringValue:@(currentListInformation [46].c_str())];
        [xyAssign63 setStringValue:@(currentListInformation [47].c_str())];
        [xyAssign64 setStringValue:@(currentListInformation [48].c_str())];
        [xyAssign65 setStringValue:@(currentListInformation [49].c_str())];
        [xyAssign66 setStringValue:@(currentListInformation [50].c_str())];
        [xyAssign67 setStringValue:@(currentListInformation [51].c_str())];
        [xyAssign68 setStringValue:@(currentListInformation [52].c_str())];
        [xyAssign69 setStringValue:@(currentListInformation [53].c_str())];
        
        [xyAssign71 setStringValue:@(currentListInformation [54].c_str())];
        [xyAssign72 setStringValue:@(currentListInformation [55].c_str())];
        [xyAssign73 setStringValue:@(currentListInformation [56].c_str())];
        [xyAssign74 setStringValue:@(currentListInformation [57].c_str())];
        [xyAssign75 setStringValue:@(currentListInformation [58].c_str())];
        [xyAssign76 setStringValue:@(currentListInformation [59].c_str())];
        [xyAssign77 setStringValue:@(currentListInformation [60].c_str())];
        [xyAssign78 setStringValue:@(currentListInformation [61].c_str())];
        [xyAssign79 setStringValue:@(currentListInformation [62].c_str())];
        
        [xyAssign81 setStringValue:@(currentListInformation [63].c_str())];
        [xyAssign82 setStringValue:@(currentListInformation [64].c_str())];
        [xyAssign83 setStringValue:@(currentListInformation [65].c_str())];
        [xyAssign84 setStringValue:@(currentListInformation [66].c_str())];
        [xyAssign85 setStringValue:@(currentListInformation [67].c_str())];
        [xyAssign86 setStringValue:@(currentListInformation [68].c_str())];
        [xyAssign87 setStringValue:@(currentListInformation [69].c_str())];
        [xyAssign88 setStringValue:@(currentListInformation [70].c_str())];
        [xyAssign89 setStringValue:@(currentListInformation [71].c_str())];
        
        [xyAssign91 setStringValue:@(currentListInformation [72].c_str())];
        [xyAssign92 setStringValue:@(currentListInformation [73].c_str())];
        [xyAssign93 setStringValue:@(currentListInformation [74].c_str())];
        [xyAssign94 setStringValue:@(currentListInformation [75].c_str())];
        [xyAssign95 setStringValue:@(currentListInformation [76].c_str())];
        [xyAssign96 setStringValue:@(currentListInformation [77].c_str())];
        [xyAssign97 setStringValue:@(currentListInformation [78].c_str())];
        [xyAssign98 setStringValue:@(currentListInformation [79].c_str())];
        [xyAssign99 setStringValue:@(currentListInformation [80].c_str())];
        
        string dimensionString = to_string(imageDimensionW)+" + "+to_string(imageDimensionH);
        
        [numberOfFilesDisplay setIntegerValue:currentNoOfImage];
        [analysisNameDisplay setStringValue:@(currentImageName.c_str())];
        [fileImageSizeDisplay setStringValue:@(dimensionString.c_str())];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
    }
    
    if (imageDisplayCall == 2){
        imageDisplayCall = 0;
        
        [loadFileNameDisplay setStringValue:@(currentListName.c_str())];
        [loadFileNumberDisplay setStringValue:@(currentListNumber.c_str())];
        
        [tableList reloadData];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
    }
    
    if (imageDisplayCall == 3){
        imageDisplayCall = 0;
        [colorPickStatusDisplay setStringValue:@"Original"];
    }
    
    if (imageDisplayCall == 4){
        imageDisplayCall = 0;
        [blurCutStatusDisplay setStringValue:@"Brightness"];
    }
    
    if (rangeDisplayCall == 1){
        rangeDisplayCall = 0;
        
        int averageR = (int)((cursorRedMin+cursorRedMax)/(double)2);
        
        string displayString = to_string(cursorRedMin)+"-"+to_string(cursorRedMax)+" Av: "+to_string(averageR);
        
        [rRangeDisplay setStringValue:@(displayString.c_str())];
        
        int averageG = (int)((cursorGreenMin+cursorGreenMax)/(double)2);
        
        displayString = to_string(cursorGreenMin)+"-"+to_string(cursorGreenMax)+" Av: "+to_string(averageG);
        
        [gRangeDisplay setStringValue:@(displayString.c_str())];
        
        int averageB = (int)((cursorBlueMin+cursorBlueMax)/(double)2);
        
        displayString = to_string(cursorBlueMin)+"-"+to_string(cursorBlueMax)+" Av: "+to_string(averageB);
        
        [bRangeDisplay setStringValue:@(displayString.c_str())];
        
        levelHoldRedPick = (double)averageR;
        levelHoldGreenPick = (double)averageG;
        levelHoldBluePick = (double)averageB;
        
        if (cursorRedMax-cursorRedMin > cutRedHoldPick) cutRedHoldPick = cursorRedMax-cursorRedMin;
        if (cursorGreenMax-cursorGreenMin > cutBlueHoldPick) cutGreenHoldPick = cursorGreenMax-cursorGreenMin;
        if (cursorBlueMax-cursorBlueMin > cutBlueHoldPick) cutBlueHoldPick = cursorBlueMax-cursorBlueMin;
        
        [sliderKnobRed setDoubleValue:levelHoldRedPick];
        [sliderKnobRedCut setDoubleValue:cutRedHoldPick];
        
        [sliderKnobGreen setDoubleValue:levelHoldGreenPick];
        [sliderKnobGreenCut setDoubleValue:cutGreenHoldPick];
        
        [sliderKnobBlue setDoubleValue:levelHoldBluePick];
        [sliderKnobBlueCut setDoubleValue:cutBlueHoldPick];
        
        [redCut setDoubleValue:cutRedHoldPick];
        [redLevel setDoubleValue:levelHoldRedPick];
        
        [greenCut setDoubleValue:cutGreenHoldPick];
        [greenLevel setDoubleValue:levelHoldGreenPick];
        
        [blueCut setDoubleValue:cutBlueHoldPick];
        [blueLevel setDoubleValue:levelHoldBluePick];
    }
    
    if (imageDisplayCall == 3){
        imageDisplayCall = 5;
        [self imageSlider];
    }
    
    if (tableDisplayCall == 1){
        tableDisplayCall = 0;
        [tableList reloadData];
    }
    
    if (productDisplayCall == 1){
        productDisplayCall = 0;
        [listBrowser reloadColumn:0];
    }
    
    if (productDisplayCall == 2){
        productDisplayCall = 0;
        [listBrowser reloadColumn:1];
    }
    
    if (progressTiming == 6){
        [backSave startAnimation:self];
        
        if (backSave) progressTiming = 7;
    }
    else if (progressTiming == 8){
        [backSave stopAnimation:self];
        
        if (backSave) progressTiming = 0;
    }
    
    if (progressTiming == 0){
        if (backSave) [backSave stopAnimation:self];
    }
    
    if (warningSet == 1){
        warningSet = 0;
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Relevant File Missing: e.g ****0001.Tif"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
        
    }
    else if (warningSet == 2){
        warningSet = 0;
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Products Folder With The Same Name Already Exists"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
    else if (warningSet == 3){
        warningSet = 0;
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Image Capture Folder Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
    else if (warningSet == 4){
        warningSet = 0;
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Unsupported Image Format: Use Single Layer, No Compression, Gray (8 or 16 bit), RGB (8 or 16 bit), or RGB+Alpha (8 or 16 bit)"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
    else if (warningSet == 5){
        warningSet = 0;
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Inconsistent Image Format"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
    else if (warningSet == 7){
        warningSet = 0;
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Number Of Images Does Not Match Set Number"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
    else if (warningSet == 8){
        warningSet = 0;
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Unsupported Image Format: Use Single Layer, No Compression, Gray (8 or 16 bit), RGB (8 or 16 bit), or RGB+Alpha (8 or 16 bit)"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
    else if (warningSet == 9){
        warningSet = 0;
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Inconsistent Image Format"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
    
    if (colorPickStatusCall == 1){
        colorPickStatusCall = 0;
        
        if (cursorRedMax != -1 && cursorGreenMax != -1 && cursorBlueMax != -1){
            [redCut setDoubleValue:cutRedHoldPick];
            [redLevel setDoubleValue:levelHoldRedPick];
            
            [sliderRed setMaxValue:sliderRedMax];
            [sliderRed setMinValue:sliderRedMin];
            [sliderRedCut setMaxValue:sliderCutRedMax];
            [sliderRedCut setMinValue:sliderCutRedMin];
            
            [sliderRed setDoubleValue:levelHoldRedPick];
            [sliderRedCut setDoubleValue:cutRedHoldPick];
            [sliderRedCircle setDoubleValue:1];
            [sliderRedCutCircle setDoubleValue:1];
            
            [sliderKnobRed setDoubleValue:levelHoldRedPick];
            [sliderKnobRedCut setDoubleValue:cutRedHoldPick];
            
            [greenCut setDoubleValue:cutGreenHoldPick];
            [greenLevel setDoubleValue:levelHoldGreenPick];
            
            [sliderGreen setMaxValue:sliderGreenMax];
            [sliderGreen setMinValue:sliderGreenMin];
            [sliderGreenCut setMaxValue:sliderCutGreenMax];
            [sliderGreenCut setMinValue:sliderCutGreenMin];
            
            [sliderGreen setDoubleValue:levelHoldGreenPick];
            [sliderGreenCut setDoubleValue:cutGreenHoldPick];
            [sliderGreenCircle setDoubleValue:1];
            [sliderGreenCutCircle setDoubleValue:1];
            
            [sliderKnobGreen setDoubleValue:levelHoldGreenPick];
            [sliderKnobGreenCut setDoubleValue:cutGreenHoldPick];
            
            [blueCut setDoubleValue:cutBlueHoldPick];
            [blueLevel setDoubleValue:levelHoldBluePick];
            
            [sliderBlue setMaxValue:sliderBlueMax];
            [sliderBlue setMinValue:sliderBlueMin];
            [sliderBlueCut setMaxValue:sliderCutBlueMax];
            [sliderBlueCut setMinValue:sliderCutBlueMin];
            
            [sliderBlue setDoubleValue:levelHoldBluePick];
            [sliderBlueCut setDoubleValue:cutBlueHoldPick];
            [sliderBlueCircle setDoubleValue:1];
            [sliderBlueCutCircle setDoubleValue:1];
            
            [sliderKnobBlue setDoubleValue:levelHoldBluePick];
            [sliderKnobBlueCut setDoubleValue:cutBlueHoldPick];
            
            int average = (int)((cursorRedMin+cursorRedMax)/(double)2);
            
            string displayString = to_string(cursorRedMin)+"-"+to_string(cursorRedMax)+" Av: "+to_string(average);
            
            [rRangeDisplay setStringValue:@(displayString.c_str())];
            
            average = (int)((cursorGreenMin+cursorGreenMax)/(double)2);
            
            displayString = to_string(cursorGreenMin)+"-"+to_string(cursorGreenMax)+" Av: "+to_string(average);
            
            [gRangeDisplay setStringValue:@(displayString.c_str())];
            
            average = (int)((cursorBlueMin+cursorBlueMax)/(double)2);
            
            displayString = to_string(cursorBlueMin)+"-"+to_string(cursorBlueMax)+" Av: "+to_string(average);
            
            [bRangeDisplay setStringValue:@(displayString.c_str())];
        }
        else{
            
            [redCut setDoubleValue:0];
            [redLevel setDoubleValue:0];
            
            [sliderRed setMaxValue:sliderRedMax];
            [sliderRed setMinValue:sliderRedMin];
            [sliderRedCut setMaxValue:sliderCutRedMax];
            [sliderRedCut setMinValue:sliderCutRedMin];
            
            [sliderRed setDoubleValue:0];
            [sliderRedCut setDoubleValue:0];
            [sliderRedCircle setDoubleValue:1];
            [sliderRedCutCircle setDoubleValue:1];
            
            [sliderKnobRed setDoubleValue:0];
            [sliderKnobRedCut setDoubleValue:0];
            
            [greenCut setDoubleValue:0];
            [greenLevel setDoubleValue:0];
            
            [sliderGreen setMaxValue:sliderGreenMax];
            [sliderGreen setMinValue:sliderGreenMin];
            [sliderGreenCut setMaxValue:sliderCutGreenMax];
            [sliderGreenCut setMinValue:sliderCutGreenMin];
            
            [sliderGreen setDoubleValue:0];
            [sliderGreenCut setDoubleValue:0];
            [sliderGreenCircle setDoubleValue:1];
            [sliderGreenCutCircle setDoubleValue:1];
            
            [sliderKnobGreen setDoubleValue:0];
            [sliderKnobGreenCut setDoubleValue:0];
            
            [blueCut setDoubleValue:0];
            [blueLevel setDoubleValue:0];
            
            [sliderBlue setMaxValue:sliderBlueMax];
            [sliderBlue setMinValue:sliderBlueMin];
            [sliderBlueCut setMaxValue:sliderCutBlueMax];
            [sliderBlueCut setMinValue:sliderCutBlueMin];
            
            [sliderBlue setDoubleValue:0];
            [sliderBlueCut setDoubleValue:0];
            [sliderBlueCircle setDoubleValue:1];
            [sliderBlueCutCircle setDoubleValue:1];
            
            [sliderKnobBlue setDoubleValue:0];
            [sliderKnobBlueCut setDoubleValue:0];
            
            string displayString = "0-0 Av: 0";
            
            [rRangeDisplay setStringValue:@(displayString.c_str())];
            [gRangeDisplay setStringValue:@(displayString.c_str())];
            [bRangeDisplay setStringValue:@(displayString.c_str())];
        }
    }
    
    if (colorPickStatusCall == 2){
        colorPickStatusCall = 0;
        
        [redCut setDoubleValue:cutRedHold];
        [redLevel setDoubleValue:levelHoldRed];
        
        [sliderRed setMaxValue:sliderRedMax];
        [sliderRed setMinValue:sliderRedMin];
        [sliderRedCut setMaxValue:sliderCutRedMax];
        [sliderRedCut setMinValue:sliderCutRedMin];
        
        [sliderRed setDoubleValue:levelHoldRed];
        [sliderRedCut setDoubleValue:cutRedHold];
        [sliderRedCircle setDoubleValue:1];
        [sliderRedCutCircle setDoubleValue:1];
        
        [sliderKnobRed setDoubleValue:levelHoldBlue];
        [sliderKnobRedCut setDoubleValue:cutBlueHold];
        
        [greenCut setDoubleValue:cutGreenHold];
        [greenLevel setDoubleValue:levelHoldGreen];
        
        [sliderGreen setMaxValue:sliderGreenMax];
        [sliderGreen setMinValue:sliderGreenMin];
        [sliderGreenCut setMaxValue:sliderCutGreenMax];
        [sliderGreenCut setMinValue:sliderCutGreenMin];
        
        [sliderGreen setDoubleValue:levelHoldGreen];
        [sliderGreenCut setDoubleValue:cutGreenHold];
        [sliderGreenCircle setDoubleValue:1];
        [sliderGreenCutCircle setDoubleValue:1];
        
        [sliderKnobGreen setDoubleValue:levelHoldBlue];
        [sliderKnobGreenCut setDoubleValue:cutBlueHold];
        
        [blueCut setDoubleValue:cutBlueHold];
        [blueLevel setDoubleValue:levelHoldBlue];
        
        [sliderBlue setMaxValue:sliderBlueMax];
        [sliderBlue setMinValue:sliderBlueMin];
        [sliderBlueCut setMaxValue:sliderCutBlueMax];
        [sliderBlueCut setMinValue:sliderCutBlueMin];
        
        [sliderBlue setDoubleValue:levelHoldBlue];
        [sliderBlueCut setDoubleValue:cutBlueHold];
        [sliderBlueCircle setDoubleValue:1];
        [sliderBlueCutCircle setDoubleValue:1];
        
        [sliderKnobBlue setDoubleValue:levelHoldBlue];
        [sliderKnobBlueCut setDoubleValue:cutBlueHold];
        
        string displayString = "nil-nil Av: nil";
        
        [rRangeDisplay setStringValue:@(displayString.c_str())];
        [gRangeDisplay setStringValue:@(displayString.c_str())];
        [bRangeDisplay setStringValue:@(displayString.c_str())];
    }
    
    if (contrastLockRelease == 1){
        contrastLockRelease = 2;
        [contrastSetLockDisplay setTextColor:[NSColor redColor]];
        [contrastSetLockDisplay setStringValue:@"Lock"];
    }
    else if (contrastLockRelease == 3){
        contrastLockRelease = 0;
        [contrastSetLockDisplay setTextColor:[NSColor blackColor]];
        [contrastSetLockDisplay setStringValue:@"Allow"];
    }
}

-(void)imageSlider{
    int totalPixHold = 0;
    
    if (photoMetricsHold == 1){
        int tempValue1 = 0;
        
        if (imageFLStatus == "Lock" || (processingFovNo == 0 && imageFLStatus == "Free") || imageDisplayCall == 5){
            if (contrastLockRelease == 0){
                for (int counter2 = 0; counter2 < fileListCount; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionH; counter3++){
                        for (int counter4 = 0; counter4 < imageDimensionW; counter4++){
                            if ((int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4]*(double)levelHoldContrast) > 255) tempValue1 = 255;
                            else tempValue1 = (int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4]*(double)levelHoldContrast);
                            
                            if ((int)(tempValue1+levelHoldBrightness) > 255) tempValue1 = 255;
                            else tempValue1 = (int)(tempValue1+levelHoldBrightness);
                            
                            arrayImageResults [counter2*imageDimensionH+counter3][counter4] = tempValue1;
                            imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]+counter4] = tempValue1;
                        }
                    }
                }
            }
        }
        else{
            
            int newXPosition = xyPositionWritingData [(processingFovNo-1)*3+2];
            int newYPosition = xyPositionWritingData [(processingFovNo-1)*3+1];
            
            int yImageCount = 0;
            int xImageCount = 0;
            
            for (int counter1 = newYPosition; counter1 < newYPosition+imageDimensionH; counter1++){
                for (int counter2 = newXPosition; counter2 < newXPosition+imageDimensionW; counter2++){
                    if ((int)(arrayImageDataHold [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount]*(double)levelHoldContrast) > 255) tempValue1 = 255;
                    else tempValue1 = (int)(arrayImageDataHold [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount]*(double)levelHoldContrast);
                    
                    if ((int)(tempValue1+levelHoldBrightness) > 255) tempValue1 = 255;
                    else tempValue1 = (int)(tempValue1+levelHoldBrightness);
                    
                    arrayImageResults [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount] = tempValue1;
                    imageDisplayArray [counter1][counter2] = tempValue1;
                    
                    xImageCount++;
                }
                
                yImageCount++;
                xImageCount = 0;
            }
        }
    }
    else if (photoMetricsHold == 2){
        int tempValue1 = 0;
        int tempValue2 = 0;
        int tempValue3 = 0;
        
        totalPixHold = 0;
        
        if (imageFLStatus == "Lock" || (processingFovNo == 0 && imageFLStatus == "Free") || imageDisplayCall == 5){
            if (contrastLockRelease == 0){
                for (int counter2 = 0; counter2 < fileListCount; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionH; counter3++){
                        for (int counter4 = 0; counter4 < imageDimensionW*3; counter4 = counter4+3){
                            if ((int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4]*(double)levelHoldContrast) > 255) tempValue1 = 255;
                            else tempValue1 = (int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4]*(double)levelHoldContrast);
                            
                            if ((int)(tempValue1+levelHoldBrightness) > 255) tempValue1 = 255;
                            else tempValue1 = (int)(tempValue1+levelHoldBrightness);
                            
                            if (tempValue1 > cutRedHold){
                                if ((int)(tempValue1+levelHoldRed) > 255) tempValue1 = 255;
                                else tempValue1 = (int)(tempValue1+levelHoldRed);
                            }
                            
                            if ((int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4+1]*(double)levelHoldContrast) > 255) tempValue2 = 255;
                            else tempValue2 = (int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4+1]*(double)levelHoldContrast);
                            
                            if ((int)(tempValue2+levelHoldBrightness) > 255) tempValue2 = 255;
                            else tempValue2 = (int)(tempValue2+levelHoldBrightness);
                            
                            if (tempValue2 > cutGreenHold){
                                if ((int)(tempValue2+levelHoldGreen) > 255) tempValue2 = 255;
                                else tempValue2 = (int)(tempValue2+levelHoldGreen);
                            }
                            
                            if ((int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4+2]*(double)levelHoldContrast) > 255) tempValue3 = 255;
                            else tempValue3 = (int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4+2]*(double)levelHoldContrast);
                            
                            if ((int)(tempValue3+levelHoldBrightness) > 255) tempValue3 = 255;
                            else tempValue3 = (int)(tempValue3+levelHoldBrightness);
                            
                            if (tempValue3 > cutBlueHold){
                                if ((int)(tempValue3+levelHoldBlue) > 255) tempValue3 = 255;
                                else tempValue3 = (int)(tempValue3+levelHoldBlue);
                            }
                            
                            if (colorSelectStatusHold == 1){
                                if (tempValue1 <= levelHoldRedPick-cutRedHoldPick || tempValue1 > levelHoldRedPick+cutRedHoldPick || tempValue2 <= levelHoldGreenPick-cutGreenHoldPick || tempValue2 > levelHoldGreenPick+cutGreenHoldPick || tempValue3 <= levelHoldBluePick-cutBlueHoldPick || tempValue3 > levelHoldBluePick+cutBlueHoldPick){
                                    tempValue1 = 0;
                                    tempValue2 = 0;
                                    tempValue3 = 0;
                                }
                                else totalPixHold++;
                            }
                            
                            arrayImageResults [counter2*imageDimensionH+counter3][counter4] = tempValue1;
                            arrayImageResults [counter2*imageDimensionH+counter3][counter4+1] = tempValue2;
                            arrayImageResults [counter2*imageDimensionH+counter3][counter4+2] = tempValue3;
                            
                            imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4] = tempValue1;
                            imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4+1] = tempValue2;
                            imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4+2] = tempValue3;
                        }
                    }
                }
            }
        }
        else{
            
            int newXPosition = xyPositionWritingData [(processingFovNo-1)*3+2];
            int newYPosition = xyPositionWritingData [(processingFovNo-1)*3+1];
            
            int yImageCount = 0;
            int xImageCount = 0;
            
            totalPixHold = 0;
            
            for (int counter1 = newYPosition; counter1 < newYPosition+imageDimensionH; counter1++){
                for (int counter2 = newXPosition*3; counter2 < newXPosition*3+imageDimensionW*3; counter2 = counter2+3){
                    if ((int)(arrayImageDataHold [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount]*(double)levelHoldContrast) > 255) tempValue1 = 255;
                    else tempValue1 = (int)(arrayImageDataHold [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount]*(double)levelHoldContrast);
                    
                    if ((int)(tempValue1+levelHoldBrightness) > 255) tempValue1 = 255;
                    else tempValue1 = (int)(tempValue1+levelHoldBrightness);
                    
                    if (tempValue1 > cutRedHold){
                        if ((int)(tempValue1+levelHoldRed) > 255) tempValue1 = 255;
                        else tempValue1 = (int)(tempValue1+levelHoldRed);
                    }
                    
                    if ((int)(arrayImageDataHold [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+1]*(double)levelHoldContrast) > 255) tempValue2 = 255;
                    else tempValue2 = (int)(arrayImageDataHold [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+1]*(double)levelHoldContrast);
                    
                    if ((int)(tempValue2+levelHoldBrightness) > 255) tempValue2 = 255;
                    else tempValue2 = (int)(tempValue2+levelHoldBrightness);
                    
                    if (tempValue2 > cutGreenHold){
                        if ((int)(tempValue2+levelHoldGreen) > 255) tempValue2 = 255;
                        else tempValue2 = (int)(tempValue2+levelHoldGreen);
                    }
                    
                    if ((int)(arrayImageDataHold [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+2]*(double)levelHoldContrast) > 255) tempValue3 = 255;
                    else tempValue3 = (int)(arrayImageDataHold [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+2]*(double)levelHoldContrast);
                    
                    if ((int)(tempValue3+levelHoldBrightness) > 255) tempValue3 = 255;
                    else tempValue3 = (int)(tempValue3+levelHoldBrightness);
                    
                    if (tempValue3 > cutBlueHold){
                        if ((int)(tempValue3+levelHoldBlue) > 255) tempValue3 = 255;
                        else tempValue3 = (int)(tempValue3+levelHoldBlue);
                    }
                    
                    if (colorSelectStatusHold == 1){
                        if (tempValue1 <= levelHoldRedPick-cutRedHoldPick || tempValue1 > levelHoldRedPick+cutRedHoldPick || tempValue2 <= levelHoldGreenPick-cutGreenHoldPick || tempValue2 > levelHoldGreenPick+cutGreenHoldPick || tempValue3 <= levelHoldBluePick-cutBlueHoldPick || tempValue3 > levelHoldBluePick+cutBlueHoldPick){
                            tempValue1 = 0;
                            tempValue2 = 0;
                            tempValue3 = 0;
                        }
                        else totalPixHold++;
                    }
                    
                    arrayImageResults [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount] = tempValue1;
                    arrayImageResults [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+1] = tempValue2;
                    arrayImageResults [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+2] = tempValue3;
                    
                    imageDisplayArray [counter1][counter2] = tempValue1;
                    imageDisplayArray [counter1][counter2+1] = tempValue2;
                    imageDisplayArray [counter1][counter2+2] = tempValue3;
                    
                    xImageCount = xImageCount+3;
                }
                
                yImageCount++;
                xImageCount = 0;
            }
        }
    }
    
    [totalPixDisplay setIntegerValue: totalPixHold];
    
    imageDisplayCall = 0;
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
}

-(int)numberOfRowsInTableView:(NSTableView *)aTableView{
    int tableViewContent = tableListHoldCount;
    return tableViewContent;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    NSAttributedString *attrStr;
    
    if (initialArraySet == 1){
        string displayData1 = tableListHold [rowIndex*85+2];
        string displayData2 = tableListHold [rowIndex*85+3];
        
        int setStatus = atoi(tableListHold [rowIndex*85].c_str());
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]){
            if (setStatus == 1){
                [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
            }
            else{
                
                [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
            }
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]){
            if (setStatus == 1){
                [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(displayData2.c_str()) attributes:attributes];
            }
            else{
                
                [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(displayData2.c_str()) attributes:attributes];
            }
        }
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    else{
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    
    return attrStr;
}

-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex{
    treatListCallCount++;
    tableCurrentRowHold = rowIndex;
    
    if (treatListCallCount == 2){
        tableCurrentRowHold = rowIndexHold;
        
        currentListName = tableListHold [tableCurrentRowHold*85+2];
        currentListNumber = tableListHold [tableCurrentRowHold*85+3];
        
        [loadFileNameDisplay setStringValue:@(currentListName.c_str())];
        [loadFileNumberDisplay setStringValue:@(currentListNumber.c_str())];
        
        if (tableListHold [tableCurrentRowHold*85] == "1"){;
            for (int counter1 = 0; counter1 < 81; counter1++){
                if (tableListHold [tableCurrentRowHold*85+counter1+4] == "nil"){
                    currentListInformation [counter1] = "";
                }
                else currentListInformation [counter1] = tableListHold [tableCurrentRowHold*84+counter1+4];
            }
        }
        else{
            
            for (int counter1 = 0; counter1 < 81; counter1++) currentListInformation [counter1] = "";
        }
        
        [xyAssign11 setStringValue:@(currentListInformation [0].c_str())];
        [xyAssign12 setStringValue:@(currentListInformation [1].c_str())];
        [xyAssign13 setStringValue:@(currentListInformation [2].c_str())];
        [xyAssign14 setStringValue:@(currentListInformation [3].c_str())];
        [xyAssign15 setStringValue:@(currentListInformation [4].c_str())];
        [xyAssign16 setStringValue:@(currentListInformation [5].c_str())];
        [xyAssign17 setStringValue:@(currentListInformation [6].c_str())];
        [xyAssign18 setStringValue:@(currentListInformation [7].c_str())];
        [xyAssign19 setStringValue:@(currentListInformation [8].c_str())];
        
        [xyAssign21 setStringValue:@(currentListInformation [9].c_str())];
        [xyAssign22 setStringValue:@(currentListInformation [10].c_str())];
        [xyAssign23 setStringValue:@(currentListInformation [11].c_str())];
        [xyAssign24 setStringValue:@(currentListInformation [12].c_str())];
        [xyAssign25 setStringValue:@(currentListInformation [13].c_str())];
        [xyAssign26 setStringValue:@(currentListInformation [14].c_str())];
        [xyAssign27 setStringValue:@(currentListInformation [15].c_str())];
        [xyAssign28 setStringValue:@(currentListInformation [16].c_str())];
        [xyAssign29 setStringValue:@(currentListInformation [17].c_str())];
        
        [xyAssign31 setStringValue:@(currentListInformation [18].c_str())];
        [xyAssign32 setStringValue:@(currentListInformation [19].c_str())];
        [xyAssign33 setStringValue:@(currentListInformation [20].c_str())];
        [xyAssign34 setStringValue:@(currentListInformation [21].c_str())];
        [xyAssign35 setStringValue:@(currentListInformation [22].c_str())];
        [xyAssign36 setStringValue:@(currentListInformation [23].c_str())];
        [xyAssign37 setStringValue:@(currentListInformation [24].c_str())];
        [xyAssign38 setStringValue:@(currentListInformation [25].c_str())];
        [xyAssign39 setStringValue:@(currentListInformation [26].c_str())];
        
        [xyAssign41 setStringValue:@(currentListInformation [27].c_str())];
        [xyAssign42 setStringValue:@(currentListInformation [28].c_str())];
        [xyAssign43 setStringValue:@(currentListInformation [29].c_str())];
        [xyAssign44 setStringValue:@(currentListInformation [30].c_str())];
        [xyAssign45 setStringValue:@(currentListInformation [31].c_str())];
        [xyAssign46 setStringValue:@(currentListInformation [32].c_str())];
        [xyAssign47 setStringValue:@(currentListInformation [33].c_str())];
        [xyAssign48 setStringValue:@(currentListInformation [34].c_str())];
        [xyAssign49 setStringValue:@(currentListInformation [35].c_str())];
        
        [xyAssign51 setStringValue:@(currentListInformation [36].c_str())];
        [xyAssign52 setStringValue:@(currentListInformation [37].c_str())];
        [xyAssign53 setStringValue:@(currentListInformation [38].c_str())];
        [xyAssign54 setStringValue:@(currentListInformation [39].c_str())];
        [xyAssign55 setStringValue:@(currentListInformation [40].c_str())];
        [xyAssign56 setStringValue:@(currentListInformation [41].c_str())];
        [xyAssign57 setStringValue:@(currentListInformation [42].c_str())];
        [xyAssign58 setStringValue:@(currentListInformation [43].c_str())];
        [xyAssign59 setStringValue:@(currentListInformation [44].c_str())];
        
        [xyAssign61 setStringValue:@(currentListInformation [45].c_str())];
        [xyAssign62 setStringValue:@(currentListInformation [46].c_str())];
        [xyAssign63 setStringValue:@(currentListInformation [47].c_str())];
        [xyAssign64 setStringValue:@(currentListInformation [48].c_str())];
        [xyAssign65 setStringValue:@(currentListInformation [49].c_str())];
        [xyAssign66 setStringValue:@(currentListInformation [50].c_str())];
        [xyAssign67 setStringValue:@(currentListInformation [51].c_str())];
        [xyAssign68 setStringValue:@(currentListInformation [52].c_str())];
        [xyAssign69 setStringValue:@(currentListInformation [53].c_str())];
        
        [xyAssign71 setStringValue:@(currentListInformation [54].c_str())];
        [xyAssign72 setStringValue:@(currentListInformation [55].c_str())];
        [xyAssign73 setStringValue:@(currentListInformation [56].c_str())];
        [xyAssign74 setStringValue:@(currentListInformation [57].c_str())];
        [xyAssign75 setStringValue:@(currentListInformation [58].c_str())];
        [xyAssign76 setStringValue:@(currentListInformation [59].c_str())];
        [xyAssign77 setStringValue:@(currentListInformation [60].c_str())];
        [xyAssign78 setStringValue:@(currentListInformation [61].c_str())];
        [xyAssign79 setStringValue:@(currentListInformation [62].c_str())];
        
        [xyAssign81 setStringValue:@(currentListInformation [63].c_str())];
        [xyAssign82 setStringValue:@(currentListInformation [64].c_str())];
        [xyAssign83 setStringValue:@(currentListInformation [65].c_str())];
        [xyAssign84 setStringValue:@(currentListInformation [66].c_str())];
        [xyAssign85 setStringValue:@(currentListInformation [67].c_str())];
        [xyAssign86 setStringValue:@(currentListInformation [68].c_str())];
        [xyAssign87 setStringValue:@(currentListInformation [69].c_str())];
        [xyAssign88 setStringValue:@(currentListInformation [70].c_str())];
        [xyAssign89 setStringValue:@(currentListInformation [71].c_str())];
        
        [xyAssign91 setStringValue:@(currentListInformation [72].c_str())];
        [xyAssign92 setStringValue:@(currentListInformation [73].c_str())];
        [xyAssign93 setStringValue:@(currentListInformation [74].c_str())];
        [xyAssign94 setStringValue:@(currentListInformation [75].c_str())];
        [xyAssign95 setStringValue:@(currentListInformation [76].c_str())];
        [xyAssign96 setStringValue:@(currentListInformation [77].c_str())];
        [xyAssign97 setStringValue:@(currentListInformation [78].c_str())];
        [xyAssign98 setStringValue:@(currentListInformation [79].c_str())];
        [xyAssign99 setStringValue:@(currentListInformation [80].c_str())];
    }
    else{
        
        tableCurrentRowHold = rowIndex;
        
        currentListName = tableListHold [tableCurrentRowHold*85+2];
        currentListNumber = tableListHold [tableCurrentRowHold*85+3];
        
        [loadFileNameDisplay setStringValue:@(currentListName.c_str())];
        [loadFileNumberDisplay setStringValue:@(currentListNumber.c_str())];
        
        if (tableListHold [tableCurrentRowHold*85] == "1"){;
            for (int counter1 = 0; counter1 < 81; counter1++){
                if (tableListHold [tableCurrentRowHold*85+counter1+4] == "nil") currentListInformation [counter1] = "";
                else currentListInformation [counter1] = tableListHold [tableCurrentRowHold*85+counter1+4];
            }
        }
        else{
            
            for (int counter1 = 0; counter1 < 81; counter1++) currentListInformation [counter1] = "";
        }
        
        [xyAssign11 setStringValue:@(currentListInformation [0].c_str())];
        [xyAssign12 setStringValue:@(currentListInformation [1].c_str())];
        [xyAssign13 setStringValue:@(currentListInformation [2].c_str())];
        [xyAssign14 setStringValue:@(currentListInformation [3].c_str())];
        [xyAssign15 setStringValue:@(currentListInformation [4].c_str())];
        [xyAssign16 setStringValue:@(currentListInformation [5].c_str())];
        [xyAssign17 setStringValue:@(currentListInformation [6].c_str())];
        [xyAssign18 setStringValue:@(currentListInformation [7].c_str())];
        [xyAssign19 setStringValue:@(currentListInformation [8].c_str())];
        
        [xyAssign21 setStringValue:@(currentListInformation [9].c_str())];
        [xyAssign22 setStringValue:@(currentListInformation [10].c_str())];
        [xyAssign23 setStringValue:@(currentListInformation [11].c_str())];
        [xyAssign24 setStringValue:@(currentListInformation [12].c_str())];
        [xyAssign25 setStringValue:@(currentListInformation [13].c_str())];
        [xyAssign26 setStringValue:@(currentListInformation [14].c_str())];
        [xyAssign27 setStringValue:@(currentListInformation [15].c_str())];
        [xyAssign28 setStringValue:@(currentListInformation [16].c_str())];
        [xyAssign29 setStringValue:@(currentListInformation [17].c_str())];
        
        [xyAssign31 setStringValue:@(currentListInformation [18].c_str())];
        [xyAssign32 setStringValue:@(currentListInformation [19].c_str())];
        [xyAssign33 setStringValue:@(currentListInformation [20].c_str())];
        [xyAssign34 setStringValue:@(currentListInformation [21].c_str())];
        [xyAssign35 setStringValue:@(currentListInformation [22].c_str())];
        [xyAssign36 setStringValue:@(currentListInformation [23].c_str())];
        [xyAssign37 setStringValue:@(currentListInformation [24].c_str())];
        [xyAssign38 setStringValue:@(currentListInformation [25].c_str())];
        [xyAssign39 setStringValue:@(currentListInformation [26].c_str())];
        
        [xyAssign41 setStringValue:@(currentListInformation [27].c_str())];
        [xyAssign42 setStringValue:@(currentListInformation [28].c_str())];
        [xyAssign43 setStringValue:@(currentListInformation [29].c_str())];
        [xyAssign44 setStringValue:@(currentListInformation [30].c_str())];
        [xyAssign45 setStringValue:@(currentListInformation [31].c_str())];
        [xyAssign46 setStringValue:@(currentListInformation [32].c_str())];
        [xyAssign47 setStringValue:@(currentListInformation [33].c_str())];
        [xyAssign48 setStringValue:@(currentListInformation [34].c_str())];
        [xyAssign49 setStringValue:@(currentListInformation [35].c_str())];
        
        [xyAssign51 setStringValue:@(currentListInformation [36].c_str())];
        [xyAssign52 setStringValue:@(currentListInformation [37].c_str())];
        [xyAssign53 setStringValue:@(currentListInformation [38].c_str())];
        [xyAssign54 setStringValue:@(currentListInformation [39].c_str())];
        [xyAssign55 setStringValue:@(currentListInformation [40].c_str())];
        [xyAssign56 setStringValue:@(currentListInformation [41].c_str())];
        [xyAssign57 setStringValue:@(currentListInformation [42].c_str())];
        [xyAssign58 setStringValue:@(currentListInformation [43].c_str())];
        [xyAssign59 setStringValue:@(currentListInformation [44].c_str())];
        
        [xyAssign61 setStringValue:@(currentListInformation [45].c_str())];
        [xyAssign62 setStringValue:@(currentListInformation [46].c_str())];
        [xyAssign63 setStringValue:@(currentListInformation [47].c_str())];
        [xyAssign64 setStringValue:@(currentListInformation [48].c_str())];
        [xyAssign65 setStringValue:@(currentListInformation [49].c_str())];
        [xyAssign66 setStringValue:@(currentListInformation [50].c_str())];
        [xyAssign67 setStringValue:@(currentListInformation [51].c_str())];
        [xyAssign68 setStringValue:@(currentListInformation [52].c_str())];
        [xyAssign69 setStringValue:@(currentListInformation [53].c_str())];
        
        [xyAssign71 setStringValue:@(currentListInformation [54].c_str())];
        [xyAssign72 setStringValue:@(currentListInformation [55].c_str())];
        [xyAssign73 setStringValue:@(currentListInformation [56].c_str())];
        [xyAssign74 setStringValue:@(currentListInformation [57].c_str())];
        [xyAssign75 setStringValue:@(currentListInformation [58].c_str())];
        [xyAssign76 setStringValue:@(currentListInformation [59].c_str())];
        [xyAssign77 setStringValue:@(currentListInformation [60].c_str())];
        [xyAssign78 setStringValue:@(currentListInformation [61].c_str())];
        [xyAssign79 setStringValue:@(currentListInformation [62].c_str())];
        
        [xyAssign81 setStringValue:@(currentListInformation [63].c_str())];
        [xyAssign82 setStringValue:@(currentListInformation [64].c_str())];
        [xyAssign83 setStringValue:@(currentListInformation [65].c_str())];
        [xyAssign84 setStringValue:@(currentListInformation [66].c_str())];
        [xyAssign85 setStringValue:@(currentListInformation [67].c_str())];
        [xyAssign86 setStringValue:@(currentListInformation [68].c_str())];
        [xyAssign87 setStringValue:@(currentListInformation [69].c_str())];
        [xyAssign88 setStringValue:@(currentListInformation [70].c_str())];
        [xyAssign89 setStringValue:@(currentListInformation [71].c_str())];
        
        [xyAssign91 setStringValue:@(currentListInformation [72].c_str())];
        [xyAssign92 setStringValue:@(currentListInformation [73].c_str())];
        [xyAssign93 setStringValue:@(currentListInformation [74].c_str())];
        [xyAssign94 setStringValue:@(currentListInformation [75].c_str())];
        [xyAssign95 setStringValue:@(currentListInformation [76].c_str())];
        [xyAssign96 setStringValue:@(currentListInformation [77].c_str())];
        [xyAssign97 setStringValue:@(currentListInformation [78].c_str())];
        [xyAssign98 setStringValue:@(currentListInformation [79].c_str())];
        [xyAssign99 setStringValue:@(currentListInformation [80].c_str())];
    }
    
    return YES;
}

-(int)browser:(NSBrowser *)sender numberOfRowsInColumn:(int)column{
    directoryInfoCount = 0;
    
    DIR *dir;
    struct dirent *dent;
    
    if (column == 0){
        dir = opendir(imageDataPath.c_str());
        
        if (dir != NULL){
            string entry;
            string entry2;
            
            while((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                    if ((int)entry.find("_ProductsH") != -1){
                        if (directoryInfoCount+2 > directoryInfoLimit) [self directoryInfoUpDate];
                        
                        arrayDirectoryInfo [directoryInfoCount] = entry.substr(0, entry.find("_ProductsH")), directoryInfoCount++;
                    }
                }
            }
            
            closedir(dir);
            
            //-----Directory Sort-----
            NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
            
            for (int counter1 = 0; counter1 < directoryInfoCount; counter1++){
                [unsortedArray addObject:@(arrayDirectoryInfo [counter1].c_str())];
            }
            
            [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
            
            for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                arrayDirectoryInfo [counter1] = [unsortedArray [counter1] UTF8String];
            }
        }
    }
    
    if (column == 1){
        NSString *path;
        path = [sender path];
        
        string imageFolderPath = imageDataPath+[path UTF8String]+"_ProductsH";
        string imageFolderPath2 = "";
        string imageNameTemp = [path UTF8String];
        
        if (imageNameTemp != ""){
            imageNameTemp = imageNameTemp.substr(1);
            
            dir = opendir(imageFolderPath.c_str());
            
            if (dir != NULL){
                string entry;
                
                while((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        if ((int)entry.find("_Capture") != -1){
                            if (directoryInfoCount+2 > directoryInfoLimit) [self directoryInfoUpDate];
                            
                            arrayDirectoryInfo [directoryInfoCount] = entry.substr(0, entry.find("_Capture")), directoryInfoCount++;
                        }
                    }
                }
                
                closedir(dir);
                
                //-----Directory Sort-----
                NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                
                for (int counter1 = 0; counter1 < directoryInfoCount; counter1++){
                    [unsortedArray addObject:@(arrayDirectoryInfo [counter1].c_str())];
                }
                
                [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                
                for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                    arrayDirectoryInfo [counter1] = [unsortedArray [counter1] UTF8String];
                }
            }
        }
    }
    
    return directoryInfoCount;
}

-(void)browser:(NSBrowser *)sender willDisplayCell:(id)cell atRow:(int)row column:(int)column{
    if (column == 0){
        string folderName = arrayDirectoryInfo [row];
        [cell setStringValue: @(folderName.c_str())];
        [cell setLoaded:YES];
    }
    
    if (column == 1){
        string folderName = arrayDirectoryInfo [row];
        [cell setStringValue: @(folderName.c_str())];
        [cell setLeaf:YES];
    }
}

-(IBAction)browserDoubleClick:(id)browser{
    NSString *nodePath = [browser path];
    string nodePathString = [nodePath UTF8String];
    
    if (nodePathString != "" || copyProgressFlag == 0){
        nodePathString = nodePathString.substr(1);
        
        if ((int)nodePathString.find("/") != -1){
            analysisNameHold = nodePathString.substr(0, nodePathString.find("/"));
            treatNameHold = nodePathString.substr(nodePathString.find("/")+1);
            
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
                copyProgressFlag = 1;
                progressTiming = 6;
                
                do usleep(10);
                while (progressTiming == 6);
                
                string imageDisplayOriginalPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files/"+analysisNameHold+"_ProductsH/"+treatNameHold+"_Capture/Original";
                
                DIR *dir;
                struct dirent *dent;
                
                fileListCount = 0;
                
                dir = opendir(imageDisplayOriginalPath.c_str());
                
                if (dir != NULL){
                    string entry;
                    
                    while((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            if ((int)entry.find(".TIFF") != -1 || (int)entry.find(".Tiff") != -1 || (int)entry.find(".tiff") != -1 || (int)entry.find(".TIF") != -1 || (int)entry.find(".Tif") != -1 || (int)entry.find(".tif") != -1){
                                
                                if (fileListLimit < fileListCount+10){
                                    string *arrayUpDate = new string [fileListCount+10];
                                    
                                    for (int counter1 = 0; counter1 < fileListCount; counter1++) arrayUpDate [counter1] = fileList [counter1];
                                    
                                    delete [] fileList;
                                    fileList = new string [fileListLimit+500];
                                    fileListLimit = fileListLimit+500;
                                    
                                    for (int counter1 = 0; counter1 < fileListCount; counter1++) fileList [counter1] = arrayUpDate [counter1];
                                    delete [] arrayUpDate;
                                }
                                
                                fileList [fileListCount] = entry, fileListCount++;
                            }
                        }
                    }
                    
                    closedir(dir);
                    
                    //-----Directory Sort-----
                    NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                    
                    for (int counter1 = 0; counter1 < fileListCount; counter1++){
                        [unsortedArray addObject:@(fileList [counter1].c_str())];
                    }
                    
                    [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                    
                    for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                        fileList [counter1] = [unsortedArray [counter1] UTF8String];
                    }
                    
                    unsigned long nextAddress = 0;
                    unsigned long stripFirstAddress = 0;
                    unsigned long stripByteCountAddress = 0;
                    unsigned long headPosition = 0;
                    unsigned long stripEntry = 0;
                    long sizeForCopy = 0;
                    
                    int terminationFlag = 0;
                    int wrongFormatFind = 0;
                    int dimensionAdditionW = 0;
                    int dimensionAdditionH = 0;
                    int newImageDimensionW = 0;
                    int newImageDimensionH = 0;
                    
                    double xPosition = 0;
                    double yPosition = 0;
                    
                    int imageWidth = 0;
                    int imageHeight = 0;
                    int imageBit = 0; //Check 8, 16
                    int imageCompression = 0; //Check 1
                    int photoMetric = 0;//Check 0, 1, 2
                    int imageDimension = 0;
                    int verticalBmp = 0;
                    int horizontalBmp = 0;
                    int horizontalBmpEntry = 0;
                    int endianType = 0;
                    int samplePerPix = 0;
                    int dataConversion [4];
                    int processType = 1; //Out put image 8 bit color or gray
                    int numberOfLayers = 0;
                    
                    string imageFilePath;
                    
                    int *imageSizeArray = new int [fileListCount*2+10];
                    int *imageInformationArray = new int [fileListCount*3+10];
                    
                    for (int counter1 = 0; counter1 < fileListCount*2+10; counter1++) imageSizeArray [counter1] = 0;
                    for (int counter1 = 0; counter1 < fileListCount*3+10; counter1++) imageInformationArray [counter1] = 0;
                    
                    ifstream fin;
                    
                    struct stat sizeOfFile;
                    
                    //-----Original file Format Check-----
                    for (int counter1 = 0; counter1 < fileListCount; counter1++){
                        imageFilePath = imageDisplayOriginalPath+"/"+fileList [counter1];
                        
                        //-----File Read-----
                        if (stat(imageFilePath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            fileReadArray = new uint8_t [sizeForCopy+4];
                            fin.open(imageFilePath.c_str(), ios::in | ios::binary);
                            
                            fin.read((char*)fileReadArray, sizeForCopy+1);
                            fin.close();
                            
                            dataConversion [0] = fileReadArray [0];
                            dataConversion [1] = fileReadArray [1];
                            
                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                            else endianType = 0;
                            
                            if (endianType == 1){
                                dataConversion [0] = fileReadArray [7];
                                dataConversion [1] = fileReadArray [6];
                                dataConversion [2] = fileReadArray [5];
                                dataConversion [3] = fileReadArray [4];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            else if (endianType == 0){
                                dataConversion [0] = fileReadArray [4];
                                dataConversion [1] = fileReadArray [5];
                                dataConversion [2] = fileReadArray [6];
                                dataConversion [3] = fileReadArray [7];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            
                            if (endianType == 1){ //-----Big endian-----
                                self->tiffFileRead = [[TiffFileRead alloc] init];
                                [self->tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                            }
                            else if (endianType == 0){
                                self->tiffFileRead = [[TiffFileRead alloc] init];
                                [self->tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                            }
                            
                            //cout<<imageCompression<<" "<<imageBit<<" "<<" "<<samplePerPix<<" "<<photoMetric<<" entryinfo"<<endl;
                            
                            if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && numberOfLayers == 1 && samplePerPix <= 4 && photoMetric < 3){
                                imageInformationArray [counter1*3] = imageBit;
                                imageInformationArray [counter1*3+1] = samplePerPix;
                                imageInformationArray [counter1*3+2] = photoMetric;
                                
                                imageSizeArray [counter1*2] = imageWidth;
                                imageSizeArray [counter1*2+1] = imageHeight;
                            }
                            else wrongFormatFind = 1;
                            
                            delete [] fileReadArray;
                        }
                    }
                    
                    //For (int counterA = 0; counterA < fileListCount; counterA++){
                    //    cout<<imageInformationArray [counterA*3]<<" "<<imageInformationArray [counterA*3+1]<<" "<<imageInformationArray [counterA*3+2]<<" imageInformationArray"<<endl;
                    //}
                    
                    //For (int counterA = 0; counterA < fileListCount; counterA++){
                    //    cout<<imageSizeArray [counterA*2]<<" "<<imageSizeArray [counterA*2+1]<<" imageSizeArray"<<endl;
                    //}
                    
                    if (wrongFormatFind == 0){
                        //-----Original Image consistency Check-----
                        int horizontalOriginal = imageSizeArray [0];
                        int verticalOriginal = imageSizeArray [1];
                        
                        int imageCheck = 0;
                        
                        for (int counter1 = 0; counter1 < fileListCount; counter1++){
                            if (imageSizeArray [counter1*2] != horizontalOriginal) imageCheck = 1;
                            if (imageSizeArray [counter1*2+1] != verticalOriginal) imageCheck = 1;
                        }
                        
                        int imageBitOriginal = imageInformationArray [0];
                        int sampleBitOriginal = imageInformationArray [1];
                        int photoMetricOriginal = imageInformationArray [2];
                        
                        for (int counter1 = 0; counter1 < fileListCount; counter1++){
                            if (imageInformationArray [counter1*3] != imageBitOriginal) imageCheck = 1;
                            if (imageInformationArray [counter1*3+1] != sampleBitOriginal) imageCheck = 1;
                            if (imageInformationArray [counter1*3+2] != photoMetricOriginal) imageCheck = 1;
                        }
                        
                        if (imageCheck == 0){
                            if (initialArraySet == 0){
                                string getString;
                                
                                fin.open(tableListPath.c_str(),ios::in);
                                
                                if (fin.is_open()){
                                    do{
                                        
                                        terminationFlag = 1;
                                        
                                        if (tableListHoldCount*85+100 > tableListHoldLimit){
                                            string *arrayUpDate = new string [tableListHoldCount*85+10];
                                            
                                            for (int counter1 = 0; counter1 < tableListHoldCount*85; counter1++) arrayUpDate [counter1] = tableListHold [counter1];
                                            delete [] tableListHold;
                                            tableListHold = new string [tableListHoldLimit+1000];
                                            tableListHoldLimit = tableListHoldLimit+1000;
                                            
                                            for (int counter1 = 0; counter1 < tableListHoldCount*85; counter1++) tableListHold [counter1] = arrayUpDate [counter1];
                                            delete [] arrayUpDate;
                                        }
                                        
                                        for (int counter1 = 0; counter1 < 85; counter1++){
                                            getline(fin, getString), tableListHold [tableListHoldCount*85+counter1] = getString;
                                            
                                            if (getString == ""){
                                                terminationFlag = 0;
                                                break;
                                            }
                                        }
                                        
                                        if (terminationFlag != 0) tableListHoldCount++;
                                        
                                    } while (terminationFlag == 1);
                                    
                                    fin.close();
                                }
                                
                                initialArraySet = 1;
                            }
                            
                            //For (int counterA = 0; counterA < tableListHoldCount*85; counterA++){
                            //    cout<<tableListHold [counterA]<<" tableListHold"<<endl;
                            //}
                            
                            int matchListNo = -1;
                            
                            for (int counter1 = 0; counter1 < tableListHoldCount; counter1++){
                                if (tableListHold [counter1*85+2] == treatNameHold && tableListHold [counter1*85+1] == analysisNameHold){
                                    matchListNo = counter1;
                                    break;
                                }
                            }
                            
                            if (matchListNo == -1){
                                string *tableHoldListTemp = new string [tableListHoldCount*2+10];
                                int tableHoldListTempCount = 0;
                                
                                string productDataPath1;
                                
                                DIR *dir2;
                                struct dirent *dent2;
                                
                                dir = opendir(imageDataPath.c_str());
                                
                                if (dir != NULL){
                                    string entry2;
                                    
                                    while((dent = readdir(dir))){
                                        entry = dent -> d_name;
                                        
                                        if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("_ProductsH") != -1 && (int)entry.find(analysisNameHold) != -1){
                                            productDataPath1 = imageDataPath+"/"+entry;
                                            
                                            dir2 = opendir(productDataPath1.c_str());
                                            
                                            if (dir2 != NULL){
                                                while ((dent2 = readdir(dir2))){
                                                    entry2 = dent2 -> d_name;
                                                    
                                                    if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store" && (int)entry2.find("_Capture") != -1){
                                                        tableHoldListTemp [tableHoldListTempCount] = entry.substr(0, entry.find("_ProductsH")), tableHoldListTempCount++;
                                                        tableHoldListTemp [tableHoldListTempCount] = entry2.substr(0, entry2.find("_Capture")), tableHoldListTempCount++;
                                                    }
                                                }
                                                
                                                closedir(dir2);
                                            }
                                        }
                                    }
                                    
                                    closedir(dir);
                                }
                                
                                //For (int counterA = 0; counterA < tableHoldListTempCount/2; counterA++){
                                //    cout<<tableHoldListTemp [counterA*2] <<" "<<tableHoldListTemp [counterA*2+1]<<" tableHoldListTemp"<<endl;
                                //}
                                
                                string *tableActiveTemp = new string [tableListHoldCount*85+(tableHoldListTempCount/2)*85+100];
                                int tableActiveTempCount = 0;
                                
                                for (int counter1 = 0; counter1 < tableListHoldCount; counter1++){
                                    tableActiveTemp [tableActiveTempCount*85] = tableListHold [counter1*85];
                                    tableActiveTemp [tableActiveTempCount*85+1] = tableListHold [counter1*85+1];
                                    tableActiveTemp [tableActiveTempCount*85+2] = tableListHold [counter1*85+2];
                                    tableActiveTemp [tableActiveTempCount*85+3] = tableListHold [counter1*85+3];
                                    
                                    for (int counter2 = 0; counter2 < 81; counter2++){
                                        tableActiveTemp [tableActiveTempCount*85+counter2+4] = tableListHold [counter1*85+counter2+4];
                                    }
                                    
                                    tableActiveTempCount++;
                                }
                                
                                int matchFind = 0;
                                
                                for (int counter1 = 0; counter1 < tableHoldListTempCount/2; counter1++){
                                    matchFind = 0;
                                    
                                    for (int counter2 = 0; counter2 < tableListHoldCount; counter2++){
                                        if (tableHoldListTemp [counter1*2] == tableListHold [counter2*85+1] && tableHoldListTemp [counter1*2+1] == tableListHold [counter2*85+2]){
                                            matchFind = 1;
                                            break;
                                        }
                                    }
                                    
                                    if (matchFind == 0){
                                        tableActiveTemp [tableActiveTempCount*85] = "0";
                                        tableActiveTemp [tableActiveTempCount*85+1] = analysisNameHold;
                                        tableActiveTemp [tableActiveTempCount*85+2] = tableHoldListTemp [counter1*2+1];
                                        tableActiveTemp [tableActiveTempCount*85+3] = to_string(fileListCount);
                                        
                                        for (int counter2 = 0; counter2 < 81; counter2++){
                                            tableActiveTemp [tableActiveTempCount*85+counter2+4] = "nil";
                                        }
                                        
                                        tableActiveTempCount++;
                                    }
                                }
                                
                                //For (int counterA = 0; counterA < tableActiveTempCount*85; counterA++){
                                //    cout<<tableActiveTemp [counterA]<<" tableActiveTemp"<<endl;
                                //}
                                
                                tableListHoldCount = 0;
                                
                                for (int counter1 = 0; counter1 < tableActiveTempCount; counter1++){
                                    if (tableListHoldCount*85+100 > tableListHoldLimit){
                                        string *arrayUpDate = new string [tableListHoldCount*85+10];
                                        
                                        for (int counter2 = 0; counter2 < tableListHoldCount*85; counter2++) arrayUpDate [counter2] = tableListHold [counter2];
                                        delete [] tableListHold;
                                        tableListHold = new string [tableListHoldLimit+1000];
                                        tableListHoldLimit = tableListHoldLimit+1000;
                                        
                                        for (int counter2 = 0; counter2 < tableListHoldCount*85; counter2++) tableListHold [counter2] = arrayUpDate [counter2];
                                        delete [] arrayUpDate;
                                    }
                                    
                                    tableListHold [tableListHoldCount*85] = tableActiveTemp [counter1*85];
                                    tableListHold [tableListHoldCount*85+1] = tableActiveTemp [counter1*85+1];
                                    tableListHold [tableListHoldCount*85+2] = tableActiveTemp [counter1*85+2];
                                    tableListHold [tableListHoldCount*85+3] = tableActiveTemp [counter1*85+3];
                                    
                                    for (int counter2 = 0; counter2 < 81; counter2++){
                                        tableListHold [tableListHoldCount*85+counter2+4] = tableActiveTemp [counter1*85+counter2+4];
                                    }
                                    
                                    tableListHoldCount++;
                                }
                                
                                ofstream oin;
                                
                                oin.open(tableListPath.c_str(), ios::out);
                                
                                for (int counter1 = 0; counter1 < tableListHoldCount*85; counter1++) oin<<tableListHold [counter1]<<endl;
                                
                                oin.close();
                                
                                delete [] tableHoldListTemp;
                                delete [] tableActiveTemp;
                                
                                matchListNo = -1;
                                
                                for (int counter1 = 0; counter1 < tableListHoldCount; counter1++){
                                    if (tableListHold [counter1*85+2] == treatNameHold && tableListHold [counter1*85+1] == analysisNameHold){
                                        matchListNo = counter1;
                                        break;
                                    }
                                }
                            }
                            
                            currentListName = tableListHold [matchListNo*85+2];
                            currentListNumber = tableListHold [matchListNo*85+3];
                            
                            if (tableListHold [matchListNo*85] == "1"){;
                                for (int counter1 = 0; counter1 < 81; counter1++){
                                    if (tableListHold [matchListNo*85+counter1+4] == "nil") currentListInformation [counter1] = "";
                                    else currentListInformation [counter1] = tableListHold [matchListNo*85+counter1+4];
                                }
                            }
                            else{
                                
                                for (int counter1 = 0; counter1 < 81; counter1++) currentListInformation [counter1] = "";
                            }
                            
                            if (imageDataHoldStatus == 1){
                                for (int counter1 = 0; counter1 < (imageDimensionH+3)*self->currentNoOfImage+20; counter1++){
                                    delete [] arrayImageDataHold [counter1];
                                    delete [] arrayImageOriginal [counter1];
                                    delete [] arrayImageResults [counter1];
                                }
                                
                                delete [] arrayImageDataHold;
                                delete [] arrayImageOriginal;
                                delete [] arrayImageResults;
                            }
                            
                            //-----Image information set to Globals-----
                            currentImageName = treatNameHold;
                            self->currentNoOfImage = fileListCount;
                            
                            imageDimensionH = verticalOriginal;
                            imageDimensionW = horizontalOriginal;
                            
                            imageBitHold = imageBit;
                            photoMetricsHold = photoMetricOriginal;
                            samplePerPixHold = sampleBitOriginal;
                            
                            if (samplePerPixHold == 3 || samplePerPixHold == 4) samplePerPixHold = 3;
                            else samplePerPixHold = 1;
                            
                            if (photoMetricsHold <= 1) photoMetricsHold = 1;
                            
                            imageBitHold = 8;
                            
                            arrayImageDataHold = new int *[(imageDimensionH+3)*self->currentNoOfImage+20];
                            arrayImageOriginal = new int *[(imageDimensionH+3)*self->currentNoOfImage+20];
                            arrayImageResults = new int *[(imageDimensionH+3)*self->currentNoOfImage+20];
                            
                            //-----Array size set, Gray (8 or 16 bit) processed as 1 byte per pix, RGB (8 or 16 bit) processed as 3 bytes per sample
                            if (photoMetricsHold <= 1){
                                for (int counter2 = 0; counter2 < (imageDimensionH+3)*fileListCount+20; counter2++){
                                    arrayImageDataHold [counter2] = new int [imageDimensionW+20];
                                    arrayImageOriginal [counter2] = new int [imageDimensionW+20];
                                    arrayImageResults [counter2] = new int [imageDimensionW+20];
                                }
                            }
                            else if (photoMetricsHold == 2){
                                for (int counter2 = 0; counter2 < (imageDimensionH+3)*fileListCount+20; counter2++){
                                    arrayImageDataHold [counter2] = new int [imageDimensionW*3+20];
                                    arrayImageOriginal [counter2] = new int [imageDimensionW*3+20];
                                    arrayImageResults [counter2] = new int [imageDimensionW*3+20];
                                }
                            }
                            
                            if (imageDataHoldStatus == 0) imageDataHoldStatus = 1;
                            
                            for (int counter1 = 0; counter1 < fileListCount; counter1++){
                                xyPositionData [counter1*3] = 0;
                                xyPositionData [counter1*3+1] = 0;
                                xyPositionData [counter1*3+2] = 0;
                                
                                xyPositionDataOriginal [counter1*3] = 0;
                                xyPositionDataOriginal [counter1*3+1] = 0;
                                xyPositionDataOriginal [counter1*3+2] = 0;
                            }
                            
                            //-----Current Image Load-----
                            string imageDisplayCurrentPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files/"+analysisNameHold+"_ProductsH/"+treatNameHold+"_Capture/Current";
                            
                            for (int counter1 = 0; counter1 < fileListCount; counter1++){
                                imageFilePath = imageDisplayCurrentPath+"/"+fileList [counter1];
                                
                                xyPositionData [counter1*3] = atoi(fileList [counter1].substr(fileList [counter1].find(".tif")-4, 4).c_str());
                                
                                if (stat(imageFilePath.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                    
                                    fileReadArray = new uint8_t [sizeForCopy+4];
                                    fin.open(imageFilePath.c_str(), ios::in | ios::binary);
                                    
                                    fin.read((char*)fileReadArray, sizeForCopy+1);
                                    fin.close();
                                    
                                    dataConversion [0] = fileReadArray [0];
                                    dataConversion [1] = fileReadArray [1];
                                    
                                    if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                    else endianType = 0;
                                    
                                    if (endianType == 1){
                                        dataConversion [0] = fileReadArray [7];
                                        dataConversion [1] = fileReadArray [6];
                                        dataConversion [2] = fileReadArray [5];
                                        dataConversion [3] = fileReadArray [4];
                                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                    }
                                    else if (endianType == 0){
                                        dataConversion [0] = fileReadArray [4];
                                        dataConversion [1] = fileReadArray [5];
                                        dataConversion [2] = fileReadArray [6];
                                        dataConversion [3] = fileReadArray [7];
                                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                    }
                                    
                                    int *arrayExtractedImage3 = new int [100];
                                    
                                    if (endianType == 1){
                                        self->tiffFileRead = [[TiffFileRead alloc] init];
                                        [self->tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                        
                                        xyPositionData [counter1*3+2] = (int)xPosition;
                                        xyPositionData [counter1*3+1] = (int)yPosition;
                                        
                                        if (imageDimensionW > imageDimensionH) imageDimension = imageDimensionW;
                                        else imageDimension = imageDimensionH;
                                        
                                        self->tiffFileRead = [[TiffFileRead alloc] init];
                                        delete [] arrayExtractedImage3;
                                        
                                        arrayExtractedImage3 = [self->tiffFileRead imageSetBigEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                    }
                                    else if (endianType == 0){
                                        self->tiffFileRead = [[TiffFileRead alloc] init];
                                        [self->tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                        
                                        xyPositionData [counter1*3+2] = (int)xPosition;
                                        xyPositionData [counter1*3+1] = (int)yPosition;
                                        
                                        if (imageDimensionW > imageDimensionH) imageDimension = imageDimensionW;
                                        else imageDimension = imageDimensionH;
                                        
                                        self->tiffFileRead = [[TiffFileRead alloc] init];
                                        delete [] arrayExtractedImage3;
                                        
                                        arrayExtractedImage3 = [self->tiffFileRead imageSetLittleEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                    }
                                    
                                    dimensionAdditionW = imageDimensionW%4;
                                    
                                    if (dimensionAdditionW == 1) dimensionAdditionW = 3;
                                    else if (dimensionAdditionW == 2) dimensionAdditionW = 2;
                                    else if (dimensionAdditionW == 3) dimensionAdditionW = 1;
                                    
                                    newImageDimensionW = imageDimensionW+dimensionAdditionW;
                                    
                                    dimensionAdditionH = imageDimensionH%4;
                                    
                                    if (dimensionAdditionH == 1) dimensionAdditionH = 3;
                                    else if (dimensionAdditionH == 2) dimensionAdditionH = 2;
                                    else if (dimensionAdditionH == 3) dimensionAdditionH = 1;
                                    
                                    newImageDimensionH = imageDimensionH+dimensionAdditionH;
                                    horizontalBmp = 0;
                                    horizontalBmpEntry = 0;
                                    
                                    for (int counter3 = 0; counter3 < imageDimensionW*imageDimensionH; counter3++){
                                        if (photoMetricsHold == 1){
                                            if (horizontalBmp < imageDimensionW){
                                                arrayImageDataHold [verticalBmp][horizontalBmpEntry] = arrayExtractedImage3 [counter3], horizontalBmpEntry++;
                                                horizontalBmp++;
                                            }
                                            
                                            if (horizontalBmp == imageDimensionW){
                                                if (imageDimensionW < newImageDimensionW){
                                                    for (int counter4 = 0; counter4 < newImageDimensionW-imageDimensionW; counter4++){
                                                        arrayImageDataHold [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                    }
                                                }
                                                
                                                horizontalBmp = 0;
                                                horizontalBmpEntry = 0;
                                                verticalBmp++;
                                            }
                                        }
                                        else if (photoMetricsHold == 2){
                                            if (horizontalBmp < imageDimensionW){
                                                arrayImageDataHold [verticalBmp][horizontalBmpEntry] = arrayExtractedImage3 [counter3*3], horizontalBmpEntry++;
                                                arrayImageDataHold [verticalBmp][horizontalBmpEntry] = arrayExtractedImage3 [counter3*3+1], horizontalBmpEntry++;
                                                arrayImageDataHold [verticalBmp][horizontalBmpEntry] = arrayExtractedImage3 [counter3*3+2], horizontalBmpEntry++;
                                                horizontalBmp++;
                                            }
                                            
                                            if (horizontalBmp == imageDimensionW){
                                                if (imageDimensionW < newImageDimensionW){
                                                    for (int counter4 = 0; counter4 < newImageDimensionW-imageDimensionW; counter4++){
                                                        arrayImageDataHold [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                        arrayImageDataHold [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                        arrayImageDataHold [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                    }
                                                }
                                                
                                                horizontalBmp = 0;
                                                horizontalBmpEntry = 0;
                                                verticalBmp++;
                                            }
                                        }
                                    }
                                    
                                    if (photoMetricsHold == 1){
                                        if (imageDimensionH < newImageDimensionH){
                                            for (int counter3 = imageDimensionH; counter3 < newImageDimensionH; counter3++){
                                                horizontalBmpEntry = 0;
                                                
                                                for (int counter4 = 0; counter4 < newImageDimensionW; counter4++){
                                                    arrayImageDataHold [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                }
                                                
                                                verticalBmp++;
                                            }
                                        }
                                    }
                                    else if (photoMetricsHold == 2){
                                        if (imageDimensionH < newImageDimensionH){
                                            for (int counter3 = imageDimensionH; counter3 < newImageDimensionH; counter3++){
                                                horizontalBmpEntry = 0;
                                                
                                                for (int counter4 = 0; counter4 < newImageDimensionW; counter4++){
                                                    arrayImageDataHold [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                    arrayImageDataHold [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                    arrayImageDataHold [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                }
                                                
                                                verticalBmp++;
                                            }
                                        }
                                    }
                                    
                                    delete [] fileReadArray;
                                    delete [] arrayExtractedImage3;
                                }
                            }
                            
                            //-----Original load to arrayImageOriginal-----
                            verticalBmp = 0;
                            
                            for (int counter1 = 0; counter1 < fileListCount; counter1++){
                                imageFilePath = imageDisplayOriginalPath+"/"+fileList [counter1];
                                
                                xyPositionDataOriginal [counter1*3] = atoi(fileList [counter1].substr(fileList [counter1].find(".tif")-4, 4).c_str());
                                
                                if (stat(imageFilePath.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                    
                                    fileReadArray = new uint8_t [sizeForCopy+4];
                                    fin.open(imageFilePath.c_str(), ios::in | ios::binary);
                                    
                                    fin.read((char*)fileReadArray, sizeForCopy+1);
                                    fin.close();
                                    
                                    dataConversion [0] = fileReadArray [0];
                                    dataConversion [1] = fileReadArray [1];
                                    
                                    if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                    else endianType = 0;
                                    
                                    if (endianType == 1){
                                        dataConversion [0] = fileReadArray [7];
                                        dataConversion [1] = fileReadArray [6];
                                        dataConversion [2] = fileReadArray [5];
                                        dataConversion [3] = fileReadArray [4];
                                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                    }
                                    else if (endianType == 0){
                                        dataConversion [0] = fileReadArray [4];
                                        dataConversion [1] = fileReadArray [5];
                                        dataConversion [2] = fileReadArray [6];
                                        dataConversion [3] = fileReadArray [7];
                                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                    }
                                    
                                    int *arrayExtractedImage3 = new int [100];
                                    
                                    if (endianType == 1){
                                        self->tiffFileRead = [[TiffFileRead alloc] init];
                                        [self->tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                        
                                        xyPositionDataOriginal [counter1*3+2] = (int)xPosition;
                                        xyPositionDataOriginal [counter1*3+1] = (int)yPosition;
                                        
                                        if (imageDimensionW > imageDimensionH) imageDimension = imageDimensionW;
                                        else imageDimension = imageDimensionH;
                                        
                                        self->tiffFileRead = [[TiffFileRead alloc] init];
                                        delete [] arrayExtractedImage3;
                                        
                                        arrayExtractedImage3 = [self->tiffFileRead imageSetBigEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                    }
                                    else if (endianType == 0){
                                        self->tiffFileRead = [[TiffFileRead alloc] init];
                                        [self->tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                        
                                        xyPositionDataOriginal [counter1*3+2] = (int)xPosition;
                                        xyPositionDataOriginal [counter1*3+1] = (int)yPosition;
                                        
                                        if (imageDimensionW > imageDimensionH) imageDimension = imageDimensionW;
                                        else imageDimension = imageDimensionH;
                                        
                                        self->tiffFileRead = [[TiffFileRead alloc] init];
                                        delete [] arrayExtractedImage3;
                                        
                                        arrayExtractedImage3 = [self->tiffFileRead imageSetLittleEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                    }
                                    
                                    dimensionAdditionW = imageDimensionW%4;
                                    
                                    if (dimensionAdditionW == 1) dimensionAdditionW = 3;
                                    else if (dimensionAdditionW == 2) dimensionAdditionW = 2;
                                    else if (dimensionAdditionW == 3) dimensionAdditionW = 1;
                                    
                                    newImageDimensionW = imageDimensionW+dimensionAdditionW;
                                    
                                    dimensionAdditionH = imageDimensionH%4;
                                    
                                    if (dimensionAdditionH == 1) dimensionAdditionH = 3;
                                    else if (dimensionAdditionH == 2) dimensionAdditionH = 2;
                                    else if (dimensionAdditionH == 3) dimensionAdditionH = 1;
                                    
                                    newImageDimensionH = imageDimensionH+dimensionAdditionH;
                                    horizontalBmp = 0;
                                    horizontalBmpEntry = 0;
                                    
                                    for (int counter3 = 0; counter3 < imageDimensionW*imageDimensionH; counter3++){
                                        if (photoMetricsHold == 1){
                                            if (horizontalBmp < imageDimensionW){
                                                arrayImageOriginal [verticalBmp][horizontalBmpEntry] = arrayExtractedImage3 [counter3], horizontalBmpEntry++;
                                                horizontalBmp++;
                                            }
                                            
                                            if (horizontalBmp == imageDimensionW){
                                                if (imageDimensionW < newImageDimensionW){
                                                    for (int counter4 = 0; counter4 < newImageDimensionW-imageDimensionW; counter4++){
                                                        arrayImageOriginal [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                    }
                                                }
                                                
                                                horizontalBmp = 0;
                                                horizontalBmpEntry = 0;
                                                verticalBmp++;
                                            }
                                        }
                                        else if (photoMetricsHold == 2){
                                            if (horizontalBmp < imageDimensionW){
                                                arrayImageOriginal [verticalBmp][horizontalBmpEntry] = arrayExtractedImage3 [counter3*3], horizontalBmpEntry++;
                                                arrayImageOriginal [verticalBmp][horizontalBmpEntry] = arrayExtractedImage3 [counter3*3+1], horizontalBmpEntry++;
                                                arrayImageOriginal [verticalBmp][horizontalBmpEntry] = arrayExtractedImage3 [counter3*3+2], horizontalBmpEntry++;
                                                horizontalBmp++;
                                            }
                                            
                                            if (horizontalBmp == imageDimensionW){
                                                if (imageDimensionW < newImageDimensionW){
                                                    for (int counter4 = 0; counter4 < newImageDimensionW-imageDimensionW; counter4++){
                                                        arrayImageOriginal [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                        arrayImageOriginal [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                        arrayImageOriginal [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                    }
                                                }
                                                
                                                horizontalBmp = 0;
                                                horizontalBmpEntry = 0;
                                                verticalBmp++;
                                            }
                                        }
                                    }
                                    
                                    if (photoMetricsHold == 1){
                                        if (imageDimensionH < newImageDimensionH){
                                            for (int counter3 = imageDimensionH; counter3 < newImageDimensionH; counter3++){
                                                horizontalBmpEntry = 0;
                                                
                                                for (int counter4 = 0; counter4 < imageDimensionW; counter4++){
                                                    arrayImageOriginal [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                }
                                                
                                                verticalBmp++;
                                            }
                                        }
                                    }
                                    else if (photoMetricsHold == 2){
                                        if (imageDimensionH < newImageDimensionH){
                                            for (int counter3 = imageDimensionH; counter3 < newImageDimensionH; counter3++){
                                                horizontalBmpEntry = 0;
                                                
                                                for (int counter4 = 0; counter4 < imageDimensionW; counter4++){
                                                    arrayImageOriginal [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                    arrayImageOriginal [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                    arrayImageOriginal [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                }
                                                
                                                verticalBmp++;
                                            }
                                        }
                                    }
                                    
                                    delete [] fileReadArray;
                                    delete [] arrayExtractedImage3;
                                    
                                    //-----Image size update-----
                                    imageDimensionH = newImageDimensionH;
                                    imageDimensionW = newImageDimensionW;
                                }
                            }
                            
                            //-----Set Other arrays-----Use Current image data-----
                            if (photoMetricsHold == 1){
                                for (int counter1 = 0; counter1 < imageDimensionH*fileListCount; counter1++){
                                    for (int counter2 = 0; counter2 < imageDimensionW; counter2++){
                                        arrayImageResults [counter1][counter2] = arrayImageDataHold [counter1][counter2];
                                    }
                                }
                            }
                            else if (photoMetricsHold == 2){
                                for (int counter1 = 0; counter1 < imageDimensionH*fileListCount; counter1++){
                                    for (int counter2 = 0; counter2 < imageDimensionW; counter2++){
                                        arrayImageResults [counter1][counter2*3] = arrayImageDataHold [counter1][counter2*3];
                                        arrayImageResults [counter1][counter2*3+1] = arrayImageDataHold [counter1][counter2*3+1];
                                        arrayImageResults [counter1][counter2*3+2] = arrayImageDataHold [counter1][counter2*3+2];
                                    }
                                }
                            }
                            
                            int stitchedImageDimensionHold = stitchedImageDimension;
                            
                            stitchedImageDimension = 0;
                            
                            int imagePositionXMax = 0;
                            int imagePositionYMax = 0;
                            int imagePositionXMin = 100000000;
                            int imagePositionYMin = 100000000;
                            
                            for (int counter3 = 0; counter3 < fileListCount; counter3++){
                                if (xyPositionData [counter3*3+2] > imagePositionXMax) imagePositionXMax = xyPositionData [counter3*3+2];
                                if (xyPositionData [counter3*3+1] > imagePositionYMax) imagePositionYMax = xyPositionData [counter3*3+1];
                                if (xyPositionData [counter3*3+2] < imagePositionXMin) imagePositionXMin = xyPositionData [counter3*3+2];
                                if (xyPositionData [counter3*3+1] < imagePositionYMin) imagePositionYMin = xyPositionData [counter3*3+1];
                            }
                            
                            if (imagePositionXMax == 0 || imagePositionXMin == 100000000){
                                imagePositionXMax = 0;
                                imagePositionXMin = 0;
                            }
                            
                            if (imagePositionYMax == 0 || imagePositionYMin == 100000000){
                                imagePositionYMax = 0;
                                imagePositionYMin = 0;
                            }
                            
                            imagePositionXMax = imagePositionXMax+imageDimensionW;
                            imagePositionYMax = imagePositionYMax+imageDimensionH;
                            
                            int imagePositionXDimension = imagePositionXMax-imagePositionXMin;
                            int imagePositionYDimension = imagePositionYMax-imagePositionYMin;
                            
                            int longerXAxeAdjust = 0;
                            int longerYAxeAdjust = 0;
                            
                            if (imagePositionXDimension > imagePositionYDimension){
                                stitchedImageDimension = imagePositionXDimension;
                                longerYAxeAdjust = (int)((imagePositionXDimension-imagePositionYDimension)/(double)2);
                            }
                            else{
                                
                                stitchedImageDimension = imagePositionYDimension;
                                longerXAxeAdjust = (int)((imagePositionYDimension-imagePositionXDimension)/(double)2);
                            }
                            
                            int stitchedImageDimensionAddition = (int)(stitchedImageDimension*0.2);
                            
                            stitchedImageDimension = stitchedImageDimension+stitchedImageDimensionAddition;
                            
                            int dimensionAdjust = stitchedImageDimension/4;
                            stitchedImageDimension = dimensionAdjust*4+4;
                            
                            for (int counter2 = 0; counter2 < fileListCount; counter2++){
                                if (longerXAxeAdjust == 0){
                                    xyPositionWritingData [counter2*3] = xyPositionData [counter2*3];
                                    xyPositionWritingData [counter2*3+1] = xyPositionData [counter2*3+1]-imagePositionYMin+(int)(stitchedImageDimensionAddition/(double)2)+longerYAxeAdjust;
                                    xyPositionWritingData [counter2*3+2] = xyPositionData [counter2*3+2]-imagePositionXMin+(int)(stitchedImageDimensionAddition/(double)2);
                                }
                                else{
                                    
                                    xyPositionWritingData [counter2*3] = xyPositionData [counter2*3];
                                    xyPositionWritingData [counter2*3+1] = xyPositionData [counter2*3+1]-imagePositionYMin+(int)(stitchedImageDimensionAddition/(double)2);
                                    xyPositionWritingData [counter2*3+2] = xyPositionData [counter2*3+2]-imagePositionXMin+(int)(stitchedImageDimensionAddition/(double)2)+longerXAxeAdjust;
                                }
                            }
                            
                            if (photoMetricsHold == 1){
                                if (imageRangeAdjustStatus == 1){
                                    for (int counter2 = 0; counter2 < stitchedImageDimensionHold+1; counter2++){
                                        delete [] imageDisplayArray [counter2];
                                        delete [] imagePositionMap [counter2];
                                    }
                                    
                                    delete [] imageDisplayArray;
                                    delete [] imagePositionMap;
                                }
                                
                                imageRangeAdjustStatus = 1;
                                
                                imageDisplayArray = new int *[stitchedImageDimension+1];
                                imagePositionMap = new int *[stitchedImageDimension+1];
                                
                                for (int counter2 = 0; counter2 < stitchedImageDimension+1; counter2++){
                                    imageDisplayArray [counter2] = new int [stitchedImageDimension+1];
                                    imagePositionMap [counter2] = new int [stitchedImageDimension+1];
                                }
                                
                                for (int counter3 = 0; counter3 < stitchedImageDimension; counter3++){
                                    for (int counter4 = 0; counter4 < stitchedImageDimension; counter4++){
                                        imageDisplayArray [counter3][counter4] = 0;
                                        imagePositionMap [counter3][counter4] = 0;
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < fileListCount; counter2++){
                                    for (int counter3 = 0; counter3 < imageDimensionH; counter3++){
                                        for (int counter4 = 0; counter4 < imageDimensionW; counter4++){
                                            imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]+counter4] = arrayImageDataHold [counter2*imageDimensionH+counter3][counter4];
                                            imagePositionMap [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]+counter4] = xyPositionWritingData [counter2*3];
                                        }
                                    }
                                }
                                
                                if (self->mapLoadHold == 1){
                                    string imageDisplayMapPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files/"+analysisNameHold+"_ProductsH/"+treatNameHold+"_Capture/Map.dat";
                                    
                                    int pixData = 0;
                                    
                                    for (int counter3 = 0; counter3 < stitchedImageDimension; counter3++){
                                        for (int counter4 = 0; counter4 < stitchedImageDimension; counter4++){
                                            imageDisplayArray [counter3][counter4] = 0;
                                            imagePositionMap [counter3][counter4] = 0;
                                        }
                                    }
                                    
                                    uint8_t *upload2 = new uint8_t [imageDimensionH*imageDimensionW*fileListCount+10];
                                    
                                    fin.open(imageDisplayMapPath.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.read((char*)upload2, imageDimensionH*imageDimensionW*fileListCount+10);
                                        fin.close();
                                        
                                        int **mapTemp = new int *[imageDimensionH+1];
                                        
                                        for (int counter1 = 0; counter1 < imageDimensionH+1; counter1++){
                                            mapTemp [counter1] = new int [imageDimensionW+1];
                                        }
                                        
                                        int yDimensionCount = 0;
                                        int xDimensionCount = 0;
                                        
                                        for (int counter1 = 0; counter1 < fileListCount; counter1++){
                                            yDimensionCount = 0;
                                            xDimensionCount = 0;
                                            
                                            for (int counter2 = imageDimensionH*imageDimensionW*counter1; counter2 < imageDimensionH*imageDimensionW*counter1+imageDimensionH*imageDimensionW; counter2++){
                                                pixData = upload2 [counter2];
                                                
                                                mapTemp [yDimensionCount][xDimensionCount] = pixData, xDimensionCount++;
                                                
                                                if (xDimensionCount == imageDimensionW){
                                                    xDimensionCount = 0;
                                                    yDimensionCount++;
                                                    
                                                    if (yDimensionCount == imageDimensionH){
                                                        break;
                                                    }
                                                }
                                            }
                                            
                                            for (int counter3 = 0; counter3 < imageDimensionH; counter3++){
                                                for (int counter4 = 0; counter4 < imageDimensionW; counter4++){
                                                    if (mapTemp [counter3][counter4] != 0){
                                                        imagePositionMap [xyPositionWritingData [counter1*3+1]+counter3][xyPositionWritingData [counter1*3+2]+counter4] = mapTemp [counter3][counter4];
                                                    }
                                                }
                                            }
                                        }
                                        
                                        for (int counter1 = 0; counter1 < imageDimensionH+1; counter1++){
                                            delete [] mapTemp [counter1];
                                        }
                                        
                                        delete [] mapTemp;
                                        
                                        for (int counter2 = 0; counter2 < fileListCount; counter2++){
                                            for (int counter3 = 0; counter3 < imageDimensionH; counter3++){
                                                for (int counter4 = 0; counter4 < imageDimensionW; counter4++){
                                                    if (imagePositionMap [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]+counter4] == counter2+1){
                                                        imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]+counter4] = arrayImageDataHold [counter2*imageDimensionH+counter3][counter4];
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    
                                    delete [] upload2;
                                }
                            }
                            else if (photoMetricsHold == 2){
                                if (imageRangeAdjustStatus == 1){
                                    for (int counter2 = 0; counter2 < stitchedImageDimensionHold+1; counter2++){
                                        delete [] imageDisplayArray [counter2];
                                        delete [] imagePositionMap [counter2];
                                    }
                                    
                                    delete [] imageDisplayArray;
                                    delete [] imagePositionMap;
                                }
                                
                                imageRangeAdjustStatus = 1;
                                
                                imageDisplayArray = new int *[stitchedImageDimension+1];
                                imagePositionMap = new int *[stitchedImageDimension+1];
                                
                                for (int counter2 = 0; counter2 < stitchedImageDimension+1; counter2++){
                                    imageDisplayArray [counter2] = new int [stitchedImageDimension*3+1];
                                    imagePositionMap [counter2] = new int [stitchedImageDimension*3+1];
                                }
                                
                                for (int counter2 = 0; counter2 < stitchedImageDimension; counter2++){
                                    for (int counter3 = 0; counter3 < stitchedImageDimension*3; counter3++){
                                        imageDisplayArray [counter2][counter3] = 0;
                                        imagePositionMap [counter2][counter3] = 0;
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < fileListCount; counter2++){
                                    for (int counter3 = 0; counter3 < imageDimensionH; counter3++){
                                        for (int counter4 = 0; counter4 < imageDimensionW*3; counter4 = counter4+3){
                                            imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4] = arrayImageDataHold [counter2*imageDimensionH+counter3][counter4];
                                            imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4+1] = arrayImageDataHold [counter2*imageDimensionH+counter3][counter4+1];
                                            imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4+2] = arrayImageDataHold [counter2*imageDimensionH+counter3][counter4+2];
                                            
                                            imagePositionMap [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4] = xyPositionWritingData [counter2*3];
                                            imagePositionMap [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4+1] = xyPositionWritingData [counter2*3];
                                            imagePositionMap [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4+2] = xyPositionWritingData [counter2*3];
                                        }
                                    }
                                }
                                
                                if (self->mapLoadHold == 1){
                                    string imageDisplayMapPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files/"+analysisNameHold+"_ProductsH/"+treatNameHold+"_Capture/FOVMap.dat";
                                    
                                    int pixData = 0;
                                    
                                    for (int counter2 = 0; counter2 < stitchedImageDimension; counter2++){
                                        for (int counter3 = 0; counter3 < stitchedImageDimension*3; counter3++){
                                            imageDisplayArray [counter2][counter3] = 0;
                                            imagePositionMap [counter2][counter3] = 0;
                                        }
                                    }
                                    
                                    uint8_t *upload2 = new uint8_t [imageDimensionH*imageDimensionW*fileListCount+10];
                                    
                                    fin.open(imageDisplayMapPath.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.read((char*)upload2, imageDimensionH*imageDimensionW*fileListCount+10);
                                        fin.close();
                                        
                                        int **mapTemp = new int *[imageDimensionH+1];
                                        
                                        for (int counter1 = 0; counter1 < imageDimensionH+1; counter1++){
                                            mapTemp [counter1] = new int [imageDimensionW+1];
                                        }
                                        
                                        int yDimensionCount = 0;
                                        int xDimensionCount = 0;
                                        
                                        for (int counter1 = 0; counter1 < fileListCount; counter1++){
                                            yDimensionCount = 0;
                                            xDimensionCount = 0;
                                            
                                            for (int counter2 = imageDimensionH*imageDimensionW*counter1; counter2 < imageDimensionH*imageDimensionW*counter1+imageDimensionH*imageDimensionW; counter2++){
                                                pixData = upload2 [counter2];
                                                
                                                mapTemp [yDimensionCount][xDimensionCount] = pixData, xDimensionCount++;
                                                
                                                if (xDimensionCount == imageDimensionW){
                                                    xDimensionCount = 0;
                                                    yDimensionCount++;
                                                    
                                                    if (yDimensionCount == imageDimensionH){
                                                        break;
                                                    }
                                                }
                                            }
                                            
                                            for (int counter3 = 0; counter3 < imageDimensionH; counter3++){
                                                for (int counter4 = 0; counter4 < imageDimensionW; counter4++){
                                                    if (mapTemp [counter3][counter4] != 0){
                                                        imagePositionMap [xyPositionWritingData [counter1*3+1]+counter3][xyPositionWritingData [counter1*3+2]*3+counter4*3] = mapTemp [counter3][counter4];
                                                        imagePositionMap [xyPositionWritingData [counter1*3+1]+counter3][xyPositionWritingData [counter1*3+2]*3+counter4*3+1] = mapTemp [counter3][counter4];
                                                        imagePositionMap [xyPositionWritingData [counter1*3+1]+counter3][xyPositionWritingData [counter1*3+2]*3+counter4*3+2] = mapTemp [counter3][counter4];
                                                    }
                                                }
                                            }
                                        }
                                        
                                        for (int counter1 = 0; counter1 < imageDimensionH+1; counter1++){
                                            delete [] mapTemp [counter1];
                                        }
                                        
                                        delete [] mapTemp;
                                        
                                        for (int counter2 = 0; counter2 < fileListCount; counter2++){
                                            for (int counter3 = 0; counter3 < imageDimensionH; counter3++){
                                                for (int counter4 = 0; counter4 < imageDimensionW*3; counter4 = counter4+3){
                                                    if (imagePositionMap [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4] == counter2+1){
                                                        imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4] = arrayImageDataHold [counter2*imageDimensionH+counter3][counter4];
                                                        imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4+1] = arrayImageDataHold [counter2*imageDimensionH+counter3][counter4+1];
                                                        imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4+2] = arrayImageDataHold [counter2*imageDimensionH+counter3][counter4+2];
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    
                                    delete [] upload2;
                                }
                            }
                            
                            string imagingParameterPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/ImageDataList";
                            
                            string *imageDataListTemp = new string [10000];
                            int imageDataListTempCount = 0;
                            int imageDataListTempLimit = 10000;
                            
                            string getString;
                            
                            fin.open(imagingParameterPath.c_str(),ios::in);
                            
                            if (fin.is_open()){
                                do{
                                    
                                    terminationFlag = 1;
                                    
                                    if (imageDataListTempCount*422+450 > imageDataListTempLimit){
                                        string *arrayUpDate = new string [imageDataListTempCount*422+10];
                                        
                                        for (int counter1 = 0; counter1 < imageDataListTempCount*422; counter1++) arrayUpDate [counter1] = imageDataListTemp [counter1];
                                        delete [] imageDataListTemp;
                                        imageDataListTemp = new string [imageDataListTempLimit+10000];
                                        imageDataListTempLimit = imageDataListTempLimit+10000;
                                        
                                        for (int counter1 = 0; counter1 < imageDataListTempCount*422; counter1++) imageDataListTemp [counter1] = arrayUpDate [counter1];
                                        delete [] arrayUpDate;
                                    }
                                    
                                    for (int counter1 = 0; counter1 < 422; counter1++){
                                        getline(fin, getString), imageDataListTemp [imageDataListTempCount*422+counter1] = getString;
                                        
                                        if (getString == ""){
                                            terminationFlag = 0;
                                            break;
                                        }
                                    }
                                    
                                    if (terminationFlag != 0) imageDataListTempCount++;
                                    
                                } while (terminationFlag == 1);
                                
                                fin.close();
                            }
                            
                            listDataCount = 0;
                            
                            for (int counter1 = 0; counter1 < imageDataListTempCount; counter1++){
                                if (imageDataListTemp [counter1*422] == analysisNameHold && imageDataListTemp [counter1*422+1] == treatNameHold){
                                    for (int counter2 = 2; counter2 < 422; counter2++){
                                        if (imageDataListTemp [counter1*422+counter2] != "A"){
                                            listDataHold [counter2-2] = atof(imageDataListTemp [counter1*422+counter2].c_str());
                                        }
                                        else{
                                            
                                            listDataCount = (counter2-2)/15;
                                            break;
                                        }
                                    }
                                }
                            }
                            
                            delete [] imageDataListTemp;
                            
                            if (listDataCount == 0){
                                listDataHold [0] = levelHoldContrast;
                                listDataHold [1] = levelHoldBrightness;
                                listDataHold [2] = levelHoldRed;
                                listDataHold [3] = cutRedHold;
                                listDataHold [4] = levelHoldGreen;
                                listDataHold [5] = cutGreenHold;
                                listDataHold [6] = levelHoldBlue;
                                listDataHold [7] = cutBlueHold;
                                listDataHold [8] = levelHoldRedPick;
                                listDataHold [9] = cutRedHoldPick;
                                listDataHold [10] = levelHoldGreenPick;
                                listDataHold [11] = cutGreenHoldPick;
                                listDataHold [12] = levelHoldBluePick;
                                listDataHold [13] = cutBlueHoldPick;
                                listDataHold [14] = 0;
                                
                                listDataCount = 1;
                            }
                            
                            imageLoadStatus = 1;
                            tableDisplayCall = 1;
                            imageDisplayCall = 1;
                        }
                        else warningSet = 5;
                    }
                    else warningSet = 4;
                    
                    delete [] imageSizeArray;
                    delete [] imageInformationArray;
                }
                else warningSet = 3;
                
                progressTiming = 8;
                copyProgressFlag = 0;
            });
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Image Folder Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)quitProcess:(id)sender{
    if (copyProgressFlag == 0){
        delete [] arrayDirectoryInfo;
        delete [] tableListHold;
        delete [] currentListInformation;
        delete [] imageSetPositionList;
        delete [] fileList;
        delete [] xyPositionData;
        delete [] xyPositionDataOriginal;
        delete [] xyPositionWritingData;
        delete [] listDataHold;
        
        if (imageDataHoldStatus == 1){
            for (int counter2 = 0; counter2 < imageDimensionH*fileListCount+20; counter2++){
                delete [] arrayImageDataHold [counter2];
                delete [] arrayImageOriginal [counter2];
                delete [] arrayImageResults [counter2];
            }
            
            delete [] arrayImageDataHold;
            delete [] arrayImageOriginal;
            delete [] arrayImageResults;
        }
        
        if (imageRangeAdjustStatus == 1){
            for (int counter2 = 0; counter2 < stitchedImageDimension; counter2++){
                delete [] imageDisplayArray [counter2];
                delete [] imagePositionMap [counter2];
            }
            
            delete [] imageDisplayArray;
            delete [] imagePositionMap;
        }
        
        exit (0);
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processes In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)tableReload:(id)sender{
    [listBrowser reloadColumn:0];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)sliderLevelContrast:(id)sender{
    if (imageLoadStatus == 1 && copyProgressFlag == 0){
        levelHoldContrast = [sliderContrast doubleValue];
        
        listDataHold [0] = levelHoldContrast;
        
        int holdTemp = (int)(levelHoldContrast*1000);
        double holdTempDouble = holdTemp/(double)1000;
        
        [contrastLevel setDoubleValue:holdTempDouble];
        
        sliderStart = 1;
    }
}

-(IBAction)sliderLevelBrightness:(id)sender{
    if (imageLoadStatus == 1 && copyProgressFlag == 0){
        if (blurCutHold == 0){
            levelHoldBrightness = [sliderBrightness doubleValue];
            
            listDataHold [1] = levelHoldBrightness;
            
            int holdTemp = (int)(levelHoldBrightness*1000);
            double holdTempDouble = holdTemp/(double)1000;
            
            [brightnessLevel setDoubleValue:holdTempDouble];
        }
        else if (blurCutHold == 1){
            levelHoldBlur = [sliderBrightness doubleValue];
            
            int holdTemp = (int)(levelHoldBlur*1000);
            double holdTempDouble = holdTemp/(double)1000;
            
            [brightnessLevel setDoubleValue:holdTempDouble];
        }
        
        sliderStart = 1;
    }
}

-(IBAction)sliderRed:(id)sender{
    if (imageLoadStatus == 1 && copyProgressFlag == 0){
        if (colorPickStatusHold == 0){
            levelHoldRed = [sliderRed doubleValue];
            
            listDataHold [2] = levelHoldRed;
            
            int holdTemp = (int)(levelHoldRed*1000);
            double holdTempDouble = holdTemp/(double)1000;
            
            [redLevel setDoubleValue:holdTempDouble];
        }
        else if (colorPickStatusHold == 1){
            levelHoldRedPick = [sliderRed doubleValue];
            
            int holdTemp = (int)(levelHoldRedPick*1000);
            double holdTempDouble = holdTemp/(double)1000;
            
            [redLevel setDoubleValue:holdTempDouble];
        }
        
        sliderStart = 1;
    }
}

-(IBAction)sliderGreen:(id)sender{
    if (imageLoadStatus == 1 && copyProgressFlag == 0){
        if (colorPickStatusHold == 0){
            levelHoldGreen = [sliderGreen doubleValue];
            
            listDataHold [4] = levelHoldGreen;
            
            int holdTemp = (int)(levelHoldGreen*1000);
            double holdTempDouble = holdTemp/(double)1000;
            
            [greenLevel setDoubleValue:holdTempDouble];
        }
        else if (colorPickStatusHold == 1){
            levelHoldGreenPick = [sliderGreen doubleValue];
            
            int holdTemp = (int)(levelHoldGreenPick*1000);
            double holdTempDouble = holdTemp/(double)1000;
            
            [greenLevel setDoubleValue:holdTempDouble];
        }
        
        sliderStart = 1;
    }
}

-(IBAction)sliderBlue:(id)sender{
    if (imageLoadStatus == 1 && copyProgressFlag == 0){
        if (colorPickStatusHold == 0){
            levelHoldBlue = [sliderBlue doubleValue];
            
            listDataHold [6] = levelHoldBlue;
            
            int holdTemp = (int)(levelHoldBlue*1000);
            double holdTempDouble = holdTemp/(double)1000;
            
            [blueLevel setDoubleValue:holdTempDouble];
        }
        else if (colorPickStatusHold == 1){
            levelHoldBluePick = [sliderBlue doubleValue];
            
            int holdTemp = (int)(levelHoldBluePick*1000);
            double holdTempDouble = holdTemp/(double)1000;
            
            [blueLevel setDoubleValue:holdTempDouble];
        }
        
        sliderStart = 1;
    }
}

-(IBAction)sliderRedCut:(id)sender{
    if (imageLoadStatus == 1 && copyProgressFlag == 0){
        if (colorPickStatusHold == 0){
            cutRedHold = [sliderRedCut doubleValue];
            
            listDataHold [3] = cutRedHold;
            
            int holdTemp = (int)(cutRedHold*1000);
            double holdTempDouble = holdTemp/(double)1000;
            
            [redCut setDoubleValue:holdTempDouble];
        }
        else if (colorPickStatusHold == 1){
            cutRedHoldPick = [sliderRedCut doubleValue];
            
            int holdTemp = (int)(cutRedHoldPick*1000);
            double holdTempDouble = holdTemp/(double)1000;
            
            [redCut setDoubleValue:holdTempDouble];
        }
        
        sliderStart = 1;
    }
}

-(IBAction)sliderGreenCut:(id)sender{
    if (imageLoadStatus == 1 && copyProgressFlag == 0){
        if (colorPickStatusHold == 0){
            cutGreenHold = [sliderGreenCut doubleValue];
            
            listDataHold [5] = cutGreenHold;
            
            int holdTemp = (int)(cutGreenHold*1000);
            double holdTempDouble = holdTemp/(double)1000;
            
            [greenCut setDoubleValue:holdTempDouble];
        }
        else if (colorPickStatusHold == 1){
            cutGreenHoldPick = [sliderGreenCut doubleValue];
            
            int holdTemp = (int)(cutGreenHoldPick*1000);
            double holdTempDouble = holdTemp/(double)1000;
            
            [greenCut setDoubleValue:holdTempDouble];
        }
        
        sliderStart = 1;
    }
}

-(IBAction)sliderBlueCut:(id)sender{
    if (imageLoadStatus == 1 && copyProgressFlag == 0){
        if (colorPickStatusHold == 0){
            cutBlueHold = [sliderBlueCut doubleValue];
            
            listDataHold [7] = cutBlueHold;
            
            int holdTemp = (int)(cutBlueHold*1000);
            double holdTempDouble = holdTemp/(double)1000;
            
            [blueCut setDoubleValue:holdTempDouble];
        }
        else if (colorPickStatusHold == 1){
            cutBlueHoldPick = [sliderBlueCut doubleValue];
            
            int holdTemp = (int)(cutBlueHoldPick*1000);
            double holdTempDouble = holdTemp/(double)1000;
            
            [blueCut setDoubleValue:holdTempDouble];
        }
        
        sliderStart = 1;
    }
}

-(IBAction)sliderContrastCircle:(id)sender{
    if (imageLoadStatus == 1){
        double sliderCircleValue = sliderContrastMax*[sliderContrastCircle doubleValue];
        double sliderCircleValue2 = sliderContrastMin/[sliderContrastCircle doubleValue];
        double sliderValue = [sliderContrast doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderContrastDiff;
        
        sliderCircleValue = sliderValue+(sliderContrastMax-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderContrastMin)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        
        [sliderContrast setMaxValue:sliderCircleValue];
        [sliderContrast setMinValue:sliderCircleValue2];
        
        int enhanceInt = (int)([sliderContrast doubleValue]*1000);
        double enhanceDouble = enhanceInt/(double)1000;
        
        [contrastLevel setDoubleValue:enhanceDouble];
    }
}

-(IBAction)sliderBrightnessCircle:(id)sender{
    if (imageLoadStatus == 1){
        double sliderCircleValue = sliderBrightnessMax*[sliderBrightnessCircle doubleValue];
        double sliderCircleValue2 = sliderBrightnessMin/[sliderBrightnessCircle doubleValue];
        double sliderValue = [sliderBrightness doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderBrightnessDiff;
        
        sliderCircleValue = sliderValue+(sliderBrightnessMax-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderBrightnessMin)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        
        [sliderBrightness setMaxValue:sliderCircleValue];
        [sliderBrightness setMinValue:sliderCircleValue2];
        
        int enhanceInt = (int)([sliderBrightness doubleValue]*1000);
        double enhanceDouble = enhanceInt/(double)1000;
        
        [brightnessLevel setDoubleValue:enhanceDouble];
    }
}

-(IBAction)sliderRedCircle:(id)sender{
    if (imageLoadStatus == 1){
        double sliderCircleValue = sliderRedMax*[sliderRedCircle doubleValue];
        double sliderCircleValue2 = sliderRedMin/[sliderRedCircle doubleValue];
        double sliderValue = [sliderRed doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderRedDiff;
        
        sliderCircleValue = sliderValue+(sliderRedMax-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderRedMin)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        
        [sliderRed setMaxValue:sliderCircleValue];
        [sliderRed setMinValue:sliderCircleValue2];
        
        int enhanceInt = (int)([sliderRed doubleValue]*1000);
        double enhanceDouble = enhanceInt/(double)1000;
        
        [redLevel setDoubleValue:enhanceDouble];
    }
}

-(IBAction)sliderGreenCircle:(id)sender{
    if (imageLoadStatus == 1){
        double sliderCircleValue = sliderGreenMax*[sliderGreenCircle doubleValue];
        double sliderCircleValue2 = sliderGreenMin/[sliderGreenCircle doubleValue];
        double sliderValue = [sliderGreen doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderGreenDiff;
        
        sliderCircleValue = sliderValue+(sliderGreenMax-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderGreenMin)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        if (sliderCircleValue > 255) sliderCircleValue = 255;
        
        [sliderGreen setMaxValue:sliderCircleValue];
        [sliderGreen setMinValue:sliderCircleValue2];
        
        int enhanceInt = (int)([sliderGreen doubleValue]*1000);
        double enhanceDouble = enhanceInt/(double)1000;
        
        [greenLevel setDoubleValue:enhanceDouble];
    }
}

-(IBAction)sliderBlueCircle:(id)sender{
    if (imageLoadStatus == 1){
        double sliderCircleValue = sliderBlueMax*[sliderBlueCircle doubleValue];
        double sliderCircleValue2 = sliderBlueMin/[sliderBlueCircle doubleValue];
        double sliderValue = [sliderBlue doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderBlueDiff;
        
        sliderCircleValue = sliderValue+(sliderBlueMax-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderBlueMin)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        if (sliderCircleValue > 255) sliderCircleValue = 255;
        
        [sliderBlue setMaxValue:sliderCircleValue];
        [sliderBlue setMinValue:sliderCircleValue2];
        
        int enhanceInt = (int)([sliderBlue doubleValue]*1000);
        double enhanceDouble = enhanceInt/(double)1000;
        
        [blueLevel setDoubleValue:enhanceDouble];
    }
}

-(IBAction)sliderRedCutCircle:(id)sender{
    if (imageLoadStatus == 1){
        double sliderCircleValue = sliderCutRedMax*[sliderRedCutCircle doubleValue];
        double sliderCircleValue2 = sliderCutRedMin/[sliderRedCutCircle doubleValue];
        double sliderValue = [sliderRedCut doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderCutRedDiff;
        
        sliderCircleValue = sliderValue+(sliderCutRedMax-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderCutRedMin)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        if (sliderCircleValue > 255) sliderCircleValue = 255;
        
        [sliderRedCut setMaxValue:sliderCircleValue];
        [sliderRedCut setMinValue:sliderCircleValue2];
        
        int enhanceInt = (int)([sliderRedCut doubleValue]*1000);
        double enhanceDouble = enhanceInt/(double)1000;
        
        [redCut setDoubleValue:enhanceDouble];
    }
}

-(IBAction)sliderGreenCutCircle:(id)sender{
    if (imageLoadStatus == 1){
        double sliderCircleValue = sliderCutGreenMax*[sliderGreenCutCircle doubleValue];
        double sliderCircleValue2 = sliderCutGreenMin/[sliderGreenCutCircle doubleValue];
        double sliderValue = [sliderGreenCut doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderCutGreenDiff;
        
        sliderCircleValue = sliderValue+(sliderCutGreenMax-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderCutGreenMin)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        if (sliderCircleValue > 255) sliderCircleValue = 255;
        
        [sliderGreenCut setMaxValue:sliderCircleValue];
        [sliderGreenCut setMinValue:sliderCircleValue2];
        
        int enhanceInt = (int)([sliderGreenCut doubleValue]*1000);
        double enhanceDouble = enhanceInt/(double)1000;
        
        [greenCut setDoubleValue:enhanceDouble];
    }
}

-(IBAction)sliderBlueCutCircle:(id)sender{
    if (imageLoadStatus == 1){
        double sliderCircleValue = sliderCutBlueMax*[sliderBlueCutCircle doubleValue];
        double sliderCircleValue2 = sliderCutBlueMin/[sliderBlueCutCircle doubleValue];
        double sliderValue = [sliderBlueCut doubleValue];
        
        double range2 = sliderCircleValue-sliderCircleValue2;
        range2 = range2/sliderCutBlueDiff;
        
        sliderCircleValue = sliderValue+(sliderCutBlueMax-sliderValue)/range2;
        sliderCircleValue2 = sliderValue-(sliderValue-sliderCutBlueMin)/range2;
        
        if (sliderCircleValue2 < 0) sliderCircleValue2 = 0;
        if (sliderCircleValue > 255) sliderCircleValue = 255;
        
        [sliderBlueCut setMaxValue:sliderCircleValue];
        [sliderBlueCut setMinValue:sliderCircleValue2];
        
        int enhanceInt = (int)([sliderBlueCut doubleValue]*1000);
        double enhanceDouble = enhanceInt/(double)1000;
        
        [blueCut setDoubleValue:enhanceDouble];
    }
}

-(IBAction)reLoadOriginal:(id)sender{
    if (imageLoadStatus == 1 && copyProgressFlag == 0){
        levelHoldContrast = 1;
        
        listDataHold [0] = levelHoldContrast;
        
        [contrastLevel setDoubleValue:1];
        [sliderContrast setDoubleValue:1];
        [sliderContrastCircle setDoubleValue:1];
        [sliderContrast setMaxValue:sliderContrastMax];
        [sliderContrast setMinValue:sliderContrastMin];
        [sliderKnobContrast setDoubleValue:levelHoldContrast];
        
        levelHoldBrightness = 0;
        
        listDataHold [1] = levelHoldBrightness;
        
        [brightnessLevel setDoubleValue:0];
        [sliderBrightness setDoubleValue:0];
        [sliderBrightnessCircle setDoubleValue:1];
        [sliderBrightness setMaxValue:sliderBrightnessMax];
        [sliderBrightness setMinValue:sliderBrightnessMin];
        [sliderKnobBrightness setDoubleValue:levelHoldBrightness];
        
        cutRedHold = 0;
        levelHoldRed = 0;
        cutRedHoldPick = 10;
        levelHoldRedPick = 0;
        
        listDataHold [2] = levelHoldRed;
        listDataHold [3] = cutRedHold;
        
        cursorRedMax = 0;
        cursorRedMin = 0;
        
        cutGreenHold = 0;
        levelHoldGreen = 0;
        cutGreenHoldPick = 10;
        levelHoldGreenPick = 0;
        
        listDataHold [4] = levelHoldGreen;
        listDataHold [5] = cutGreenHold;
        
        cursorGreenMax = 0;
        cursorGreenMin = 0;
        
        cutBlueHold = 0;
        levelHoldBlue = 0;
        cutBlueHoldPick = 10;
        levelHoldBluePick = 0;
        
        listDataHold [6] = levelHoldBlue;
        listDataHold [7] = cutBlueHold;
        
        cursorBlueMax = 0;
        cursorBlueMin = 0;
        
        if (colorPickStatusHold == 0){
            [redCut setDoubleValue:0];
            [redLevel setDoubleValue:0];
            
            [sliderRed setMaxValue:sliderRedMax];
            [sliderRed setMinValue:sliderRedMin];
            
            [sliderRedCut setMaxValue:sliderCutRedMax];
            [sliderRedCut setMinValue:sliderCutRedMin];
            
            [sliderRed setDoubleValue:0];
            [sliderRedCut setDoubleValue:0];
            [sliderRedCircle setDoubleValue:1];
            [sliderRedCutCircle setDoubleValue:1];
            
            [sliderKnobRed setDoubleValue:0];
            [sliderKnobRedCut setDoubleValue:0];
            
            [greenCut setDoubleValue:0];
            [greenLevel setDoubleValue:0];
            
            [sliderGreen setMaxValue:sliderGreenMax];
            [sliderGreen setMinValue:sliderGreenMin];
            
            [sliderGreenCut setMaxValue:sliderCutGreenMax];
            [sliderGreenCut setMinValue:sliderCutGreenMin];
            
            [sliderGreen setDoubleValue:0];
            [sliderGreenCut setDoubleValue:0];
            [sliderGreenCircle setDoubleValue:1];
            [sliderGreenCutCircle setDoubleValue:1];
            
            [sliderKnobGreen setDoubleValue:0];
            [sliderKnobGreenCut setDoubleValue:0];
            
            [blueCut setDoubleValue:0];
            [blueLevel setDoubleValue:0];
            
            [sliderBlue setMaxValue:sliderBlueMax];
            [sliderBlue setMinValue:sliderBlueMin];
            
            [sliderBlueCut setMaxValue:sliderCutBlueMax];
            [sliderBlueCut setMinValue:sliderCutBlueMin];
            
            [sliderBlue setDoubleValue:0];
            [sliderBlueCut setDoubleValue:0];
            [sliderBlueCircle setDoubleValue:1];
            [sliderBlueCutCircle setDoubleValue:1];
            
            [sliderKnobBlue setDoubleValue:0];
            [sliderKnobBlueCut setDoubleValue:0];
        }
        
        if (photoMetricsHold == 1){
            int tempValue1 = 0;
            
            if (imageFLStatus == "Lock" || (processingFovNo == 0 && imageFLStatus == "Free")){
                for (int counter2 = 0; counter2 < fileListCount; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionH; counter3++){
                        for (int counter4 = 0; counter4 < imageDimensionW; counter4++){
                            if ((int)(arrayImageOriginal [counter2*imageDimensionH+counter3][counter4]*(double)levelHoldContrast) > 255) tempValue1 = 255;
                            else tempValue1 = (int)(arrayImageOriginal [counter2*imageDimensionH+counter3][counter4]*(double)levelHoldContrast);
                            
                            if ((int)(tempValue1+levelHoldBrightness) > 255) tempValue1 = 255;
                            else tempValue1 = (int)(tempValue1+levelHoldBrightness);
                            
                            arrayImageDataHold [counter2*imageDimensionH+counter3][counter4] = tempValue1;
                            arrayImageResults [counter2*imageDimensionH+counter3][counter4] = tempValue1;
                            
                            imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]+counter4] = tempValue1;
                        }
                    }
                }
            }
            else{
                
                int newXPosition = xyPositionWritingData [(processingFovNo-1)*3+2];
                int newYPosition = xyPositionWritingData [(processingFovNo-1)*3+1];
                
                int yImageCount = 0;
                int xImageCount = 0;
                
                for (int counter1 = newYPosition; counter1 < newYPosition+imageDimensionH; counter1++){
                    for (int counter2 = newXPosition; counter2 < newXPosition+imageDimensionW; counter2++){
                        if ((int)(arrayImageOriginal [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount]*(double)levelHoldContrast) > 255) tempValue1 = 255;
                        else tempValue1 = (int)(arrayImageOriginal [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount]*(double)levelHoldContrast);
                        
                        if ((int)(tempValue1+levelHoldBrightness) > 255) tempValue1 = 255;
                        else tempValue1 = (int)(tempValue1+levelHoldBrightness);
                        
                        arrayImageDataHold [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount] = tempValue1;
                        arrayImageResults [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount] = tempValue1;
                        
                        imageDisplayArray [counter1][counter2] = tempValue1;
                        
                        xImageCount++;
                    }
                    
                    yImageCount++;
                    xImageCount = 0;
                }
            }
        }
        else if (photoMetricsHold == 2){
            int tempValue1 = 0;
            int tempValue2 = 0;
            int tempValue3 = 0;
            
            if (imageFLStatus == "Lock" || (processingFovNo == 0 && imageFLStatus == "Free")){
                for (int counter2 = 0; counter2 < fileListCount; counter2++){
                    for (int counter3 = 0; counter3 < imageDimensionH; counter3++){
                        for (int counter4 = 0; counter4 < imageDimensionW*3; counter4 = counter4+3){
                            if ((int)(arrayImageOriginal [counter2*imageDimensionH+counter3][counter4]*(double)levelHoldContrast) > 255) tempValue1 = 255;
                            else tempValue1 = (int)(arrayImageOriginal [counter2*imageDimensionH+counter3][counter4]*(double)levelHoldContrast);
                            
                            if ((int)(tempValue1+levelHoldBrightness) > 255) tempValue1 = 255;
                            else tempValue1 = (int)(tempValue1+levelHoldBrightness);
                            
                            if (tempValue1 > cutRedHold){
                                if ((int)(tempValue1+levelHoldRed) > 255) tempValue1 = 255;
                                else tempValue1 = (int)(tempValue1+levelHoldRed);
                            }
                            
                            if ((int)(arrayImageOriginal [counter2*imageDimensionH+counter3][counter4+1]*(double)levelHoldContrast) > 255) tempValue2 = 255;
                            else tempValue2 = (int)(arrayImageOriginal [counter2*imageDimensionH+counter3][counter4+1]*(double)levelHoldContrast);
                            
                            if ((int)(tempValue2+levelHoldBrightness) > 255) tempValue2 = 255;
                            else tempValue2 = (int)(tempValue2+levelHoldBrightness);
                            
                            if (tempValue2 > cutGreenHold){
                                if ((int)(tempValue2+levelHoldGreen) > 255) tempValue2 = 255;
                                else tempValue2 = (int)(tempValue2+levelHoldGreen);
                            }
                            
                            if ((int)(arrayImageOriginal [counter2*imageDimensionH+counter3][counter4+2]*(double)levelHoldContrast) > 255) tempValue3 = 255;
                            else tempValue3 = (int)(arrayImageOriginal [counter2*imageDimensionH+counter3][counter4+2]*(double)levelHoldContrast);
                            
                            if ((int)(tempValue3+levelHoldBrightness) > 255) tempValue3 = 255;
                            else tempValue3 = (int)(tempValue3+levelHoldBrightness);
                            
                            if (tempValue3 > cutBlueHold){
                                if ((int)(tempValue3+levelHoldBlue) > 255) tempValue3 = 255;
                                else tempValue3 = (int)(tempValue3+levelHoldBlue);
                            }
                            
                            arrayImageDataHold [counter2*imageDimensionH+counter3][counter4] = tempValue1;
                            arrayImageDataHold [counter2*imageDimensionH+counter3][counter4+1] = tempValue2;
                            arrayImageDataHold [counter2*imageDimensionH+counter3][counter4+2] = tempValue3;
                            
                            arrayImageResults [counter2*imageDimensionH+counter3][counter4] = tempValue1;
                            arrayImageResults [counter2*imageDimensionH+counter3][counter4+1] = tempValue2;
                            arrayImageResults [counter2*imageDimensionH+counter3][counter4+2] = tempValue3;
                            
                            imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4] = tempValue1;
                            imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4+1] = tempValue2;
                            imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4+2] = tempValue3;
                        }
                    }
                }
            }
            else{
                
                int newXPosition = xyPositionWritingData [(processingFovNo-1)*3+2];
                int newYPosition = xyPositionWritingData [(processingFovNo-1)*3+1];
                
                int yImageCount = 0;
                int xImageCount = 0;
                
                for (int counter1 = newYPosition; counter1 < newYPosition+imageDimensionH; counter1++){
                    for (int counter2 = newXPosition*3; counter2 < newXPosition*3+imageDimensionW*3; counter2 = counter2+3){
                        if ((int)(arrayImageOriginal [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount]*(double)levelHoldContrast) > 255) tempValue1 = 255;
                        else tempValue1 = (int)(arrayImageOriginal [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount]*(double)levelHoldContrast);
                        
                        if ((int)(tempValue1+levelHoldBrightness) > 255) tempValue1 = 255;
                        else tempValue1 = (int)(tempValue1+levelHoldBrightness);
                        
                        if (tempValue1 > cutRedHold){
                            if ((int)(tempValue1+levelHoldRed) > 255) tempValue1 = 255;
                            else tempValue1 = (int)(tempValue1+levelHoldRed);
                        }
                        
                        if ((int)(arrayImageOriginal [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+1]*(double)levelHoldContrast) > 255) tempValue2 = 255;
                        else tempValue2 = (int)(arrayImageOriginal [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+1]*(double)levelHoldContrast);
                        
                        if ((int)(tempValue2+levelHoldBrightness) > 255) tempValue2 = 255;
                        else tempValue2 = (int)(tempValue2+levelHoldBrightness);
                        
                        if (tempValue2 > cutGreenHold){
                            if ((int)(tempValue2+levelHoldGreen) > 255) tempValue2 = 255;
                            else tempValue2 = (int)(tempValue2+levelHoldGreen);
                        }
                        
                        if ((int)(arrayImageOriginal [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+2]*(double)levelHoldContrast) > 255) tempValue3 = 255;
                        else tempValue3 = (int)(arrayImageOriginal [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+2]*(double)levelHoldContrast);
                        
                        if ((int)(tempValue3+levelHoldBrightness) > 255) tempValue3 = 255;
                        else tempValue3 = (int)(tempValue3+levelHoldBrightness);
                        
                        if (tempValue3 > cutBlueHold){
                            if ((int)(tempValue3+levelHoldBlue) > 255) tempValue3 = 255;
                            else tempValue3 = (int)(tempValue3+levelHoldBlue);
                        }
                        
                        arrayImageDataHold [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount] = tempValue1;
                        arrayImageDataHold [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+1] = tempValue2;
                        arrayImageDataHold [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+2] = tempValue3;
                        
                        arrayImageResults [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount] = tempValue1;
                        arrayImageResults [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+1] = tempValue2;
                        arrayImageResults [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+2] = tempValue3;
                        
                        imageDisplayArray [counter1][counter2] = tempValue1;
                        imageDisplayArray [counter1][counter2+1] = tempValue2;
                        imageDisplayArray [counter1][counter2+2] = tempValue3;
                        
                        xImageCount = xImageCount+3;
                    }
                    
                    yImageCount++;
                    xImageCount = 0;
                }
            }
        }
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
}

-(IBAction)resetContrast:(id)sender{
    if (imageLoadStatus == 1 && copyProgressFlag == 0){
        levelHoldContrast = 1;
        
        listDataHold [0] = levelHoldContrast;
        
        [contrastLevel setDoubleValue:1];
        [sliderContrast setDoubleValue:1];
        [sliderContrastCircle setDoubleValue:1];
        [sliderContrast setMaxValue:sliderContrastMax];
        [sliderContrast setMinValue:sliderContrastMin];
        [sliderKnobContrast setDoubleValue:levelHoldContrast];
        
        if (photoMetricsHold == 1){
            int tempValue1 = 0;
            
            if (imageFLStatus == "Lock" || (processingFovNo == 0 && imageFLStatus == "Free")){
                if (contrastLockRelease == 0){
                    for (int counter2 = 0; counter2 < fileListCount; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionH; counter3++){
                            for (int counter4 = 0; counter4 < imageDimensionW; counter4++){
                                if ((int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4]*(double)levelHoldContrast) > 255) tempValue1 = 255;
                                else tempValue1 = (int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4]*(double)levelHoldContrast);
                                
                                if ((int)(tempValue1+levelHoldBrightness) > 255) tempValue1 = 255;
                                else tempValue1 = (int)(tempValue1+levelHoldBrightness);
                                
                                arrayImageResults [counter2*imageDimensionH+counter3][counter4] = tempValue1;
                                imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]+counter4] = tempValue1;
                            }
                        }
                    }
                }
            }
            else{
                
                int newXPosition = xyPositionWritingData [(processingFovNo-1)*3+2];
                int newYPosition = xyPositionWritingData [(processingFovNo-1)*3+1];
                
                int yImageCount = 0;
                int xImageCount = 0;
                
                for (int counter1 = newYPosition; counter1 < newYPosition+imageDimensionH; counter1++){
                    for (int counter2 = newXPosition; counter2 < newXPosition+imageDimensionW; counter2++){
                        if ((int)(arrayImageDataHold [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount]*(double)levelHoldContrast) > 255) tempValue1 = 255;
                        else tempValue1 = (int)(arrayImageDataHold [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount]*(double)levelHoldContrast);
                        
                        if ((int)(tempValue1+levelHoldBrightness) > 255) tempValue1 = 255;
                        else tempValue1 = (int)(tempValue1+levelHoldBrightness);
                        
                        arrayImageResults [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount] = tempValue1;
                        imageDisplayArray [counter1][counter2] = tempValue1;
                        
                        xImageCount++;
                    }
                    
                    yImageCount++;
                    xImageCount = 0;
                }
            }
        }
        else if (photoMetricsHold == 2){
            int tempValue1 = 0;
            int tempValue2 = 0;
            int tempValue3 = 0;
            
            if (imageFLStatus == "Lock" || (processingFovNo == 0 && imageFLStatus == "Free")){
                if (contrastLockRelease == 0){
                    for (int counter2 = 0; counter2 < fileListCount; counter2++){
                        for (int counter3 = 0; counter3 < imageDimensionH; counter3++){
                            for (int counter4 = 0; counter4 < imageDimensionW*3; counter4 = counter4+3){
                                if ((int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4]*(double)levelHoldContrast) > 255) tempValue1 = 255;
                                else tempValue1 = (int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4]*(double)levelHoldContrast);
                                
                                if ((int)(tempValue1+levelHoldBrightness) > 255) tempValue1 = 255;
                                else tempValue1 = (int)(tempValue1+levelHoldBrightness);
                                
                                if (tempValue1 > cutRedHold){
                                    if ((int)(tempValue1+levelHoldRed) > 255) tempValue1 = 255;
                                    else tempValue1 = (int)(tempValue1+levelHoldRed);
                                }
                                
                                if ((int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4+1]*(double)levelHoldContrast) > 255) tempValue2 = 255;
                                else tempValue2 = (int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4+1]*(double)levelHoldContrast);
                                
                                if ((int)(tempValue2+levelHoldBrightness) > 255) tempValue2 = 255;
                                else tempValue2 = (int)(tempValue2+levelHoldBrightness);
                                
                                if (tempValue2 > cutGreenHold){
                                    if ((int)(tempValue2+levelHoldGreen) > 255) tempValue2 = 255;
                                    else tempValue2 = (int)(tempValue2+levelHoldGreen);
                                }
                                
                                if ((int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4+2]*(double)levelHoldContrast) > 255) tempValue3 = 255;
                                else tempValue3 = (int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4+2]*(double)levelHoldContrast);
                                
                                if ((int)(tempValue3+levelHoldBrightness) > 255) tempValue3 = 255;
                                else tempValue3 = (int)(tempValue3+levelHoldBrightness);
                                
                                if (tempValue3 > cutBlueHold){
                                    if ((int)(tempValue3+levelHoldBlue) > 255) tempValue3 = 255;
                                    else tempValue3 = (int)(tempValue3+levelHoldBlue);
                                }
                                
                                arrayImageResults [counter2*imageDimensionH+counter3][counter4] = tempValue1;
                                arrayImageResults [counter2*imageDimensionH+counter3][counter4+1] = tempValue2;
                                arrayImageResults [counter2*imageDimensionH+counter3][counter4+2] = tempValue3;
                                
                                imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4] = tempValue1;
                                imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4+1] = tempValue2;
                                imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4+2] = tempValue3;
                            }
                        }
                    }
                }
            }
            else{
                
                int newXPosition = xyPositionWritingData [(processingFovNo-1)*3+2];
                int newYPosition = xyPositionWritingData [(processingFovNo-1)*3+1];
                
                int yImageCount = 0;
                int xImageCount = 0;
                
                for (int counter1 = newYPosition; counter1 < newYPosition+imageDimensionH; counter1++){
                    for (int counter2 = newXPosition*3; counter2 < newXPosition*3+imageDimensionW*3; counter2 = counter2+3){
                        if ((int)(arrayImageDataHold [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount]*(double)levelHoldContrast) > 255) tempValue1 = 255;
                        else tempValue1 = (int)(arrayImageDataHold [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount]*(double)levelHoldContrast);
                        
                        if ((int)(tempValue1+levelHoldBrightness) > 255) tempValue1 = 255;
                        else tempValue1 = (int)(tempValue1+levelHoldBrightness);
                        
                        if (tempValue1 > cutRedHold){
                            if ((int)(tempValue1+levelHoldRed) > 255) tempValue1 = 255;
                            else tempValue1 = (int)(tempValue1+levelHoldRed);
                        }
                        
                        if ((int)(arrayImageDataHold [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+1]*(double)levelHoldContrast) > 255) tempValue2 = 255;
                        else tempValue2 = (int)(arrayImageDataHold [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+1]*(double)levelHoldContrast);
                        
                        if ((int)(tempValue2+levelHoldBrightness) > 255) tempValue2 = 255;
                        else tempValue2 = (int)(tempValue2+levelHoldBrightness);
                        
                        if (tempValue2 > cutGreenHold){
                            if ((int)(tempValue2+levelHoldGreen) > 255) tempValue2 = 255;
                            else tempValue2 = (int)(tempValue2+levelHoldGreen);
                        }
                        
                        if ((int)(arrayImageDataHold [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+2]*(double)levelHoldContrast) > 255) tempValue3 = 255;
                        else tempValue3 = (int)(arrayImageDataHold [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+2]*(double)levelHoldContrast);
                        
                        if ((int)(tempValue3+levelHoldBrightness) > 255) tempValue3 = 255;
                        else tempValue3 = (int)(tempValue3+levelHoldBrightness);
                        
                        if (tempValue3 > cutBlueHold){
                            if ((int)(tempValue3+levelHoldBlue) > 255) tempValue3 = 255;
                            else tempValue3 = (int)(tempValue3+levelHoldBlue);
                        }
                        
                        arrayImageResults [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount] = tempValue1;
                        arrayImageResults [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+1] = tempValue2;
                        arrayImageResults [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+2] = tempValue3;
                        
                        imageDisplayArray [counter1][counter2] = tempValue1;
                        imageDisplayArray [counter1][counter2+1] = tempValue2;
                        imageDisplayArray [counter1][counter2+2] = tempValue3;
                        
                        xImageCount = xImageCount+3;
                    }
                    
                    yImageCount++;
                    xImageCount = 0;
                }
            }
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
    }
}

-(IBAction)resetBrightness:(id)sender{
    if (imageLoadStatus == 1 && copyProgressFlag == 0){
        if (blurCutHold == 0){
            levelHoldBrightness = 0;
            
            listDataHold [1] = levelHoldBrightness;
            
            [brightnessLevel setDoubleValue:0];
            [sliderBrightness setDoubleValue:0];
            [sliderBrightnessCircle setDoubleValue:1];
            [sliderBrightness setMaxValue:sliderBrightnessMax];
            [sliderBrightness setMinValue:sliderBrightnessMin];
            [sliderKnobBrightness setDoubleValue:levelHoldBrightness];
            
            if (photoMetricsHold == 1){
                int tempValue1 = 0;
                
                if (imageFLStatus == "Lock" || (processingFovNo == 0 && imageFLStatus == "Free")){
                    if (contrastLockRelease == 0){
                        for (int counter2 = 0; counter2 < fileListCount; counter2++){
                            for (int counter3 = 0; counter3 < imageDimensionH; counter3++){
                                for (int counter4 = 0; counter4 < imageDimensionW; counter4++){
                                    if ((int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4]*(double)levelHoldContrast) > 255) tempValue1 = 255;
                                    else tempValue1 = (int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4]*(double)levelHoldContrast);
                                    
                                    if ((int)(tempValue1+levelHoldBrightness) > 255) tempValue1 = 255;
                                    else tempValue1 = (int)(tempValue1+levelHoldBrightness);
                                    
                                    arrayImageResults [counter2*imageDimensionH+counter3][counter4] = tempValue1;
                                    imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]+counter4] = tempValue1;
                                }
                            }
                        }
                    }
                }
                else{
                    
                    int newXPosition = xyPositionWritingData [(processingFovNo-1)*3+2];
                    int newYPosition = xyPositionWritingData [(processingFovNo-1)*3+1];
                    
                    int yImageCount = 0;
                    int xImageCount = 0;
                    
                    for (int counter1 = newYPosition; counter1 < newYPosition+imageDimensionH; counter1++){
                        for (int counter2 = newXPosition; counter2 < newXPosition+imageDimensionW; counter2++){
                            if ((int)(arrayImageDataHold [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount]*(double)levelHoldContrast) > 255) tempValue1 = 255;
                            else tempValue1 = (int)(arrayImageDataHold [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount]*(double)levelHoldContrast);
                            
                            if ((int)(tempValue1+levelHoldBrightness) > 255) tempValue1 = 255;
                            else tempValue1 = (int)(tempValue1+levelHoldBrightness);
                            
                            arrayImageResults [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount] = tempValue1;
                            imageDisplayArray [counter1][counter2] = tempValue1;
                            
                            xImageCount++;
                        }
                        
                        yImageCount++;
                        xImageCount = 0;
                    }
                }
            }
            else if (photoMetricsHold == 2){
                int tempValue1 = 0;
                int tempValue2 = 0;
                int tempValue3 = 0;
                
                if (imageFLStatus == "Lock" || (processingFovNo == 0 && imageFLStatus == "Free")){
                    if (contrastLockRelease == 0){
                        for (int counter2 = 0; counter2 < fileListCount; counter2++){
                            for (int counter3 = 0; counter3 < imageDimensionH; counter3++){
                                for (int counter4 = 0; counter4 < imageDimensionW*3; counter4 = counter4+3){
                                    if ((int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4]*(double)levelHoldContrast) > 255) tempValue1 = 255;
                                    else tempValue1 = (int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4]*(double)levelHoldContrast);
                                    
                                    if ((int)(tempValue1+levelHoldBrightness) > 255) tempValue1 = 255;
                                    else tempValue1 = (int)(tempValue1+levelHoldBrightness);
                                    
                                    if (tempValue1 > cutRedHold){
                                        if ((int)(tempValue1+levelHoldRed) > 255) tempValue1 = 255;
                                        else tempValue1 = (int)(tempValue1+levelHoldRed);
                                    }
                                    
                                    if ((int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4+1]*(double)levelHoldContrast) > 255) tempValue2 = 255;
                                    else tempValue2 = (int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4+1]*(double)levelHoldContrast);
                                    
                                    if ((int)(tempValue2+levelHoldBrightness) > 255) tempValue2 = 255;
                                    else tempValue2 = (int)(tempValue2+levelHoldBrightness);
                                    
                                    if (tempValue2 > cutGreenHold){
                                        if ((int)(tempValue2+levelHoldGreen) > 255) tempValue2 = 255;
                                        else tempValue2 = (int)(tempValue2+levelHoldGreen);
                                    }
                                    
                                    if ((int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4+2]*(double)levelHoldContrast) > 255) tempValue3 = 255;
                                    else tempValue3 = (int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4+2]*(double)levelHoldContrast);
                                    
                                    if ((int)(tempValue3+levelHoldBrightness) > 255) tempValue3 = 255;
                                    else tempValue3 = (int)(tempValue3+levelHoldBrightness);
                                    
                                    if (tempValue3 > cutBlueHold){
                                        if ((int)(tempValue3+levelHoldBlue) > 255) tempValue3 = 255;
                                        else tempValue3 = (int)(tempValue3+levelHoldBlue);
                                    }
                                    
                                    arrayImageResults [counter2*imageDimensionH+counter3][counter4] = tempValue1;
                                    arrayImageResults [counter2*imageDimensionH+counter3][counter4+1] = tempValue2;
                                    arrayImageResults [counter2*imageDimensionH+counter3][counter4+2] = tempValue3;
                                    
                                    imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4] = tempValue1;
                                    imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4+1] = tempValue2;
                                    imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4+2] = tempValue3;
                                }
                            }
                        }
                    }
                }
                else{
                    
                    int newXPosition = xyPositionWritingData [(processingFovNo-1)*3+2];
                    int newYPosition = xyPositionWritingData [(processingFovNo-1)*3+1];
                    
                    int yImageCount = 0;
                    int xImageCount = 0;
                    
                    for (int counter1 = newYPosition; counter1 < newYPosition+imageDimensionH; counter1++){
                        for (int counter2 = newXPosition*3; counter2 < newXPosition*3+imageDimensionW*3; counter2 = counter2+3){
                            if ((int)(arrayImageDataHold [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount]*(double)levelHoldContrast) > 255) tempValue1 = 255;
                            else tempValue1 = (int)(arrayImageDataHold [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount]*(double)levelHoldContrast);
                            
                            if ((int)(tempValue1+levelHoldBrightness) > 255) tempValue1 = 255;
                            else tempValue1 = (int)(tempValue1+levelHoldBrightness);
                            
                            if (tempValue1 > cutRedHold){
                                if ((int)(tempValue1+levelHoldRed) > 255) tempValue1 = 255;
                                else tempValue1 = (int)(tempValue1+levelHoldRed);
                            }
                            
                            if ((int)(arrayImageDataHold [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+1]*(double)levelHoldContrast) > 255) tempValue2 = 255;
                            else tempValue2 = (int)(arrayImageDataHold [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+1]*(double)levelHoldContrast);
                            
                            if ((int)(tempValue2+levelHoldBrightness) > 255) tempValue2 = 255;
                            else tempValue2 = (int)(tempValue2+levelHoldBrightness);
                            
                            if (tempValue2 > cutGreenHold){
                                if ((int)(tempValue2+levelHoldGreen) > 255) tempValue2 = 255;
                                else tempValue2 = (int)(tempValue2+levelHoldGreen);
                            }
                            
                            if ((int)(arrayImageDataHold [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+2]*(double)levelHoldContrast) > 255) tempValue3 = 255;
                            else tempValue3 = (int)(arrayImageDataHold [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+2]*(double)levelHoldContrast);
                            
                            if ((int)(tempValue3+levelHoldBrightness) > 255) tempValue3 = 255;
                            else tempValue3 = (int)(tempValue3+levelHoldBrightness);
                            
                            if (tempValue3 > cutBlueHold){
                                if ((int)(tempValue3+levelHoldBlue) > 255) tempValue3 = 255;
                                else tempValue3 = (int)(tempValue3+levelHoldBlue);
                            }
                            
                            arrayImageResults [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount] = tempValue1;
                            arrayImageResults [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+1] = tempValue2;
                            arrayImageResults [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+2] = tempValue3;
                            
                            imageDisplayArray [counter1][counter2] = tempValue1;
                            imageDisplayArray [counter1][counter2+1] = tempValue2;
                            imageDisplayArray [counter1][counter2+2] = tempValue3;
                            
                            xImageCount = xImageCount+3;
                        }
                        
                        yImageCount++;
                        xImageCount = 0;
                    }
                }
            }
        }
        else{
            
            levelHoldBlur = 0;
            
            [brightnessLevel setDoubleValue:0];
            [sliderBrightness setDoubleValue:0];
            [sliderBrightnessCircle setDoubleValue:1];
            [sliderBrightness setMaxValue:sliderBrightnessMax];
            [sliderBrightness setMinValue:sliderBrightnessMin];
            [sliderKnobBrightness setDoubleValue:levelHoldBrightness];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
    }
}

-(IBAction)resetRed:(id)sender{
    if (imageLoadStatus == 1 && copyProgressFlag == 0){
        cutRedHold = 0;
        levelHoldRed = 0;
        cutRedHoldPick = 10;
        levelHoldRedPick = 0;
        
        listDataHold [2] = levelHoldRed;
        listDataHold [3] = cutRedHold;
        
        cursorRedMax = 0;
        cursorRedMin = 0;
        
        if (colorPickStatusHold == 0){
            [redCut setDoubleValue:0];
            [redLevel setDoubleValue:0];
            
            [sliderRed setMaxValue:sliderRedMax];
            [sliderRed setMinValue:sliderRedMin];
            
            [sliderRedCut setMaxValue:sliderCutRedMax];
            [sliderRedCut setMinValue:sliderCutRedMin];
            
            [sliderRed setDoubleValue:0];
            [sliderRedCut setDoubleValue:0];
            [sliderRedCircle setDoubleValue:1];
            [sliderRedCutCircle setDoubleValue:1];
            
            [sliderKnobRed setDoubleValue:0];
            [sliderKnobRedCut setDoubleValue:0];
            
            if (photoMetricsHold == 2){
                int tempValue1 = 0;
                
                if (imageFLStatus == "Lock" || (processingFovNo == 0 && imageFLStatus == "Free")){
                    if (contrastLockRelease == 0){
                        for (int counter2 = 0; counter2 < fileListCount; counter2++){
                            for (int counter3 = 0; counter3 < imageDimensionH; counter3++){
                                for (int counter4 = 0; counter4 < imageDimensionW*3; counter4 = counter4+3){
                                    if ((int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4]*(double)levelHoldContrast) > 255) tempValue1 = 255;
                                    else tempValue1 = (int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4]*(double)levelHoldContrast);
                                    
                                    if ((int)(tempValue1+levelHoldBrightness) > 255) tempValue1 = 255;
                                    else tempValue1 = (int)(tempValue1+levelHoldBrightness);
                                    
                                    if (tempValue1 > cutRedHold){
                                        if ((int)(tempValue1+levelHoldRed) > 255) tempValue1 = 255;
                                        else tempValue1 = (int)(tempValue1+levelHoldRed);
                                    }
                                    
                                    arrayImageResults [counter2*imageDimensionH+counter3][counter4] = tempValue1;
                                    imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4] = tempValue1;
                                }
                            }
                        }
                    }
                }
                else{
                    
                    int newXPosition = xyPositionWritingData [(processingFovNo-1)*3+2];
                    int newYPosition = xyPositionWritingData [(processingFovNo-1)*3+1];
                    
                    int yImageCount = 0;
                    int xImageCount = 0;
                    
                    for (int counter1 = newYPosition; counter1 < newYPosition+imageDimensionH; counter1++){
                        for (int counter2 = newXPosition*3; counter2 < newXPosition*3+imageDimensionW*3; counter2 = counter2+3){
                            if ((int)(arrayImageDataHold [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount]*(double)levelHoldContrast) > 255) tempValue1 = 255;
                            else tempValue1 = (int)(arrayImageDataHold [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount]*(double)levelHoldContrast);
                            
                            if ((int)(tempValue1+levelHoldBrightness) > 255) tempValue1 = 255;
                            else tempValue1 = (int)(tempValue1+levelHoldBrightness);
                            
                            if (tempValue1 > cutRedHold){
                                if ((int)(tempValue1+levelHoldRed) > 255) tempValue1 = 255;
                                else tempValue1 = (int)(tempValue1+levelHoldRed);
                            }
                            
                            arrayImageResults [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount] = tempValue1;
                            imageDisplayArray [counter1][counter2] = tempValue1;
                            
                            xImageCount = xImageCount+3;
                        }
                        
                        yImageCount++;
                        xImageCount = 0;
                    }
                }
            }
        }
        else{
            
            string displayString = to_string(cursorRedMin)+"-"+to_string(cursorRedMax)+" Av: 0";
            
            [rRangeDisplay setStringValue:@(displayString.c_str())];
            
            [redCut setDoubleValue:10];
            [redLevel setDoubleValue:0];
            
            [sliderRed setMaxValue:sliderRedMax];
            [sliderRed setMinValue:sliderRedMin];
            
            [sliderRedCut setMaxValue:sliderCutRedMax];
            [sliderRedCut setMinValue:sliderCutRedMin];
            
            [sliderRed setDoubleValue:0];
            [sliderRedCut setDoubleValue:10];
            [sliderRedCircle setDoubleValue:1];
            [sliderRedCutCircle setDoubleValue:1];
            
            [sliderKnobRed setDoubleValue:0];
            [sliderKnobRedCut setDoubleValue:10];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
    }
}

-(IBAction)resetGreen:(id)sender{
    if (imageLoadStatus == 1 && copyProgressFlag == 0){
        cutGreenHold = 0;
        levelHoldGreen = 0;
        cutGreenHoldPick = 10;
        levelHoldGreenPick = 0;
        
        listDataHold [4] = levelHoldGreen;
        listDataHold [5] = cutGreenHold;
        
        cursorGreenMax = 0;
        cursorGreenMin = 0;
        
        if (colorPickStatusHold == 0){
            [greenCut setDoubleValue:0];
            [greenLevel setDoubleValue:0];
            
            [sliderGreen setMaxValue:sliderGreenMax];
            [sliderGreen setMinValue:sliderGreenMin];
            
            [sliderGreenCut setMaxValue:sliderCutGreenMax];
            [sliderGreenCut setMinValue:sliderCutGreenMin];
            
            [sliderGreen setDoubleValue:0];
            [sliderGreenCut setDoubleValue:0];
            [sliderGreenCircle setDoubleValue:1];
            [sliderGreenCutCircle setDoubleValue:1];
            
            [sliderKnobGreen setDoubleValue:0];
            [sliderKnobGreenCut setDoubleValue:0];
            
            if (photoMetricsHold == 2){
                int tempValue2 = 0;
                
                if (imageFLStatus == "Lock" || (processingFovNo == 0 && imageFLStatus == "Free")){
                    if (contrastLockRelease == 0){
                        for (int counter2 = 0; counter2 < fileListCount; counter2++){
                            for (int counter3 = 0; counter3 < imageDimensionH; counter3++){
                                for (int counter4 = 0; counter4 < imageDimensionW*3; counter4 = counter4+3){
                                    if ((int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4+1]*(double)levelHoldContrast) > 255) tempValue2 = 255;
                                    else tempValue2 = (int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4+1]*(double)levelHoldContrast);
                                    
                                    if ((int)(tempValue2+levelHoldBrightness) > 255) tempValue2 = 255;
                                    else tempValue2 = (int)(tempValue2+levelHoldBrightness);
                                    
                                    if (tempValue2 > cutGreenHold){
                                        if ((int)(tempValue2+levelHoldGreen) > 255) tempValue2 = 255;
                                        else tempValue2 = (int)(tempValue2+levelHoldGreen);
                                    }
                                    
                                    arrayImageResults [counter2*imageDimensionH+counter3][counter4+1] = tempValue2;
                                    imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4+1] = tempValue2;
                                }
                            }
                        }
                    }
                }
                else{
                    
                    int newXPosition = xyPositionWritingData [(processingFovNo-1)*3+2];
                    int newYPosition = xyPositionWritingData [(processingFovNo-1)*3+1];
                    
                    int yImageCount = 0;
                    int xImageCount = 0;
                    
                    for (int counter1 = newYPosition; counter1 < newYPosition+imageDimensionH; counter1++){
                        for (int counter2 = newXPosition*3; counter2 < newXPosition*3+imageDimensionW*3; counter2 = counter2+3){
                            if ((int)(arrayImageDataHold [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+1]*(double)levelHoldContrast) > 255) tempValue2 = 255;
                            else tempValue2 = (int)(arrayImageDataHold [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+1]*(double)levelHoldContrast);
                            
                            if ((int)(tempValue2+levelHoldBrightness) > 255) tempValue2 = 255;
                            else tempValue2 = (int)(tempValue2+levelHoldBrightness);
                            
                            if (tempValue2 > cutGreenHold){
                                if ((int)(tempValue2+levelHoldGreen) > 255) tempValue2 = 255;
                                else tempValue2 = (int)(tempValue2+levelHoldGreen);
                            }
                            
                            arrayImageResults [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+1] = tempValue2;
                            imageDisplayArray [counter1][counter2+1] = tempValue2;
                            
                            xImageCount = xImageCount+3;
                        }
                        
                        yImageCount++;
                        xImageCount = 0;
                    }
                }
            }
        }
        else{
            
            string displayString = to_string(cursorGreenMin)+"-"+to_string(cursorGreenMax)+" Av: 0";
            
            [gRangeDisplay setStringValue:@(displayString.c_str())];
            
            [greenCut setDoubleValue:10];
            [greenLevel setDoubleValue:0];
            
            [sliderGreen setMaxValue:sliderGreenMax];
            [sliderGreen setMinValue:sliderGreenMin];
            
            [sliderGreenCut setMaxValue:sliderCutGreenMax];
            [sliderGreenCut setMinValue:sliderCutGreenMin];
            
            [sliderGreen setDoubleValue:0];
            [sliderGreenCut setDoubleValue:10];
            [sliderGreenCircle setDoubleValue:1];
            [sliderGreenCutCircle setDoubleValue:1];
            
            [sliderKnobGreen setDoubleValue:0];
            [sliderKnobGreenCut setDoubleValue:10];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
    }
}

-(IBAction)resetBlue:(id)sender{
    if (imageLoadStatus == 1 && copyProgressFlag == 0){
        cutBlueHold = 0;
        levelHoldBlue = 0;
        cutBlueHoldPick = 10;
        levelHoldBluePick = 0;
        
        listDataHold [6] = levelHoldBlue;
        listDataHold [7] = cutBlueHold;
        
        cursorBlueMax = 0;
        cursorBlueMin = 0;
        
        if (colorPickStatusHold == 0){
            [blueCut setDoubleValue:0];
            [blueLevel setDoubleValue:0];
            
            [sliderBlue setMaxValue:sliderBlueMax];
            [sliderBlue setMinValue:sliderBlueMin];
            
            [sliderBlueCut setMaxValue:sliderCutBlueMax];
            [sliderBlueCut setMinValue:sliderCutBlueMin];
            
            [sliderBlue setDoubleValue:0];
            [sliderBlueCut setDoubleValue:0];
            [sliderBlueCircle setDoubleValue:1];
            [sliderBlueCutCircle setDoubleValue:1];
            
            [sliderKnobBlue setDoubleValue:0];
            [sliderKnobBlueCut setDoubleValue:0];
            
            if (photoMetricsHold == 2){
                int tempValue3 = 0;
                
                if (imageFLStatus == "Lock" || (processingFovNo == 0 && imageFLStatus == "Free")){
                    if (contrastLockRelease == 0){
                        for (int counter2 = 0; counter2 < fileListCount; counter2++){
                            for (int counter3 = 0; counter3 < imageDimensionH; counter3++){
                                for (int counter4 = 0; counter4 < imageDimensionW*3; counter4 = counter4+3){
                                    if ((int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4+2]*(double)levelHoldContrast) > 255) tempValue3 = 255;
                                    else tempValue3 = (int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4+2]*(double)levelHoldContrast);
                                    
                                    if ((int)(tempValue3+levelHoldBrightness) > 255) tempValue3 = 255;
                                    else tempValue3 = (int)(tempValue3+levelHoldBrightness);
                                    
                                    if (tempValue3 > cutBlueHold){
                                        if ((int)(tempValue3+levelHoldBlue) > 255) tempValue3 = 255;
                                        else tempValue3 = (int)(tempValue3+levelHoldBlue);
                                    }
                                    
                                    arrayImageResults [counter2*imageDimensionH+counter3][counter4+2] = tempValue3;
                                    imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4+2] = tempValue3;
                                }
                            }
                        }
                    }
                }
                else{
                    
                    int newXPosition = xyPositionWritingData [(processingFovNo-1)*3+2];
                    int newYPosition = xyPositionWritingData [(processingFovNo-1)*3+1];
                    
                    int yImageCount = 0;
                    int xImageCount = 0;
                    
                    for (int counter1 = newYPosition; counter1 < newYPosition+imageDimensionH; counter1++){
                        for (int counter2 = newXPosition*3; counter2 < newXPosition*3+imageDimensionW*3; counter2 = counter2+3){
                            if ((arrayImageDataHold [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+2]*(double)levelHoldContrast) > 255) tempValue3 = 255;
                            else tempValue3 = (int)(arrayImageDataHold [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+2]*(double)levelHoldContrast);
                            
                            if ((int)(tempValue3+levelHoldBrightness) > 255) tempValue3 = 255;
                            else tempValue3 = (int)(tempValue3+levelHoldBrightness);
                            
                            if (tempValue3 > cutBlueHold){
                                if ((int)(tempValue3+levelHoldBlue) > 255) tempValue3 = 255;
                                else tempValue3 = (int)(tempValue3+levelHoldBlue);
                            }
                            
                            arrayImageResults [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+2] = tempValue3;
                            imageDisplayArray [counter1][counter2+2] = tempValue3;
                            
                            xImageCount = xImageCount+3;
                        }
                        
                        yImageCount++;
                        xImageCount = 0;
                    }
                }
            }
        }
        else{
            
            string displayString = to_string(cursorBlueMin)+"-"+to_string(cursorBlueMax)+" Av: 0";
            
            [bRangeDisplay setStringValue:@(displayString.c_str())];
            
            [blueCut setDoubleValue:10];
            [blueLevel setDoubleValue:0];
            
            [sliderBlue setMaxValue:sliderBlueMax];
            [sliderBlue setMinValue:sliderBlueMin];
            
            [sliderBlueCut setMaxValue:sliderCutBlueMax];
            [sliderBlueCut setMinValue:sliderCutBlueMin];
            
            [sliderBlue setDoubleValue:0];
            [sliderBlueCut setDoubleValue:10];
            [sliderBlueCircle setDoubleValue:1];
            [sliderBlueCutCircle setDoubleValue:1];
            
            [sliderKnobBlue setDoubleValue:0];
            [sliderKnobBlueCut setDoubleValue:10];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
    }
}

-(IBAction)resetRGB:(id)sender{
    if (imageLoadStatus == 1 && copyProgressFlag == 0){
        cutRedHold = 0;
        levelHoldRed = 0;
        cutRedHoldPick = 10;
        levelHoldRedPick = 0;
        
        cursorRedMax = 0;
        cursorRedMin = 0;
        
        cutGreenHold = 0;
        levelHoldGreen = 0;
        cutGreenHoldPick = 10;
        levelHoldGreenPick = 0;
        
        cursorGreenMax = 0;
        cursorGreenMin = 0;
        
        cutBlueHold = 0;
        levelHoldBlue = 0;
        cutBlueHoldPick = 10;
        levelHoldBluePick = 0;
        
        cursorBlueMax = 0;
        cursorBlueMin = 0;
        
        listDataHold [2] = levelHoldRed;
        listDataHold [3] = cutRedHold;
        listDataHold [4] = levelHoldGreen;
        listDataHold [5] = cutGreenHold;
        listDataHold [6] = levelHoldBlue;
        listDataHold [7] = cutBlueHold;
        
        if (colorPickStatusHold == 0){
            [redCut setDoubleValue:0];
            [redLevel setDoubleValue:0];
            
            [sliderRed setMaxValue:sliderRedMax];
            [sliderRed setMinValue:sliderRedMin];
            
            [sliderRedCut setMaxValue:sliderCutRedMax];
            [sliderRedCut setMinValue:sliderCutRedMin];
            
            [sliderRed setDoubleValue:0];
            [sliderRedCut setDoubleValue:0];
            [sliderRedCircle setDoubleValue:1];
            [sliderRedCutCircle setDoubleValue:1];
            
            [sliderKnobRed setDoubleValue:0];
            [sliderKnobRedCut setDoubleValue:0];
            [greenCut setDoubleValue:0];
            [greenLevel setDoubleValue:0];
            
            [sliderGreen setMaxValue:sliderGreenMax];
            [sliderGreen setMinValue:sliderGreenMin];
            
            [sliderGreenCut setMaxValue:sliderCutGreenMax];
            [sliderGreenCut setMinValue:sliderCutGreenMin];
            
            [sliderGreen setDoubleValue:0];
            [sliderGreenCut setDoubleValue:0];
            [sliderGreenCircle setDoubleValue:1];
            [sliderGreenCutCircle setDoubleValue:1];
            
            [sliderKnobGreen setDoubleValue:0];
            [sliderKnobGreenCut setDoubleValue:0];
            
            [blueCut setDoubleValue:0];
            [blueLevel setDoubleValue:0];
            
            [sliderBlue setMaxValue:sliderBlueMax];
            [sliderBlue setMinValue:sliderBlueMin];
            
            [sliderBlueCut setMaxValue:sliderCutBlueMax];
            [sliderBlueCut setMinValue:sliderCutBlueMin];
            
            [sliderBlue setDoubleValue:0];
            [sliderBlueCut setDoubleValue:0];
            [sliderBlueCircle setDoubleValue:1];
            [sliderBlueCutCircle setDoubleValue:1];
            
            [sliderKnobBlue setDoubleValue:0];
            [sliderKnobBlueCut setDoubleValue:0];
            
            if (photoMetricsHold == 2){
                int tempValue1 = 0;
                int tempValue2 = 0;
                int tempValue3 = 0;
                
                if (imageFLStatus == "Lock" || (processingFovNo == 0 && imageFLStatus == "Free")){
                    if (contrastLockRelease == 0){
                        for (int counter2 = 0; counter2 < fileListCount; counter2++){
                            for (int counter3 = 0; counter3 < imageDimensionH; counter3++){
                                for (int counter4 = 0; counter4 < imageDimensionW*3; counter4 = counter4+3){
                                    if ((int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4]*(double)levelHoldContrast) > 255) tempValue1 = 255;
                                    else tempValue1 = (int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4]*(double)levelHoldContrast);
                                    
                                    if ((int)(tempValue1+levelHoldBrightness) > 255) tempValue1 = 255;
                                    else tempValue1 = (int)(tempValue1+levelHoldBrightness);
                                    
                                    if (tempValue1 > cutRedHold){
                                        if ((int)(tempValue1+levelHoldRed) > 255) tempValue1 = 255;
                                        else tempValue1 = (int)(tempValue1+levelHoldRed);
                                    }
                                    
                                    arrayImageResults [counter2*imageDimensionH+counter3][counter4] = tempValue1;
                                    
                                    if ((int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4+1]*(double)levelHoldContrast) > 255) tempValue2 = 255;
                                    else tempValue2 = (int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4+1]*(double)levelHoldContrast);
                                    
                                    if ((int)(tempValue2+levelHoldBrightness) > 255) tempValue2 = 255;
                                    else tempValue2 = (int)(tempValue2+levelHoldBrightness);
                                    
                                    if (tempValue2 > cutGreenHold){
                                        if ((int)(tempValue2+levelHoldGreen) > 255) tempValue2 = 255;
                                        else tempValue2 = (int)(tempValue2+levelHoldGreen);
                                    }
                                    
                                    arrayImageResults [counter2*imageDimensionH+counter3][counter4+1] = tempValue2;
                                    
                                    if ((int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4+2]*(double)levelHoldContrast) > 255) tempValue3 = 255;
                                    else tempValue3 = (int)(arrayImageDataHold [counter2*imageDimensionH+counter3][counter4+2]*(double)levelHoldContrast);
                                    
                                    if ((int)(tempValue3+levelHoldBrightness) > 255) tempValue3 = 255;
                                    else tempValue3 = (int)(tempValue3+levelHoldBrightness);
                                    
                                    if (tempValue3 > cutBlueHold){
                                        if ((int)(tempValue3+levelHoldBlue) > 255) tempValue3 = 255;
                                        else tempValue3 = (int)(tempValue3+levelHoldBlue);
                                    }
                                    
                                    arrayImageResults [counter2*imageDimensionH+counter3][counter4+2] = tempValue3;
                                    
                                    imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4] = tempValue1;
                                    imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4+1] = tempValue2;
                                    imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4+2] = tempValue3;
                                }
                            }
                        }
                    }
                }
                else{
                    
                    int newXPosition = xyPositionWritingData [(processingFovNo-1)*3+2];
                    int newYPosition = xyPositionWritingData [(processingFovNo-1)*3+1];
                    
                    int yImageCount = 0;
                    int xImageCount = 0;
                    
                    for (int counter1 = newYPosition; counter1 < newYPosition+imageDimensionH; counter1++){
                        for (int counter2 = newXPosition*3; counter2 < newXPosition*3+imageDimensionW*3; counter2 = counter2+3){
                            if ((int)(arrayImageDataHold [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount]*(double)levelHoldContrast) > 255) tempValue1 = 255;
                            else tempValue1 = (int)(arrayImageDataHold [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount]*(double)levelHoldContrast);
                            
                            if ((int)(tempValue1+levelHoldBrightness) > 255) tempValue1 = 255;
                            else tempValue1 = (int)(tempValue1+levelHoldBrightness);
                            
                            if (tempValue1 > cutRedHold){
                                if ((int)(tempValue1+levelHoldRed) > 255) tempValue1 = 255;
                                else tempValue1 = (int)(tempValue1+levelHoldRed);
                            }
                            
                            arrayImageResults [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount] = tempValue1;
                            
                            if ((int)(arrayImageDataHold [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+1]*(double)levelHoldContrast) > 255) tempValue2 = 255;
                            else tempValue2 = (int)(arrayImageDataHold [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+1]*(double)levelHoldContrast);
                            
                            if ((int)(tempValue2+levelHoldBrightness) > 255) tempValue2 = 255;
                            else tempValue2 = (int)(tempValue2+levelHoldBrightness);
                            
                            if (tempValue2 > cutGreenHold){
                                if ((int)(tempValue2+levelHoldGreen) > 255) tempValue2 = 255;
                                else tempValue2 = (int)(tempValue2+levelHoldGreen);
                            }
                            
                            arrayImageResults [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+1] = tempValue2;
                            
                            if ((arrayImageDataHold [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+2]*(double)levelHoldContrast) > 255) tempValue3 = 255;
                            else tempValue3 = (int)(arrayImageDataHold [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+2]*(double)levelHoldContrast);
                            
                            if ((int)(tempValue3+levelHoldBrightness) > 255) tempValue3 = 255;
                            else tempValue3 = (int)(tempValue3+levelHoldBrightness);
                            
                            if (tempValue3 > cutBlueHold){
                                if ((int)(tempValue3+levelHoldBlue) > 255) tempValue3 = 255;
                                else tempValue3 = (int)(tempValue3+levelHoldBlue);
                            }
                            
                            arrayImageResults [(processingFovNo-1)*imageDimensionH+yImageCount][xImageCount+2] = tempValue3;
                            
                            imageDisplayArray [counter1][counter2] = tempValue1;
                            imageDisplayArray [counter1][counter2+1] = tempValue2;
                            imageDisplayArray [counter1][counter2+2] = tempValue3;
                            
                            xImageCount = xImageCount+3;
                        }
                        
                        yImageCount++;
                        xImageCount = 0;
                    }
                }
            }
        }
        else{
            
            string displayString = to_string(cursorRedMin)+"-"+to_string(cursorRedMax)+" Av: 0";
            
            [rRangeDisplay setStringValue:@(displayString.c_str())];
            
            [redCut setDoubleValue:10];
            [redLevel setDoubleValue:0];
            
            [sliderRed setMaxValue:sliderRedMax];
            [sliderRed setMinValue:sliderRedMin];
            
            [sliderRedCut setMaxValue:sliderCutRedMax];
            [sliderRedCut setMinValue:sliderCutRedMin];
            
            [sliderRed setDoubleValue:0];
            [sliderRedCut setDoubleValue:10];
            [sliderRedCircle setDoubleValue:1];
            [sliderRedCutCircle setDoubleValue:1];
            
            [sliderKnobRed setDoubleValue:0];
            [sliderKnobRedCut setDoubleValue:10];
            
            displayString = to_string(cursorGreenMin)+"-"+to_string(cursorGreenMax)+" Av: 0";
            
            [gRangeDisplay setStringValue:@(displayString.c_str())];
            
            [greenCut setDoubleValue:10];
            [greenLevel setDoubleValue:0];
            
            [sliderGreen setMaxValue:sliderGreenMax];
            [sliderGreen setMinValue:sliderGreenMin];
            
            [sliderGreenCut setMaxValue:sliderCutGreenMax];
            [sliderGreenCut setMinValue:sliderCutGreenMin];
            
            [sliderGreen setDoubleValue:0];
            [sliderGreenCut setDoubleValue:10];
            [sliderGreenCircle setDoubleValue:1];
            [sliderGreenCutCircle setDoubleValue:1];
            
            [sliderKnobGreen setDoubleValue:0];
            [sliderKnobGreenCut setDoubleValue:10];
            
            displayString = to_string(cursorBlueMin)+"-"+to_string(cursorBlueMax)+" Av: 0";
            
            [bRangeDisplay setStringValue:@(displayString.c_str())];
            
            [blueCut setDoubleValue:10];
            [blueLevel setDoubleValue:0];
            
            [sliderBlue setMaxValue:sliderBlueMax];
            [sliderBlue setMinValue:sliderBlueMin];
            
            [sliderBlueCut setMaxValue:sliderCutBlueMax];
            [sliderBlueCut setMinValue:sliderCutBlueMin];
            
            [sliderBlue setDoubleValue:0];
            [sliderBlueCut setDoubleValue:10];
            [sliderBlueCircle setDoubleValue:1];
            [sliderBlueCutCircle setDoubleValue:1];
            
            [sliderKnobBlue setDoubleValue:0];
            [sliderKnobBlueCut setDoubleValue:10];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMovieDisplay object:self];
    }
}

-(IBAction)clearTable:(id)sender{
    for (int counter1 = 0; counter1 < 81; counter1++){
        currentListInformation [counter1] = "";
    }
    
    [xyAssign11 setStringValue:@(currentListInformation [0].c_str())];
    [xyAssign12 setStringValue:@(currentListInformation [1].c_str())];
    [xyAssign13 setStringValue:@(currentListInformation [2].c_str())];
    [xyAssign14 setStringValue:@(currentListInformation [3].c_str())];
    [xyAssign15 setStringValue:@(currentListInformation [4].c_str())];
    [xyAssign16 setStringValue:@(currentListInformation [5].c_str())];
    [xyAssign17 setStringValue:@(currentListInformation [6].c_str())];
    [xyAssign18 setStringValue:@(currentListInformation [7].c_str())];
    [xyAssign19 setStringValue:@(currentListInformation [8].c_str())];
    
    [xyAssign21 setStringValue:@(currentListInformation [9].c_str())];
    [xyAssign22 setStringValue:@(currentListInformation [10].c_str())];
    [xyAssign23 setStringValue:@(currentListInformation [11].c_str())];
    [xyAssign24 setStringValue:@(currentListInformation [12].c_str())];
    [xyAssign25 setStringValue:@(currentListInformation [13].c_str())];
    [xyAssign26 setStringValue:@(currentListInformation [14].c_str())];
    [xyAssign27 setStringValue:@(currentListInformation [15].c_str())];
    [xyAssign28 setStringValue:@(currentListInformation [16].c_str())];
    [xyAssign29 setStringValue:@(currentListInformation [17].c_str())];
    
    [xyAssign31 setStringValue:@(currentListInformation [18].c_str())];
    [xyAssign32 setStringValue:@(currentListInformation [19].c_str())];
    [xyAssign33 setStringValue:@(currentListInformation [20].c_str())];
    [xyAssign34 setStringValue:@(currentListInformation [21].c_str())];
    [xyAssign35 setStringValue:@(currentListInformation [22].c_str())];
    [xyAssign36 setStringValue:@(currentListInformation [23].c_str())];
    [xyAssign37 setStringValue:@(currentListInformation [24].c_str())];
    [xyAssign38 setStringValue:@(currentListInformation [25].c_str())];
    [xyAssign39 setStringValue:@(currentListInformation [26].c_str())];
    
    [xyAssign41 setStringValue:@(currentListInformation [27].c_str())];
    [xyAssign42 setStringValue:@(currentListInformation [28].c_str())];
    [xyAssign43 setStringValue:@(currentListInformation [29].c_str())];
    [xyAssign44 setStringValue:@(currentListInformation [30].c_str())];
    [xyAssign45 setStringValue:@(currentListInformation [31].c_str())];
    [xyAssign46 setStringValue:@(currentListInformation [32].c_str())];
    [xyAssign47 setStringValue:@(currentListInformation [33].c_str())];
    [xyAssign48 setStringValue:@(currentListInformation [34].c_str())];
    [xyAssign49 setStringValue:@(currentListInformation [35].c_str())];
    
    [xyAssign51 setStringValue:@(currentListInformation [36].c_str())];
    [xyAssign52 setStringValue:@(currentListInformation [37].c_str())];
    [xyAssign53 setStringValue:@(currentListInformation [38].c_str())];
    [xyAssign54 setStringValue:@(currentListInformation [39].c_str())];
    [xyAssign55 setStringValue:@(currentListInformation [40].c_str())];
    [xyAssign56 setStringValue:@(currentListInformation [41].c_str())];
    [xyAssign57 setStringValue:@(currentListInformation [42].c_str())];
    [xyAssign58 setStringValue:@(currentListInformation [43].c_str())];
    [xyAssign59 setStringValue:@(currentListInformation [44].c_str())];
    
    [xyAssign61 setStringValue:@(currentListInformation [45].c_str())];
    [xyAssign62 setStringValue:@(currentListInformation [46].c_str())];
    [xyAssign63 setStringValue:@(currentListInformation [47].c_str())];
    [xyAssign64 setStringValue:@(currentListInformation [48].c_str())];
    [xyAssign65 setStringValue:@(currentListInformation [49].c_str())];
    [xyAssign66 setStringValue:@(currentListInformation [50].c_str())];
    [xyAssign67 setStringValue:@(currentListInformation [51].c_str())];
    [xyAssign68 setStringValue:@(currentListInformation [52].c_str())];
    [xyAssign69 setStringValue:@(currentListInformation [53].c_str())];
    
    [xyAssign71 setStringValue:@(currentListInformation [54].c_str())];
    [xyAssign72 setStringValue:@(currentListInformation [55].c_str())];
    [xyAssign73 setStringValue:@(currentListInformation [56].c_str())];
    [xyAssign74 setStringValue:@(currentListInformation [57].c_str())];
    [xyAssign75 setStringValue:@(currentListInformation [58].c_str())];
    [xyAssign76 setStringValue:@(currentListInformation [59].c_str())];
    [xyAssign77 setStringValue:@(currentListInformation [60].c_str())];
    [xyAssign78 setStringValue:@(currentListInformation [61].c_str())];
    [xyAssign79 setStringValue:@(currentListInformation [62].c_str())];
    
    [xyAssign81 setStringValue:@(currentListInformation [63].c_str())];
    [xyAssign82 setStringValue:@(currentListInformation [64].c_str())];
    [xyAssign83 setStringValue:@(currentListInformation [65].c_str())];
    [xyAssign84 setStringValue:@(currentListInformation [66].c_str())];
    [xyAssign85 setStringValue:@(currentListInformation [67].c_str())];
    [xyAssign86 setStringValue:@(currentListInformation [68].c_str())];
    [xyAssign87 setStringValue:@(currentListInformation [69].c_str())];
    [xyAssign88 setStringValue:@(currentListInformation [70].c_str())];
    [xyAssign89 setStringValue:@(currentListInformation [71].c_str())];
    
    [xyAssign91 setStringValue:@(currentListInformation [72].c_str())];
    [xyAssign92 setStringValue:@(currentListInformation [73].c_str())];
    [xyAssign93 setStringValue:@(currentListInformation [74].c_str())];
    [xyAssign94 setStringValue:@(currentListInformation [75].c_str())];
    [xyAssign95 setStringValue:@(currentListInformation [76].c_str())];
    [xyAssign96 setStringValue:@(currentListInformation [77].c_str())];
    [xyAssign97 setStringValue:@(currentListInformation [78].c_str())];
    [xyAssign98 setStringValue:@(currentListInformation [79].c_str())];
    [xyAssign99 setStringValue:@(currentListInformation [80].c_str())];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)saveTable:(id)sender{
    if (currentListName != "" && currentListNumber != "" && imageLoadStatus == 1 && copyProgressFlag == 0){
        currentListInformation [0] = [[xyAssign11 stringValue] UTF8String];
        currentListInformation [1] = [[xyAssign12 stringValue] UTF8String];
        currentListInformation [2] = [[xyAssign13 stringValue] UTF8String];
        currentListInformation [3] = [[xyAssign14 stringValue] UTF8String];
        currentListInformation [4] = [[xyAssign15 stringValue] UTF8String];
        currentListInformation [5] = [[xyAssign16 stringValue] UTF8String];
        currentListInformation [6] = [[xyAssign17 stringValue] UTF8String];
        currentListInformation [7] = [[xyAssign18 stringValue] UTF8String];
        currentListInformation [8] = [[xyAssign19 stringValue] UTF8String];
        
        currentListInformation [9] = [[xyAssign21 stringValue] UTF8String];
        currentListInformation [10] = [[xyAssign22 stringValue] UTF8String];
        currentListInformation [11] = [[xyAssign23 stringValue] UTF8String];
        currentListInformation [12] = [[xyAssign24 stringValue] UTF8String];
        currentListInformation [13] = [[xyAssign25 stringValue] UTF8String];
        currentListInformation [14] = [[xyAssign26 stringValue] UTF8String];
        currentListInformation [15] = [[xyAssign27 stringValue] UTF8String];
        currentListInformation [16] = [[xyAssign28 stringValue] UTF8String];
        currentListInformation [17] = [[xyAssign29 stringValue] UTF8String];
        
        currentListInformation [18] = [[xyAssign31 stringValue] UTF8String];
        currentListInformation [19] = [[xyAssign32 stringValue] UTF8String];
        currentListInformation [20] = [[xyAssign33 stringValue] UTF8String];
        currentListInformation [21] = [[xyAssign34 stringValue] UTF8String];
        currentListInformation [22] = [[xyAssign35 stringValue] UTF8String];
        currentListInformation [23] = [[xyAssign36 stringValue] UTF8String];
        currentListInformation [24] = [[xyAssign37 stringValue] UTF8String];
        currentListInformation [25] = [[xyAssign38 stringValue] UTF8String];
        currentListInformation [26] = [[xyAssign39 stringValue] UTF8String];
        
        currentListInformation [27] = [[xyAssign41 stringValue] UTF8String];
        currentListInformation [28] = [[xyAssign42 stringValue] UTF8String];
        currentListInformation [29] = [[xyAssign43 stringValue] UTF8String];
        currentListInformation [30] = [[xyAssign44 stringValue] UTF8String];
        currentListInformation [31] = [[xyAssign45 stringValue] UTF8String];
        currentListInformation [32] = [[xyAssign46 stringValue] UTF8String];
        currentListInformation [33] = [[xyAssign47 stringValue] UTF8String];
        currentListInformation [34] = [[xyAssign48 stringValue] UTF8String];
        currentListInformation [35] = [[xyAssign49 stringValue] UTF8String];
        
        currentListInformation [36] = [[xyAssign51 stringValue] UTF8String];
        currentListInformation [37] = [[xyAssign52 stringValue] UTF8String];
        currentListInformation [38] = [[xyAssign53 stringValue] UTF8String];
        currentListInformation [39] = [[xyAssign54 stringValue] UTF8String];
        currentListInformation [40] = [[xyAssign55 stringValue] UTF8String];
        currentListInformation [41] = [[xyAssign56 stringValue] UTF8String];
        currentListInformation [42] = [[xyAssign57 stringValue] UTF8String];
        currentListInformation [43] = [[xyAssign58 stringValue] UTF8String];
        currentListInformation [44] = [[xyAssign59 stringValue] UTF8String];
        
        currentListInformation [45] = [[xyAssign61 stringValue] UTF8String];
        currentListInformation [46] = [[xyAssign62 stringValue] UTF8String];
        currentListInformation [47] = [[xyAssign63 stringValue] UTF8String];
        currentListInformation [48] = [[xyAssign64 stringValue] UTF8String];
        currentListInformation [49] = [[xyAssign65 stringValue] UTF8String];
        currentListInformation [50] = [[xyAssign66 stringValue] UTF8String];
        currentListInformation [51] = [[xyAssign67 stringValue] UTF8String];
        currentListInformation [52] = [[xyAssign68 stringValue] UTF8String];
        currentListInformation [53] = [[xyAssign69 stringValue] UTF8String];
        
        currentListInformation [54] = [[xyAssign71 stringValue] UTF8String];
        currentListInformation [55] = [[xyAssign72 stringValue] UTF8String];
        currentListInformation [56] = [[xyAssign73 stringValue] UTF8String];
        currentListInformation [57] = [[xyAssign74 stringValue] UTF8String];
        currentListInformation [58] = [[xyAssign75 stringValue] UTF8String];
        currentListInformation [59] = [[xyAssign76 stringValue] UTF8String];
        currentListInformation [60] = [[xyAssign77 stringValue] UTF8String];
        currentListInformation [61] = [[xyAssign78 stringValue] UTF8String];
        currentListInformation [62] = [[xyAssign79 stringValue] UTF8String];
        
        currentListInformation [63] = [[xyAssign81 stringValue] UTF8String];
        currentListInformation [64] = [[xyAssign82 stringValue] UTF8String];
        currentListInformation [65] = [[xyAssign83 stringValue] UTF8String];
        currentListInformation [66] = [[xyAssign84 stringValue] UTF8String];
        currentListInformation [67] = [[xyAssign85 stringValue] UTF8String];
        currentListInformation [68] = [[xyAssign86 stringValue] UTF8String];
        currentListInformation [69] = [[xyAssign87 stringValue] UTF8String];
        currentListInformation [70] = [[xyAssign88 stringValue] UTF8String];
        currentListInformation [71] = [[xyAssign89 stringValue] UTF8String];
        
        currentListInformation [72] = [[xyAssign91 stringValue] UTF8String];
        currentListInformation [73] = [[xyAssign92 stringValue] UTF8String];
        currentListInformation [74] = [[xyAssign93 stringValue] UTF8String];
        currentListInformation [75] = [[xyAssign94 stringValue] UTF8String];
        currentListInformation [76] = [[xyAssign95 stringValue] UTF8String];
        currentListInformation [77] = [[xyAssign96 stringValue] UTF8String];
        currentListInformation [78] = [[xyAssign97 stringValue] UTF8String];
        currentListInformation [79] = [[xyAssign98 stringValue] UTF8String];
        currentListInformation [80] = [[xyAssign99 stringValue] UTF8String];
        
        //For (int counterA = 0; counterA < 81; counterA++){
        //    cout<<counterA<<" "<<currentListInformation [counterA]<<" currentListInformation"<<endl;
        //}
        
        int entryCheck = 0;
        int maxNumberFind = 0;
        
        for (int counter1 = 0; counter1 < 81; counter1++){
            if (atoi(currentListInformation [counter1].c_str()) > 81 || atoi(currentListInformation [counter1].c_str()) <= 0) currentListInformation [counter1] = "";
            if (currentListInformation [counter1] != "") entryCheck++;
            if (atoi(currentListInformation [counter1].c_str()) > maxNumberFind) maxNumberFind = atoi(currentListInformation [counter1].c_str());
        }
        
        [xyAssign11 setStringValue:@(currentListInformation [0].c_str())];
        [xyAssign12 setStringValue:@(currentListInformation [1].c_str())];
        [xyAssign13 setStringValue:@(currentListInformation [2].c_str())];
        [xyAssign14 setStringValue:@(currentListInformation [3].c_str())];
        [xyAssign15 setStringValue:@(currentListInformation [4].c_str())];
        [xyAssign16 setStringValue:@(currentListInformation [5].c_str())];
        [xyAssign17 setStringValue:@(currentListInformation [6].c_str())];
        [xyAssign18 setStringValue:@(currentListInformation [7].c_str())];
        [xyAssign19 setStringValue:@(currentListInformation [8].c_str())];
        
        [xyAssign21 setStringValue:@(currentListInformation [9].c_str())];
        [xyAssign22 setStringValue:@(currentListInformation [10].c_str())];
        [xyAssign23 setStringValue:@(currentListInformation [11].c_str())];
        [xyAssign24 setStringValue:@(currentListInformation [12].c_str())];
        [xyAssign25 setStringValue:@(currentListInformation [13].c_str())];
        [xyAssign26 setStringValue:@(currentListInformation [14].c_str())];
        [xyAssign27 setStringValue:@(currentListInformation [15].c_str())];
        [xyAssign28 setStringValue:@(currentListInformation [16].c_str())];
        [xyAssign29 setStringValue:@(currentListInformation [17].c_str())];
        
        [xyAssign31 setStringValue:@(currentListInformation [18].c_str())];
        [xyAssign32 setStringValue:@(currentListInformation [19].c_str())];
        [xyAssign33 setStringValue:@(currentListInformation [20].c_str())];
        [xyAssign34 setStringValue:@(currentListInformation [21].c_str())];
        [xyAssign35 setStringValue:@(currentListInformation [22].c_str())];
        [xyAssign36 setStringValue:@(currentListInformation [23].c_str())];
        [xyAssign37 setStringValue:@(currentListInformation [24].c_str())];
        [xyAssign38 setStringValue:@(currentListInformation [25].c_str())];
        [xyAssign39 setStringValue:@(currentListInformation [26].c_str())];
        
        [xyAssign41 setStringValue:@(currentListInformation [27].c_str())];
        [xyAssign42 setStringValue:@(currentListInformation [28].c_str())];
        [xyAssign43 setStringValue:@(currentListInformation [29].c_str())];
        [xyAssign44 setStringValue:@(currentListInformation [30].c_str())];
        [xyAssign45 setStringValue:@(currentListInformation [31].c_str())];
        [xyAssign46 setStringValue:@(currentListInformation [32].c_str())];
        [xyAssign47 setStringValue:@(currentListInformation [33].c_str())];
        [xyAssign48 setStringValue:@(currentListInformation [34].c_str())];
        [xyAssign49 setStringValue:@(currentListInformation [35].c_str())];
        
        [xyAssign51 setStringValue:@(currentListInformation [36].c_str())];
        [xyAssign52 setStringValue:@(currentListInformation [37].c_str())];
        [xyAssign53 setStringValue:@(currentListInformation [38].c_str())];
        [xyAssign54 setStringValue:@(currentListInformation [39].c_str())];
        [xyAssign55 setStringValue:@(currentListInformation [40].c_str())];
        [xyAssign56 setStringValue:@(currentListInformation [41].c_str())];
        [xyAssign57 setStringValue:@(currentListInformation [42].c_str())];
        [xyAssign58 setStringValue:@(currentListInformation [43].c_str())];
        [xyAssign59 setStringValue:@(currentListInformation [44].c_str())];
        
        [xyAssign61 setStringValue:@(currentListInformation [45].c_str())];
        [xyAssign62 setStringValue:@(currentListInformation [46].c_str())];
        [xyAssign63 setStringValue:@(currentListInformation [47].c_str())];
        [xyAssign64 setStringValue:@(currentListInformation [48].c_str())];
        [xyAssign65 setStringValue:@(currentListInformation [49].c_str())];
        [xyAssign66 setStringValue:@(currentListInformation [50].c_str())];
        [xyAssign67 setStringValue:@(currentListInformation [51].c_str())];
        [xyAssign68 setStringValue:@(currentListInformation [52].c_str())];
        [xyAssign69 setStringValue:@(currentListInformation [53].c_str())];
        
        [xyAssign71 setStringValue:@(currentListInformation [54].c_str())];
        [xyAssign72 setStringValue:@(currentListInformation [55].c_str())];
        [xyAssign73 setStringValue:@(currentListInformation [56].c_str())];
        [xyAssign74 setStringValue:@(currentListInformation [57].c_str())];
        [xyAssign75 setStringValue:@(currentListInformation [58].c_str())];
        [xyAssign76 setStringValue:@(currentListInformation [59].c_str())];
        [xyAssign77 setStringValue:@(currentListInformation [60].c_str())];
        [xyAssign78 setStringValue:@(currentListInformation [61].c_str())];
        [xyAssign79 setStringValue:@(currentListInformation [62].c_str())];
        
        [xyAssign81 setStringValue:@(currentListInformation [63].c_str())];
        [xyAssign82 setStringValue:@(currentListInformation [64].c_str())];
        [xyAssign83 setStringValue:@(currentListInformation [65].c_str())];
        [xyAssign84 setStringValue:@(currentListInformation [66].c_str())];
        [xyAssign85 setStringValue:@(currentListInformation [67].c_str())];
        [xyAssign86 setStringValue:@(currentListInformation [68].c_str())];
        [xyAssign87 setStringValue:@(currentListInformation [69].c_str())];
        [xyAssign88 setStringValue:@(currentListInformation [70].c_str())];
        [xyAssign89 setStringValue:@(currentListInformation [71].c_str())];
        
        [xyAssign91 setStringValue:@(currentListInformation [72].c_str())];
        [xyAssign92 setStringValue:@(currentListInformation [73].c_str())];
        [xyAssign93 setStringValue:@(currentListInformation [74].c_str())];
        [xyAssign94 setStringValue:@(currentListInformation [75].c_str())];
        [xyAssign95 setStringValue:@(currentListInformation [76].c_str())];
        [xyAssign96 setStringValue:@(currentListInformation [77].c_str())];
        [xyAssign97 setStringValue:@(currentListInformation [78].c_str())];
        [xyAssign98 setStringValue:@(currentListInformation [79].c_str())];
        [xyAssign99 setStringValue:@(currentListInformation [80].c_str())];
        
        if (entryCheck != 0){
            int *missingNumberList = new int [100];
            int missingNumberListCount = 0;
            int missingFind = 0;
            
            for (int counter1 = 0; counter1 < 100; counter1++) missingNumberList [counter1] = 0;
            
            for (int counter1 = 1; counter1 <= maxNumberFind; counter1++){
                for (int counter2 = 0; counter2 < 81; counter2++){
                    missingFind = 0;
                    
                    if (atoi(currentListInformation [counter2].c_str()) == counter1){
                        missingFind = 1;
                        break;
                    }
                }
                
                if (missingFind == 0){
                    missingNumberList [missingNumberListCount] = counter1, missingNumberListCount++;
                }
            }
            
            if (missingNumberListCount == 0){
                int *duplicateNumberList = new int [100];
                int duplicateNumberListCount = 0;
                int duplicateFind = 0;
                
                for (int counter1 = 0; counter1 < 100; counter1++) duplicateNumberList [counter1] = 0;
                
                for (int counter1 = 1; counter1 <= maxNumberFind; counter1++){
                    duplicateFind = 0;
                    
                    for (int counter2 = 0; counter2 < 81; counter2++){
                        if (atoi(currentListInformation [counter2].c_str()) == counter1) duplicateFind++;
                    }
                    
                    if (duplicateFind > 1){
                        duplicateNumberList [duplicateNumberListCount] = counter1, duplicateNumberListCount++;
                    }
                }
                
                if (duplicateNumberListCount == 0){
                    if (currentImageName != "" && currentNoOfImage == maxNumberFind){
                        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
                            copyProgressFlag = 1;
                            progressTiming = 6;
                            
                            do usleep(10);
                            while (progressTiming == 6);
                            
                            currentListName = currentImageName;
                            currentListNumber = to_string(self->currentNoOfImage);
                            
                            for (int counter1 = 0; counter1 < tableListHoldCount; counter1++){
                                if (tableListHold [counter1*85+2] == currentImageName && tableListHold [counter1*85+1] == analysisNameHold){
                                    tableListHold [counter1*85] = "1";
                                    tableListHold [counter1*85+3] = to_string(self->currentNoOfImage);
                                    
                                    for (int counter2 = 0; counter2 < 81; counter2++){
                                        if (currentListInformation [counter2] == ""){
                                            tableListHold [counter1*85+counter2+4] = "nil";
                                        }
                                        else tableListHold [counter1*85+counter2+4] = currentListInformation [counter2];
                                    }
                                    
                                    break;
                                }
                            }
                            
                            //For (int counterA = 0; counterA < tableListHoldCount*85; counterA++){
                            //    cout<<tableListHold [counterA]<<" tableListHold"<<endl;
                            //}
                            
                            ofstream oin;
                            
                            oin.open(tableListPath.c_str(), ios::out);
                            
                            for (int counter1 = 0; counter1 < tableListHoldCount*85; counter1++) oin<<tableListHold [counter1]<<endl;
                            
                            oin.close();
                            
                            int xPositionSet = 10+imageDimensionW*9;
                            int yPositionSet = 10;
                            int entryCount = 1;
                            
                            for (int counter1 = 1; counter1 <= 9; counter1++){
                                for (int counter2 = 1; counter2 <= 9; counter2++){
                                    imageSetPositionList [entryCount*2] = yPositionSet;
                                    imageSetPositionList [entryCount*2+1] = xPositionSet-imageDimensionW;
                                    
                                    entryCount++;
                                    xPositionSet = xPositionSet-imageDimensionW;
                                }
                                
                                yPositionSet = yPositionSet+imageDimensionH;
                                xPositionSet = 10+imageDimensionW*9;
                            }
                            
                            string imageDisplayListPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files/"+analysisNameHold+"_ProductsH/"+currentImageName+"_Capture/Original";
                            
                            DIR *dir;
                            struct dirent *dent;
                            
                            string *fileList2 = new string [100];
                            int fileListCount2 = 0;
                            int fileListLimit2 = 100;
                            
                            dir = opendir(imageDisplayListPath.c_str());
                            
                            if (dir != NULL){
                                string entry;
                                
                                while((dent = readdir(dir))){
                                    entry = dent -> d_name;
                                    
                                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                        if ((int)entry.find(".TIFF") != -1 || (int)entry.find(".Tiff") != -1 || (int)entry.find(".tiff") != -1 || (int)entry.find(".TIF") != -1 || (int)entry.find(".Tif") != -1 || (int)entry.find(".tif") != -1){
                                            
                                            if (fileListLimit2 < fileListCount2+10){
                                                string *arrayUpDate = new string [fileListCount2+10];
                                                
                                                for (int counter1 = 0; counter1 < fileListCount2; counter1++) arrayUpDate [counter1] = fileList2 [counter1];
                                                
                                                delete [] fileList2;
                                                fileList2 = new string [fileListLimit2+500];
                                                fileListLimit2 = fileListLimit2+500;
                                                
                                                for (int counter1 = 0; counter1 < fileListCount2; counter1++) fileList2 [counter1] = arrayUpDate [counter1];
                                                delete [] arrayUpDate;
                                            }
                                            
                                            fileList2 [fileListCount2] = entry, fileListCount2++;
                                        }
                                    }
                                }
                                
                                closedir(dir);
                                
                                //-----Directory Sort-----
                                NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                                
                                for (int counter1 = 0; counter1 < fileListCount2; counter1++){
                                    [unsortedArray addObject:@(fileList2 [counter1].c_str())];
                                }
                                
                                [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                                
                                for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                                    fileList2 [counter1] = [unsortedArray [counter1] UTF8String];
                                }
                                
                                unsigned long nextAddress = 0;
                                unsigned long stripFirstAddress = 0;
                                unsigned long stripByteCountAddress = 0;
                                unsigned long headPosition = 0;
                                unsigned long stripEntry = 0;
                                long sizeForCopy = 0;
                                
                                double xPosition = 0;
                                double yPosition = 0;
                                
                                int imageWidth = 0;
                                int imageHeight = 0;
                                int imageBit = 0; //Check 8, 16
                                int imageCompression = 0; //Check 1
                                int photoMetric = 0;//Check 0, 1, 2
                                int imageDimension = 0;
                                int verticalBmp = 0;
                                int horizontalBmp = 0;
                                int horizontalBmpEntry = 0;
                                int endianType = 0;
                                int samplePerPix = 0;
                                int dataConversion [4];
                                int mode = 0;
                                int processType = 1;
                                int numberOfLayers = 0;
                                int wrongFormatFind = 0;
                                
                                string imageFilePath;
                                
                                int *imageSizeArray = new int [fileListCount2*2+10];
                                int *imageInformationArray = new int [fileListCount2*3+10];
                                
                                for (int counter1 = 0; counter1 < fileListCount2*2+10; counter1++) imageSizeArray [counter1] = 0;
                                for (int counter1 = 0; counter1 < fileListCount2*3+10; counter1++) imageInformationArray [counter1] = 0;
                                
                                ifstream fin;
                                
                                struct stat sizeOfFile;
                                
                                //=========Original Image Check==========
                                for (int counter1 = 0; counter1 < fileListCount2; counter1++){
                                    imageFilePath = imageDisplayListPath+"/"+fileList2 [counter1];
                                    
                                    //-----File Read-----
                                    if (stat(imageFilePath.c_str(), &sizeOfFile) == 0){
                                        sizeForCopy = sizeOfFile.st_size;
                                        
                                        fileReadArray = new uint8_t [sizeForCopy+4];
                                        fin.open(imageFilePath.c_str(), ios::in | ios::binary);
                                        
                                        fin.read((char*)fileReadArray, sizeForCopy+1);
                                        fin.close();
                                        
                                        dataConversion [0] = fileReadArray [0];
                                        dataConversion [1] = fileReadArray [1];
                                        
                                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                        else endianType = 0;
                                        
                                        if (endianType == 1){
                                            dataConversion [0] = fileReadArray [7];
                                            dataConversion [1] = fileReadArray [6];
                                            dataConversion [2] = fileReadArray [5];
                                            dataConversion [3] = fileReadArray [4];
                                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                        }
                                        else if (endianType == 0){
                                            dataConversion [0] = fileReadArray [4];
                                            dataConversion [1] = fileReadArray [5];
                                            dataConversion [2] = fileReadArray [6];
                                            dataConversion [3] = fileReadArray [7];
                                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                        }
                                        
                                        if (endianType == 1){ //-----Big endian-----
                                            self->tiffFileRead = [[TiffFileRead alloc] init];
                                            [self->tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                        }
                                        else if (endianType == 0){
                                            self->tiffFileRead = [[TiffFileRead alloc] init];
                                            [self->tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                        }
                                        
                                        if (imageCompression == 1 && (imageBit == 8 || imageBit == 16) && numberOfLayers == 1 && samplePerPix <= 4 && photoMetric < 3){
                                            imageInformationArray [counter1*3] = imageBit;
                                            imageInformationArray [counter1*3+1] = samplePerPix;
                                            imageInformationArray [counter1*3+2] = photoMetric;
                                            
                                            imageSizeArray [counter1*2] = imageWidth;
                                            imageSizeArray [counter1*2+1] = imageHeight;
                                        }
                                        else wrongFormatFind = 1;
                                        
                                        delete [] fileReadArray;
                                    }
                                }
                                
                                if (wrongFormatFind == 0){
                                    //-----Original Image consistency Check-----
                                    int horizontalOriginal = imageSizeArray [0];
                                    int verticalOriginal = imageSizeArray [1];
                                    
                                    int imageCheck = 0;
                                    
                                    for (int counter1 = 0; counter1 < fileListCount2; counter1++){
                                        if (imageSizeArray [counter1*2] != horizontalOriginal) imageCheck = 1;
                                        if (imageSizeArray [counter1*2+1] != verticalOriginal) imageCheck = 1;
                                    }
                                    
                                    int imageBitOriginal = imageInformationArray [0];
                                    int sampleBitOriginal = imageInformationArray [1];
                                    int photoMetricOriginal = imageInformationArray [2];
                                    
                                    for (int counter1 = 0; counter1 < fileListCount2; counter1++){
                                        if (imageInformationArray [counter1*3] != imageBitOriginal) imageCheck = 1;
                                        if (imageInformationArray [counter1*3+1] != sampleBitOriginal) imageCheck = 1;
                                        if (imageInformationArray [counter1*3+2] != photoMetricOriginal) imageCheck = 1;
                                    }
                                    
                                    if (imageCheck == 0){
                                        if (imageDataHoldStatus == 1){
                                            for (int counter1 = 0; counter1 < imageDimensionH*fileListCount+20; counter1++){
                                                delete [] arrayImageDataHold [counter1];
                                                delete [] arrayImageOriginal [counter1];
                                                delete [] arrayImageResults [counter1];
                                            }
                                            
                                            delete [] arrayImageDataHold;
                                            delete [] arrayImageOriginal;
                                            delete [] arrayImageResults;
                                        }
                                        
                                        imageDimensionH = verticalOriginal;
                                        imageDimensionW = horizontalOriginal;
                                        
                                        imageBitHold = imageBitOriginal;
                                        photoMetricsHold = photoMetricOriginal;
                                        samplePerPixHold = sampleBitOriginal;
                                        
                                        //cout<<imageDimensionH <<" "<<imageDimensionW<<" "<<imageBitHold<<" "<<" "<<photoMetricsHold<<" "<<samplePerPixHold<<" "<<processType <<" info"<<endl;
                                        
                                        if (samplePerPixHold == 3 || samplePerPixHold == 4) samplePerPixHold = 3;
                                        else samplePerPixHold = 1;
                                        
                                        if (photoMetricsHold <= 1) photoMetricsHold = 1;
                                        
                                        imageBitHold = 8;
                                        
                                        arrayImageDataHold = new int *[(imageDimensionH+3)*fileListCount2+20];
                                        arrayImageOriginal = new int *[(imageDimensionH+3)*fileListCount2+20];
                                        arrayImageResults = new int *[(imageDimensionH+3)*fileListCount2+20];
                                        
                                        if (photoMetricsHold <= 1){
                                            for (int counter2 = 0; counter2 < (imageDimensionH+3)*fileListCount2+20; counter2++){
                                                arrayImageDataHold [counter2] = new int [imageDimensionW+20];
                                                arrayImageOriginal [counter2] = new int [imageDimensionW+20];
                                                arrayImageResults [counter2] = new int [imageDimensionW+20];
                                            }
                                        }
                                        else if (photoMetricsHold == 2){
                                            for (int counter2 = 0; counter2 < (imageDimensionH+3)*fileListCount2+20; counter2++){
                                                arrayImageDataHold [counter2] = new int [imageDimensionW*3+20];
                                                arrayImageOriginal [counter2] = new int [imageDimensionW*3+20];
                                                arrayImageResults [counter2] = new int [imageDimensionW*3+20];
                                            }
                                        }
                                        
                                        if (imageDataHoldStatus == 0) imageDataHoldStatus = 1;
                                        
                                        unsigned long verticalTotal = 0;
                                        
                                        int xNewPosition = 0;
                                        int yNewPosition = 0;
                                        int xyPositionIndex = 0;
                                        int imageFileNo = 0;
                                        int dimensionAdditionW = 0;
                                        int dimensionAdditionH = 0;
                                        int newImageDimensionW = 0;
                                        int newImageDimensionH = 0;
                                        
                                        string saveString;
                                        
                                        for (int counter1 = 0; counter1 < fileListCount; counter1++){
                                            xyPositionData [counter1*3] = 0;
                                            xyPositionData [counter1*3+1] = 0;
                                            xyPositionData [counter1*3+2] = 0;
                                            xyPositionDataOriginal [counter1*3] = 0;
                                            xyPositionDataOriginal [counter1*3+1] = 0;
                                            xyPositionDataOriginal [counter1*3+2] = 0;
                                        }
                                        
                                        string imageDisplayListCurrentPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"05_Products_Files/"+analysisNameHold+"_ProductsH/"+currentImageName+"_Capture/Current";
                                        
                                        //-----Write Files into Current folder-----
                                        for (int counter1 = 0; counter1 < fileListCount2; counter1++){
                                            fileSavePathHold = imageDisplayListCurrentPath+"/"+fileList2 [counter1];
                                            
                                            imageFileNo = atoi(fileList2 [counter1].substr(fileList2 [counter1].find(".tif")-4, 4).c_str());
                                            xyPositionData [counter1*3] = atoi(fileList2 [counter1].substr(fileList2 [counter1].find(".tif")-4, 4).c_str());
                                            
                                            xyPositionIndex = -1;
                                            
                                            for (int counter2 = 0; counter2 < 81; counter2++){
                                                if (atoi(currentListInformation [counter2].c_str()) == imageFileNo){
                                                    xyPositionIndex = counter2;
                                                    break;
                                                }
                                            }
                                            
                                            if (xyPositionIndex != -1){
                                                yNewPosition = imageSetPositionList [xyPositionIndex*2];
                                                xNewPosition = imageSetPositionList [xyPositionIndex*2+1];
                                                
                                                xyPositionData [counter1*3+1] = yNewPosition;
                                                xyPositionData [counter1*3+2] = xNewPosition;
                                                
                                                if (stat(fileSavePathHold.c_str(), &sizeOfFile) == 0){
                                                    sizeForCopy = sizeOfFile.st_size;
                                                    
                                                    fileReadArray = new uint8_t [sizeForCopy+4];
                                                    fin.open(fileSavePathHold.c_str(), ios::in | ios::binary);
                                                    
                                                    fin.read((char*)fileReadArray, sizeForCopy+1);
                                                    fin.close();
                                                    
                                                    dataConversion [0] = fileReadArray [0];
                                                    dataConversion [1] = fileReadArray [1];
                                                    
                                                    if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                                    else endianType = 0;
                                                    
                                                    if (endianType == 1){
                                                        dataConversion [0] = fileReadArray [7];
                                                        dataConversion [1] = fileReadArray [6];
                                                        dataConversion [2] = fileReadArray [5];
                                                        dataConversion [3] = fileReadArray [4];
                                                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                                    }
                                                    else if (endianType == 0){
                                                        dataConversion [0] = fileReadArray [4];
                                                        dataConversion [1] = fileReadArray [5];
                                                        dataConversion [2] = fileReadArray [6];
                                                        dataConversion [3] = fileReadArray [7];
                                                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                                    }
                                                    
                                                    int *arrayExtractedImage3 = new int [100];
                                                    
                                                    if (endianType == 1){
                                                        self->tiffFileRead = [[TiffFileRead alloc] init];
                                                        [self->tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                                        
                                                        if (imageDimensionW > imageDimensionH) imageDimension = imageDimensionW;
                                                        else imageDimension = imageDimensionH;
                                                        
                                                        self->tiffFileRead = [[TiffFileRead alloc] init];
                                                        delete [] arrayExtractedImage3;
                                                        
                                                        arrayExtractedImage3 = [self->tiffFileRead imageSetBigEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                                    }
                                                    else if (endianType == 0){
                                                        self->tiffFileRead = [[TiffFileRead alloc] init];
                                                        [self->tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                                        
                                                        if (imageDimensionW > imageDimensionH) imageDimension = imageDimensionW;
                                                        else imageDimension = imageDimensionH;
                                                        
                                                        self->tiffFileRead = [[TiffFileRead alloc] init];
                                                        delete [] arrayExtractedImage3;
                                                        
                                                        arrayExtractedImage3 = [self->tiffFileRead imageSetLittleEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                                    }
                                                    
                                                    dimensionAdditionW = imageDimensionW%4;
                                                    
                                                    if (dimensionAdditionW == 1) dimensionAdditionW = 3;
                                                    else if (dimensionAdditionW == 2) dimensionAdditionW = 2;
                                                    else if (dimensionAdditionW == 3) dimensionAdditionW = 1;
                                                    
                                                    newImageDimensionW = imageDimensionW+dimensionAdditionW;
                                                    
                                                    dimensionAdditionH = imageDimensionH%4;
                                                    
                                                    if (dimensionAdditionH == 1) dimensionAdditionH = 3;
                                                    else if (dimensionAdditionH == 2) dimensionAdditionH = 2;
                                                    else if (dimensionAdditionH == 3) dimensionAdditionH = 1;
                                                    
                                                    newImageDimensionH = imageDimensionH+dimensionAdditionH;
                                                    
                                                    int **arrayExtractedImage = new int *[newImageDimensionH+1];
                                                    
                                                    for (int counter3 = 0; counter3 < newImageDimensionH+1; counter3++){
                                                        arrayExtractedImage [counter3] = new int [newImageDimensionW*3+1];
                                                    }
                                                    
                                                    horizontalBmp = 0;
                                                    horizontalBmpEntry = 0;
                                                    verticalBmp = 0;
                                                    
                                                    for (int counter3 = 0; counter3 < imageDimensionW*imageDimensionH; counter3++){
                                                        if (photoMetricsHold == 1){
                                                            if (horizontalBmp < imageDimensionW){
                                                                arrayExtractedImage [verticalBmp][horizontalBmpEntry] = arrayExtractedImage3 [counter3], horizontalBmpEntry++;
                                                                horizontalBmp++;
                                                            }
                                                            
                                                            if (horizontalBmp == imageDimensionW){
                                                                if (imageDimensionW < newImageDimensionW){
                                                                    for (int counter4 = 0; counter4 < newImageDimensionW-imageDimensionW; counter4++){
                                                                        arrayExtractedImage [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                                    }
                                                                }
                                                                
                                                                horizontalBmp = 0;
                                                                horizontalBmpEntry = 0;
                                                                verticalBmp++;
                                                            }
                                                        }
                                                        else if (photoMetricsHold == 2){
                                                            if (horizontalBmp < imageDimensionW){
                                                                arrayExtractedImage [verticalBmp][horizontalBmpEntry] = arrayExtractedImage3 [counter3*3], horizontalBmpEntry++;
                                                                arrayExtractedImage [verticalBmp][horizontalBmpEntry] = arrayExtractedImage3 [counter3*3+1], horizontalBmpEntry++;
                                                                arrayExtractedImage [verticalBmp][horizontalBmpEntry] = arrayExtractedImage3 [counter3*3+2], horizontalBmpEntry++;
                                                                
                                                                horizontalBmp++;
                                                            }
                                                            
                                                            if (horizontalBmp == imageDimensionW){
                                                                if (imageDimensionW < newImageDimensionW){
                                                                    for (int counter4 = 0; counter4 < newImageDimensionW-imageDimensionW; counter4++){
                                                                        arrayExtractedImage [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                                        arrayExtractedImage [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                                        arrayExtractedImage [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                                    }
                                                                }
                                                                
                                                                horizontalBmp = 0;
                                                                horizontalBmpEntry = 0;
                                                                verticalBmp++;
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (photoMetricsHold == 1){
                                                        if (imageDimensionH < newImageDimensionH){
                                                            for (int counter3 = imageDimensionH; counter3 < newImageDimensionH; counter3++){
                                                                horizontalBmpEntry = 0;
                                                                
                                                                for (int counter4 = 0; counter4 < newImageDimensionW; counter4++){
                                                                    arrayExtractedImage [counter3][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                                }
                                                                
                                                                verticalBmp++;
                                                            }
                                                        }
                                                    }
                                                    else if (photoMetricsHold == 2){
                                                        if (imageDimensionH < newImageDimensionH){
                                                            for (int counter3 = imageDimensionH; counter3 < newImageDimensionH; counter3++){
                                                                horizontalBmpEntry = 0;
                                                                
                                                                for (int counter4 = 0; counter4 < newImageDimensionW; counter4++){
                                                                    arrayExtractedImage [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                                    arrayExtractedImage [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                                    arrayExtractedImage [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                                }
                                                                
                                                                verticalBmp++;
                                                            }
                                                        }
                                                    }
                                                    
                                                    arrayImageFileSave = new int *[newImageDimensionH+1];
                                                    
                                                    for (int counter5 = 0; counter5 < newImageDimensionH+1; counter5++){
                                                        arrayImageFileSave [counter5] = new int [newImageDimensionW*3+1];
                                                    }
                                                    
                                                    if (photoMetricsHold == 1){
                                                        for (int counter5 = 0; counter5 < newImageDimensionH; counter5++){
                                                            for (int counter6 = 0; counter6 < newImageDimensionW; counter6++){
                                                                arrayImageFileSave [counter5][counter6] = arrayExtractedImage [counter5][counter6];
                                                            }
                                                        }
                                                    }
                                                    else if (photoMetricsHold == 2){
                                                        for (int counter5 = 0; counter5 < newImageDimensionH; counter5++){
                                                            for (int counter6 = 0; counter6 < newImageDimensionW; counter6++){
                                                                arrayImageFileSave [counter5][counter6*3] = arrayExtractedImage [counter5][counter6*3];
                                                                arrayImageFileSave [counter5][counter6*3+1] = arrayExtractedImage [counter5][counter6*3+1];
                                                                arrayImageFileSave [counter5][counter6*3+2] = arrayExtractedImage [counter5][counter6*3+2];
                                                            }
                                                        }
                                                    }
                                                    
                                                    xPosition = xyPositionData [counter1*3+2];
                                                    yPosition = xyPositionData [counter1*3+1];
                                                    
                                                    self->singleTiffSave = [[SingleTiffSave alloc] init];
                                                    [self->singleTiffSave singleTiffLayerSave:newImageDimensionW:newImageDimensionH:imageBitHold:photoMetricsHold:samplePerPixHold:xPosition:yPosition:mode:(unsigned long)mode];
                                                    
                                                    if (photoMetricsHold == 1){
                                                        for (int counter5 = 0; counter5 < newImageDimensionH; counter5++){
                                                            for (int counter6 = 0; counter6 < newImageDimensionW; counter6++){
                                                                arrayImageDataHold [verticalTotal][counter6] = arrayExtractedImage [counter5][counter6];
                                                            }
                                                            
                                                            verticalTotal++;
                                                        }
                                                    }
                                                    else if (photoMetricsHold == 2){
                                                        for (int counter5 = 0; counter5 < newImageDimensionH; counter5++){
                                                            for (int counter6 = 0; counter6 < newImageDimensionW; counter6++){
                                                                arrayImageDataHold [verticalTotal][counter6*3] = arrayExtractedImage [counter5][counter6*3];
                                                                arrayImageDataHold [verticalTotal][counter6*3+1] = arrayExtractedImage [counter5][counter6*3+1];
                                                                arrayImageDataHold [verticalTotal][counter6*3+2] = arrayExtractedImage [counter5][counter6*3+2];
                                                            }
                                                            
                                                            verticalTotal++;
                                                        }
                                                    }
                                                    
                                                    for (int counter3 = 0; counter3 < newImageDimensionH+1; counter3++){
                                                        delete [] arrayExtractedImage [counter3];
                                                        delete [] arrayImageFileSave [counter3];
                                                    }
                                                    
                                                    delete [] arrayImageFileSave;
                                                    delete [] arrayExtractedImage;
                                                    
                                                    delete [] fileReadArray;
                                                    delete [] arrayExtractedImage3;
                                                }
                                            }
                                        }
                                        
                                        //-----Original image set-----
                                        verticalTotal = 0;
                                        
                                        for (int counter1 = 0; counter1 < fileListCount2; counter1++){
                                            fileSavePathHold = imageDisplayListPath+"/"+fileList2 [counter1];
                                            
                                            imageFileNo = atoi(fileList2 [counter1].substr(fileList2 [counter1].find(".tif")-4, 4).c_str());
                                            xyPositionDataOriginal [counter1*3] = imageFileNo;
                                            
                                            xyPositionIndex = -1;
                                            
                                            for (int counter2 = 0; counter2 < 81; counter2++){
                                                if (atoi(currentListInformation [counter2].c_str()) == imageFileNo){
                                                    xyPositionIndex = counter2;
                                                    break;
                                                }
                                            }
                                            
                                            if (xyPositionIndex != -1){
                                                yNewPosition = imageSetPositionList [xyPositionIndex*2];
                                                xNewPosition = imageSetPositionList [xyPositionIndex*2+1];
                                                
                                                xyPositionDataOriginal [counter1*3+1] = yNewPosition;
                                                xyPositionDataOriginal [counter1*3+2] = xNewPosition;
                                                
                                                if (stat(fileSavePathHold.c_str(), &sizeOfFile) == 0){
                                                    sizeForCopy = sizeOfFile.st_size;
                                                    
                                                    fileReadArray = new uint8_t [sizeForCopy+4];
                                                    fin.open(fileSavePathHold.c_str(), ios::in | ios::binary);
                                                    
                                                    fin.read((char*)fileReadArray, sizeForCopy+1);
                                                    fin.close();
                                                    
                                                    dataConversion [0] = fileReadArray [0];
                                                    dataConversion [1] = fileReadArray [1];
                                                    
                                                    if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                                    else endianType = 0;
                                                    
                                                    if (endianType == 1){
                                                        dataConversion [0] = fileReadArray [7];
                                                        dataConversion [1] = fileReadArray [6];
                                                        dataConversion [2] = fileReadArray [5];
                                                        dataConversion [3] = fileReadArray [4];
                                                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                                    }
                                                    else if (endianType == 0){
                                                        dataConversion [0] = fileReadArray [4];
                                                        dataConversion [1] = fileReadArray [5];
                                                        dataConversion [2] = fileReadArray [6];
                                                        dataConversion [3] = fileReadArray [7];
                                                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                                    }
                                                    
                                                    int *arrayExtractedImage3 = new int [100];
                                                    
                                                    if (endianType == 1){
                                                        self->tiffFileRead = [[TiffFileRead alloc] init];
                                                        [self->tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                                        
                                                        if (imageDimensionW > imageDimensionH) imageDimension = imageDimensionW;
                                                        else imageDimension = imageDimensionH;
                                                        
                                                        self->tiffFileRead = [[TiffFileRead alloc] init];
                                                        delete [] arrayExtractedImage3;
                                                        
                                                        arrayExtractedImage3 = [self->tiffFileRead imageSetBigEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                                    }
                                                    else if (endianType == 0){
                                                        self->tiffFileRead = [[TiffFileRead alloc] init];
                                                        [self->tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                                        
                                                        if (imageDimensionW > imageDimensionH) imageDimension = imageDimensionW;
                                                        else imageDimension = imageDimensionH;
                                                        
                                                        self->tiffFileRead = [[TiffFileRead alloc] init];
                                                        delete [] arrayExtractedImage3;
                                                        
                                                        arrayExtractedImage3 = [self->tiffFileRead imageSetLittleEndian:imageDimension:imageBit:photoMetric:samplePerPix:stripEntry:stripFirstAddress:stripByteCountAddress:processType];
                                                    }
                                                    
                                                    dimensionAdditionW = imageDimensionW%4;
                                                    
                                                    if (dimensionAdditionW == 1) dimensionAdditionW = 3;
                                                    else if (dimensionAdditionW == 2) dimensionAdditionW = 2;
                                                    else if (dimensionAdditionW == 3) dimensionAdditionW = 1;
                                                    
                                                    newImageDimensionW = imageDimensionW+dimensionAdditionW;
                                                    
                                                    dimensionAdditionH = imageDimensionH%4;
                                                    
                                                    if (dimensionAdditionH == 1) dimensionAdditionH = 3;
                                                    else if (dimensionAdditionH == 2) dimensionAdditionH = 2;
                                                    else if (dimensionAdditionH == 3) dimensionAdditionH = 1;
                                                    
                                                    newImageDimensionH = imageDimensionH+dimensionAdditionH;
                                                    
                                                    int **arrayExtractedImage = new int *[newImageDimensionH+1];
                                                    
                                                    for (int counter3 = 0; counter3 < newImageDimensionH+1; counter3++){
                                                        arrayExtractedImage [counter3] = new int [newImageDimensionW*3+1];
                                                    }
                                                    
                                                    horizontalBmp = 0;
                                                    horizontalBmpEntry = 0;
                                                    verticalBmp = 0;
                                                    
                                                    for (int counter3 = 0; counter3 < imageDimensionW*imageDimensionH; counter3++){
                                                        if (photoMetricsHold == 1){
                                                            if (horizontalBmp < imageDimensionW){
                                                                arrayExtractedImage [verticalBmp][horizontalBmpEntry] = arrayExtractedImage3 [counter3], horizontalBmpEntry++;
                                                                horizontalBmp++;
                                                            }
                                                            
                                                            if (horizontalBmp == imageDimensionW){
                                                                if (imageDimensionW < newImageDimensionW){
                                                                    for (int counter4 = 0; counter4 < newImageDimensionW-imageDimensionW; counter4++){
                                                                        arrayExtractedImage [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                                    }
                                                                }
                                                                
                                                                horizontalBmp = 0;
                                                                horizontalBmpEntry = 0;
                                                                verticalBmp++;
                                                            }
                                                        }
                                                        else if (photoMetricsHold == 2){
                                                            if (horizontalBmp < imageDimensionW){
                                                                arrayExtractedImage [verticalBmp][horizontalBmpEntry] = arrayExtractedImage3 [counter3*3], horizontalBmpEntry++;
                                                                arrayExtractedImage [verticalBmp][horizontalBmpEntry] = arrayExtractedImage3 [counter3*3+1], horizontalBmpEntry++;
                                                                arrayExtractedImage [verticalBmp][horizontalBmpEntry] = arrayExtractedImage3 [counter3*3+2], horizontalBmpEntry++;
                                                                
                                                                horizontalBmp++;
                                                            }
                                                            
                                                            if (horizontalBmp == imageDimensionW){
                                                                if (imageDimensionW < newImageDimensionW){
                                                                    for (int counter4 = 0; counter4 < newImageDimensionW-imageDimensionW; counter4++){
                                                                        arrayExtractedImage [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                                        arrayExtractedImage [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                                        arrayExtractedImage [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                                    }
                                                                }
                                                                
                                                                horizontalBmp = 0;
                                                                horizontalBmpEntry = 0;
                                                                verticalBmp++;
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (photoMetricsHold == 1){
                                                        if (imageDimensionH < newImageDimensionH){
                                                            for (int counter3 = imageDimensionH; counter3 < newImageDimensionH; counter3++){
                                                                horizontalBmpEntry = 0;
                                                                
                                                                for (int counter4 = 0; counter4 < newImageDimensionW; counter4++){
                                                                    arrayExtractedImage [counter3][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                                }
                                                                
                                                                verticalBmp++;
                                                            }
                                                        }
                                                    }
                                                    else if (photoMetricsHold == 2){
                                                        if (imageDimensionH < newImageDimensionH){
                                                            for (int counter3 = imageDimensionH; counter3 < newImageDimensionH; counter3++){
                                                                horizontalBmpEntry = 0;
                                                                
                                                                for (int counter4 = 0; counter4 < newImageDimensionW; counter4++){
                                                                    arrayExtractedImage [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                                    arrayExtractedImage [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                                    arrayExtractedImage [verticalBmp][horizontalBmpEntry] = 0, horizontalBmpEntry++;
                                                                }
                                                                
                                                                verticalBmp++;
                                                            }
                                                        }
                                                    }
                                                    
                                                    arrayImageFileSave = new int *[newImageDimensionH+1];
                                                    
                                                    for (int counter5 = 0; counter5 < newImageDimensionH+1; counter5++){
                                                        arrayImageFileSave [counter5] = new int [newImageDimensionW*3+1];
                                                    }
                                                    
                                                    if (photoMetricsHold == 1){
                                                        for (int counter5 = 0; counter5 < newImageDimensionH; counter5++){
                                                            for (int counter6 = 0; counter6 < newImageDimensionW; counter6++){
                                                                arrayImageFileSave [counter5][counter6] = arrayExtractedImage [counter5][counter6];
                                                            }
                                                        }
                                                    }
                                                    else if (photoMetricsHold == 2){
                                                        for (int counter5 = 0; counter5 < newImageDimensionH; counter5++){
                                                            for (int counter6 = 0; counter6 < newImageDimensionW; counter6++){
                                                                arrayImageFileSave [counter5][counter6*3] = arrayExtractedImage [counter5][counter6*3];
                                                                arrayImageFileSave [counter5][counter6*3+1] = arrayExtractedImage [counter5][counter6*3+1];
                                                                arrayImageFileSave [counter5][counter6*3+2] = arrayExtractedImage [counter5][counter6*3+2];
                                                            }
                                                        }
                                                    }
                                                    
                                                    xPosition = xyPositionData [counter1*3+2];
                                                    yPosition = xyPositionData [counter1*3+1];
                                                    
                                                    self->singleTiffSave = [[SingleTiffSave alloc] init];
                                                    [self->singleTiffSave singleTiffLayerSave:newImageDimensionW:newImageDimensionH:imageBitHold:photoMetricsHold:samplePerPixHold:xPosition:yPosition:mode:(unsigned long)mode];
                                                    
                                                    if (photoMetricsHold == 1){
                                                        for (int counter5 = 0; counter5 < newImageDimensionH; counter5++){
                                                            for (int counter6 = 0; counter6 < newImageDimensionW; counter6++){
                                                                arrayImageOriginal [verticalTotal][counter6] = arrayExtractedImage [counter5][counter6];
                                                            }
                                                            
                                                            verticalTotal++;
                                                        }
                                                    }
                                                    else if (photoMetricsHold == 2){
                                                        for (int counter5 = 0; counter5 < newImageDimensionH; counter5++){
                                                            for (int counter6 = 0; counter6 < newImageDimensionW; counter6++){
                                                                arrayImageOriginal [verticalTotal][counter6*3] = arrayExtractedImage [counter5][counter6*3];
                                                                arrayImageOriginal [verticalTotal][counter6*3+1] = arrayExtractedImage [counter5][counter6*3+1];
                                                                arrayImageOriginal [verticalTotal][counter6*3+2] = arrayExtractedImage [counter5][counter6*3+2];
                                                            }
                                                            
                                                            verticalTotal++;
                                                        }
                                                    }
                                                    
                                                    for (int counter3 = 0; counter3 < newImageDimensionH+1; counter3++){
                                                        delete [] arrayExtractedImage [counter3];
                                                        delete [] arrayImageFileSave [counter3];
                                                    }
                                                    
                                                    delete [] arrayImageFileSave;
                                                    delete [] arrayExtractedImage;
                                                    
                                                    delete [] fileReadArray;
                                                    delete [] arrayExtractedImage3;
                                                    
                                                    //-----Image size update-----
                                                    imageDimensionH = newImageDimensionH;
                                                    imageDimensionW = newImageDimensionW;
                                                }
                                            }
                                        }
                                        
                                        if (photoMetricsHold == 1){
                                            for (int counter1 = 0; counter1 < imageDimensionH*fileListCount; counter1++){
                                                for (int counter2 = 0; counter2 < imageDimensionW; counter2++){
                                                    arrayImageResults [counter1][counter2] = arrayImageDataHold [counter1][counter2];
                                                }
                                            }
                                        }
                                        else if (photoMetricsHold == 2){
                                            for (int counter1 = 0; counter1 < imageDimensionH*fileListCount; counter1++){
                                                for (int counter2 = 0; counter2 < imageDimensionW; counter2++){
                                                    arrayImageResults [counter1][counter2*3] = arrayImageDataHold [counter1][counter2*3];
                                                    arrayImageResults [counter1][counter2*3+1] = arrayImageDataHold [counter1][counter2*3+1];
                                                    arrayImageResults [counter1][counter2*3+2] = arrayImageDataHold [counter1][counter2*3+2];
                                                }
                                            }
                                        }
                                        
                                        int stitchedImageDimensionHold = stitchedImageDimension;
                                        
                                        stitchedImageDimension = 0;
                                        
                                        int imagePositionXMax = 0;
                                        int imagePositionYMax = 0;
                                        int imagePositionXMin = 100000000;
                                        int imagePositionYMin = 100000000;
                                        
                                        for (int counter3 = 0; counter3 < fileListCount; counter3++){
                                            if (xyPositionData [counter3*3+2] > imagePositionXMax) imagePositionXMax = xyPositionData [counter3*3+2];
                                            if (xyPositionData [counter3*3+1] > imagePositionYMax) imagePositionYMax = xyPositionData [counter3*3+1];
                                            if (xyPositionData [counter3*3+2] < imagePositionXMin) imagePositionXMin = xyPositionData [counter3*3+2];
                                            if (xyPositionData [counter3*3+1] < imagePositionYMin) imagePositionYMin = xyPositionData [counter3*3+1];
                                        }
                                        
                                        if (imagePositionXMax == 0 || imagePositionXMin == 100000000){
                                            imagePositionXMax = 0;
                                            imagePositionXMin = 0;
                                        }
                                        
                                        if (imagePositionYMax == 0 || imagePositionYMin == 100000000){
                                            imagePositionYMax = 0;
                                            imagePositionYMin = 0;
                                        }
                                        
                                        imagePositionXMax = imagePositionXMax+imageDimensionW;
                                        imagePositionYMax = imagePositionYMax+imageDimensionH;
                                        
                                        int imagePositionXDimension = imagePositionXMax-imagePositionXMin;
                                        int imagePositionYDimension = imagePositionYMax-imagePositionYMin;
                                        int longerXAxeAdjust = 0;
                                        int longerYAxeAdjust = 0;
                                        
                                        if (imagePositionXDimension > imagePositionYDimension){
                                            stitchedImageDimension = imagePositionXDimension;
                                            longerYAxeAdjust = (int)((imagePositionXDimension-imagePositionYDimension)/(double)2);
                                        }
                                        else{
                                            
                                            stitchedImageDimension = imagePositionYDimension;
                                            longerXAxeAdjust = (int)((imagePositionYDimension-imagePositionXDimension)/(double)2);
                                        }
                                        
                                        int stitchedImageDimensionAddition = (int)(stitchedImageDimension*0.2);
                                        
                                        stitchedImageDimension = stitchedImageDimension+stitchedImageDimensionAddition;
                                        
                                        int dimensionAdjust = stitchedImageDimension/4;
                                        stitchedImageDimension = dimensionAdjust*4+4;
                                        
                                        for (int counter2 = 0; counter2 < fileListCount; counter2++){
                                            if (longerXAxeAdjust == 0){
                                                xyPositionWritingData [counter2*3] = xyPositionData [counter2*3];
                                                xyPositionWritingData [counter2*3+1] = xyPositionData [counter2*3+1]-imagePositionYMin+(int)(stitchedImageDimensionAddition/(double)2)+longerYAxeAdjust;
                                                xyPositionWritingData [counter2*3+2] = xyPositionData [counter2*3+2]-imagePositionXMin+(int)(stitchedImageDimensionAddition/(double)2);
                                            }
                                            else{
                                                
                                                xyPositionWritingData [counter2*3] = xyPositionData [counter2*3];
                                                xyPositionWritingData [counter2*3+1] = xyPositionData [counter2*3+1]-imagePositionYMin+(int)(stitchedImageDimensionAddition/(double)2);
                                                xyPositionWritingData [counter2*3+2] = xyPositionData [counter2*3+2]-imagePositionXMin+(int)(stitchedImageDimensionAddition/(double)2)+longerXAxeAdjust;
                                            }
                                        }
                                        
                                        if (photoMetricsHold == 1){
                                            if (imageRangeAdjustStatus == 1){
                                                for (int counter2 = 0; counter2 < stitchedImageDimensionHold+1; counter2++){
                                                    delete [] imageDisplayArray [counter2];
                                                    delete [] imagePositionMap [counter2];
                                                }
                                                
                                                delete [] imageDisplayArray;
                                                delete [] imagePositionMap;
                                            }
                                            
                                            imageRangeAdjustStatus = 1;
                                            
                                            imageDisplayArray = new int *[stitchedImageDimension+1];
                                            imagePositionMap = new int *[stitchedImageDimension+1];
                                            
                                            for (int counter2 = 0; counter2 < stitchedImageDimension+1; counter2++){
                                                imageDisplayArray [counter2] = new int [stitchedImageDimension+1];
                                                imagePositionMap [counter2] = new int [stitchedImageDimension+1];
                                            }
                                            
                                            for (int counter3 = 0; counter3 < stitchedImageDimension; counter3++){
                                                for (int counter4 = 0; counter4 < stitchedImageDimension; counter4++){
                                                    imageDisplayArray [counter3][counter4] = 0;
                                                    imagePositionMap [counter3][counter4] = 0;
                                                }
                                            }
                                            
                                            for (int counter2 = 0; counter2 < fileListCount; counter2++){
                                                for (int counter3 = 0; counter3 < imageDimensionH; counter3++){
                                                    for (int counter4 = 0; counter4 < imageDimensionW; counter4++){
                                                        imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]+counter4] = arrayImageDataHold [counter2*imageDimensionH+counter3][counter4];
                                                        imagePositionMap [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]+counter4] = xyPositionWritingData [counter2*3];
                                                    }
                                                }
                                            }
                                        }
                                        else if (photoMetricsHold == 2){
                                            if (imageRangeAdjustStatus == 1){
                                                for (int counter2 = 0; counter2 < stitchedImageDimensionHold+1; counter2++){
                                                    delete [] imageDisplayArray [counter2];
                                                    delete [] imagePositionMap [counter2];
                                                }
                                                
                                                delete [] imageDisplayArray;
                                                delete [] imagePositionMap;
                                            }
                                            
                                            imageRangeAdjustStatus = 1;
                                            
                                            imageDisplayArray = new int *[stitchedImageDimension+1];
                                            imagePositionMap = new int *[stitchedImageDimension+1];
                                            
                                            for (int counter2 = 0; counter2 < stitchedImageDimension+1; counter2++){
                                                imageDisplayArray [counter2] = new int [stitchedImageDimension*3+1];
                                                imagePositionMap [counter2] = new int [stitchedImageDimension*3+1];
                                            }
                                            
                                            for (int counter2 = 0; counter2 < stitchedImageDimension; counter2++){
                                                for (int counter3 = 0; counter3 < stitchedImageDimension*3; counter3++){
                                                    imageDisplayArray [counter2][counter3] = 0;
                                                    imagePositionMap [counter2][counter3] = 0;
                                                }
                                            }
                                            
                                            for (int counter2 = 0; counter2 < fileListCount; counter2++){
                                                for (int counter3 = 0; counter3 < imageDimensionH; counter3++){
                                                    for (int counter4 = 0; counter4 < imageDimensionW*3; counter4 = counter4+3){
                                                        imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4] = arrayImageDataHold [counter2*imageDimensionH+counter3][counter4];
                                                        imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4+1] = arrayImageDataHold [counter2*imageDimensionH+counter3][counter4+1];
                                                        imageDisplayArray [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4+2] = arrayImageDataHold [counter2*imageDimensionH+counter3][counter4+2];
                                                        
                                                        imagePositionMap [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4] = xyPositionWritingData [counter2*3];
                                                        imagePositionMap [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4+1] = xyPositionWritingData [counter2*3];
                                                        imagePositionMap [xyPositionWritingData [counter2*3+1]+counter3][xyPositionWritingData [counter2*3+2]*3+counter4+2] = xyPositionWritingData [counter2*3];
                                                    }
                                                }
                                            }
                                        }
                                        
                                        imageDisplayCall = 1;
                                    }
                                    else warningSet = 9;
                                }
                                else warningSet = 8;
                                
                                delete [] imageSizeArray;
                                delete [] imageInformationArray;
                            }
                            else warningSet = 7;
                            
                            delete [] fileList2;
                            
                            progressTiming = 8;
                            copyProgressFlag = 0;
                        });
                    }
                    else{
                        
                        if (currentImageName == ""){
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"No Images Loaded"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Image Number Does Not Match"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                }
                else{
                    
                    string duplicateNo = "Duplicate no: ";
                    
                    for (int counter1 = 0; counter1 < duplicateNumberListCount; counter1++){
                        duplicateNo = duplicateNo+to_string(duplicateNumberList [counter1])+"/";
                    }
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@(duplicateNo.c_str())];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                
                delete [] duplicateNumberList;
            }
            else{
                
                string missingNo = "Missing no: ";
                
                for (int counter1 = 0; counter1 < missingNumberListCount; counter1++){
                    missingNo = missingNo+to_string(missingNumberList [counter1])+"/";
                }
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@(missingNo.c_str())];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
            
            delete [] missingNumberList;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Data Entered"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        if (currentListName == "" || currentListNumber == ""){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Data Entered"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Other Processes In Progress"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)up1:(id)sender{
    if (currentListName != "" && currentListNumber != ""){
        string inputValue = [[xyAssign11 stringValue] UTF8String];
        
        if (atoi(inputValue.c_str()) >= 1 && atoi(inputValue.c_str()) <= 81){
            string *newTableumber = new string [10];
            
            for (int counter1 = 0; counter1 < 9; counter1++) newTableumber [counter1] = "";
            
            int entryCount = 0;
            int inputValueInt = atoi(inputValue.c_str());
            
            for (int counter1 = 0; counter1 < 9; counter1++){
                if (inputValueInt+entryCount <= 81){
                    newTableumber [entryCount] = to_string(inputValueInt+entryCount), entryCount++;
                }
            }
            
            [xyAssign11 setStringValue:@(newTableumber [0].c_str())];
            [xyAssign21 setStringValue:@(newTableumber [1].c_str())];
            [xyAssign31 setStringValue:@(newTableumber [2].c_str())];
            [xyAssign41 setStringValue:@(newTableumber [3].c_str())];
            [xyAssign51 setStringValue:@(newTableumber [4].c_str())];
            [xyAssign61 setStringValue:@(newTableumber [5].c_str())];
            [xyAssign71 setStringValue:@(newTableumber [6].c_str())];
            [xyAssign81 setStringValue:@(newTableumber [7].c_str())];
            [xyAssign91 setStringValue:@(newTableumber [8].c_str())];
            
            delete [] newTableumber;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Number Must Be Between 1 And 81"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Entered"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)up2:(id)sender{
    if (currentListName != "" && currentListNumber != ""){
        string inputValue = [[xyAssign12 stringValue] UTF8String];
        
        if (atoi(inputValue.c_str()) >= 1 && atoi(inputValue.c_str()) <= 81){
            string *newTableumber = new string [10];
            
            for (int counter1 = 0; counter1 < 9; counter1++) newTableumber [counter1] = "";
            
            int entryCount = 0;
            int inputValueInt = atoi(inputValue.c_str());
            
            for (int counter1 = 0; counter1 < 9; counter1++){
                if (inputValueInt+entryCount <= 81){
                    newTableumber [entryCount] = to_string(inputValueInt+entryCount), entryCount++;
                }
            }
            
            [xyAssign12 setStringValue:@(newTableumber [0].c_str())];
            [xyAssign22 setStringValue:@(newTableumber [1].c_str())];
            [xyAssign32 setStringValue:@(newTableumber [2].c_str())];
            [xyAssign42 setStringValue:@(newTableumber [3].c_str())];
            [xyAssign52 setStringValue:@(newTableumber [4].c_str())];
            [xyAssign62 setStringValue:@(newTableumber [5].c_str())];
            [xyAssign72 setStringValue:@(newTableumber [6].c_str())];
            [xyAssign82 setStringValue:@(newTableumber [7].c_str())];
            [xyAssign92 setStringValue:@(newTableumber [8].c_str())];
            
            delete [] newTableumber;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Number Must Be Between 1 And 81"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Entered"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)up3:(id)sender{
    if (currentListName != "" && currentListNumber != ""){
        string inputValue = [[xyAssign13 stringValue] UTF8String];
        
        if (atoi(inputValue.c_str()) >= 1 && atoi(inputValue.c_str()) <= 81){
            string *newTableumber = new string [10];
            
            for (int counter1 = 0; counter1 < 9; counter1++) newTableumber [counter1] = "";
            
            int entryCount = 0;
            int inputValueInt = atoi(inputValue.c_str());
            
            for (int counter1 = 0; counter1 < 9; counter1++){
                if (inputValueInt+entryCount <= 81){
                    newTableumber [entryCount] = to_string(inputValueInt+entryCount), entryCount++;
                }
            }
            
            [xyAssign13 setStringValue:@(newTableumber [0].c_str())];
            [xyAssign23 setStringValue:@(newTableumber [1].c_str())];
            [xyAssign33 setStringValue:@(newTableumber [2].c_str())];
            [xyAssign43 setStringValue:@(newTableumber [3].c_str())];
            [xyAssign53 setStringValue:@(newTableumber [4].c_str())];
            [xyAssign63 setStringValue:@(newTableumber [5].c_str())];
            [xyAssign73 setStringValue:@(newTableumber [6].c_str())];
            [xyAssign83 setStringValue:@(newTableumber [7].c_str())];
            [xyAssign93 setStringValue:@(newTableumber [8].c_str())];
            
            delete [] newTableumber;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Number Must Be Between 1 And 81"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Entered"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)up4:(id)sender{
    if (currentListName != "" && currentListNumber != ""){
        string inputValue = [[xyAssign14 stringValue] UTF8String];
        
        if (atoi(inputValue.c_str()) >= 1 && atoi(inputValue.c_str()) <= 81){
            string *newTableumber = new string [10];
            
            for (int counter1 = 0; counter1 < 9; counter1++) newTableumber [counter1] = "";
            
            int entryCount = 0;
            int inputValueInt = atoi(inputValue.c_str());
            
            for (int counter1 = 0; counter1 < 9; counter1++){
                if (inputValueInt+entryCount <= 81){
                    newTableumber [entryCount] = to_string(inputValueInt+entryCount), entryCount++;
                }
            }
            
            [xyAssign14 setStringValue:@(newTableumber [0].c_str())];
            [xyAssign24 setStringValue:@(newTableumber [1].c_str())];
            [xyAssign34 setStringValue:@(newTableumber [2].c_str())];
            [xyAssign44 setStringValue:@(newTableumber [3].c_str())];
            [xyAssign54 setStringValue:@(newTableumber [4].c_str())];
            [xyAssign64 setStringValue:@(newTableumber [5].c_str())];
            [xyAssign74 setStringValue:@(newTableumber [6].c_str())];
            [xyAssign84 setStringValue:@(newTableumber [7].c_str())];
            [xyAssign94 setStringValue:@(newTableumber [8].c_str())];
            
            delete [] newTableumber;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Number Must Be Between 1 And 81"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Entered"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)up5:(id)sender{
    if (currentListName != "" && currentListNumber != ""){
        string inputValue = [[xyAssign15 stringValue] UTF8String];
        
        if (atoi(inputValue.c_str()) >= 1 && atoi(inputValue.c_str()) <= 81){
            string *newTableumber = new string [10];
            
            for (int counter1 = 0; counter1 < 9; counter1++) newTableumber [counter1] = "";
            
            int entryCount = 0;
            int inputValueInt = atoi(inputValue.c_str());
            
            for (int counter1 = 0; counter1 < 9; counter1++){
                if (inputValueInt+entryCount <= 81){
                    newTableumber [entryCount] = to_string(inputValueInt+entryCount), entryCount++;
                }
            }
            
            [xyAssign15 setStringValue:@(newTableumber [0].c_str())];
            [xyAssign25 setStringValue:@(newTableumber [1].c_str())];
            [xyAssign35 setStringValue:@(newTableumber [2].c_str())];
            [xyAssign45 setStringValue:@(newTableumber [3].c_str())];
            [xyAssign55 setStringValue:@(newTableumber [4].c_str())];
            [xyAssign65 setStringValue:@(newTableumber [5].c_str())];
            [xyAssign75 setStringValue:@(newTableumber [6].c_str())];
            [xyAssign85 setStringValue:@(newTableumber [7].c_str())];
            [xyAssign95 setStringValue:@(newTableumber [8].c_str())];
            
            delete [] newTableumber;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Number Must Be Between 1 And 81"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Entered"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)up6:(id)sender{
    if (currentListName != "" && currentListNumber != ""){
        string inputValue = [[xyAssign16 stringValue] UTF8String];
        
        if (atoi(inputValue.c_str()) >= 1 && atoi(inputValue.c_str()) <= 81){
            string *newTableumber = new string [10];
            
            for (int counter1 = 0; counter1 < 9; counter1++) newTableumber [counter1] = "";
            
            int entryCount = 0;
            int inputValueInt = atoi(inputValue.c_str());
            
            for (int counter1 = 0; counter1 < 9; counter1++){
                if (inputValueInt+entryCount <= 81){
                    newTableumber [entryCount] = to_string(inputValueInt+entryCount), entryCount++;
                }
            }
            
            [xyAssign16 setStringValue:@(newTableumber [0].c_str())];
            [xyAssign26 setStringValue:@(newTableumber [1].c_str())];
            [xyAssign36 setStringValue:@(newTableumber [2].c_str())];
            [xyAssign46 setStringValue:@(newTableumber [3].c_str())];
            [xyAssign56 setStringValue:@(newTableumber [4].c_str())];
            [xyAssign66 setStringValue:@(newTableumber [5].c_str())];
            [xyAssign76 setStringValue:@(newTableumber [6].c_str())];
            [xyAssign86 setStringValue:@(newTableumber [7].c_str())];
            [xyAssign96 setStringValue:@(newTableumber [8].c_str())];
            
            delete [] newTableumber;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Number Must Be Between 1 And 81"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Entered"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)up7:(id)sender{
    if (currentListName != "" && currentListNumber != ""){
        string inputValue = [[xyAssign17 stringValue] UTF8String];
        
        if (atoi(inputValue.c_str()) >= 1 && atoi(inputValue.c_str()) <= 81){
            string *newTableumber = new string [10];
            
            for (int counter1 = 0; counter1 < 9; counter1++) newTableumber [counter1] = "";
            
            int entryCount = 0;
            int inputValueInt = atoi(inputValue.c_str());
            
            for (int counter1 = 0; counter1 < 9; counter1++){
                if (inputValueInt+entryCount <= 81){
                    newTableumber [entryCount] = to_string(inputValueInt+entryCount), entryCount++;
                }
            }
            
            [xyAssign17 setStringValue:@(newTableumber [0].c_str())];
            [xyAssign27 setStringValue:@(newTableumber [1].c_str())];
            [xyAssign37 setStringValue:@(newTableumber [2].c_str())];
            [xyAssign47 setStringValue:@(newTableumber [3].c_str())];
            [xyAssign57 setStringValue:@(newTableumber [4].c_str())];
            [xyAssign67 setStringValue:@(newTableumber [5].c_str())];
            [xyAssign77 setStringValue:@(newTableumber [6].c_str())];
            [xyAssign87 setStringValue:@(newTableumber [7].c_str())];
            [xyAssign97 setStringValue:@(newTableumber [8].c_str())];
            
            delete [] newTableumber;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Number Must Be Between 1 And 81"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Entered"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)up8:(id)sender{
    if (currentListName != "" && currentListNumber != ""){
        string inputValue = [[xyAssign18 stringValue] UTF8String];
        
        if (atoi(inputValue.c_str()) >= 1 && atoi(inputValue.c_str()) <= 81){
            string *newTableumber = new string [10];
            
            for (int counter1 = 0; counter1 < 9; counter1++) newTableumber [counter1] = "";
            
            int entryCount = 0;
            int inputValueInt = atoi(inputValue.c_str());
            
            for (int counter1 = 0; counter1 < 9; counter1++){
                if (inputValueInt+entryCount <= 81){
                    newTableumber [entryCount] = to_string(inputValueInt+entryCount), entryCount++;
                }
            }
            
            [xyAssign18 setStringValue:@(newTableumber [0].c_str())];
            [xyAssign28 setStringValue:@(newTableumber [1].c_str())];
            [xyAssign38 setStringValue:@(newTableumber [2].c_str())];
            [xyAssign48 setStringValue:@(newTableumber [3].c_str())];
            [xyAssign58 setStringValue:@(newTableumber [4].c_str())];
            [xyAssign68 setStringValue:@(newTableumber [5].c_str())];
            [xyAssign78 setStringValue:@(newTableumber [6].c_str())];
            [xyAssign88 setStringValue:@(newTableumber [7].c_str())];
            [xyAssign98 setStringValue:@(newTableumber [8].c_str())];
            
            delete [] newTableumber;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Number Must Be Between 1 And 81"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Entered"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)up9:(id)sender{
    if (currentListName != "" && currentListNumber != ""){
        string inputValue = [[xyAssign19 stringValue] UTF8String];
        
        if (atoi(inputValue.c_str()) >= 1 && atoi(inputValue.c_str()) <= 81){
            string *newTableumber = new string [10];
            
            for (int counter1 = 0; counter1 < 9; counter1++) newTableumber [counter1] = "";
            
            int entryCount = 0;
            int inputValueInt = atoi(inputValue.c_str());
            
            for (int counter1 = 0; counter1 < 9; counter1++){
                if (inputValueInt+entryCount <= 81){
                    newTableumber [entryCount] = to_string(inputValueInt+entryCount), entryCount++;
                }
            }
            
            [xyAssign19 setStringValue:@(newTableumber [0].c_str())];
            [xyAssign29 setStringValue:@(newTableumber [1].c_str())];
            [xyAssign39 setStringValue:@(newTableumber [2].c_str())];
            [xyAssign49 setStringValue:@(newTableumber [3].c_str())];
            [xyAssign59 setStringValue:@(newTableumber [4].c_str())];
            [xyAssign69 setStringValue:@(newTableumber [5].c_str())];
            [xyAssign79 setStringValue:@(newTableumber [6].c_str())];
            [xyAssign89 setStringValue:@(newTableumber [7].c_str())];
            [xyAssign99 setStringValue:@(newTableumber [8].c_str())];
            
            delete [] newTableumber;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Number Must Be Between 1 And 81"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Entered"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)down1:(id)sender{
    if (currentListName != "" && currentListNumber != ""){
        string inputValue = [[xyAssign91 stringValue] UTF8String];
        
        if (atoi(inputValue.c_str()) >= 1 && atoi(inputValue.c_str()) <= 81){
            string *newTableumber = new string [10];
            
            for (int counter1 = 0; counter1 < 9; counter1++) newTableumber [counter1] = "";
            
            int entryCount = 0;
            int inputValueInt = atoi(inputValue.c_str());
            
            for (int counter1 = 0; counter1 < 9; counter1++){
                if (inputValueInt+entryCount <= 81){
                    newTableumber [entryCount] = to_string(inputValueInt+entryCount), entryCount++;
                }
            }
            
            [xyAssign91 setStringValue:@(newTableumber [0].c_str())];
            [xyAssign81 setStringValue:@(newTableumber [1].c_str())];
            [xyAssign71 setStringValue:@(newTableumber [2].c_str())];
            [xyAssign61 setStringValue:@(newTableumber [3].c_str())];
            [xyAssign51 setStringValue:@(newTableumber [4].c_str())];
            [xyAssign41 setStringValue:@(newTableumber [5].c_str())];
            [xyAssign31 setStringValue:@(newTableumber [6].c_str())];
            [xyAssign21 setStringValue:@(newTableumber [7].c_str())];
            [xyAssign11 setStringValue:@(newTableumber [8].c_str())];
            
            delete [] newTableumber;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Number Must Be Between 1 And 81"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Entered"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)down2:(id)sender{
    if (currentListName != "" && currentListNumber != ""){
        string inputValue = [[xyAssign92 stringValue] UTF8String];
        
        if (atoi(inputValue.c_str()) >= 1 && atoi(inputValue.c_str()) <= 81){
            string *newTableumber = new string [10];
            
            for (int counter1 = 0; counter1 < 9; counter1++) newTableumber [counter1] = "";
            
            int entryCount = 0;
            int inputValueInt = atoi(inputValue.c_str());
            
            for (int counter1 = 0; counter1 < 9; counter1++){
                if (inputValueInt+entryCount <= 81){
                    newTableumber [entryCount] = to_string(inputValueInt+entryCount), entryCount++;
                }
            }
            
            [xyAssign92 setStringValue:@(newTableumber [0].c_str())];
            [xyAssign82 setStringValue:@(newTableumber [1].c_str())];
            [xyAssign72 setStringValue:@(newTableumber [2].c_str())];
            [xyAssign62 setStringValue:@(newTableumber [3].c_str())];
            [xyAssign52 setStringValue:@(newTableumber [4].c_str())];
            [xyAssign42 setStringValue:@(newTableumber [5].c_str())];
            [xyAssign32 setStringValue:@(newTableumber [6].c_str())];
            [xyAssign22 setStringValue:@(newTableumber [7].c_str())];
            [xyAssign12 setStringValue:@(newTableumber [8].c_str())];
            
            delete [] newTableumber;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Number Must Be Between 1 And 81"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Entered"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)down3:(id)sender{
    if (currentListName != "" && currentListNumber != ""){
        string inputValue = [[xyAssign93 stringValue] UTF8String];
        
        if (atoi(inputValue.c_str()) >= 1 && atoi(inputValue.c_str()) <= 81){
            string *newTableumber = new string [10];
            
            for (int counter1 = 0; counter1 < 9; counter1++) newTableumber [counter1] = "";
            
            int entryCount = 0;
            int inputValueInt = atoi(inputValue.c_str());
            
            for (int counter1 = 0; counter1 < 9; counter1++){
                if (inputValueInt+entryCount <= 81){
                    newTableumber [entryCount] = to_string(inputValueInt+entryCount), entryCount++;
                }
            }
            
            [xyAssign93 setStringValue:@(newTableumber [0].c_str())];
            [xyAssign83 setStringValue:@(newTableumber [1].c_str())];
            [xyAssign73 setStringValue:@(newTableumber [2].c_str())];
            [xyAssign63 setStringValue:@(newTableumber [3].c_str())];
            [xyAssign53 setStringValue:@(newTableumber [4].c_str())];
            [xyAssign43 setStringValue:@(newTableumber [5].c_str())];
            [xyAssign33 setStringValue:@(newTableumber [6].c_str())];
            [xyAssign23 setStringValue:@(newTableumber [7].c_str())];
            [xyAssign13 setStringValue:@(newTableumber [8].c_str())];
            
            delete [] newTableumber;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Number Must Be Between 1 And 81"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Entered"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)down4:(id)sender{
    if (currentListName != "" && currentListNumber != ""){
        string inputValue = [[xyAssign94 stringValue] UTF8String];
        
        if (atoi(inputValue.c_str()) >= 1 && atoi(inputValue.c_str()) <= 81){
            string *newTableumber = new string [10];
            
            for (int counter1 = 0; counter1 < 9; counter1++) newTableumber [counter1] = "";
            
            int entryCount = 0;
            int inputValueInt = atoi(inputValue.c_str());
            
            for (int counter1 = 0; counter1 < 9; counter1++){
                if (inputValueInt+entryCount <= 81){
                    newTableumber [entryCount] = to_string(inputValueInt+entryCount), entryCount++;
                }
            }
            
            [xyAssign94 setStringValue:@(newTableumber [0].c_str())];
            [xyAssign84 setStringValue:@(newTableumber [1].c_str())];
            [xyAssign74 setStringValue:@(newTableumber [2].c_str())];
            [xyAssign64 setStringValue:@(newTableumber [3].c_str())];
            [xyAssign54 setStringValue:@(newTableumber [4].c_str())];
            [xyAssign44 setStringValue:@(newTableumber [5].c_str())];
            [xyAssign34 setStringValue:@(newTableumber [6].c_str())];
            [xyAssign24 setStringValue:@(newTableumber [7].c_str())];
            [xyAssign14 setStringValue:@(newTableumber [8].c_str())];
            
            delete [] newTableumber;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Number Must Be Between 1 And 81"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Entered"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)down5:(id)sender{
    if (currentListName != "" && currentListNumber != ""){
        string inputValue = [[xyAssign95 stringValue] UTF8String];
        
        if (atoi(inputValue.c_str()) >= 1 && atoi(inputValue.c_str()) <= 81){
            string *newTableumber = new string [10];
            
            for (int counter1 = 0; counter1 < 9; counter1++) newTableumber [counter1] = "";
            
            int entryCount = 0;
            int inputValueInt = atoi(inputValue.c_str());
            
            for (int counter1 = 0; counter1 < 9; counter1++){
                if (inputValueInt+entryCount <= 81){
                    newTableumber [entryCount] = to_string(inputValueInt+entryCount), entryCount++;
                }
            }
            
            [xyAssign95 setStringValue:@(newTableumber [0].c_str())];
            [xyAssign85 setStringValue:@(newTableumber [1].c_str())];
            [xyAssign75 setStringValue:@(newTableumber [2].c_str())];
            [xyAssign65 setStringValue:@(newTableumber [3].c_str())];
            [xyAssign55 setStringValue:@(newTableumber [4].c_str())];
            [xyAssign45 setStringValue:@(newTableumber [5].c_str())];
            [xyAssign35 setStringValue:@(newTableumber [6].c_str())];
            [xyAssign25 setStringValue:@(newTableumber [7].c_str())];
            [xyAssign15 setStringValue:@(newTableumber [8].c_str())];
            
            delete [] newTableumber;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Number Must Be Between 1 And 81"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Entered"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)down6:(id)sender{
    if (currentListName != "" && currentListNumber != ""){
        string inputValue = [[xyAssign96 stringValue] UTF8String];
        
        if (atoi(inputValue.c_str()) >= 1 && atoi(inputValue.c_str()) <= 81){
            string *newTableumber = new string [10];
            
            for (int counter1 = 0; counter1 < 9; counter1++) newTableumber [counter1] = "";
            
            int entryCount = 0;
            int inputValueInt = atoi(inputValue.c_str());
            
            for (int counter1 = 0; counter1 < 9; counter1++){
                if (inputValueInt+entryCount <= 81){
                    newTableumber [entryCount] = to_string(inputValueInt+entryCount), entryCount++;
                }
            }
            
            [xyAssign96 setStringValue:@(newTableumber [0].c_str())];
            [xyAssign86 setStringValue:@(newTableumber [1].c_str())];
            [xyAssign76 setStringValue:@(newTableumber [2].c_str())];
            [xyAssign66 setStringValue:@(newTableumber [3].c_str())];
            [xyAssign56 setStringValue:@(newTableumber [4].c_str())];
            [xyAssign46 setStringValue:@(newTableumber [5].c_str())];
            [xyAssign36 setStringValue:@(newTableumber [6].c_str())];
            [xyAssign26 setStringValue:@(newTableumber [7].c_str())];
            [xyAssign16 setStringValue:@(newTableumber [8].c_str())];
            
            delete [] newTableumber;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Number Must Be Between 1 And 81"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Entered"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)down7:(id)sender{
    if (currentListName != "" && currentListNumber != ""){
        string inputValue = [[xyAssign97 stringValue] UTF8String];
        
        if (atoi(inputValue.c_str()) >= 1 && atoi(inputValue.c_str()) <= 81){
            string *newTableumber = new string [10];
            
            for (int counter1 = 0; counter1 < 9; counter1++) newTableumber [counter1] = "";
            
            int entryCount = 0;
            int inputValueInt = atoi(inputValue.c_str());
            
            for (int counter1 = 0; counter1 < 9; counter1++){
                if (inputValueInt+entryCount <= 81){
                    newTableumber [entryCount] = to_string(inputValueInt+entryCount), entryCount++;
                }
            }
            
            [xyAssign97 setStringValue:@(newTableumber [0].c_str())];
            [xyAssign87 setStringValue:@(newTableumber [1].c_str())];
            [xyAssign77 setStringValue:@(newTableumber [2].c_str())];
            [xyAssign67 setStringValue:@(newTableumber [3].c_str())];
            [xyAssign57 setStringValue:@(newTableumber [4].c_str())];
            [xyAssign47 setStringValue:@(newTableumber [5].c_str())];
            [xyAssign37 setStringValue:@(newTableumber [6].c_str())];
            [xyAssign27 setStringValue:@(newTableumber [7].c_str())];
            [xyAssign17 setStringValue:@(newTableumber [8].c_str())];
            
            delete [] newTableumber;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Number Must Be Between 1 And 81"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Entered"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)down8:(id)sender{
    if (currentListName != "" && currentListNumber != ""){
        string inputValue = [[xyAssign98 stringValue] UTF8String];
        
        if (atoi(inputValue.c_str()) >= 1 && atoi(inputValue.c_str()) <= 81){
            string *newTableumber = new string [10];
            
            for (int counter1 = 0; counter1 < 9; counter1++) newTableumber [counter1] = "";
            
            int entryCount = 0;
            int inputValueInt = atoi(inputValue.c_str());
            
            for (int counter1 = 0; counter1 < 9; counter1++){
                if (inputValueInt+entryCount <= 81){
                    newTableumber [entryCount] = to_string(inputValueInt+entryCount), entryCount++;
                }
            }
            
            [xyAssign98 setStringValue:@(newTableumber [0].c_str())];
            [xyAssign88 setStringValue:@(newTableumber [1].c_str())];
            [xyAssign78 setStringValue:@(newTableumber [2].c_str())];
            [xyAssign68 setStringValue:@(newTableumber [3].c_str())];
            [xyAssign58 setStringValue:@(newTableumber [4].c_str())];
            [xyAssign48 setStringValue:@(newTableumber [5].c_str())];
            [xyAssign38 setStringValue:@(newTableumber [6].c_str())];
            [xyAssign28 setStringValue:@(newTableumber [7].c_str())];
            [xyAssign18 setStringValue:@(newTableumber [8].c_str())];
            
            delete [] newTableumber;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Number Must Be Between 1 And 81"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Entered"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)down9:(id)sender{
    if (currentListName != "" && currentListNumber != ""){
        string inputValue = [[xyAssign99 stringValue] UTF8String];
        
        if (atoi(inputValue.c_str()) >= 1 && atoi(inputValue.c_str()) <= 81){
            string *newTableumber = new string [10];
            
            for (int counter1 = 0; counter1 < 9; counter1++) newTableumber [counter1] = "";
            
            int entryCount = 0;
            int inputValueInt = atoi(inputValue.c_str());
            
            for (int counter1 = 0; counter1 < 9; counter1++){
                if (inputValueInt+entryCount <= 81){
                    newTableumber [entryCount] = to_string(inputValueInt+entryCount), entryCount++;
                }
            }
            
            [xyAssign99 setStringValue:@(newTableumber [0].c_str())];
            [xyAssign89 setStringValue:@(newTableumber [1].c_str())];
            [xyAssign79 setStringValue:@(newTableumber [2].c_str())];
            [xyAssign69 setStringValue:@(newTableumber [3].c_str())];
            [xyAssign59 setStringValue:@(newTableumber [4].c_str())];
            [xyAssign49 setStringValue:@(newTableumber [5].c_str())];
            [xyAssign39 setStringValue:@(newTableumber [6].c_str())];
            [xyAssign29 setStringValue:@(newTableumber [7].c_str())];
            [xyAssign19 setStringValue:@(newTableumber [8].c_str())];
            
            delete [] newTableumber;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Number Must Be Between 1 And 81"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Entered"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)right1:(id)sender{
    if (currentListName != "" && currentListNumber != ""){
        string inputValue = [[xyAssign11 stringValue] UTF8String];
        
        if (atoi(inputValue.c_str()) >= 1 && atoi(inputValue.c_str()) <= 81){
            string *newTableumber = new string [10];
            
            for (int counter1 = 0; counter1 < 9; counter1++) newTableumber [counter1] = "";
            
            int entryCount = 0;
            int inputValueInt = atoi(inputValue.c_str());
            
            for (int counter1 = 0; counter1 < 9; counter1++){
                if (inputValueInt+entryCount <= 81){
                    newTableumber [entryCount] = to_string(inputValueInt+entryCount), entryCount++;
                }
            }
            
            [xyAssign11 setStringValue:@(newTableumber [0].c_str())];
            [xyAssign12 setStringValue:@(newTableumber [1].c_str())];
            [xyAssign13 setStringValue:@(newTableumber [2].c_str())];
            [xyAssign14 setStringValue:@(newTableumber [3].c_str())];
            [xyAssign15 setStringValue:@(newTableumber [4].c_str())];
            [xyAssign16 setStringValue:@(newTableumber [5].c_str())];
            [xyAssign17 setStringValue:@(newTableumber [6].c_str())];
            [xyAssign18 setStringValue:@(newTableumber [7].c_str())];
            [xyAssign19 setStringValue:@(newTableumber [8].c_str())];
            
            delete [] newTableumber;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Number Must Be Between 1 And 81"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Entered"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)right2:(id)sender{
    if (currentListName != "" && currentListNumber != ""){
        string inputValue = [[xyAssign21 stringValue] UTF8String];
        
        if (atoi(inputValue.c_str()) >= 1 && atoi(inputValue.c_str()) <= 81){
            string *newTableumber = new string [10];
            
            for (int counter1 = 0; counter1 < 9; counter1++) newTableumber [counter1] = "";
            
            int entryCount = 0;
            int inputValueInt = atoi(inputValue.c_str());
            
            for (int counter1 = 0; counter1 < 9; counter1++){
                if (inputValueInt+entryCount <= 81){
                    newTableumber [entryCount] = to_string(inputValueInt+entryCount), entryCount++;
                }
            }
            
            [xyAssign21 setStringValue:@(newTableumber [0].c_str())];
            [xyAssign22 setStringValue:@(newTableumber [1].c_str())];
            [xyAssign23 setStringValue:@(newTableumber [2].c_str())];
            [xyAssign24 setStringValue:@(newTableumber [3].c_str())];
            [xyAssign25 setStringValue:@(newTableumber [4].c_str())];
            [xyAssign26 setStringValue:@(newTableumber [5].c_str())];
            [xyAssign27 setStringValue:@(newTableumber [6].c_str())];
            [xyAssign28 setStringValue:@(newTableumber [7].c_str())];
            [xyAssign29 setStringValue:@(newTableumber [8].c_str())];
            
            delete [] newTableumber;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Number Must Be Between 1 And 81"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Entered"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)right3:(id)sender{
    if (currentListName != "" && currentListNumber != ""){
        string inputValue = [[xyAssign31 stringValue] UTF8String];
        
        if (atoi(inputValue.c_str()) >= 1 && atoi(inputValue.c_str()) <= 81){
            string *newTableumber = new string [10];
            
            for (int counter1 = 0; counter1 < 9; counter1++) newTableumber [counter1] = "";
            
            int entryCount = 0;
            int inputValueInt = atoi(inputValue.c_str());
            
            for (int counter1 = 0; counter1 < 9; counter1++){
                if (inputValueInt+entryCount <= 81){
                    newTableumber [entryCount] = to_string(inputValueInt+entryCount), entryCount++;
                }
            }
            
            [xyAssign31 setStringValue:@(newTableumber [0].c_str())];
            [xyAssign32 setStringValue:@(newTableumber [1].c_str())];
            [xyAssign33 setStringValue:@(newTableumber [2].c_str())];
            [xyAssign34 setStringValue:@(newTableumber [3].c_str())];
            [xyAssign35 setStringValue:@(newTableumber [4].c_str())];
            [xyAssign36 setStringValue:@(newTableumber [5].c_str())];
            [xyAssign37 setStringValue:@(newTableumber [6].c_str())];
            [xyAssign38 setStringValue:@(newTableumber [7].c_str())];
            [xyAssign39 setStringValue:@(newTableumber [8].c_str())];
            
            delete [] newTableumber;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Number Must Be Between 1 And 81"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Entered"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)right4:(id)sender{
    if (currentListName != "" && currentListNumber != ""){
        string inputValue = [[xyAssign41 stringValue] UTF8String];
        
        if (atoi(inputValue.c_str()) >= 1 && atoi(inputValue.c_str()) <= 81){
            string *newTableumber = new string [10];
            
            for (int counter1 = 0; counter1 < 9; counter1++) newTableumber [counter1] = "";
            
            int entryCount = 0;
            int inputValueInt = atoi(inputValue.c_str());
            
            for (int counter1 = 0; counter1 < 9; counter1++){
                if (inputValueInt+entryCount <= 81){
                    newTableumber [entryCount] = to_string(inputValueInt+entryCount), entryCount++;
                }
            }
            
            [xyAssign41 setStringValue:@(newTableumber [0].c_str())];
            [xyAssign42 setStringValue:@(newTableumber [1].c_str())];
            [xyAssign43 setStringValue:@(newTableumber [2].c_str())];
            [xyAssign44 setStringValue:@(newTableumber [3].c_str())];
            [xyAssign45 setStringValue:@(newTableumber [4].c_str())];
            [xyAssign46 setStringValue:@(newTableumber [5].c_str())];
            [xyAssign47 setStringValue:@(newTableumber [6].c_str())];
            [xyAssign48 setStringValue:@(newTableumber [7].c_str())];
            [xyAssign49 setStringValue:@(newTableumber [8].c_str())];
            
            delete [] newTableumber;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Number Must Be Between 1 And 81"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Entered"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)right5:(id)sender{
    if (currentListName != "" && currentListNumber != ""){
        string inputValue = [[xyAssign51 stringValue] UTF8String];
        
        if (atoi(inputValue.c_str()) >= 1 && atoi(inputValue.c_str()) <= 81){
            string *newTableumber = new string [10];
            
            for (int counter1 = 0; counter1 < 9; counter1++) newTableumber [counter1] = "";
            
            int entryCount = 0;
            int inputValueInt = atoi(inputValue.c_str());
            
            for (int counter1 = 0; counter1 < 9; counter1++){
                if (inputValueInt+entryCount <= 81){
                    newTableumber [entryCount] = to_string(inputValueInt+entryCount), entryCount++;
                }
            }
            
            [xyAssign51 setStringValue:@(newTableumber [0].c_str())];
            [xyAssign52 setStringValue:@(newTableumber [1].c_str())];
            [xyAssign53 setStringValue:@(newTableumber [2].c_str())];
            [xyAssign54 setStringValue:@(newTableumber [3].c_str())];
            [xyAssign55 setStringValue:@(newTableumber [4].c_str())];
            [xyAssign56 setStringValue:@(newTableumber [5].c_str())];
            [xyAssign57 setStringValue:@(newTableumber [6].c_str())];
            [xyAssign58 setStringValue:@(newTableumber [7].c_str())];
            [xyAssign59 setStringValue:@(newTableumber [8].c_str())];
            
            delete [] newTableumber;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Number Must Be Between 1 And 81"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Entered"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)right6:(id)sender{
    if (currentListName != "" && currentListNumber != ""){
        string inputValue = [[xyAssign61 stringValue] UTF8String];
        
        if (atoi(inputValue.c_str()) >= 1 && atoi(inputValue.c_str()) <= 81){
            string *newTableumber = new string [10];
            
            for (int counter1 = 0; counter1 < 9; counter1++) newTableumber [counter1] = "";
            
            int entryCount = 0;
            int inputValueInt = atoi(inputValue.c_str());
            
            for (int counter1 = 0; counter1 < 9; counter1++){
                if (inputValueInt+entryCount <= 81){
                    newTableumber [entryCount] = to_string(inputValueInt+entryCount), entryCount++;
                }
            }
            
            [xyAssign61 setStringValue:@(newTableumber [0].c_str())];
            [xyAssign62 setStringValue:@(newTableumber [1].c_str())];
            [xyAssign63 setStringValue:@(newTableumber [2].c_str())];
            [xyAssign64 setStringValue:@(newTableumber [3].c_str())];
            [xyAssign65 setStringValue:@(newTableumber [4].c_str())];
            [xyAssign66 setStringValue:@(newTableumber [5].c_str())];
            [xyAssign67 setStringValue:@(newTableumber [6].c_str())];
            [xyAssign68 setStringValue:@(newTableumber [7].c_str())];
            [xyAssign69 setStringValue:@(newTableumber [8].c_str())];
            
            delete [] newTableumber;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Number Must Be Between 1 And 81"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Entered"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)right7:(id)sender{
    if (currentListName != "" && currentListNumber != ""){
        string inputValue = [[xyAssign71 stringValue] UTF8String];
        
        if (atoi(inputValue.c_str()) >= 1 && atoi(inputValue.c_str()) <= 81){
            string *newTableumber = new string [10];
            
            for (int counter1 = 0; counter1 < 9; counter1++) newTableumber [counter1] = "";
            
            int entryCount = 0;
            int inputValueInt = atoi(inputValue.c_str());
            
            for (int counter1 = 0; counter1 < 9; counter1++){
                if (inputValueInt+entryCount <= 81){
                    newTableumber [entryCount] = to_string(inputValueInt+entryCount), entryCount++;
                }
            }
            
            [xyAssign71 setStringValue:@(newTableumber [0].c_str())];
            [xyAssign72 setStringValue:@(newTableumber [1].c_str())];
            [xyAssign73 setStringValue:@(newTableumber [2].c_str())];
            [xyAssign74 setStringValue:@(newTableumber [3].c_str())];
            [xyAssign75 setStringValue:@(newTableumber [4].c_str())];
            [xyAssign76 setStringValue:@(newTableumber [5].c_str())];
            [xyAssign77 setStringValue:@(newTableumber [6].c_str())];
            [xyAssign78 setStringValue:@(newTableumber [7].c_str())];
            [xyAssign79 setStringValue:@(newTableumber [8].c_str())];
            
            delete [] newTableumber;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Number Must Be Between 1 And 81"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Entered"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}
-(IBAction)right8:(id)sender{
    if (currentListName != "" && currentListNumber != ""){
        string inputValue = [[xyAssign81 stringValue] UTF8String];
        
        if (atoi(inputValue.c_str()) >= 1 && atoi(inputValue.c_str()) <= 81){
            string *newTableumber = new string [10];
            
            for (int counter1 = 0; counter1 < 9; counter1++) newTableumber [counter1] = "";
            
            int entryCount = 0;
            int inputValueInt = atoi(inputValue.c_str());
            
            for (int counter1 = 0; counter1 < 9; counter1++){
                if (inputValueInt+entryCount <= 81){
                    newTableumber [entryCount] = to_string(inputValueInt+entryCount), entryCount++;
                }
            }
            
            [xyAssign81 setStringValue:@(newTableumber [0].c_str())];
            [xyAssign82 setStringValue:@(newTableumber [1].c_str())];
            [xyAssign83 setStringValue:@(newTableumber [2].c_str())];
            [xyAssign84 setStringValue:@(newTableumber [3].c_str())];
            [xyAssign85 setStringValue:@(newTableumber [4].c_str())];
            [xyAssign86 setStringValue:@(newTableumber [5].c_str())];
            [xyAssign87 setStringValue:@(newTableumber [6].c_str())];
            [xyAssign88 setStringValue:@(newTableumber [7].c_str())];
            [xyAssign89 setStringValue:@(newTableumber [8].c_str())];
            
            delete [] newTableumber;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Number Must Be Between 1 And 81"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Entered"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)right9:(id)sender{
    if (currentListName != "" && currentListNumber != ""){
        string inputValue = [[xyAssign91 stringValue] UTF8String];
        
        if (atoi(inputValue.c_str()) >= 1 && atoi(inputValue.c_str()) <= 81){
            string *newTableumber = new string [10];
            
            for (int counter1 = 0; counter1 < 9; counter1++) newTableumber [counter1] = "";
            
            int entryCount = 0;
            int inputValueInt = atoi(inputValue.c_str());
            
            for (int counter1 = 0; counter1 < 9; counter1++){
                if (inputValueInt+entryCount <= 81){
                    newTableumber [entryCount] = to_string(inputValueInt+entryCount), entryCount++;
                }
            }
            
            [xyAssign91 setStringValue:@(newTableumber [0].c_str())];
            [xyAssign92 setStringValue:@(newTableumber [1].c_str())];
            [xyAssign93 setStringValue:@(newTableumber [2].c_str())];
            [xyAssign94 setStringValue:@(newTableumber [3].c_str())];
            [xyAssign95 setStringValue:@(newTableumber [4].c_str())];
            [xyAssign96 setStringValue:@(newTableumber [5].c_str())];
            [xyAssign97 setStringValue:@(newTableumber [6].c_str())];
            [xyAssign98 setStringValue:@(newTableumber [7].c_str())];
            [xyAssign99 setStringValue:@(newTableumber [8].c_str())];
            
            delete [] newTableumber;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Number Must Be Between 1 And 81"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Entered"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)left1:(id)sender{
    if (currentListName != "" && currentListNumber != ""){
        string inputValue = [[xyAssign19 stringValue] UTF8String];
        
        if (atoi(inputValue.c_str()) >= 1 && atoi(inputValue.c_str()) <= 81){
            string *newTableumber = new string [10];
            
            for (int counter1 = 0; counter1 < 9; counter1++) newTableumber [counter1] = "";
            
            int entryCount = 0;
            int inputValueInt = atoi(inputValue.c_str());
            
            for (int counter1 = 0; counter1 < 9; counter1++){
                if (inputValueInt+entryCount <= 81){
                    newTableumber [entryCount] = to_string(inputValueInt+entryCount), entryCount++;
                }
            }
            
            [xyAssign19 setStringValue:@(newTableumber [0].c_str())];
            [xyAssign18 setStringValue:@(newTableumber [1].c_str())];
            [xyAssign17 setStringValue:@(newTableumber [2].c_str())];
            [xyAssign16 setStringValue:@(newTableumber [3].c_str())];
            [xyAssign15 setStringValue:@(newTableumber [4].c_str())];
            [xyAssign14 setStringValue:@(newTableumber [5].c_str())];
            [xyAssign13 setStringValue:@(newTableumber [6].c_str())];
            [xyAssign12 setStringValue:@(newTableumber [7].c_str())];
            [xyAssign11 setStringValue:@(newTableumber [8].c_str())];
            
            delete [] newTableumber;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Number Must Be Between 1 And 81"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Entered"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)left2:(id)sender{
    if (currentListName != "" && currentListNumber != ""){
        string inputValue = [[xyAssign29 stringValue] UTF8String];
        
        if (atoi(inputValue.c_str()) >= 1 && atoi(inputValue.c_str()) <= 81){
            string *newTableumber = new string [10];
            
            for (int counter1 = 0; counter1 < 9; counter1++) newTableumber [counter1] = "";
            
            int entryCount = 0;
            int inputValueInt = atoi(inputValue.c_str());
            
            for (int counter1 = 0; counter1 < 9; counter1++){
                if (inputValueInt+entryCount <= 81){
                    newTableumber [entryCount] = to_string(inputValueInt+entryCount), entryCount++;
                }
            }
            
            [xyAssign29 setStringValue:@(newTableumber [0].c_str())];
            [xyAssign28 setStringValue:@(newTableumber [1].c_str())];
            [xyAssign27 setStringValue:@(newTableumber [2].c_str())];
            [xyAssign26 setStringValue:@(newTableumber [3].c_str())];
            [xyAssign25 setStringValue:@(newTableumber [4].c_str())];
            [xyAssign24 setStringValue:@(newTableumber [5].c_str())];
            [xyAssign23 setStringValue:@(newTableumber [6].c_str())];
            [xyAssign22 setStringValue:@(newTableumber [7].c_str())];
            [xyAssign21 setStringValue:@(newTableumber [8].c_str())];
            
            delete [] newTableumber;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Number Must Be Between 1 And 81"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Entered"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)left3:(id)sender{
    if (currentListName != "" && currentListNumber != ""){
        string inputValue = [[xyAssign39 stringValue] UTF8String];
        
        if (atoi(inputValue.c_str()) >= 1 && atoi(inputValue.c_str()) <= 81){
            string *newTableumber = new string [10];
            
            for (int counter1 = 0; counter1 < 9; counter1++) newTableumber [counter1] = "";
            
            int entryCount = 0;
            int inputValueInt = atoi(inputValue.c_str());
            
            for (int counter1 = 0; counter1 < 9; counter1++){
                if (inputValueInt+entryCount <= 81){
                    newTableumber [entryCount] = to_string(inputValueInt+entryCount), entryCount++;
                }
            }
            
            [xyAssign39 setStringValue:@(newTableumber [0].c_str())];
            [xyAssign38 setStringValue:@(newTableumber [1].c_str())];
            [xyAssign37 setStringValue:@(newTableumber [2].c_str())];
            [xyAssign36 setStringValue:@(newTableumber [3].c_str())];
            [xyAssign35 setStringValue:@(newTableumber [4].c_str())];
            [xyAssign34 setStringValue:@(newTableumber [5].c_str())];
            [xyAssign33 setStringValue:@(newTableumber [6].c_str())];
            [xyAssign32 setStringValue:@(newTableumber [7].c_str())];
            [xyAssign31 setStringValue:@(newTableumber [8].c_str())];
            
            delete [] newTableumber;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Number Must Be Between 1 And 81"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Entered"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)left4:(id)sender{
    if (currentListName != "" && currentListNumber != ""){
        string inputValue = [[xyAssign49 stringValue] UTF8String];
        
        if (atoi(inputValue.c_str()) >= 1 && atoi(inputValue.c_str()) <= 81){
            string *newTableumber = new string [10];
            
            for (int counter1 = 0; counter1 < 9; counter1++) newTableumber [counter1] = "";
            
            int entryCount = 0;
            int inputValueInt = atoi(inputValue.c_str());
            
            for (int counter1 = 0; counter1 < 9; counter1++){
                if (inputValueInt+entryCount <= 81){
                    newTableumber [entryCount] = to_string(inputValueInt+entryCount), entryCount++;
                }
            }
            
            [xyAssign49 setStringValue:@(newTableumber [0].c_str())];
            [xyAssign48 setStringValue:@(newTableumber [1].c_str())];
            [xyAssign47 setStringValue:@(newTableumber [2].c_str())];
            [xyAssign46 setStringValue:@(newTableumber [3].c_str())];
            [xyAssign45 setStringValue:@(newTableumber [4].c_str())];
            [xyAssign44 setStringValue:@(newTableumber [5].c_str())];
            [xyAssign43 setStringValue:@(newTableumber [6].c_str())];
            [xyAssign42 setStringValue:@(newTableumber [7].c_str())];
            [xyAssign41 setStringValue:@(newTableumber [8].c_str())];
            
            delete [] newTableumber;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Number Must Be Between 1 And 81"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Entered"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)left5:(id)sender{
    if (currentListName != "" && currentListNumber != ""){
        string inputValue = [[xyAssign59 stringValue] UTF8String];
        
        if (atoi(inputValue.c_str()) >= 1 && atoi(inputValue.c_str()) <= 81){
            string *newTableumber = new string [10];
            
            for (int counter1 = 0; counter1 < 9; counter1++) newTableumber [counter1] = "";
            
            int entryCount = 0;
            int inputValueInt = atoi(inputValue.c_str());
            
            for (int counter1 = 0; counter1 < 9; counter1++){
                if (inputValueInt+entryCount <= 81){
                    newTableumber [entryCount] = to_string(inputValueInt+entryCount), entryCount++;
                }
            }
            
            [xyAssign59 setStringValue:@(newTableumber [0].c_str())];
            [xyAssign58 setStringValue:@(newTableumber [1].c_str())];
            [xyAssign57 setStringValue:@(newTableumber [2].c_str())];
            [xyAssign56 setStringValue:@(newTableumber [3].c_str())];
            [xyAssign55 setStringValue:@(newTableumber [4].c_str())];
            [xyAssign54 setStringValue:@(newTableumber [5].c_str())];
            [xyAssign53 setStringValue:@(newTableumber [6].c_str())];
            [xyAssign52 setStringValue:@(newTableumber [7].c_str())];
            [xyAssign51 setStringValue:@(newTableumber [8].c_str())];
            
            delete [] newTableumber;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Number Must Be Between 1 And 81"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Entered"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)left6:(id)sender{
    if (currentListName != "" && currentListNumber != ""){
        string inputValue = [[xyAssign69 stringValue] UTF8String];
        
        if (atoi(inputValue.c_str()) >= 1 && atoi(inputValue.c_str()) <= 81){
            string *newTableumber = new string [10];
            
            for (int counter1 = 0; counter1 < 9; counter1++) newTableumber [counter1] = "";
            
            int entryCount = 0;
            int inputValueInt = atoi(inputValue.c_str());
            
            for (int counter1 = 0; counter1 < 9; counter1++){
                if (inputValueInt+entryCount <= 81){
                    newTableumber [entryCount] = to_string(inputValueInt+entryCount), entryCount++;
                }
            }
            
            [xyAssign69 setStringValue:@(newTableumber [0].c_str())];
            [xyAssign68 setStringValue:@(newTableumber [1].c_str())];
            [xyAssign67 setStringValue:@(newTableumber [2].c_str())];
            [xyAssign66 setStringValue:@(newTableumber [3].c_str())];
            [xyAssign65 setStringValue:@(newTableumber [4].c_str())];
            [xyAssign64 setStringValue:@(newTableumber [5].c_str())];
            [xyAssign63 setStringValue:@(newTableumber [6].c_str())];
            [xyAssign62 setStringValue:@(newTableumber [7].c_str())];
            [xyAssign61 setStringValue:@(newTableumber [8].c_str())];
            
            delete [] newTableumber;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Number Must Be Between 1 And 81"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Entered"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)left7:(id)sender{
    if (currentListName != "" && currentListNumber != ""){
        string inputValue = [[xyAssign79 stringValue] UTF8String];
        
        if (atoi(inputValue.c_str()) >= 1 && atoi(inputValue.c_str()) <= 81){
            string *newTableumber = new string [10];
            
            for (int counter1 = 0; counter1 < 9; counter1++) newTableumber [counter1] = "";
            
            int entryCount = 0;
            int inputValueInt = atoi(inputValue.c_str());
            
            for (int counter1 = 0; counter1 < 9; counter1++){
                if (inputValueInt+entryCount <= 81){
                    newTableumber [entryCount] = to_string(inputValueInt+entryCount), entryCount++;
                }
            }
            
            [xyAssign79 setStringValue:@(newTableumber [0].c_str())];
            [xyAssign78 setStringValue:@(newTableumber [1].c_str())];
            [xyAssign77 setStringValue:@(newTableumber [2].c_str())];
            [xyAssign76 setStringValue:@(newTableumber [3].c_str())];
            [xyAssign75 setStringValue:@(newTableumber [4].c_str())];
            [xyAssign74 setStringValue:@(newTableumber [5].c_str())];
            [xyAssign73 setStringValue:@(newTableumber [6].c_str())];
            [xyAssign72 setStringValue:@(newTableumber [7].c_str())];
            [xyAssign71 setStringValue:@(newTableumber [8].c_str())];
            
            delete [] newTableumber;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Number Must Be Between 1 And 81"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Entered"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)left8:(id)sender{
    if (currentListName != "" && currentListNumber != ""){
        string inputValue = [[xyAssign89 stringValue] UTF8String];
        
        if (atoi(inputValue.c_str()) >= 1 && atoi(inputValue.c_str()) <= 81){
            string *newTableumber = new string [10];
            
            for (int counter1 = 0; counter1 < 9; counter1++) newTableumber [counter1] = "";
            
            int entryCount = 0;
            int inputValueInt = atoi(inputValue.c_str());
            
            for (int counter1 = 0; counter1 < 9; counter1++){
                if (inputValueInt+entryCount <= 81){
                    newTableumber [entryCount] = to_string(inputValueInt+entryCount), entryCount++;
                }
            }
            
            [xyAssign89 setStringValue:@(newTableumber [0].c_str())];
            [xyAssign88 setStringValue:@(newTableumber [1].c_str())];
            [xyAssign87 setStringValue:@(newTableumber [2].c_str())];
            [xyAssign86 setStringValue:@(newTableumber [3].c_str())];
            [xyAssign85 setStringValue:@(newTableumber [4].c_str())];
            [xyAssign84 setStringValue:@(newTableumber [5].c_str())];
            [xyAssign83 setStringValue:@(newTableumber [6].c_str())];
            [xyAssign82 setStringValue:@(newTableumber [7].c_str())];
            [xyAssign81 setStringValue:@(newTableumber [8].c_str())];
            
            delete [] newTableumber;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Number Must Be Between 1 And 81"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Entered"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)left9:(id)sender{
    if (currentListName != "" && currentListNumber != ""){
        string inputValue = [[xyAssign99 stringValue] UTF8String];
        
        if (atoi(inputValue.c_str()) >= 1 && atoi(inputValue.c_str()) <= 81){
            string *newTableumber = new string [10];
            
            for (int counter1 = 0; counter1 < 9; counter1++) newTableumber [counter1] = "";
            
            int entryCount = 0;
            int inputValueInt = atoi(inputValue.c_str());
            
            for (int counter1 = 0; counter1 < 9; counter1++){
                if (inputValueInt+entryCount <= 81){
                    newTableumber [entryCount] = to_string(inputValueInt+entryCount), entryCount++;
                }
            }
            
            [xyAssign99 setStringValue:@(newTableumber [0].c_str())];
            [xyAssign98 setStringValue:@(newTableumber [1].c_str())];
            [xyAssign97 setStringValue:@(newTableumber [2].c_str())];
            [xyAssign96 setStringValue:@(newTableumber [3].c_str())];
            [xyAssign95 setStringValue:@(newTableumber [4].c_str())];
            [xyAssign94 setStringValue:@(newTableumber [5].c_str())];
            [xyAssign93 setStringValue:@(newTableumber [6].c_str())];
            [xyAssign92 setStringValue:@(newTableumber [7].c_str())];
            [xyAssign91 setStringValue:@(newTableumber [8].c_str())];
            
            delete [] newTableumber;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Number Must Be Between 1 And 81"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Entered"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)stepperActionAuto:(id)sender{
    if ([stepperAuto intValue] >= 10 && [stepperAuto intValue] <= 245){
        [autoValueDisplay setIntValue:[stepperAuto intValue]];
        autoValueHold = [stepperAuto intValue];
    }
}

-(IBAction)colorPickMode:(id)sender{
    if (imageLoadStatus == 1 && copyProgressFlag == 0){
        if (colorSelectStatusHold == 0){
            colorSelectStatusHold = 1;
            
            [self imageSlider];
            [colorPickStatusDisplay setStringValue:@"Extract"];
        }
        else if (colorSelectStatusHold == 1){
            colorSelectStatusHold = 0;
            
            [self imageSlider];
            [colorPickStatusDisplay setStringValue:@"Original"];
            
            blurCutHold = 0;
            [blurCutStatusDisplay setStringValue:@"Brightness"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        if (imageLoadStatus != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Data Entered"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Other Processes In Progress"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)blurCutSet:(id)sender{
    if (imageLoadStatus == 1 && copyProgressFlag == 0){
        if (colorSelectStatusHold == 1){
            if (blurCutHold == 0){
                blurCutHold = 1;
                
                [blurCutStatusDisplay setStringValue:@"Blur CutOff"];
            }
            else if (blurCutHold == 1){
                blurCutHold = 0;
                
                [blurCutStatusDisplay setStringValue:@"Brightness"];
            }
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Extract Mode Off"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
            
        }
    }
    else{
        
        if (imageLoadStatus != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Data Entered"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Other Processes In Progress"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)blurRPriority:(id)sender{
    if (imageLoadStatus == 1 && copyProgressFlag == 0){
        if (mergeRStatusHold == 0){
            mergeRStatusHold = 1;
            
            [colorRDisplay setTextColor:[NSColor redColor]];
            [colorRDisplay setStringValue:@"R"];
        }
        else if (mergeRStatusHold == 1){
            mergeRStatusHold = 0;
            
            [colorRDisplay setTextColor:[NSColor blackColor]];
            [colorRDisplay setStringValue:@"R"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        if (imageLoadStatus != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Data Entered"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Other Processes In Progress"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)blurGPriority:(id)sender{
    if (imageLoadStatus == 1 && copyProgressFlag == 0){
        if (mergeGStatusHold == 0){
            mergeGStatusHold = 1;
            
            [colorGDisplay setTextColor:[NSColor greenColor]];
            [colorGDisplay setStringValue:@"G"];
        }
        else if (mergeGStatusHold == 1){
            mergeGStatusHold = 0;
            
            [colorGDisplay setTextColor:[NSColor blackColor]];
            [colorGDisplay setStringValue:@"G"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        if (imageLoadStatus != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Data Entered"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Other Processes In Progress"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)blurBPriority:(id)sender{
    if (imageLoadStatus == 1 && copyProgressFlag == 0){
        if (mergeBStatusHold == 0){
            mergeBStatusHold = 1;
            
            [colorBDisplay setTextColor:[NSColor blueColor]];
            [colorBDisplay setStringValue:@"B"];
        }
        else if (mergeBStatusHold == 1){
            mergeBStatusHold = 0;
            
            [colorBDisplay setTextColor:[NSColor blackColor]];
            [colorBDisplay setStringValue:@"B"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        if (imageLoadStatus != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Data Entered"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Other Processes In Progress"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)mapLoadSet:(id)sender{
    if (imageLoadStatus == 1 && copyProgressFlag == 0){
        if (mapLoadHold == 0){
            mapLoadHold = 1;
            
            [mapLoadDisplay setTextColor:[NSColor redColor]];
            [mapLoadDisplay setStringValue:@"File (Contrast)"];
            
            [mapLoadTitleDisplay setTextColor:[NSColor redColor]];
            [mapLoadTitleDisplay setStringValue:@"Map:"];
        }
        else if (mapLoadHold == 1){
            mapLoadHold = 0;
            
            [mapLoadDisplay setTextColor:[NSColor blackColor]];
            [mapLoadDisplay setStringValue:@"Create (Stitch)"];
            
            [mapLoadTitleDisplay setTextColor:[NSColor blackColor]];
            [mapLoadTitleDisplay setStringValue:@"Map:"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        if (imageLoadStatus != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Data Entered"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Other Processes In Progress"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)displayOrderSet:(id)sender{
    if (imageLoadStatus == 1 && copyProgressFlag == 0){
        if (displayOrderHold == 0){
            displayOrderHold = 1;
            
            [displayOrderDisplay setTextColor:[NSColor redColor]];
            [displayOrderDisplay setStringValue:@"Top (Contrast)"];
            
            [displayOrderTitleDisplay setTextColor:[NSColor redColor]];
            [displayOrderTitleDisplay setStringValue:@"Overlay order:"];
        }
        else if (displayOrderHold == 1){
            displayOrderHold = 0;
            
            [displayOrderDisplay setTextColor:[NSColor blackColor]];
            [displayOrderDisplay setStringValue:@"Maintain (Stitch)"];
            
            [displayOrderTitleDisplay setTextColor:[NSColor blackColor]];
            [displayOrderTitleDisplay setStringValue:@"Overlay order:"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        if (imageLoadStatus != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Data Entered"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Other Processes In Progress"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(void)directoryInfoUpDate{
    string *arrayUpDate = new string [directoryInfoCount+10];
    
    for (int counter1 = 0; counter1 < directoryInfoCount; counter1++) arrayUpDate [counter1] = arrayDirectoryInfo [counter1];
    
    delete [] arrayDirectoryInfo;
    arrayDirectoryInfo = new string [directoryInfoLimit+500];
    directoryInfoLimit = directoryInfoLimit+500;
    
    for (int counter1 = 0; counter1 < directoryInfoCount; counter1++) arrayDirectoryInfo [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)dealloc{
    if (timerCD) [timerCD invalidate];
}

@end
