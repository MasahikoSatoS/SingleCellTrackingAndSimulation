//
//  Controller.h
//  Watson
//
//  Created by Masahiko Sato on 2014-09-29.
//  Copyright 2014 Masahiko Sato. All rights reserved.
//
//

#ifndef CONTROLLER_H
#define CONTROLLER_H
#import <Cocoa/Cocoa.h>
#import "MovieDisplay.h"
#import "ASCIIconversion.h"
#import "ImageFileProcessing.h"
#import "SingleTiffSave.h"
#import "TiffFileRead.h"
#include <iostream>
#include <dirent.h>
#include <sys/stat.h>
#include <fstream>
#include <sstream>
#endif

using namespace std;

extern NSString *notificationToMovieDisplay;

//-----Basic info-----
extern string pathNameString; //Path name
extern string analysisNameHold; //Analysis name
extern string treatNameHold; //Treat name
extern string imageDataPath; //Image data path

//-----Arrays-----
extern string *fileList; //Hold file name
extern int fileListCount;
extern int fileListLimit;
extern string *arrayDirectoryInfo; //Array used for sorting of file names
extern int directoryInfoCount;
extern int directoryInfoLimit;
extern string fileSavePathHold;//Path for Tiff file save
extern int **arrayImageFileSave;//Image array for tif save
extern uint8_t *fileReadArray;//Array holding image data

//-----Basic operation-----
extern string tableListPath;//Hold Table List path
extern int imageLoadStatus; //Set 1 when the first image is loaded
extern double levelHoldContrast; //Process values hold
extern double levelHoldBrightness; //Process values hold
extern double levelHoldBlur; //Process values hold
extern double levelHoldRed; //Process values hold
extern double levelHoldGreen; //Process values hold
extern double levelHoldBlue; //Process values hold
extern double cutRedHold; //Process values hold
extern double cutGreenHold; //Process values hold
extern double cutBlueHold; //Process values hold
extern double levelHoldRedPick; //Process values hold
extern double levelHoldGreenPick; //Process values hold
extern double levelHoldBluePick; //Process values hold
extern double cutRedHoldPick; //Process values hold
extern double cutGreenHoldPick; //Process values hold
extern double cutBlueHoldPick; //Process values hold
extern int tableDisplayCall; //Call for table info display
extern int productDisplayCall; //Call for product info display
extern int progressTiming; //For process timing adjustment
extern int copyProgressFlag; //Copy progress check

extern int initialArraySet; //Set when the initial array is set
extern int imageDimensionH; //Image hight hold
extern int imageDimensionW; //Image width hold
extern int imageBitHold; //Image bit hold
extern int photoMetricsHold; //Image photometric hold
extern int samplePerPixHold; //Image sample per pix hold

//-----Image display-----
extern int stitchedImageDimension; //Hold stitched image dimension
extern int **imageDisplayArray; //Array for image data display
extern int imageDisplayCall; //Call to display image
extern int processingFovNo; //Current FOV no
extern double autoValueHold; //Auto mode Mean value hold
extern int totalRGBHold; //Auto color adjustment mode

//-----List-----
extern string *tableListHold; //Pattern list data
extern int tableListHoldCount;
extern int tableListHoldLimit;
extern string currentListName; //Currently active name
extern string currentListNumber; //Number of files
extern string *currentListInformation; //xy Table data
extern int *imageSetPositionList; //Image xy position hold

//-----Current image-----
extern string currentImageName; //Name of current image
extern int **arrayImageDataHold;//Source Image data array
extern int imageDataHoldStatus;
extern int **arrayImageOriginal; //Original Image data array
extern int **arrayImageResults; //Processed Image data array
extern int imageRangeAdjustStatus;
extern int **imagePositionMap; //Map for each FOV position
extern int *xyPositionData; //Position of each FOV
extern int *xyPositionDataOriginal; //Position of each FOV (Original)
extern int *xyPositionWritingData; //Position of each FOV for writing--position after moving FOVs
extern string imageFLStatus; //Image Lock Free Status
extern int contrastLockRelease; //Contrast Lock Allow status

//-----Others-----
extern string ascIIstring; //To ascII string for int conversion
extern int warningSet; //Warning message set
extern int cursorRedMax; //For RGB range display
extern int cursorGreenMax; //For RGB range display
extern int cursorBlueMax; //For RGB range display
extern int cursorRedMin; //For RGB range display
extern int cursorGreenMin; //For RGB range display
extern int cursorBlueMin; //For RGB range display
extern int colorSelectStatusHold; //Extract Original status hold
extern int rangeDisplayCall; //Call for the range display
extern int colorPickStatusHold; //Color pick status hold
extern int colorPickStatusCall; //Call for color pick status
extern int listModeStatusHold; //Hold list mode status
extern double *listDataHold; //List data hold (for color pick)
extern int listDataCount; //Number of list entry
extern int blurCutHold; //Blur status data
extern int mergeRStatusHold;// For F/V mode, for gray scale image creation, use R G B RG RB GB or RGB
extern int mergeGStatusHold; // For F/V mode, for gray scale image creation, use R G B RG RB GB or RGB
extern int mergeBStatusHold; // For F/V mode, for gray scale image creation, use R G B RG RB GB or RGB
extern int displayOrderHold; //Display order hold

//-----Histogram image Folder-----
//05_Products_Files/AnalysisName_Products/TreatName_Capture/TreatName_0001.tif

//Readable file format, Single layer Tiff, No compression, Gray (8 bit or 16 bit): 0:White will be converted to 0: Black, Handling file format, Gray 8 bit. When an image is saved, the file format will be Gray 8 bit
//RGB (8 or 16 bit) and RGB+Alpha (8 or 16 bit). Handling format is RGB 8 bit no Alpha. When an image is saved, the file format will be RGB, no alpha 8 bit.

//Upload: original files will be copied into Current and Original; Manipulation will be done only for Current, Both format has to be the same
//Table Load: Write Position of images into Current and Original Files. File format will be changed: Gray (0: black) 8 bit, RGB 8 bit (no alpha)

/*
 S: Blur
 Mode has to be Extract.
 Works only for color image
 Blur works for Extracted image.
 When F or V is performed, Blur is cancelled. To apply blur, do it again.
 Blur can be repeated times.
 In the Brightness mode, blue will be performed for R G B separately.
 When Blur cut off is set, cutoff value will be apply. Same cut off value will be applied for R G B. Value below the cut off is 0.
 */

/*
 F/V
 When Peach color button is on, use R, G, B, RG, RB, GB, or RGB value to calculate gray scale value. In the case that RG, RB, GB or RGB is selected, calculate average value of two or three channels.
 When no Peach button is set, generate RGB image.
 */

/*
 B:
 When image Free is set, Mode will be Lock. Contrast of each FOV can be changed, but when image is combined, image contrast parameters will not be applied unless the status is "Allow".
 */

/*
 //-----totalRGBHold
 //-----First determine overall Average value of each RGB channel. Then, determine a difference between the average of each FOV and overall average, or use the Set value.
 //-----Then adding vales of each FOV for each RGB channel are determined.
 //-----0 (Total or FOV, but no FOV mode). Use the Set value to determine the adding value. R value+Set Adding value, G value+Set Adding value, B value+Set Adding value.
 //-----1 (RGB) R value+R Adding value, G value+G Adding value, B value+B Adding value
 //-----2 (R) R value+R Adding value, G value+R Adding value, B value+R Adding value
 //-----3 (G) R value+G Adding value, G value+G Adding value, B value+G Adding value
 //-----4 (B) R value+B Adding value, G value+B Adding value, B value+B Adding value
 //-----5 (RG) R value+average of RG Adding value, G value+average of RG Adding value, B value+average of RG Adding value
 //-----6 (RB) R value+average of RB Adding value, G value+average of RB Adding value, B value+average of RB Adding value
 //-----7 (GB) R value+average of GB Adding value, G value+average of GB Adding value, B value+average of GB Adding value
 
 //-----FOV modes, determine Adding value based on the selected FOV values
 //-----8 (FOV) R value+R (sel) Adding value, G (sel) value+G Adding value, B (sel) value+B Adding value
 
 //-----FOV RGB mode, determine multiplying value based on the selected FOV
 //-----9 (FOVR) R value+R (sel) Multiplying value, G (sel) value+R Multiplying value, B (sel) value+R Multiplying value
 //-----10 (FOVG) R value+G (sel) Multiplying value, G (sel) value+G Multiplying value, B (sel) value+G Multiplying value
 //-----11 (FOVB) R value+B (sel) Multiplying value, G (sel) value+B Multiplying value, B (sel) value+B Multiplying value
 */

@interface Controller : NSObject <NSTextFieldDelegate, NSTableViewDataSource>{
    int treatListCallCount; //List call
    int tableCurrentRowHold; //Table operation
    int rowIndexHold; //Table operation
    int currentNoOfImage; //Current image no
    int sliderStart; //Slider
    int sliderEnd; //Slider
    int mapLoadHold; //Map load
    
    double sliderContrastMax; //Slider
    double sliderContrastMin; //Slider
    double sliderContrastDiff; //Slider
    
    double sliderBrightnessMax; //Slider
    double sliderBrightnessMin; //Slider
    double sliderBrightnessDiff; //Slider
    
    double sliderRedMax; //Slider
    double sliderRedMin; //Slider
    double sliderRedDiff; //Slider
    
    double sliderGreenMax; //Slider
    double sliderGreenMin; //Slider
    double sliderGreenDiff; //Slider
    
    double sliderBlueMax; //Slider
    double sliderBlueMin; //Slider
    double sliderBlueDiff; //Slider
    
    double sliderCutRedMax; //Slider
    double sliderCutRedMin; //Slider
    double sliderCutRedDiff; //Slider
    
    double sliderCutGreenMax; //Slider
    double sliderCutGreenMin; //Slider
    double sliderCutGreenDiff; //Slider
    
    double sliderCutBlueMax; //Slider
    double sliderCutBlueMin; //Slider
    double sliderCutBlueDiff; //Slider
    
    IBOutlet NSTextField *analysisNameDisplay;
    IBOutlet NSTextField *numberOfFilesDisplay;
    IBOutlet NSTextField *fileImageSizeDisplay;
    
    IBOutlet NSTextField *contrastLevel;
    IBOutlet NSTextField *brightnessLevel;
    IBOutlet NSTextField *redLevel;
    IBOutlet NSTextField *redCut;
    IBOutlet NSTextField *greenLevel;
    IBOutlet NSTextField *greenCut;
    IBOutlet NSTextField *blueLevel;
    IBOutlet NSTextField *blueCut;
    
    IBOutlet NSSlider *sliderContrast;
    IBOutlet NSSlider *sliderBrightness;
    IBOutlet NSSlider *sliderRed;
    IBOutlet NSSlider *sliderGreen;
    IBOutlet NSSlider *sliderBlue;
    
    IBOutlet NSSlider *sliderRedCut;
    IBOutlet NSSlider *sliderGreenCut;
    IBOutlet NSSlider *sliderBlueCut;
    
    IBOutlet NSSlider *sliderContrastCircle;
    IBOutlet NSSlider *sliderBrightnessCircle;
    IBOutlet NSSlider *sliderRedCircle;
    IBOutlet NSSlider *sliderGreenCircle;
    IBOutlet NSSlider *sliderBlueCircle;
    
    IBOutlet NSSlider *sliderRedCutCircle;
    IBOutlet NSSlider *sliderGreenCutCircle;
    IBOutlet NSSlider *sliderBlueCutCircle;
    
    IBOutlet NSCell *sliderKnobContrast;
    IBOutlet NSCell *sliderKnobBrightness;
    IBOutlet NSCell *sliderKnobRed;
    IBOutlet NSCell *sliderKnobGreen;
    IBOutlet NSCell *sliderKnobBlue;
    IBOutlet NSCell *sliderKnobRedCut;
    IBOutlet NSCell *sliderKnobGreenCut;
    IBOutlet NSCell *sliderKnobBlueCut;
    
    IBOutlet NSTextField *xyAssign11;
    IBOutlet NSTextField *xyAssign21;
    IBOutlet NSTextField *xyAssign31;
    IBOutlet NSTextField *xyAssign41;
    IBOutlet NSTextField *xyAssign51;
    IBOutlet NSTextField *xyAssign61;
    IBOutlet NSTextField *xyAssign71;
    IBOutlet NSTextField *xyAssign81;
    IBOutlet NSTextField *xyAssign91;
    
    IBOutlet NSTextField *xyAssign12;
    IBOutlet NSTextField *xyAssign22;
    IBOutlet NSTextField *xyAssign32;
    IBOutlet NSTextField *xyAssign42;
    IBOutlet NSTextField *xyAssign52;
    IBOutlet NSTextField *xyAssign62;
    IBOutlet NSTextField *xyAssign72;
    IBOutlet NSTextField *xyAssign82;
    IBOutlet NSTextField *xyAssign92;
    
    IBOutlet NSTextField *xyAssign13;
    IBOutlet NSTextField *xyAssign23;
    IBOutlet NSTextField *xyAssign33;
    IBOutlet NSTextField *xyAssign43;
    IBOutlet NSTextField *xyAssign53;
    IBOutlet NSTextField *xyAssign63;
    IBOutlet NSTextField *xyAssign73;
    IBOutlet NSTextField *xyAssign83;
    IBOutlet NSTextField *xyAssign93;
    
    IBOutlet NSTextField *xyAssign14;
    IBOutlet NSTextField *xyAssign24;
    IBOutlet NSTextField *xyAssign34;
    IBOutlet NSTextField *xyAssign44;
    IBOutlet NSTextField *xyAssign54;
    IBOutlet NSTextField *xyAssign64;
    IBOutlet NSTextField *xyAssign74;
    IBOutlet NSTextField *xyAssign84;
    IBOutlet NSTextField *xyAssign94;
    
    IBOutlet NSTextField *xyAssign15;
    IBOutlet NSTextField *xyAssign25;
    IBOutlet NSTextField *xyAssign35;
    IBOutlet NSTextField *xyAssign45;
    IBOutlet NSTextField *xyAssign55;
    IBOutlet NSTextField *xyAssign65;
    IBOutlet NSTextField *xyAssign75;
    IBOutlet NSTextField *xyAssign85;
    IBOutlet NSTextField *xyAssign95;
    
    IBOutlet NSTextField *xyAssign16;
    IBOutlet NSTextField *xyAssign26;
    IBOutlet NSTextField *xyAssign36;
    IBOutlet NSTextField *xyAssign46;
    IBOutlet NSTextField *xyAssign56;
    IBOutlet NSTextField *xyAssign66;
    IBOutlet NSTextField *xyAssign76;
    IBOutlet NSTextField *xyAssign86;
    IBOutlet NSTextField *xyAssign96;
    
    IBOutlet NSTextField *xyAssign17;
    IBOutlet NSTextField *xyAssign27;
    IBOutlet NSTextField *xyAssign37;
    IBOutlet NSTextField *xyAssign47;
    IBOutlet NSTextField *xyAssign57;
    IBOutlet NSTextField *xyAssign67;
    IBOutlet NSTextField *xyAssign77;
    IBOutlet NSTextField *xyAssign87;
    IBOutlet NSTextField *xyAssign97;
    
    IBOutlet NSTextField *xyAssign18;
    IBOutlet NSTextField *xyAssign28;
    IBOutlet NSTextField *xyAssign38;
    IBOutlet NSTextField *xyAssign48;
    IBOutlet NSTextField *xyAssign58;
    IBOutlet NSTextField *xyAssign68;
    IBOutlet NSTextField *xyAssign78;
    IBOutlet NSTextField *xyAssign88;
    IBOutlet NSTextField *xyAssign98;
    
    IBOutlet NSTextField *xyAssign19;
    IBOutlet NSTextField *xyAssign29;
    IBOutlet NSTextField *xyAssign39;
    IBOutlet NSTextField *xyAssign49;
    IBOutlet NSTextField *xyAssign59;
    IBOutlet NSTextField *xyAssign69;
    IBOutlet NSTextField *xyAssign79;
    IBOutlet NSTextField *xyAssign89;
    IBOutlet NSTextField *xyAssign99;
    
    IBOutlet NSTextField *loadFileNameDisplay;
    IBOutlet NSTextField *loadFileNumberDisplay;
    IBOutlet NSTextField *autoValueDisplay;
    
    IBOutlet NSTextField *rRangeDisplay;
    IBOutlet NSTextField *gRangeDisplay;
    IBOutlet NSTextField *bRangeDisplay;
    IBOutlet NSTextField *colorPickStatusDisplay;
    IBOutlet NSTextField *totalPixDisplay;
    IBOutlet NSTextField *blurCutStatusDisplay;
    
    IBOutlet NSTextField *colorRDisplay;
    IBOutlet NSTextField *colorGDisplay;
    IBOutlet NSTextField *colorBDisplay;
    
    IBOutlet NSTextField *contrastSetLockDisplay;
    IBOutlet NSTextField *mapLoadDisplay;
    IBOutlet NSTextField *displayOrderDisplay;
    IBOutlet NSTextField *mapLoadTitleDisplay;
    IBOutlet NSTextField *displayOrderTitleDisplay;
    
    IBOutlet NSWindow *controllerWindow;
    IBOutlet NSBrowser *listBrowser;
    
    IBOutlet NSTableView *tableList;
    
    IBOutlet NSProgressIndicator *backSave;
    IBOutlet NSStepper *stepperAuto;
    
    id ascIIconversion;
    id singleTiffSave;
    id tiffFileRead;
    
    NSTimer *timerCD;
}

-(id)init;
-(void)dealloc;

-(void)display;
-(void)imageSlider;

-(void)directoryInfoUpDate;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;
-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex;

-(IBAction)quitProcess:(id)sender;
-(IBAction)tableReload:(id)sender;
-(IBAction)colorPickMode:(id)sender;

-(IBAction)browserDoubleClick:(id)browser;

-(IBAction)sliderLevelContrast:(id)sender;
-(IBAction)sliderLevelBrightness:(id)sender;
-(IBAction)sliderRed:(id)sender;
-(IBAction)sliderRedCut:(id)sender;
-(IBAction)sliderGreen:(id)sender;
-(IBAction)sliderGreenCut:(id)sender;
-(IBAction)sliderBlue:(id)sender;
-(IBAction)sliderBlueCut:(id)sender;

-(IBAction)sliderContrastCircle:(id)sender;
-(IBAction)sliderBrightnessCircle:(id)sender;
-(IBAction)sliderRedCircle:(id)sender;
-(IBAction)sliderRedCutCircle:(id)sender;
-(IBAction)sliderGreenCircle:(id)sender;
-(IBAction)sliderGreenCutCircle:(id)sender;
-(IBAction)sliderBlueCircle:(id)sender;
-(IBAction)sliderBlueCutCircle:(id)sender;

-(IBAction)resetContrast:(id)sender;
-(IBAction)resetBrightness:(id)sender;
-(IBAction)resetRed:(id)sender;
-(IBAction)resetGreen:(id)sender;
-(IBAction)resetBlue:(id)sender;
-(IBAction)resetRGB:(id)sender;
-(IBAction)blurCutSet:(id)sender;
-(IBAction)blurRPriority:(id)sender;
-(IBAction)blurGPriority:(id)sender;
-(IBAction)blurBPriority:(id)sender;
-(IBAction)reLoadOriginal:(id)sender;

-(IBAction)clearTable:(id)sender;
-(IBAction)saveTable:(id)sender;
-(IBAction)stepperActionAuto:(id)sender;
-(IBAction)mapLoadSet:(id)sender;
-(IBAction)displayOrderSet:(id)sender;

-(IBAction)up1:(id)sender;
-(IBAction)up2:(id)sender;
-(IBAction)up3:(id)sender;
-(IBAction)up4:(id)sender;
-(IBAction)up5:(id)sender;
-(IBAction)up6:(id)sender;
-(IBAction)up7:(id)sender;
-(IBAction)up8:(id)sender;
-(IBAction)up9:(id)sender;

-(IBAction)down1:(id)sender;
-(IBAction)down2:(id)sender;
-(IBAction)down3:(id)sender;
-(IBAction)down4:(id)sender;
-(IBAction)down5:(id)sender;
-(IBAction)down6:(id)sender;
-(IBAction)down7:(id)sender;
-(IBAction)down8:(id)sender;
-(IBAction)down9:(id)sender;

-(IBAction)right1:(id)sender;
-(IBAction)right2:(id)sender;
-(IBAction)right3:(id)sender;
-(IBAction)right4:(id)sender;
-(IBAction)right5:(id)sender;
-(IBAction)right6:(id)sender;
-(IBAction)right7:(id)sender;
-(IBAction)right8:(id)sender;
-(IBAction)right9:(id)sender;

-(IBAction)left1:(id)sender;
-(IBAction)left2:(id)sender;
-(IBAction)left3:(id)sender;
-(IBAction)left4:(id)sender;
-(IBAction)left5:(id)sender;
-(IBAction)left6:(id)sender;
-(IBAction)left7:(id)sender;
-(IBAction)left8:(id)sender;
-(IBAction)left9:(id)sender;

@end
