//
//  TerminationMonitor.m
//  Data_BackUp
//
//  Created by Masahiko Sato on 2014-05-25.
//
//

#import "TerminationMonitor.h"

NSString *notificationToTermination = @"notificationExecuteTermination";

@implementation TerminationMonitor

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToTermination object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    commTimer = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(processControl) userInfo:nil repeats:YES];
}

-(void)processControl{
    NSString *activeProcess;
    
    int mainControllerActive = 1;
    
    for (NSRunningApplication *currApp in [[NSWorkspace sharedWorkspace] runningApplications]) {
        activeProcess = [currApp localizedName];
        
        if ([activeProcess isEqualToString:@"Imaging_Controller"]) mainControllerActive = 2;
    }
    
    if (mainControllerActive == 1){
        delete [] arrayBackUpInfo;
        delete [] arrayTableDisplay;
        delete [] arrayFileName;
        delete [] arrayFileDelete;
        
        exit (0);
    }
}

-(void)dealloc{
    if (commTimer) [commTimer invalidate];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToTermination object:nil];
}

@end
