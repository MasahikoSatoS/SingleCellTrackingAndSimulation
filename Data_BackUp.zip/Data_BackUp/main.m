//
//  main.m
//  Data_BackUp
//
//  Created by Masahiko Sato on 14/04/07.
//  Copyright Masahiko Sato 2014. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[]){
    return NSApplicationMain(argc, (const char **) argv);
}
