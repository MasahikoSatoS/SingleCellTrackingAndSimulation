//
//  Controller.h
//  Data_BackUp
//
//  Created by Masahiko Sato on 2014-05-24.
//  Copyright Masahiko Sato 2014 All rights reserved.
//
//

#ifndef CONTROLLER_H
#define CONTROLLER_H
#import <Cocoa/Cocoa.h>
#import "TerminationMonitor.h"
#include <iostream>
#include <dirent.h>
#include <sys/stat.h>
#include <fstream>
#include <sstream>
#endif

using namespace std;

extern NSString *notificationToTermination;

//------Arrays-------
extern string *arrayBackUpInfo; //Info read from Backup Results
extern int backUpInfoCount;
extern string *arrayTableDisplay; //Array for table display
extern int tableDisplayCount;
extern string *arrayFileName; //Array for back-up file name holding-
extern int fileNameCount;
extern int fileNameLimit;
extern string *arrayFileDelete; //Array for file order arrange or delete
extern int fileDeleteCount;
extern int fileDeleteLimit;

@interface Controller : NSObject <NSTableViewDataSource> {
    int tableViewCall; //Table operation
    int tableCallCount; //Table operation
    int rowIndexHold; //Table operation
    int tableCurrentRowHold; //Table operation
    int initialArraySet; //First time array set check
    int processStartFlag; //On when Process start is pressed
    int backupStartFlag; //On when folder is found
    int holdFlag; //Hold status
    int backUpCopyFlag; //Backup flag
    int incrementCount; //Increment count
    int incrementSize; //Increment size
    int exitFlag; //Exit flag
    int forceCompletionFlag; //Set when current folder is closed before it get full
    int lastPickUpFolder; //Last processed folder no
    int saveFolderNo; //Save folder No
    int progressValue; //Hold Progress indicator value
    int progressTiming; //Hold Progress indicator timing
    int cleaningProgress; //Cleaning progress status
    
    //------Basic info------
    string pathNameString;//Path name
    string bodyName; //Body name
    string userID; //user ID
    
    //------Paths-------
    string basicInfoPath; //BK path
    string backUpFolderPath; //BFK folder
    string messagePath; //Message path
    string destinationFolderPath; //Destination path
    
    //------Basic operation------
    string folderKeep; //Folder keep/delete status hold
    string saveFolderName; //Save folder name
    string processFolderName; //Procession folder name
    string backupStartNo; //Back up start
    string backupEndNo; //Back up end
    string saveNoString; //Save no
    string backupDirectory; //Back up directory
    string backupFolderNo; //Back up folder no
    string directoryStatus; //Directory status hold
    unsigned long totalFileSize; //Total file size
    
    IBOutlet NSTextField *analysisName;
    IBOutlet NSTextField *backUpFolderDisplay;
    IBOutlet NSTextField *startStatus;
    IBOutlet NSTextField *keepOnOff;
    IBOutlet NSTextField *completionDisplay;
    
    IBOutlet NSTableView *tableViewList;
    IBOutlet NSWindow *controllerWindow;
    
    IBOutlet NSProgressIndicator *progressIndicator;
    
    NSTimer *timerBK;
}

-(id)init;
-(void)dealloc;
-(void)display;
-(void)processStopSub;
-(void)backUpMain;
-(void)fileDeleteUpDate;
-(void)backUpAlreadyCleanMain;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;
-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex;

-(IBAction)quitProcess:(id)sender;
-(IBAction)startProcess:(id)sender;
-(IBAction)folderKeepControl:(id)sender;
-(IBAction)backUpAlreadyClean:(id)sender;
-(IBAction)forcedCompletion:(id)sender;

@end
