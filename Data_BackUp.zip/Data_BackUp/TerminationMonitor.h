//
//  TerminationMonitor.h
//  Data_BackUp
//
//  Created by Masahiko Sato on 2014-05-25.
//  Copyright Masahiko Sato 2014 All rights reserved.
//
//

#ifndef TERMINATIONMONITOR_H
#define TERMINATIONMONITOR_H
#import "Controller.h"
#endif

@interface TerminationMonitor : NSObject {
    NSTimer *commTimer;
}

-(id)init;
-(void)dealloc;
-(void)processControl;

@end
