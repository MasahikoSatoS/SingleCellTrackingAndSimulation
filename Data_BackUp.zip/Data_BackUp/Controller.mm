//
//  Controller.m
//  Data_BackUp
//
//  Created by Masahiko Sato on 2014-05-24.
//
//

#import "Controller.h"

string *arrayBackUpInfo;
int backUpInfoCount;
string *arrayTableDisplay;
int tableDisplayCount;
string *arrayFileName;
int fileNameCount;
int fileNameLimit;
string *arrayFileDelete;
int fileDeleteCount;
int fileDeleteLimit;

@implementation Controller

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSString *currentDirectoryPathNSString = [[NSBundle mainBundle] bundlePath];
        string userPathNameString = [currentDirectoryPathNSString cStringUsingEncoding:NSUTF8StringEncoding];
        
        if (userPathNameString.length() == 0) exit (0);
        else if ((int)userPathNameString.find("/Users/") == -1) exit (0);
        else{
            
            string pathName2 = userPathNameString.substr((unsigned long)userPathNameString.find("/Users/")+7);
            pathNameString = pathName2.substr(0, (unsigned long)pathName2.find("/"));
        }
        
        tableViewCall = 0;
        tableCallCount = 0;
        rowIndexHold = 0;
        tableCurrentRowHold = 0;
        initialArraySet = 0;
        processStartFlag = 0;
        backupStartFlag = 0;
        holdFlag = 0;
        backUpCopyFlag = 0;
        exitFlag = 0;
        forceCompletionFlag = 0;
        progressValue = 0;
        progressTiming = 0;
        
        cleaningProgress = 0;
    }
    
    return self;
}

-(void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat xLength = screenRect.size.width;
    CGFloat yLength = screenRect.size.height;
    
    int mainControllerX = 800;
    
    NSRect windowSize = [controllerWindow frame];
    CGFloat windowWidth = windowSize.size.width;
    CGFloat windowHeight = windowSize.size.height;
    
    int displayPositionType = 0;
    
    if (80+mainControllerX+5+windowWidth+5+80 > xLength) displayPositionType = 1;
    
    CGFloat displayX;
    
    if (displayPositionType == 1) displayX = 550;
    else displayX = 80+mainControllerX+5;
    
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [controllerWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    [tableViewList setDataSource:self];
    
    for (NSTableColumn* column in [tableViewList tableColumns]) {
        if ([[column identifier] isEqualToString:@"COL1"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"Directory Path" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL2"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"No." attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL3"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"First" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL4"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"Last" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL5"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"Status" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
    }
}

-(void)applicationDidFinishLaunching:(NSNotification*)notification{
    basicInfoPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/BKBasic";
    backUpFolderPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"04_BackUp_Folder";
    messagePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/BKData";
    
    string analysisDataPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/AnalysisSetting";
    
    string getString;
    
    ifstream fin;
    fin.open(analysisDataPath.c_str(),ios::in);
    
    if (fin.is_open()){
        getline(fin, getString), bodyName = getString;
        getline(fin, getString);
        getline(fin, getString);
        getline(fin, getString), userID = getString;
        
        fin.close();
    }
    
    if ((int)bodyName.find("IF") != -1){
        if (bodyName.substr(bodyName.length()-2) == "IF"){
            bodyName = bodyName.substr(0, bodyName.length()-2);
        }
    }
    
    fin.open(basicInfoPath.c_str(),ios::in);
    
    if (fin.is_open()){
        getline(fin, getString), lastPickUpFolder = atoi(getString.c_str());
        getline(fin, getString), folderKeep = getString;
        getline(fin, getString), saveFolderNo = atoi(getString.c_str());
        fin.close();
    }
    else{
        
        lastPickUpFolder = 0;
        folderKeep = "Yes";
        saveFolderNo = 0;
        
        ofstream oin;
        oin.open(basicInfoPath.c_str(), ios::out);
        oin<<lastPickUpFolder<<endl;
        oin<<folderKeep<<endl;
        oin<<saveFolderNo<<endl;
        oin.close();
    }
    
    //cout<<lastPickUpFolder<<" "<<folderKeep<<" "<<saveFolderNo<<" folder"<<endl;
    
    [analysisName setStringValue:@(bodyName.c_str())];
    [backUpFolderDisplay setIntegerValue: lastPickUpFolder];
    [keepOnOff setStringValue:@(folderKeep.c_str())];
    
    arrayBackUpInfo = new string [200];
    backUpInfoCount = 0;
    
    string backUpPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/BackUpResults";
    
    fin.open(backUpPath.c_str(),ios::in);
    
    if (fin.is_open()){
        getline(fin, getString);
        getline(fin, getString), saveFolderName = getString;
        
        do{
            
            getline(fin, getString);
            
            if (getString != "" && backUpInfoCount < 200) arrayBackUpInfo [backUpInfoCount] = getString, backUpInfoCount++;
        } while (getString != "");
        
        fin.close();
    }
    
    //for (int counterA = 0; counterA < backUpInfoCount/2; counterA++){
    //    cout<<arrayBackUpInfo [counterA*2]<<" "<<arrayBackUpInfo [counterA*2+1]<<" BK info"<<endl;
    //}
    
    arrayTableDisplay = new string [backUpInfoCount*3+2];
    tableDisplayCount = 0;
    
    string dataTemp;
    string dataTemp2;
    string folderNo;
    string startNo;
    string endNo;
    string status;
    
    for (int counter1 = 0; counter1 <  backUpInfoCount/2; counter1++){
        dataTemp = arrayBackUpInfo [counter1*2];
        dataTemp2 = arrayBackUpInfo [counter1*2+1];
        
        folderNo = dataTemp2.substr(dataTemp2.find("N: ")+3, dataTemp2.find("F: ")-dataTemp2.find("N: ")-5);
        startNo = dataTemp2.substr(dataTemp2.find("F: ")+3, dataTemp2.find("L: ")-dataTemp2.find("F: ")-5);
        endNo = dataTemp2.substr(dataTemp2.find("L: ")+3, dataTemp2.find("S: ")-dataTemp2.find("L: ")-5);
        status = dataTemp2.substr(dataTemp2.find("S: ")+3, 1);
        
        arrayTableDisplay [tableDisplayCount] = dataTemp, tableDisplayCount++;
        arrayTableDisplay [tableDisplayCount] = folderNo, tableDisplayCount++;
        arrayTableDisplay [tableDisplayCount] = startNo, tableDisplayCount++;
        arrayTableDisplay [tableDisplayCount] = endNo, tableDisplayCount++;
        arrayTableDisplay [tableDisplayCount] = status, tableDisplayCount++;
    }
    
    //for (int counterA = 0; counterA < tableDisplayCount/5; counterA++){
    //    cout<<arrayTableDisplay [counterA*5]<<" "<<arrayTableDisplay [counterA*5+1]<<" "<<arrayTableDisplay [counterA*5+2]<<" "<<arrayTableDisplay [counterA*5+3]<<" "<<arrayTableDisplay [counterA*5+4]<<" arrayTableDisplay"<<endl;
    //}
    
    arrayFileName = new string [500];
    fileNameCount = 0;
    fileNameLimit = 500;
    arrayFileDelete = new string [100];
    fileDeleteCount = 0;
    fileDeleteLimit = 100;
    
    initialArraySet = 1;
    tableViewCall = 1;
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTermination object:self];
    timerBK = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(display) userInfo:nil repeats:YES];
}

-(void)display{
    if (tableViewCall == 1){
        tableViewCall = 0;
        [tableViewList reloadData];
    }
    
    if (tableCallCount == 1){
        tableCallCount = 0;
        rowIndexHold = tableCurrentRowHold;
    }
    
    if (tableCallCount > 1) tableCallCount = 0;
    
    if (processStartFlag == 1 && backupStartFlag == 0){
        string timeString = to_string(lastPickUpFolder+1);
        
        if (timeString.length() == 1) timeString = "-1000"+timeString;
        else if (timeString.length() == 2) timeString = "-100"+timeString;
        else if (timeString.length() == 3) timeString = "-10"+timeString;
        else if (timeString.length() == 4) timeString = "-1"+timeString;
        
        processFolderName = bodyName+timeString;
        
        DIR *dir;
        struct dirent *dent;
        
        dir = opendir(backUpFolderPath.c_str());
        
        if (dir != NULL){
            string entry;
            int findFlag = 0;
            
            while((dent = readdir(dir))){
                entry = dent -> d_name;
                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                    if (entry == processFolderName) findFlag = 1;
                }
            }
            
            closedir(dir);
            
            if (findFlag == 1) backupStartFlag = 1;
            else if (findFlag == 0){
                if (holdFlag == 1) {
                    if (forceCompletionFlag == 1){
                        forceCompletionFlag = 0;
                        
                        arrayTableDisplay [rowIndexHold*5+4] = "C";
                        
                        ofstream oin;
                        oin.open(messagePath.c_str(), ios::out);
                        
                        oin<<backupDirectory<<endl;
                        oin<<backupFolderNo<<endl;
                        oin<<backupStartNo<<endl;
                        oin<<backupEndNo<<endl;
                        oin<<"C"<<endl;
                        oin.close();
                        
                        [completionDisplay setStringValue:@"nil"];
                        tableViewCall = 1;
                    }
                    
                    processStartFlag = 0;
                    holdFlag = 0;
                    [startStatus setStringValue:@"Hold"];
                }
                if (exitFlag == 1){
                    processStartFlag = 0;
                    exitFlag = 2;
                }
            }
        }
    }
    else if (backupStartFlag == 1){
        backupStartFlag =2;
        [backUpFolderDisplay setIntegerValue:lastPickUpFolder+1];
    }
    else if (backupStartFlag == 2){
        backupStartFlag = 3;
        
        ifstream fin;
        fin.open(messagePath.c_str(),ios::in);
        
        if (fin.is_open()){
            backupStartFlag = 0;
            fin.close();
        }
        else [self backUpMain];
    }
    else if (backupStartFlag == 4){
        if (exitFlag == 1){
            processStartFlag = 0;
            exitFlag = 2;
        }
        else if (holdFlag == 1){
            if (forceCompletionFlag == 1){
                forceCompletionFlag = 0;
                
                arrayTableDisplay [rowIndexHold*5+4] = "C";
                
                ofstream oin;
                oin.open(messagePath.c_str(), ios::out);
                
                oin<<backupDirectory<<endl;
                oin<<backupFolderNo<<endl;
                oin<<backupStartNo<<endl;
                oin<<backupEndNo<<endl;
                oin<<"C"<<endl;
                oin.close();
                
                [completionDisplay setStringValue:@"nil"];
                tableViewCall = 1;
            }
            
            processStartFlag = 0;
            holdFlag = 0;
            [startStatus setStringValue:@"Hold"];
        }
        else backupStartFlag = 0;
    }
    
    if (backUpCopyFlag == 1){
        backUpCopyFlag= 2;
        incrementSize = 0;
        incrementCount = 0;
        
        progressValue = fileNameCount;
        progressTiming = 1;
    }
    else if (backUpCopyFlag == 2){
        string sourcePathName = backUpFolderPath+"/"+processFolderName;
        
        if (fileNameCount > incrementCount){
            string entry = arrayFileName [incrementCount];
            string pathName2 = sourcePathName+"/"+entry;
            string pathNameB2 = destinationFolderPath+"/"+entry;
            
            struct stat sizeOfFile;
            
            long sizeForCopy = 0;
            
            if (stat(pathName2.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
                
                ifstream infile (pathName2.c_str(), ifstream::binary);
                ofstream outfile (pathNameB2.c_str(), ofstream::binary);
                
                char* buffer = new char[sizeForCopy];
                infile.read (buffer, sizeForCopy);
                outfile.write (buffer, sizeForCopy);
                delete[] buffer;
                
                outfile.close();
                infile.close();
                
                incrementCount++;
                
                progressValue = incrementCount;
                progressTiming = 3;
            }
        }
        else{
            
            progressTiming = 5;
            
            if (folderKeep == "No"){
                fileDeleteCount = 0;
                
                DIR *dir;
                struct dirent *dent;
                
                dir = opendir(sourcePathName.c_str());
                
                if (dir != NULL){
                    string entry;
                    string pathName2;
                    
                    while((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                        arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                    }
                    
                    closedir(dir);
                    
                    for(int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                        entry = arrayFileDelete [counter1];
                        
                        pathName2 = sourcePathName+"/"+entry;
                        remove (pathName2.c_str());
                    }
                    
                    rmdir (sourcePathName.c_str());
                }
            }
            
            lastPickUpFolder++;
            
            if (backupStartNo == "nil"){
                saveNoString = to_string(lastPickUpFolder);
                
                backupStartNo = saveNoString;
                backupEndNo = saveNoString;
            }
            else{
                
                saveNoString = to_string(lastPickUpFolder);
                backupEndNo = saveNoString;
            }
            
            for (int counter1 = 0; counter1 < tableDisplayCount/5; counter1++){
                if (arrayTableDisplay [counter1*5] == backupDirectory){
                    arrayTableDisplay [counter1*5+1] = backupFolderNo;
                    arrayTableDisplay [counter1*5+2] = backupStartNo;
                    arrayTableDisplay [counter1*5+3] = backupEndNo;
                    arrayTableDisplay [counter1*5+4] = directoryStatus;
                    break;
                }
            }
            
            ofstream oin;
            
            oin.open(basicInfoPath.c_str(), ios::out);
            oin<<lastPickUpFolder<<endl;
            oin<<folderKeep<<endl;
            oin<<saveFolderNo<<endl;
            oin.close();
            
            oin.open(messagePath.c_str(), ios::out);
            
            oin<<backupDirectory<<endl;
            oin<<backupFolderNo<<endl;
            oin<<backupStartNo<<endl;
            oin<<backupEndNo<<endl;
            oin<<"O"<<endl;
            oin.close();
            
            backUpCopyFlag = 0;
            backupStartFlag = 4;
            tableViewCall = 1;
        }
    }
    
    if (progressTiming == 1){
        [progressIndicator setMinValue:0];
        [progressIndicator setMaxValue:progressValue];
        [progressIndicator startAnimation:self];
        [progressIndicator setHidden:NO];
        
        double bValue = [progressIndicator maxValue];
        
        if (progressIndicator){
            if (bValue == progressValue){
                progressTiming = 2;
            }
        }
    }
    else if (progressTiming == 3){
        [progressIndicator setDoubleValue:progressValue];
        [progressIndicator displayIfNeeded];
        
        double bValue = [progressIndicator doubleValue];
        
        if (bValue == progressValue){
            progressTiming = 4;
        }
    }
    else if (progressTiming == 5){
        [progressIndicator setDoubleValue:0];
        [progressIndicator displayIfNeeded];
        
        double bValue = [progressIndicator doubleValue];
        
        if (bValue == 0){
            [progressIndicator stopAnimation:self];
            
            if (!progressIndicator){
                progressTiming = 0;
            }
        }
    }
    
    if (exitFlag == 2)[self processStopSub];
}

-(int)numberOfRowsInTableView:(NSTableView *)aTableView{
    int tableViewContent = tableDisplayCount/5;
    return tableViewContent;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    NSAttributedString *attrStr;
    
    if (initialArraySet == 1){
        string displayData1 = arrayTableDisplay [rowIndex*5];
        string displayData2 = arrayTableDisplay [rowIndex*5+1];
        string displayData3 = arrayTableDisplay [rowIndex*5+2];
        string displayData4 = arrayTableDisplay [rowIndex*5+3];
        string displayData5 = arrayTableDisplay [rowIndex*5+4];
        
        if (displayData5 == "O") displayData5 = "Open";
        else displayData5 = "Comp.";
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        
        [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
        [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]){
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]){
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData2.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL3"]){
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData3.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL4"]){
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData4.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL5"]){
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData5.c_str()) attributes:attributes];
        }
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    else{
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL3"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL4"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL5"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    
    return attrStr;
}

-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex{
    tableCallCount++;
    
    if (tableCallCount == 2) tableCurrentRowHold = rowIndexHold;
    else if (tableCallCount == 1) tableCurrentRowHold = rowIndex;
    
    return YES;
}

-(IBAction)forcedCompletion:(id)sender{
    if (cleaningProgress == 0){
        if (tableDisplayCount != 0){
            string statusRead = arrayTableDisplay [rowIndexHold*5+4];
            
            if (statusRead == "C"){
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Folders have been closed"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
            else {
                
                if (processStartFlag == 1){
                    [completionDisplay setStringValue:@"Wait"];
                    forceCompletionFlag = 1;
                }
                else{
                    
                    forceCompletionFlag = 0;
                    arrayTableDisplay [rowIndexHold*5+4] = "C";
                    
                    ofstream oin;
                    oin.open(messagePath.c_str(), ios::out);
                    
                    oin<<backupDirectory<<endl;
                    oin<<backupFolderNo<<endl;
                    oin<<backupStartNo<<endl;
                    oin<<backupEndNo<<endl;
                    oin<<"C"<<endl;
                    oin.close();
                    
                    tableViewCall = 1;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
            }
            
            tableViewCall = 1;
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Backup folder: under the deletion"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)startProcess:(id)sender{
    if (cleaningProgress == 0){
        if (processStartFlag == 0){
            processStartFlag = 1;
            backupStartFlag = 0;
            [startStatus setStringValue:@"On"];
        }
        else if (processStartFlag == 1){
            holdFlag = 1;
            [startStatus setStringValue:@"Wait"];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Backup folders: under the deletion"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)folderKeepControl:(id)sender{
    if (folderKeep == "No") folderKeep = "Yes";
    else if (folderKeep == "Yes") folderKeep = "No";
    
    [keepOnOff setStringValue:@(folderKeep.c_str())];
    
    ofstream oin;
    oin.open(basicInfoPath.c_str(), ios::out);
    oin<<lastPickUpFolder<<endl;
    oin<<folderKeep<<endl;
    oin<<saveFolderNo<<endl;
    oin.close();
}

-(void)backUpMain{
    backupDirectory = "";
    backupFolderNo = "";
    backupStartNo = "";
    backupEndNo = "";
    directoryStatus = "";
    
    for (int counter1 = 0; counter1 < tableDisplayCount/5; counter1++){
        directoryStatus = arrayTableDisplay [counter1*5+4];
        
        if (directoryStatus == "O"){
            backupDirectory = arrayTableDisplay [counter1*5];
            backupFolderNo = arrayTableDisplay [counter1*5+1];
            backupStartNo = arrayTableDisplay [counter1*5+2];
            backupEndNo = arrayTableDisplay [counter1*5+3];
            
            break;
        }
    }
    
    if (backupDirectory != ""){
        ifstream fin;
        fin.open(backupDirectory.c_str(),ios::in);
        
        if (fin.is_open()){
            fin.close();
            
            string directryPath2 = backupDirectory;
            string sizeCheckPathTemp = "";
            string stringExtract;
            string sizeCheckPath;
            
            int entryCount = 0;
            int terminationFlag = 0;
            
            do{
                
                terminationFlag = 1;
                
                if ((int)directryPath2.find("/") != -1){
                    stringExtract = directryPath2.substr(0, directryPath2.find("/"));
                    directryPath2 = directryPath2.substr(directryPath2.find("/")+1);
                    
                    if (entryCount != 3) sizeCheckPathTemp = sizeCheckPathTemp+stringExtract+"/", entryCount++;
                }
                else{
                    
                    if (entryCount == 2) sizeCheckPathTemp = sizeCheckPathTemp+directryPath2;
                    
                    terminationFlag = 0;
                }
                
            } while (terminationFlag == 1);
            
            if ((int)sizeCheckPathTemp.find("Volumes") != -1) sizeCheckPath = sizeCheckPathTemp;
            else sizeCheckPath = "/";
            
            DIR *dir;
            struct dirent *dent;
            DIR *dir2;
            struct dirent *dent2;
            
            fin.open(sizeCheckPath.c_str(),ios::in);
            
            if (fin.is_open()){
                fin.close();
                
                destinationFolderPath = backupDirectory+"/"+saveFolderName+"_"+userID+backupFolderNo+"/"+processFolderName;
                
                fin.open(destinationFolderPath.c_str(),ios::in);
                
                if (fin.is_open()){
                    fin.close();
                    
                    dir = opendir(destinationFolderPath.c_str());
                    fileDeleteCount = 0;
                    
                    if (dir != NULL){
                        string entry;
                        string entry2;
                        string pathName2;
                        string pathName3;
                        
                        while((dent = readdir(dir))){
                            entry = dent -> d_name;
                            pathName2 = destinationFolderPath+"/"+entry;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                dir2 = opendir(pathName2.c_str());
                                
                                if (dir2 != NULL){
                                    while((dent2 = readdir(dir2))){
                                        entry2 = dent2 -> d_name;
                                        
                                        if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                        arrayFileDelete [fileDeleteCount] = pathName2+"/"+entry2, fileDeleteCount++;
                                    }
                                    
                                    closedir(dir2);
                                }
                            }
                        }
                        
                        closedir(dir);
                        
                        for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                            remove (arrayFileDelete [counter1].c_str());
                        }
                    }
                    
                    fileDeleteCount = 0;
                    
                    dir = opendir(destinationFolderPath.c_str());
                    
                    if (dir != NULL){
                        string entry;
                        string pathName2;
                        
                        while((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                            arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                        }
                        
                        closedir(dir);
                        
                        for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                            pathName2 = destinationFolderPath+"/"+arrayFileDelete [counter1];
                            remove (pathName2.c_str());
                            rmdir (pathName2.c_str());
                        }
                    }
                    
                    rmdir (destinationFolderPath.c_str());
                }
                
                string sourcePathName = backUpFolderPath+"/"+processFolderName;
                
                totalFileSize = 0;
                
                dir = opendir(sourcePathName.c_str());
                
                if (dir != NULL){
                    string entry;
                    string pathName2;
                    long sizeForCopy = 0;
                    
                    struct stat sizeOfFile;
                    
                    while((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            pathName2 = sourcePathName+"/"+entry;
                            
                            if (stat(pathName2.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                totalFileSize = totalFileSize+(unsigned long)sizeForCopy;
                            }
                        }
                    }
                    
                    closedir(dir);
                    
                    NSDictionary *dicVol = [[NSFileManager defaultManager] attributesOfFileSystemForPath: @(sizeCheckPath.c_str()) error:nil];
                    unsigned long freeSize = [[dicVol objectForKey: NSFileSystemFreeSize] unsignedLongLongValue];
                    unsigned long refSize = (unsigned long)totalFileSize+1048576000; //-------1Gb---------
                    
                    if (freeSize > refSize){
                        if (backupFolderNo == "nil"){
                            saveFolderNo++;
                            saveNoString = to_string(saveFolderNo);
                            
                            backupFolderNo = saveNoString;
                            
                            destinationFolderPath = backupDirectory+"/"+saveFolderName+"_"+userID+saveNoString+"/"+processFolderName;
                            string newFolderPath = backupDirectory+"/"+saveFolderName+"_"+userID+saveNoString+"/";
                            
                            mkdir(newFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                        }
                        
                        mkdir(destinationFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                        
                        fileNameCount = 0;
                        
                        dir = opendir(sourcePathName.c_str());
                        
                        if (dir != NULL){
                            while((dent = readdir(dir))){
                                entry = dent -> d_name;
                                
                                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                    if (fileNameCount+5 > fileNameLimit){
                                        string *arrayUpDate = new string [fileNameCount+10];
                                        
                                        for (int counter1 = 0; counter1 < fileNameCount; counter1++) arrayUpDate [counter1] = arrayFileName [counter1];
                                        
                                        delete [] arrayFileName;
                                        arrayFileName = new string [fileNameLimit+500];
                                        fileNameLimit = fileNameLimit+500;
                                        
                                        for (int counter1 = 0; counter1 < fileNameCount; counter1++){
                                            arrayFileName [counter1] = arrayUpDate [counter1];
                                        }
                                        
                                        delete [] arrayUpDate;
                                    }
                                    
                                    arrayFileName [fileNameCount] = entry, fileNameCount++;
                                }
                            }
                            
                            //-------Directory Sort------
                            NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                            
                            for (int counter1 = 0; counter1 < fileNameCount; counter1++){
                                [unsortedArray addObject:@(arrayFileName [counter1].c_str())];
                            }
                            
                            [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                            
                            for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                                arrayFileName [counter1] = [unsortedArray [counter1] UTF8String];
                            }
                            
                            closedir(dir);
                        }
                        
                        backUpCopyFlag = 1;
                    }
                    else{
                        
                        for (int counter1 = 0; counter1 < tableDisplayCount/5; counter1++){
                            if (arrayTableDisplay [counter1*5] == backupDirectory){
                                arrayTableDisplay [counter1*5+4] = "C";
                                break;
                            }
                        }
                        
                        ofstream oin;
                        oin.open(messagePath.c_str(), ios::out);
                        
                        oin<<backupDirectory<<endl;
                        oin<<backupFolderNo<<endl;
                        oin<<backupStartNo<<endl;
                        oin<<backupEndNo<<endl;
                        oin<<"C"<<endl;
                        oin.close();
                        
                        tableViewCall = 1;
                        backupStartFlag = 4;
                    }
                }
            }
            else if (backupFolderNo == "nil"){
                for (int counter1 = 0; counter1 < tableDisplayCount/5; counter1++){
                    if (arrayTableDisplay [counter1*5] == backupDirectory){
                        arrayTableDisplay [counter1*5+1] = "0";
                        arrayTableDisplay [counter1*5+2] = "0";
                        arrayTableDisplay [counter1*5+3] = "0";
                        arrayTableDisplay [counter1*5+4] = "C";
                        break;
                    }
                }
                
                ofstream oin;
                oin.open(messagePath.c_str(), ios::out);
                
                oin<<backupDirectory<<endl;
                oin<<"0"<<endl;
                oin<<"0"<<endl;
                oin<<"0"<<endl;
                oin<<"C"<<endl;
                oin.close();
                
                tableViewCall = 1;
                backupStartFlag = 4;
            }
            else if (backupFolderNo != "nil"){
                for (int counter1 = 0; counter1 < tableDisplayCount/5; counter1++){
                    if (arrayTableDisplay [counter1*5] == backupDirectory){
                        arrayTableDisplay [counter1*5+4] = "C";
                        break;
                    }
                }
                
                ofstream oin;
                oin.open(messagePath.c_str(), ios::out);
                
                oin<<backupDirectory<<endl;
                oin<<backupFolderNo<<endl;
                oin<<backupStartNo<<endl;
                oin<<backupEndNo<<endl;
                oin<<"C"<<endl;
                oin.close();
                
                tableViewCall = 1;
                backupStartFlag = 4;
            }
        }
        else if (backupFolderNo == "nil"){
            for (int counter1 = 0; counter1 < tableDisplayCount/5; counter1++){
                if (arrayTableDisplay [counter1*5] == backupDirectory){
                    arrayTableDisplay [counter1*5+1] = "0";
                    arrayTableDisplay [counter1*5+2] = "0";
                    arrayTableDisplay [counter1*5+3] = "0";
                    arrayTableDisplay [counter1*5+4] = "C";
                    break;
                }
            }
            
            ofstream oin;
            oin.open(messagePath.c_str(), ios::out);
            
            oin<<backupDirectory<<endl;
            oin<<"0"<<endl;
            oin<<"0"<<endl;
            oin<<"0"<<endl;
            oin<<"C"<<endl;
            oin.close();
            
            tableViewCall = 1;
            backupStartFlag = 4;
        }
        else if (backupFolderNo != "nil"){
            for (int counter1 = 0; counter1 < tableDisplayCount/5; counter1++){
                if (arrayTableDisplay [counter1*5] == backupDirectory){
                    arrayTableDisplay [counter1*5+4] = "C";
                    break;
                }
            }
            
            ofstream oin;
            oin.open(messagePath.c_str(), ios::out);
            
            oin<<backupDirectory<<endl;
            oin<<backupFolderNo<<endl;
            oin<<backupStartNo<<endl;
            oin<<backupEndNo<<endl;
            oin<<"C"<<endl;
            oin.close();
            
            tableViewCall = 1;
            backupStartFlag = 4;
        }
    }
    else{
        
        ofstream oin;
        oin.open(messagePath.c_str(), ios::out);
        
        oin<<"NAD"<<endl;
        oin<<"nil"<<endl;
        oin<<"nil"<<endl;
        oin<<"nil"<<endl;
        oin<<"nil"<<endl;
        oin.close();
        
        [self processStopSub];
    }
}

-(IBAction)backUpAlreadyClean:(id)sender{
    if (processStartFlag == 0 && cleaningProgress == 0){
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert addButtonWithTitle:@"Cancel"];
        [alert setMessageText:@"Back-up folders will be deleted"];
        [alert setAlertStyle:NSAlertStyleWarning];
        
        if ([alert runModal] == NSAlertFirstButtonReturn){
            [self backUpAlreadyCleanMain];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Backup Running/Backup folders: under the deletion"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)backUpAlreadyCleanMain{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
        self->cleaningProgress = 1;
        
        int fileNoCount = 0;
        
        DIR *dir;
        struct dirent *dent;
        DIR *dir2;
        struct dirent *dent2;
        
        dir = opendir(self->backUpFolderPath.c_str());
        
        if (dir != NULL){
            string entry;
            string productDataPath1;
            string extractString;
            
            while((dent = readdir(dir))){
                entry = dent -> d_name;
                productDataPath1 = self->backUpFolderPath+"/"+entry;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                    extractString = entry.substr(entry.find("-1")+2);
                    
                    if (atoi(extractString.c_str()) <= self->lastPickUpFolder) fileNoCount++;
                }
            }
            
            closedir(dir);
            
            string *folderNameList = new string [fileNoCount+50];
            int folderNameListCount = 0;
            
            dir = opendir(self->backUpFolderPath.c_str());
            
            while((dent = readdir(dir))){
                entry = dent -> d_name;
                productDataPath1 = self->backUpFolderPath+"/"+entry;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                    extractString = entry.substr(entry.find("-1")+2);
                    
                    if (atoi(extractString.c_str()) <= self->lastPickUpFolder){
                        folderNameList [folderNameListCount] = entry, folderNameListCount++;
                    }
                }
            }
            
            closedir(dir);
            
            string entry2;
            string productDataPath2;
            
            self->progressValue = folderNameListCount;
            self->progressTiming = 1;
            
            do usleep(10);
            while (self->progressTiming == 1);
            
            for (int counter1 = 0; counter1 < folderNameListCount; counter1++){
                self->progressValue = counter1+1;
                self->progressTiming = 3;
                
                usleep(1000);
                
                entry = folderNameList [counter1];
                productDataPath1 = self->backUpFolderPath+"/"+entry;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                    dir2 = opendir(productDataPath1.c_str());
                    fileDeleteCount = 0;
                    
                    if (dir2 != NULL){
                        while((dent2 = readdir(dir2))){
                            entry2 = dent2 -> d_name;
                            
                            if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                            arrayFileDelete [fileDeleteCount] = entry2, fileDeleteCount++;
                        }
                        
                        closedir(dir2);
                        
                        for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                            productDataPath2 = productDataPath1+"/"+arrayFileDelete [counter2];
                            remove (productDataPath2.c_str());
                        }
                    }
                }
                
                rmdir (productDataPath1.c_str());
            }
            
            delete [] folderNameList;
            
            self->progressTiming = 5;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        
        self->cleaningProgress = 0;
    });
}

-(IBAction)quitProcess:(id)sender{
    if (processStartFlag == 0 && cleaningProgress == 0) [self processStopSub];
    else exitFlag = 1;
}

-(void)processStopSub{
    if (timerBK) [timerBK invalidate];
    
    delete [] arrayBackUpInfo;
    delete [] arrayTableDisplay;
    delete [] arrayFileName;
    delete [] arrayFileDelete;
    
    exit (0);
}

-(void)fileDeleteUpDate{
    string *arrayUpDate = new string [fileDeleteCount+10];
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayUpDate [counter1] = arrayFileDelete [counter1];
    
    delete [] arrayFileDelete;
    arrayFileDelete = new string [fileDeleteLimit+500];
    fileDeleteLimit = fileDeleteLimit+500;
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayFileDelete [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)dealloc{
    if (timerBK) [timerBK invalidate];
}

@end
