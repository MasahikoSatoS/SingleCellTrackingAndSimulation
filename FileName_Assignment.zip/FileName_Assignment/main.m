//
//  main.m
//  FileName_Assignment
//
//  Created by Masahiko Sato on 14/03/10.
//  Copyright Masahiko Sato 2010-2014. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[]){
    return NSApplicationMain(argc, (const char **) argv);
}
