/*
 *  Controller.h
 *  FileName_Assignment
 *
 *  Created by Masahiko Sato on 03/01/10, 06/03/14 revise.
 *  Copyright 2010 All rights reserved.
 *
 */

#ifndef CONTROLLER_H
#define CONTROLLER_H
#import <Cocoa/Cocoa.h>
#import "TerminationMonitor.h"
#include <iostream>
#include <string>
#include <dirent.h>
#include <sys/stat.h>
#include <fstream>
#include <sstream>
#endif

using namespace std;

extern NSString *notificationToTermination;

extern string *arrayTableData; //Array holding Fov, name color info
extern string *arrayFileDelete; //Array for files to be deleted
extern int fileDeleteCount;
extern int fileDeleteLimit;
extern int *arrayMark; //Array for error status after evaluation of names

@interface Controller : NSObject <NSTableViewDataSource>{
    int totalFOV; //Total FOV
    int tableViewCall; //Call Table view
    int initialArraySet; //Flag for initial array set
    int rowIndexHold; //Row index no
    int processPermission; //Permit process proceed
    int processMode; //Auto/Initial
    int tableCallCount; //Table display control
    int tableCurrentRowHold; //Table operation
    int firstCommunication; //Communication establishment flag
    int basicInfoRead; //Flag for data receive
    int fileInfoSendCall; //Flag for data send
    int sendMessageON; //Send message type
    
    string pathNameString; //Name path
    string bodyName; //Analysis name
    string xyDimensionMapPath; //XY Map info Path
    string fileDataPath; //Fluorescent data path
    string assignNamePath; //Assign Name Path
    string nameCheckString; //For Name check
    string dataFilesPath; //Data file path "02"
    string namedFilesPath; //Named file path "03"
    string instructionNamePath; //Instraction
    
    IBOutlet NSTableView *tableViewList;
    
    IBOutlet NSTextField *totalFOVDisplay;
    IBOutlet NSTextField *bodyNameDisplay;
    IBOutlet NSTextField *inputData;
    IBOutlet NSTextField *checkStatusDisplay;
    IBOutlet NSTextField *processModeDisplay;
    IBOutlet NSWindow *fileNameWindow;
    
    NSTimer *controllerTimer;
}

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;
-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex;
-(void)tableView:(NSTableView *)aTableView setObjectValue:(id)anObject forTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;

-(id)init;
-(void)dealloc;
-(void)processStartSub;
-(void)processStopSub;
-(void)displayData;
-(void)Communication;
-(int)nameCheck:(int)chLength;
-(void)fileDeleteUpDate;

-(IBAction)folderNameCheck:(id)sender;
-(IBAction)processStart:(id)sender;
-(IBAction)processStop:(id)sender;
-(IBAction)inputData:(id)sender;
-(IBAction)color1:(id)sender;
-(IBAction)color2:(id)sender;
-(IBAction)color3:(id)sender;
-(IBAction)color4:(id)sender;
-(IBAction)color5:(id)sender;
-(IBAction)color6:(id)sender;
-(IBAction)color7:(id)sender;
-(IBAction)color8:(id)sender;
-(IBAction)color9:(id)sender;

@end


