/*
 *  Controller.mm
 *  FileName_Assignment
 *
 *  Created by Masahiko Sato on 03/01/10, 06/03/14 revised.
 *  Copyright 2010 All rights reserved.
 *
 */

#import "Controller.h"

string *arrayTableData;
string *arrayFileDelete;
int fileDeleteCount;
int fileDeleteLimit;
int *arrayMark;

@implementation Controller

//==========Data File Format==========
//Data File: Folder<Data_files>/Sub folder<HeLaFA-10001>, "HeLaFA" Analysis name, "10001" Sequential number starting from 10000.
//File Name format: BaseName000_s0001_t0001.tif or BaseName000_Blue_s0001_t0001.tif

//Named File: Folder<Named_files>/Sub folder<HeLaFA-10001>/File Name, "Cont_0001-001.tif", "Cont" is well name, "0001" is time point (0001, 0010, 0100..), "001" is stage position. In the case of fluorescent: "Cont_0001-001_1_Blue.tif", _1_ is color no, Blue is color name

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSString *currentDirectoryPathNSString = [[NSBundle mainBundle] bundlePath];
        string userPathNameString = [currentDirectoryPathNSString cStringUsingEncoding:NSUTF8StringEncoding];
        
        if (userPathNameString.length() == 0) exit (0);
        else if ((int)userPathNameString.find("/Users/") == -1) exit (0);
        else{
            
            string pathName2 = userPathNameString.substr((unsigned long)userPathNameString.find("/Users/")+7);
            pathNameString = pathName2.substr(0, (unsigned long)pathName2.find("/"));
        }
        
        tableViewCall = 0;
        initialArraySet = 0;
        rowIndexHold = 0;
        processPermission = 0;
        processMode = 0;
        tableCallCount = 0;
        tableCurrentRowHold = 0;
        firstCommunication = 0;
        basicInfoRead = 0;
        fileInfoSendCall = 0;
        sendMessageON = 0;
        
        bodyName = "";
    }
    
    return self;
}

- (void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat xLength = screenRect.size.width;
    CGFloat yLength = screenRect.size.height;
    
    int mainControllerX = 800;
    
    NSRect windowSize = [fileNameWindow frame];
    CGFloat windowWidth = windowSize.size.width;
    CGFloat windowHeight = windowSize.size.height;
    
    int displayPositionType = 0;
    
    if (80+mainControllerX+5+windowWidth+5+80 > xLength) displayPositionType = 1;
    
    CGFloat displayX;
    
    if (displayPositionType == 1) displayX = 550;
    else displayX = 80+mainControllerX+5;
    
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [fileNameWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    [fileNameWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    [tableViewList setDataSource:self];
}

-(void)applicationDidFinishLaunching:(NSNotification*)notification{
    string dataString;
    
    xyDimensionMapPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/MAP_XYDimensionMapData";
    fileDataPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/FLFileData";
    assignNamePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/NAAssignedName";
    dataFilesPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"02_Data_Files";
    namedFilesPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"03_Named_Files";
    instructionNamePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/"+"Name_Instruction1";
    
    arrayTableData = new string [100];
    arrayMark = new int [50];
    
    arrayFileDelete = new string [100];
    fileDeleteCount = 0;
    fileDeleteLimit = 100;
    
    totalFOV = 0;
    
    ifstream fin;
    
    fin.open(assignNamePath.c_str(),ios::in);
    
    if (fin.is_open()){
        for (int counter1 = 0; counter1 < 31; counter1++){
            getline(fin, dataString);
            arrayTableData [counter1*3] = dataString;
            getline(fin, dataString);
            arrayTableData [counter1*3+1] = dataString;
            getline(fin, dataString);
            arrayTableData [counter1*3+2] = dataString;
            
            if (counter1 >= 1 && counter1 <= 17) totalFOV = totalFOV+atoi(dataString.c_str());
        }
        
        fin.close();
    }
    else{
        
        arrayTableData [0] = "Well No";
        arrayTableData [1] = "Treat. Name";
        arrayTableData [2] = "No of FOV";
        
        fin.open(xyDimensionMapPath.c_str(),ios::in);
        
        if (fin.is_open()){
            for (int counter1 = 0; counter1 < 16; counter1++){
                getline(fin, dataString);
                getline(fin, dataString);
                getline(fin, dataString);
                arrayTableData [counter1*3+3] = "Well";
                arrayTableData [counter1*3+4] = "nil";
                arrayTableData [counter1*3+5] = dataString;
                totalFOV = totalFOV+atoi(dataString.c_str());
            }
            
            fin.close();
        }
        else{
            
            for (int counter1 = 0; counter1 < 16; counter1++){
                arrayTableData [counter1*3+3] = "Well";
                arrayTableData [counter1*3+4] = "nil";
                arrayTableData [counter1*3+5] = "0";
            }
        }
        
        arrayTableData [51] = "BF";
        arrayTableData [52] = "BF";
        arrayTableData [53] = "BF";
        
        arrayTableData [54] = "Fluo: Org Name";
        arrayTableData [55] = "Fluo: New Name";
        arrayTableData [56] = "Color No";
        
        fin.open(fileDataPath.c_str(),ios::in);
        
        if (fin.is_open()){
            getline(fin, dataString);
            getline(fin, dataString);
            getline(fin, dataString);
            arrayTableData [57] = dataString;
            arrayTableData [58] = dataString;
            arrayTableData [59] = "0";
            
            getline(fin, dataString);
            arrayTableData [60] = dataString;
            arrayTableData [61] = dataString;
            arrayTableData [62] = "0";
            
            getline(fin, dataString);
            arrayTableData [63] = dataString;
            arrayTableData [64] = dataString;
            arrayTableData [65] = "0";
            
            getline(fin, dataString);
            arrayTableData [66] = dataString;
            arrayTableData [67] = dataString;
            arrayTableData [68] = "0";
            
            getline(fin, dataString);
            arrayTableData [69] = dataString;
            arrayTableData [70] = dataString;
            arrayTableData [71] = "0";
            
            getline(fin, dataString);
            arrayTableData [72] = dataString;
            arrayTableData [73] = dataString;
            arrayTableData [74] = "0";
            
            fin.close();
        }
        else{
            
            arrayTableData [57] = "nil";
            arrayTableData [58] = "nil";
            arrayTableData [59] = "0";
            
            arrayTableData [60] = "nil";
            arrayTableData [61] = "nil";
            arrayTableData [62] = "0";
            
            arrayTableData [63] = "nil";
            arrayTableData [64] = "nil";
            arrayTableData [65] = "0";
            
            arrayTableData [66] = "nil";
            arrayTableData [67] = "nil";
            arrayTableData [68] = "0";
            
            arrayTableData [69] = "nil";
            arrayTableData [70] = "nil";
            arrayTableData [71] = "0";
            
            arrayTableData [72] = "nil";
            arrayTableData [73] = "nil";
            arrayTableData [74] = "0";
        }
        
        ofstream oin;
        
        oin.open(assignNamePath.c_str(), ios::out);
        
        for (int counter1 = 0; counter1 <= 74; counter1++) oin<<arrayTableData [counter1]<<endl;
        
        oin.close();
    }
    
    //for (int counterA = 0; counterA < 22; counterA++){
    //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayTableData [counterA*3+counterB];
    //    cout<<" arrayTableData "<<counterA+1<<endl;
    //}
    
    for (int counter1 = 0; counter1 < 25; counter1++) arrayMark [counter1] = 0;
    
    [totalFOVDisplay setIntegerValue:totalFOV];
    [inputData setStringValue:@""];
    
    initialArraySet = 1;
    tableViewCall = 1;
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTermination object:self];
    controllerTimer = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(displayData) userInfo:nil repeats:YES];
}

-(void)displayData{
    if (tableViewCall == 1){
        tableViewCall = 0;
        [tableViewList reloadData];
    }
    
    if (tableCallCount == 1){
        tableCallCount = 0;
        rowIndexHold = tableCurrentRowHold;
    }
    
    if (tableCallCount > 1) tableCallCount = 0;
    
    [self Communication];
}

-(void)Communication{
    //---------Initial establishment---------
    if (firstCommunication == 0){
        firstCommunication = 1;
        basicInfoRead = 1;
    }
    
    //----------Basic info and holding flag read----------
    if (firstCommunication == 1 && basicInfoRead == 1){
        basicInfoRead = 2;
    }
    
    if (firstCommunication == 1 && basicInfoRead == 2){
        string runStatusTemp = "nil";
        string bodynameTemp;
        string receivedData = "nil";
        string getString = "nil";
        
        int instractionNameFlag = 0;
        
        ifstream fin;
        
        fin.open(instructionNamePath.c_str(),ios::in);
        
        if (fin.is_open()){
            instractionNameFlag = 1;
            fin.close();
        }
        
        if (instractionNameFlag != 0){
            fin.open(instructionNamePath.c_str(),ios::in);
            
            getline(fin, getString), runStatusTemp = getString;
            getline(fin, getString), bodynameTemp = getString;
            
            if (atoi(runStatusTemp.c_str()) >= 2 && atoi(runStatusTemp.c_str()) <= 5){
                receivedData = runStatusTemp;
                remove (instructionNamePath.c_str());
            }
            
            fin.close();
        }
        
        if (receivedData != "nil"){
            bodyName = bodynameTemp;
            processMode = atoi(runStatusTemp.c_str());
            
            [bodyNameDisplay setStringValue:@(bodyName.c_str())];
            
            if (processMode == 2){
                remove(assignNamePath.c_str());
                
                [processModeDisplay setStringValue:@"Init."];
                
                arrayTableData [0] = "Well No";
                arrayTableData [1] = "Treat. Name";
                arrayTableData [2] = "No of FOV";
                
                totalFOV = 0;
                
                fin.open(xyDimensionMapPath.c_str(),ios::in);
                
                string dataString;
                
                if (fin.is_open()){
                    for (int counter1 = 0; counter1 < 16; counter1++){
                        getline(fin, dataString);
                        getline(fin, dataString);
                        getline(fin, dataString);
                        
                        if (dataString != ""){
                            arrayTableData [counter1*3+3] = "Well";
                            arrayTableData [counter1*3+4] = "nil";
                            arrayTableData [counter1*3+5] = dataString;
                            totalFOV = totalFOV+atoi(dataString.c_str());
                        }
                        else{
                            
                            arrayTableData [counter1*3+3] = "Well";
                            arrayTableData [counter1*3+4] = "nil";
                            arrayTableData [counter1*3+5] = "0";
                        }
                    }
                    
                    fin.close();
                }
                else{
                    
                    for (int counter1 = 0; counter1 < 16; counter1++){
                        arrayTableData [counter1*3+3] = "Well";
                        arrayTableData [counter1*3+4] = "nil";
                        arrayTableData [counter1*3+5] = "0";
                    }
                }
                
                arrayTableData [51] = "BF";
                arrayTableData [52] = "BF";
                arrayTableData [53] = "BF";
                
                arrayTableData [54] = "Fluo: Org Name";
                arrayTableData [55] = "Fluo: New Name";
                arrayTableData [56] = "Color No";
                
                fin.open(fileDataPath.c_str(),ios::in);
                
                if (fin.is_open()){
                    getline(fin, dataString);
                    getline(fin, dataString);
                    getline(fin, dataString);
                    arrayTableData [57] = dataString;
                    arrayTableData [58] = dataString;
                    arrayTableData [59] = "0";
                    
                    getline(fin, dataString);
                    arrayTableData [60] = dataString;
                    arrayTableData [61] = dataString;
                    arrayTableData [62] = "0";
                    
                    getline(fin, dataString);
                    arrayTableData [63] = dataString;
                    arrayTableData [64] = dataString;
                    arrayTableData [65] = "0";
                    
                    getline(fin, dataString);
                    arrayTableData [66] = dataString;
                    arrayTableData [67] = dataString;
                    arrayTableData [68] = "0";
                    
                    getline(fin, dataString);
                    arrayTableData [69] = dataString;
                    arrayTableData [70] = dataString;
                    arrayTableData [71] = "0";
                    
                    getline(fin, dataString);
                    arrayTableData [72] = dataString;
                    arrayTableData [73] = dataString;
                    arrayTableData [74] = "0";
                    
                    fin.close();
                }
                else{
                    
                    arrayTableData [57] = "nil";
                    arrayTableData [58] = "nil";
                    arrayTableData [59] = "0";
                    
                    arrayTableData [60] = "nil";
                    arrayTableData [61] = "nil";
                    arrayTableData [62] = "0";
                    
                    arrayTableData [63] = "nil";
                    arrayTableData [64] = "nil";
                    arrayTableData [65] = "0";
                    
                    arrayTableData [66] = "nil";
                    arrayTableData [67] = "nil";
                    arrayTableData [68] = "0";
                    
                    arrayTableData [69] = "nil";
                    arrayTableData [70] = "nil";
                    arrayTableData [71] = "0";
                    
                    arrayTableData [72] = "nil";
                    arrayTableData [73] = "nil";
                    arrayTableData [74] = "0";
                }
                
                ofstream oin;
                
                oin.open(assignNamePath.c_str(), ios::out);
                
                for (int counter1 = 0; counter1 <= 74; counter1++) oin<<arrayTableData [counter1]<<endl;
                
                oin.close();
                
                //for (int counterA = 0; counterA < 22; counterA++){
                //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayTableData [counterA*3+counterB];
                //    cout<<" arrayTableData "<<counterA+1<<endl;
                //}
                
                tableViewCall = 1;
            }
            else if (processMode == 4){
                [processModeDisplay setStringValue:@"IF-Init."];
                
                string dataString;
                
                fin.open(assignNamePath.c_str(),ios::in);
                
                for (int counter1 = 0; counter1 < 22; counter1++){
                    getline(fin, dataString);
                    arrayTableData [counter1*3] = dataString;
                    getline(fin, dataString);
                    arrayTableData [counter1*3+1] = dataString;
                    getline(fin, dataString);
                    arrayTableData [counter1*3+2] = dataString;
                    
                    if (counter1 >= 1 && counter1 <= 17) totalFOV = totalFOV+atoi(dataString.c_str());
                }
                
                fin.close();
                
                arrayTableData [51] = "BF";
                arrayTableData [52] = "BF";
                arrayTableData [53] = "BF";
                
                arrayTableData [54] = "Fluo: Org Name";
                arrayTableData [55] = "Fluo: New Name";
                arrayTableData [56] = "Color No";
                
                fin.open(fileDataPath.c_str(),ios::in);
                
                if (fin.is_open()){
                    getline(fin, dataString);
                    getline(fin, dataString);
                    getline(fin, dataString);
                    arrayTableData [57] = dataString;
                    arrayTableData [58] = dataString;
                    arrayTableData [59] = "0";
                    
                    getline(fin, dataString);
                    arrayTableData [60] = dataString;
                    arrayTableData [61] = dataString;
                    arrayTableData [62] = "0";
                    
                    getline(fin, dataString);
                    arrayTableData [63] = dataString;
                    arrayTableData [64] = dataString;
                    arrayTableData [65] = "0";
                    
                    getline(fin, dataString);
                    arrayTableData [66] = dataString;
                    arrayTableData [67] = dataString;
                    arrayTableData [68] = "0";
                    
                    getline(fin, dataString);
                    arrayTableData [69] = dataString;
                    arrayTableData [70] = dataString;
                    arrayTableData [71] = "0";
                    
                    getline(fin, dataString);
                    arrayTableData [72] = dataString;
                    arrayTableData [73] = dataString;
                    arrayTableData [74] = "0";
                    
                    fin.close();
                }
                else{
                    
                    arrayTableData [57] = "nil";
                    arrayTableData [58] = "nil";
                    arrayTableData [59] = "0";
                    
                    arrayTableData [60] = "nil";
                    arrayTableData [61] = "nil";
                    arrayTableData [62] = "0";
                    
                    arrayTableData [63] = "nil";
                    arrayTableData [64] = "nil";
                    arrayTableData [65] = "0";
                    
                    arrayTableData [66] = "nil";
                    arrayTableData [67] = "nil";
                    arrayTableData [68] = "0";
                    
                    arrayTableData [69] = "nil";
                    arrayTableData [70] = "nil";
                    arrayTableData [71] = "0";
                    
                    arrayTableData [72] = "nil";
                    arrayTableData [73] = "nil";
                    arrayTableData [74] = "0";
                }
                
                ofstream oin;
                
                oin.open(assignNamePath.c_str(), ios::out);
                
                for (int counter1 = 0; counter1 <= 74; counter1++) oin<<arrayTableData [counter1]<<endl;
                
                oin.close();
                
                //for (int counterA = 0; counterA < 22; counterA++){
                //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayTableData [counterA*3+counterB];
                //    cout<<" arrayTableData "<<counterA+1<<endl;
                //}
                
                tableViewCall = 1;
            }
            else if (processMode == 3 || processMode == 5){
                if (processMode == 3)[processModeDisplay setStringValue:@"Init."];
                else [processModeDisplay setStringValue:@"IF-Init."];
            }
            
            basicInfoRead = 3;
        }
    }
    
    if (firstCommunication == 1 && basicInfoRead == 3){
        basicInfoRead = 4;
    }
    
    //----------Send Setting data----------
    if (firstCommunication == 1 && fileInfoSendCall == 1 && sendMessageON == 2){
        fileInfoSendCall = 2;
    }
    
    if (firstCommunication == 1 && fileInfoSendCall == 2){
        string sendString = "~~N";
        
        for (int counter1 = 1; counter1 < 17; counter1++) sendString = sendString+"/"+arrayTableData [counter1*3+1];
        
        sendString = sendString+"/"+arrayTableData [58]+"/"+arrayTableData [59];
        sendString = sendString+"/"+arrayTableData [61]+"/"+arrayTableData [62];
        sendString = sendString+"/"+arrayTableData [64]+"/"+arrayTableData [65];
        sendString = sendString+"/"+arrayTableData [67]+"/"+arrayTableData [68];
        sendString = sendString+"/"+arrayTableData [70]+"/"+arrayTableData [71];
        sendString = sendString+"/"+arrayTableData [73]+"/"+arrayTableData [74];
        sendString = sendString+"/"+bodyName+"-10001"+"/";
        
        fstream oin;
        
        for (int counter1 = 0; counter1 < 10; counter1++){
            oin.open(instructionNamePath.c_str(), ios::out);
            
            if (oin.is_open()){
                oin<<sendString<<endl;
                oin.close();
                fileInfoSendCall = 3;
                break;
            }
        }
    }
    
    if (firstCommunication == 1 && fileInfoSendCall == 3){
        fileInfoSendCall = 4;
    }
    
    if (firstCommunication == 1 && fileInfoSendCall == 4){
        fileInfoSendCall = 0;
        
        if (processMode == 2 || processMode == 4){
            sendMessageON = 7;
            [checkStatusDisplay setStringValue:@"R-to-Quit"];
        }
    }
}

-(int)numberOfRowsInTableView:(NSTableView *)aTableView{
    int tableViewContent = 25;
    return tableViewContent;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    NSAttributedString *attrStr;
    
    if (initialArraySet == 1){
        int markStatus = arrayMark [rowIndex];
        
        int highlight = 0;
        string displayData1;
        string displayData2;
        string displayData3;
        
        if (rowIndex >= 1 && rowIndex <= 16 && arrayTableData [rowIndex*3+2] != "0") highlight = 1;
        else if (rowIndex >= 19 && rowIndex <= 24 && arrayTableData [rowIndex*3] != "nil") highlight = 1;
        
        if (rowIndex == 0) displayData1 = arrayTableData [rowIndex*3], displayData2 = arrayTableData [rowIndex*3+1], displayData3 = arrayTableData [rowIndex*3+2];
        else if (rowIndex == 1) displayData1 = "Well 1", displayData2 = arrayTableData [rowIndex*3+1], displayData3 = arrayTableData [rowIndex*3+2];
        else if (rowIndex == 2) displayData1 = "Well 2", displayData2 = arrayTableData [rowIndex*3+1], displayData3 = arrayTableData [rowIndex*3+2];
        else if (rowIndex == 3) displayData1 = "Well 3", displayData2 = arrayTableData [rowIndex*3+1], displayData3 = arrayTableData [rowIndex*3+2];
        else if (rowIndex == 4) displayData1 = "Well 4", displayData2 = arrayTableData [rowIndex*3+1], displayData3 = arrayTableData [rowIndex*3+2];
        else if (rowIndex == 5) displayData1 = "Well 5", displayData2 = arrayTableData [rowIndex*3+1], displayData3 = arrayTableData [rowIndex*3+2];
        else if (rowIndex == 6) displayData1 = "Well 6", displayData2 = arrayTableData [rowIndex*3+1], displayData3 = arrayTableData [rowIndex*3+2];
        else if (rowIndex == 7) displayData1 = "Well 7", displayData2 = arrayTableData [rowIndex*3+1], displayData3 = arrayTableData [rowIndex*3+2];
        else if (rowIndex == 8) displayData1 = "Well 8", displayData2 = arrayTableData [rowIndex*3+1], displayData3 = arrayTableData [rowIndex*3+2];
        else if (rowIndex == 9) displayData1 = "Well 9", displayData2 = arrayTableData [rowIndex*3+1], displayData3 = arrayTableData [rowIndex*3+2];
        else if (rowIndex == 10) displayData1 = "Well 10", displayData2 = arrayTableData [rowIndex*3+1], displayData3 = arrayTableData [rowIndex*3+2];
        else if (rowIndex == 11) displayData1 = "Well 11", displayData2 = arrayTableData [rowIndex*3+1], displayData3 = arrayTableData [rowIndex*3+2];
        else if (rowIndex == 12) displayData1 = "Well 12", displayData2 = arrayTableData [rowIndex*3+1], displayData3 = arrayTableData [rowIndex*3+2];
        else if (rowIndex == 13) displayData1 = "Well 13", displayData2 = arrayTableData [rowIndex*3+1], displayData3 = arrayTableData [rowIndex*3+2];
        else if (rowIndex == 14) displayData1 = "Well 14", displayData2 = arrayTableData [rowIndex*3+1], displayData3 = arrayTableData [rowIndex*3+2];
        else if (rowIndex == 15) displayData1 = "Well 15", displayData2 = arrayTableData [rowIndex*3+1], displayData3 = arrayTableData [rowIndex*3+2];
        else if (rowIndex == 16) displayData1 = "Well 16", displayData2 = arrayTableData [rowIndex*3+1], displayData3 = arrayTableData [rowIndex*3+2];
        else if (rowIndex == 17) displayData1 = " ", displayData2 = " ", displayData3 = " ";
        else if (rowIndex == 18) displayData1 = arrayTableData [rowIndex*3], displayData2 = arrayTableData [rowIndex*3+1], displayData3 = arrayTableData [rowIndex*3+2];
        else if (rowIndex == 19) displayData1 = arrayTableData [rowIndex*3], displayData2 = arrayTableData [rowIndex*3+1], displayData3 = arrayTableData [rowIndex*3+2];
        else if (rowIndex == 20) displayData1 = arrayTableData [rowIndex*3], displayData2 = arrayTableData [rowIndex*3+1], displayData3 = arrayTableData [rowIndex*3+2];
        else if (rowIndex == 21) displayData1 = arrayTableData [rowIndex*3], displayData2 = arrayTableData [rowIndex*3+1], displayData3 = arrayTableData [rowIndex*3+2];
        else if (rowIndex == 22) displayData1 = arrayTableData [rowIndex*3], displayData2 = arrayTableData [rowIndex*3+1], displayData3 = arrayTableData [rowIndex*3+2];
        else if (rowIndex == 23) displayData1 = arrayTableData [rowIndex*3], displayData2 = arrayTableData [rowIndex*3+1], displayData3 = arrayTableData [rowIndex*3+2];
        else if (rowIndex == 24) displayData1 = arrayTableData [rowIndex*3], displayData2 = arrayTableData [rowIndex*3+1], displayData3 = arrayTableData [rowIndex*3+2];
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
        [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"] && markStatus == 0 && highlight == 0){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL1"] && ((markStatus == 1 && highlight == 0) || (markStatus == 1 && highlight == 1))){
            [attributes setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL1"] && markStatus == 0 && highlight == 1){
            [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && markStatus == 0 && highlight == 0){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData2.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && ((markStatus == 1 && highlight == 0) || (markStatus == 1 && highlight == 1))){
            [attributes setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData2.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && markStatus == 0 && highlight == 1){
            [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData2.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL3"] && markStatus == 0  && highlight == 0){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData3.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL3"] && ((markStatus == 1 && highlight == 0) || (markStatus == 1 && highlight == 1))){
            [attributes setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData3.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL3"] && markStatus == 0  && highlight == 1){
            [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData3.c_str()) attributes:attributes];
        }
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    else{
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL3"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    
    return attrStr;
}

-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex{
    tableCallCount++;
    
    if (tableCallCount == 2) tableCurrentRowHold = rowIndexHold;
    else if (tableCallCount == 1) tableCurrentRowHold = rowIndex;
    
    return YES;
}

- (void)tableView:(NSTableView *)aTableView setObjectValue:(id)anObject forTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex {
    if (sendMessageON == 0){
        NSString *columnIdentifier = [aTableColumn identifier];
        NSString *objectInfo = anObject;
        
        ofstream oin;
        
        if (rowIndex >= 1 && rowIndex <= 17 && [columnIdentifier isEqualToString:@"COL2"] && (processMode == 2 || processMode == 3)){
            if (arrayTableData [rowIndex*3+2] != "0"){
                nameCheckString = [objectInfo UTF8String];
                int chLength = 4;
                
                int errorResult = [self nameCheck:chLength];
                
                if (errorResult == 0 && nameCheckString != ""){
                    int identicalNoFind = 0;
                    
                    for (int counter1 = 1; counter1 <= 17; counter1++){
                        if (counter1 != rowIndex && arrayTableData [counter1*3+1] == nameCheckString) identicalNoFind = 1;
                    }
                    
                    int chEndCheck = 0;
                    int findString = (int)nameCheckString.find("CH1");
                    
                    if (findString != -1) chEndCheck = 1;
                    else if ((int)nameCheckString.find("CH2") != -1) chEndCheck = 1;
                    else if ((int)nameCheckString.find("CH3") != -1) chEndCheck = 1;
                    
                    if (identicalNoFind == 0 && chEndCheck == 0){
                        arrayTableData [rowIndex*3+1] = nameCheckString;
                        
                        oin.open(assignNamePath.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 <= 74; counter1++) oin<<arrayTableData [counter1]<<endl;
                        
                        oin.close();
                        
                        processPermission = 0;
                        [checkStatusDisplay setStringValue:@"None"];
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                        
                        tableViewCall = 1;
                    }
                    else{
                        
                        if (identicalNoFind != 0){
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Duplicate File Names Detected"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                        
                        if (chEndCheck != 0){
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Check Character Restrictions"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Check Character Restrictions"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else if (rowIndex >= 19 && rowIndex <= 24 && ([columnIdentifier isEqualToString:@"COL2"] || [columnIdentifier isEqualToString:@"COL3"])){
            if (arrayTableData [rowIndex*3+1] != "nil"){
                nameCheckString = [objectInfo UTF8String];
                
                if ([columnIdentifier isEqualToString:@"COL2"]){
                    int chLength = 3;
                    int errorResult = [self nameCheck:chLength];
                    
                    if (errorResult == 0 && nameCheckString != ""){
                        int identicalNoFind = 0;
                        
                        for (int counter1 = 19; counter1 <= 24; counter1++){
                            if (counter1 != rowIndex && arrayTableData [counter1*3+1] == nameCheckString) identicalNoFind = 1;
                        }
                        
                        if (identicalNoFind == 0){
                            arrayTableData [rowIndex*3+1] = nameCheckString;
                            
                            oin.open(assignNamePath.c_str(), ios::out);
                            
                            for (int counter1 = 0; counter1 <= 74; counter1++) oin<<arrayTableData [counter1]<<endl;
                            
                            oin.close();
                            
                            processPermission = 0;
                            [checkStatusDisplay setStringValue:@"None"];
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                            
                            tableViewCall = 1;
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Duplicate File Names Detected"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Check Character Restrictions"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else if ([columnIdentifier isEqualToString:@"COL3"]){
                    if (nameCheckString == "1" || nameCheckString == "2"|| nameCheckString == "3" || nameCheckString == "4" || nameCheckString == "5"){
                        int identicalNoFind = 0;
                        
                        for (int counter1 = 19; counter1 <= 24; counter1++){
                            if (counter1 != rowIndex && arrayTableData [counter1*3+2] == nameCheckString) identicalNoFind = 1;
                        }
                        
                        if (identicalNoFind == 0){
                            arrayTableData [rowIndex*3+2] = nameCheckString;
                            
                            oin.open(assignNamePath.c_str(), ios::out);
                            
                            for (int counter1 = 0; counter1 <= 74; counter1++) oin<<arrayTableData [counter1]<<endl;
                            
                            oin.close();
                            
                            processPermission = 0;
                            [checkStatusDisplay setStringValue:@"None"];
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                            
                            tableViewCall = 1;
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Files With Identical Numbers Detected"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            [inputData setStringValue:@""];
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                }
                else{
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Ready To Exit"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
    
    //for (int counterA = 0; counterA < 22; counterA++){
    //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayTableData [counterA*3+counterB];
    //    cout<<" arrayTableData "<<counterA+1<<endl;
    //}
}

-(IBAction)inputData:(id)sender{
    if (sendMessageON == 0){
        ofstream oin;
        
        if (rowIndexHold >= 1 && rowIndexHold <= 17 && (processMode == 2 || processMode == 3)){
            if (arrayTableData [rowIndexHold*3+2] != "0"){
                nameCheckString = [[inputData stringValue] UTF8String];
                
                int chLength = 4;
                int errorResult = [self nameCheck:chLength];
                
                int chEndCheck = 0;
                int findString = (int)nameCheckString.find("CH1");
                
                if (findString != -1) chEndCheck = 1;
                else if ((int)nameCheckString.find("CH2") != -1) chEndCheck = 1;
                else if ((int)nameCheckString.find("CH3") != -1) chEndCheck = 1;
                
                if (errorResult == 0 && nameCheckString != "" && chEndCheck == 0){
                    int identicalNoFind = 0;
                    
                    for (int counter1 = 1; counter1 <= 17; counter1++){
                        if (counter1 != rowIndexHold && arrayTableData [counter1*3+1] == nameCheckString) identicalNoFind = 1;
                    }
                    
                    if (identicalNoFind == 0){
                        arrayTableData [rowIndexHold*3+1] = nameCheckString;
                        
                        oin.open(assignNamePath.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 <= 74; counter1++) oin<<arrayTableData [counter1]<<endl;
                        
                        oin.close();
                        
                        processPermission = 0;
                        [checkStatusDisplay setStringValue:@"None"];
                        
                        [inputData setStringValue:@""];
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                        
                        tableViewCall = 1;
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Duplicate File Names Detected"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        [inputData setStringValue:@""];
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Check Character Restrictions"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    [inputData setStringValue:@""];
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                [inputData setStringValue:@""];
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else if (rowIndexHold >= 19 && rowIndexHold <= 24){
            if (arrayTableData [rowIndexHold*3+1] != "nil"){
                nameCheckString = [[inputData stringValue] UTF8String];
                
                int chLength = 3;
                int errorResult = [self nameCheck:chLength];
                
                if (errorResult == 0 && nameCheckString != ""){
                    int identicalNoFind = 0;
                    
                    for (int counter1 = 19; counter1 <= 24; counter1++){
                        if (counter1 != rowIndexHold && arrayTableData [counter1*3] == nameCheckString) identicalNoFind = 1;
                    }
                    
                    if (identicalNoFind == 0){
                        arrayTableData [rowIndexHold*3+1] = nameCheckString;
                        
                        oin.open(assignNamePath.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 <= 74; counter1++) oin<<arrayTableData [counter1]<<endl;
                        
                        oin.close();
                        
                        processPermission = 0;
                        [checkStatusDisplay setStringValue:@"None"];
                        
                        [inputData setStringValue:@""];
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                        
                        tableViewCall = 1;
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Duplicate File Names Detected"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        [inputData setStringValue:@""];
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Check Character Restrictions"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    [inputData setStringValue:@""];
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                [inputData setStringValue:@""];
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            [inputData setStringValue:@""];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Ready To Exit"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(int)nameCheck:(int)chLength{
    int errorFlag = 0;
    string newAnalysisID = nameCheckString;
    
    if ((int)newAnalysisID.length() < chLength || (int)newAnalysisID.length() > 15) errorFlag = 1;
    if ((int)newAnalysisID.find(" ") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find(",") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find(".") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("/") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find(",") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find(":") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("<") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find(">") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("'") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("[") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("]") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("=") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("+") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("{") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("}") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find(")") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("(") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("*") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("&") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("^") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("%") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("$") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("#") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("@") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("!") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("`") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("~") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("|") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("_") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("-") >= 0) errorFlag = 1;
    
    return errorFlag;
}

-(IBAction)color1:(id)sender{
    if (sendMessageON == 0){
        ofstream oin;
        
        if (rowIndexHold >= 19 && rowIndexHold <= 24){
            if (arrayTableData [rowIndexHold*3+1] != "nil"){
                int identicalNoFind = 0;
                
                for (int counter1 = 19; counter1 <= 24; counter1++){
                    if (counter1 != rowIndexHold && arrayTableData [counter1*3+2] == "1") identicalNoFind = 1;
                }
                
                if (identicalNoFind == 0){
                    arrayTableData [rowIndexHold*3+2] = "1";
                    
                    oin.open(assignNamePath.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 <= 74; counter1++) oin<<arrayTableData [counter1]<<endl;
                    
                    oin.close();
                    
                    processPermission = 0;
                    [checkStatusDisplay setStringValue:@"None"];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    tableViewCall = 1;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Files With Identical Numbers Detected"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Ready To Exit"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)color2:(id)sender{
    if (sendMessageON == 0){
        ofstream oin;
        
        if (rowIndexHold >= 19 && rowIndexHold <= 24){
            if (arrayTableData [rowIndexHold*3+1] != "nil"){
                int identicalNoFind = 0;
                
                for (int counter1 = 19; counter1 <= 24; counter1++){
                    if (counter1 != rowIndexHold && arrayTableData [counter1*3+2] == "2") identicalNoFind = 1;
                }
                
                if (identicalNoFind == 0){
                    arrayTableData [rowIndexHold*3+2] = "2";
                    
                    oin.open(assignNamePath.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 <= 74; counter1++) oin<<arrayTableData [counter1]<<endl;
                    
                    oin.close();
                    
                    processPermission = 0;
                    [checkStatusDisplay setStringValue:@"None"];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    tableViewCall = 1;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Files With Identical Numbers Detected"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Ready To Exit"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)color3:(id)sender{
    if (sendMessageON == 0){
        ofstream oin;
        
        if (rowIndexHold >= 19 && rowIndexHold <= 24){
            if (arrayTableData [rowIndexHold*3+1] != "nil"){
                int identicalNoFind = 0;
                
                for (int counter1 = 19; counter1 <= 24; counter1++){
                    if (counter1 != rowIndexHold && arrayTableData [counter1*3+2] == "3") identicalNoFind = 1;
                }
                
                if (identicalNoFind == 0){
                    arrayTableData [rowIndexHold*3+2] = "3";
                    
                    oin.open(assignNamePath.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 <= 74; counter1++) oin<<arrayTableData [counter1]<<endl;
                    
                    oin.close();
                    
                    processPermission = 0;
                    [checkStatusDisplay setStringValue:@"None"];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    tableViewCall = 1;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Files With Identical Numbers Detected"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Ready To Exit"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)color4:(id)sender{
    if (sendMessageON == 0){
        ofstream oin;
        
        if (rowIndexHold >= 19 && rowIndexHold <= 24){
            if (arrayTableData [rowIndexHold*3+1] != "nil"){
                int identicalNoFind = 0;
                
                for (int counter1 = 19; counter1 <= 24; counter1++){
                    if (counter1 != rowIndexHold && arrayTableData [counter1*3+2] == "4") identicalNoFind = 1;
                }
                
                if (identicalNoFind == 0){
                    arrayTableData [rowIndexHold*3+2] = "4";
                    
                    oin.open(assignNamePath.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 <= 74; counter1++) oin<<arrayTableData [counter1]<<endl;
                    
                    oin.close();
                    
                    processPermission = 0;
                    [checkStatusDisplay setStringValue:@"None"];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    tableViewCall = 1;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Files With Identical Numbers Detected"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Ready To Exit"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)color5:(id)sender{
    if (sendMessageON == 0){
        ofstream oin;
        
        if (rowIndexHold >= 19 && rowIndexHold <= 24){
            if (arrayTableData [rowIndexHold*3+1] != "nil"){
                int identicalNoFind = 0;
                
                for (int counter1 = 19; counter1 <= 24; counter1++){
                    if (counter1 != rowIndexHold && arrayTableData [counter1*3+2] == "5") identicalNoFind = 1;
                }
                
                if (identicalNoFind == 0){
                    arrayTableData [rowIndexHold*3+2] = "5";
                    
                    oin.open(assignNamePath.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 <= 74; counter1++) oin<<arrayTableData [counter1]<<endl;
                    
                    oin.close();
                    
                    processPermission = 0;
                    [checkStatusDisplay setStringValue:@"None"];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    tableViewCall = 1;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Files With Identical Numbers Detected"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Ready To Exit"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)color6:(id)sender{
    if (sendMessageON == 0){
        ofstream oin;
        
        if (rowIndexHold >= 19 && rowIndexHold <= 24){
            if (arrayTableData [rowIndexHold*3+1] != "nil"){
                int identicalNoFind = 0;
                
                for (int counter1 = 19; counter1 <= 24; counter1++){
                    if (counter1 != rowIndexHold && arrayTableData [counter1*3+2] == "6") identicalNoFind = 1;
                }
                
                if (identicalNoFind == 0){
                    arrayTableData [rowIndexHold*3+2] = "6";
                    
                    oin.open(assignNamePath.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 <= 74; counter1++) oin<<arrayTableData [counter1]<<endl;
                    
                    oin.close();
                    
                    processPermission = 0;
                    [checkStatusDisplay setStringValue:@"None"];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    tableViewCall = 1;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Files With Identical Numbers Detected"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Ready To Exit"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)color7:(id)sender{
    if (sendMessageON == 0){
        ofstream oin;
        
        if (rowIndexHold >= 19 && rowIndexHold <= 24){
            if (arrayTableData [rowIndexHold*3+1] != "nil"){
                int identicalNoFind = 0;
                
                for (int counter1 = 19; counter1 <= 24; counter1++){
                    if (counter1 != rowIndexHold && arrayTableData [counter1*3+2] == "7") identicalNoFind = 1;
                }
                
                if (identicalNoFind == 0){
                    arrayTableData [rowIndexHold*3+2] = "7";
                    
                    oin.open(assignNamePath.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 <= 74; counter1++) oin<<arrayTableData [counter1]<<endl;
                    
                    oin.close();
                    
                    processPermission = 0;
                    [checkStatusDisplay setStringValue:@"None"];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    tableViewCall = 1;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Files With Identical Numbers Detected"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Ready To Exit"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)color8:(id)sender{
    if (sendMessageON == 0){
        ofstream oin;
        
        if (rowIndexHold >= 19 && rowIndexHold <= 24){
            if (arrayTableData [rowIndexHold*3+1] != "nil"){
                int identicalNoFind = 0;
                
                for (int counter1 = 19; counter1 <= 24; counter1++){
                    if (counter1 != rowIndexHold && arrayTableData [counter1*3+2] == "8") identicalNoFind = 1;
                }
                
                if (identicalNoFind == 0){
                    arrayTableData [rowIndexHold*3+2] = "8";
                    
                    oin.open(assignNamePath.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 <= 74; counter1++) oin<<arrayTableData [counter1]<<endl;
                    
                    oin.close();
                    
                    processPermission = 0;
                    [checkStatusDisplay setStringValue:@"None"];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    tableViewCall = 1;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Files With Identical Numbers Detected"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Ready To Exit"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)color9:(id)sender{
    if (sendMessageON == 0){
        ofstream oin;
        
        if (rowIndexHold >= 19 && rowIndexHold <= 24){
            if (arrayTableData [rowIndexHold*3+1] != "nil"){
                int identicalNoFind = 0;
                
                for (int counter1 = 19; counter1 <= 24; counter1++){
                    if (counter1 != rowIndexHold && arrayTableData [counter1*3+2] == "9") identicalNoFind = 1;
                }
                
                if (identicalNoFind == 0){
                    arrayTableData [rowIndexHold*3+2] = "9";
                    
                    oin.open(assignNamePath.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 <= 74; counter1++) oin<<arrayTableData [counter1]<<endl;
                    
                    oin.close();
                    
                    processPermission = 0;
                    [checkStatusDisplay setStringValue:@"None"];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    tableViewCall = 1;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Files With Identical Numbers Detected"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Ready To Exit"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)folderNameCheck:(id)sender{
    if (sendMessageON == 0){
        int findMark1 = 0;
        int findMark2 = 0;
        int entryCheck = 0;
        
        for (int counter1 = 0; counter1 < 25; counter1++){
            if (counter1 >= 1 && counter1 <= 16){
                if (arrayTableData [counter1*3+2] != "0"){
                    if (arrayTableData [counter1*3+1] == "nil"){
                        arrayMark [counter1] = 1;
                        findMark1 = 1;
                    }
                    else arrayMark [counter1] = 0;
                }
                else arrayMark [counter1] = 0;
                
                if (arrayTableData [counter1*3+2] != "0") entryCheck = 1;
            }
            
            if (counter1 >= 19 && counter1 <= 24){
                if (arrayTableData [counter1*3] != "nil"){
                    if (arrayTableData [counter1*3+2] == "0"){
                        arrayMark [counter1] = 1;
                        findMark2 = 1;
                    }
                    else arrayMark [counter1] = 0;
                }
                else arrayMark [counter1] = 0;
            }
        }
        
        //cout<<findMark1<<" "<<findMark2<<"  "<<entryCheck<<" Mark"<<endl;
        
        if (entryCheck == 1){
            if (findMark1 == 1 || findMark2 == 1){
                processPermission = 0;
                [checkStatusDisplay setStringValue:@"None"];
                
                if (findMark1 == 1 && findMark2 == 0){
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Check Treatment Name"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                
                if (findMark1 == 0 && findMark2 == 1){
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Check Color No"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                
                if (findMark1 == 1 && findMark2 == 1){
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Check Treatment Name And Color No"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                
                tableViewCall = 1;
            }
            else{
                
                processPermission = 1;
                [checkStatusDisplay setStringValue:@"Done"];
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
                
                tableViewCall = 1;
            }
        }
        else{
            
            processPermission = 0;
            [checkStatusDisplay setStringValue:@"None"];
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Data Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Ready To Exit"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)processStart:(id)sender{
    if (sendMessageON == 0){
        if (processPermission == 1){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert addButtonWithTitle:@"Cancel"];
            [alert setMessageText:@"Proceed?"];
            [alert setInformativeText:@"Name Assiginment cannot redo after Performing Assiginment."];
            [alert setAlertStyle:NSAlertStyleWarning];
            
            if ([alert runModal] == NSAlertFirstButtonReturn){
                [self processStartSub];
            }
            
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Perform Check"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else if (sendMessageON == 7){
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Ready To Exit"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)processStartSub{
    int folderFindFlag = 0;
    
    DIR *dir;
    struct dirent *dent;
    
    dir = opendir(dataFilesPath.c_str());
    
    if (dir != NULL){
        string entry;
        
        while((dent = readdir(dir))){
            entry = dent -> d_name;
            int findString1 = (int)entry.find("-10001");
            
            if (findString1 != -1){
                folderFindFlag = 1;
                break;
            }
        }
        
        closedir(dir);
    }
    
    if (folderFindFlag != 0){
        string *arrayTransferNameList = new string [totalFOV+10];
        int transferNameListCount = 1;
        string bodyNameTemp;
        
        int *arrayTransferNumberList = new int [totalFOV*2+10];
        int transferNumberListCount = 2; //---------No entry to 0 and 1---------
        
        int sequentialNo = 1;
        int listNumberCount = 1;
        
        for (int counter1 = 1; counter1 <= 16; counter1++){
            if (arrayTableData [counter1*3+2] != "0"){
                bodyNameTemp = arrayTableData [counter1*3+1];
                
                listNumberCount = 1;
                
                for (int counter2 = 0; counter2 < atoi(arrayTableData [counter1*3+2].c_str()); counter2++){
                    arrayTransferNameList [transferNameListCount] = bodyNameTemp, transferNameListCount++;
                    arrayTransferNumberList [transferNumberListCount] = listNumberCount, transferNumberListCount++, listNumberCount++;
                    arrayTransferNumberList [transferNumberListCount] = sequentialNo, transferNumberListCount++, sequentialNo++;
                }
            }
        }
        
        //for (int counterA = 1; counterA <= totalFOV; counterA++){
        //    cout<<" "<<arrayTransferNameList [counterA]<<" "<<arrayTransferNumberList [counterA*2]<<" "<<arrayTransferNumberList [counterA*2+1]<<" arrayData"<<counterA<<endl;
        //}
        
        string dataSaveFolderPath = namedFilesPath+"/"+bodyName+"-10001";
        mkdir(dataSaveFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        string sourceFolderPath = dataFilesPath+"/"+bodyName+"-10001";
        
        string timePoint = "0001";
        string entry;
        string stagePosition;
        string newTreatmentName;
        string fluorescentColor;
        string newFluorescentColor;
        string fluorescentColorNo;
        string sourceFilePath;
        string destinationFilePath;
        
        int findString1 = 0;
        int stagePositionTemp = 0;
        
        for (int counter1 = 1; counter1 <= totalFOV; counter1++){
            fileDeleteCount = 0;
            
            dir = opendir(sourceFolderPath.c_str());
            
            if (dir != NULL){
                while((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                    arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                }
                
                closedir(dir);
                
                for(int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                    entry = arrayFileDelete [counter2];
                    
                    findString1 = (int)entry.find(bodyName);
                    
                    if (findString1 > 0){
                        if (entry.substr((unsigned long)findString1-1, 1) != "_") findString1 = -1;
                    }
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store" && findString1 != -1){
                        findString1 = (int)entry.find("_s");
                        stagePosition = entry.substr((unsigned long)findString1+2, 4);
                        
                        stagePositionTemp = 1;
                        
                        for (int counter3 = 1; counter3 <= totalFOV; counter3++){
                            if (atoi(stagePosition.c_str()) == arrayTransferNumberList [counter3*2+1]){
                                stagePositionTemp = counter3;
                                break;
                            }
                        }
                        
                        newTreatmentName = arrayTransferNameList [stagePositionTemp];
                        stagePosition = to_string(arrayTransferNumberList [stagePositionTemp*2]);
                        
                        if (bodyName.length()+19 != entry.length()) fluorescentColor = entry.substr(bodyName.length()+4, (unsigned long)findString1-bodyName.length()-4);
                        else fluorescentColor = "";
                        
                        if (fluorescentColor != ""){
                            for (int counter3 = 19; counter3 <= 24; counter3++){
                                if (fluorescentColor == arrayTableData [counter3*3]){
                                    newFluorescentColor = arrayTableData [counter3*3+1];
                                    fluorescentColorNo = arrayTableData [counter3*3+2];
                                    break;
                                }
                            }
                        }
                        else newFluorescentColor = "";
                        
                        sourceFilePath = sourceFolderPath+"/"+entry;
                        
                        if (newFluorescentColor == "") destinationFilePath = dataSaveFolderPath+"/"+newTreatmentName+"_"+timePoint+"-"+stagePosition+".tif";
                        else destinationFilePath = dataSaveFolderPath+"/"+newTreatmentName+"_"+timePoint+"-"+stagePosition+"_"+fluorescentColorNo+"_"+newFluorescentColor+".tif";
                        
                        rename (sourceFilePath.c_str(), destinationFilePath.c_str());
                    }
                }
            }
        }
        
        fileDeleteCount = 0;
        
        dir = opendir(sourceFolderPath.c_str());
        
        if (dir != NULL){
            while((dent = readdir(dir))){
                entry = dent -> d_name;
                if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
            }
            
            closedir(dir);
            
            string removeDirectoryPath;
            
            for(int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                entry = arrayFileDelete [counter1];
                
                removeDirectoryPath = sourceFolderPath+"/"+entry;
                remove (removeDirectoryPath.c_str());
            }
        }
        
        rmdir (sourceFolderPath.c_str());
        
        if (processMode != 1){
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        
        if (processMode == 2 || processMode == 4){
            sendMessageON = 2;
            fileInfoSendCall = 1;
        }
        
        delete [] arrayTransferNumberList;
        delete [] arrayTransferNameList;
    }
    else{
        
        processPermission = 1;
        sendMessageON = 7;
        
        [checkStatusDisplay setStringValue:@"R-to-Exit"];
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"***-10001 Folder Missing. Re-do Initial Setting."];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)processStop:(id)sender{
    if (sendMessageON == 0 || sendMessageON == 7){
        [self processStopSub];
    }
}

-(void)fileDeleteUpDate{
    string *arrayUpDate = new string [fileDeleteCount+10];
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayUpDate [counter1] = arrayFileDelete [counter1];
    
    delete [] arrayFileDelete;
    arrayFileDelete = new string [fileDeleteLimit+500];
    fileDeleteLimit = fileDeleteLimit+500;
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayFileDelete [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)processStopSub{
    delete [] arrayTableData;
    delete [] arrayMark;
    delete [] arrayFileDelete;
    
    exit (0);
}

-(void)dealloc{
    if (controllerTimer) [controllerTimer invalidate];
}

@end
