//
//  main.m
//  CellMovie4
//
//  Created by Masahiko Sato on 14/10/02.
//  Copyright Masahiko Sato 2014. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[]){
    return NSApplicationMain(argc, (const char **) argv);
}
