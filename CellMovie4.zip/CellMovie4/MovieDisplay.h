//
//  MovieDisplay.h
//  CellMovie4
//
//  Created by Masahiko Sato on 2014-09-29.
//
//

#ifndef MOVIEDISPLAY_H
#define MOVIEDISPLAY_H
#import "Controller.h"
#endif

@interface MovieDisplay : NSView {
    int firstDisplayFlag; //Set the movie is called the first time
    
    int magnificationDisplay; //Movie operation
    int mouseDragFlag; //Movie operation
    double xPositionDisplay; //Movie operation
    double yPositionDisplay; //Movie operation
    double xPositionAdjustDisplay; //Movie operation
    double yPositionAdjustDisplay; //Movie operation
    double xPointDownDisplay; //Movie operation
    double yPointDownDisplay; //Movie operation
    double xPositionMoveDisplay; //Movie operation
    double yPositionMoveDisplay; //Movie operation
    double xPointDragDisplay; //Movie operation
    double yPointDragDisplay; //Movie operation
    double windowWidthDisplay; //Movie operation
    double windowHeightDisplay; //Movie operation
    
    IBOutlet NSImage *movieImage;
}

-(void)mouseDown:(NSEvent *)event;
-(void)mouseUp:(NSEvent *)event;
-(void)mouseDragged:(NSEvent *)event;
-(void)keyDown:(NSEvent *)event;
-(BOOL)acceptsFirstResponder;
-(void)dealloc;

@end
