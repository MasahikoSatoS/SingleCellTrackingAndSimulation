//
//  DataCheck.h
//  FileUpLoad
//
//  Created by Masahiko Sato on 2022-03-22.
//

#ifndef DATACHECK_H
#define DATACHECK_H
#import "Controller.h"
#endif

@interface DataCheck : NSObject <NSTableViewDataSource>{
    int flImageSizeCur; //Current data
    int singleDualStatusCur;//Current data
    int fluorescentFileNoCountCur;//Current data
    int latestBodyNoHoldCur;//Current data
    int latestTimePointHoldCur;//Current data
    int flImageSizeSave; //Saved data
    int singleDualStatusSave; //Saved data
    int fluorescentFileNoCountSave; //Saved data
    int latestBodyNoHoldSave; //Saved data
    int latestTimePointHoldSave; //Saved data
    
    IBOutlet NSWindow *dataCheckWindow;
    IBOutlet NSTableView *dataCheckList;
    
    NSWindowController *dataCheckWindController;
    
    NSTimer *dataCheckTimer;
}

-(id)init;
-(void)dealloc;
-(void)reDisplayWindow;
-(int)nameCheck:(int)chLength;

-(IBAction)closeWindow:(id)sender;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;
-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex;
-(void)tableView:(NSTableView *)aTableView setObjectValue:(id)anObject forTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;

-(IBAction)currentSet:(id)sender;
-(IBAction)currentSave:(id)sender;
-(IBAction)currentCopy:(id)sender;

@end
