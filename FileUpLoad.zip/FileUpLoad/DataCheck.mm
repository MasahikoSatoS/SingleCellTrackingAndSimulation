//
//  DataCheck.m
//  FileUpLoad
//
//  Created by Masahiko Sato on 2022-03-22.
//

#import "DataCheck.h"

NSString *notificationToDataCheck = @"notificationExecuteDataCheck";

@implementation DataCheck

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToDataCheck object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    dataCheckWindController = [[NSWindowController alloc] initWithWindowNibName:@"UpLoadData"];
    [dataCheckWindController showWindow:self];
    
    string getString;
    
    ifstream fin;
    fin.open(fileDataPath.c_str(),ios::in);
    
    if (fin.is_open()){
        getline(fin, getString), flImageSizeCur = atoi(getString.c_str());
        getline(fin, getString), singleDualStatusCur = atoi(getString.c_str());
        getline(fin, getString), fluorescentCurrent1 = getString;
        getline(fin, getString), fluorescentCurrent2 = getString;
        getline(fin, getString), fluorescentCurrent3 = getString;
        getline(fin, getString), fluorescentCurrent4 = getString;
        getline(fin, getString), fluorescentCurrent5 = getString;
        getline(fin, getString), fluorescentCurrent6 = getString;
        getline(fin, getString), fluorescentFileNoCountCur = atoi(getString.c_str());
        getline(fin, getString), latestBodyNoHoldCur = atoi(getString.c_str());
        getline(fin, getString), latestTimePointHoldCur = atoi(getString.c_str());
        fin.close();
    }
    else{
        
        flImageSizeCur = 0;
        singleDualStatusCur = 0;
        fluorescentCurrent1 = "nil";
        fluorescentCurrent2 = "nil";
        fluorescentCurrent3 = "nil";
        fluorescentCurrent4 = "nil";
        fluorescentCurrent5 = "nil";
        fluorescentCurrent6 = "nil";
        fluorescentFileNoCountCur = 0;
        latestBodyNoHoldCur = 0;
        latestTimePointHoldCur = 0;
    }
    
    fin.open(fileDataSavePath.c_str(),ios::in);
    
    if (fin.is_open()){
        getline(fin, getString), flImageSizeSave = atoi(getString.c_str());
        getline(fin, getString), singleDualStatusSave = atoi(getString.c_str());
        getline(fin, getString), fluorescentSave1 = getString;
        getline(fin, getString), fluorescentSave2 = getString;
        getline(fin, getString), fluorescentSave3 = getString;
        getline(fin, getString), fluorescentSave4 = getString;
        getline(fin, getString), fluorescentSave5 = getString;
        getline(fin, getString), fluorescentSave6 = getString;
        getline(fin, getString), fluorescentFileNoCountSave = atoi(getString.c_str());
        getline(fin, getString), latestBodyNoHoldSave = atoi(getString.c_str());
        getline(fin, getString), latestTimePointHoldSave = atoi(getString.c_str());
        fin.close();
    }
    else{
        
        flImageSizeSave = 0;
        singleDualStatusSave = 0;
        fluorescentSave1 = "nil";
        fluorescentSave2 = "nil";
        fluorescentSave3 = "nil";
        fluorescentSave4 = "nil";
        fluorescentSave5 = "nil";
        fluorescentSave6 = "nil";
        fluorescentFileNoCountSave = 0;
        latestBodyNoHoldSave = 0;
        latestTimePointHoldSave = 0;
    }
}

-(void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [dataCheckWindow frame];
    CGFloat windowHeight = windowSize.size.height;
    
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [dataCheckWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    [dataCheckList setDataSource:self];
}
-(int)numberOfRowsInTableView:(NSTableView *)aTableView{
    int tableViewContent = 11;
    return tableViewContent;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    NSAttributedString *attrStr;
    
    string displayData1;
    string displayData2;
    
    if (rowIndex == 0) displayData1 = to_string(flImageSizeSave), displayData2 = to_string(flImageSizeCur);
    else if (rowIndex == 1){
        if (singleDualStatusSave == 0) displayData1 = "Single";
        else if (singleDualStatusSave == 1) displayData1 = "Dual";
        
        if (singleDualStatusCur == 0) displayData2 = "Single";
        else if (singleDualStatusCur == 1) displayData2 = "Dual";
    }
    else if (rowIndex == 2) displayData1 = fluorescentSave1, displayData2 = fluorescentCurrent1;
    else if (rowIndex == 3) displayData1 = fluorescentSave2, displayData2 = fluorescentCurrent2;
    else if (rowIndex == 4) displayData1 = fluorescentSave3, displayData2 = fluorescentCurrent3;
    else if (rowIndex == 5) displayData1 = fluorescentSave4, displayData2 = fluorescentCurrent4;
    else if (rowIndex == 6) displayData1 = fluorescentSave5, displayData2 = fluorescentCurrent5;
    else if (rowIndex == 7) displayData1 = fluorescentSave6, displayData2 = fluorescentCurrent6;
    else if (rowIndex == 8) displayData1 = to_string(fluorescentFileNoCountSave), displayData2 = to_string(fluorescentFileNoCountCur);
    else if (rowIndex == 9) displayData1 = to_string(latestBodyNoHoldSave), displayData2 = to_string(latestBodyNoHoldCur);
    else if (rowIndex == 10) displayData1 = to_string(latestTimePointHoldSave), displayData2 = to_string(latestTimePointHoldCur);
    
    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
    [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
    [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
    
    if ([[aTableColumn identifier] isEqualToString:@"COL1"]){
        [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL2"]){
        [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(displayData2.c_str()) attributes:attributes];
    }
    else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    
    return attrStr;
}

-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex{
    tableCallCount++;
    
    if (tableCallCount == 2) tableCurrentRowHold = rowIndexHold;
    else if (tableCallCount == 1) tableCurrentRowHold = rowIndex;
    
    return YES;
}

- (void)tableView:(NSTableView *)aTableView setObjectValue:(id)anObject forTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex {
    NSString *columnIdentifier = [aTableColumn identifier];
    NSString *objectInfo = anObject;
    
    ofstream oin;
    
    if (rowIndex == 0 && [columnIdentifier isEqualToString:@"COL2"]){
        nameCheckString = [objectInfo UTF8String];
        int inputValue = atoi(nameCheckString.c_str());
        
        if (inputValue > 0) flImageSizeCur = inputValue;
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else if (rowIndex == 1 && [columnIdentifier isEqualToString:@"COL2"]){
        nameCheckString = [objectInfo UTF8String];
        
        if (nameCheckString == "Single") singleDualStatusCur = 0;
        else if (nameCheckString == "Dual") singleDualStatusCur = 1;
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else if (rowIndex == 2 && [columnIdentifier isEqualToString:@"COL2"]){
        nameCheckString = [objectInfo UTF8String];
        
        int chLength = 3;
        int errorResult = [self nameCheck:chLength];
        
        if (nameCheckString != "nil" && errorResult == 0) fluorescentCurrent1 = nameCheckString;
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else if (rowIndex == 3 && [columnIdentifier isEqualToString:@"COL2"]){
        nameCheckString = [objectInfo UTF8String];
        
        int chLength = 3;
        int errorResult = [self nameCheck:chLength];
        
        if (nameCheckString != "nil" && errorResult == 0) fluorescentCurrent2 = nameCheckString;
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else if (rowIndex == 4 && [columnIdentifier isEqualToString:@"COL2"]){
        nameCheckString = [objectInfo UTF8String];
        
        int chLength = 3;
        int errorResult = [self nameCheck:chLength];
        
        if (nameCheckString != "nil" && errorResult == 0) fluorescentCurrent3 = nameCheckString;
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else if (rowIndex == 5 && [columnIdentifier isEqualToString:@"COL2"]){
        nameCheckString = [objectInfo UTF8String];
        
        int chLength = 3;
        int errorResult = [self nameCheck:chLength];
        
        if (nameCheckString != "nil" && errorResult == 0) fluorescentCurrent4 = nameCheckString;
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else if (rowIndex == 6 && [columnIdentifier isEqualToString:@"COL2"]){
        nameCheckString = [objectInfo UTF8String];
        
        int chLength = 3;
        int errorResult = [self nameCheck:chLength];
        
        if (nameCheckString != "nil" && errorResult == 0) fluorescentCurrent5 = nameCheckString;
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else if (rowIndex == 7 && [columnIdentifier isEqualToString:@"COL2"]){
        nameCheckString = [objectInfo UTF8String];
        
        int chLength = 3;
        int errorResult = [self nameCheck:chLength];
        
        if (nameCheckString != "nil" && errorResult == 0) fluorescentCurrent6 = nameCheckString;
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else if (rowIndex == 8 && [columnIdentifier isEqualToString:@"COL2"]){
        nameCheckString = [objectInfo UTF8String];
        int inputValue = atoi(nameCheckString.c_str());
        
        if (inputValue > 0) fluorescentFileNoCountCur = inputValue;
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else if (rowIndex == 9 && [columnIdentifier isEqualToString:@"COL2"]){
        nameCheckString = [objectInfo UTF8String];
        int inputValue = atoi(nameCheckString.c_str());
        
        if (inputValue > 0) latestBodyNoHoldCur = inputValue;
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else if (rowIndex == 10 && [columnIdentifier isEqualToString:@"COL2"]){
        nameCheckString = [objectInfo UTF8String];
        int inputValue = atoi(nameCheckString.c_str());
        
        if (inputValue > 0) latestTimePointHoldCur = inputValue;
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)currentSet:(id)sender{
    string getString;
    
    ifstream fin;
    fin.open(fileDataPath.c_str(),ios::in);
    
    if (fin.is_open()){
        getline(fin, getString), flImageSizeCur = atoi(getString.c_str());
        getline(fin, getString), singleDualStatusCur = atoi(getString.c_str());
        getline(fin, getString), fluorescentCurrent1 = getString;
        getline(fin, getString), fluorescentCurrent2 = getString;
        getline(fin, getString), fluorescentCurrent3 = getString;
        getline(fin, getString), fluorescentCurrent4 = getString;
        getline(fin, getString), fluorescentCurrent5 = getString;
        getline(fin, getString), fluorescentCurrent6 = getString;
        getline(fin, getString), fluorescentFileNoCountCur = atoi(getString.c_str());
        getline(fin, getString), latestBodyNoHoldCur = atoi(getString.c_str());
        getline(fin, getString), latestTimePointHoldCur = atoi(getString.c_str());
        fin.close();
    }
    else{
        
        flImageSizeCur = 0;
        singleDualStatusCur = 0;
        fluorescentCurrent1 = "nil";
        fluorescentCurrent2 = "nil";
        fluorescentCurrent3 = "nil";
        fluorescentCurrent4 = "nil";
        fluorescentCurrent5 = "nil";
        fluorescentCurrent6 = "nil";
        fluorescentFileNoCountCur = 0;
        latestBodyNoHoldCur = 0;
        latestTimePointHoldCur = 0;
    }
    
    [dataCheckList reloadData];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)currentSave:(id)sender{
    ofstream oin;
    
    oin.open(fileDataPath.c_str(), ios::out);
    
    if (oin.is_open()){
        oin<<to_string(flImageSizeCur)<<endl;
        oin<<to_string(singleDualStatusCur)<<endl;
        
        oin<<fluorescentCurrent1<<endl;
        oin<<fluorescentCurrent2<<endl;
        oin<<fluorescentCurrent3<<endl;
        oin<<fluorescentCurrent4<<endl;
        oin<<fluorescentCurrent5<<endl;
        oin<<fluorescentCurrent6<<endl;
        
        oin<<to_string(fluorescentFileNoCountCur)<<endl;
        
        oin<<to_string(latestBodyNoHoldCur)<<endl;
        oin<<to_string(latestTimePointHoldCur)<<endl;
        
        oin.close();
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)currentCopy:(id)sender{
    string getString;
    
    ifstream fin;
    fin.open(fileDataSavePath.c_str(),ios::in);
    
    if (fin.is_open()){
        getline(fin, getString), flImageSizeCur = atoi(getString.c_str());
        getline(fin, getString), singleDualStatusCur = atoi(getString.c_str());
        getline(fin, getString), fluorescentCurrent1 = getString;
        getline(fin, getString), fluorescentCurrent2 = getString;
        getline(fin, getString), fluorescentCurrent3 = getString;
        getline(fin, getString), fluorescentCurrent4 = getString;
        getline(fin, getString), fluorescentCurrent5 = getString;
        getline(fin, getString), fluorescentCurrent6 = getString;
        getline(fin, getString), fluorescentFileNoCountCur = atoi(getString.c_str());
        getline(fin, getString), latestBodyNoHoldCur = atoi(getString.c_str());
        getline(fin, getString), latestTimePointHoldCur = atoi(getString.c_str());
        fin.close();
    }
    else{
        
        flImageSizeCur = 0;
        singleDualStatusCur = 0;
        fluorescentCurrent1 = "nil";
        fluorescentCurrent2 = "nil";
        fluorescentCurrent3 = "nil";
        fluorescentCurrent4 = "nil";
        fluorescentCurrent5 = "nil";
        fluorescentCurrent6 = "nil";
        fluorescentFileNoCountCur = 0;
        latestBodyNoHoldCur = 0;
        latestTimePointHoldCur = 0;
    }
    
    [dataCheckList reloadData];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(int)nameCheck:(int)chLength{
    int errorFlag = 0;
    string newAnalysisID = nameCheckString;
    
    if ((int)newAnalysisID.length() < chLength || (int)newAnalysisID.length() > 15) errorFlag = 1;
    if ((int)newAnalysisID.find(" ") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find(",") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find(".") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("/") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find(",") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find(":") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("<") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find(">") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("'") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("[") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("]") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("=") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("+") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("{") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("}") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find(")") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("(") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("*") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("&") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("^") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("%") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("$") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("#") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("@") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("!") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("`") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("~") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("|") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("_") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("-") >= 0) errorFlag = 1;
    
    return errorFlag;
}

-(IBAction)closeWindow:(id)sender{
    [dataCheckWindow orderOut:self];
    dataCheckOperation = 2;
    dataCheckTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
}

-(void)reDisplayWindow{
    if (dataCheckOperation == 3){
        [dataCheckWindow makeKeyAndOrderFront:self];
        dataCheckOperation = 1;
        [dataCheckTimer invalidate];
    }
}

-(void)dealloc{
    if (dataCheckTimer) [dataCheckTimer invalidate];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToDataCheck object:nil];
}

@end
