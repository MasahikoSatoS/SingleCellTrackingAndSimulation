//
//  Controller.mm
//  FileUpLoad
//
//  Created by Masahiko Sato on 11/07/11, 06/06/13 revised.
//  Copyright 2011 Masahiko Sato All rights reserved.
//

#import "Controller.h"

//========Uploading Rule=========
//Initial Loading
//Take files with Largest Body No and Time point
//If other files with a Body No or Time points exist, ask to remove
//If two acquisitions were made, and the second one was terminated before reached the last point, all files will be removed.  In this case redo acquisition
//If any problem occurs during the Initial Setting, use "Interrupt"

//Auto Loading
//Wait required no of files are written
//If the next Time point of files are detected, transfer the incomplete files to Mac, then Mac removes them

//--------Paths----------
string fileDataPath;
string fileDataSavePath;

//--------Arrays----------
string *arrayFileName;
int fileNameCount;
int fileNameLimit;
int *arrayTimeNumber;
int timeNumberCount;
int timeNumberLimit;
int *arrayBodyNumber;
int bodyNumberCount;
int bodyNumberLimit;
string *arrayFileNameTable;
int fileNameTableCount;
int fileNameTableLimit;
string *arraySelectFiles;
int selectFileCount;
int selectFileLimit;
string *arrayFileIFData;

//---------Data Check -------
int dataCheckOperation;
int tableCallCount;
int tableCurrentRowHold;
int rowIndexHold;
string fluorescentCurrent1;
string fluorescentCurrent2;
string fluorescentCurrent3;
string fluorescentCurrent4;
string fluorescentCurrent5;
string fluorescentCurrent6;
string fluorescentSave1;
string fluorescentSave2;
string fluorescentSave3;
string fluorescentSave4;
string fluorescentSave5;
string fluorescentSave6;
string nameCheckString;

@implementation Controller

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSString *currentDirectoryPathNSString = [[NSBundle mainBundle] bundlePath];
        string userPathNameString = [currentDirectoryPathNSString cStringUsingEncoding:NSUTF8StringEncoding];
        
        if (userPathNameString.length() == 0) exit (0);
        else if ((int)userPathNameString.find("/Users/") == -1) exit (0);
        else{
            
            string pathName2 = userPathNameString.substr((unsigned long)userPathNameString.find("/Users/")+7);
            pathNameString = pathName2.substr(0, (unsigned long)pathName2.find("/"));
        }
        
        dataCheckOperation = 0;
        tableCallCount = 0;
        tableCurrentRowHold = 0;
        rowIndexHold = 0;
        
        firstCommunication = 0;
        fileUpLoadingFlag = 0;
        exitFlag = 0;
        basicInfoRead = 0;
        fileSizeSetFlag = 0;
        initialUploadStart = 0;
        fileListCheckFlag = 0;
        fileSingleDualFlag = 0;
        fluorescentNameFlag = 0;
        tableViewCall = 0;
        fileInfoSendCall = 0;
        autoLoadingControlFlag = 0;
        interruptionFlag = 0;
        loadingCount = 0;
        autoUploadStart = 0;
        sendMessageON = 0;
        copyStartFlag = 0;
        copyStartFlag2 = 0;
        incrementCount = 0;
        lowestTimeAuto = -1;
        lowestBodyNumberAuto = -1;
        progressValue = 0;
        progressTiming = 0;
        readingTimingFlag = 0;
    }
    
    return self;
}

-(void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat xLength = screenRect.size.width;
    CGFloat yLength = screenRect.size.height;
    int mainControllerX = 800;
    
    NSRect windowSize = [controllerWindow frame];
    CGFloat windowWidth = windowSize.size.width;
    CGFloat windowHeight = windowSize.size.height;
    int displayPositionType = 0;
    
    if (80+mainControllerX+5+windowWidth+5+80 > xLength) displayPositionType = 1;
    
    CGFloat displayX;
    
    if (displayPositionType == 1) displayX = 550;
    else displayX = 80+mainControllerX+5;
    
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [controllerWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    [tableViewList setDataSource:self];
}

-(void)applicationDidFinishLaunching:(NSNotification*)notification{
    fileDataPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/FLFileData";
    fileDataSavePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/FLFileDataHold";
    fileIFDataPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/FLFileIFData";
    importFolder = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"01_Data_Import";
    loadingCompletePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/FLComplete1";
    
    string analysisDataPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/AnalysisSetting";
    string getString;
    
    ifstream fin;
    fin.open(fileDataPath.c_str(),ios::in);
    
    if (fin.is_open()){
        getline(fin, getString), fileImageSize = atoi(getString.c_str());
        getline(fin, getString), singleDualStatus = atoi(getString.c_str());
        getline(fin, getString), fluorescent1 = getString;
        getline(fin, getString), fluorescent2 = getString;
        getline(fin, getString), fluorescent3 = getString;
        getline(fin, getString), fluorescent4 = getString;
        getline(fin, getString), fluorescent5 = getString;
        getline(fin, getString), fluorescent6 = getString;
        getline(fin, getString), fluorescentFileNoCount = atoi(getString.c_str());
        getline(fin, getString), latestBodyNoHold = atoi(getString.c_str());
        getline(fin, getString), latestTimePointHold = atoi(getString.c_str());
        fin.close();
        
        if (singleDualStatus == 1) [singleDualDisplay setStringValue:@"DIC"];
        if (singleDualStatus == 2) [singleDualDisplay setStringValue:@"DIC+FLU"];
        
        [fluorescentDisplay1 setStringValue:@(fluorescent1.c_str())];
        [fluorescentDisplay2 setStringValue:@(fluorescent2.c_str())];
        [fluorescentDisplay3 setStringValue:@(fluorescent3.c_str())];
        [fluorescentDisplay4 setStringValue:@(fluorescent4.c_str())];
        [fluorescentDisplay5 setStringValue:@(fluorescent5.c_str())];
        [fluorescentDisplay6 setStringValue:@(fluorescent6.c_str())];
    }
    else{
        
        fileImageSize = 0;
        singleDualStatus = 0;
        fluorescent1 = "nil";
        fluorescent2 = "nil";
        fluorescent3 = "nil";
        fluorescent4 = "nil";
        fluorescent5 = "nil";
        fluorescent6 = "nil";
        fluorescentFileNoCount = 0;
    }
    
    fin.open(analysisDataPath.c_str(),ios::in);
    
    if (fin.is_open()){
        getline(fin, getString);
        getline(fin, getString), flComputerDataName = getString;
        getline(fin, getString);
        getline(fin, getString), flUserName = getString;
        fin.close();
    }
    else{
        
        flComputerDataName = "nil";
        flUserName = "nil";
    }
    
    flProcessName = "nil";
    
    string directoryDataPath2 = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/DirectoryData";
    
    dataDirectoryPath = "nil";
    string informationDirectoryPath = "nil";
    
    fin.open(directoryDataPath2.c_str(),ios::in);
    
    if (fin.is_open()){
        getline(fin, getString),
        dataDirectoryPath = getString;
        
        getline(fin, getString), informationDirectoryPath = getString;
        
        fin.close();
    }
    
    [autoInitStatus setStringValue:@"None"];
    
    string tifExtSave = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/FLTifExt";
    
    fin.open(tifExtSave.c_str(), ios::out);
    
    if (fin.is_open()){
        getline(fin, getString), tiffExtension = getString;
        
        fin.close();
    }
    else tiffExtension = ".TIF";
    
    [tiffExtDisplay setStringValue:@(tiffExtension.c_str())];
    
    if (dataDirectoryPath != "nil" && informationDirectoryPath != "nil"){
        directoryPathForPC = dataDirectoryPath;
        
        //FileUpLoadingFlag = 1, flComputerDataName = "Confocal", flUserName = "Ann", flProcessName = "Name", totalFOVNoHold = "8", autoLoadingControlFlag = 0, fluorescentFileNoCount = 0; //========================
        //FileImageSize = 0, singleDualStatus = 0, fluorescent1 = "nil", fluorescent2 = "nil", fluorescent3 = "nil", fluorescentFileNoCount = 0, fileUpLoadingFlag = 2, flComputerDataName = "Confocal", flUserName = "Ann", flProcessName = "BaseName", totalFOVNoHold = "8"; //=====================
        
        arrayFileName = new string [500];
        fileNameCount = 0;
        fileNameLimit = 500;
        arrayTimeNumber = new int [500];
        timeNumberCount = 0;
        timeNumberLimit = 500;
        arrayBodyNumber = new int [500];
        bodyNumberCount = 0;
        bodyNumberLimit = 500;
        arrayFileNameTable = new string [500];
        fileNameTableCount = 0;
        fileNameTableLimit = 500;
        arraySelectFiles = new string [1000];
        selectFileCount = 0;
        selectFileLimit = 1000;
        arrayFileIFData = new string [50];
        
        int fileIFDataCount = 0;
        
        fin.open(fileIFDataPath.c_str(),ios::in);
        
        if (fin.is_open()){
            for (int counter1 = 0; counter1 < 6; counter1++){
                getline(fin, getString);
                
                if (getString != "") arrayFileIFData [fileIFDataCount] = getString, fileIFDataCount++;
                else{
                    
                    break;
                }
            }
            
            fin.close();
        }
        
        arrayDirectoryInfoHold = new string [10000];
        directoryInfoHoldCount = 0;
        directoryInfoHoldLimit = 10000;
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTermination object:self];
        timerFL = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(display) userInfo:nil repeats:YES];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Directory Path Error"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
        
        exit(0);
    }
}

-(IBAction)quitProcess:(id)sender{
    int loadingCompleteFlag = 0;
    
    ifstream fin;
    fin.open(loadingCompletePath.c_str(),ios::in);
    
    if (fin.is_open()){
        loadingCompleteFlag = 1;
        fin.close();
    }
    
    if (loadingCompleteFlag == 1){
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"Cancel"];
        [alert addButtonWithTitle:@"Quit"];
        [alert setMessageText:@"Files Currently Processing"];
        [alert setInformativeText:@"Exit stops uploade. Wait for FUP/NAS display"];
        [alert setAlertStyle:NSAlertStyleWarning];
        
        if ([alert runModal] == NSAlertSecondButtonReturn){
            remove (loadingCompletePath.c_str());
            
            if (initialUploadStart == 1 || autoUploadStart == 1) exitFlag = 1;
            else exitFlag = 2;
        }
    }
    else if (fileUpLoadingFlag == 4 || fileUpLoadingFlag == 40){
        if (exitFlag != 3) exitFlag = 3;
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else if (initialUploadStart == 1 || autoUploadStart == 1) exitFlag = 1;
    else exitFlag = 2;
}

-(void)processStopSub{
    if (timerFL) [timerFL invalidate];
    
    delete [] arrayFileName;
    delete [] arrayTimeNumber;
    delete [] arrayBodyNumber;
    delete [] arrayFileNameTable;
    delete [] arraySelectFiles;
    delete [] arrayFileIFData;
    delete [] arrayDirectoryInfoHold;
    
    exit (0);
}

-(void)display{
    if (tableViewCall == 1){
        tableViewCall = 0;
        [tableViewList reloadData];
    }
    
    if (exitFlag == 2){
        exitFlag = 0;
        [self processStopSub]; //------Exit in the event that Controller stops---------
    }
    
    if (exitFlag == 3){
        string entry;
        int findFlag = 0;
        
        DIR *dir;
        struct dirent *dent;
        
        dir = opendir(importFolder.c_str());
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                    findFlag = 1;
                    break;
                }
            }
            
            closedir (dir);
        }
        
        string dataFilesPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"02_Data_Files";
        
        dir = opendir(dataFilesPath.c_str());
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                    findFlag = 1;
                    break;
                }
            }
            
            closedir (dir);
        }
        
        if (findFlag == 0) [self processStopSub];
    }
    
    //-----Initial uploading------
    if (fileUpLoadingFlag == 2){
        if (initialUploadStart == 1){
            if (fileListCheckFlag == 0 && interruptionFlag == 0){
                fileNoMinimalHold = 0;
                [self fileListCheck];
            }
            if (fileListCheckFlag == 0 && interruptionFlag == 1) [self interruption];
        }
        
        if (initialUploadStart == 1 && fileListCheckFlag == 1){
            if (fileSingleDualFlag == 0 && interruptionFlag == 0) [self singleDualFind];
            if (fileSingleDualFlag == 0 && interruptionFlag == 1) [self interruption];
        }
        
        if (initialUploadStart == 1 && fileSingleDualFlag == 1 && singleDualStatus == 2){
            if (fluorescentNameFlag == 0 && singleDualStatus == 2 && interruptionFlag == 0){
                fileSingleDualFlag = 1;
                [self fluorescentNameFind];
            }
            if (fluorescentNameFlag == 0 && singleDualStatus == 2 && interruptionFlag == 1){
                fileSingleDualFlag = 1;
                [self interruption];
            }
        }
        
        if (initialUploadStart == 1 && ((fileSingleDualFlag == 1 && singleDualStatus == 2 && fluorescentNameFlag == 1) || singleDualStatus == 1)){
            if ((fileSizeSetFlag == 0 || fileImageSize == 0) && interruptionFlag == 0 && readingTimingFlag == 0){
                readingTimingFlag = 1;
                [self fileSizeDetermination];
            }
            if ((fileSizeSetFlag == 0 || fileImageSize == 0) && interruptionFlag == 1) [self interruption];
        }
        
        if (fileSizeSetFlag >= 1){
            [loadingStatus setStringValue:@"File UpLoading"];
            
            if (fileSizeSetFlag == 1) fileSizeSetFlag = 2;
            if (fileSizeSetFlag < 4){
                fileSizeSetFlag++;
                
                if (fileSizeSetFlag == 4) [self initialFileUpLoad];
            }
        }
    }
    
    //----IF initial uploading----
    if (fileUpLoadingFlag == 3){
        if (initialUploadStart == 1){
            if (fileListCheckFlag == 0 && interruptionFlag == 0){
                fileNoMinimalHold = 0;
                [self fileListCheckIF];
            }
            if (fileListCheckFlag == 0 && interruptionFlag == 1) [self interruption];
        }
        
        if (initialUploadStart == 1 && fileListCheckFlag == 1){
            if (fileSingleDualFlag == 0 && interruptionFlag == 0) [self singleDualFindIF];
            if (fileSingleDualFlag == 0 && interruptionFlag == 1) [self interruption];
        }
        
        if (initialUploadStart == 1 && fileSingleDualFlag == 1 && singleDualStatus == 2){
            if (fluorescentNameFlag == 0 && singleDualStatus == 2 && interruptionFlag == 0){
                fileSingleDualFlag = 1;
                [self fluorescentNameFind];
            }
            if (fluorescentNameFlag == 0 && singleDualStatus == 2 && interruptionFlag == 1){
                fileSingleDualFlag = 1;
                [self interruption];
            }
        }
        
        if (initialUploadStart == 1 && ((fileSingleDualFlag == 1 && singleDualStatus == 2 && fluorescentNameFlag == 1) || singleDualStatus == 1)){
            if ((fileSizeSetFlag == 0 || fileImageSize == 0) && interruptionFlag == 0 && readingTimingFlag == 0){
                readingTimingFlag = 1;
                [self fileSizeDeterminationIF];
            }
            if ((fileSizeSetFlag == 0 || fileImageSize == 0) && interruptionFlag == 1) [self interruption];
        }
        
        if (fileSizeSetFlag >= 1){
            [loadingStatus setStringValue:@"File UpLoading"];
            
            if (fileSizeSetFlag == 1) fileSizeSetFlag = 2;
            if (fileSizeSetFlag < 4){
                fileSizeSetFlag++;
                
                if (fileSizeSetFlag == 4) [self initialFileUpLoad];
            }
        }
    }
    
    //-----Auto uploading-----
    if ((fileUpLoadingFlag == 1 || fileUpLoadingFlag == 9 || fileUpLoadingFlag == 40) && autoLoadingControlFlag == 0) autoLoadingControlFlag = 2;
    else if ((fileUpLoadingFlag == 1 || fileUpLoadingFlag == 9 || fileUpLoadingFlag == 40) && autoLoadingControlFlag < 5){
        autoLoadingControlFlag++;
        
        if (autoLoadingControlFlag == 5) autoLoadingControlFlag = 6;
    }
    else if ((fileUpLoadingFlag == 1 || fileUpLoadingFlag == 9 || fileUpLoadingFlag == 40) && autoLoadingControlFlag == 6){
        autoLoadingControlFlag = 7;
        
        string entry;
        string timePointSelect;
        string tempName;
        string bodyNameExtract;
        string lastString;
        string bodyNumber;
        string timePoint;
        string examFileName;
        string examFilePath;
        
        int bodyNumberTemp = 0;
        int timePointTemp = 0;
        int terminationFlag = 0;
        
        ifstream fin;
        
        directoryInfoHoldCount = 0;
        
        int nextPointInformation [10];
        
        for (int counter1 = 0; counter1 < 10; counter1++) nextPointInformation [counter1] = 10000;
        
        int breakFlag = 0;
        int nextTimeStart = 0;
        
        //cout<<latestBodyNoHold<<" "<<latestTimePointHold<<" LatestBodyTime"<<endl;
        
        [searchBodyNo setIntegerValue:latestBodyNoHold];
        [searchTime setIntegerValue:latestTimePointHold];
        
        for (int counter1 = latestBodyNoHold; counter1 < latestBodyNoHold+10; counter1++){
            if (counter1 == latestBodyNoHold) nextTimeStart = latestTimePointHold;
            else nextTimeStart = 0;
            
            breakFlag = 0;
            
            //cout<<counter1<<" "<<latestBodyNoHold<<" "<<nextTimeStart<<" "<<counter1<<" bodyNoTimeA"<<endl;
            
            for (int counter2 = nextTimeStart+1; counter2 < nextTimeStart+10; counter2++){
                examFileName = "";
                
                if (singleDualStatus == 1){
                    if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_s1_t"+to_string(counter2)+tiffExtension;
                    else examFileName = flProcessName+"_s1_t"+to_string(counter2)+tiffExtension;
                }
                else if (singleDualStatus == 2 && fluorescentFileNoCount == 1){
                    if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w2IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                    else examFileName = flProcessName+"_w2IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                }
                else if (singleDualStatus == 2 && fluorescentFileNoCount == 2){
                    if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w3IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                    else examFileName = flProcessName+"_w3IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                }
                else if (singleDualStatus == 2 && fluorescentFileNoCount == 3){
                    if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w4IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                    else examFileName = flProcessName+"_w4IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                }
                else if (singleDualStatus == 2 && fluorescentFileNoCount == 4){
                    if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w5IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                    else examFileName = flProcessName+"_w5IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                }
                else if (singleDualStatus == 2 && fluorescentFileNoCount == 5){
                    if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w6IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                    else examFileName = flProcessName+"_w6IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                }
                else if (singleDualStatus == 2 && fluorescentFileNoCount == 6){
                    if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w7IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                    else examFileName = flProcessName+"_w7IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                }
                
                if (examFileName == ""){
                    if (singleDualStatus == 2 && fluorescentFileNoCount == 1){
                        if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w2DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        else examFileName = flProcessName+"_w2DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                    }
                    else if (singleDualStatus == 2 && fluorescentFileNoCount == 2){
                        if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w3DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        else examFileName = flProcessName+"_w3DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                    }
                    else if (singleDualStatus == 2 && fluorescentFileNoCount == 3){
                        if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w4DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        else examFileName = flProcessName+"_w4DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                    }
                    else if (singleDualStatus == 2 && fluorescentFileNoCount == 4){
                        if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w5DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        else examFileName = flProcessName+"_w5DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                    }
                    else if (singleDualStatus == 2 && fluorescentFileNoCount == 5){
                        if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w6DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        else examFileName = flProcessName+"_w6DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                    }
                    else if (singleDualStatus == 2 && fluorescentFileNoCount == 6){
                        if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w7DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        else examFileName = flProcessName+"_w7DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                    }
                }
                
                examFilePath = directoryPathForPC+"/"+examFileName;
                
                fin.open(examFilePath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    fin.close();
                    
                    nextPointInformation [0] = counter1;
                    nextPointInformation [1] = counter2;
                    
                    breakFlag = 1;
                    break;
                }
            }
            
            if (breakFlag == 1){
                break;
            }
        }
        
        if (nextPointInformation [0] != 10000){
            for (int counter1 = nextPointInformation [0]; counter1 < nextPointInformation [0]+10; counter1++){
                if (counter1 == nextPointInformation [0]) nextTimeStart = nextPointInformation [1];
                else nextTimeStart = 0;
                
                breakFlag = 0;
                
                //cout<<nextPointInformation [0]<<" "<<nextTimeStart<<" "<<counter1<<" bodyNoTime"<<endl;
                
                for (int counter2 = nextTimeStart+1; counter2 < nextTimeStart+10; counter2++){
                    examFileName = "";
                    
                    if (singleDualStatus == 1){
                        if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_s1_t"+to_string(counter2)+tiffExtension;
                        else examFileName = flProcessName+"_s1_t"+to_string(counter2)+tiffExtension;
                    }
                    else if (singleDualStatus == 2 && fluorescentFileNoCount == 1){
                        if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w2IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        else examFileName = flProcessName+"_w2IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        
                    }
                    else if (singleDualStatus == 2 && fluorescentFileNoCount == 2){
                        if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w3IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        else examFileName = flProcessName+"_w3IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        
                    }
                    else if (singleDualStatus == 2 && fluorescentFileNoCount == 3){
                        if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w4IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        else examFileName = flProcessName+"_w4IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                    }
                    else if (singleDualStatus == 2 && fluorescentFileNoCount == 4){
                        if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w5IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        else examFileName = flProcessName+"_w5IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        
                    }
                    else if (singleDualStatus == 2 && fluorescentFileNoCount == 5){
                        if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w6IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        else examFileName = flProcessName+"_w6IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        
                    }
                    else if (singleDualStatus == 2 && fluorescentFileNoCount == 6){
                        if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w7IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        else examFileName = flProcessName+"_w7IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                    }
                    
                    if (examFileName == ""){
                        if (singleDualStatus == 2 && fluorescentFileNoCount == 1){
                            if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w2DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                            else examFileName = flProcessName+"_w2DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                            
                        }
                        else if (singleDualStatus == 2 && fluorescentFileNoCount == 2){
                            if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w3DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                            else examFileName = flProcessName+"_w3DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                            
                        }
                        else if (singleDualStatus == 2 && fluorescentFileNoCount == 3){
                            if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w4DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                            else examFileName = flProcessName+"_w4DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        }
                        else if (singleDualStatus == 2 && fluorescentFileNoCount == 4){
                            if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w5DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                            else examFileName = flProcessName+"_w5DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                            
                        }
                        else if (singleDualStatus == 2 && fluorescentFileNoCount == 5){
                            if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w6DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                            else examFileName = flProcessName+"_w6DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                            
                        }
                        else if (singleDualStatus == 2 && fluorescentFileNoCount == 6){
                            if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w7DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                            else examFileName = flProcessName+"_w7DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        }
                    }
                    
                    examFilePath = directoryPathForPC+"/"+examFileName;
                    
                    fin.open(examFilePath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.close();
                        
                        nextPointInformation [2] = counter1;
                        nextPointInformation [3] = counter2;
                        
                        breakFlag = 1;
                        break;
                    }
                }
                
                if (breakFlag == 1){
                    break;
                }
            }
        }
        
        if (nextPointInformation [2] != 10000){
            for (int counter1 = nextPointInformation [2]; counter1 < nextPointInformation [2]+10; counter1++){
                if (counter1 == nextPointInformation [2]) nextTimeStart = nextPointInformation [3];
                else nextTimeStart = 0;
                
                breakFlag = 0;
                
                for (int counter2 = nextTimeStart+1; counter2 < nextTimeStart+10; counter2++){
                    examFileName = "";
                    
                    if (singleDualStatus == 1){
                        if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_s1_t"+to_string(counter2)+tiffExtension;
                        else examFileName = flProcessName+"_s1_t"+to_string(counter2)+tiffExtension;
                    }
                    else if (singleDualStatus == 2 && fluorescentFileNoCount == 1){
                        if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w2IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        else examFileName = flProcessName+"_w2IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                    }
                    else if (singleDualStatus == 2 && fluorescentFileNoCount == 2){
                        if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w3IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        else examFileName = flProcessName+"_w3IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                    }
                    else if (singleDualStatus == 2 && fluorescentFileNoCount == 3){
                        if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w4IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        else examFileName = flProcessName+"_w4IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                    }
                    else if (singleDualStatus == 2 && fluorescentFileNoCount == 4){
                        if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w5IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        else examFileName = flProcessName+"_w5IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                    }
                    else if (singleDualStatus == 2 && fluorescentFileNoCount == 5){
                        if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w6IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        else examFileName = flProcessName+"_w6IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                    }
                    else if (singleDualStatus == 2 && fluorescentFileNoCount == 6){
                        if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w7IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        else examFileName = flProcessName+"_w7IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                    }
                    
                    if (examFileName == ""){
                        if (singleDualStatus == 2 && fluorescentFileNoCount == 1){
                            if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w2DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                            else examFileName = flProcessName+"_w2DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        }
                        else if (singleDualStatus == 2 && fluorescentFileNoCount == 2){
                            if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w3DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                            else examFileName = flProcessName+"_w3DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        }
                        else if (singleDualStatus == 2 && fluorescentFileNoCount == 3){
                            if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w4DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                            else examFileName = flProcessName+"_w4DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        }
                        else if (singleDualStatus == 2 && fluorescentFileNoCount == 4){
                            if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w5DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                            else examFileName = flProcessName+"_w5DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        }
                        else if (singleDualStatus == 2 && fluorescentFileNoCount == 5){
                            if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w6DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                            else examFileName = flProcessName+"_w6DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        }
                        else if (singleDualStatus == 2 && fluorescentFileNoCount == 6){
                            if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w7DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                            else examFileName = flProcessName+"_w7DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        }
                    }
                    
                    examFilePath = directoryPathForPC+"/"+examFileName;
                    
                    fin.open(examFilePath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.close();
                        
                        nextPointInformation [4] = counter1;
                        nextPointInformation [5] = counter2;
                        
                        breakFlag = 1;
                        break;
                    }
                }
                
                if (breakFlag == 1){
                    break;
                }
            }
        }
        
        if (nextPointInformation [4] != 10000){
            for (int counter1 = nextPointInformation [4]; counter1 < nextPointInformation [4]+10; counter1++){
                if (counter1 == nextPointInformation [4]) nextTimeStart = nextPointInformation [5];
                else nextTimeStart = 0;
                
                breakFlag = 0;
                
                for (int counter2 = nextTimeStart+1; counter2 < nextTimeStart+10; counter2++){
                    examFileName = "";
                    
                    if (singleDualStatus == 1){
                        if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_s1_t"+to_string(counter2)+tiffExtension;
                        else examFileName = flProcessName+"_s1_t"+to_string(counter2)+tiffExtension;
                    }
                    else if (singleDualStatus == 2 && fluorescentFileNoCount == 1){
                        if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w2IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        else examFileName = flProcessName+"_w2IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                    }
                    else if (singleDualStatus == 2 && fluorescentFileNoCount == 2){
                        if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w3IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        else examFileName = flProcessName+"_w3IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                    }
                    else if (singleDualStatus == 2 && fluorescentFileNoCount == 3){
                        if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w4IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        else examFileName = flProcessName+"_w4IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                    }
                    else if (singleDualStatus == 2 && fluorescentFileNoCount == 4){
                        if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w5IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        else examFileName = flProcessName+"_w5IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                    }
                    else if (singleDualStatus == 2 && fluorescentFileNoCount == 5){
                        if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w6IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        else examFileName = flProcessName+"_w6IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                    }
                    else if (singleDualStatus == 2 && fluorescentFileNoCount == 6){
                        if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w7IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        else examFileName = flProcessName+"_w7IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                    }
                    
                    if (examFileName == ""){
                        if (singleDualStatus == 2 && fluorescentFileNoCount == 1){
                            if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w2DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                            else examFileName = flProcessName+"_w2DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        }
                        else if (singleDualStatus == 2 && fluorescentFileNoCount == 2){
                            if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w3DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                            else examFileName = flProcessName+"_w3DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        }
                        else if (singleDualStatus == 2 && fluorescentFileNoCount == 3){
                            if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w4DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                            else examFileName = flProcessName+"_w4DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        }
                        else if (singleDualStatus == 2 && fluorescentFileNoCount == 4){
                            if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w5DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                            else examFileName = flProcessName+"_w5DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        }
                        else if (singleDualStatus == 2 && fluorescentFileNoCount == 5){
                            if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w6DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                            else examFileName = flProcessName+"_w6DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        }
                        else if (singleDualStatus == 2 && fluorescentFileNoCount == 6){
                            if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w7DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                            else examFileName = flProcessName+"_w7DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        }
                    }
                    
                    examFilePath = directoryPathForPC+"/"+examFileName;
                    
                    fin.open(examFilePath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.close();
                        
                        nextPointInformation [6] = counter1;
                        nextPointInformation [7] = counter2;
                        
                        breakFlag = 1;
                        break;
                    }
                }
                
                if (breakFlag == 1){
                    break;
                }
            }
        }
        
        if (nextPointInformation [6] != 10000){
            for (int counter1 = nextPointInformation [6]; counter1 < nextPointInformation [6]+10; counter1++){
                if (counter1 == nextPointInformation [6]) nextTimeStart = nextPointInformation [7];
                else nextTimeStart = 0;
                
                breakFlag = 0;
                
                for (int counter2 = nextTimeStart+1; counter2 < nextTimeStart+10; counter2++){
                    examFileName = "";
                    
                    if (singleDualStatus == 1){
                        if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_s1_t"+to_string(counter2)+tiffExtension;
                        else examFileName = flProcessName+"_s1_t"+to_string(counter2)+tiffExtension;
                    }
                    else if (singleDualStatus == 2 && fluorescentFileNoCount == 1){
                        if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w2IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        else examFileName = flProcessName+"_w2IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        
                    }
                    else if (singleDualStatus == 2 && fluorescentFileNoCount == 2){
                        if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w3IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        else examFileName = flProcessName+"_w3IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                    }
                    else if (singleDualStatus == 2 && fluorescentFileNoCount == 3){
                        if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w4IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        else examFileName = flProcessName+"_w4IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                    }
                    else if (singleDualStatus == 2 && fluorescentFileNoCount == 4){
                        if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w5IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        else examFileName = flProcessName+"_w5IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        
                    }
                    else if (singleDualStatus == 2 && fluorescentFileNoCount == 5){
                        if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w6IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        else examFileName = flProcessName+"_w6IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                    }
                    else if (singleDualStatus == 2 && fluorescentFileNoCount == 6){
                        if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w7IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        else examFileName = flProcessName+"_w7IR DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                    }
                    
                    if (examFileName == ""){
                        if (singleDualStatus == 2 && fluorescentFileNoCount == 1){
                            if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w2DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                            else examFileName = flProcessName+"_w2DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        }
                        else if (singleDualStatus == 2 && fluorescentFileNoCount == 2){
                            if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w3DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                            else examFileName = flProcessName+"_w3DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        }
                        else if (singleDualStatus == 2 && fluorescentFileNoCount == 3){
                            if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w4DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                            else examFileName = flProcessName+"_w4DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        }
                        else if (singleDualStatus == 2 && fluorescentFileNoCount == 4){
                            if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w5DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                            else examFileName = flProcessName+"_w5DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        }
                        else if (singleDualStatus == 2 && fluorescentFileNoCount == 5){
                            if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w6DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                            else examFileName = flProcessName+"_w6DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        }
                        else if (singleDualStatus == 2 && fluorescentFileNoCount == 6){
                            if (counter1 != 0) examFileName = flProcessName+to_string(counter1)+"_w7DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                            else examFileName = flProcessName+"_w7DIC"+"_s1_t"+to_string(counter2)+tiffExtension;
                        }
                    }
                    
                    examFilePath = directoryPathForPC+"/"+examFileName;
                    
                    fin.open(examFilePath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.close();
                        
                        nextPointInformation [8] = counter1;
                        nextPointInformation [9] = counter2;
                        
                        breakFlag = 1;
                        break;
                    }
                }
                
                if (breakFlag == 1){
                    break;
                }
            }
        }
        
        int dicCheck = 0;
        
        //for (int counter1 = 0; counter1 < 5; counter1++){
        //    cout<<nextPointInformation [counter1*2]<<" "<<nextPointInformation [counter1*2+1]<<" Info"<<endl;
        //}
        
        for (int counter1 = 0; counter1 < 5; counter1++){
            bodyNumberTemp = nextPointInformation [counter1*2];
            timePointTemp = nextPointInformation [counter1*2+1];
            
            if (bodyNumberTemp != 10000 && timePointTemp != 10000){
                if (singleDualStatus == 1){
                    for (int counter2 = 1; counter2 < 2000; counter2++){
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        else{
                            
                            break;
                        }
                    }
                }
                else if (singleDualStatus == 2 && fluorescentFileNoCount == 1){
                    for (int counter2 = 1; counter2 < 2000; counter2++){
                        dicCheck = 0;
                        examFileName = "";
                        
                        //----Fluorescent 1----
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w1Wheel 1 "+fluorescent1+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w1Wheel 1 "+fluorescent1+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w1Wheel 2 "+fluorescent1+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w1Wheel 2 "+fluorescent1+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        examFileName = "";
                        
                        //------DIC/IR DIC----
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w2DIC"+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w2DIC"+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                            
                            dicCheck = 1;
                        }
                        
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w2IR DIC"+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w2IR DIC"+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                            
                            dicCheck = 1;
                        }
                        
                        if (dicCheck == 0){
                            break;
                        }
                    }
                }
                else if (singleDualStatus == 2 && fluorescentFileNoCount == 2){
                    for (int counter2 = 1; counter2 < 2000; counter2++){
                        dicCheck = 0;
                        
                        examFileName = "";
                        
                        //----Fluorescent 1----
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w1Wheel 1 "+fluorescent1+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w1Wheel 1 "+fluorescent1+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w1Wheel 2 "+fluorescent1+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w1Wheel 2 "+fluorescent1+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        //----Fluorescent 2----
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w2Wheel 1 "+fluorescent2+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w2Wheel 1 "+fluorescent2+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w2Wheel 2 "+fluorescent2+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w2Wheel 2 "+fluorescent2+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        //------DIC/IR DIC----
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w3DIC"+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w3DIC"+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                            
                            dicCheck = 1;
                        }
                        
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w3IR DIC"+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w3IR DIC"+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                            
                            dicCheck = 1;
                        }
                        
                        if (dicCheck == 0){
                            break;
                        }
                    }
                }
                else if (singleDualStatus == 2 && fluorescentFileNoCount == 3){
                    for (int counter2 = 1; counter2 < 2000; counter2++){
                        dicCheck = 0;
                        examFileName = "";
                        
                        //----Fluorescent 1----
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w1Wheel 1 "+fluorescent1+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w1Wheel 1 "+fluorescent1+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w1Wheel 2 "+fluorescent1+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w1Wheel 2 "+fluorescent1+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        //----Fluorescent 2----
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w2Wheel 1 "+fluorescent2+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w2Wheel 1 "+fluorescent2+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w2Wheel 2 "+fluorescent2+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w2Wheel 2 "+fluorescent2+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        //----Fluorescent 3----
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w3Wheel 1 "+fluorescent3+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w3Wheel 1 "+fluorescent3+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w3Wheel 2 "+fluorescent3+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w3Wheel 2 "+fluorescent3+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        //------DIC/IR DIC----
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w4DIC"+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w4DIC"+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                            
                            dicCheck = 1;
                        }
                        
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w4IR DIC"+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w4IR DIC"+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                            
                            dicCheck = 1;
                        }
                        
                        if (dicCheck == 0){
                            break;
                        }
                    }
                }
                else if (singleDualStatus == 2 && fluorescentFileNoCount == 4){
                    for (int counter2 = 1; counter2 < 2000; counter2++){
                        dicCheck = 0;
                        examFileName = "";
                        
                        //----Fluorescent 1----
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w1Wheel 1 "+fluorescent1+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w1Wheel 1 "+fluorescent1+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w1Wheel 2 "+fluorescent1+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w1Wheel 2 "+fluorescent1+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        //----Fluorescent 2----
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w2Wheel 1 "+fluorescent2+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w2Wheel 1 "+fluorescent2+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w2Wheel 2 "+fluorescent2+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w2Wheel 2 "+fluorescent2+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        //----Fluorescent 3----
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w3Wheel 1 "+fluorescent3+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w3Wheel 1 "+fluorescent3+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w3Wheel 2 "+fluorescent3+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w3Wheel 2 "+fluorescent3+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        //----Fluorescent 4----
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w4Wheel 1 "+fluorescent4+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w4Wheel 1 "+fluorescent4+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w4Wheel 2 "+fluorescent4+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w4Wheel 2 "+fluorescent3+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        //------DIC/IR DIC----
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w5DIC"+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w5DIC"+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                            
                            dicCheck = 1;
                        }
                        
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w5IR DIC"+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w5IR DIC"+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                            
                            dicCheck = 1;
                        }
                        
                        if (dicCheck == 0){
                            break;
                        }
                    }
                }
                else if (singleDualStatus == 2 && fluorescentFileNoCount == 5){
                    for (int counter2 = 1; counter2 < 2000; counter2++){
                        dicCheck = 0;
                        examFileName = "";
                        
                        //----Fluorescent 1----
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w1Wheel 1 "+fluorescent1+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w1Wheel 1 "+fluorescent1+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w1Wheel 2 "+fluorescent1+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w1Wheel 2 "+fluorescent1+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        //----Fluorescent 2----
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w2Wheel 1 "+fluorescent2+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w2Wheel 1 "+fluorescent2+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w2Wheel 2 "+fluorescent2+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w2Wheel 2 "+fluorescent2+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        //----Fluorescent 3----
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w3Wheel 1 "+fluorescent3+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w3Wheel 1 "+fluorescent3+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w3Wheel 2 "+fluorescent3+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w3Wheel 2 "+fluorescent3+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        //----Fluorescent 4----
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w4Wheel 1 "+fluorescent4+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w4Wheel 1 "+fluorescent4+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w4Wheel 2 "+fluorescent4+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w4Wheel 2 "+fluorescent3+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        //----Fluorescent 5----
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w5Wheel 1 "+fluorescent5+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w5Wheel 1 "+fluorescent4+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w5Wheel 2 "+fluorescent5+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w5Wheel 2 "+fluorescent3+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        //------DIC/IR DIC----
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w6DIC"+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w6DIC"+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                            
                            dicCheck = 1;
                        }
                        
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w6IR DIC"+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w6IR DIC"+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                            
                            dicCheck = 1;
                        }
                        
                        if (dicCheck == 0){
                            break;
                        }
                    }
                }
                else if (singleDualStatus == 2 && fluorescentFileNoCount == 6){
                    for (int counter2 = 1; counter2 < 2000; counter2++){
                        dicCheck = 0;
                        examFileName = "";
                        
                        //----Fluorescent 1----
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w1Wheel 1 "+fluorescent1+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w1Wheel 1 "+fluorescent1+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w1Wheel 2 "+fluorescent1+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w1Wheel 2 "+fluorescent1+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        //----Fluorescent 2----
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w2Wheel 1 "+fluorescent2+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w2Wheel 1 "+fluorescent2+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w2Wheel 2 "+fluorescent2+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w2Wheel 2 "+fluorescent2+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        //----Fluorescent 3----
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w3Wheel 1 "+fluorescent3+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w3Wheel 1 "+fluorescent3+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w3Wheel 2 "+fluorescent3+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w3Wheel 2 "+fluorescent3+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        //----Fluorescent 4----
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w4Wheel 1 "+fluorescent4+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w4Wheel 1 "+fluorescent4+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w4Wheel 2 "+fluorescent4+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w4Wheel 2 "+fluorescent3+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        //----Fluorescent 5----
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w5Wheel 1 "+fluorescent5+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w5Wheel 1 "+fluorescent4+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w5Wheel 2 "+fluorescent5+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w5Wheel 2 "+fluorescent3+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        //----Fluorescent 6----
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w6Wheel 1 "+fluorescent5+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w6Wheel 1 "+fluorescent4+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w6Wheel 2 "+fluorescent5+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w6Wheel 2 "+fluorescent3+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                        }
                        
                        //------DIC/IR DIC----
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w7DIC"+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w7DIC"+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                            
                            dicCheck = 1;
                        }
                        
                        examFileName = "";
                        
                        if (bodyNumberTemp != 0) examFileName = flProcessName+to_string(bodyNumberTemp)+"_w7IR DIC"+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        else examFileName = flProcessName+"_w7IR DIC"+"_s"+to_string(counter2)+"_t"+to_string(timePointTemp)+tiffExtension;
                        
                        examFilePath = directoryPathForPC+"/"+examFileName;
                        
                        fin.open(examFilePath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                            arrayDirectoryInfoHold [directoryInfoHoldCount] = examFileName, directoryInfoHoldCount++;
                            
                            dicCheck = 1;
                        }
                        
                        if (dicCheck == 0){
                            break;
                        }
                    }
                }
            }
        }
        
        if (fileUpLoadingFlag == 9 && nextPointInformation [0] == 10000 && nextPointInformation [1] == 10000){
            autoLoadingControlFlag = 20;
            remove(loadingCompletePath.c_str());
            
            terminationFlag = 1;
            
            ofstream oin;
            
            do{
                
                oin.open(loadingCompletePath.c_str(), ios::out);
                
                if (oin.is_open()){
                    oin<<"End"<<endl;
                    oin.close();
                    
                    terminationFlag = 0;
                    fileInfoSendCall = 1;
                    sendMessageON = 1;
                }
                
            } while (terminationFlag == 1);
        }
    }
    else if ((fileUpLoadingFlag == 1 || fileUpLoadingFlag == 9 || fileUpLoadingFlag == 40) && autoLoadingControlFlag == 7){
        int bodyNameLength = (int)flProcessName.length();
        lowestTimeAuto = 100000;
        lowestBodyNumberAuto = 100000; //----------After Processing, those variable hold up-dated numbers----------
        int nextBodyNumber = 0;
        int nextTimePoint = 0;
        int findDicOrder = 0;
        fileNameCount = 0;
        timeNumberCount = 0;
        bodyNumberCount = 0;
        
        if (directoryInfoHoldCount != 0){
            string entry;
            string tempName;
            string bodyNameExtract;
            string lastString;
            string bodyNumber;
            string timePoint;
            int findMatch0 = 0;
            int terminationFlag = 0;
            
            for (int counter1 = 0; counter1 < directoryInfoHoldCount; counter1++){
                entry = arrayDirectoryInfoHold [counter1];
                findMatch0 = (int)entry.find(flProcessName);
                
                if ((int)entry.find("DIC") != -1 && (int)entry.find("_w1") != -1) findDicOrder = 1;
                
                if (findMatch0 > 0){
                    if (entry.substr((unsigned long)findMatch0-1, 1) != "_") findMatch0 = -1;
                }
                
                if (entry != "." && entry != ".." && entry != ".DS_Store" && findMatch0 != -1){
                    bodyNameExtract = entry.substr((unsigned long)findMatch0).substr(0, entry.substr((unsigned long)findMatch0).find("_"));
                    
                    do{
                        
                        terminationFlag = 1;
                        lastString = bodyNameExtract.substr(bodyNameExtract.length()-1, 1);
                        
                        if (lastString == "0" || lastString == "1" || lastString == "2" || lastString == "3" || lastString == "4" || lastString == "5" || lastString == "6" || lastString == "7" || lastString == "8" || lastString == "9"){
                            bodyNameExtract = bodyNameExtract.substr(0, bodyNameExtract.length()-1);
                        }
                        else terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                    
                    if (bodyNameExtract == flProcessName){
                        tempName = entry.substr(entry.find(flProcessName));
                        
                        if ((int)entry.find("_s") != -1){
                            bodyNumber = tempName.substr((unsigned long)bodyNameLength, tempName.find("_")-(unsigned long)bodyNameLength);
                            timePoint = entry.substr(entry.find("_t")+2, entry.find(tiffExtension)-entry.find("_t")-2);
                            
                            if (fileNameCount+5 > fileNameLimit) [self fileNameUpDate];
                            if (timeNumberCount+5 > timeNumberLimit) [self timeNumberUpDate];
                            if (bodyNumberCount+5 > bodyNumberLimit) [self bodyNumberUpDate];
                            
                            arrayFileName [fileNameCount] = entry, fileNameCount++;
                            arrayTimeNumber [timeNumberCount] = atoi(timePoint.c_str()), timeNumberCount++;
                            
                            if (bodyNumber == "") arrayBodyNumber [bodyNumberCount] = 0, bodyNumberCount++;
                            else arrayBodyNumber [bodyNumberCount] = atoi(bodyNumber.c_str()), bodyNumberCount++;
                        }
                    }
                }
            }
        }
        
        if (directoryInfoHoldCount != 0 && fileNameCount != 0){
            string entry2;
            string extractStringTemp2;
            string extractStringTemp3;
            string fluorescentNameTemp;
            string fluoroTemp1;
            string fluoroTemp2;
            string fluoroTemp3;
            string fluoroTemp4;
            string fluoroTemp5;
            string fluoroTemp6;
            
            for (int counter1 = 0; counter1 < fileNameCount; counter1++){
                if (arrayBodyNumber [counter1] < lowestBodyNumberAuto) lowestBodyNumberAuto = arrayBodyNumber [counter1];
                if (arrayBodyNumber [counter1] > nextBodyNumber) nextBodyNumber = arrayBodyNumber [counter1];
            }
            
            if (lowestBodyNumberAuto != 100000){
                for (int counter1 = 0; counter1 < fileNameCount; counter1++){
                    if (arrayTimeNumber [counter1] < lowestTimeAuto && arrayBodyNumber [counter1] == lowestBodyNumberAuto) lowestTimeAuto = arrayTimeNumber [counter1];
                    if (arrayTimeNumber [counter1] > nextTimePoint && arrayBodyNumber [counter1] == nextBodyNumber) nextTimePoint = arrayTimeNumber [counter1];
                }
                
                if (lowestTimeAuto != 100000){
                    int findFlag = 0;
                    string timePointString = to_string(lowestTimeAuto);
                    
                    fileNameTableCount = 0;
                    selectFileCount = 0;
                    
                    for (int counter1 = 0; counter1 < fileNameCount; counter1++){
                        if (arrayBodyNumber [counter1] == lowestBodyNumberAuto && arrayTimeNumber [counter1] == lowestTimeAuto){
                            if (fileNameTableCount+10 > fileNameTableLimit) [self fileNameTableUpDate];
                            if (selectFileCount+10 > selectFileLimit) [self selectFileUpDate];
                            
                            arrayFileNameTable [fileNameTableCount] = arrayFileName [counter1], fileNameTableCount++;
                            arraySelectFiles [selectFileCount] = arrayFileName [counter1], selectFileCount++;
                        }
                    }
                    
                    tableViewCall = 1;
                    
                    //cout<<nextBodyNumber<<" "<<lowestBodyNumberAuto<<" "<<nextTimePoint<<"  "<<lowestTimeAuto<<" "<<fileUpLoadingFlag<<" "<<findFlag<<" Next"<<endl;
                    
                    if (nextBodyNumber > lowestBodyNumberAuto || (nextBodyNumber == lowestBodyNumberAuto && nextTimePoint > lowestTimeAuto) || fileUpLoadingFlag == 9 || fileUpLoadingFlag == 40) findFlag = 1;
                    
                    if (findFlag == 1){
                        NSDictionary *dicVol = [[NSFileManager defaultManager] attributesOfFileSystemForPath: @"/" error:nil];
                        unsigned long freeSize = [[dicVol objectForKey: NSFileSystemFreeSize] unsignedLongLongValue];
                        //---------1073741824, 1Gb limit----------
                        
                        int totalFileNoTemp = 0;
                        
                        if (singleDualStatus == 1) totalFileNoTemp = atoi(totalFOVNoHold.c_str());
                        if (singleDualStatus == 2) totalFileNoTemp = atoi(totalFOVNoHold.c_str())+atoi(totalFOVNoHold.c_str())*fluorescentFileNoCount;
                        
                        unsigned long refSize = (unsigned long)fileImageSize*(unsigned long)totalFileNoTemp*2;
                        
                        //cout<<freeSize<<" "<<fileImageSize<<" "<<totalFileNoTemp<<" "<<fileImageSize*totalFileNoTemp*2<<" size "<<fileUpLoadingFlag<<endl;
                        
                        if (refSize < freeSize && 20971520000 < freeSize){ //-------~20 Gb---------
                            int newIFFind = 0;
                            int findDIC = 0;
                            int multipleWaveLengthFlag = 0;
                            
                            for (int counter1 = 0; counter1 < selectFileCount; counter1++){
                                entry2 = arraySelectFiles [counter1];
                                
                                if ((int)entry2.find("_w") != -1){
                                    multipleWaveLengthFlag = 1;
                                    break;
                                }
                            }
                            
                            if (fileUpLoadingFlag == 40){
                                fluoroTemp1 = "nil";
                                fluoroTemp2 = "nil";
                                fluoroTemp3 = "nil";
                                fluoroTemp4 = "nil";
                                fluoroTemp5 = "nil";
                                fluoroTemp6 = "nil";
                                
                                int fluoroTempCount1 = 0;
                                int fluoroTempCount2 = 0;
                                int fluoroTempCount3 = 0;
                                int fluoroTempCount4 = 0;
                                int fluoroTempCount5 = 0;
                                int fluoroTempCount6 = 0;
                                int findString7 = 0;
                                
                                for (int counter1 = 0; counter1 < selectFileCount; counter1++){
                                    entry2 = arraySelectFiles [counter1];
                                    
                                    if ((int)entry2.find("_w") != -1){
                                        extractStringTemp2 = entry2.substr(entry2.find("_w")+1, entry2.find("_s")-entry2.find("_w")-1);
                                        extractStringTemp2 = extractStringTemp2.substr(extractStringTemp2.find(" ")+1);
                                        
                                        if ((int)extractStringTemp2.find(" ") != -1) fluorescentNameTemp = extractStringTemp2.substr(extractStringTemp2.find(" ")+1);
                                        else fluorescentNameTemp = "nil";
                                        
                                        findString7 = (int)extractStringTemp2.find("DIC");
                                        
                                        if (fluoroTemp1 == "nil" && findString7 == -1) fluoroTemp1 = fluorescentNameTemp, fluoroTempCount1++;
                                        else if (fluoroTemp1 != "nil" && fluoroTemp1 == fluorescentNameTemp && findString7 == -1) fluoroTempCount1++;
                                        else if (fluoroTemp2 == "nil" && findString7 == -1) fluoroTemp2 = fluorescentNameTemp, fluoroTempCount2++;
                                        else if (fluoroTemp2 != "nil" && fluoroTemp2 == fluorescentNameTemp && findString7 == -1) fluoroTempCount2++;
                                        else if (fluoroTemp3 == "nil" && findString7 == -1) fluoroTemp3 = fluorescentNameTemp, fluoroTempCount3++;
                                        else if (fluoroTemp3 != "nil" && fluoroTemp3 == fluorescentNameTemp && findString7 == -1) fluoroTempCount3++;
                                        else if (fluoroTemp4 == "nil" && findString7 == -1) fluoroTemp4 = fluorescentNameTemp, fluoroTempCount4++;
                                        else if (fluoroTemp4 != "nil" && fluoroTemp4 == fluorescentNameTemp && findString7 == -1) fluoroTempCount4++;
                                        else if (fluoroTemp5 == "nil" && findString7 == -1) fluoroTemp5 = fluorescentNameTemp, fluoroTempCount5++;
                                        else if (fluoroTemp5 != "nil" && fluoroTemp5 == fluorescentNameTemp && findString7 == -1) fluoroTempCount5++;
                                        else if (fluoroTemp6 == "nil" && findString7 == -1) fluoroTemp6 = fluorescentNameTemp, fluoroTempCount6++;
                                        else if (fluoroTemp6 != "nil" && fluoroTemp6 == fluorescentNameTemp && findString7 == -1) fluoroTempCount6++;
                                        
                                        if (findString7 != -1) findDIC = 1;
                                    }
                                }
                                
                                int misMatchFind1 = 0;
                                int misMatchFind2 = 0;
                                int misMatchFind3 = 0;
                                int misMatchFind4 = 0;
                                int misMatchFind5 = 0;
                                int misMatchFind6 = 0;
                                
                                if (fluoroTemp1 != "nil"){
                                    if (arrayFileIFData [0] == fluoroTemp1) misMatchFind1 = 1;
                                    if (arrayFileIFData [2] == fluoroTemp1) misMatchFind1 = 2;
                                    if (arrayFileIFData [4] == fluoroTemp1) misMatchFind1 = 3;
                                    if (arrayFileIFData [6] == fluoroTemp1) misMatchFind1 = 4;
                                    if (arrayFileIFData [8] == fluoroTemp1) misMatchFind1 = 5;
                                    if (arrayFileIFData [10] == fluoroTemp1) misMatchFind1 = 6;
                                }
                                
                                if (fluoroTemp2 != "nil"){
                                    if (arrayFileIFData [0] == fluoroTemp2) misMatchFind2 = 1;
                                    if (arrayFileIFData [2] == fluoroTemp2) misMatchFind2 = 2;
                                    if (arrayFileIFData [4] == fluoroTemp2) misMatchFind2 = 3;
                                    if (arrayFileIFData [6] == fluoroTemp2) misMatchFind2 = 4;
                                    if (arrayFileIFData [8] == fluoroTemp2) misMatchFind2 = 5;
                                    if (arrayFileIFData [10] == fluoroTemp2) misMatchFind2 = 6;
                                }
                                
                                if (fluoroTemp3 != "nil"){
                                    if (arrayFileIFData [0] == fluoroTemp3) misMatchFind3 = 1;
                                    if (arrayFileIFData [2] == fluoroTemp3) misMatchFind3 = 2;
                                    if (arrayFileIFData [4] == fluoroTemp3) misMatchFind3 = 3;
                                    if (arrayFileIFData [6] == fluoroTemp3) misMatchFind3 = 4;
                                    if (arrayFileIFData [8] == fluoroTemp3) misMatchFind3 = 5;
                                    if (arrayFileIFData [10] == fluoroTemp3) misMatchFind3 = 6;
                                }
                                
                                if (fluoroTemp4 != "nil"){
                                    if (arrayFileIFData [0] == fluoroTemp4) misMatchFind4 = 1;
                                    if (arrayFileIFData [2] == fluoroTemp4) misMatchFind4 = 2;
                                    if (arrayFileIFData [4] == fluoroTemp4) misMatchFind4 = 3;
                                    if (arrayFileIFData [6] == fluoroTemp4) misMatchFind4 = 4;
                                    if (arrayFileIFData [8] == fluoroTemp4) misMatchFind4 = 5;
                                    if (arrayFileIFData [10] == fluoroTemp4) misMatchFind4 = 6;
                                }
                                
                                if (fluoroTemp5 != "nil"){
                                    if (arrayFileIFData [0] == fluoroTemp5) misMatchFind5 = 1;
                                    if (arrayFileIFData [2] == fluoroTemp5) misMatchFind5 = 2;
                                    if (arrayFileIFData [4] == fluoroTemp5) misMatchFind5 = 3;
                                    if (arrayFileIFData [6] == fluoroTemp5) misMatchFind5 = 4;
                                    if (arrayFileIFData [8] == fluoroTemp5) misMatchFind5 = 5;
                                    if (arrayFileIFData [10] == fluoroTemp5) misMatchFind5 = 6;
                                }
                                
                                if (fluoroTemp6 != "nil"){
                                    if (arrayFileIFData [0] == fluoroTemp6) misMatchFind6 = 1;
                                    if (arrayFileIFData [2] == fluoroTemp6) misMatchFind6 = 2;
                                    if (arrayFileIFData [4] == fluoroTemp6) misMatchFind6 = 3;
                                    if (arrayFileIFData [6] == fluoroTemp6) misMatchFind6 = 4;
                                    if (arrayFileIFData [8] == fluoroTemp6) misMatchFind6 = 5;
                                    if (arrayFileIFData [10] == fluoroTemp6) misMatchFind6 = 6;
                                }
                                
                                if (fluoroTemp1 != "nil" && misMatchFind1 == 0) newIFFind = 1;
                                if (fluoroTemp2 != "nil" && misMatchFind2 == 0) newIFFind = 1;
                                if (fluoroTemp3 != "nil" && misMatchFind3 == 0) newIFFind = 1;
                                if (fluoroTemp4 != "nil" && misMatchFind4 == 0) newIFFind = 1;
                                if (fluoroTemp5 != "nil" && misMatchFind5 == 0) newIFFind = 1;
                                if (fluoroTemp6 != "nil" && misMatchFind6 == 0) newIFFind = 1;
                                if (arrayFileIFData [0] != "0" && fluoroTemp1 == "nil") newIFFind = 1;
                                if (arrayFileIFData [2] != "0" && fluoroTemp2 == "nil") newIFFind = 1;
                                if (arrayFileIFData [4] != "0" && fluoroTemp3 == "nil") newIFFind = 1;
                                if (arrayFileIFData [6] != "0" && fluoroTemp4 == "nil") newIFFind = 1;
                                if (arrayFileIFData [8] != "0" && fluoroTemp5 == "nil") newIFFind = 1;
                                if (arrayFileIFData [10] != "0" && fluoroTemp6 == "nil") newIFFind = 1;
                                
                                if (newIFFind == 0){
                                    if (fluoroTemp1 != "nil"){
                                        if (misMatchFind1 == 1 && atoi(arrayFileIFData [1].c_str()) != fluoroTempCount1) newIFFind = 2;
                                        if (misMatchFind1 == 2 && atoi(arrayFileIFData [3].c_str()) != fluoroTempCount1) newIFFind = 2;
                                        if (misMatchFind1 == 3 && atoi(arrayFileIFData [5].c_str()) != fluoroTempCount1) newIFFind = 2;
                                        if (misMatchFind1 == 4 && atoi(arrayFileIFData [7].c_str()) != fluoroTempCount1) newIFFind = 2;
                                        if (misMatchFind1 == 5 && atoi(arrayFileIFData [9].c_str()) != fluoroTempCount1) newIFFind = 2;
                                        if (misMatchFind1 == 6 && atoi(arrayFileIFData [11].c_str()) != fluoroTempCount1) newIFFind = 2;
                                    }
                                    
                                    if (fluoroTemp2 != "nil"){
                                        if (misMatchFind2 == 1 && atoi(arrayFileIFData [1].c_str()) != fluoroTempCount2) newIFFind = 2;
                                        if (misMatchFind2 == 2 && atoi(arrayFileIFData [3].c_str()) != fluoroTempCount2) newIFFind = 2;
                                        if (misMatchFind2 == 3 && atoi(arrayFileIFData [5].c_str()) != fluoroTempCount2) newIFFind = 2;
                                        if (misMatchFind2 == 4 && atoi(arrayFileIFData [7].c_str()) != fluoroTempCount2) newIFFind = 2;
                                        if (misMatchFind2 == 5 && atoi(arrayFileIFData [9].c_str()) != fluoroTempCount2) newIFFind = 2;
                                        if (misMatchFind2 == 6 && atoi(arrayFileIFData [11].c_str()) != fluoroTempCount2) newIFFind = 2;
                                    }
                                    
                                    if (fluoroTemp3 != "nil"){
                                        if (misMatchFind3 == 1 && atoi(arrayFileIFData [1].c_str()) != fluoroTempCount3) newIFFind = 2;
                                        if (misMatchFind3 == 2 && atoi(arrayFileIFData [3].c_str()) != fluoroTempCount3) newIFFind = 2;
                                        if (misMatchFind3 == 3 && atoi(arrayFileIFData [5].c_str()) != fluoroTempCount3) newIFFind = 2;
                                        if (misMatchFind3 == 4 && atoi(arrayFileIFData [7].c_str()) != fluoroTempCount3) newIFFind = 2;
                                        if (misMatchFind3 == 5 && atoi(arrayFileIFData [9].c_str()) != fluoroTempCount3) newIFFind = 2;
                                        if (misMatchFind3 == 6 && atoi(arrayFileIFData [11].c_str()) != fluoroTempCount3) newIFFind = 2;
                                    }
                                    
                                    if (fluoroTemp4 != "nil"){
                                        if (misMatchFind4 == 1 && atoi(arrayFileIFData [1].c_str()) != fluoroTempCount4) newIFFind = 2;
                                        if (misMatchFind4 == 2 && atoi(arrayFileIFData [3].c_str()) != fluoroTempCount4) newIFFind = 2;
                                        if (misMatchFind4 == 3 && atoi(arrayFileIFData [5].c_str()) != fluoroTempCount4) newIFFind = 2;
                                        if (misMatchFind4 == 4 && atoi(arrayFileIFData [7].c_str()) != fluoroTempCount4) newIFFind = 2;
                                        if (misMatchFind4 == 5 && atoi(arrayFileIFData [9].c_str()) != fluoroTempCount4) newIFFind = 2;
                                        if (misMatchFind4 == 6 && atoi(arrayFileIFData [11].c_str()) != fluoroTempCount4) newIFFind = 2;
                                    }
                                    
                                    if (fluoroTemp5 != "nil"){
                                        if (misMatchFind5 == 1 && atoi(arrayFileIFData [1].c_str()) != fluoroTempCount5) newIFFind = 2;
                                        if (misMatchFind5 == 2 && atoi(arrayFileIFData [3].c_str()) != fluoroTempCount5) newIFFind = 2;
                                        if (misMatchFind5 == 3 && atoi(arrayFileIFData [5].c_str()) != fluoroTempCount5) newIFFind = 2;
                                        if (misMatchFind5 == 4 && atoi(arrayFileIFData [7].c_str()) != fluoroTempCount5) newIFFind = 2;
                                        if (misMatchFind5 == 5 && atoi(arrayFileIFData [9].c_str()) != fluoroTempCount5) newIFFind = 2;
                                        if (misMatchFind5 == 6 && atoi(arrayFileIFData [11].c_str()) != fluoroTempCount5) newIFFind = 2;
                                    }
                                    
                                    if (fluoroTemp6 != "nil"){
                                        if (misMatchFind6 == 1 && atoi(arrayFileIFData [1].c_str()) != fluoroTempCount6) newIFFind = 2;
                                        if (misMatchFind6 == 2 && atoi(arrayFileIFData [3].c_str()) != fluoroTempCount6) newIFFind = 2;
                                        if (misMatchFind6 == 3 && atoi(arrayFileIFData [5].c_str()) != fluoroTempCount6) newIFFind = 2;
                                        if (misMatchFind6 == 4 && atoi(arrayFileIFData [7].c_str()) != fluoroTempCount6) newIFFind = 2;
                                        if (misMatchFind6 == 5 && atoi(arrayFileIFData [9].c_str()) != fluoroTempCount6) newIFFind = 2;
                                        if (misMatchFind6 == 6 && atoi(arrayFileIFData [11].c_str()) != fluoroTempCount6) newIFFind = 2;
                                    }
                                }
                            }
                            else findDIC = 1;
                            
                            if (newIFFind == 0 && findDIC == 1 && findDicOrder == 0){
                                if (multipleWaveLengthFlag == 1){
                                    string *fileNameTemp = new string [selectFileCount];
                                    string *fileNameTemp2 = new string [selectFileCount];
                                    int fileNameTempCount = 0;
                                    int fileNameTempCount2 = 0;
                                    int entryCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < selectFileCount; counter1++){
                                        if ((int)arraySelectFiles [counter1].find("DIC") != -1){
                                            fileNameTemp [fileNameTempCount] = arraySelectFiles [counter1], fileNameTempCount++;
                                            arraySelectFiles [counter1] = "nil";
                                        }
                                    }
                                    
                                    for (int counter1 = 0; counter1 < selectFileCount; counter1++){
                                        if (arraySelectFiles [counter1] != "nil"){
                                            fileNameTemp2 [fileNameTempCount2] = arraySelectFiles [counter1], fileNameTempCount2++;
                                        }
                                    }
                                    
                                    for (int counter1 = 0; counter1 < fileNameTempCount2; counter1++){
                                        arraySelectFiles [entryCount] = fileNameTemp2 [counter1], entryCount++;
                                    }
                                    
                                    for (int counter1 = 0; counter1 < fileNameTempCount; counter1++){
                                        arraySelectFiles [entryCount] = fileNameTemp [counter1], entryCount++;
                                    }
                                    
                                    delete [] fileNameTemp;
                                    delete [] fileNameTemp2;
                                }
                                
                                autoUploadStart = 1;
                                copyStartFlag2 = 1;
                                autoLoadingControlFlag = 8;
                            }
                            else{
                                
                                if (newIFFind == 1){
                                    NSAlert *alert = [[NSAlert alloc] init];
                                    [alert addButtonWithTitle:@"OK"];
                                    [alert setMessageText:@"New IF Detected: Remove or Do File Merge/Start New IF"];
                                    [alert setAlertStyle:NSAlertStyleWarning];
                                    [alert runModal];
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                                    [sound play];
                                    
                                    fileUpLoadingFlag = 4;
                                    autoLoadingControlFlag = 0;
                                }
                                
                                if (newIFFind == 2){
                                    NSAlert *alert = [[NSAlert alloc] init];
                                    [alert addButtonWithTitle:@"OK"];
                                    [alert setMessageText:@"Wait Until All IF Images Created"];
                                    [alert setAlertStyle:NSAlertStyleWarning];
                                    [alert runModal];
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                                    [sound play];
                                    
                                    fileUpLoadingFlag = 4;
                                    autoLoadingControlFlag = 0;
                                }
                                
                                if (findDIC == 0 || findDicOrder == 1){
                                    NSAlert *alert = [[NSAlert alloc] init];
                                    [alert addButtonWithTitle:@"OK"];
                                    [alert setMessageText:@"DIC File Missing"];
                                    [alert setAlertStyle:NSAlertStyleWarning];
                                    [alert runModal];
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                                    [sound play];
                                    
                                    fileUpLoadingFlag = 4;
                                    autoLoadingControlFlag = 0;
                                }
                            }
                        }
                        else{
                            
                            string warningPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/"+"FL_Warning";
                            
                            ofstream oin;
                            oin.open(warningPath.c_str(), ios::out);
                            oin<<"[FL] Not Enough Disk Space: Stop UpLoading"<<endl;
                            oin.close();
                            
                            autoLoadingControlFlag = 0;
                            exitFlag = 2;
                        }
                    }
                    else autoLoadingControlFlag = 0;
                }
                else autoLoadingControlFlag = 0;
            }
            else autoLoadingControlFlag = 0;
        }
        else autoLoadingControlFlag = 0;
    }
    
    //--------Copy Auto Mode-------
    if (copyStartFlag2 == 1){
        copyStartFlag2 = 2;
        
        if (fileUpLoadingFlag == 9){
            remove(loadingCompletePath.c_str());
            
            int terminationFlag = 1;
            
            ofstream oin;
            
            do{
                
                oin.open(loadingCompletePath.c_str(), ios::out);
                
                if (oin.is_open()){
                    oin<<"End"<<endl;
                    oin.close();
                    terminationFlag = 0;
                }
                
            } while (terminationFlag == 1);
        }
        
        progressValue = fileNameTableCount-1;
        progressTiming = 1;
        
        indicatorCount = 0;
        incrementCount = 0;
    }
    else if (copyStartFlag2 == 2){
        if (selectFileCount != incrementCount){
            string entry;
            string fluorescentAddition;
            string fileNamePath;
            string tempName;
            string bodyNumber;
            string stagePosition;
            string timePoint;
            string bodyNumberAdjust;
            string stagePositionAdjust;
            string timePointAdjust;
            string destinationNamePath;
            
            struct stat sizeOfFile;
            
            entry = arraySelectFiles [incrementCount];
            
            if (singleDualStatus == 2){
                if ((int)entry.find("DIC") != -1) fluorescentAddition = "";
                
                if ((int)entry.find(fluorescent1) != -1) fluorescentAddition = fluorescent1;
                
                if ((int)entry.find(fluorescent2) != -1) fluorescentAddition = fluorescent2;
                
                if ((int)entry.find(fluorescent3) != -1) fluorescentAddition = fluorescent3;
                
                if ((int)entry.find(fluorescent4) != -1) fluorescentAddition = fluorescent4;
                
                if ((int)entry.find(fluorescent5) != -1) fluorescentAddition = fluorescent5;
                
                if ((int)entry.find(fluorescent6) != -1) fluorescentAddition = fluorescent6;
            }
            
            fileNamePath = directoryPathForPC+"/"+entry;
            
            long sizeForCopy = 0;
            
            if (stat(fileNamePath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
                
                tempName = entry.substr(entry.find(flProcessName));
                bodyNumber = tempName.substr(flProcessName.length(), tempName.find("_")-flProcessName.length());
                stagePosition = entry.substr(entry.find("_s")+2, entry.find("_t")-entry.find("_s")-2);
                timePoint = entry.substr(entry.find("_t")+2, entry.find(tiffExtension)-entry.find("_t")-2);
                
                //cout<<bodyNumber<<" "<<stagePosition<<" "<<timePoint<<" Info"<<endl;
                
                if (bodyNumber == "") bodyNumberAdjust = "000";
                else if (bodyNumber.length() == 1) bodyNumberAdjust = "00"+bodyNumber;
                else if (bodyNumber.length() == 2) bodyNumberAdjust = "0"+bodyNumber;
                else bodyNumberAdjust = bodyNumber;
                
                if (stagePosition == "") stagePositionAdjust = "0000";
                else if (stagePosition.length() == 1) stagePositionAdjust = "000"+stagePosition;
                else if (stagePosition.length() == 2) stagePositionAdjust = "00"+stagePosition;
                else if (stagePosition.length() == 3) stagePositionAdjust = "0"+stagePosition;
                else stagePositionAdjust = stagePosition;
                
                if (timePoint == "") timePointAdjust = "0000";
                else if (timePoint.length() == 1) timePointAdjust = "000"+timePoint;
                else if (timePoint.length() == 2) timePointAdjust = "00"+timePoint;
                else if (timePoint.length() == 3) timePointAdjust = "0"+timePoint;
                else timePointAdjust = timePoint;
                
                if (singleDualStatus == 1) destinationNamePath = importFolder+"/"+flProcessName+bodyNumberAdjust+"_s"+stagePositionAdjust+"_t"+timePointAdjust+".tif";
                else if (singleDualStatus == 2 && fluorescentAddition != "") destinationNamePath = importFolder+"/"+flProcessName+bodyNumberAdjust+"_"+fluorescentAddition+"_s"+stagePositionAdjust+"_t"+timePointAdjust+".tif";
                else if (singleDualStatus == 2 && fluorescentAddition == "") destinationNamePath = importFolder+"/"+flProcessName+bodyNumberAdjust+"_s"+stagePositionAdjust+"_t"+timePointAdjust+".tif";
                
                ifstream infile (fileNamePath.c_str(), ifstream::binary);
                ofstream outfile (destinationNamePath.c_str(), ofstream::binary);
                
                char *buffer = new char[sizeForCopy];
                infile.read (buffer, sizeForCopy);
                outfile.write (buffer, sizeForCopy);
                delete [] buffer;
                
                outfile.close();
                infile.close();
                
                remove (fileNamePath.c_str());
                
                indicatorCount++;
                
                progressValue = indicatorCount;
                progressTiming = 3;
                
                if (fileNameTableCount-1 == indicatorCount){
                    progressTiming = 5;
                }
                
                latestBodyNoHold = atoi(bodyNumber.c_str());
                latestTimePointHold = atoi(timePoint.c_str());
                
                incrementCount++;
            }
        }
        else{
            
            int terminationFlag = 1;
            
            ofstream oin;
            
            do{
                
                oin.open(fileDataPath.c_str(), ios::out);
                
                if (oin.is_open()){
                    oin<<to_string(fileImageSize)<<endl;
                    
                    if (singleDualStatus == 1) oin<<"1"<<endl;
                    else oin<<"2"<<endl;
                    
                    oin<<fluorescent1<<endl;
                    oin<<fluorescent2<<endl;
                    oin<<fluorescent3<<endl;
                    oin<<fluorescent4<<endl;
                    oin<<fluorescent5<<endl;
                    oin<<fluorescent6<<endl;
                    
                    if (fluorescentFileNoCount == 1) oin<<"1"<<endl;
                    else if (fluorescentFileNoCount == 2) oin<<"2"<<endl;
                    else if (fluorescentFileNoCount == 3) oin<<"3"<<endl;
                    else if (fluorescentFileNoCount == 4) oin<<"4"<<endl;
                    else if (fluorescentFileNoCount == 5) oin<<"5"<<endl;
                    else oin<<"6"<<endl;
                    
                    oin<<latestBodyNoHold<<endl;
                    oin<<latestTimePointHold<<endl;
                    
                    oin.close();
                    
                    oin.open(fileDataSavePath.c_str(), ios::out);
                    
                    oin<<to_string(fileImageSize)<<endl;
                    
                    if (singleDualStatus == 1) oin<<"1"<<endl;
                    else oin<<"2"<<endl;
                    
                    oin<<fluorescent1<<endl;
                    oin<<fluorescent2<<endl;
                    oin<<fluorescent3<<endl;
                    oin<<fluorescent4<<endl;
                    oin<<fluorescent5<<endl;
                    oin<<fluorescent6<<endl;
                    
                    if (fluorescentFileNoCount == 1) oin<<"1"<<endl;
                    else if (fluorescentFileNoCount == 2) oin<<"2"<<endl;
                    else if (fluorescentFileNoCount == 3) oin<<"3"<<endl;
                    else if (fluorescentFileNoCount == 4) oin<<"4"<<endl;
                    else if (fluorescentFileNoCount == 5) oin<<"5"<<endl;
                    else oin<<"6"<<endl;
                    
                    oin<<latestBodyNoHold<<endl;
                    oin<<latestTimePointHold<<endl;
                    
                    oin.close();
                    
                    autoUploadStart = 0;
                    copyStartFlag2 = 0;
                    autoLoadingControlFlag = 9;
                    terminationFlag = 0;
                    
                    if (exitFlag == 1) exitFlag = 2;
                }
                
            } while (terminationFlag == 1);
        }
    }
    else if ((fileUpLoadingFlag == 1 || fileUpLoadingFlag == 9 || fileUpLoadingFlag == 40) && autoLoadingControlFlag == 9) autoLoadingControlFlag = 10;
    else if ((fileUpLoadingFlag == 1 || fileUpLoadingFlag == 9 || fileUpLoadingFlag == 40) && autoLoadingControlFlag >= 10 && autoLoadingControlFlag < 12){
        autoLoadingControlFlag++;
        
        if (autoLoadingControlFlag == 12 && fileUpLoadingFlag != 9) autoLoadingControlFlag = 0;
        
        if (fileUpLoadingFlag == 9){
            fileInfoSendCall = 1;
            sendMessageON = 1;
            autoLoadingControlFlag = 20;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        
        if (fileUpLoadingFlag == 40){
            exitFlag = 3;
            fileUpLoadingFlag = 4;
        }
    }
    
    //--------Last Purge Quite----------
    if (autoLoadingControlFlag == 20){
        int lastPurgeFlag = 0;
        
        ifstream fin;
        fin.open(loadingCompletePath.c_str(),ios::in);
        
        if (fin.is_open()){
            lastPurgeFlag = 1;
            fin.close();
        }
        if (lastPurgeFlag == 0) [self processStopSub];
    }
    
    //-------Copy Initial Upload---------
    if (copyStartFlag == 1){
        copyStartFlag = 2;
        
        progressValue = fileNameTableCount-1;
        progressTiming = 1;
        
        indicatorCount = 0;
        incrementCount = 0;
    }
    else if (copyStartFlag == 2){
        int bodyNameLength = (int)flProcessName.length();
        
        if (fileNameTableCount != incrementCount){
            string entry;
            string fluorescentAddition;
            string fileNamePath;
            string tempName;
            string bodyNumber;
            string stagePosition;
            string timePoint;
            string bodyNumberAdjust;
            string stagePositionAdjust;
            string timePointAdjust;
            string destinationNamePath;
            
            struct stat sizeOfFile;
            
            entry = arrayFileNameTable [incrementCount];
            
            fluorescentAddition = "";
            
            if (singleDualStatus == 2){
                if ((int)entry.find("DIC") != -1) fluorescentAddition = "";
                
                if ((int)entry.find(fluorescent1) != -1) fluorescentAddition = fluorescent1;
                
                if ((int)entry.find(fluorescent2) != -1) fluorescentAddition = fluorescent2;
                
                if ((int)entry.find(fluorescent3) != -1) fluorescentAddition = fluorescent3;
                
                if ((int)entry.find(fluorescent4) != -1) fluorescentAddition = fluorescent4;
                
                if ((int)entry.find(fluorescent5) != -1) fluorescentAddition = fluorescent5;
                
                if ((int)entry.find(fluorescent6) != -1) fluorescentAddition = fluorescent6;
            }
            
            fileNamePath = directoryPathForPC+"/"+entry;
            
            long sizeForCopy = 0;
            
            if (stat(fileNamePath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
                
                tempName = entry.substr(entry.find(flProcessName));
                bodyNumber = tempName.substr((unsigned long)bodyNameLength, tempName.find("_")-(unsigned long)bodyNameLength);
                stagePosition = entry.substr(entry.find("_s")+2, entry.find("_t")-entry.find("_s")-2);
                timePoint = entry.substr(entry.find("_t")+2, entry.find(tiffExtension)-entry.find("_t")-2);
                
                if (bodyNumber == "") bodyNumberAdjust = "000";
                else if (bodyNumber.length() == 1) bodyNumberAdjust = "00"+bodyNumber;
                else if (bodyNumber.length() == 2) bodyNumberAdjust = "0"+bodyNumber;
                else bodyNumberAdjust = bodyNumber;
                
                if (stagePosition == "") stagePositionAdjust = "0000";
                else if (stagePosition.length() == 1) stagePositionAdjust = "000"+stagePosition;
                else if (stagePosition.length() == 2) stagePositionAdjust = "00"+stagePosition;
                else if (stagePosition.length() == 3) stagePositionAdjust = "0"+stagePosition;
                else stagePositionAdjust = stagePosition;
                
                if (timePoint == "") timePointAdjust = "0000";
                else if (timePoint.length() == 1) timePointAdjust = "000"+timePoint;
                else if (timePoint.length() == 2) timePointAdjust = "00"+timePoint;
                else if (timePoint.length() == 3) timePointAdjust = "0"+timePoint;
                else timePointAdjust = timePoint;
                
                if (singleDualStatus == 1) destinationNamePath = importFolder+"/"+flProcessName+bodyNumberAdjust+"_s"+stagePositionAdjust+"_t"+timePointAdjust+".tif";
                else if (singleDualStatus == 2 && fluorescentAddition != "") destinationNamePath = importFolder+"/"+flProcessName+bodyNumberAdjust+"_"+fluorescentAddition+"_s"+stagePositionAdjust+"_t"+timePointAdjust+".tif";
                else if (singleDualStatus == 2 && fluorescentAddition == "") destinationNamePath = importFolder+"/"+flProcessName+bodyNumberAdjust+"_s"+stagePositionAdjust+"_t"+timePointAdjust+".tif";
                
                ifstream infile (fileNamePath.c_str(), ifstream::binary);
                ofstream outfile (destinationNamePath.c_str(), ofstream::binary);
                
                char *buffer = new char[sizeForCopy];
                infile.read (buffer, sizeForCopy);
                outfile.write (buffer, sizeForCopy);
                delete [] buffer;
                
                outfile.close();
                infile.close();
                
                remove (fileNamePath.c_str());
                
                incrementCount++;
                indicatorCount++;
                
                progressValue = indicatorCount;
                progressTiming = 3;
            }
        }
        else{
            
            progressTiming = 5;
            
            [loadingStatus setStringValue:@"File UpLoading: Complete"];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
            
            initialUploadStart = 0;
            fileListCheckFlag = 0;
            fileSizeSetFlag = 0;
            fluorescentNameFlag = 0;
            fileInfoSendCall = 1;
            sendMessageON = 1;
            copyStartFlag = 0;
        }
    }
    
    if (progressTiming == 1){
        [progressIndicator setMinValue:0];
        [progressIndicator setMaxValue:progressValue];
        [progressIndicator startAnimation:self];
        [progressIndicator setHidden:NO];
        
        double bValue = [progressIndicator maxValue];
        
        if (progressIndicator){
            if (bValue == progressValue){
                progressTiming = 2;
            }
        }
    }
    else if (progressTiming == 3){
        [progressIndicator setDoubleValue:progressValue];
        [progressIndicator displayIfNeeded];
        
        double bValue = [progressIndicator doubleValue];
        
        if (bValue == progressValue){
            progressTiming = 4;
        }
    }
    else if (progressTiming == 5){
        [progressIndicator setDoubleValue:0];
        [progressIndicator displayIfNeeded];
        
        double bValue = [progressIndicator doubleValue];
        
        if (bValue == progressValue){
            [progressIndicator stopAnimation:self];
            progressTiming = 0;
        }
    }
    
    [self Communication];
}

-(void)Communication{
    //---------Initial establishment---------
    if (firstCommunication == 0){
        firstCommunication = 1;
        basicInfoRead = 1;
    }
    
    //----------Basic info and holding flag read----------
    if (firstCommunication == 1 && basicInfoRead == 1){
        basicInfoRead = 2;
    }
    
    if (firstCommunication == 1 && basicInfoRead == 2){
        string instructionFLPath2 = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/FL_Instruction2";
        
        int instractionFIFlag = 0;
        
        ifstream fin;
        fin.open(instructionFLPath2.c_str(),ios::in);
        if (fin.is_open()){
            instractionFIFlag = 1;
            fin.close();
        }
        
        if (instractionFIFlag != 0){
            fin.open(instructionFLPath2.c_str(),ios::in);
            
            string getString = "";
            
            getline(fin, getString);
            flComputerDataName = getString;
            getline(fin, getString);
            flUserName = getString;
            getline(fin, getString);
            flProcessName = getString;
            getline(fin, getString);
            totalFOVNoHold = getString;
            getline(fin, getString);
            fileUpLoadingFlag = atoi(getString.c_str());
            
            directoryPathForPC = dataDirectoryPath;
            
            if (fileUpLoadingFlag == 2 || fileUpLoadingFlag == 3){
                fluorescent1 = "nil";
                fluorescent2 = "nil";
                fluorescent3 = "nil";
                fluorescent4 = "nil";
                fluorescent5 = "nil";
                fluorescent6 = "nil";
                fluorescentFileNoCount = 0;
                singleDualStatus = 0;
                fileImageSize = 0;
                latestBodyNoHold = 0;
                latestTimePointHold = 0;
                
                remove(fileDataPath.c_str());
                remove(loadingCompletePath.c_str());
                remove(fileIFDataPath.c_str());
                
                [detectedFOV setStringValue:@"nil"];
                [singleDualDisplay setStringValue:@"nil"];
                [fluorescentDisplay1 setStringValue:@"nil"];
                [fluorescentDisplay2 setStringValue:@"nil"];
                [fluorescentDisplay3 setStringValue:@"nil"];
                [fluorescentDisplay4 setStringValue:@"nil"];
                [fluorescentDisplay5 setStringValue:@"nil"];
                [fluorescentDisplay6 setStringValue:@"nil"];
                [autoInitStatus setStringValue:@"Init"];
            }
            else if (fileUpLoadingFlag == 9){
                [autoInitStatus setStringValue:@"Last Purge"];
                [loadingStatus setStringValue:@"Last Purge"];
            }
            else if (fileUpLoadingFlag == 4 || fileUpLoadingFlag == 3){
                [autoInitStatus setStringValue:@"IF-Loading"];
                [loadingStatus setStringValue:@"File IF-Loading"];
            }
            else{
                
                [autoInitStatus setStringValue:@"Auto"];
                [loadingStatus setStringValue:@"File Auto-Loading"];
                
                [NSApp miniaturizeAll:self];
            }
            
            [computerName setStringValue:@(flComputerDataName.c_str())];
            [userID setStringValue:@(flUserName.c_str())];
            [analysisName setStringValue:@(flProcessName.c_str())];
            [totalFOV setStringValue:@(totalFOVNoHold.c_str())];
            
            basicInfoRead = 3;
        }
    }
    
    if (firstCommunication == 1 && basicInfoRead == 3){
        basicInfoRead = 4;
    }
    
    //----------Send Setting data----------
    if ((firstCommunication == 1 && fileInfoSendCall == 1 && sendMessageON == 1 && fileUpLoadingFlag != 9) || (firstCommunication == 1 && fileUpLoadingFlag == 9 && fileInfoSendCall == 1 && sendMessageON == 1)){
        fileInfoSendCall = 2;
        sendMessageON = 2;
    }
    
    if ((firstCommunication == 1 && fileInfoSendCall == 2 && fileUpLoadingFlag != 9) || (firstCommunication == 1 && fileUpLoadingFlag == 9 && fileInfoSendCall == 2)){
        string instructionFLTempPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/FL_InstructionTemp1";
        string instructionFLPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/FL_Instruction1";
        
        int terminationFlag = 1;
        
        ofstream oin;
        
        do {
            
            oin.open(instructionFLTempPath.c_str(), ios::out);
            
            if (oin.is_open()){
                if (firstCommunication == 1 && fileInfoSendCall == 2 && fileUpLoadingFlag != 9){
                    string modeTemp;
                    
                    if (singleDualStatus == 1) modeTemp = "1";
                    else modeTemp = "2";
                    
                    string fluorescentCount = "0";
                    
                    if (fluorescentFileNoCount == 1) fluorescentCount = "1";
                    else if (fluorescentFileNoCount == 2) fluorescentCount = "2";
                    else if (fluorescentFileNoCount == 3) fluorescentCount = "3";
                    else if (fluorescentFileNoCount == 4) fluorescentCount = "4";
                    else if (fluorescentFileNoCount == 5) fluorescentCount = "5";
                    else if (fluorescentFileNoCount == 6) fluorescentCount = "6";
                    
                    oin<<"DIC"<<endl;
                    oin<<fluorescent1<<endl;
                    oin<<fluorescent2<<endl;
                    oin<<fluorescent3<<endl;
                    oin<<fluorescent4<<endl;
                    oin<<fluorescent5<<endl;
                    oin<<fluorescent6<<endl;
                    oin<<fluorescentCount<<endl;
                    oin<<modeTemp<<endl;
                }
                else if (firstCommunication == 1 && fileUpLoadingFlag == 9 && fileInfoSendCall == 2){
                    oin<<"IF"<<endl;
                }
                
                oin.close();
                
                ifstream fin;
                
                fin.open(instructionFLTempPath.c_str(),ios::in);
                
                if (fin.is_open()){
                    fin.close();
                    fin.clear();
                    
                    rename(instructionFLTempPath.c_str(), instructionFLPath.c_str());
                    
                    fileInfoSendCall = 3;
                    sendMessageON = 0;
                    
                    break;
                }
                
                terminationFlag = 0;
            }
            
        } while (terminationFlag == 1);
    }
}

-(IBAction)fileUpLoadStart:(id)sender{
    if (flComputerDataName != "nil" && flUserName != "nil" && flProcessName != "nil" && totalFOVNoHold != "nil" && (fileUpLoadingFlag == 2 || fileUpLoadingFlag == 3) && initialUploadStart == 0){
        ifstream fin;
        
        fin.open(directoryPathForPC.c_str(),ios::in);
        
        if (fin.is_open()){
            fin.close();
            
            remove(loadingCompletePath.c_str());
            
            int terminationFlag = 1;
            
            ofstream oin;
            
            do{
                
                oin.open(loadingCompletePath.c_str(), ios::out);
                
                if (oin.is_open()){
                    oin<<"End"<<endl;
                    oin.close();
                    
                    arrayFileIFData [0] = "0";
                    arrayFileIFData [1] = "0";
                    arrayFileIFData [2] = "0";
                    arrayFileIFData [3] = "0";
                    arrayFileIFData [4] = "0";
                    arrayFileIFData [5] = "0";
                    arrayFileIFData [6] = "0";
                    arrayFileIFData [7] = "0";
                    arrayFileIFData [8] = "0";
                    arrayFileIFData [9] = "0";
                    arrayFileIFData [10] = "0";
                    arrayFileIFData [11] = "0";
                    
                    oin.open(fileIFDataPath.c_str(), ios::out);
                    for (int counter1 = 0; counter1 < 12; counter1++) oin<<arrayFileIFData [counter1]<<endl;
                    oin.close();
                    
                    initialUploadStart = 1;
                    fileNameTableCount = 0;
                    terminationFlag = 0;
                }
                
            } while (terminationFlag == 1);
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Check Image Acquisition Computer"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        if (fileUpLoadingFlag == 4) fileUpLoadingFlag = 40;
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(void)fileListCheck{
    [loadingStatus setStringValue:@"Stage Positions and Time Points Check"];
    
    string firstTimePoint = "";
    int timeMismatchFind = 0;
    int bodyExtensionMismatchFind = 0;
    int timeLaps = 0;
    int terminationFlag = 0;
    int loopCount = 0;
    
    directoryInfoHoldCount = 0;
    
    do{
        
        terminationFlag = 1;
        DIR *dir;
        struct dirent *dent;
        
        dir = opendir(directoryPathForPC.c_str());
        
        if (dir != NULL){
            string entry;
            
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if ((int)entry.find(flProcessName) != -1 && (int)entry.find(tiffExtension) != -1){
                    if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                    arrayDirectoryInfoHold [directoryInfoHoldCount] = entry, directoryInfoHoldCount++;
                }
            }
            
            closedir(dir);
            
            //-------Directory Sort------
            NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
            
            for (int counter1 = 0; counter1 < directoryInfoHoldCount; counter1++){
                [unsortedArray addObject:@(arrayDirectoryInfoHold [counter1].c_str())];
            }
            
            [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
            
            for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                arrayDirectoryInfoHold [counter1] = [unsortedArray [counter1] UTF8String];
            }
        }
        
        if (directoryInfoHoldCount != 0) terminationFlag = 0;
        else{
            
            directoryInfoHoldCount = 0;
            loopCount++;
            
            if (loopCount == 1000) terminationFlag = 0;
        }
        
    } while (terminationFlag == 1);
    
    if (loopCount != 1000){
        if (directoryInfoHoldCount != 0){
            string entry;
            string tempName;
            string bodyNameExtract;
            string lastString;
            string extractStringTemp;
            
            int bodyNameExtension = -1;
            int bodyNameLength = (int)flProcessName.length();
            int findString1 = 0;
            
            for (int counter1 = 0; counter1 < directoryInfoHoldCount; counter1++){
                entry = arrayDirectoryInfoHold [counter1];
                findString1 = (int)entry.find(flProcessName);
                
                if (findString1 > 0){
                    if (entry.substr((unsigned long)findString1-1, 1) != "_") findString1 = -1;
                }
                
                if (entry != "." && entry != ".." && entry != ".DS_Store" && findString1 != -1){
                    tempName = entry.substr((unsigned long)findString1);
                    bodyNameExtract = tempName.substr(0, tempName.find("_"));
                    
                    do{
                        
                        terminationFlag = 1;
                        
                        lastString = bodyNameExtract.substr(bodyNameExtract.length()-1, 1);
                        
                        if (lastString == "0" || lastString == "1" || lastString == "2" || lastString == "3" || lastString == "4" || lastString == "5" || lastString == "6" || lastString == "7" || lastString == "8" || lastString == "9"){
                            bodyNameExtract = bodyNameExtract.substr(0, bodyNameExtract.length()-1);
                        }
                        else terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                    
                    if (bodyNameExtract == flProcessName && (int)entry.find("_s") != -1){
                        if ((int)entry.find("_t") == -1) timeLaps = 1;
                        
                        if (firstTimePoint == "") firstTimePoint = entry.substr(entry.find("_t")+2, entry.find(tiffExtension)-entry.find("_t")-2);
                        else if (firstTimePoint != entry.substr(entry.find("_t")+2, entry.find(tiffExtension)-entry.find("_t")-2)) timeMismatchFind = 1;
                        
                        tempName = entry.substr(entry.find(flProcessName));
                        extractStringTemp = tempName.substr((unsigned long)bodyNameLength, tempName.find("_")-(unsigned long)bodyNameLength);
                        
                        if (bodyNameExtension == -1) bodyNameExtension = atoi(extractStringTemp.c_str());
                        else if (bodyNameExtension != atoi(extractStringTemp.c_str())) bodyExtensionMismatchFind = 1;
                        
                        if (fileNameTableCount+10 > fileNameTableLimit) [self fileNameTableUpDate];
                        
                        arrayFileNameTable [fileNameTableCount] = entry, fileNameTableCount++;
                    }
                }
            }
        }
        
        if (fileNameTableCount != 0 && timeLaps == 0){
            if (timeMismatchFind == 0 && bodyExtensionMismatchFind == 0){
                fileListCheckFlag = 1;
                tableViewCall = 1;
            }
            else{
                
                [loadingStatus setStringValue:@"nil"];
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Clear Old Files And Re-do"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
                
                initialUploadStart = 0;
                fileListCheckFlag = 0;
                tableViewCall = 1;
            }
        }
        else{
            
            [loadingStatus setStringValue:@"nil"];
            
            if (fileNameTableCount == 0){
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"File Missing"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Time Lapse Mode Off"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
            }
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
            
            initialUploadStart = 0;
            fileListCheckFlag = 0;
            tableViewCall = 1;
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Relevant File Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
        
        initialUploadStart = 0;
        fileListCheckFlag = 0;
        tableViewCall = 1;
    }
}

-(void)singleDualFind{
    [loadingStatus setStringValue:@"Image File Format Check: DIC or DIC+Fluorescent"];
    
    int singleDoubleStatusTemp = 0;
    int findDICTemp = 0;
    int terminationFlag = 0;
    
    directoryInfoHoldCount = 0;
    
    do{
        
        terminationFlag = 1;
        DIR *dir;
        struct dirent *dent;
        
        dir = opendir(directoryPathForPC.c_str());
        
        if (dir != NULL){
            string entry;
            
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if ((int)entry.find(flProcessName) != -1 && (int)entry.find(tiffExtension) != -1){
                    if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                    arrayDirectoryInfoHold [directoryInfoHoldCount] = entry, directoryInfoHoldCount++;
                }
            }
            
            closedir(dir);
            
            //-------Directory Sort------
            NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
            
            for (int counter1 = 0; counter1 < directoryInfoHoldCount; counter1++){
                [unsortedArray addObject:@(arrayDirectoryInfoHold [counter1].c_str())];
            }
            
            [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
            
            for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                arrayDirectoryInfoHold [counter1] = [unsortedArray [counter1] UTF8String];
            }
        }
        
        if (directoryInfoHoldCount != 0){
            terminationFlag = 0;
        }
        else directoryInfoHoldCount = 0;
        
    } while (terminationFlag == 1);
    
    if (directoryInfoHoldCount != 0){
        string entry;
        string tempName;
        string bodyNameExtract;
        string lastString;
        string stringExtract;
        
        int findString1 = 0;
        
        for (int counter1 = 0; counter1 < directoryInfoHoldCount; counter1++){
            entry = arrayDirectoryInfoHold [counter1];
            
            findString1 = (int)entry.find(flProcessName);
            
            if (findString1 > 0){
                if (entry.substr((unsigned long)findString1-1, 1) != "_") findString1 = -1;
            }
            
            if (entry != "." && entry != ".." && entry != ".DS_Store" && findString1 != -1){
                tempName = entry.substr((unsigned long)findString1);
                bodyNameExtract = tempName.substr(0, tempName.find("_"));
                
                do{
                    
                    terminationFlag = 1;
                    
                    lastString = bodyNameExtract.substr(bodyNameExtract.length()-1, 1);
                    
                    if (lastString == "0" || lastString == "1" || lastString == "2" || lastString == "3" || lastString == "4" || lastString == "5" || lastString == "6" || lastString == "7" || lastString == "8" || lastString == "9"){
                        bodyNameExtract = bodyNameExtract.substr(0, bodyNameExtract.length()-1);
                    }
                    else terminationFlag = 0;
                    
                } while (terminationFlag == 1);
                
                if (bodyNameExtract == flProcessName){
                    stringExtract = entry.substr(entry.find("_s")-3, 3);
                    
                    if (stringExtract != "DIC"){
                        if ((int)entry.find("_w") != -1) singleDoubleStatusTemp = 2;
                        else{
                            
                            singleDoubleStatusTemp = 1;
                            findDICTemp = 1;
                        }
                    }
                    else{
                        
                        if (singleDoubleStatusTemp == 0) singleDoubleStatusTemp = 1;
                        
                        findDICTemp = 1;
                    }
                }
            }
        }
    }
    
    if (findDICTemp == 0) singleDoubleStatusTemp = 3;
    
    if (singleDoubleStatusTemp == 1){
        singleDualStatus = 1;
        fileSingleDualFlag = 1;
    }
    else if (singleDoubleStatusTemp == 2){
        singleDualStatus = 2;
        fileSingleDualFlag = 1;
    }
    else if (singleDoubleStatusTemp == 3){
        [loadingStatus setStringValue:@"nil"];
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"DIC File Missing/Clear All Files And Re-do"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
        
        initialUploadStart = 0;
        fileListCheckFlag = 0;
    }
    
    if (singleDoubleStatusTemp != 0){
        terminationFlag = 1;
        
        ofstream oin;
        
        do{
            
            oin.open(fileDataPath.c_str(), ios::out);
            
            if (oin.is_open()){
                oin<<"nil"<<endl;
                
                if (singleDualStatus == 1) oin<<"1"<<endl;
                else oin<<"2"<<endl;
                
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                oin.close();
                
                oin.open(fileDataSavePath.c_str(), ios::out);
                oin<<"nil"<<endl;
                
                if (singleDualStatus == 1) oin<<"1"<<endl;
                else oin<<"2"<<endl;
                
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                oin.close();
                
                terminationFlag = 0;
                
                if (singleDualStatus == 1) [singleDualDisplay setStringValue:@"DIC"];
                if (singleDualStatus == 2) [singleDualDisplay setStringValue:@"DIC+FLU"];
            }
        }
        
        while (terminationFlag == 1);
    }
}

-(void)fluorescentNameFind{
    //=======Name Rule==========
    //=======DUAL MODE=========
    //BodyName_w*** *** DAPI_s1_t1 >>>>Take DAPI
    //BodyName_w*** DIC_s1_t1 >>>>Take DIC or BodyName_w*DIC_s1_t1 >>>>Take DIC
    
    //=======Single MODE=========
    //BodyName_w*** DIC_s1_t1 >>>>Take DIC or BodyName_w*DIC_s1_t1 >>>>Take DIC
    
    [loadingStatus setStringValue:@"Fluorescent Type Identification and DIC File Check"];
    
    int dicFileCount = 0;
    int fileDicOrder = 0;
    int terminationFlag = 0;
    int maxWNumber = 0;
    
    directoryInfoHoldCount = 0;
    
    do{
        
        terminationFlag = 1;
        DIR *dir;
        struct dirent *dent;
        
        dir = opendir(directoryPathForPC.c_str());
        
        if (dir != NULL){
            string entry;
            
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if ((int)entry.find(flProcessName) != -1 && (int)entry.find(tiffExtension) != -1){
                    if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                    arrayDirectoryInfoHold [directoryInfoHoldCount] = entry, directoryInfoHoldCount++;
                }
            }
            
            closedir(dir);
            
            //-------Directory Sort------
            NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
            
            for (int counter1 = 0; counter1 < directoryInfoHoldCount; counter1++){
                [unsortedArray addObject:@(arrayDirectoryInfoHold [counter1].c_str())];
            }
            
            [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
            
            for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                arrayDirectoryInfoHold [counter1] = [unsortedArray [counter1] UTF8String];
            }
        }
        
        if (directoryInfoHoldCount > 4){
            terminationFlag = 0;
        }
        else directoryInfoHoldCount = 0;
        
    } while (terminationFlag == 1);
    
    if (directoryInfoHoldCount != 0){
        string entry;
        string fluorescentNameTemp;
        string extension;
        string tempName;
        string bodyNameExtract;
        string lastString;
        string stringExtractTemp;
        
        int findString1 = 0;
        
        for (int counter1 = 0; counter1 < directoryInfoHoldCount; counter1++){
            entry = arrayDirectoryInfoHold [counter1];
            
            findString1 = (int)entry.find(flProcessName);
            
            if (findString1 > 0){
                if (entry.substr((unsigned long)findString1-1, 1) != "_") findString1 = -1;
            }
            
            if (entry != "." && entry != ".." && entry != ".DS_Store" && findString1 != -1){
                tempName = entry.substr((unsigned long)findString1);
                bodyNameExtract = tempName.substr(0, tempName.find("_"));
                
                do{
                    
                    terminationFlag = 1;
                    
                    lastString = bodyNameExtract.substr(bodyNameExtract.length()-1, 1);
                    
                    if (lastString == "0" || lastString == "1" || lastString == "2" || lastString == "3" || lastString == "4" || lastString == "5" || lastString == "6" || lastString == "7" || lastString == "8" || lastString == "9"){
                        bodyNameExtract = bodyNameExtract.substr(0, bodyNameExtract.length()-1);
                    }
                    else terminationFlag = 0;
                    
                } while (terminationFlag == 1);
                
                if (bodyNameExtract == flProcessName){
                    if ((int)entry.find("DIC") != -1) dicFileCount++;
                    if ((int)entry.find("DIC") != -1 && (int)entry.find("_w1") != -1) fileDicOrder = 1;
                    
                    if (atoi((entry.substr(entry.find("_w")+2, 1)).c_str()) > maxWNumber) maxWNumber = atoi((entry.substr(entry.find("_w")+2, 1)).c_str());
                    
                    findString1 = (int)entry.find("_w");
                    
                    if (findString1 != -1){ //=========================DIC DIC IR, name extract parameter change==============
                        stringExtractTemp = entry.substr(entry.find("_w")+1, entry.find("_s")-entry.find("_w")-1);
                        
                        //w*** *** DAPI
                        //w*** DIC
                        //w*DIC
                        
                        //w*** *** DAPI--A
                        //w*** DIC--A
                        //w*DIC--x
                        
                        if ((int)stringExtractTemp.find(" ") != -1) stringExtractTemp = stringExtractTemp.substr(stringExtractTemp.find(" ")+1);
                        
                        //w*** *** DAPI--*** DAPI
                        //w*** DIC--DIC
                        //w*DIC--x
                        
                        if ((int)entry.find("DIC") != -1) stringExtractTemp = "DIC";
                        
                        //w*** *** DAPI--*** DAPI
                        //w*** DIC--DIC
                        //w*DIC--DIC
                        
                        //findString1 = stringExtractTemp.find(" ");
                        
                        if ((int)stringExtractTemp.find(" ") != -1) fluorescentNameTemp = stringExtractTemp.substr(stringExtractTemp.find(" ")+1);
                        else fluorescentNameTemp = stringExtractTemp.substr(stringExtractTemp.find(" ")+1); //------Start 0--------
                        
                        //w*** *** DAPI--*** DAPI--DAPI
                        //w*** DIC--DIC--DIC
                        //w*DIC--DIC
                        
                        if (fluorescentNameTemp != "DIC"){
                            if (fluorescent1 == "nil") fluorescent1 = fluorescentNameTemp;
                            else if (fluorescent1 != "nil" && fluorescent1 != fluorescentNameTemp && fluorescent2 == "nil") fluorescent2 = fluorescentNameTemp;
                            else if (fluorescent1 != "nil" && fluorescent1 != fluorescentNameTemp && fluorescent2 != "nil" && fluorescent2 != fluorescentNameTemp && fluorescent3 == "nil") fluorescent3 = fluorescentNameTemp;
                            else if (fluorescent1 != "nil" && fluorescent1 != fluorescentNameTemp && fluorescent2 != "nil" && fluorescent2 != fluorescentNameTemp && fluorescent3 != "nil" && fluorescent3 != fluorescentNameTemp && fluorescent4 == "nil") fluorescent4 = fluorescentNameTemp;
                            else if (fluorescent1 != "nil" && fluorescent1 != fluorescentNameTemp && fluorescent2 != "nil" && fluorescent2 != fluorescentNameTemp && fluorescent3 != "nil" && fluorescent3 != fluorescentNameTemp && fluorescent4 != "nil" && fluorescent4 != fluorescentNameTemp && fluorescent5 == "nil") fluorescent5 = fluorescentNameTemp;
                            else if (fluorescent1 != "nil" && fluorescent1 != fluorescentNameTemp && fluorescent2 != "nil" && fluorescent2 != fluorescentNameTemp && fluorescent3 != "nil" && fluorescent3 != fluorescentNameTemp && fluorescent4 != "nil" && fluorescent4 != fluorescentNameTemp && fluorescent5 != "nil" && fluorescent5 != fluorescentNameTemp && fluorescent6 == "nil") fluorescent6 = fluorescentNameTemp;
                        }
                    }
                }
            }
        }
    }
    
    if (fluorescent1 != "nil"){
        fluorescentFileNoCount++;
        arrayFileIFData [0] = fluorescent1;
    }
    if (fluorescent2 != "nil"){
        fluorescentFileNoCount++;
        arrayFileIFData [2] = fluorescent2;
    }
    if (fluorescent3 != "nil"){
        fluorescentFileNoCount++;
        arrayFileIFData [4] = fluorescent3;
    }
    if (fluorescent4 != "nil"){
        fluorescentFileNoCount++;
        arrayFileIFData [6] = fluorescent4;
    }
    if (fluorescent5 != "nil"){
        fluorescentFileNoCount++;
        arrayFileIFData [8] = fluorescent5;
    }
    if (fluorescent6 != "nil"){
        fluorescentFileNoCount++;
        arrayFileIFData [10] = fluorescent6;
    }
    
    int sameNameFind = 0;
    
    if (maxWNumber == 2 && fluorescent1 == "nil") sameNameFind = 1;
    else if (maxWNumber == 3 && fluorescent2 == "nil") sameNameFind = 1;
    else if (maxWNumber == 4 && fluorescent3 == "nil") sameNameFind = 1;
    else if (maxWNumber == 5 && fluorescent4 == "nil") sameNameFind = 1;
    else if (maxWNumber == 6 && fluorescent5 == "nil") sameNameFind = 1;
    else if (maxWNumber == 7 && fluorescent6 == "nil") sameNameFind = 1;
    
    if (sameNameFind == 0){
        terminationFlag = 1;
        
        ofstream oin;
        
        do{
            
            oin.open(fileIFDataPath.c_str(), ios::out);
            
            if (oin.is_open()){
                for (int counter1 = 0; counter1 < 12; counter1++) oin<<arrayFileIFData [counter1]<<endl;
                oin.close();
                
                if (dicFileCount != 0 && fileDicOrder == 0){
                    fluorescentNameFlag = 1;
                    
                    oin.open(fileDataPath.c_str(), ios::out);
                    
                    oin<<"nil"<<endl;
                    
                    if (singleDualStatus == 1) oin<<"1"<<endl;
                    else oin<<"2"<<endl;
                    
                    oin<<fluorescent1<<endl;
                    oin<<fluorescent2<<endl;
                    oin<<fluorescent3<<endl;
                    oin<<fluorescent4<<endl;
                    oin<<fluorescent5<<endl;
                    oin<<fluorescent6<<endl;
                    
                    if (fluorescentFileNoCount == 1) oin<<"1"<<endl;
                    else if (fluorescentFileNoCount == 2) oin<<"2"<<endl;
                    else if (fluorescentFileNoCount == 3) oin<<"3"<<endl;
                    else if (fluorescentFileNoCount == 4) oin<<"4"<<endl;
                    else if (fluorescentFileNoCount == 5) oin<<"5"<<endl;
                    else oin<<"6"<<endl;
                    
                    oin<<"nil"<<endl;
                    oin<<"nil"<<endl;
                    
                    oin.close();
                    
                    oin.open(fileDataSavePath.c_str(), ios::out);
                    
                    oin<<"nil"<<endl;
                    
                    if (singleDualStatus == 1) oin<<"1"<<endl;
                    else oin<<"2"<<endl;
                    
                    oin<<fluorescent1<<endl;
                    oin<<fluorescent2<<endl;
                    oin<<fluorescent3<<endl;
                    oin<<fluorescent4<<endl;
                    oin<<fluorescent5<<endl;
                    oin<<fluorescent6<<endl;
                    
                    if (fluorescentFileNoCount == 1) oin<<"1"<<endl;
                    else if (fluorescentFileNoCount == 2) oin<<"2"<<endl;
                    else if (fluorescentFileNoCount == 3) oin<<"3"<<endl;
                    else if (fluorescentFileNoCount == 4) oin<<"4"<<endl;
                    else if (fluorescentFileNoCount == 5) oin<<"5"<<endl;
                    else oin<<"6"<<endl;
                    
                    oin<<"nil"<<endl;
                    oin<<"nil"<<endl;
                    
                    oin.close();
                    
                    [fluorescentDisplay1 setStringValue:@(fluorescent1.c_str())];
                    [fluorescentDisplay2 setStringValue:@(fluorescent2.c_str())];
                    [fluorescentDisplay3 setStringValue:@(fluorescent3.c_str())];
                    [fluorescentDisplay4 setStringValue:@(fluorescent4.c_str())];
                    [fluorescentDisplay5 setStringValue:@(fluorescent5.c_str())];
                    [fluorescentDisplay6 setStringValue:@(fluorescent6.c_str())];
                }
                else{
                    
                    [loadingStatus setStringValue:@"nil"];
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"DIC File Missing"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                    
                    initialUploadStart = 0;
                    fileListCheckFlag = 0;
                    fluorescentFileNoCount = 0;
                    singleDualStatus = 0;
                    fileSingleDualFlag = 0;
                    fluorescent1 = "nil";
                    fluorescent2 = "nil";
                    fluorescent3 = "nil";
                    fluorescent4 = "nil";
                    fluorescent5 = "nil";
                    fluorescent6 = "nil";
                    latestBodyNoHold = 0;
                    latestTimePointHold = 0;
                    
                    remove(fileDataPath.c_str());
                }
                
                terminationFlag = 0;
            }
            
        } while (terminationFlag == 1);
    }
    else{
        
        [loadingStatus setStringValue:@"nil"];
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Duplicate Name Detected"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
        
        initialUploadStart = 0;
        fileListCheckFlag = 0;
        fluorescentFileNoCount = 0;
        singleDualStatus = 0;
        fileSingleDualFlag = 0;
        fluorescent1 = "nil";
        fluorescent2 = "nil";
        fluorescent3 = "nil";
        fluorescent4 = "nil";
        fluorescent5 = "nil";
        fluorescent6 = "nil";
        latestBodyNoHold = 0;
        latestTimePointHold = 0;
        
        remove(fileDataPath.c_str());
    }
}

-(void)fileSizeDetermination{
    [loadingStatus setStringValue:@"File Size Determination"];
    
    int checkCount = 0;
    long sizeForCopy = 0;
    int detectedFOVNo = 0;
    fileNameTableCount = 0;
    int terminationFlag = 0;
    
    directoryInfoHoldCount = 0;
    
    int totalFileNo = 0;
    
    if (singleDualStatus == 1) totalFileNo = atoi(totalFOVNoHold.c_str());
    if (singleDualStatus == 2) totalFileNo = atoi(totalFOVNoHold.c_str())+atoi(totalFOVNoHold.c_str())*fluorescentFileNoCount;
    
    do{
        
        terminationFlag = 1;
        DIR *dir;
        struct dirent *dent;
        
        dir = opendir(directoryPathForPC.c_str());
        
        if (dir != NULL){
            string entry;
            
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if ((int)entry.find(flProcessName) != -1 && (int)entry.find(tiffExtension) != -1){
                    if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                    arrayDirectoryInfoHold [directoryInfoHoldCount] = entry, directoryInfoHoldCount++;
                }
            }
            
            closedir(dir);
            
            //-------Directory Sort------
            NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
            
            for (int counter1 = 0; counter1 < directoryInfoHoldCount; counter1++){
                [unsortedArray addObject:@(arrayDirectoryInfoHold [counter1].c_str())];
            }
            
            [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
            
            for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                arrayDirectoryInfoHold [counter1] = [unsortedArray [counter1] UTF8String];
            }
        }
        
        if (directoryInfoHoldCount <= totalFileNo){
            fileNoMinimalHold = directoryInfoHoldCount;
            terminationFlag = 0;
        }
        else directoryInfoHoldCount = 0;
        
    } while (terminationFlag == 1);
    
    if (directoryInfoHoldCount != 0){
        string entry;
        string fileDirectoryPath;
        string tempName;
        string bodyNameExtract;
        string lastString;
        
        struct stat sizeOfFile;
        
        int findString1 = 0;
        
        for (int counter1 = 0; counter1 < directoryInfoHoldCount; counter1++){
            entry = arrayDirectoryInfoHold [counter1];
            
            findString1 = (int)entry.find(flProcessName);
            
            if (findString1 > 0){
                if (entry.substr((unsigned long)findString1-1, 1) != "_") findString1 = -1;
            }
            
            if (entry != "." && entry != ".." && entry != ".DS_Store" && findString1 != -1){
                bodyNameExtract = entry.substr((unsigned long)findString1).substr(0, entry.substr((unsigned long)findString1).find("_"));
                
                do{
                    
                    terminationFlag = 1;
                    
                    lastString = bodyNameExtract.substr(bodyNameExtract.length()-1, 1);
                    
                    if (lastString == "0" || lastString == "1" || lastString == "2" || lastString == "3" || lastString == "4" || lastString == "5" || lastString == "6" || lastString == "7" || lastString == "8" || lastString == "9"){
                        bodyNameExtract = bodyNameExtract.substr(0, bodyNameExtract.length()-1);
                    }
                    else terminationFlag = 0;
                    
                } while (terminationFlag == 1);
                
                if (bodyNameExtract == flProcessName){
                    fileDirectoryPath = directoryPathForPC+"/"+entry;
                    
                    if (stat(fileDirectoryPath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                        
                        if (fileNameTableCount+10 > fileNameTableLimit) [self fileNameTableUpDate];
                        
                        checkCount++;
                        
                        if (sizeForCopy > fileImageSize) fileImageSize = (int)sizeForCopy;
                        
                        arrayFileNameTable [fileNameTableCount] = entry, fileNameTableCount++;
                    }
                }
            }
        }
    }
    
    if (singleDualStatus == 1){
        if (fileNoMinimalHold > checkCount) detectedFOVNo = fileNoMinimalHold;
        else detectedFOVNo = checkCount;
    }
    if (singleDualStatus == 2){
        if (fileNoMinimalHold > checkCount) detectedFOVNo = fileNoMinimalHold/(fluorescentFileNoCount+1);
        else detectedFOVNo = checkCount/(fluorescentFileNoCount+1);
    }
    
    [detectedFOV setIntegerValue:detectedFOVNo];
    
    tableViewCall = 1;
    
    if (fileImageSize != 0 && checkCount == totalFileNo){
        fileSizeSetFlag = 1;
        terminationFlag = 1;
        
        ofstream oin;
        
        do{
            
            oin.open(fileDataPath.c_str(), ios::out);
            
            if (oin.is_open()){
                string extension = to_string(fileImageSize);
                oin<<extension<<endl;
                
                if (singleDualStatus == 1) oin<<"1"<<endl;
                else oin<<"2"<<endl;
                
                oin<<fluorescent1<<endl;
                oin<<fluorescent2<<endl;
                oin<<fluorescent3<<endl;
                oin<<fluorescent4<<endl;
                oin<<fluorescent5<<endl;
                oin<<fluorescent6<<endl;
                
                if (fluorescentFileNoCount == 1) oin<<"1"<<endl;
                else if (fluorescentFileNoCount == 2) oin<<"2"<<endl;
                else if (fluorescentFileNoCount == 3) oin<<"3"<<endl;
                else if (fluorescentFileNoCount == 4) oin<<"4"<<endl;
                else if (fluorescentFileNoCount == 5) oin<<"5"<<endl;
                else oin<<"6"<<endl;
                
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                
                oin.close();
                
                oin.open(fileDataSavePath.c_str(), ios::out);
                extension = to_string(fileImageSize);
                oin<<extension<<endl;
                
                if (singleDualStatus == 1) oin<<"1"<<endl;
                else oin<<"2"<<endl;
                
                oin<<fluorescent1<<endl;
                oin<<fluorescent2<<endl;
                oin<<fluorescent3<<endl;
                oin<<fluorescent4<<endl;
                oin<<fluorescent5<<endl;
                oin<<fluorescent6<<endl;
                
                if (fluorescentFileNoCount == 1) oin<<"1"<<endl;
                else if (fluorescentFileNoCount == 2) oin<<"2"<<endl;
                else if (fluorescentFileNoCount == 3) oin<<"3"<<endl;
                else if (fluorescentFileNoCount == 4) oin<<"4"<<endl;
                else if (fluorescentFileNoCount == 5) oin<<"5"<<endl;
                else oin<<"6"<<endl;
                
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                
                oin.close();
                
                loadingCount = 0;
                [loadingMark setTextColor:[NSColor blackColor]];
                [loadingMark setStringValue:@"H"];
                
                terminationFlag = 0;
            }
            
        } while (terminationFlag == 1);
    }
    else{
        
        [loadingStatus setStringValue:@"File Size Determination: Waiting for Image Acquisition"];
        
        if (loadingCount == 0){
            loadingCount = 1;
            [loadingMark setTextColor:[NSColor redColor]];
            [loadingMark setStringValue:@"H"];
        }
        else if (loadingCount == 1){
            loadingCount = 0;
            [loadingMark setTextColor:[NSColor greenColor]];
            [loadingMark setStringValue:@"H"];
        }
    }
    
    readingTimingFlag = 0;
}

-(void)initialFileUpLoad{
    string *fileNameTemp;
    string *fileNameTemp2;
    
    //-------Free hard drive size check----------
    int totalFileNoTemp = 0;
    
    NSDictionary *dicVol = [[NSFileManager defaultManager] attributesOfFileSystemForPath: @"/" error:nil];
    unsigned long freeSize = [[dicVol objectForKey: NSFileSystemFreeSize] unsignedLongLongValue];
    
    if (singleDualStatus == 1) totalFileNoTemp = atoi(totalFOVNoHold.c_str());
    else if (singleDualStatus == 2) totalFileNoTemp = atoi(totalFOVNoHold.c_str())+atoi(totalFOVNoHold.c_str())*fluorescentFileNoCount;
    
    unsigned long fileZize = (unsigned long)fileImageSize*(unsigned long)totalFileNoTemp*2;
    
    //cout<<fileImageSize<<" "<<totalFileNoTemp<<" "<<fileImageSize*totalFileNoTemp*2<<" "<<freeSize<<" "<<fileZize<<" fileSize"<<endl;
    
    if (fileZize < freeSize){
        fileNameTemp = new string [fileNameTableCount];
        fileNameTemp2 = new string [fileNameTableCount];
        int fileNameTempCount = 0;
        int fileNameTempCount2 = 0;
        int entryCount = 0;
        
        for (int counter1 = 0; counter1 < fileNameTableCount; counter1++){
            if ((int)arrayFileNameTable [counter1].find("DIC") != -1){
                fileNameTemp [fileNameTempCount] = arrayFileNameTable [counter1], fileNameTempCount++;
                arrayFileNameTable [counter1] = "nil";
            }
        }
        
        for (int counter1 = 0; counter1 < fileNameTableCount; counter1++){
            if (arrayFileNameTable [counter1] != "nil"){
                fileNameTemp2 [fileNameTempCount2] = arrayFileNameTable [counter1], fileNameTempCount2++;
            }
        }
        
        for (int counter1 = 0; counter1 < fileNameTempCount2; counter1++){
            arrayFileNameTable [entryCount] = fileNameTemp2 [counter1], entryCount++;
        }
        
        for (int counter1 = 0; counter1 < fileNameTempCount; counter1++){
            arrayFileNameTable [entryCount] = fileNameTemp [counter1], entryCount++;
        }
        
        delete [] fileNameTemp;
        delete [] fileNameTemp2;
        
        int findString1 = (int)arrayFileNameTable [0].find(flProcessName);
        string bodyNameExtract = arrayFileNameTable [0].substr((unsigned long)findString1).substr(0, arrayFileNameTable [0].substr((unsigned long)findString1).find("_"));
        
        latestBodyNoHold = atoi(bodyNameExtract.substr(flProcessName.length()).c_str());
        latestTimePointHold = atoi(arrayFileNameTable [0].substr(arrayFileNameTable [0].find("_t")+2, arrayFileNameTable [0].find(tiffExtension)-arrayFileNameTable [0].find("_t")-2).c_str());
        
        ofstream oin;
        
        int terminationFlag = 1;
        
        do{
            
            oin.open(fileDataPath.c_str(), ios::out);
            
            if (oin.is_open()){
                oin<<to_string(fileImageSize)<<endl;
                
                if (singleDualStatus == 1) oin<<"1"<<endl;
                else oin<<"2"<<endl;
                
                oin<<fluorescent1<<endl;
                oin<<fluorescent2<<endl;
                oin<<fluorescent3<<endl;
                oin<<fluorescent4<<endl;
                oin<<fluorescent5<<endl;
                oin<<fluorescent6<<endl;
                
                if (fluorescentFileNoCount == 1) oin<<"1"<<endl;
                else if (fluorescentFileNoCount == 2) oin<<"2"<<endl;
                else if (fluorescentFileNoCount == 3) oin<<"3"<<endl;
                else if (fluorescentFileNoCount == 4) oin<<"4"<<endl;
                else if (fluorescentFileNoCount == 5) oin<<"5"<<endl;
                else oin<<"6"<<endl;
                
                oin<<latestBodyNoHold<<endl;
                oin<<latestTimePointHold<<endl;
                
                oin.close();
                
                oin.open(fileDataSavePath.c_str(), ios::out);
                oin<<to_string(fileImageSize)<<endl;
                
                if (singleDualStatus == 1) oin<<"1"<<endl;
                else oin<<"2"<<endl;
                
                oin<<fluorescent1<<endl;
                oin<<fluorescent2<<endl;
                oin<<fluorescent3<<endl;
                oin<<fluorescent4<<endl;
                oin<<fluorescent5<<endl;
                oin<<fluorescent6<<endl;
                
                if (fluorescentFileNoCount == 1) oin<<"1"<<endl;
                else if (fluorescentFileNoCount == 2) oin<<"2"<<endl;
                else if (fluorescentFileNoCount == 3) oin<<"3"<<endl;
                else if (fluorescentFileNoCount == 4) oin<<"4"<<endl;
                else if (fluorescentFileNoCount == 5) oin<<"5"<<endl;
                else oin<<"6"<<endl;
                
                oin<<latestBodyNoHold<<endl;
                oin<<latestTimePointHold<<endl;
                
                oin.close();
                
                copyStartFlag = 1;
                terminationFlag = 0;
            }
            
        } while (terminationFlag == 1);
    }
    else{
        
        [loadingStatus setStringValue:@"nil"];
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Disk Space Low"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
        
        initialUploadStart = 0;
        fileListCheckFlag = 0;
        fileSizeSetFlag = 0;
        fluorescentNameFlag = 0;
        fileImageSize = 0;
        fluorescentFileNoCount = 0;
        singleDualStatus = 0;
        fluorescent1 = "nil";
        fluorescent2 = "nil";
        fluorescent3 = "nil";
        fluorescent4 = "nil";
        fluorescent5 = "nil";
        fluorescent6 = "nil";
        
        latestBodyNoHold = 0;
        latestTimePointHold = 0;
        
        remove(fileDataPath.c_str());
    }
}

-(void)fileListCheckIF{
    [loadingStatus setStringValue:@"Stage Positions and Time Points Check"];
    
    string firstTimePoint = "";
    string timeString;
    lowestTime = 10000;
    lowestBodyNumber = 10000;
    fileNameTableCount = 0;
    int timeLapsFlag = 0;
    int terminationFlag = 0;
    int loopCount = 0;
    
    directoryInfoHoldCount = 0;
    
    do{
        
        terminationFlag = 1;
        DIR *dir;
        struct dirent *dent;
        
        dir = opendir(directoryPathForPC.c_str());
        
        if (dir != NULL){
            string entry;
            
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if ((int)entry.find(flProcessName) != -1 && (int)entry.find(tiffExtension) != -1){
                    if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                    arrayDirectoryInfoHold [directoryInfoHoldCount] = entry, directoryInfoHoldCount++;
                }
            }
            
            closedir(dir);
            
            //-------Directory Sort------
            NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
            
            for (int counter1 = 0; counter1 < directoryInfoHoldCount; counter1++){
                [unsortedArray addObject:@(arrayDirectoryInfoHold [counter1].c_str())];
            }
            
            [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
            
            for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                arrayDirectoryInfoHold [counter1] = [unsortedArray [counter1] UTF8String];
            }
        }
        
        if (directoryInfoHoldCount != 0) terminationFlag = 0;
        else{
            
            directoryInfoHoldCount = 0;
            loopCount++;
            
            if (loopCount == 1000) terminationFlag = 0;
        }
        
    } while (terminationFlag == 1);
    
    if (loopCount != 1000){
        if (directoryInfoHoldCount != 0){
            string entry;
            string fileDirectoryPath;
            string tempName;
            string lastString;
            string bodyNameExtract;
            string extractStringTemp;
            
            int bodyNameLength = (int)flProcessName.length();
            int findString1 = 0;
            int findString2 = 0;
            
            for (int counter1 = 0; counter1 < directoryInfoHoldCount; counter1++){
                entry = arrayDirectoryInfoHold [counter1];
                findString1 = (int)entry.find(flProcessName);
                
                if (findString1 > 0){
                    if (entry.substr((unsigned long)findString1-1, 1) != "_") findString1 = -1;
                }
                
                if (entry != "." && entry != ".." && entry != ".DS_Store" && findString1 != -1){
                    tempName = entry.substr((unsigned long)findString1);
                    findString2 = (int)tempName.find("_");
                    bodyNameExtract = tempName.substr(0, (unsigned long)findString2);
                    
                    //cout<<tempName<<" "<<bodyNameExtract<<" Name"<<endl;
                    
                    do{
                        
                        terminationFlag = 1;
                        
                        lastString = bodyNameExtract.substr(bodyNameExtract.length()-1, 1);
                        
                        if (lastString == "0" || lastString == "1" || lastString == "2" || lastString == "3" || lastString == "4" || lastString == "5" || lastString == "6" || lastString == "7" || lastString == "8" || lastString == "9"){
                            bodyNameExtract = bodyNameExtract.substr(0, bodyNameExtract.length()-1);
                        }
                        else terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                    
                    if (bodyNameExtract == flProcessName && (int)entry.find("_s") != -1 && (int)entry.find("_t") != -1){
                        tempName = entry.substr(entry.find(flProcessName));
                        extractStringTemp = tempName.substr((unsigned long)bodyNameLength, tempName.find("_")-(unsigned long)bodyNameLength);
                        
                        if (lowestBodyNumber > atoi(extractStringTemp.c_str())) lowestBodyNumber = atoi(extractStringTemp.c_str());
                    }
                }
            }
            
            for (int counter1 = 0; counter1 < directoryInfoHoldCount; counter1++){
                entry = arrayDirectoryInfoHold [counter1];
                findString1 = (int)entry.find(flProcessName);
                
                if (findString1 > 0){
                    if (entry.substr((unsigned long)findString1-1, 1) != "_") findString1 = -1;
                }
                
                if (entry != "." && entry != ".." && entry != ".DS_Store" && findString1 != -1){
                    tempName = entry.substr((unsigned long)findString1);
                    bodyNameExtract = tempName.substr(0, tempName.find("_"));
                    
                    do{
                        
                        terminationFlag = 1;
                        
                        lastString = bodyNameExtract.substr(bodyNameExtract.length()-1, 1);
                        
                        if (lastString == "0" || lastString == "1" || lastString == "2" || lastString == "3" || lastString == "4" || lastString == "5" || lastString == "6" || lastString == "7" || lastString == "8" || lastString == "9"){
                            bodyNameExtract = bodyNameExtract.substr(0, bodyNameExtract.length()-1);
                        }
                        else terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                    
                    if (bodyNameExtract == flProcessName && (int)entry.find("_s") != -1 && (int)entry.find("_t") != -1){
                        timeString = entry.substr(entry.find("_t")+2, entry.find(tiffExtension)-entry.find("_t")-2);
                        
                        if (lowestTime > atoi(timeString.c_str())) lowestTime = atoi(timeString.c_str());
                        
                        tempName = entry.substr(entry.find(flProcessName));
                        extractStringTemp = tempName.substr((unsigned long)bodyNameLength, tempName.find("_")-(unsigned long)bodyNameLength);
                        
                        if (lowestBodyNumber == atoi(extractStringTemp.c_str())){
                            lowestBodyNumber = atoi(extractStringTemp.c_str());
                            
                            if ((int)entry.find("_t") == -1) timeLapsFlag = 1;
                            
                            timeString = entry.substr(entry.find("_t")+2, entry.find(tiffExtension)-entry.find("_t")-2);
                            
                            if (lowestTime > atoi(timeString.c_str())) lowestTime = atoi(timeString.c_str());
                            
                            fileNameTableCount++;
                        }
                    }
                }
            }
        }
        
        if (fileNameTableCount != 0 && lowestTime != 10000 && lowestBodyNumber != 10000 && timeLapsFlag == 0){
            fileListCheckFlag = 1;
            tableViewCall = 1;
        }
        else{
            
            [loadingStatus setStringValue:@"nil"];
            
            if (timeLapsFlag == 1){
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Time Lapse Mode Off"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"File was not Found"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
            }
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
            
            initialUploadStart = 0;
            fileListCheckFlag = 0;
            tableViewCall = 1;
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Relevant File Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
        
        initialUploadStart = 0;
        fileListCheckFlag = 0;
        tableViewCall = 1;
    }
}

-(void)singleDualFindIF{
    [loadingStatus setStringValue:@"Image File Format Check: DIC or DIC+Fluorescent"];
    
    int singleDoubleStatusTemp = 0;
    int findDICTemp = 0;
    int terminationFlag = 0;
    
    directoryInfoHoldCount = 0;
    
    do{
        
        terminationFlag = 1;
        DIR *dir;
        struct dirent *dent;
        
        dir = opendir(directoryPathForPC.c_str());
        
        if (dir != NULL){
            string entry;
            
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if ((int)entry.find(flProcessName) != -1 && (int)entry.find("TIF") != -1){
                    if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                    arrayDirectoryInfoHold [directoryInfoHoldCount] = entry, directoryInfoHoldCount++;
                }
            }
            
            closedir(dir);
            
            //-------Directory Sort------
            NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
            
            for (int counter1 = 0; counter1 < directoryInfoHoldCount; counter1++){
                [unsortedArray addObject:@(arrayDirectoryInfoHold [counter1].c_str())];
            }
            
            [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
            
            for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                arrayDirectoryInfoHold [counter1] = [unsortedArray [counter1] UTF8String];
            }
        }
        
        if (directoryInfoHoldCount != 0) terminationFlag = 0;
        else directoryInfoHoldCount = 0;
        
    } while (terminationFlag == 1);
    
    if (directoryInfoHoldCount != 0){
        string entry;
        string tempName;
        string bodyNameExtract;
        string lastString;
        string stringExtract;
        
        int findString1 = 0;
        
        for (int counter1 = 0; counter1 < directoryInfoHoldCount; counter1++){
            entry = arrayDirectoryInfoHold [counter1];
            
            findString1 = (int)entry.find(flProcessName);
            
            if (findString1 > 0){
                if (entry.substr((unsigned long)findString1-1, 1) != "_") findString1 = -1;
            }
            
            if (entry != "." && entry != ".." && entry != ".DS_Store" && findString1 != -1){
                tempName = entry.substr((unsigned long)findString1);
                bodyNameExtract = tempName.substr(0, tempName.find("_"));
                
                do{
                    
                    terminationFlag = 1;
                    
                    lastString = bodyNameExtract.substr(bodyNameExtract.length()-1, 1);
                    
                    if (lastString == "0" || lastString == "1" || lastString == "2" || lastString == "3" || lastString == "4" || lastString == "5" || lastString == "6" || lastString == "7" || lastString == "8" || lastString == "9"){
                        bodyNameExtract = bodyNameExtract.substr(0, bodyNameExtract.length()-1);
                    }
                    else terminationFlag = 0;
                    
                } while (terminationFlag == 1);
                
                if (bodyNameExtract == flProcessName){
                    stringExtract = entry.substr(entry.find("_s")-3, 3);
                    
                    if (stringExtract != "DIC"){
                        if ((int)entry.find("_w") != -1) singleDoubleStatusTemp = 2;
                        else{
                            
                            singleDoubleStatusTemp = 1;
                            findDICTemp = 1;
                        }
                    }
                    else{
                        
                        if (singleDoubleStatusTemp == 0) singleDoubleStatusTemp = 1;
                        
                        findDICTemp = 1;
                    }
                }
            }
        }
    }
    
    if (findDICTemp == 0) singleDoubleStatusTemp = 3;
    
    if (singleDoubleStatusTemp == 1){
        [loadingStatus setStringValue:@"nil"];
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Fluorescent File Missing: Clear Oldest Files And Re-do"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
        
        initialUploadStart = 0;
        fileListCheckFlag = 0;
    }
    else if (singleDoubleStatusTemp == 2){
        singleDualStatus = 2;
        fileSingleDualFlag = 1;
    }
    else if (singleDoubleStatusTemp == 3){
        [loadingStatus setStringValue:@"nil"];
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"DIC File Missing/Clear Oldest Files And Re-do"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
        
        initialUploadStart = 0;
        fileListCheckFlag = 0;
    }
    
    if (singleDoubleStatusTemp != 0){
        ofstream oin;
        
        terminationFlag = 1;
        
        do{
            
            oin.open(fileDataPath.c_str(), ios::out);
            
            if (oin.is_open()){
                oin<<"nil"<<endl;
                
                if (singleDualStatus == 1) oin<<"1"<<endl;
                else oin<<"2"<<endl;
                
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                oin.close();
                
                oin.open(fileDataSavePath.c_str(), ios::out);
                oin<<"nil"<<endl;
                
                if (singleDualStatus == 1) oin<<"1"<<endl;
                else oin<<"2"<<endl;
                
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                oin.close();
                
                terminationFlag = 0;
                
                if (singleDualStatus == 1) [singleDualDisplay setStringValue:@"DIC"];
                if (singleDualStatus == 2) [singleDualDisplay setStringValue:@"DIC+FLU"];
            }
            
        } while (terminationFlag == 1);
    }
}

-(void)fileSizeDeterminationIF{
    string entry;
    
    [loadingStatus setStringValue:@"File Size Determination"];
    
    int checkCount = 0;
    int totalFileNo = 0;
    int detectedFOVNo = 0;
    int terminationFlag = 0;
    fileNameTableCount = 0;
    long sizeForCopy = 0;
    
    if (singleDualStatus == 1) totalFileNo = atoi(totalFOVNoHold.c_str());
    if (singleDualStatus == 2) totalFileNo = atoi(totalFOVNoHold.c_str())+atoi(totalFOVNoHold.c_str())*fluorescentFileNoCount;
    
    directoryInfoHoldCount = 0;
    
    do{
        
        terminationFlag = 1;
        DIR *dir;
        struct dirent *dent;
        
        dir = opendir(directoryPathForPC.c_str());
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if ((int)entry.find(flProcessName) != -1 && (int)entry.find("TIF") != -1){
                    if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                    arrayDirectoryInfoHold [directoryInfoHoldCount] = entry, directoryInfoHoldCount++;
                }
            }
            
            closedir(dir);
            
            //-------Directory Sort------
            NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
            
            for (int counter1 = 0; counter1 < directoryInfoHoldCount; counter1++){
                [unsortedArray addObject:@(arrayDirectoryInfoHold [counter1].c_str())];
            }
            
            [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
            
            for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                arrayDirectoryInfoHold [counter1] = [unsortedArray [counter1] UTF8String];
            }
        }
        
        if (directoryInfoHoldCount <= totalFileNo){
            fileNoMinimalHold = directoryInfoHoldCount;
            terminationFlag = 0;
        }
        else directoryInfoHoldCount = 0;
        
    } while (terminationFlag == 1);
    
    if (directoryInfoHoldCount != 0){
        string fileDirectoryPath;
        string tempName;
        string bodyNameExtract;
        string lastString;
        string fluorescentNameTemp;
        string timeString;
        string extractStringTemp;
        string extractStringTemp2;
        string extractStringTemp3;
        string extractStringTemp4;
        
        struct stat sizeOfFile;
        
        int bodyNameLength = (int)flProcessName.length();
        
        arrayFileIFData [1] = "0";
        arrayFileIFData [3] = "0";
        arrayFileIFData [5] = "0";
        arrayFileIFData [7] = "0";
        arrayFileIFData [9] = "0";
        arrayFileIFData [11] = "0";
        
        int findString1 = 0;
        
        for (int counter1 = 0; counter1 < directoryInfoHoldCount; counter1++){
            entry = arrayDirectoryInfoHold [counter1];
            
            findString1 = (int)entry.find(flProcessName);
            
            if (findString1 > 0){
                if (entry.substr((unsigned long)findString1-1, 1) != "_") findString1 = -1;
            }
            
            if (entry != "." && entry != ".." && entry != ".DS_Store" && findString1 != -1){
                tempName = entry.substr((unsigned long)findString1);
                bodyNameExtract = tempName.substr(0, tempName.find("_"));
                
                do{
                    
                    terminationFlag = 1;
                    
                    lastString = bodyNameExtract.substr(bodyNameExtract.length()-1, 1);
                    
                    if (lastString == "0" || lastString == "1" || lastString == "2" || lastString == "3" || lastString == "4" || lastString == "5" || lastString == "6" || lastString == "7" || lastString == "8" || lastString == "9"){
                        bodyNameExtract = bodyNameExtract.substr(0, bodyNameExtract.length()-1);
                    }
                    else terminationFlag = 0;
                    
                } while (terminationFlag == 1);
                
                if (bodyNameExtract == flProcessName){
                    timeString = entry.substr(entry.find("_t")+2, entry.find(tiffExtension)-entry.find("_t")-2);
                    tempName = entry.substr(entry.find(flProcessName));
                    
                    extractStringTemp = tempName.substr((unsigned long)bodyNameLength, tempName.find("_")-(unsigned long)bodyNameLength);
                    
                    if (lowestTime == atoi(timeString.c_str()) && lowestBodyNumber == atoi(extractStringTemp.c_str())){
                        fileDirectoryPath = directoryPathForPC+"/"+entry;
                        
                        if (stat(fileDirectoryPath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            if (fileNameTableCount+10 > fileNameTableLimit) [self fileNameTableUpDate];
                            
                            checkCount++;
                            
                            if (sizeForCopy > fileImageSize) fileImageSize = (int)sizeForCopy;
                            
                            arrayFileNameTable [fileNameTableCount] = entry, fileNameTableCount++;
                            
                            if ((int)entry.find("_w") != -1){
                                extractStringTemp2 = entry.substr(entry.find("_w")+1, entry.find("_s")-entry.find("_w")-1);
                                extractStringTemp4 = entry.substr(entry.find("_s")+2, entry.find("_t")-entry.find("_s")-1);
                                extractStringTemp2 = extractStringTemp2.substr(extractStringTemp2.find(" ")+1);
                                
                                if ((int)extractStringTemp2.find(" ") != -1) fluorescentNameTemp = extractStringTemp2.substr(extractStringTemp2.find(" ")+1);
                                else fluorescentNameTemp = "nil";
                                
                                if (arrayFileIFData [0] == fluorescentNameTemp){
                                    extractStringTemp3 = arrayFileIFData [1];
                                    int countTemp = atoi(extractStringTemp3.c_str());
                                    
                                    if (countTemp < atoi(extractStringTemp4.c_str())) countTemp = atoi(extractStringTemp4.c_str());
                                    
                                    extractStringTemp2 = to_string(countTemp);
                                    arrayFileIFData [1] = extractStringTemp2;
                                }
                                else if (arrayFileIFData [2] == fluorescentNameTemp){
                                    extractStringTemp3 = arrayFileIFData [3];
                                    int countTemp = atoi(extractStringTemp3.c_str());
                                    
                                    if (countTemp < atoi(extractStringTemp4.c_str())) countTemp = atoi(extractStringTemp4.c_str());
                                    
                                    extractStringTemp2 = to_string(countTemp);
                                    arrayFileIFData [3] = extractStringTemp2;
                                }
                                else if (arrayFileIFData [4] == fluorescentNameTemp){
                                    extractStringTemp3 = arrayFileIFData [5];
                                    int countTemp = atoi(extractStringTemp3.c_str());
                                    
                                    if (countTemp < atoi(extractStringTemp4.c_str())) countTemp = atoi(extractStringTemp4.c_str());
                                    
                                    extractStringTemp2 = to_string(countTemp);
                                    arrayFileIFData [5] = extractStringTemp2;
                                }
                                else if (arrayFileIFData [6] == fluorescentNameTemp){
                                    extractStringTemp3 = arrayFileIFData [7];
                                    int countTemp = atoi(extractStringTemp3.c_str());
                                    
                                    if (countTemp < atoi(extractStringTemp4.c_str())) countTemp = atoi(extractStringTemp4.c_str());
                                    
                                    extractStringTemp2 = to_string(countTemp);
                                    arrayFileIFData [7] = extractStringTemp2;
                                }
                                else if (arrayFileIFData [8] == fluorescentNameTemp){
                                    extractStringTemp3 = arrayFileIFData [9];
                                    int countTemp = atoi(extractStringTemp3.c_str());
                                    
                                    if (countTemp < atoi(extractStringTemp4.c_str())) countTemp = atoi(extractStringTemp4.c_str());
                                    
                                    extractStringTemp2 = to_string(countTemp);
                                    arrayFileIFData [9] = extractStringTemp2;
                                }
                                else if (arrayFileIFData [10] == fluorescentNameTemp){
                                    extractStringTemp3 = arrayFileIFData [11];
                                    int countTemp = atoi(extractStringTemp3.c_str());
                                    
                                    if (countTemp < atoi(extractStringTemp4.c_str())) countTemp = atoi(extractStringTemp4.c_str());
                                    
                                    extractStringTemp2 = to_string(countTemp);
                                    arrayFileIFData [11] = extractStringTemp2;
                                }
                            }
                        }
                    }
                }
            }
        }
        
        ofstream oin;
        
        terminationFlag = 1;
        
        do{
            
            oin.open(fileIFDataPath.c_str(), ios::out);
            
            if (oin.is_open()){
                for (int counter1 = 0; counter1 < 12; counter1++) oin<<arrayFileIFData [counter1]<<endl;
                oin.close();
                
                terminationFlag = 0;
            }
            
        } while (terminationFlag == 1);
    }
    
    if (singleDualStatus == 1){
        if (fileNoMinimalHold > checkCount) detectedFOVNo = checkCount;
        else detectedFOVNo = checkCount;
    }
    if (singleDualStatus == 2){
        if (fileNoMinimalHold > checkCount) detectedFOVNo = fileNoMinimalHold/(fluorescentFileNoCount+1);
        else detectedFOVNo = checkCount/(fluorescentFileNoCount+1);
    }
    
    [detectedFOV setIntegerValue:detectedFOVNo];
    
    tableViewCall = 1;
    
    if (fileImageSize != 0 && checkCount == totalFileNo){
        fileSizeSetFlag = 1;
        terminationFlag = 1;
        
        ofstream oin;
        
        do{
            
            oin.open(fileDataPath.c_str(), ios::out);
            
            if (oin.is_open()){
                string extension = to_string(fileImageSize);
                oin<<extension<<endl;
                
                if (singleDualStatus == 1) oin<<"1"<<endl;
                else oin<<"2"<<endl;
                
                oin<<fluorescent1<<endl;
                oin<<fluorescent2<<endl;
                oin<<fluorescent3<<endl;
                oin<<fluorescent4<<endl;
                oin<<fluorescent5<<endl;
                oin<<fluorescent6<<endl;
                
                if (fluorescentFileNoCount == 1) oin<<"1"<<endl;
                else if (fluorescentFileNoCount == 2) oin<<"2"<<endl;
                else if (fluorescentFileNoCount == 3) oin<<"3"<<endl;
                else if (fluorescentFileNoCount == 4) oin<<"4"<<endl;
                else if (fluorescentFileNoCount == 5) oin<<"5"<<endl;
                else oin<<"6"<<endl;
                
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                
                oin.close();
                
                oin.open(fileDataSavePath.c_str(), ios::out);
                extension = to_string(fileImageSize);
                oin<<extension<<endl;
                
                if (singleDualStatus == 1) oin<<"1"<<endl;
                else oin<<"2"<<endl;
                
                oin<<fluorescent1<<endl;
                oin<<fluorescent2<<endl;
                oin<<fluorescent3<<endl;
                oin<<fluorescent4<<endl;
                oin<<fluorescent5<<endl;
                oin<<fluorescent6<<endl;
                
                if (fluorescentFileNoCount == 1) oin<<"1"<<endl;
                else if (fluorescentFileNoCount == 2) oin<<"2"<<endl;
                else if (fluorescentFileNoCount == 3) oin<<"3"<<endl;
                else if (fluorescentFileNoCount == 4) oin<<"4"<<endl;
                else if (fluorescentFileNoCount == 5) oin<<"5"<<endl;
                else oin<<"6"<<endl;
                
                oin<<"nil"<<endl;
                oin<<"nil"<<endl;
                
                oin.close();
                
                terminationFlag = 0;
                
                loadingCount = 0;
                [loadingMark setTextColor:[NSColor blackColor]];
                [loadingMark setStringValue:@"H"];
            }
            
        } while (terminationFlag == 1);
    }
    else{
        
        [loadingStatus setStringValue:@"File Size Determination: Waiting for Image Acquisition"];
        
        if (loadingCount == 0){
            loadingCount = 1;
            [loadingMark setTextColor:[NSColor redColor]];
            [loadingMark setStringValue:@"H"];
        }
        else if (loadingCount == 1){
            loadingCount = 0;
            [loadingMark setTextColor:[NSColor greenColor]];
            [loadingMark setStringValue:@"H"];
        }
    }
    
    readingTimingFlag = 0;
}

-(IBAction)interruptionSet:(id)sender{
    if (initialUploadStart == 1){
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert addButtonWithTitle:@"Cancel"];
        [alert setMessageText:@"Interrupt Initial File Up-Loading?"];
        [alert setAlertStyle:NSAlertStyleWarning];
        
        if ([alert runModal] == NSAlertFirstButtonReturn) interruptionFlag = 1;
        
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)interruption{
    [loadingStatus setStringValue:@"nil"];
    
    loadingCount = 0;
    [loadingMark setTextColor:[NSColor blackColor]];
    [loadingMark setStringValue:@"H"];
    
    initialUploadStart = 0;
    fileListCheckFlag = 0;
    fileSizeSetFlag = 0;
    fluorescentNameFlag = 0;
    fileImageSize = 0;
    fluorescentFileNoCount = 0;
    singleDualStatus = 0;
    interruptionFlag = 0;
    fileSingleDualFlag = 0;
    latestBodyNoHold = 0;
    latestTimePointHold = 0;
    
    remove(fileDataPath.c_str());
    
    fluorescent1 = "nil";
    fluorescent2 = "nil";
    fluorescent3 = "nil";
    fluorescent4 = "nil";
    fluorescent5 = "nil";
    fluorescent6 = "nil";
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(int)numberOfRowsInTableView:(NSTableView *)aTableView{
    int tableViewContent = fileNameTableCount;
    return tableViewContent;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    string displayData1;
    string displayData2;
    
    NSAttributedString *attrStr;
    
    int numberOfFiles = (int)rowIndex+1;
    
    displayData1 = to_string(numberOfFiles);
    displayData2 = arrayFileNameTable [rowIndex];
    
    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
    [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
    [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
    
    if ([[aTableColumn identifier] isEqualToString:@"COL1"]){
        attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL2"]){
        attrStr = [[NSAttributedString alloc] initWithString:@(displayData2.c_str()) attributes:attributes];
    }
    else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    
    return attrStr;
}

-(IBAction)clearAll:(id)sender{
    if (flComputerDataName != "nil" && flUserName != "nil" && flProcessName != "nil" && totalFOVNoHold != "nil" && fileUpLoadingFlag == 2){
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert addButtonWithTitle:@"Cancel"];
        [alert setMessageText:@"Clear All Image Files"];
        [alert setInformativeText:@"Removing All Image Files With Analysis Name"];
        [alert setAlertStyle:NSAlertStyleWarning];
        
        if ([alert runModal] == NSAlertFirstButtonReturn){
            directoryInfoHoldCount = 0;
            
            DIR *dir;
            struct dirent *dent;
            
            dir = opendir(directoryPathForPC.c_str());
            
            if (dir != NULL){
                string entry;
                
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if ((int)entry.find(flProcessName) != -1){
                        if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                        arrayDirectoryInfoHold [directoryInfoHoldCount] = entry, directoryInfoHoldCount++;
                    }
                }
                
                closedir(dir);
                
                //-------Directory Sort------
                NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                
                for (int counter1 = 0; counter1 < directoryInfoHoldCount; counter1++){
                    [unsortedArray addObject:@(arrayDirectoryInfoHold [counter1].c_str())];
                }
                
                [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                
                for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                    arrayDirectoryInfoHold [counter1] = [unsortedArray [counter1] UTF8String];
                }
            }
            
            if (directoryInfoHoldCount != 0){
                string entry;
                string tempName;
                string bodyNameExtract;
                string lastString;
                string removeFilePath;
                
                int findMatch1 = 0;
                int terminationFlag = 0;
                
                for (int counter1 = 0; counter1 < directoryInfoHoldCount; counter1++){
                    entry = arrayDirectoryInfoHold [counter1] ;
                    
                    findMatch1 = (int)entry.find(flProcessName);
                    
                    if (findMatch1 > 0){
                        if (entry.substr((unsigned long)findMatch1-1, 1) != "_") findMatch1 = -1;
                    }
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store" && findMatch1 != -1){
                        tempName = entry.substr((unsigned long)findMatch1);
                        bodyNameExtract = tempName.substr(0, tempName.find("_"));
                        
                        do{
                            
                            terminationFlag = 1;
                            
                            lastString = bodyNameExtract.substr(bodyNameExtract.length()-1, 1);
                            
                            if (lastString == "0" || lastString == "1" || lastString == "2" || lastString == "3" || lastString == "4" || lastString == "5" || lastString == "6" || lastString == "7" || lastString == "8" || lastString == "9"){
                                bodyNameExtract = bodyNameExtract.substr(0, bodyNameExtract.length()-1);
                            }
                            else terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                        
                        if (bodyNameExtract == flProcessName){
                            if ((int)entry.find(flProcessName) != -1 && (int)entry.find(".nd") == -1){
                                removeFilePath = directoryPathForPC+"/"+entry;
                                remove(removeFilePath.c_str());
                            }
                        }
                    }
                }
            }
            
            fileNameTableCount = 0;
            tableViewCall = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)clearOld:(id)sender{
    if (flComputerDataName != "nil" && flUserName != "nil" && flProcessName != "nil" && totalFOVNoHold != "nil" && fileUpLoadingFlag == 2){
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert addButtonWithTitle:@"Cancel"];
        [alert setMessageText:@"Clear Previous Image Files"];
        [alert setInformativeText:@"Retain only most recent image files"];
        [alert setAlertStyle:NSAlertStyleWarning];
        
        if ([alert runModal] == NSAlertFirstButtonReturn){
            int maxBodyNo = 0;
            int maxTimePoint = 1;
            int bodyNameLength = (int)flProcessName.length();
            
            directoryInfoHoldCount = 0;
            
            DIR *dir;
            struct dirent *dent;
            
            dir = opendir(directoryPathForPC.c_str());
            
            if (dir != NULL){
                string entry;
                
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if ((int)entry.find(flProcessName) != -1){
                        if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                        arrayDirectoryInfoHold [directoryInfoHoldCount] = entry, directoryInfoHoldCount++;
                    }
                }
                
                closedir(dir);
                
                //-------Directory Sort------
                NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                
                for (int counter1 = 0; counter1 < directoryInfoHoldCount; counter1++){
                    [unsortedArray addObject:@(arrayDirectoryInfoHold [counter1].c_str())];
                }
                
                [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                
                for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                    arrayDirectoryInfoHold [counter1] = [unsortedArray [counter1] UTF8String];
                }
            }
            
            if (directoryInfoHoldCount != 0){
                string entry;
                string tempName;
                string bodyNameExtract;
                string lastString;
                string extractStringTemp;
                string removeFilePath;
                
                int findString1 = 0;
                int terminationFlag = 0;
                
                for (int counter1 = 0; counter1 < directoryInfoHoldCount; counter1++){
                    entry = arrayDirectoryInfoHold [counter1];
                    
                    findString1 = (int)entry.find(flProcessName);
                    
                    if (findString1 > 0){
                        if (entry.substr((unsigned long)findString1-1, 1) != "_")  findString1 = -1;
                    }
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store" && findString1 != -1){
                        tempName = entry.substr((unsigned long)findString1);
                        bodyNameExtract = tempName.substr(0, tempName.find("_"));
                        
                        do{
                            
                            terminationFlag = 1;
                            
                            lastString = bodyNameExtract.substr(bodyNameExtract.length()-1, 1);
                            
                            if (lastString == "0" || lastString == "1" || lastString == "2" || lastString == "3" || lastString == "4" || lastString == "5" || lastString == "6" || lastString == "7" || lastString == "8" || lastString == "9"){
                                bodyNameExtract = bodyNameExtract.substr(0, bodyNameExtract.length()-1);
                            }
                            else terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                        
                        if (bodyNameExtract == flProcessName && (int)entry.find("_s") != -1){
                            tempName = entry.substr(entry.find(flProcessName));
                            extractStringTemp = tempName.substr((unsigned long)bodyNameLength, tempName.find("_")-(unsigned long)bodyNameLength);
                            
                            if (atoi(extractStringTemp.c_str()) != 0 && atoi(extractStringTemp.c_str()) > maxBodyNo) maxBodyNo = atoi(extractStringTemp.c_str());
                        }
                    }
                }
                
                for (int counter1 = 0; counter1 < directoryInfoHoldCount; counter1++){
                    entry = arrayDirectoryInfoHold [counter1];
                    
                    findString1 = (int)entry.find(flProcessName);
                    
                    if (findString1 > 0){
                        if (entry.substr((unsigned long)findString1-1, 1) != "_")  findString1 = -1;
                    }
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store" && findString1 != -1){
                        tempName = entry.substr((unsigned long)findString1);
                        bodyNameExtract = tempName.substr(0, tempName.find("_"));
                        
                        do{
                            
                            terminationFlag = 1;
                            
                            lastString = bodyNameExtract.substr(bodyNameExtract.length()-1, 1);
                            
                            if (lastString == "0" || lastString == "1" || lastString == "2" || lastString == "3" || lastString == "4" || lastString == "5" || lastString == "6" || lastString == "7" || lastString == "8" || lastString == "9"){
                                bodyNameExtract = bodyNameExtract.substr(0, bodyNameExtract.length()-1);
                            }
                            else terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                        
                        if (bodyNameExtract == flProcessName && (int)entry.find("_s") != -1){
                            tempName = entry.substr(entry.find(flProcessName));
                            extractStringTemp = tempName.substr((unsigned long)bodyNameLength, tempName.find("_")-(unsigned long)bodyNameLength);
                            
                            if (maxBodyNo == atoi(extractStringTemp.c_str())){
                                extractStringTemp = entry.substr(entry.find("_t")+2, entry.find(tiffExtension)-entry.find("_t")-2);
                                
                                if (maxTimePoint < atoi(extractStringTemp.c_str())) maxTimePoint = atoi(extractStringTemp.c_str());
                            }
                        }
                    }
                }
                
                fileNameTableCount = 0;
                
                int extractStringTempInt = 0;
                
                for (int counter1 = 0; counter1 < directoryInfoHoldCount; counter1++){
                    entry = arrayDirectoryInfoHold [counter1];
                    
                    findString1 = (int)entry.find(flProcessName);
                    
                    if (findString1 > 0){
                        if (entry.substr((unsigned long)findString1-1, 1) != "_")  findString1 = -1;
                    }
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store" && findString1 != -1){
                        tempName = entry.substr((unsigned long)findString1);
                        bodyNameExtract = tempName.substr(0, tempName.find("_"));
                        
                        do{
                            
                            terminationFlag = 1;
                            
                            lastString = bodyNameExtract.substr(bodyNameExtract.length()-1, 1);
                            
                            if (lastString == "0" || lastString == "1" || lastString == "2" || lastString == "3" || lastString == "4" || lastString == "5" || lastString == "6" || lastString == "7" || lastString == "8" || lastString == "9"){
                                bodyNameExtract = bodyNameExtract.substr(0, bodyNameExtract.length()-1);
                            }
                            else terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                        
                        if (bodyNameExtract == flProcessName){
                            tempName = entry.substr(entry.find(flProcessName));
                            extractStringTemp = tempName.substr((unsigned long)bodyNameLength, tempName.find("_")-(unsigned long)bodyNameLength);
                            extractStringTempInt = atoi(extractStringTemp.c_str());
                            extractStringTemp = entry.substr(entry.find("_t")+2, entry.find(tiffExtension)-entry.find("_t")-2);
                            
                            if (extractStringTempInt == maxBodyNo && atoi(extractStringTemp.c_str()) == maxTimePoint){
                                if (fileNameTableCount+10 > fileNameTableLimit) [self fileNameTableUpDate];
                                
                                arrayFileNameTable [fileNameTableCount] = entry, fileNameTableCount++;
                            }
                            else{
                                
                                removeFilePath = directoryPathForPC+"/"+entry;
                                remove(removeFilePath.c_str());
                            }
                        }
                    }
                }
                
                tableViewCall = 1;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSAlert *alert2 = [[NSAlert alloc] init];
                [alert2 addButtonWithTitle:@"OK"];
                [alert2 setMessageText:@"Check Image Acquisition Computer/No file was found"];
                [alert2 setAlertStyle:NSAlertStyleWarning];
                [alert2 runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
    }
    else{
        
        if (fileUpLoadingFlag == 3){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"IF Mode On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)clearOldest:(id)sender{
    /*
     For IF mode
     */
    
    if (flComputerDataName != "nil" && flUserName != "nil" && flProcessName != "nil" && totalFOVNoHold != "nil" && (fileUpLoadingFlag == 3 || fileUpLoadingFlag == 4) && exitFlag != 3){
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert addButtonWithTitle:@"Cancel"];
        [alert setMessageText:@"Clear The Oldest Image Files"];
        [alert setAlertStyle:NSAlertStyleWarning];
        
        if ([alert runModal] == NSAlertFirstButtonReturn){
            int bodyNameLength = (int)flProcessName.length();
            
            directoryInfoHoldCount = 0;
            
            DIR *dir;
            struct dirent *dent;
            
            dir = opendir(directoryPathForPC.c_str());
            
            if (dir != NULL){
                string entry;
                
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if ((int)entry.find(flProcessName) != -1){
                        if (directoryInfoHoldCount+10 > directoryInfoHoldLimit) [self directoryInfoHoldUpDate];
                        arrayDirectoryInfoHold [directoryInfoHoldCount] = entry, directoryInfoHoldCount++;
                    }
                }
                
                closedir(dir);
                
                //-------Directory Sort------
                NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                
                for (int counter1 = 0; counter1 < directoryInfoHoldCount; counter1++){
                    [unsortedArray addObject:@(arrayDirectoryInfoHold [counter1].c_str())];
                }
                
                [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                
                for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                    arrayDirectoryInfoHold [counter1] = [unsortedArray [counter1] UTF8String];
                }
            }
            
            if (directoryInfoHoldCount != 0){
                string entry;
                string tempName;
                string bodyNameExtract;
                string lastString;
                string extractStringTemp;
                string timeString;
                string removeFilePath;
                
                int lowestBodyNumberTemp = 10000;
                int lowestTimeTemp = 10000;
                int findString1 = 0;
                int terminationFlag = 0;
                
                for (int counter1 = 0; counter1 < directoryInfoHoldCount; counter1++){
                    entry = arrayDirectoryInfoHold [counter1];
                    
                    findString1 = (int)entry.find(flProcessName);
                    
                    if (findString1 > 0){
                        if (entry.substr((unsigned long)findString1-1, 1) != "_")  findString1 = -1;
                    }
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store" && findString1 != -1){
                        tempName = entry.substr((unsigned long)findString1);
                        bodyNameExtract = tempName.substr(0, tempName.find("_"));
                        
                        do{
                            
                            terminationFlag = 1;
                            
                            lastString = bodyNameExtract.substr(bodyNameExtract.length()-1, 1);
                            
                            if (lastString == "0" || lastString == "1" || lastString == "2" || lastString == "3" || lastString == "4" || lastString == "5" || lastString == "6" || lastString == "7" || lastString == "8" || lastString == "9"){
                                bodyNameExtract = bodyNameExtract.substr(0, bodyNameExtract.length()-1);
                            }
                            else terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                        
                        if (bodyNameExtract == flProcessName && (int)entry.find("_s") != -1){
                            tempName = entry.substr(entry.find(flProcessName));
                            extractStringTemp = tempName.substr((unsigned long)bodyNameLength, tempName.find("_")-(unsigned long)bodyNameLength);
                            
                            if (lowestBodyNumberTemp > atoi(extractStringTemp.c_str())) lowestBodyNumberTemp = atoi(extractStringTemp.c_str());
                        }
                    }
                }
                
                if (lowestBodyNumberTemp != 10000){
                    for (int counter1 = 0; counter1 < directoryInfoHoldCount; counter1++){
                        entry = arrayDirectoryInfoHold [counter1];
                        
                        findString1 = (int)entry.find(flProcessName);
                        
                        if (findString1 > 0){
                            if (entry.substr((unsigned long)findString1-1, 1) != "_")  findString1 = -1;
                        }
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store" && findString1 != -1){
                            tempName = entry.substr((unsigned long)findString1);
                            bodyNameExtract = tempName.substr(0, tempName.find("_"));
                            
                            do{
                                
                                terminationFlag = 1;
                                
                                lastString = bodyNameExtract.substr(bodyNameExtract.length()-1, 1);
                                
                                if (lastString == "0" || lastString == "1" || lastString == "2" || lastString == "3" || lastString == "4" || lastString == "5" || lastString == "6" || lastString == "7" || lastString == "8" || lastString == "9"){
                                    bodyNameExtract = bodyNameExtract.substr(0, bodyNameExtract.length()-1);
                                }
                                else terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                            
                            if (bodyNameExtract == flProcessName && (int)entry.find("_s") != -1){
                                tempName = entry.substr(entry.find(flProcessName));
                                extractStringTemp = tempName.substr((unsigned long)bodyNameLength, tempName.find("_")-(unsigned long)bodyNameLength);
                                
                                if (lowestBodyNumberTemp == atoi(extractStringTemp.c_str())){
                                    timeString = entry.substr(entry.find("_t")+2, entry.find(tiffExtension)-entry.find("_t")-2);
                                    
                                    if (lowestTimeTemp > atoi(timeString.c_str())) lowestTimeTemp = atoi(timeString.c_str());
                                }
                            }
                        }
                    }
                    
                    if (lowestBodyNumberTemp != 10000 && lowestTimeTemp != 10000){
                        for (int counter1 = 0; counter1 < directoryInfoHoldCount; counter1++){
                            entry = arrayDirectoryInfoHold [counter1];
                            
                            findString1 = (int)entry.find(flProcessName);
                            
                            if (findString1 > 0){
                                if (entry.substr((unsigned long)findString1-1, 1) != "_")  findString1 = -1;
                            }
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store" && findString1 != -1){
                                tempName = entry.substr((unsigned long)findString1);
                                bodyNameExtract = tempName.substr(0, tempName.find("_"));
                                
                                do{
                                    
                                    terminationFlag = 1;
                                    
                                    lastString = bodyNameExtract.substr(bodyNameExtract.length()-1, 1);
                                    
                                    if (lastString == "0" || lastString == "1" || lastString == "2" || lastString == "3" || lastString == "4" || lastString == "5" || lastString == "6" || lastString == "7" || lastString == "8" || lastString == "9"){
                                        bodyNameExtract = bodyNameExtract.substr(0, bodyNameExtract.length()-1);
                                    }
                                    else terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                                
                                if (bodyNameExtract == flProcessName && (int)entry.find("_s") != -1){
                                    timeString = entry.substr(entry.find("_t")+2, entry.find(tiffExtension)-entry.find("_t")-2);
                                    tempName = entry.substr(entry.find(flProcessName));
                                    extractStringTemp = tempName.substr((unsigned long)bodyNameLength, tempName.find("_")-(unsigned long)bodyNameLength);
                                    
                                    if (atoi(timeString.c_str()) == lowestTimeTemp && atoi(extractStringTemp.c_str()) == lowestBodyNumberTemp){
                                        removeFilePath = directoryPathForPC+"/"+entry;
                                        remove(removeFilePath.c_str());
                                    }
                                }
                            }
                        }
                        
                        tableViewCall = 1;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                }
            }
            else{
                
                NSAlert *alert2 = [[NSAlert alloc] init];
                [alert2 addButtonWithTitle:@"OK"];
                [alert2 setMessageText:@"Check Image Acquisition Computer/No file was found"];
                [alert2 setAlertStyle:NSAlertStyleWarning];
                [alert2 runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
    }
    else{
        
        if (fileUpLoadingFlag == 2){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"IF Mode Off"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (exitFlag == 3){
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Terminating"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else {
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)extensionTIFFSet:(id)sender{
    if (flComputerDataName != "nil" && flUserName != "nil" && flProcessName != "nil" && totalFOVNoHold != "nil" && (fileUpLoadingFlag == 2 || fileUpLoadingFlag == 3) && initialUploadStart == 0){
        tiffExtension = ".TIFF";
        [tiffExtDisplay setStringValue:@(tiffExtension.c_str())];
        
        string tifExtSave = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/FLTifExt";
        
        ofstream oin;
        oin.open(tifExtSave.c_str(), ios::out);
        
        oin<<".TIFF"<<endl;
        oin.close();
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress/Auto Mode"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)extensionTiffSet:(id)sender{
    if (flComputerDataName != "nil" && flUserName != "nil" && flProcessName != "nil" && totalFOVNoHold != "nil" && (fileUpLoadingFlag == 2 || fileUpLoadingFlag == 3) && initialUploadStart == 0){
        tiffExtension = ".Tiff";
        [tiffExtDisplay setStringValue:@(tiffExtension.c_str())];
        
        string tifExtSave = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/FLTifExt";
        
        ofstream oin;
        oin.open(tifExtSave.c_str(), ios::out);
        
        oin<<".Tiff"<<endl;
        oin.close();
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress/Auto Mode"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)extensiontiffSet:(id)sender{
    if (flComputerDataName != "nil" && flUserName != "nil" && flProcessName != "nil" && totalFOVNoHold != "nil" && (fileUpLoadingFlag == 2 || fileUpLoadingFlag == 3) && initialUploadStart == 0){
        tiffExtension = ".tiff";
        [tiffExtDisplay setStringValue:@(tiffExtension.c_str())];
        
        string tifExtSave = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/FLTifExt";
        
        ofstream oin;
        oin.open(tifExtSave.c_str(), ios::out);
        
        oin<<".tiff"<<endl;
        oin.close();
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress/Auto Mode"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)extensionTIFSet:(id)sender{
    if (flComputerDataName != "nil" && flUserName != "nil" && flProcessName != "nil" && totalFOVNoHold != "nil" && (fileUpLoadingFlag == 2 || fileUpLoadingFlag == 3) && initialUploadStart == 0){
        tiffExtension = ".TIF";
        [tiffExtDisplay setStringValue:@(tiffExtension.c_str())];
        
        string tifExtSave = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/FLTifExt";
        
        ofstream oin;
        oin.open(tifExtSave.c_str(), ios::out);
        
        oin<<".TIF"<<endl;
        oin.close();
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress/Auto Mode"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)extensionTifSet:(id)sender{
    if (flComputerDataName != "nil" && flUserName != "nil" && flProcessName != "nil" && totalFOVNoHold != "nil" && (fileUpLoadingFlag == 2 || fileUpLoadingFlag == 3) && initialUploadStart == 0){
        tiffExtension = ".Tif";
        [tiffExtDisplay setStringValue:@(tiffExtension.c_str())];
        
        string tifExtSave = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/FLTifExt";
        
        ofstream oin;
        oin.open(tifExtSave.c_str(), ios::out);
        
        oin<<".Tif"<<endl;
        oin.close();
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress/Auto Mode"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)extensiontifSet:(id)sender{
    if (flComputerDataName != "nil" && flUserName != "nil" && flProcessName != "nil" && totalFOVNoHold != "nil" && (fileUpLoadingFlag == 2 || fileUpLoadingFlag == 3) && initialUploadStart == 0){
        tiffExtension = ".tif";
        [tiffExtDisplay setStringValue:@(tiffExtension.c_str())];
        
        string tifExtSave = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/FLTifExt";
        
        ofstream oin;
        oin.open(tifExtSave.c_str(), ios::out);
        
        oin<<".tif"<<endl;
        oin.close();
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress/Auto Mode"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)dataCheckSet:(id)sender{
    if (dataCheckOperation == 0){
        dataCheckOperation = 1;
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDataCheck object:self];
    }
    if (dataCheckOperation == 2) dataCheckOperation = 3;
}

-(void)fileNameUpDate{
    string *arrayUpDate = new string [fileNameCount+10];
    
    for (int counter1 = 0; counter1 < fileNameCount; counter1++) arrayUpDate [counter1] = arrayFileName [counter1];
    
    delete [] arrayFileName;
    arrayFileName = new string [fileNameLimit+5000];
    fileNameLimit = fileNameLimit+5000;
    
    for (int counter1 = 0; counter1 < fileNameCount; counter1++) arrayFileName [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)timeNumberUpDate{
    int *arrayUpDate = new int [timeNumberCount+10];
    
    for (int counter1 = 0; counter1 < timeNumberCount; counter1++) arrayUpDate [counter1] = arrayTimeNumber [counter1];
    
    delete [] arrayTimeNumber;
    arrayTimeNumber = new int [timeNumberLimit+5000];
    timeNumberLimit = timeNumberLimit+5000;
    
    for (int counter1 = 0; counter1 < timeNumberCount; counter1++) arrayTimeNumber [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)bodyNumberUpDate{
    int *arrayUpDate = new int [bodyNumberCount+10];
    
    for (int counter1 = 0; counter1 < bodyNumberCount; counter1++) arrayUpDate [counter1] = arrayBodyNumber [counter1];
    
    delete [] arrayBodyNumber;
    arrayBodyNumber = new int [bodyNumberLimit+5000];
    bodyNumberLimit = bodyNumberLimit+5000;
    
    for (int counter1 = 0; counter1 < bodyNumberCount; counter1++) arrayBodyNumber [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)directoryInfoHoldUpDate{
    string *arrayUpDate = new string [directoryInfoHoldCount+10];
    
    for (int counter1 = 0; counter1 < directoryInfoHoldCount; counter1++) arrayUpDate [counter1] = arrayDirectoryInfoHold [counter1];
    
    delete [] arrayDirectoryInfoHold;
    arrayDirectoryInfoHold = new string [directoryInfoHoldLimit+50000];
    directoryInfoHoldLimit = directoryInfoHoldLimit+50000;
    
    for (int counter1 = 0; counter1 < directoryInfoHoldCount; counter1++) arrayDirectoryInfoHold [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)fileNameTableUpDate{
    string *arrayUpDate = new string [fileNameTableCount+10];
    
    for (int counter1 = 0; counter1 < fileNameTableCount; counter1++) arrayUpDate [counter1] = arrayFileNameTable [counter1];
    
    delete [] arrayFileNameTable;
    arrayFileNameTable = new string [fileNameTableLimit+500];
    fileNameTableLimit = fileNameTableLimit+500;
    
    for (int counter1 = 0; counter1 < fileNameTableCount; counter1++) arrayFileNameTable [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)selectFileUpDate{
    string *arrayUpDate = new string [selectFileCount+10];
    
    for (int counter1 = 0; counter1 < selectFileCount; counter1++) arrayUpDate [counter1] = arraySelectFiles [counter1];
    
    delete [] arraySelectFiles;
    arraySelectFiles = new string [selectFileLimit+500];
    selectFileLimit = selectFileLimit+500;
    
    for (int counter1 = 0; counter1 < selectFileCount; counter1++) arraySelectFiles [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)dealloc{
    if (timerFL) [timerFL invalidate];
}

@end
