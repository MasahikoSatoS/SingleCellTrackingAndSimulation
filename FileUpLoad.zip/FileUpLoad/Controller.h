//
//  Controller.h
//  FileUpLoad
//
//  Created by Masahiko Sato on 11/07/11, 06/06/13 revised.
//  Copyright 2011 Masahiko Sato All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "TerminationMonitor.h"
#import "DataCheck.h"
#include <iostream>
#include <dirent.h>
#include <fstream>
#include <sstream>
#include <sys/stat.h>

using namespace std;

extern NSString *notificationToTermination;
extern NSString *notificationToDataCheck;

//--------Paths----------
extern string fileDataPath; //File size that is held in the system folder
extern string fileDataSavePath; //File size that is held in the system folder, backup

//--------Arrays----------
extern string *arrayFileName; //Hold file names
extern int fileNameCount;
extern int fileNameLimit;
extern int *arrayTimeNumber; //Hold time points
extern int timeNumberCount;
extern int timeNumberLimit;
extern int *arrayBodyNumber; //Hold file body number
extern int bodyNumberCount;
extern int bodyNumberLimit;
extern string *arrayFileNameTable; //Array for table display
extern int fileNameTableCount;
extern int fileNameTableLimit;
extern string *arraySelectFiles; //Hold the names of selected files
extern int selectFileCount;
extern int selectFileLimit;
extern string *arrayFileIFData; //IF fluorescentname array

//---------Data Check -------
extern int dataCheckOperation; //Data operation window control
extern int tableCallCount; //Table display control
extern int tableCurrentRowHold; //Table operation
extern int rowIndexHold; //Row index no
extern string fluorescentCurrent1;
extern string fluorescentCurrent2;
extern string fluorescentCurrent3;
extern string fluorescentCurrent4;
extern string fluorescentCurrent5;
extern string fluorescentCurrent6;
extern string fluorescentSave1;
extern string fluorescentSave2;
extern string fluorescentSave3;
extern string fluorescentSave4;
extern string fluorescentSave5;
extern string fluorescentSave6;
extern string nameCheckString;

@interface Controller : NSObject <NSTableViewDataSource> {
    int firstCommunication; //Communication establish flag
    int fileImageSize; //Image file size
    int fileUpLoadingFlag; //Up loading flag, 1. Auto upload, 2. initial up load, 3.
    int fluorescentFileNoCount; //No of fluorescent file
    int exitFlag; //Exit Flag
    int basicInfoRead; //Read flag for the basic info
    int fileSizeSetFlag; //File size set
    int singleDualStatus; //Hold single, dual status: 1 single, 2: dual
    int initialUploadStart; //Flag for initial upload start
    int fileListCheckFlag; //File list check flag
    int fileSingleDualFlag; //Flag for single dual status
    int fluorescentNameFlag; //Flag for fluorescent set
    int tableViewCall; //Table View call
    int fileInfoSendCall; //Send fluorescent and single/double status
    int autoLoadingControlFlag; //Control flag for auto Loading
    int interruptionFlag; //Interrupt initial file uploading
    int loadingCount; //Count for Loading Mark
    int autoUploadStart; //Set when Auto upLoad start
    int sendMessageON; //Activate message send
    int copyStartFlag; //File copy start flag
    int copyStartFlag2; //File copy start flag
    int indicatorCount; //Indicator
    int incrementCount; //Indicator
    int lowestBodyNumberAuto; //Lowest Body number
    int lowestTimeAuto; //Lowest time
    int lowestTime; //Lowest time
    int lowestBodyNumber; //Lowest Body number
    int progressValue; //Hold Progress indicator value
    int progressTiming; //Hold Progress indicator timing
    int fileNoMinimalHold; //Hold counted file no
    int latestBodyNoHold; //Last body number
    int latestTimePointHold; //Last time
    int readingTimingFlag; //Timing flag for file size determination
    
    string pathNameString; //Path name
    string flComputerDataName; //Computer Name
    string flUserName; //User Name
    string flProcessName; //Body Name
    string importFolder; //Data Import folder name
    string directoryPathForPC; //PC directory path
    string totalFOVNoHold; //Total no of FOV
    string fluorescent1; //Fluorescent name
    string fluorescent2; //Fluorescent name
    string fluorescent3; //Fluorescent name
    string fluorescent4; //Fluorescent name
    string fluorescent5; //Fluorescent name
    string fluorescent6; //Fluorescent name
    string loadingCompletePath; //Loading complete path
    string dataDirectoryPath; //Data directory path
    string tiffExtension;//Tif extension hold
    string fileIFDataPath; //IF fluorescent name hold
    
    string *arrayDirectoryInfoHold; //Hold PC directory info
    int directoryInfoHoldCount;
    int directoryInfoHoldLimit;
    
    IBOutlet NSTableView *tableViewList;
    
    IBOutlet NSTextField *loadingStatus;
    IBOutlet NSTextField *analysisName;
    IBOutlet NSTextField *computerName;
    IBOutlet NSTextField *totalFOV;
    IBOutlet NSTextField *userID;
    IBOutlet NSTextField *detectedFOV;
    IBOutlet NSTextField *singleDualDisplay;
    IBOutlet NSTextField *fluorescentDisplay1;
    IBOutlet NSTextField *fluorescentDisplay2;
    IBOutlet NSTextField *fluorescentDisplay3;
    IBOutlet NSTextField *fluorescentDisplay4;
    IBOutlet NSTextField *fluorescentDisplay5;
    IBOutlet NSTextField *fluorescentDisplay6;
    IBOutlet NSTextField *autoInitStatus;
    IBOutlet NSTextField *loadingMark;
    IBOutlet NSTextField *tiffExtDisplay;
    IBOutlet NSTextField *searchTime;
    IBOutlet NSTextField *searchBodyNo;
    
    IBOutlet NSWindow *controllerWindow;
    IBOutlet NSProgressIndicator *progressIndicator;
    
    NSTimer *timerFL;
    NSString *processInfo;
}

-(id)init;
-(void)dealloc;
-(void)processStopSub;
-(void)Communication;
-(void)display;
-(void)fileSizeDetermination;
-(void)fileListCheck;
-(void)singleDualFind;
-(void)fluorescentNameFind;
-(void)initialFileUpLoad;
-(void)fileNameUpDate;
-(void)timeNumberUpDate;
-(void)bodyNumberUpDate;
-(void)fileNameTableUpDate;
-(void)selectFileUpDate;
-(void)interruption;
-(void)directoryInfoHoldUpDate;
-(void)fileListCheckIF;
-(void)singleDualFindIF;
-(void)fileSizeDeterminationIF;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;

-(IBAction)fileUpLoadStart:(id)sender;
-(IBAction)clearAll:(id)sender;
-(IBAction)clearOld:(id)sender;
-(IBAction)clearOldest:(id)sender;
-(IBAction)quitProcess:(id)sender;
-(IBAction)interruptionSet:(id)sender;
-(IBAction)extensionTIFFSet:(id)sender;
-(IBAction)extensionTiffSet:(id)sender;
-(IBAction)extensiontiffSet:(id)sender;
-(IBAction)extensionTIFSet:(id)sender;
-(IBAction)extensionTifSet:(id)sender;
-(IBAction)extensiontifSet:(id)sender;
-(IBAction)dataCheckSet:(id)sender;

@end
