//
//  MovieDisplay.m
//  CellMovie2
//
//  Created by Masahiko Sato on 2014-09-29.
//
//

#import "MovieDisplay.h"

NSString *notificationToMovieDisplay = @"notificationExecuteMovieDisplay";

@implementation MovieDisplay

-(id)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    
    if (self) {
        firstDisplayFlag = 0;
        magnificationDisplay = 10;
        mouseDragFlag = 0;
        
        movieImage = [[NSImage alloc] initWithContentsOfFile:@""];
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToMovieDisplay object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    if (imageXYLength != 0){
        NSBitmapImageRep *bitmapRepsCR = nil;
        bitmapRepsCR = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageXYLength pixelsHigh:imageXYLength bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageXYLength*4 bitsPerPixel:32];
        
        unsigned char *bitmapData = [bitmapRepsCR bitmapData];
        
        if (grayColorStatus == 0){
            int value0 = 0;
            int value1 = 0;
            int value2 = 0;
            int value3 = 0;
            int value4 = 0;
            int value5 = 0;
            int value6 = 0;
            
            int dataConversion [4];
            int endianType = 0;
            
            double colorHit1 = 0;
            double colorHit2 = 0;
            double colorHit3 = 0;
            double colorHit4 = 0;
            double colorHit5 = 0;
            double colorHit6 = 0;
            
            int hitR = 0;
            int hitG = 0;
            int hitB = 0;
            
            if (statusHold1 != 0 || statusHold2 != 0 || statusHold3 != 0 || statusHold4 != 0 || statusHold5 != 0 || statusHold6 != 0){
                if (imageBmpTifFlag == 0){
                    double *hitMap = new double [20];
                    
                    if (colorNo1 == "1"){
                        hitMap [0] = 0;
                        hitMap [1] = 0;
                        hitMap [2] = 1;
                    }
                    else if (colorNo1 == "2"){
                        hitMap [0] = 0;
                        hitMap [1] = 1;
                        hitMap [2] = 0;
                    }
                    else if (colorNo1 == "3"){
                        hitMap [0] = 1;
                        hitMap [1] = 1;
                        hitMap [2] = 0;
                    }
                    else if (colorNo1 == "4"){
                        hitMap [0] = 1;
                        hitMap [1] = 0;
                        hitMap [2] = 0;
                    }
                    else if (colorNo1 == "5"){
                        hitMap [0] = 1;
                        hitMap [1] = 0;
                        hitMap [2] = 1;
                    }
                    else if (colorNo1 == "6"){
                        hitMap [0] = 0;
                        hitMap [1] = 1;
                        hitMap [2] = 1;
                    }
                    else if (colorNo1 == "7"){
                        hitMap [0] = 1;
                        hitMap [1] = 0.674;
                        hitMap [2] = 0;
                    }
                    else if (colorNo1 == "8"){
                        hitMap [0] = 0.627;
                        hitMap [1] = 0.125;
                        hitMap [2] = 0.941;
                    }
                    else if (colorNo1 == "9"){
                        hitMap [0] = 0.529;
                        hitMap [1] = 0.808;
                        hitMap [2] = 0.922;
                    }
                    
                    if (colorNo2 == "1"){
                        hitMap [3] = 0;
                        hitMap [4] = 0;
                        hitMap [5] = 1;
                    }
                    else if (colorNo2 == "2"){
                        hitMap [3] = 0;
                        hitMap [4] = 1;
                        hitMap [5] = 0;
                    }
                    else if (colorNo2 == "3"){
                        hitMap [3] = 1;
                        hitMap [4] = 1;
                        hitMap [5] = 0;
                    }
                    else if (colorNo2 == "4"){
                        hitMap [3] = 1;
                        hitMap [4] = 0;
                        hitMap [5] = 0;
                    }
                    else if (colorNo2 == "5"){
                        hitMap [3] = 1;
                        hitMap [4] = 0;
                        hitMap [5] = 1;
                    }
                    else if (colorNo2 == "6"){
                        hitMap [3] = 0;
                        hitMap [4] = 1;
                        hitMap [5] = 1;
                    }
                    else if (colorNo2 == "7"){
                        hitMap [3] = 1;
                        hitMap [4] = 0.674;
                        hitMap [5] = 0;
                    }
                    else if (colorNo2 == "8"){
                        hitMap [3] = 0.627;
                        hitMap [4] = 0.125;
                        hitMap [5] = 0.941;
                    }
                    else if (colorNo2 == "9"){
                        hitMap [3] = 0.529;
                        hitMap [4] = 0.808;
                        hitMap [5] = 0.922;
                    }
                    
                    if (colorNo3 == "1"){
                        hitMap [6] = 0;
                        hitMap [7] = 0;
                        hitMap [8] = 1;
                    }
                    else if (colorNo3 == "2"){
                        hitMap [6] = 0;
                        hitMap [7] = 1;
                        hitMap [8] = 0;
                    }
                    else if (colorNo3 == "3"){
                        hitMap [6] = 1;
                        hitMap [7] = 1;
                        hitMap [8] = 0;
                    }
                    else if (colorNo3 == "4"){
                        hitMap [6] = 1;
                        hitMap [7] = 0;
                        hitMap [8] = 0;
                    }
                    else if (colorNo3 == "5"){
                        hitMap [6] = 1;
                        hitMap [7] = 0;
                        hitMap [8] = 1;
                    }
                    else if (colorNo3 == "6"){
                        hitMap [6] = 0;
                        hitMap [7] = 1;
                        hitMap [8] = 1;
                    }
                    else if (colorNo3 == "7"){
                        hitMap [6] = 1;
                        hitMap [7] = 0.674;
                        hitMap [8] = 0;
                    }
                    else if (colorNo3 == "8"){
                        hitMap [6] = 0.627;
                        hitMap [7] = 0.125;
                        hitMap [8] = 0.941;
                    }
                    else if (colorNo3 == "9"){
                        hitMap [6] = 0.529;
                        hitMap [7] = 0.808;
                        hitMap [8] = 0.922;
                    }
                    
                    if (colorNo4 == "1"){
                        hitMap [9] = 0;
                        hitMap [10] = 0;
                        hitMap [11] = 1;
                    }
                    else if (colorNo4 == "2"){
                        hitMap [9] = 0;
                        hitMap [10] = 1;
                        hitMap [11] = 0;
                    }
                    else if (colorNo4 == "3"){
                        hitMap [9] = 1;
                        hitMap [10] = 1;
                        hitMap [11] = 0;
                    }
                    else if (colorNo4 == "4"){
                        hitMap [9] = 1;
                        hitMap [10] = 0;
                        hitMap [11] = 0;
                    }
                    else if (colorNo4 == "5"){
                        hitMap [9] = 1;
                        hitMap [10] = 0;
                        hitMap [11] = 1;
                    }
                    else if (colorNo4 == "6"){
                        hitMap [9] = 0;
                        hitMap [10] = 1;
                        hitMap [11] = 1;
                    }
                    else if (colorNo4 == "7"){
                        hitMap [9] = 1;
                        hitMap [10] = 0.674;
                        hitMap [11] = 0;
                    }
                    else if (colorNo4 == "8"){
                        hitMap [9] = 0.627;
                        hitMap [10] = 0.125;
                        hitMap [11] = 0.941;
                    }
                    else if (colorNo4 == "9"){
                        hitMap [9] = 0.529;
                        hitMap [10] = 0.808;
                        hitMap [11] = 0.922;
                    }
                    
                    if (colorNo5 == "1"){
                        hitMap [12] = 0;
                        hitMap [13] = 0;
                        hitMap [14] = 1;
                    }
                    else if (colorNo5 == "2"){
                        hitMap [12] = 0;
                        hitMap [13] = 1;
                        hitMap [14] = 0;
                    }
                    else if (colorNo5 == "3"){
                        hitMap [12] = 1;
                        hitMap [13] = 1;
                        hitMap [14] = 0;
                    }
                    else if (colorNo5 == "4"){
                        hitMap [12] = 1;
                        hitMap [13] = 0;
                        hitMap [14] = 0;
                    }
                    else if (colorNo5 == "5"){
                        hitMap [12] = 1;
                        hitMap [13] = 0;
                        hitMap [14] = 1;
                    }
                    else if (colorNo5 == "6"){
                        hitMap [12] = 0;
                        hitMap [13] = 1;
                        hitMap [14] = 1;
                    }
                    else if (colorNo5 == "7"){
                        hitMap [12] = 1;
                        hitMap [13] = 0.674;
                        hitMap [14] = 0;
                    }
                    else if (colorNo5 == "8"){
                        hitMap [12] = 0.627;
                        hitMap [13] = 0.125;
                        hitMap [14] = 0.941;
                    }
                    else if (colorNo5 == "9"){
                        hitMap [12] = 0.529;
                        hitMap [13] = 0.808;
                        hitMap [14] = 0.922;
                    }
                    
                    if (colorNo6 == "1"){
                        hitMap [15] = 0;
                        hitMap [16] = 0;
                        hitMap [17] = 1;
                    }
                    else if (colorNo6 == "2"){
                        hitMap [15] = 0;
                        hitMap [16] = 1;
                        hitMap [17] = 0;
                    }
                    else if (colorNo6 == "3"){
                        hitMap [15] = 1;
                        hitMap [16] = 1;
                        hitMap [17] = 0;
                    }
                    else if (colorNo6 == "4"){
                        hitMap [15] = 1;
                        hitMap [16] = 0;
                        hitMap [17] = 0;
                    }
                    else if (colorNo6 == "5"){
                        hitMap [15] = 1;
                        hitMap [16] = 0;
                        hitMap [17] = 1;
                    }
                    else if (colorNo6 == "6"){
                        hitMap [15] = 0;
                        hitMap [16] = 1;
                        hitMap [17] = 1;
                    }
                    else if (colorNo6 == "7"){
                        hitMap [15] = 1;
                        hitMap [16] = 0.674;
                        hitMap [17] = 0;
                    }
                    else if (colorNo6 == "8"){
                        hitMap [15] = 0.627;
                        hitMap [16] = 0.125;
                        hitMap [17] = 0.941;
                    }
                    else if (colorNo6 == "9"){
                        hitMap [15] = 0.529;
                        hitMap [16] = 0.808;
                        hitMap [17] = 0.922;
                    }
                    
                    unsigned long headPosition = 0;
                    
                    dataConversion [0] = uploadTemp [0];
                    dataConversion [1] = uploadTemp [1];
                    
                    if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                    else endianType = 0;
                    
                    headPosition = 0;
                    
                    if (endianType == 1){
                        dataConversion [0] = uploadTemp [7];
                        dataConversion [1] = uploadTemp [6];
                        dataConversion [2] = uploadTemp [5];
                        dataConversion [3] = uploadTemp [4];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    else if (endianType == 0){
                        dataConversion [0] = uploadTemp [4];
                        dataConversion [1] = uploadTemp [5];
                        dataConversion [2] = uploadTemp [6];
                        dataConversion [3] = uploadTemp [7];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    
                    for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                        value1 = 0;
                        value2 = 0;
                        value3 = 0;
                        value4 = 0;
                        value5 = 0;
                        value6 = 0;
                        
                        value0 = uploadTemp [counter1];
                        
                        if (value0 >= 0 && value0 < cutHoldDIC){
                            value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                            
                            if (value0 < 0) value0 = 0;
                        }
                        else{
                            
                            value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                            
                            if (value0 > 255) value0 = 255;
                        }
                        
                        if (statusHold1 == 1 && colorFlag1 == 1){
                            value1 = uploadTempCl1 [counter1];
                            
                            if (value1 < cutHold1) value1 = 0;
                            else{
                                
                                value1 = value1+(int)((value1-cutHold1)*levelHold1);
                                
                                if (value1 > 255) value1 = 255;
                            }
                        }
                        
                        if (statusHold2 == 1 && colorFlag2 == 1){
                            value2 = uploadTempCl2 [counter1];
                            
                            if (value2 < cutHold2) value2 = 0;
                            else{
                                
                                value2 = value2+(int)((value2-cutHold2)*levelHold2);
                                
                                if (value2 > 255) value2 = 255;
                            }
                        }
                        
                        if (statusHold3 == 1 && colorFlag3 == 1){
                            value3 = uploadTempCl3 [counter1];
                            
                            if (value3 < cutHold3) value3 = 0;
                            else{
                                
                                value3 = value3+(int)((value3-cutHold3)*levelHold3);
                                
                                if (value3 > 255) value3 = 255;
                            }
                        }
                        
                        if (statusHold4 == 1 && colorFlag4 == 1){
                            value4 = uploadTempCl4 [counter1];
                            
                            if (value4 < cutHold4) value4 = 0;
                            else{
                                
                                value4 = value4+(int)((value4-cutHold4)*levelHold4);
                                
                                if (value4 > 255) value4 = 255;
                            }
                        }
                        
                        if (statusHold5 == 1 && colorFlag5 == 1){
                            value5 = uploadTempCl5 [counter1];
                            
                            if (value5 < cutHold5) value5 = 0;
                            else{
                                
                                value5 = value5+(int)((value5-cutHold5)*levelHold5);
                                
                                if (value5 > 255) value5 = 255;
                            }
                        }
                        
                        if (statusHold6 == 1 && colorFlag6 == 1){
                            value6 = uploadTempCl6 [counter1];
                            
                            if (value6 < cutHold6) value6 = 0;
                            else{
                                
                                value6 = value6+(int)((value6-cutHold6)*levelHold6);
                                
                                if (value6 > 255) value6 = 255;
                            }
                        }
                        
                        if (statusHold1 == 0) value1 = 0;
                        if (statusHold2 == 0) value2 = 0;
                        if (statusHold3 == 0) value3 = 0;
                        if (statusHold4 == 0) value4 = 0;
                        if (statusHold5 == 0) value5 = 0;
                        if (statusHold6 == 0) value6 = 0;
                        
                        if (value1 <= 0 && value2 <= 0 && value3 <= 0 && value4 <= 0 && value5 <= 0 && value6 <= 0){
                            *bitmapData++ = (unsigned char)value0;
                            *bitmapData++ = (unsigned char)value0;
                            *bitmapData++ = (unsigned char)value0;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            if (value1 < 0) value1 = 0;
                            if (value2 < 0) value2 = 0;
                            if (value3 < 0) value3 = 0;
                            if (value4 < 0) value4 = 0;
                            if (value5 < 0) value5 = 0;
                            if (value6 < 0) value6 = 0;
                            
                            hitR = 0;
                            hitG = 0;
                            hitB = 0;
                            
                            if (value1 > 0){
                                if (hitMap [0] != 0) hitR++;
                                if (hitMap [1] != 0) hitG++;
                                if (hitMap [2] != 0) hitB++;
                            }
                            
                            if (value2 > 0){
                                if (hitMap [3] != 0) hitR++;
                                if (hitMap [4] != 0) hitG++;
                                if (hitMap [5] != 0) hitB++;
                            }
                            
                            if (value3 > 0){
                                if (hitMap [6] != 0) hitR++;
                                if (hitMap [7] != 0) hitG++;
                                if (hitMap [8] != 0) hitB++;
                            }
                            
                            if (value4 > 0){
                                if (hitMap [9] != 0) hitR++;
                                if (hitMap [10] != 0) hitG++;
                                if (hitMap [11] != 0) hitB++;
                            }
                            
                            if (value5 > 0){
                                if (hitMap [12] != 0) hitR++;
                                if (hitMap [13] != 0) hitG++;
                                if (hitMap [14] != 0) hitB++;
                            }
                            
                            if (value6 > 0){
                                if (hitMap [15] != 0) hitR++;
                                if (hitMap [16] != 0) hitG++;
                                if (hitMap [17] != 0) hitB++;
                            }
                            
                            colorHit1 = 0;
                            colorHit2 = 0;
                            colorHit3 = 0;
                            colorHit4 = 0;
                            colorHit5 = 0;
                            colorHit6 = 0;
                            
                            if (hitR == 1){
                                if (hitMap [0] != 0 && value1 > 0) colorHit1 = 1;
                                if (hitMap [3] != 0 && value2 > 0) colorHit2 = 1;
                                if (hitMap [6] != 0 && value3 > 0) colorHit3 = 1;
                                if (hitMap [9] != 0 && value4 > 0) colorHit4 = 1;
                                if (hitMap [12] != 0 && value5 > 0) colorHit5 = 1;
                                if (hitMap [15] != 0 && value6 > 0) colorHit6 = 1;
                            }
                            else if (hitR == 2){
                                if (hitMap [0] != 0 && value1 > 0) colorHit1 = 0.5;
                                if (hitMap [3] != 0 && value2 > 0) colorHit2 = 0.5;
                                if (hitMap [6] != 0 && value3 > 0) colorHit3 = 0.5;
                                if (hitMap [9] != 0 && value4 > 0) colorHit4 = 0.5;
                                if (hitMap [12] != 0 && value5 > 0) colorHit5 = 0.5;
                                if (hitMap [15] != 0 && value6 > 0) colorHit6 = 0.5;
                            }
                            else if (hitR == 3){
                                if (hitMap [0] != 0 && value1 > 0) colorHit1 = 0.33;
                                if (hitMap [3] != 0 && value2 > 0) colorHit2 = 0.33;
                                if (hitMap [6] != 0 && value3 > 0) colorHit3 = 0.33;
                                if (hitMap [9] != 0 && value4 > 0) colorHit4 = 0.33;
                                if (hitMap [12] != 0 && value5 > 0) colorHit5 = 0.33;
                                if (hitMap [15] != 0 && value6 > 0) colorHit6 = 0.33;
                            }
                            else if (hitR == 4){
                                if (hitMap [0] != 0 && value1 > 0) colorHit1 = 0.25;
                                if (hitMap [3] != 0 && value2 > 0) colorHit2 = 0.25;
                                if (hitMap [6] != 0 && value3 > 0) colorHit3 = 0.25;
                                if (hitMap [9] != 0 && value4 > 0) colorHit4 = 0.25;
                                if (hitMap [12] != 0 && value5 > 0) colorHit5 = 0.25;
                                if (hitMap [15] != 0 && value6 > 0) colorHit6 = 0.25;
                            }
                            else if (hitR == 5){
                                if (hitMap [0] != 0 && value1 > 0) colorHit1 = 0.2;
                                if (hitMap [3] != 0 && value2 > 0) colorHit2 = 0.2;
                                if (hitMap [6] != 0 && value3 > 0) colorHit3 = 0.2;
                                if (hitMap [9] != 0 && value4 > 0) colorHit4 = 0.2;
                                if (hitMap [12] != 0 && value5 > 0) colorHit5 = 0.2;
                                if (hitMap [15] != 0 && value6 > 0) colorHit6 = 0.2;
                            }
                            else if (hitR == 6){
                                if (hitMap [0] != 0 && value1 > 0) colorHit1 = 0.13;
                                if (hitMap [3] != 0 && value2 > 0) colorHit2 = 0.13;
                                if (hitMap [6] != 0 && value3 > 0) colorHit3 = 0.13;
                                if (hitMap [9] != 0 && value4 > 0) colorHit4 = 0.13;
                                if (hitMap [12] != 0 && value5 > 0) colorHit5 = 0.13;
                                if (hitMap [15] != 0 && value6 > 0) colorHit6 = 0.13;
                            }
                            
                            if (value1 > 0 && colorNo1 == "7") colorHit1 = colorHit1*0.647;
                            else if (value1 > 0 && colorNo1 == "8") colorHit1 = colorHit1*0.627;
                            else if (value1 > 0 && colorNo1 == "9") colorHit1 = colorHit1*0.529;
                            
                            if (value2 > 0 && colorNo2 == "7") colorHit2 = colorHit2*0.647;
                            else if (value2 > 0 && colorNo2 == "8") colorHit2 = colorHit2*0.627;
                            else if (value2 > 0 && colorNo2 == "9") colorHit2 = colorHit2*0.529;
                            
                            if (value3 > 0 && colorNo3 == "7") colorHit3 = colorHit3*0.647;
                            else if (value3 > 0 && colorNo3 == "8") colorHit3 = colorHit3*0.627;
                            else if (value3 > 0 && colorNo3 == "9") colorHit3 = colorHit3*0.529;
                            
                            if (value4 > 0 && colorNo4 == "7") colorHit4 = colorHit4*0.647;
                            else if (value4 > 0 && colorNo4 == "8") colorHit4 = colorHit4*0.627;
                            else if (value4 > 0 && colorNo4 == "9") colorHit4 = colorHit4*0.529;
                            
                            if (value5 > 0 && colorNo5 == "7") colorHit5 = colorHit5*0.647;
                            else if (value5 > 0 && colorNo5 == "8") colorHit5 = colorHit5*0.627;
                            else if (value5 > 0 && colorNo5 == "9") colorHit5 = colorHit5*0.529;
                            
                            if (value6 > 0 && colorNo6 == "7") colorHit6 = colorHit6*0.647;
                            else if (value6 > 0 && colorNo6 == "8") colorHit6 = colorHit6*0.627;
                            else if (value6 > 0 && colorNo6 == "9") colorHit6 = colorHit6*0.529;
                            
                            *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3+value4*(double)colorHit4+value5*(double)colorHit5+value6*(double)colorHit6));
                            
                            colorHit1 = 0;
                            colorHit2 = 0;
                            colorHit3 = 0;
                            colorHit4 = 0;
                            colorHit5 = 0;
                            colorHit6 = 0;
                            
                            if (hitG == 1){
                                if (hitMap [1] != 0 && value1 > 0) colorHit1 = 1;
                                if (hitMap [4] != 0 && value2 > 0) colorHit2 = 1;
                                if (hitMap [7] != 0 && value3 > 0) colorHit3 = 1;
                                if (hitMap [10] != 0 && value4 > 0) colorHit4 = 1;
                                if (hitMap [13] != 0 && value5 > 0) colorHit5 = 1;
                                if (hitMap [16] != 0 && value6 > 0) colorHit6 = 1;
                            }
                            else if (hitG == 2){
                                if (hitMap [1] != 0 && value1 > 0) colorHit1 = 0.5;
                                if (hitMap [4] != 0 && value2 > 0) colorHit2 = 0.5;
                                if (hitMap [7] != 0 && value3 > 0) colorHit3 = 0.5;
                                if (hitMap [10] != 0 && value4 > 0) colorHit4 = 0.5;
                                if (hitMap [13] != 0 && value5 > 0) colorHit5 = 0.5;
                                if (hitMap [16] != 0 && value6 > 0) colorHit6 = 0.5;
                            }
                            else if (hitG == 3){
                                if (hitMap [1] != 0 && value1 > 0) colorHit1 = 0.33;
                                if (hitMap [4] != 0 && value2 > 0) colorHit2 = 0.33;
                                if (hitMap [7] != 0 && value3 > 0) colorHit3 = 0.33;
                                if (hitMap [10] != 0 && value4 > 0) colorHit4 = 0.33;
                                if (hitMap [13] != 0 && value5 > 0) colorHit5 = 0.33;
                                if (hitMap [16] != 0 && value6 > 0) colorHit6 = 0.33;
                            }
                            else if (hitG == 4){
                                if (hitMap [1] != 0 && value1 > 0) colorHit1 = 0.25;
                                if (hitMap [4] != 0 && value2 > 0) colorHit2 = 0.25;
                                if (hitMap [7] != 0 && value3 > 0) colorHit3 = 0.25;
                                if (hitMap [10] != 0 && value4 > 0) colorHit4 = 0.25;
                                if (hitMap [13] != 0 && value5 > 0) colorHit5 = 0.25;
                                if (hitMap [16] != 0 && value6 > 0) colorHit6 = 0.25;
                            }
                            else if (hitG == 5){
                                if (hitMap [1] != 0 && value1 > 0) colorHit1 = 0.2;
                                if (hitMap [4] != 0 && value2 > 0) colorHit2 = 0.2;
                                if (hitMap [7] != 0 && value3 > 0) colorHit3 = 0.2;
                                if (hitMap [10] != 0 && value4 > 0) colorHit4 = 0.2;
                                if (hitMap [13] != 0 && value5 > 0) colorHit5 = 0.2;
                                if (hitMap [16] != 0 && value6 > 0) colorHit6 = 0.2;
                            }
                            else if (hitG == 6){
                                if (hitMap [1] != 0 && value1 > 0) colorHit1 = 0.13;
                                if (hitMap [4] != 0 && value2 > 0) colorHit2 = 0.13;
                                if (hitMap [7] != 0 && value3 > 0) colorHit3 = 0.13;
                                if (hitMap [10] != 0 && value4 > 0) colorHit4 = 0.13;
                                if (hitMap [13] != 0 && value5 > 0) colorHit5 = 0.13;
                                if (hitMap [16] != 0 && value6 > 0) colorHit6 = 0.13;
                            }
                            
                            if (value1 > 0 && colorNo1 == "8") colorHit1 = colorHit1*0.125;
                            else if (value1 > 0 && colorNo1 == "9") colorHit1 = colorHit1*0.808;
                            
                            if (value2 > 0 && colorNo2 == "8") colorHit2 = colorHit2*0.125;
                            else if (value2 > 0 && colorNo2 == "9") colorHit2 = colorHit2*0.808;
                            
                            if (value3 > 0 && colorNo3 == "8") colorHit3 = colorHit3*0.125;
                            else if (value3 > 0 && colorNo3 == "9") colorHit3 = colorHit3*0.808;
                            
                            if (value4 > 0 && colorNo4 == "8") colorHit4 = colorHit4*0.125;
                            else if (value4 > 0 && colorNo4 == "9") colorHit4 = colorHit4*0.808;
                            
                            if (value5 > 0 && colorNo5 == "8") colorHit5 = colorHit5*0.125;
                            else if (value5 > 0 && colorNo5 == "9") colorHit5 = colorHit5*0.808;
                            
                            if (value6 > 0 && colorNo6 == "8") colorHit6 = colorHit6*0.125;
                            else if (value6 > 0 && colorNo6 == "9") colorHit6 = colorHit6*0.808;
                            
                            *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3+value4*(double)colorHit4+value5*(double)colorHit5+value6*(double)colorHit6));
                            
                            colorHit1 = 0;
                            colorHit2 = 0;
                            colorHit3 = 0;
                            colorHit4 = 0;
                            colorHit5 = 0;
                            colorHit6 = 0;
                            
                            if (hitB == 1){
                                if (hitMap [2] != 0 && value1 > 0) colorHit1 = 1;
                                if (hitMap [5] != 0 && value2 > 0) colorHit2 = 1;
                                if (hitMap [8] != 0 && value3 > 0) colorHit3 = 1;
                                if (hitMap [11] != 0 && value4 > 0) colorHit4 = 1;
                                if (hitMap [14] != 0 && value5 > 0) colorHit5 = 1;
                                if (hitMap [17] != 0 && value6 > 0) colorHit6 = 1;
                            }
                            else if (hitB == 2){
                                if (hitMap [2] != 0 && value1 > 0) colorHit1 = 0.5;
                                if (hitMap [5] != 0 && value2 > 0) colorHit2 = 0.5;
                                if (hitMap [8] != 0 && value3 > 0) colorHit3 = 0.5;
                                if (hitMap [11] != 0 && value4 > 0) colorHit4 = 0.5;
                                if (hitMap [14] != 0 && value5 > 0) colorHit5 = 0.5;
                                if (hitMap [17] != 0 && value6 > 0) colorHit6 = 0.5;
                            }
                            else if (hitB == 3){
                                if (hitMap [2] != 0 && value1 > 0) colorHit1 = 0.33;
                                if (hitMap [5] != 0 && value2 > 0) colorHit2 = 0.33;
                                if (hitMap [8] != 0 && value3 > 0) colorHit3 = 0.33;
                                if (hitMap [11] != 0 && value4 > 0) colorHit4 = 0.33;
                                if (hitMap [14] != 0 && value5 > 0) colorHit5 = 0.33;
                                if (hitMap [17] != 0 && value6 > 0) colorHit6 = 0.33;
                            }
                            else if (hitB == 4){
                                if (hitMap [2] != 0 && value1 > 0) colorHit1 = 0.25;
                                if (hitMap [5] != 0 && value2 > 0) colorHit2 = 0.25;
                                if (hitMap [8] != 0 && value3 > 0) colorHit3 = 0.25;
                                if (hitMap [11] != 0 && value4 > 0) colorHit4 = 0.25;
                                if (hitMap [14] != 0 && value5 > 0) colorHit5 = 0.25;
                                if (hitMap [17] != 0 && value6 > 0) colorHit6 = 0.25;
                            }
                            else if (hitB == 5){
                                if (hitMap [2] != 0 && value1 > 0) colorHit1 = 0.2;
                                if (hitMap [5] != 0 && value2 > 0) colorHit2 = 0.2;
                                if (hitMap [8] != 0 && value3 > 0) colorHit3 = 0.2;
                                if (hitMap [11] != 0 && value4 > 0) colorHit4 = 0.2;
                                if (hitMap [14] != 0 && value5 > 0) colorHit5 = 0.2;
                                if (hitMap [17] != 0 && value6 > 0) colorHit6 = 0.2;
                            }
                            else if (hitB == 6){
                                if (hitMap [2] != 0 && value1 > 0) colorHit1 = 0.13;
                                if (hitMap [5] != 0 && value2 > 0) colorHit2 = 0.13;
                                if (hitMap [8] != 0 && value3 > 0) colorHit3 = 0.13;
                                if (hitMap [11] != 0 && value4 > 0) colorHit4 = 0.13;
                                if (hitMap [14] != 0 && value5 > 0) colorHit5 = 0.13;
                                if (hitMap [17] != 0 && value6 > 0) colorHit6 = 0.13;
                            }
                            
                            if (value1 > 0 && colorNo1 == "8") colorHit1 = colorHit1*0.941;
                            else if (value1 > 0 && colorNo1 == "9") colorHit1 = colorHit1*0.922;
                            
                            if (value2 > 0 && colorNo2 == "8") colorHit2 = colorHit2*0.941;
                            else if (value2 > 0 && colorNo2 == "9") colorHit2 = colorHit2*0.922;
                            
                            if (value3 > 0 && colorNo3 == "8") colorHit3 = colorHit3*0.941;
                            else if (value3 > 0 && colorNo3 == "9") colorHit3 = colorHit3*0.922;
                            
                            if (value4 > 0 && colorNo4 == "8") colorHit4 = colorHit4*0.941;
                            else if (value4 > 0 && colorNo4 == "9") colorHit4 = colorHit4*0.922;
                            
                            if (value5 > 0 && colorNo5 == "8") colorHit5 = colorHit5*0.941;
                            else if (value5 > 0 && colorNo5 == "9") colorHit5 = colorHit5*0.922;
                            
                            if (value6 > 0 && colorNo6 == "8") colorHit6 = colorHit6*0.941;
                            else if (value6 > 0 && colorNo6 == "9") colorHit6 = colorHit6*0.922;
                            
                            *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3+value4*(double)colorHit4+value5*(double)colorHit5+value6*(double)colorHit6));
                            *bitmapData++ = 0;
                        }
                    }
                    
                    delete [] hitMap;
                }
                else if (imageBmpTifFlag == 1){
                    double *hitMap = new double [20];
                    
                    if (colorNo1 == "1"){
                        hitMap [0] = 0;
                        hitMap [1] = 0;
                        hitMap [2] = 1;
                    }
                    else if (colorNo1 == "2"){
                        hitMap [0] = 0;
                        hitMap [1] = 1;
                        hitMap [2] = 0;
                    }
                    else if (colorNo1 == "3"){
                        hitMap [0] = 1;
                        hitMap [1] = 1;
                        hitMap [2] = 0;
                    }
                    else if (colorNo1 == "4"){
                        hitMap [0] = 1;
                        hitMap [1] = 0;
                        hitMap [2] = 0;
                    }
                    else if (colorNo1 == "5"){
                        hitMap [0] = 1;
                        hitMap [1] = 0;
                        hitMap [2] = 1;
                    }
                    
                    if (colorNo2 == "1"){
                        hitMap [3] = 0;
                        hitMap [4] = 0;
                        hitMap [5] = 1;
                    }
                    else if (colorNo2 == "2"){
                        hitMap [3] = 0;
                        hitMap [4] = 1;
                        hitMap [5] = 0;
                    }
                    else if (colorNo2 == "3"){
                        hitMap [3] = 1;
                        hitMap [4] = 1;
                        hitMap [5] = 0;
                    }
                    else if (colorNo2 == "4"){
                        hitMap [3] = 1;
                        hitMap [4] = 0;
                        hitMap [5] = 0;
                    }
                    else if (colorNo2 == "5"){
                        hitMap [3] = 1;
                        hitMap [4] = 0;
                        hitMap [5] = 1;
                    }
                    
                    if (colorNo3 == "1"){
                        hitMap [6] = 0;
                        hitMap [7] = 0;
                        hitMap [8] = 1;
                    }
                    else if (colorNo3 == "2"){
                        hitMap [6] = 0;
                        hitMap [7] = 1;
                        hitMap [8] = 0;
                    }
                    else if (colorNo3 == "3"){
                        hitMap [6] = 1;
                        hitMap [7] = 1;
                        hitMap [8] = 0;
                    }
                    else if (colorNo3 == "4"){
                        hitMap [6] = 1;
                        hitMap [7] = 0;
                        hitMap [8] = 0;
                    }
                    else if (colorNo3 == "5"){
                        hitMap [6] = 1;
                        hitMap [7] = 0;
                        hitMap [8] = 1;
                    }
                    
                    for (int counter1 = imageXYLength-1; counter1 >= 0; counter1--){
                        for (int counter2 = 0; counter2 < imageXYLength; counter2++){
                            value0 = uploadTemp [1078+counter1*imageXYLength+counter2];
                            
                            if (value0 >= 0 && value0 < cutHoldDIC){
                                value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                                
                                if (value0 < 0) value0 = 0;
                            }
                            else{
                                
                                value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                                
                                if (value0 > 255) value0 = 255;
                            }
                            
                            if (statusHold1 == 1 && colorFlag1 == 1){
                                value1 = uploadTempCl1 [1078+counter1*imageXYLength+counter2];
                                
                                if (value1 < cutHold1) value1 = 0;
                                else{
                                    
                                    value1 = value1+(int)((value1-cutHold1)*levelHold1);
                                    
                                    if (value1 > 255) value1 = 255;
                                }
                            }
                            
                            if (statusHold2 == 1 && colorFlag2 == 1){
                                value2 = uploadTempCl2 [1078+counter1*imageXYLength+counter2];
                                
                                if (value2 < cutHold2) value2 = 0;
                                else{
                                    
                                    value2 = value2+(int)((value2-cutHold2)*levelHold2);
                                    
                                    if (value2 > 255) value2 = 255;
                                }
                            }
                            
                            if (statusHold3 == 1 && colorFlag3 == 1){
                                value3 = uploadTempCl3 [1078+counter1*imageXYLength+counter2];
                                
                                if (value3 < cutHold3) value3 = 0;
                                else{
                                    
                                    value3 = value3+(int)((value3-cutHold3)*levelHold3);
                                    
                                    if (value3 > 255) value3 = 255;
                                }
                            }
                            
                            if (statusHold1 == 0) value1 = 0;
                            if (statusHold2 == 0) value2 = 0;
                            if (statusHold3 == 0) value3 = 0;
                            
                            if (value1 <= 0 && value2 <= 0 && value3 <= 0){
                                *bitmapData++ = (unsigned char)value0;
                                *bitmapData++ = (unsigned char)value0;
                                *bitmapData++ = (unsigned char)value0;
                                *bitmapData++ = 0;
                            }
                            else{
                                
                                if (value1 < 0) value1 = 0;
                                if (value2 < 0) value2 = 0;
                                if (value3 < 0) value3 = 0;
                                
                                hitR = 0;
                                hitG = 0;
                                hitB = 0;
                                
                                if (value1 > 0 && statusHold1 != 0){
                                    if (hitMap [0] != 0) hitR++;
                                    if (hitMap [1] != 0) hitG++;
                                    if (hitMap [2] != 0) hitB++;
                                }
                                
                                if (value2 > 0 && statusHold2 != 0){
                                    if (hitMap [3] != 0) hitR++;
                                    if (hitMap [4] != 0) hitG++;
                                    if (hitMap [5] != 0) hitB++;
                                }
                                
                                if (value3 > 0 && statusHold3 != 0){
                                    if (hitMap [6] != 0) hitR++;
                                    if (hitMap [7] != 0) hitG++;
                                    if (hitMap [8] != 0) hitB++;
                                }
                                
                                colorHit1 = 0;
                                colorHit2 = 0;
                                colorHit3 = 0;
                                
                                if (hitR == 1){
                                    if (hitMap [0] != 0 && value1 > 0 ) colorHit1 = 1;
                                    if (hitMap [3] != 0 && value2 > 0 ) colorHit2 = 1;
                                    if (hitMap [6] != 0 && value3 > 0 ) colorHit3 = 1;
                                    
                                }
                                else if (hitR == 2){
                                    if (hitMap [0] != 0 && value1 > 0 ) colorHit1 = 0.5;
                                    if (hitMap [3] != 0 && value2 > 0 ) colorHit2 = 0.5;
                                    if (hitMap [6] != 0 && value3 > 0 ) colorHit3 = 0.5;
                                }
                                else if (hitR == 3){
                                    if (value1 > 0) colorHit1 = 0.33;
                                    if (value2 > 0) colorHit2 = 0.33;
                                    if (value3 > 0) colorHit3 = 0.33;
                                }
                                
                                *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3));
                                
                                colorHit1 = 0;
                                colorHit2 = 0;
                                colorHit3 = 0;
                                
                                if (hitG == 1){
                                    if (hitMap [1] != 0 && value1 > 0 ) colorHit1 = 1;
                                    if (hitMap [4] != 0 && value2 > 0 ) colorHit2 = 1;
                                    if (hitMap [7] != 0 && value3 > 0 ) colorHit3 = 1;
                                }
                                else if (hitG == 2){
                                    if (hitMap [1] != 0 && value1 > 0 ) colorHit1 = 0.5;
                                    if (hitMap [4] != 0 && value2 > 0 ) colorHit2 = 0.5;
                                    if (hitMap [7] != 0 && value3 > 0 ) colorHit3 = 0.5;
                                }
                                else if (hitG == 3){
                                    if (hitMap [1] != 0 && value1 > 0 ) colorHit1 = 0.33;
                                    if (hitMap [4] != 0 && value2 > 0 ) colorHit2 = 0.33;
                                    if (hitMap [7] != 0 && value3 > 0 ) colorHit3 = 0.33;
                                }
                                
                                *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3));
                                
                                colorHit1 = 0;
                                colorHit2 = 0;
                                colorHit3 = 0;
                                
                                if (hitB == 1){
                                    if (hitMap [2] != 0 && value1 > 0 ) colorHit1 = 1;
                                    if (hitMap [5] != 0 && value2 > 0 ) colorHit2 = 1;
                                    if (hitMap [8] != 0 && value3 > 0 ) colorHit3 = 1;
                                }
                                else if (hitB == 2){
                                    if (hitMap [2] != 0 && value1 > 0 ) colorHit1 = 0.5;
                                    if (hitMap [5] != 0 && value2 > 0 ) colorHit2 = 0.5;
                                    if (hitMap [8] != 0 && value3 > 0 ) colorHit3 = 0.5;
                                }
                                else if (hitB == 3){
                                    if (hitMap [2] != 0 && value1 > 0 ) colorHit1 = 0.33;
                                    if (hitMap [5] != 0 && value2 > 0 ) colorHit2 = 0.33;
                                    if (hitMap [8] != 0 && value3 > 0 ) colorHit3 = 0.33;
                                }
                                
                                *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3));
                                *bitmapData++ = 0;
                            }
                        }
                    }
                    
                    delete [] hitMap;
                }
            }
            else{
                
                if (imageBmpTifFlag == 0){
                    unsigned long headPosition = 0;
                    
                    dataConversion [0] = uploadTemp [0];
                    dataConversion [1] = uploadTemp [1];
                    
                    if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                    else endianType = 0;
                    
                    headPosition = 0;
                    
                    if (endianType == 1){
                        dataConversion [0] = uploadTemp [7];
                        dataConversion [1] = uploadTemp [6];
                        dataConversion [2] = uploadTemp [5];
                        dataConversion [3] = uploadTemp [4];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    else if (endianType == 0){
                        dataConversion [0] = uploadTemp [4];
                        dataConversion [1] = uploadTemp [5];
                        dataConversion [2] = uploadTemp [6];
                        dataConversion [3] = uploadTemp [7];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    
                    for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                        value0 = uploadTemp [counter1];
                        
                        if (value0 >= 0 && value0 < cutHoldDIC){
                            value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                            
                            if (value0 < 0) value0 = 0;
                        }
                        else{
                            
                            value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                            
                            if (value0 > 255) value0 = 255;
                        }
                        
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = 0;
                    }
                }
                else if (imageBmpTifFlag == 1){
                    for (int counter1 = imageXYLength-1; counter1 >= 0; counter1--){
                        for (int counter2 = 0; counter2 < imageXYLength; counter2++){
                            value0 = uploadTemp [1078+counter1*imageXYLength+counter2];
                            
                            if (value0 >= 0 && value0 < cutHoldDIC){
                                value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                                
                                if (value0 < 0) value0 = 0;
                            }
                            else{
                                
                                value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                                
                                if (value0 > 255) value0 = 255;
                            }
                            
                            *bitmapData++ = (unsigned char)value0;
                            *bitmapData++ = (unsigned char)value0;
                            *bitmapData++ = (unsigned char)value0;
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
        }
        else if (grayColorStatus == 1){
            int dataConversion [4];
            int endianType = 0;
            
            unsigned long headPosition = 0;
            
            dataConversion [0] = uploadTemp [0];
            dataConversion [1] = uploadTemp [1];
            
            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
            else endianType = 0;
            
            headPosition = 0;
            
            if (endianType == 1){
                dataConversion [0] = uploadTemp [7];
                dataConversion [1] = uploadTemp [6];
                dataConversion [2] = uploadTemp [5];
                dataConversion [3] = uploadTemp [4];
                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
            }
            else if (endianType == 0){
                dataConversion [0] = uploadTemp [4];
                dataConversion [1] = uploadTemp [5];
                dataConversion [2] = uploadTemp [6];
                dataConversion [3] = uploadTemp [7];
                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
            }
            
            int value0 = 0;
            int value1 = 0;
            int value2 = 0;
            
            for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                value0 = uploadTemp [counter1];
                value0 = (int)(value0*(double)levelHoldR);
                
                if (value0 > 255) value0 = 255;
                
                value1 = uploadTemp [counter1+1];
                value1 = (int)(value1*(double)levelHoldG);
                
                if (value1 > 255) value1 = 255;
                
                value2 = uploadTemp [counter1+2];
                value2 = (int)(value2*(double)levelHoldB);
                
                if (value2 > 255) value2 = 255;
                
                *bitmapData++ = (unsigned char)value0;
                *bitmapData++ = (unsigned char)value1;
                *bitmapData++ = (unsigned char)value2;
                *bitmapData++ = 0;
            }
        }
        
        movieImage = [[NSImage alloc] initWithSize:NSMakeSize(imageXYLength, imageXYLength)];
        [movieImage addRepresentation:bitmapRepsCR];
        
        if (firstDisplayFlag == 0){
            xPositionDisplay = 0;
            yPositionDisplay = 0;
            xPositionAdjustDisplay = 0;
            yPositionAdjustDisplay = 0;
            magnificationDisplay = 10;
            firstDisplayFlag = 1;
        }
        
        int vertical = 600+78;
        int horizontal = 600;
        
        windowWidthDisplay = imageXYLength/(double)horizontal;
        windowHeightDisplay = imageXYLength/(double)(vertical-78);
        
        xPositionAdjustDisplay = (imageXYLength-imageXYLength/(double)(magnificationDisplay*0.1))/(double)2;
        yPositionAdjustDisplay = (imageXYLength-imageXYLength/(double)(magnificationDisplay*0.1))/(double)2;
        
        [self setNeedsDisplay:YES];
    }
}

//----------First Responder----------
-(BOOL)acceptsFirstResponder{
    return YES;
}

-(void)mouseDown:(NSEvent *)event{
    NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
    xPointDownDisplay = clickPoint.x;
    yPointDownDisplay = clickPoint.y;
    [self setNeedsDisplay:YES];
}

-(void)mouseUp:(NSEvent *)event{
    xPositionDisplay = xPositionDisplay+xPositionMoveDisplay;
    yPositionDisplay = yPositionDisplay+yPositionMoveDisplay;
    xPositionMoveDisplay = 0;
    yPositionMoveDisplay = 0;
    mouseDragFlag = 0;
    [self setNeedsDisplay:YES];
}

- (void)mouseDragged:(NSEvent *)event{
    NSPoint clickPoint= [self convertPoint:[event locationInWindow] fromView:nil];
    xPointDragDisplay = clickPoint.x;
    yPointDragDisplay = clickPoint.y;
    xPositionMoveDisplay = (xPointDownDisplay-xPointDragDisplay)*windowWidthDisplay/(double)(magnificationDisplay*0.1);
    yPositionMoveDisplay = (yPointDownDisplay-yPointDragDisplay)*windowHeightDisplay/(double)(magnificationDisplay*0.1);
    
    mouseDragFlag = 1;
    
    [self setNeedsDisplay:YES];
}

-(void)keyDown:(NSEvent *)event{
    int keyCode = [event keyCode];
    int proceedFlag = 0;
    
    
    if (keyCode == 124 && movieRunningFlag == 0){
        filePosition++;
        
        if (maxImageNo < filePosition) filePosition--;
        
        proceedFlag = 1;
        string timeDisplayTemp = fileList [(filePosition-1)*7];
        timeDisplayTemp = timeDisplayTemp.substr(8, 4);
        
        timePointHold = atoi(timeDisplayTemp.c_str());
        timePointDisplayCall = 1;
        
    }
    
    if (keyCode == 123 && movieRunningFlag == 0){
        filePosition--;
        
        if (filePosition <= 0) filePosition = 1;
        
        proceedFlag = 1;
        string timeDisplayTemp = fileList [(filePosition-1)*7];
        timeDisplayTemp = timeDisplayTemp.substr(8, 4);
        
        timePointHold = atoi(timeDisplayTemp.c_str());
        timePointDisplayCall = 1;
    }
    
    //------Magnification Magnify------
    if (keyCode == 125){
        if (magnificationDisplay >= 10 && magnificationDisplay <= 350){
            if (magnificationDisplay-10 < 10) magnificationDisplay = 10;
            else magnificationDisplay = magnificationDisplay-10;
            
            xPositionAdjustDisplay = -1*(imageXYLength/(double)(magnificationDisplay*0.1)-imageXYLength)/(double)2;
            yPositionAdjustDisplay = -1*(imageXYLength/(double)(magnificationDisplay*0.1)-imageXYLength)/(double)2;
            
            [self setNeedsDisplay:YES];
        }
    }
    
    //------Magnification Reduction------
    if (keyCode == 126){
        if (magnificationDisplay >= 10 && magnificationDisplay <= 498){
            if (magnificationDisplay+10 > 498) magnificationDisplay = 498;
            else magnificationDisplay = magnificationDisplay+10;
            
            xPositionAdjustDisplay = (imageXYLength-imageXYLength/(double)(magnificationDisplay*0.1))/(double)2;
            yPositionAdjustDisplay = (imageXYLength-imageXYLength/(double)(magnificationDisplay*0.1))/(double)2;
            
            [self setNeedsDisplay:YES];
        }
    }
    
    if (proceedFlag == 1){
        string imageMoviePath = imageDisplayPath+"/"+fileList [(filePosition-1)*7];
        
        if (statusHoldDIC == 1){
            if (filePosition > lastDICImageTime) imageMoviePath = imageDisplayPath+"/"+fileList [(lastDICImageTime-1)*7];
        }
        
        ifstream fin;
        
        fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
        
        if (fin.is_open()){
            fin.read((char*)uploadTemp, (long)uploadTempFileSize+1);
            fin.close();
        }
        
        if (fileList [(filePosition-1)*7+1] != ""){
            colorFlag1 = 1;
            colorFlag2 = 0;
            colorFlag3 = 0;
            colorFlag4 = 0;
            colorFlag5 = 0;
            colorFlag6 = 0;
            
            unsigned long findString = fileList [(filePosition-1)*7+1].find("tif");
            if ((int)findString == -1) findString = fileList [(filePosition-1)*7+1].find("TIF");
            if ((int)findString == -1) findString = fileList [(filePosition-1)*7+1].find("bmp");
            if ((int)findString == -1) findString = fileList [(filePosition-1)*7+1].find("BMP");
            
            colorNo1 = fileList [(filePosition-1)*7+1].substr(13, 1);
            colorName1 = fileList [(filePosition-1)*7+1].substr(15, findString-16);
            
            imageMoviePath = imageDisplayPath+"/"+fileList [(filePosition-1)*7+1];
            
            if (uploadTempStatusCl1 == 1) delete [] uploadTempCl1;
            
            uploadTempCl1 = new uint8_t [uploadTempFileSize+50];
            uploadTempStatusCl1 = 1;
            
            fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
            
            fin.read((char*)uploadTempCl1, (long)uploadTempFileSize+1);
            fin.close();
            
            if (fileList [(filePosition-1)*7+2] != ""){
                colorFlag2 = 1;
                
                findString = fileList [(filePosition-1)*7+2].find("tif");
                if ((int)findString == -1) findString = fileList [(filePosition-1)*7+2].find("TIF");
                if ((int)findString == -1) findString = fileList [(filePosition-1)*7+2].find("bmp");
                if ((int)findString == -1) findString = fileList [(filePosition-1)*7+2].find("BMP");
                
                colorNo2 = fileList [(filePosition-1)*7+2].substr(13, 1);
                colorName2 = fileList [(filePosition-1)*7+2].substr(15, findString-16);
                
                imageMoviePath = imageDisplayPath+"/"+fileList [(filePosition-1)*7+2];
                
                if (uploadTempStatusCl2 == 1) delete [] uploadTempCl2;
                
                uploadTempCl2 = new uint8_t [uploadTempFileSize+50];
                uploadTempStatusCl2 = 1;
                
                fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
                
                fin.read((char*)uploadTempCl2, (long)uploadTempFileSize+1);
                fin.close();
                
                if (fileList [(filePosition-1)*7+3] != ""){
                    colorFlag3 = 1;
                    
                    findString = fileList [(filePosition-1)*7+3].find("tif");
                    if ((int)findString == -1) findString = fileList [(filePosition-1)*7+3].find("TIF");
                    if ((int)findString == -1) findString = fileList [(filePosition-1)*7+3].find("bmp");
                    if ((int)findString == -1) findString = fileList [(filePosition-1)*7+3].find("BMP");
                    
                    colorNo3 = fileList [(filePosition-1)*7+3].substr(13, 1);
                    colorName3 = fileList [(filePosition-1)*7+3].substr(15, findString-16);
                    
                    imageMoviePath = imageDisplayPath+"/"+fileList [(filePosition-1)*7+3];
                    
                    if (uploadTempStatusCl3 == 1) delete [] uploadTempCl3;
                    
                    uploadTempCl3 = new uint8_t [uploadTempFileSize+50];
                    uploadTempStatusCl3 = 1;
                    
                    fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
                    
                    fin.read((char*)uploadTempCl3, (long)uploadTempFileSize+1);
                    fin.close();
                    
                    if (fileList [(filePosition-1)*7+4] != ""){
                        colorFlag4 = 1;
                        
                        findString = fileList [(filePosition-1)*7+4].find("tif");
                        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+4].find("TIF");
                        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+4].find("bmp");
                        if ((int)findString == -1) findString = fileList [(filePosition-1)*7+4].find("BMP");
                        
                        colorNo4 = fileList [(filePosition-1)*7+4].substr(13, 1);
                        colorName4 = fileList [(filePosition-1)*7+4].substr(15, findString-16);
                        
                        imageMoviePath = imageDisplayPath+"/"+fileList [(filePosition-1)*7+4];
                        
                        if (uploadTempStatusCl4 == 1) delete [] uploadTempCl4;
                        
                        uploadTempCl4 = new uint8_t [uploadTempFileSize+50];
                        uploadTempStatusCl4 = 1;
                        
                        fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
                        
                        fin.read((char*)uploadTempCl4, (long)uploadTempFileSize+1);
                        fin.close();
                        
                        if (fileList [(filePosition-1)*7+5] != ""){
                            colorFlag5 = 1;
                            
                            findString = fileList [(filePosition-1)*7+5].find("tif");
                            if ((int)findString == -1) findString = fileList [(filePosition-1)*7+5].find("TIF");
                            if ((int)findString == -1) findString = fileList [(filePosition-1)*7+5].find("bmp");
                            if ((int)findString == -1) findString = fileList [(filePosition-1)*7+5].find("BMP");
                            
                            colorNo5 = fileList [(filePosition-1)*7+5].substr(13, 1);
                            colorName5 = fileList [(filePosition-1)*7+5].substr(15, findString-16);
                            
                            imageMoviePath = imageDisplayPath+"/"+fileList [(filePosition-1)*7+5];
                            
                            if (uploadTempStatusCl5 == 1) delete [] uploadTempCl5;
                            
                            uploadTempCl5 = new uint8_t [uploadTempFileSize+50];
                            uploadTempStatusCl5 = 1;
                            
                            fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
                            
                            fin.read((char*)uploadTempCl5, (long)uploadTempFileSize+1);
                            fin.close();
                            
                            if (fileList [(filePosition-1)*7+6] != ""){
                                colorFlag6 = 1;
                                
                                findString = fileList [(filePosition-1)*7+6].find("tif");
                                if ((int)findString == -1) findString = fileList [(filePosition-1)*7+6].find("TIF");
                                if ((int)findString == -1) findString = fileList [(filePosition-1)*7+6].find("bmp");
                                if ((int)findString == -1) findString = fileList [(filePosition-1)*7+6].find("BMP");
                                
                                colorNo6 = fileList [(filePosition-1)*7+6].substr(13, 1);
                                colorName6 = fileList [(filePosition-1)*7+6].substr(15, findString-16);
                                
                                imageMoviePath = imageDisplayPath+"/"+fileList [(filePosition-1)*7+6];
                                
                                if (uploadTempStatusCl6 == 1) delete [] uploadTempCl6;
                                
                                uploadTempCl6 = new uint8_t [uploadTempFileSize+50];
                                uploadTempStatusCl6 = 1;
                                
                                fin.open(imageMoviePath.c_str(), ios::in | ios::binary);
                                
                                fin.read((char*)uploadTempCl6, (long)uploadTempFileSize+1);
                                fin.close();
                            }
                        }
                    }
                }
            }
            
            colorInfoDisplayCall = 1;
        }
        else{
            
            if (colorFlag1 != 0){
                colorFlag1 = 0;
                colorFlag2 = 0;
                colorFlag3 = 0;
                colorFlag4 = 0;
                colorFlag5 = 0;
                colorFlag6 = 0;
                
                colorInfoDisplayCall = 1;
            }
        }
        
        NSBitmapImageRep *bitmapRepsCR = nil;
        bitmapRepsCR = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:imageXYLength pixelsHigh:imageXYLength bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:imageXYLength*4 bitsPerPixel:32];
        
        unsigned char *bitmapData = [bitmapRepsCR bitmapData];
        
        if (grayColorStatus == 0){
            int value0 = 0;
            int value1 = 0;
            int value2 = 0;
            int value3 = 0;
            int value4 = 0;
            int value5 = 0;
            int value6 = 0;
            
            int dataConversion [4];
            int endianType = 0;
            
            double colorHit1 = 0;
            double colorHit2 = 0;
            double colorHit3 = 0;
            double colorHit4 = 0;
            double colorHit5 = 0;
            double colorHit6 = 0;
            
            int hitR = 0;
            int hitG = 0;
            int hitB = 0;
            
            if (statusHold1 != 0 || statusHold2 != 0 || statusHold3 != 0 || statusHold4 != 0 || statusHold5 != 0 || statusHold6 != 0){
                if (imageBmpTifFlag == 0){
                    double *hitMap = new double [20];
                    
                    if (colorNo1 == "1"){
                        hitMap [0] = 0;
                        hitMap [1] = 0;
                        hitMap [2] = 1;
                    }
                    else if (colorNo1 == "2"){
                        hitMap [0] = 0;
                        hitMap [1] = 1;
                        hitMap [2] = 0;
                    }
                    else if (colorNo1 == "3"){
                        hitMap [0] = 1;
                        hitMap [1] = 1;
                        hitMap [2] = 0;
                    }
                    else if (colorNo1 == "4"){
                        hitMap [0] = 1;
                        hitMap [1] = 0;
                        hitMap [2] = 0;
                    }
                    else if (colorNo1 == "5"){
                        hitMap [0] = 1;
                        hitMap [1] = 0;
                        hitMap [2] = 1;
                    }
                    else if (colorNo1 == "6"){
                        hitMap [0] = 0;
                        hitMap [1] = 1;
                        hitMap [2] = 1;
                    }
                    else if (colorNo1 == "7"){
                        hitMap [0] = 1;
                        hitMap [1] = 0.674;
                        hitMap [2] = 0;
                    }
                    else if (colorNo1 == "8"){
                        hitMap [0] = 0.627;
                        hitMap [1] = 0.125;
                        hitMap [2] = 0.941;
                    }
                    else if (colorNo1 == "9"){
                        hitMap [0] = 0.529;
                        hitMap [1] = 0.808;
                        hitMap [2] = 0.922;
                    }
                    
                    if (colorNo2 == "1"){
                        hitMap [3] = 0;
                        hitMap [4] = 0;
                        hitMap [5] = 1;
                    }
                    else if (colorNo2 == "2"){
                        hitMap [3] = 0;
                        hitMap [4] = 1;
                        hitMap [5] = 0;
                    }
                    else if (colorNo2 == "3"){
                        hitMap [3] = 1;
                        hitMap [4] = 1;
                        hitMap [5] = 0;
                    }
                    else if (colorNo2 == "4"){
                        hitMap [3] = 1;
                        hitMap [4] = 0;
                        hitMap [5] = 0;
                    }
                    else if (colorNo2 == "5"){
                        hitMap [3] = 1;
                        hitMap [4] = 0;
                        hitMap [5] = 1;
                    }
                    else if (colorNo2 == "6"){
                        hitMap [3] = 0;
                        hitMap [4] = 1;
                        hitMap [5] = 1;
                    }
                    else if (colorNo2 == "7"){
                        hitMap [3] = 1;
                        hitMap [4] = 0.674;
                        hitMap [5] = 0;
                    }
                    else if (colorNo2 == "8"){
                        hitMap [3] = 0.627;
                        hitMap [4] = 0.125;
                        hitMap [5] = 0.941;
                    }
                    else if (colorNo2 == "9"){
                        hitMap [3] = 0.529;
                        hitMap [4] = 0.808;
                        hitMap [5] = 0.922;
                    }
                    
                    if (colorNo3 == "1"){
                        hitMap [6] = 0;
                        hitMap [7] = 0;
                        hitMap [8] = 1;
                    }
                    else if (colorNo3 == "2"){
                        hitMap [6] = 0;
                        hitMap [7] = 1;
                        hitMap [8] = 0;
                    }
                    else if (colorNo3 == "3"){
                        hitMap [6] = 1;
                        hitMap [7] = 1;
                        hitMap [8] = 0;
                    }
                    else if (colorNo3 == "4"){
                        hitMap [6] = 1;
                        hitMap [7] = 0;
                        hitMap [8] = 0;
                    }
                    else if (colorNo3 == "5"){
                        hitMap [6] = 1;
                        hitMap [7] = 0;
                        hitMap [8] = 1;
                    }
                    else if (colorNo3 == "6"){
                        hitMap [6] = 0;
                        hitMap [7] = 1;
                        hitMap [8] = 1;
                    }
                    else if (colorNo3 == "7"){
                        hitMap [6] = 1;
                        hitMap [7] = 0.674;
                        hitMap [8] = 0;
                    }
                    else if (colorNo3 == "8"){
                        hitMap [6] = 0.627;
                        hitMap [7] = 0.125;
                        hitMap [8] = 0.941;
                    }
                    else if (colorNo3 == "9"){
                        hitMap [6] = 0.529;
                        hitMap [7] = 0.808;
                        hitMap [8] = 0.922;
                    }
                    
                    if (colorNo4 == "1"){
                        hitMap [9] = 0;
                        hitMap [10] = 0;
                        hitMap [11] = 1;
                    }
                    else if (colorNo4 == "2"){
                        hitMap [9] = 0;
                        hitMap [10] = 1;
                        hitMap [11] = 0;
                    }
                    else if (colorNo4 == "3"){
                        hitMap [9] = 1;
                        hitMap [10] = 1;
                        hitMap [11] = 0;
                    }
                    else if (colorNo4 == "4"){
                        hitMap [9] = 1;
                        hitMap [10] = 0;
                        hitMap [11] = 0;
                    }
                    else if (colorNo4 == "5"){
                        hitMap [9] = 1;
                        hitMap [10] = 0;
                        hitMap [11] = 1;
                    }
                    else if (colorNo4 == "6"){
                        hitMap [9] = 0;
                        hitMap [10] = 1;
                        hitMap [11] = 1;
                    }
                    else if (colorNo4 == "7"){
                        hitMap [9] = 1;
                        hitMap [10] = 0.674;
                        hitMap [11] = 0;
                    }
                    else if (colorNo4 == "8"){
                        hitMap [9] = 0.627;
                        hitMap [10] = 0.125;
                        hitMap [11] = 0.941;
                    }
                    else if (colorNo4 == "9"){
                        hitMap [9] = 0.529;
                        hitMap [10] = 0.808;
                        hitMap [11] = 0.922;
                    }
                    
                    if (colorNo5 == "1"){
                        hitMap [12] = 0;
                        hitMap [13] = 0;
                        hitMap [14] = 1;
                    }
                    else if (colorNo5 == "2"){
                        hitMap [12] = 0;
                        hitMap [13] = 1;
                        hitMap [14] = 0;
                    }
                    else if (colorNo5 == "3"){
                        hitMap [12] = 1;
                        hitMap [13] = 1;
                        hitMap [14] = 0;
                    }
                    else if (colorNo5 == "4"){
                        hitMap [12] = 1;
                        hitMap [13] = 0;
                        hitMap [14] = 0;
                    }
                    else if (colorNo5 == "5"){
                        hitMap [12] = 1;
                        hitMap [13] = 0;
                        hitMap [14] = 1;
                    }
                    else if (colorNo5 == "6"){
                        hitMap [12] = 0;
                        hitMap [13] = 1;
                        hitMap [14] = 1;
                    }
                    else if (colorNo5 == "7"){
                        hitMap [12] = 1;
                        hitMap [13] = 0.674;
                        hitMap [14] = 0;
                    }
                    else if (colorNo5 == "8"){
                        hitMap [12] = 0.627;
                        hitMap [13] = 0.125;
                        hitMap [14] = 0.941;
                    }
                    else if (colorNo5 == "9"){
                        hitMap [12] = 0.529;
                        hitMap [13] = 0.808;
                        hitMap [14] = 0.922;
                    }
                    
                    if (colorNo6 == "1"){
                        hitMap [15] = 0;
                        hitMap [16] = 0;
                        hitMap [17] = 1;
                    }
                    else if (colorNo6 == "2"){
                        hitMap [15] = 0;
                        hitMap [16] = 1;
                        hitMap [17] = 0;
                    }
                    else if (colorNo6 == "3"){
                        hitMap [15] = 1;
                        hitMap [16] = 1;
                        hitMap [17] = 0;
                    }
                    else if (colorNo6 == "4"){
                        hitMap [15] = 1;
                        hitMap [16] = 0;
                        hitMap [17] = 0;
                    }
                    else if (colorNo6 == "5"){
                        hitMap [15] = 1;
                        hitMap [16] = 0;
                        hitMap [17] = 1;
                    }
                    else if (colorNo6 == "6"){
                        hitMap [15] = 0;
                        hitMap [16] = 1;
                        hitMap [17] = 1;
                    }
                    else if (colorNo6 == "7"){
                        hitMap [15] = 1;
                        hitMap [16] = 0.674;
                        hitMap [17] = 0;
                    }
                    else if (colorNo6 == "8"){
                        hitMap [15] = 0.627;
                        hitMap [16] = 0.125;
                        hitMap [17] = 0.941;
                    }
                    else if (colorNo6 == "9"){
                        hitMap [15] = 0.529;
                        hitMap [16] = 0.808;
                        hitMap [17] = 0.922;
                    }
                    
                    unsigned long headPosition = 0;
                    
                    dataConversion [0] = uploadTemp [0];
                    dataConversion [1] = uploadTemp [1];
                    
                    if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                    else endianType = 0;
                    
                    headPosition = 0;
                    
                    if (endianType == 1){
                        dataConversion [0] = uploadTemp [7];
                        dataConversion [1] = uploadTemp [6];
                        dataConversion [2] = uploadTemp [5];
                        dataConversion [3] = uploadTemp [4];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    else if (endianType == 0){
                        dataConversion [0] = uploadTemp [4];
                        dataConversion [1] = uploadTemp [5];
                        dataConversion [2] = uploadTemp [6];
                        dataConversion [3] = uploadTemp [7];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    
                    for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                        value1 = 0;
                        value2 = 0;
                        value3 = 0;
                        value4 = 0;
                        value5 = 0;
                        value6 = 0;
                        
                        value0 = uploadTemp [counter1];
                        
                        if (value0 >= 0 && value0 < cutHoldDIC){
                            value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                            
                            if (value0 < 0) value0 = 0;
                        }
                        else{
                            
                            value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                            
                            if (value0 > 255) value0 = 255;
                        }
                        
                        if (statusHold1 == 1 && colorFlag1 == 1){
                            value1 = uploadTempCl1 [counter1];
                            
                            if (value1 < cutHold1) value1 = 0;
                            else{
                                
                                value1 = value1+(int)((value1-cutHold1)*levelHold1);
                                
                                if (value1 > 255) value1 = 255;
                            }
                        }
                        
                        if (statusHold2 == 1 && colorFlag2 == 1){
                            value2 = uploadTempCl2 [counter1];
                            
                            if (value2 < cutHold2) value2 = 0;
                            else{
                                
                                value2 = value2+(int)((value2-cutHold2)*levelHold2);
                                
                                if (value2 > 255) value2 = 255;
                            }
                        }
                        
                        if (statusHold3 == 1 && colorFlag3 == 1){
                            value3 = uploadTempCl3 [counter1];
                            
                            if (value3 < cutHold3) value3 = 0;
                            else{
                                
                                value3 = value3+(int)((value3-cutHold3)*levelHold3);
                                
                                if (value3 > 255) value3 = 255;
                            }
                        }
                        
                        if (statusHold4 == 1 && colorFlag4 == 1){
                            value4 = uploadTempCl4 [counter1];
                            
                            if (value4 < cutHold4) value4 = 0;
                            else{
                                
                                value4 = value4+(int)((value4-cutHold4)*levelHold4);
                                
                                if (value4 > 255) value4 = 255;
                            }
                        }
                        
                        if (statusHold5 == 1 && colorFlag5 == 1){
                            value5 = uploadTempCl5 [counter1];
                            
                            if (value5 < cutHold5) value5 = 0;
                            else{
                                
                                value5 = value5+(int)((value5-cutHold5)*levelHold5);
                                
                                if (value5 > 255) value5 = 255;
                            }
                        }
                        
                        if (statusHold6 == 1 && colorFlag6 == 1){
                            value6 = uploadTempCl6 [counter1];
                            
                            if (value6 < cutHold6) value6 = 0;
                            else{
                                
                                value6 = value6+(int)((value6-cutHold6)*levelHold6);
                                
                                if (value6 > 255) value6 = 255;
                            }
                        }
                        
                        if (statusHold1 == 0) value1 = 0;
                        if (statusHold2 == 0) value2 = 0;
                        if (statusHold3 == 0) value3 = 0;
                        if (statusHold4 == 0) value4 = 0;
                        if (statusHold5 == 0) value5 = 0;
                        if (statusHold6 == 0) value6 = 0;
                        
                        if (value1 <= 0 && value2 <= 0 && value3 <= 0 && value4 <= 0 && value5 <= 0 && value6 <= 0){
                            *bitmapData++ = (unsigned char)value0;
                            *bitmapData++ = (unsigned char)value0;
                            *bitmapData++ = (unsigned char)value0;
                            *bitmapData++ = 0;
                        }
                        else{
                            
                            if (value1 < 0) value1 = 0;
                            if (value2 < 0) value2 = 0;
                            if (value3 < 0) value3 = 0;
                            if (value4 < 0) value4 = 0;
                            if (value5 < 0) value5 = 0;
                            if (value6 < 0) value6 = 0;
                            
                            hitR = 0;
                            hitG = 0;
                            hitB = 0;
                            
                            if (value1 > 0){
                                if (hitMap [0] != 0) hitR++;
                                if (hitMap [1] != 0) hitG++;
                                if (hitMap [2] != 0) hitB++;
                            }
                            
                            if (value2 > 0){
                                if (hitMap [3] != 0) hitR++;
                                if (hitMap [4] != 0) hitG++;
                                if (hitMap [5] != 0) hitB++;
                            }
                            
                            if (value3 > 0){
                                if (hitMap [6] != 0) hitR++;
                                if (hitMap [7] != 0) hitG++;
                                if (hitMap [8] != 0) hitB++;
                            }
                            
                            if (value4 > 0){
                                if (hitMap [9] != 0) hitR++;
                                if (hitMap [10] != 0) hitG++;
                                if (hitMap [11] != 0) hitB++;
                            }
                            
                            if (value5 > 0){
                                if (hitMap [12] != 0) hitR++;
                                if (hitMap [13] != 0) hitG++;
                                if (hitMap [14] != 0) hitB++;
                            }
                            
                            if (value6 > 0){
                                if (hitMap [15] != 0) hitR++;
                                if (hitMap [16] != 0) hitG++;
                                if (hitMap [17] != 0) hitB++;
                            }
                            
                            colorHit1 = 0;
                            colorHit2 = 0;
                            colorHit3 = 0;
                            colorHit4 = 0;
                            colorHit5 = 0;
                            colorHit6 = 0;
                            
                            if (hitR == 1){
                                if (hitMap [0] != 0 && value1 > 0) colorHit1 = 1;
                                if (hitMap [3] != 0 && value2 > 0) colorHit2 = 1;
                                if (hitMap [6] != 0 && value3 > 0) colorHit3 = 1;
                                if (hitMap [9] != 0 && value4 > 0) colorHit4 = 1;
                                if (hitMap [12] != 0 && value5 > 0) colorHit5 = 1;
                                if (hitMap [15] != 0 && value6 > 0) colorHit6 = 1;
                            }
                            else if (hitR == 2){
                                if (hitMap [0] != 0 && value1 > 0) colorHit1 = 0.5;
                                if (hitMap [3] != 0 && value2 > 0) colorHit2 = 0.5;
                                if (hitMap [6] != 0 && value3 > 0) colorHit3 = 0.5;
                                if (hitMap [9] != 0 && value4 > 0) colorHit4 = 0.5;
                                if (hitMap [12] != 0 && value5 > 0) colorHit5 = 0.5;
                                if (hitMap [15] != 0 && value6 > 0) colorHit6 = 0.5;
                            }
                            else if (hitR == 3){
                                if (hitMap [0] != 0 && value1 > 0) colorHit1 = 0.33;
                                if (hitMap [3] != 0 && value2 > 0) colorHit2 = 0.33;
                                if (hitMap [6] != 0 && value3 > 0) colorHit3 = 0.33;
                                if (hitMap [9] != 0 && value4 > 0) colorHit4 = 0.33;
                                if (hitMap [12] != 0 && value5 > 0) colorHit5 = 0.33;
                                if (hitMap [15] != 0 && value6 > 0) colorHit6 = 0.33;
                            }
                            else if (hitR == 4){
                                if (hitMap [0] != 0 && value1 > 0) colorHit1 = 0.25;
                                if (hitMap [3] != 0 && value2 > 0) colorHit2 = 0.25;
                                if (hitMap [6] != 0 && value3 > 0) colorHit3 = 0.25;
                                if (hitMap [9] != 0 && value4 > 0) colorHit4 = 0.25;
                                if (hitMap [12] != 0 && value5 > 0) colorHit5 = 0.25;
                                if (hitMap [15] != 0 && value6 > 0) colorHit6 = 0.25;
                            }
                            else if (hitR == 5){
                                if (hitMap [0] != 0 && value1 > 0) colorHit1 = 0.2;
                                if (hitMap [3] != 0 && value2 > 0) colorHit2 = 0.2;
                                if (hitMap [6] != 0 && value3 > 0) colorHit3 = 0.2;
                                if (hitMap [9] != 0 && value4 > 0) colorHit4 = 0.2;
                                if (hitMap [12] != 0 && value5 > 0) colorHit5 = 0.2;
                                if (hitMap [15] != 0 && value6 > 0) colorHit6 = 0.2;
                            }
                            else if (hitR == 6){
                                if (hitMap [0] != 0 && value1 > 0) colorHit1 = 0.13;
                                if (hitMap [3] != 0 && value2 > 0) colorHit2 = 0.13;
                                if (hitMap [6] != 0 && value3 > 0) colorHit3 = 0.13;
                                if (hitMap [9] != 0 && value4 > 0) colorHit4 = 0.13;
                                if (hitMap [12] != 0 && value5 > 0) colorHit5 = 0.13;
                                if (hitMap [15] != 0 && value6 > 0) colorHit6 = 0.13;
                            }
                            
                            if (value1 > 0 && colorNo1 == "7") colorHit1 = colorHit1*0.647;
                            else if (value1 > 0 && colorNo1 == "8") colorHit1 = colorHit1*0.627;
                            else if (value1 > 0 && colorNo1 == "9") colorHit1 = colorHit1*0.529;
                            
                            if (value2 > 0 && colorNo2 == "7") colorHit2 = colorHit2*0.647;
                            else if (value2 > 0 && colorNo2 == "8") colorHit2 = colorHit2*0.627;
                            else if (value2 > 0 && colorNo2 == "9") colorHit2 = colorHit2*0.529;
                            
                            if (value3 > 0 && colorNo3 == "7") colorHit3 = colorHit3*0.647;
                            else if (value3 > 0 && colorNo3 == "8") colorHit3 = colorHit3*0.627;
                            else if (value3 > 0 && colorNo3 == "9") colorHit3 = colorHit3*0.529;
                            
                            if (value4 > 0 && colorNo4 == "7") colorHit4 = colorHit4*0.647;
                            else if (value4 > 0 && colorNo4 == "8") colorHit4 = colorHit4*0.627;
                            else if (value4 > 0 && colorNo4 == "9") colorHit4 = colorHit4*0.529;
                            
                            if (value5 > 0 && colorNo5 == "7") colorHit5 = colorHit5*0.647;
                            else if (value5 > 0 && colorNo5 == "8") colorHit5 = colorHit5*0.627;
                            else if (value5 > 0 && colorNo5 == "9") colorHit5 = colorHit5*0.529;
                            
                            if (value6 > 0 && colorNo6 == "7") colorHit6 = colorHit6*0.647;
                            else if (value6 > 0 && colorNo6 == "8") colorHit6 = colorHit6*0.627;
                            else if (value6 > 0 && colorNo6 == "9") colorHit6 = colorHit6*0.529;
                            
                            *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3+value4*(double)colorHit4+value5*(double)colorHit5+value6*(double)colorHit6));
                            
                            colorHit1 = 0;
                            colorHit2 = 0;
                            colorHit3 = 0;
                            colorHit4 = 0;
                            colorHit5 = 0;
                            colorHit6 = 0;
                            
                            if (hitG == 1){
                                if (hitMap [1] != 0 && value1 > 0) colorHit1 = 1;
                                if (hitMap [4] != 0 && value2 > 0) colorHit2 = 1;
                                if (hitMap [7] != 0 && value3 > 0) colorHit3 = 1;
                                if (hitMap [10] != 0 && value4 > 0) colorHit4 = 1;
                                if (hitMap [13] != 0 && value5 > 0) colorHit5 = 1;
                                if (hitMap [16] != 0 && value6 > 0) colorHit6 = 1;
                            }
                            else if (hitG == 2){
                                if (hitMap [1] != 0 && value1 > 0) colorHit1 = 0.5;
                                if (hitMap [4] != 0 && value2 > 0) colorHit2 = 0.5;
                                if (hitMap [7] != 0 && value3 > 0) colorHit3 = 0.5;
                                if (hitMap [10] != 0 && value4 > 0) colorHit4 = 0.5;
                                if (hitMap [13] != 0 && value5 > 0) colorHit5 = 0.5;
                                if (hitMap [16] != 0 && value6 > 0) colorHit6 = 0.5;
                            }
                            else if (hitG == 3){
                                if (hitMap [1] != 0 && value1 > 0) colorHit1 = 0.33;
                                if (hitMap [4] != 0 && value2 > 0) colorHit2 = 0.33;
                                if (hitMap [7] != 0 && value3 > 0) colorHit3 = 0.33;
                                if (hitMap [10] != 0 && value4 > 0) colorHit4 = 0.33;
                                if (hitMap [13] != 0 && value5 > 0) colorHit5 = 0.33;
                                if (hitMap [16] != 0 && value6 > 0) colorHit6 = 0.33;
                            }
                            else if (hitG == 4){
                                if (hitMap [1] != 0 && value1 > 0) colorHit1 = 0.25;
                                if (hitMap [4] != 0 && value2 > 0) colorHit2 = 0.25;
                                if (hitMap [7] != 0 && value3 > 0) colorHit3 = 0.25;
                                if (hitMap [10] != 0 && value4 > 0) colorHit4 = 0.25;
                                if (hitMap [13] != 0 && value5 > 0) colorHit5 = 0.25;
                                if (hitMap [16] != 0 && value6 > 0) colorHit6 = 0.25;
                            }
                            else if (hitG == 5){
                                if (hitMap [1] != 0 && value1 > 0) colorHit1 = 0.2;
                                if (hitMap [4] != 0 && value2 > 0) colorHit2 = 0.2;
                                if (hitMap [7] != 0 && value3 > 0) colorHit3 = 0.2;
                                if (hitMap [10] != 0 && value4 > 0) colorHit4 = 0.2;
                                if (hitMap [13] != 0 && value5 > 0) colorHit5 = 0.2;
                                if (hitMap [16] != 0 && value6 > 0) colorHit6 = 0.2;
                            }
                            else if (hitG == 6){
                                if (hitMap [1] != 0 && value1 > 0) colorHit1 = 0.13;
                                if (hitMap [4] != 0 && value2 > 0) colorHit2 = 0.13;
                                if (hitMap [7] != 0 && value3 > 0) colorHit3 = 0.13;
                                if (hitMap [10] != 0 && value4 > 0) colorHit4 = 0.13;
                                if (hitMap [13] != 0 && value5 > 0) colorHit5 = 0.13;
                                if (hitMap [16] != 0 && value6 > 0) colorHit6 = 0.13;
                            }
                            
                            if (value1 > 0 && colorNo1 == "8") colorHit1 = colorHit1*0.125;
                            else if (value1 > 0 && colorNo1 == "9") colorHit1 = colorHit1*0.808;
                            
                            if (value2 > 0 && colorNo2 == "8") colorHit2 = colorHit2*0.125;
                            else if (value2 > 0 && colorNo2 == "9") colorHit2 = colorHit2*0.808;
                            
                            if (value3 > 0 && colorNo3 == "8") colorHit3 = colorHit3*0.125;
                            else if (value3 > 0 && colorNo3 == "9") colorHit3 = colorHit3*0.808;
                            
                            if (value4 > 0 && colorNo4 == "8") colorHit4 = colorHit4*0.125;
                            else if (value4 > 0 && colorNo4 == "9") colorHit4 = colorHit4*0.808;
                            
                            if (value5 > 0 && colorNo5 == "8") colorHit5 = colorHit5*0.125;
                            else if (value5 > 0 && colorNo5 == "9") colorHit5 = colorHit5*0.808;
                            
                            if (value6 > 0 && colorNo6 == "8") colorHit6 = colorHit6*0.125;
                            else if (value6 > 0 && colorNo6 == "9") colorHit6 = colorHit6*0.808;
                            
                            *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3+value4*(double)colorHit4+value5*(double)colorHit5+value6*(double)colorHit6));
                            
                            colorHit1 = 0;
                            colorHit2 = 0;
                            colorHit3 = 0;
                            colorHit4 = 0;
                            colorHit5 = 0;
                            colorHit6 = 0;
                            
                            if (hitB == 1){
                                if (hitMap [2] != 0 && value1 > 0) colorHit1 = 1;
                                if (hitMap [5] != 0 && value2 > 0) colorHit2 = 1;
                                if (hitMap [8] != 0 && value3 > 0) colorHit3 = 1;
                                if (hitMap [11] != 0 && value4 > 0) colorHit4 = 1;
                                if (hitMap [14] != 0 && value5 > 0) colorHit5 = 1;
                                if (hitMap [17] != 0 && value6 > 0) colorHit6 = 1;
                            }
                            else if (hitB == 2){
                                if (hitMap [2] != 0 && value1 > 0) colorHit1 = 0.5;
                                if (hitMap [5] != 0 && value2 > 0) colorHit2 = 0.5;
                                if (hitMap [8] != 0 && value3 > 0) colorHit3 = 0.5;
                                if (hitMap [11] != 0 && value4 > 0) colorHit4 = 0.5;
                                if (hitMap [14] != 0 && value5 > 0) colorHit5 = 0.5;
                                if (hitMap [17] != 0 && value6 > 0) colorHit6 = 0.5;
                            }
                            else if (hitB == 3){
                                if (hitMap [2] != 0 && value1 > 0) colorHit1 = 0.33;
                                if (hitMap [5] != 0 && value2 > 0) colorHit2 = 0.33;
                                if (hitMap [8] != 0 && value3 > 0) colorHit3 = 0.33;
                                if (hitMap [11] != 0 && value4 > 0) colorHit4 = 0.33;
                                if (hitMap [14] != 0 && value5 > 0) colorHit5 = 0.33;
                                if (hitMap [17] != 0 && value6 > 0) colorHit6 = 0.33;
                            }
                            else if (hitB == 4){
                                if (hitMap [2] != 0 && value1 > 0) colorHit1 = 0.25;
                                if (hitMap [5] != 0 && value2 > 0) colorHit2 = 0.25;
                                if (hitMap [8] != 0 && value3 > 0) colorHit3 = 0.25;
                                if (hitMap [11] != 0 && value4 > 0) colorHit4 = 0.25;
                                if (hitMap [14] != 0 && value5 > 0) colorHit5 = 0.25;
                                if (hitMap [17] != 0 && value6 > 0) colorHit6 = 0.25;
                            }
                            else if (hitB == 5){
                                if (hitMap [2] != 0 && value1 > 0) colorHit1 = 0.2;
                                if (hitMap [5] != 0 && value2 > 0) colorHit2 = 0.2;
                                if (hitMap [8] != 0 && value3 > 0) colorHit3 = 0.2;
                                if (hitMap [11] != 0 && value4 > 0) colorHit4 = 0.2;
                                if (hitMap [14] != 0 && value5 > 0) colorHit5 = 0.2;
                                if (hitMap [17] != 0 && value6 > 0) colorHit6 = 0.2;
                            }
                            else if (hitB == 6){
                                if (hitMap [2] != 0 && value1 > 0) colorHit1 = 0.13;
                                if (hitMap [5] != 0 && value2 > 0) colorHit2 = 0.13;
                                if (hitMap [8] != 0 && value3 > 0) colorHit3 = 0.13;
                                if (hitMap [11] != 0 && value4 > 0) colorHit4 = 0.13;
                                if (hitMap [14] != 0 && value5 > 0) colorHit5 = 0.13;
                                if (hitMap [17] != 0 && value6 > 0) colorHit6 = 0.13;
                            }
                            
                            if (value1 > 0 && colorNo1 == "8") colorHit1 = colorHit1*0.941;
                            else if (value1 > 0 && colorNo1 == "9") colorHit1 = colorHit1*0.922;
                            
                            if (value2 > 0 && colorNo2 == "8") colorHit2 = colorHit2*0.941;
                            else if (value2 > 0 && colorNo2 == "9") colorHit2 = colorHit2*0.922;
                            
                            if (value3 > 0 && colorNo3 == "8") colorHit3 = colorHit3*0.941;
                            else if (value3 > 0 && colorNo3 == "9") colorHit3 = colorHit3*0.922;
                            
                            if (value4 > 0 && colorNo4 == "8") colorHit4 = colorHit4*0.941;
                            else if (value4 > 0 && colorNo4 == "9") colorHit4 = colorHit4*0.922;
                            
                            if (value5 > 0 && colorNo5 == "8") colorHit5 = colorHit5*0.941;
                            else if (value5 > 0 && colorNo5 == "9") colorHit5 = colorHit5*0.922;
                            
                            if (value6 > 0 && colorNo6 == "8") colorHit6 = colorHit6*0.941;
                            else if (value6 > 0 && colorNo6 == "9") colorHit6 = colorHit6*0.922;
                            
                            *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3+value4*(double)colorHit4+value5*(double)colorHit5+value6*(double)colorHit6));
                            *bitmapData++ = 0;
                        }
                    }
                    
                    delete [] hitMap;
                }
                else if (imageBmpTifFlag == 1){
                    double *hitMap = new double [20];
                    
                    if (colorNo1 == "1"){
                        hitMap [0] = 0;
                        hitMap [1] = 0;
                        hitMap [2] = 1;
                    }
                    else if (colorNo1 == "2"){
                        hitMap [0] = 0;
                        hitMap [1] = 1;
                        hitMap [2] = 0;
                    }
                    else if (colorNo1 == "3"){
                        hitMap [0] = 1;
                        hitMap [1] = 1;
                        hitMap [2] = 0;
                    }
                    else if (colorNo1 == "4"){
                        hitMap [0] = 1;
                        hitMap [1] = 0;
                        hitMap [2] = 0;
                    }
                    else if (colorNo1 == "5"){
                        hitMap [0] = 1;
                        hitMap [1] = 0;
                        hitMap [2] = 1;
                    }
                    
                    if (colorNo2 == "1"){
                        hitMap [3] = 0;
                        hitMap [4] = 0;
                        hitMap [5] = 1;
                    }
                    else if (colorNo2 == "2"){
                        hitMap [3] = 0;
                        hitMap [4] = 1;
                        hitMap [5] = 0;
                    }
                    else if (colorNo2 == "3"){
                        hitMap [3] = 1;
                        hitMap [4] = 1;
                        hitMap [5] = 0;
                    }
                    else if (colorNo2 == "4"){
                        hitMap [3] = 1;
                        hitMap [4] = 0;
                        hitMap [5] = 0;
                    }
                    else if (colorNo2 == "5"){
                        hitMap [3] = 1;
                        hitMap [4] = 0;
                        hitMap [5] = 1;
                    }
                    
                    if (colorNo3 == "1"){
                        hitMap [6] = 0;
                        hitMap [7] = 0;
                        hitMap [8] = 1;
                    }
                    else if (colorNo3 == "2"){
                        hitMap [6] = 0;
                        hitMap [7] = 1;
                        hitMap [8] = 0;
                    }
                    else if (colorNo3 == "3"){
                        hitMap [6] = 1;
                        hitMap [7] = 1;
                        hitMap [8] = 0;
                    }
                    else if (colorNo3 == "4"){
                        hitMap [6] = 1;
                        hitMap [7] = 0;
                        hitMap [8] = 0;
                    }
                    else if (colorNo3 == "5"){
                        hitMap [6] = 1;
                        hitMap [7] = 0;
                        hitMap [8] = 1;
                    }
                    
                    for (int counter1 = imageXYLength-1; counter1 >= 0; counter1--){
                        for (int counter2 = 0; counter2 < imageXYLength; counter2++){
                            value0 = uploadTemp [1078+counter1*imageXYLength+counter2];
                            
                            if (value0 >= 0 && value0 < cutHoldDIC){
                                value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                                
                                if (value0 < 0) value0 = 0;
                            }
                            else{
                                
                                value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                                
                                if (value0 > 255) value0 = 255;
                            }
                            
                            if (statusHold1 == 1 && colorFlag1 == 1){
                                value1 = uploadTempCl1 [1078+counter1*imageXYLength+counter2];
                                
                                if (value1 < cutHold1) value1 = 0;
                                else{
                                    
                                    value1 = value1+(int)((value1-cutHold1)*levelHold1);
                                    
                                    if (value1 > 255) value1 = 255;
                                }
                            }
                            
                            if (statusHold2 == 1 && colorFlag2 == 1){
                                value2 = uploadTempCl2 [1078+counter1*imageXYLength+counter2];
                                
                                if (value2 < cutHold2) value2 = 0;
                                else{
                                    
                                    value2 = value2+(int)((value2-cutHold2)*levelHold2);
                                    
                                    if (value2 > 255) value2 = 255;
                                }
                            }
                            
                            if (statusHold3 == 1 && colorFlag3 == 1){
                                value3 = uploadTempCl3 [1078+counter1*imageXYLength+counter2];
                                
                                if (value3 < cutHold3) value3 = 0;
                                else{
                                    
                                    value3 = value3+(int)((value3-cutHold3)*levelHold3);
                                    
                                    if (value3 > 255) value3 = 255;
                                }
                            }
                            
                            if (statusHold1 == 0) value1 = 0;
                            if (statusHold2 == 0) value2 = 0;
                            if (statusHold3 == 0) value3 = 0;
                            
                            if (value1 <= 0 && value2 <= 0 && value3 <= 0){
                                *bitmapData++ = (unsigned char)value0;
                                *bitmapData++ = (unsigned char)value0;
                                *bitmapData++ = (unsigned char)value0;
                                *bitmapData++ = 0;
                            }
                            else{
                                
                                if (value1 < 0) value1 = 0;
                                if (value2 < 0) value2 = 0;
                                if (value3 < 0) value3 = 0;
                                
                                hitR = 0;
                                hitG = 0;
                                hitB = 0;
                                
                                if (value1 > 0 && statusHold1 != 0){
                                    if (hitMap [0] != 0) hitR++;
                                    if (hitMap [1] != 0) hitG++;
                                    if (hitMap [2] != 0) hitB++;
                                }
                                
                                if (value2 > 0 && statusHold2 != 0){
                                    if (hitMap [3] != 0) hitR++;
                                    if (hitMap [4] != 0) hitG++;
                                    if (hitMap [5] != 0) hitB++;
                                }
                                
                                if (value3 > 0 && statusHold3 != 0){
                                    if (hitMap [6] != 0) hitR++;
                                    if (hitMap [7] != 0) hitG++;
                                    if (hitMap [8] != 0) hitB++;
                                }
                                
                                colorHit1 = 0;
                                colorHit2 = 0;
                                colorHit3 = 0;
                                
                                if (hitR == 1){
                                    if (hitMap [0] != 0 && value1 > 0 ) colorHit1 = 1;
                                    if (hitMap [3] != 0 && value2 > 0 ) colorHit2 = 1;
                                    if (hitMap [6] != 0 && value3 > 0 ) colorHit3 = 1;
                                    
                                }
                                else if (hitR == 2){
                                    if (hitMap [0] != 0 && value1 > 0 ) colorHit1 = 0.5;
                                    if (hitMap [3] != 0 && value2 > 0 ) colorHit2 = 0.5;
                                    if (hitMap [6] != 0 && value3 > 0 ) colorHit3 = 0.5;
                                }
                                else if (hitR == 3){
                                    if (value1 > 0) colorHit1 = 0.33;
                                    if (value2 > 0) colorHit2 = 0.33;
                                    if (value3 > 0) colorHit3 = 0.33;
                                }
                                
                                *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3));
                                
                                colorHit1 = 0;
                                colorHit2 = 0;
                                colorHit3 = 0;
                                
                                if (hitG == 1){
                                    if (hitMap [1] != 0 && value1 > 0 ) colorHit1 = 1;
                                    if (hitMap [4] != 0 && value2 > 0 ) colorHit2 = 1;
                                    if (hitMap [7] != 0 && value3 > 0 ) colorHit3 = 1;
                                }
                                else if (hitG == 2){
                                    if (hitMap [1] != 0 && value1 > 0 ) colorHit1 = 0.5;
                                    if (hitMap [4] != 0 && value2 > 0 ) colorHit2 = 0.5;
                                    if (hitMap [7] != 0 && value3 > 0 ) colorHit3 = 0.5;
                                }
                                else if (hitG == 3){
                                    if (hitMap [1] != 0 && value1 > 0 ) colorHit1 = 0.33;
                                    if (hitMap [4] != 0 && value2 > 0 ) colorHit2 = 0.33;
                                    if (hitMap [7] != 0 && value3 > 0 ) colorHit3 = 0.33;
                                }
                                
                                *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3));
                                
                                colorHit1 = 0;
                                colorHit2 = 0;
                                colorHit3 = 0;
                                
                                if (hitB == 1){
                                    if (hitMap [2] != 0 && value1 > 0 ) colorHit1 = 1;
                                    if (hitMap [5] != 0 && value2 > 0 ) colorHit2 = 1;
                                    if (hitMap [8] != 0 && value3 > 0 ) colorHit3 = 1;
                                }
                                else if (hitB == 2){
                                    if (hitMap [2] != 0 && value1 > 0 ) colorHit1 = 0.5;
                                    if (hitMap [5] != 0 && value2 > 0 ) colorHit2 = 0.5;
                                    if (hitMap [8] != 0 && value3 > 0 ) colorHit3 = 0.5;
                                }
                                else if (hitB == 3){
                                    if (hitMap [2] != 0 && value1 > 0 ) colorHit1 = 0.33;
                                    if (hitMap [5] != 0 && value2 > 0 ) colorHit2 = 0.33;
                                    if (hitMap [8] != 0 && value3 > 0 ) colorHit3 = 0.33;
                                }
                                
                                *bitmapData++ = (unsigned char)((int)(value1*(double)colorHit1+value2*(double)colorHit2+value3*(double)colorHit3));
                                *bitmapData++ = 0;
                            }
                        }
                    }
                    
                    delete [] hitMap;
                }
            }
            else{
                
                if (imageBmpTifFlag == 0){
                    unsigned long headPosition = 0;
                    
                    dataConversion [0] = uploadTemp [0];
                    dataConversion [1] = uploadTemp [1];
                    
                    if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                    else endianType = 0;
                    
                    headPosition = 0;
                    
                    if (endianType == 1){
                        dataConversion [0] = uploadTemp [7];
                        dataConversion [1] = uploadTemp [6];
                        dataConversion [2] = uploadTemp [5];
                        dataConversion [3] = uploadTemp [4];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    else if (endianType == 0){
                        dataConversion [0] = uploadTemp [4];
                        dataConversion [1] = uploadTemp [5];
                        dataConversion [2] = uploadTemp [6];
                        dataConversion [3] = uploadTemp [7];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    
                    for (unsigned long counter1 = 8; counter1 < headPosition; counter1++){
                        value0 = uploadTemp [counter1];
                        
                        if (value0 >= 0 && value0 < cutHoldDIC){
                            value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                            
                            if (value0 < 0) value0 = 0;
                        }
                        else{
                            
                            value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                            
                            if (value0 > 255) value0 = 255;
                        }
                        
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = (unsigned char)value0;
                        *bitmapData++ = 0;
                    }
                }
                else if (imageBmpTifFlag == 1){
                    for (int counter1 = imageXYLength-1; counter1 >= 0; counter1--){
                        for (int counter2 = 0; counter2 < imageXYLength; counter2++){
                            value0 = uploadTemp [1078+counter1*imageXYLength+counter2];
                            
                            if (value0 >= 0 && value0 < cutHoldDIC){
                                value0 = value0-(int)((cutHoldDIC-value0)*levelHoldDIC);
                                
                                if (value0 < 0) value0 = 0;
                            }
                            else{
                                
                                value0 = value0+(int)((value0-cutHoldDIC)*levelHoldDIC);
                                
                                if (value0 > 255) value0 = 255;
                            }
                            
                            *bitmapData++ = (unsigned char)value0;
                            *bitmapData++ = (unsigned char)value0;
                            *bitmapData++ = (unsigned char)value0;
                            *bitmapData++ = 0;
                        }
                    }
                }
            }
        }
        else if (grayColorStatus == 1){
            int dataConversion [4];
            int endianType = 0;
            
            unsigned long headPosition = 0;
            
            dataConversion [0] = uploadTemp [0];
            dataConversion [1] = uploadTemp [1];
            
            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
            else endianType = 0;
            
            headPosition = 0;
            
            if (endianType == 1){
                dataConversion [0] = uploadTemp [7];
                dataConversion [1] = uploadTemp [6];
                dataConversion [2] = uploadTemp [5];
                dataConversion [3] = uploadTemp [4];
                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
            }
            else if (endianType == 0){
                dataConversion [0] = uploadTemp [4];
                dataConversion [1] = uploadTemp [5];
                dataConversion [2] = uploadTemp [6];
                dataConversion [3] = uploadTemp [7];
                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
            }
            
            int value0 = 0;
            int value1 = 0;
            int value2 = 0;
            
            for (unsigned long counter1 = 8; counter1 < headPosition-3; counter1 = counter1+3){
                value0 = uploadTemp [counter1];
                value0 = (int)(value0*(double)levelHoldR);
                
                if (value0 > 255) value0 = 255;
                
                value1 = uploadTemp [counter1+1];
                value1 = (int)(value1*(double)levelHoldG);
                
                if (value1 > 255) value1 = 255;
                
                value2 = uploadTemp [counter1+2];
                value2 = (int)(value2*(double)levelHoldB);
                
                if (value2 > 255) value2 = 255;
                
                *bitmapData++ = (unsigned char)value0;
                *bitmapData++ = (unsigned char)value1;
                *bitmapData++ = (unsigned char)value2;
                *bitmapData++ = 0;
            }
        }
        
        movieImage = [[NSImage alloc] initWithSize:NSMakeSize(imageXYLength, imageXYLength)];
        [movieImage addRepresentation:bitmapRepsCR];
        
        [self setNeedsDisplay:YES];
    }
}

-(void)drawRect:(NSRect)rect {
    NSRect srcRect;
    srcRect.origin.x = xPositionDisplay+xPositionAdjustDisplay+xPositionMoveDisplay;
    srcRect.origin.y = yPositionDisplay+yPositionAdjustDisplay+yPositionMoveDisplay;
    srcRect.size.width = imageXYLength/(double)(magnificationDisplay*0.1);
    srcRect.size.height = imageXYLength/(double)(magnificationDisplay*0.1);
    
    [movieImage drawInRect:rect fromRect:srcRect operation:NSCompositingOperationCopy fraction:1.0f];
    
    movieTiming = 0;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToMovieDisplay object:nil];
}

@end
