//
//  Controller.h
//  CellMovie2
//
//  Created by Masahiko Sato on 2014-09-29.
//
//

#ifndef CONTROLLER_H
#define CONTROLLER_H
#import <Cocoa/Cocoa.h>
#import "MovieDisplay.h"
#import "TiffFileRead.h"
#include <iostream>
#include <dirent.h>
#include <sys/stat.h>
#include <fstream>
#include <sstream>
#endif

using namespace std;

extern NSString *notificationToMovieDisplay;

//-------Basic info------
extern string pathNameString; //Path name
extern string analysisNameHold; //Analysis name
extern string treatNameHold; //Treat name
extern string imageDataPath; //Image data path
extern string imageDisplayPath; //Image display path
extern int grayColorStatus; //Hold gray color image status

//-----Arrays--------
extern string *fileList; //Hold name of files
extern int fileListCount;
extern int fileListStatus;
extern uint8_t *fileReadArray;//Array holding image data

//-------Basic operation------
extern int maxImageNo; //Largest image no
extern int timePointHold; //Current time point
extern int movieRunningFlag; //Set when movie is on
extern int filePosition; //Image position
extern int timePointDisplayCall; //Call to display time
extern int movieTiming; //Movie timing
extern int imageXYLength; //Image width
extern int imageBmpTifFlag; //Hold image format: 0 tif, 1 bmp

extern uint8_t *uploadTemp; //Hold DIC image
extern int uploadTempStatus;
extern uint8_t *uploadTempCl1; //Hold fluorescent image
extern int uploadTempStatusCl1;
extern uint8_t *uploadTempCl2; //Hold fluorescent image
extern int uploadTempStatusCl2;
extern uint8_t *uploadTempCl3; //Hold fluorescent image
extern int uploadTempStatusCl3;
extern uint8_t *uploadTempCl4; //Hold fluorescent image
extern int uploadTempStatusCl4;
extern uint8_t *uploadTempCl5; //Hold fluorescent image
extern int uploadTempStatusCl5;
extern uint8_t *uploadTempCl6; //Hold fluorescent image
extern int uploadTempStatusCl6;
extern long uploadTempFileSize; //File size of uploadTemps
extern int colorFlag1; //Fluorescent set flag
extern int colorFlag2; //Fluorescent set flag
extern int colorFlag3; //Fluorescent set flag
extern int colorFlag4; //Fluorescent set flag
extern int colorFlag5; //Fluorescent set flag
extern int colorFlag6; //Fluorescent set flag
extern string colorNo1; //Hold color no
extern string colorNo2; //Hold color no
extern string colorNo3; //Hold color no
extern string colorNo4; //Hold color no
extern string colorNo5; //Hold color no
extern string colorNo6; //Hold color no
extern string colorName1; //Hold color name
extern string colorName2; //Hold color name
extern string colorName3; //Hold color name
extern string colorName4; //Hold color name
extern string colorName5; //Hold color name
extern string colorName6; //Hold color name
extern double levelHold1; //Level hold
extern double levelHold2; //Level hold
extern double levelHold3; //Level hold
extern double levelHold4; //Level hold
extern double levelHold5; //Level hold
extern double levelHold6; //Level hold
extern double levelHoldDIC; //Level hold
extern double levelHoldR; //Level hold
extern double levelHoldG; //Level hold
extern double levelHoldB; //Level hold
extern double cutHold1; //Cut level hold
extern double cutHold2; //Cut level hold
extern double cutHold3; //Cut level hold
extern double cutHold4; //Cut level hold
extern double cutHold5; //Cut level hold
extern double cutHold6; //Cut level hold
extern double cutHoldDIC; //Cut level hold
extern int statusHold1; //Status hold
extern int statusHold2; //Status hold
extern int statusHold3; //Status hold
extern int statusHold4; //Status hold
extern int statusHold5; //Status hold
extern int statusHold6; //Status hold
extern int statusHoldDIC; //Status hold
extern int lastDICImageTime; //Last DIC image
extern int lastTIFRoundNo; //Last TIF image
extern int colorInfoDisplayCall; //Color info call

@interface Controller : NSObject <NSTextFieldDelegate> {
    int currentImageNo; //Current no of image
    int speedHold; //Speed
    int orientationHold; //Movie orientation
    
    double sliderFluorescentCHMax1; //Slider
    double sliderFluorescentCHMin1; //Slider
    double sliderFluorescentCHDiff1; //Slider
    double sliderCutCHMax1; //Slider
    double sliderCutCHMin1; //Slider
    double sliderCutCHDiff1; //Slider
    
    double sliderFluorescentCHMax2; //Slider
    double sliderFluorescentCHMin2; //Slider
    double sliderFluorescentCHDiff2; //Slider
    double sliderCutCHMax2; //Slider
    double sliderCutCHMin2; //Slider
    double sliderCutCHDiff2; //Slider
    
    double sliderFluorescentCHMax3; //Slider
    double sliderFluorescentCHMin3; //Slider
    double sliderFluorescentCHDiff3; //Slider
    double sliderCutCHMax3; //Slider
    double sliderCutCHMin3; //Slider
    double sliderCutCHDiff3; //Slider
    
    double sliderFluorescentCHMax4; //Slider
    double sliderFluorescentCHMin4; //Slider
    double sliderFluorescentCHDiff4; //Slider
    double sliderCutCHMax4; //Slider
    double sliderCutCHMin4; //Slider
    double sliderCutCHDiff4; //Slider
    
    double sliderFluorescentCHMax5; //Slider
    double sliderFluorescentCHMin5; //Slider
    double sliderFluorescentCHDiff5; //Slider
    double sliderCutCHMax5; //Slider
    double sliderCutCHMin5; //Slider
    double sliderCutCHDiff5; //Slider
    
    double sliderFluorescentCHMax6; //Slider
    double sliderFluorescentCHMin6; //Slider
    double sliderFluorescentCHDiff6; //Slider
    double sliderCutCHMax6; //Slider
    double sliderCutCHMin6; //Slider
    double sliderCutCHDiff6; //Slider
    
    double sliderDICMax; //Slider
    double sliderDICMin; //Slider
    double sliderDICDiff; //Slider
    double sliderCutDICMax; //Slider
    double sliderCutDICMin; //Slider
    double sliderCutDICDiff; //Slider
    
    double sliderRMax; //Slider
    double sliderRMin; //Slider
    double sliderRDiff; //Slider
    
    double sliderGMax; //Slider
    double sliderGMin; //Slider
    double sliderGDiff; //Slider
    
    double sliderBMax; //Slider
    double sliderBMin; //Slider
    double sliderBDiff; //Slider
    
    string *arrayDirectoryInfo; //For file sorting
    int directoryInfoCount;
    int directoryInfoLimit;
    
    int sliderStart; //Slider start
    int sliderEnd; //Slider end
    
    IBOutlet NSTextField *analysisName;
    IBOutlet NSTextField *treatment;
    IBOutlet NSTextField *timePoint;
    IBOutlet NSTextField *direction;
    IBOutlet NSTextField *speed;
    IBOutlet NSTextField *movieStatus;
    IBOutlet NSTextField *movieText;
    
    IBOutlet NSTextField *chLabel1;
    IBOutlet NSTextField *chLabel2;
    IBOutlet NSTextField *chLabel3;
    IBOutlet NSTextField *chLabel4;
    IBOutlet NSTextField *chLabel5;
    IBOutlet NSTextField *chLabel6;
    
    IBOutlet NSTextField *chName1;
    IBOutlet NSTextField *chName2;
    IBOutlet NSTextField *chName3;
    IBOutlet NSTextField *chName4;
    IBOutlet NSTextField *chName5;
    IBOutlet NSTextField *chName6;
    
    IBOutlet NSTextField *chLevel1;
    IBOutlet NSTextField *chLevel2;
    IBOutlet NSTextField *chLevel3;
    IBOutlet NSTextField *chLevel4;
    IBOutlet NSTextField *chLevel5;
    IBOutlet NSTextField *chLevel6;
    IBOutlet NSTextField *chLevelDIC;
    IBOutlet NSTextField *chLevelR;
    IBOutlet NSTextField *chLevelG;
    IBOutlet NSTextField *chLevelB;
    
    IBOutlet NSTextField *chCut1;
    IBOutlet NSTextField *chCut2;
    IBOutlet NSTextField *chCut3;
    IBOutlet NSTextField *chCut4;
    IBOutlet NSTextField *chCut5;
    IBOutlet NSTextField *chCut6;
    IBOutlet NSTextField *chCutDIC;
    
    IBOutlet NSTextField *chStatus1;
    IBOutlet NSTextField *chStatus2;
    IBOutlet NSTextField *chStatus3;
    IBOutlet NSTextField *chStatus4;
    IBOutlet NSTextField *chStatus5;
    IBOutlet NSTextField *chStatus6;
    
    IBOutlet NSTextField *chDICImage;
    IBOutlet NSTextField *chColor;
    
    IBOutlet NSSlider *sliderLevel1;
    IBOutlet NSSlider *sliderLevel2;
    IBOutlet NSSlider *sliderLevel3;
    IBOutlet NSSlider *sliderLevel4;
    IBOutlet NSSlider *sliderLevel5;
    IBOutlet NSSlider *sliderLevel6;
    IBOutlet NSSlider *sliderLevelDIC;
    IBOutlet NSSlider *sliderLevelR;
    IBOutlet NSSlider *sliderLevelG;
    IBOutlet NSSlider *sliderLevelB;
    
    IBOutlet NSSlider *sliderCut1;
    IBOutlet NSSlider *sliderCut2;
    IBOutlet NSSlider *sliderCut3;
    IBOutlet NSSlider *sliderCut4;
    IBOutlet NSSlider *sliderCut5;
    IBOutlet NSSlider *sliderCut6;
    IBOutlet NSSlider *sliderCutDIC;
    
    IBOutlet NSSlider *sliderLevelCircle1;
    IBOutlet NSSlider *sliderLevelCircle2;
    IBOutlet NSSlider *sliderLevelCircle3;
    IBOutlet NSSlider *sliderLevelCircle4;
    IBOutlet NSSlider *sliderLevelCircle5;
    IBOutlet NSSlider *sliderLevelCircle6;
    IBOutlet NSSlider *sliderLevelCircleDIC;
    IBOutlet NSSlider *sliderLevelCircleR;
    IBOutlet NSSlider *sliderLevelCircleG;
    IBOutlet NSSlider *sliderLevelCircleB;
    
    IBOutlet NSSlider *sliderCutCircle1;
    IBOutlet NSSlider *sliderCutCircle2;
    IBOutlet NSSlider *sliderCutCircle3;
    IBOutlet NSSlider *sliderCutCircle4;
    IBOutlet NSSlider *sliderCutCircle5;
    IBOutlet NSSlider *sliderCutCircle6;
    IBOutlet NSSlider *sliderCutCircleDIC;
    
    IBOutlet NSCell *sliderKnobLevel1;
    IBOutlet NSCell *sliderKnobLevel2;
    IBOutlet NSCell *sliderKnobLevel3;
    IBOutlet NSCell *sliderKnobLevel4;
    IBOutlet NSCell *sliderKnobLevel5;
    IBOutlet NSCell *sliderKnobLevel6;
    
    IBOutlet NSCell *sliderKnobCut1;
    IBOutlet NSCell *sliderKnobCut2;
    IBOutlet NSCell *sliderKnobCut3;
    IBOutlet NSCell *sliderKnobCut4;
    IBOutlet NSCell *sliderKnobCut5;
    IBOutlet NSCell *sliderKnobCut6;
    
    IBOutlet NSStepper *stepper;
    
    IBOutlet NSWindow *controllerWindow;
    IBOutlet NSBrowser *listBrowser;
    
    NSTimer *timerCD;
    
    id tiffFileRead;
}

/*
 Tif file will be read at address 8 to to the -1 of IDF. Image has to be written in one block, as it will be read without using block addresses to reduce file uploading time.
 */

-(id)init;
-(void)dealloc;
-(void)display;
-(void)directoryInfoUpDate;
-(void)dataSetAndDisplay;

-(IBAction)quitProcess:(id)sender;
-(IBAction)startProcess:(id)sender;
-(IBAction)directionSet:(id)sender;
-(IBAction)stepperAction:(id)sender;
-(IBAction)tableReload:(id)sender;
-(IBAction)tenFW:(id)sender;
-(IBAction)tenBW:(id)sender;
-(IBAction)hundredFW:(id)sender;
-(IBAction)hundredBW:(id)sender;
-(IBAction)browserDoubleClick:(id)browser;

-(IBAction)chSet1:(id)sender;
-(IBAction)chSet2:(id)sender;
-(IBAction)chSet3:(id)sender;
-(IBAction)chSet4:(id)sender;
-(IBAction)chSet5:(id)sender;
-(IBAction)chSet6:(id)sender;
-(IBAction)sliderLevelCH1:(id)sender;
-(IBAction)sliderLevelCH2:(id)sender;
-(IBAction)sliderLevelCH3:(id)sender;
-(IBAction)sliderLevelCH4:(id)sender;
-(IBAction)sliderLevelCH5:(id)sender;
-(IBAction)sliderLevelCH6:(id)sender;
-(IBAction)sliderLevelDIC:(id)sender;
-(IBAction)sliderLevelR:(id)sender;
-(IBAction)sliderLevelG:(id)sender;
-(IBAction)sliderLevelB:(id)sender;
-(IBAction)sliderCutCH1:(id)sender;
-(IBAction)sliderCutCH2:(id)sender;
-(IBAction)sliderCutCH3:(id)sender;
-(IBAction)sliderCutCH4:(id)sender;
-(IBAction)sliderCutCH5:(id)sender;
-(IBAction)sliderCutCH6:(id)sender;
-(IBAction)sliderCutDIC:(id)sender;
-(IBAction)sliderLevelCHCircle1:(id)sender;
-(IBAction)sliderLevelCHCircle2:(id)sender;
-(IBAction)sliderLevelCHCircle3:(id)sender;
-(IBAction)sliderLevelCHCircle4:(id)sender;
-(IBAction)sliderLevelCHCircle5:(id)sender;
-(IBAction)sliderLevelCHCircle6:(id)sender;
-(IBAction)sliderLevelDICCircle:(id)sender;
-(IBAction)sliderLevelRCircle:(id)sender;
-(IBAction)sliderLevelGCircle:(id)sender;
-(IBAction)sliderLevelBCircle:(id)sender;
-(IBAction)sliderCutCHCircle1:(id)sender;
-(IBAction)sliderCutCHCircle2:(id)sender;
-(IBAction)sliderCutCHCircle3:(id)sender;
-(IBAction)sliderCutCHCircle4:(id)sender;
-(IBAction)sliderCutCHCircle5:(id)sender;
-(IBAction)sliderCutCHCircle6:(id)sender;
-(IBAction)sliderCutDICCircle:(id)sender;
-(IBAction)resetCH1:(id)sender;
-(IBAction)resetCH2:(id)sender;
-(IBAction)resetCH3:(id)sender;
-(IBAction)resetCH4:(id)sender;
-(IBAction)resetCH5:(id)sender;
-(IBAction)resetCH6:(id)sender;
-(IBAction)resetDIC:(id)sender;
-(IBAction)resetR:(id)sender;
-(IBAction)resetG:(id)sender;
-(IBAction)resetB:(id)sender;
-(IBAction)dicImageSelect:(id)sender;
-(void)setCH1:(int)mode;
-(void)setCH2:(int)mode;
-(void)setCH3:(int)mode;
-(void)setCH4:(int)mode;
-(void)setCH5:(int)mode;
-(void)setCH6:(int)mode;

@end
